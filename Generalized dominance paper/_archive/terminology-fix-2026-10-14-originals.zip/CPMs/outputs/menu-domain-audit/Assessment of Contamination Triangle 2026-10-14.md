# Assessment of The Contamination Triangle — 14 October 2026

This is a targeted mathematical and assumptions audit, not a full independent referee report on every result in the source collection. Sources read include the consolidated TeX, its check report, the central arguments in N20, the scope reports in N19 and N24, and the relevant passages of N21/N23. The earlier conditional-probability example in Loss Dominance Generalized v2 and the additive necessity argument in R1 were checked directly.

## Verdict

The main accept-or-silence impossibility argument appears sound and materially advances the programme. Its construction of straight level sets, exclusion of pinning, slope/rotation bounds, and two-stage blow-up remove the previously assumed first-order regularity. I found no Bayes-at-selection-index assumption in that argument. The extension to the explicitly stated non-adjacent domain class has the same scope, subject to its cited reduction.

It does not establish impossibility of exact coverage under the adopted ordinal axioms, or even under additive rankings on arbitrary menu domains. The choice is not yet between approximation and non-additive rankings.

## Why the conditional-probability warning does not invalidate this theorem

Use different letters throughout:

- s is the index of the closed competitive selection C_s required by (S).
- q is a numerical weighting used to form q·L.
- B_q denotes a Bayes minimiser for that numerical weighting.

No identity C_s = B_s is required. In the conditional example in LDG v2, the certifying prior q_0(s) differs from s, can discard cells, and has support contained in supp(s). This is exactly the latitude that must be retained.

For finite integral penalties on a full measurable menu domain, the following separate argument is legitimate:

1. A pointwise minimiser gives B_q for each q.
2. For strictly positive q, B_q is Pareto-undominated: a strict improvement in one coordinate and no worsening in any coordinate strictly lowers q·L.
3. LDG's KKM theorem, using whatever selection satisfies (S), supplies a coherent selected weak dominator of B_q. Undominatedness forces equality of profiles; (C) makes B_q coherent.
4. If local Bayes advice ties on a non-null set, arbitrary measurable splicing of the tied actions yields Bayes models. A radial splice can be non-conic, hence incoherent. Therefore the Bayes model is unique modulo null sets at each interior q.
5. Pointwise finite-action gaps and dominated convergence give continuity in measure of q ↦ B_q in the interior, and thus Hausdorff continuity of its credal set. This is continuity of the auxiliary Bayes family, not continuity imposed on the (S) selection.
6. Compact convexity of the attainable integral loss profiles yields a supporting numerical weighting for any undominated target. For an interior credal target, local freedom and strict bad-versus-silence penalties rule out a boundary supporting weighting.

Consequently the entire interior Bayes family, including an interior Bayes occurrence of the target, is a necessary object for this additive class. Reindexing the selection, or using boundary certifying weights to construct it, cannot remove this auxiliary family.

Boundary Bayes models need not all be coherent or unique. The conditional example illustrates exactly this. The main no-go uses the interior family and limits towards edges, not a requirement that the (S) selection be Bayes at its index. Its negative direction does not depend on the converse closed-choice construction.

## Scope qualifications

1. **Non-adjacency is substantive.** The proved extension requires non-adjacency for almost every pair with an orientation in D_{K'}, for some K' contained in the interior of the target triangle. This cone contains the target's entire acceptance cone and a collar. It is stronger than requiring two actions merely in a neighbourhood of its boundary. The consolidated check report explicitly corrects the weaker wording.
2. **The restriction is not without loss of generality.** The note itself explains that deleting the opposite acceptance can remove vertex selections or destroy coherence of Bayes models. General three-action menus remain an additive route.
3. **Numerical representation remains a restriction.** Integrable local penalties are assumptions of the additive theorem, not consequences of (G), (IB), (LA), (S), (C). The charge extensions and coherent-almost-preference extensions have their own explicit hypotheses. Completeness alone is not the coherent-almost-preference representation assumption.
4. **The almost-preference residual is a real gap.** Unique coherent minimisers at almost every weighting do not give them at every weighting. The auxiliary integral field need not itself satisfy (S) and (C); one cannot apply the necessity argument to it without establishing that. Property (U) supplies missing content, not a harmless choice of parametrisation.
5. **Permitted negligible-stakes ties remain open.** Section 7.1 expressly says that transfer of the unconditional proof to permitted ties has not been examined. The earlier conditional transfer is not an unconditional no-go.
6. **Other dimensions and targets remain distinct questions.** The result is three-world and concerns all-facing triangles in general position. It is not a classification of all coverable credal sets.

## A specific imported geometric assumption to repair

Section 5 of the consolidated TeX and N21's setup choose a closed conic neighbourhood N_0 of the nonzero target boundary contained in the LF neighbourhood N. N23 repeats that setup. LF grants an arbitrary open N, not a conic one.

For example, writing F for the boundary of the open acceptance cone,

    N = {g : dist(g,F) < exp(-||g||)}

is an open neighbourhood of every boundary point. Its angular width tends to zero at large radii, so it contains no conic neighbourhood of all nonzero boundary rays. Compactness on a sphere only gives control on that sphere, not along whole rays.

This is a missing justification, not a counterexample to the general-menu conclusions. A plausible repair is to use neighbourhoods of bounded facet representatives and their compact unions, employing homogeneity of lower previsions where needed without assuming homogeneity of the menus. The proof must check all shifted gambles, witnesses and splices stay in the actual LF neighbourhood. The accept-or-silence theorem starts with an explicitly conic U and is unaffected.

## Recommended next work

- Retain exact coverage as the open aim; report the new theorem as a strong restricted impossibility.
- Repair the LF/conic-neighbourhood step before treating the general-menu dichotomy as fully audited under precisely the adopted LF condition.
- Prioritise the two general-menu configurations, including the full three-action choice setting. This is an additive route with direct decision-theoretic meaning, not an exotic loophole.
- Separately audit the unconditional argument under permitted negligible-stakes ties. Do not infer transfer from the conditional theorem.
- For coherent almost-preferences, isolate property (U) with all quantifiers and distinguish the original ranking from its auxiliary integral field.
- Keep arbitrary (IB) preorders open. No representation theorem supplied here reduces all of them to the excluded class.

In plain English: ordinary sums of independent binary-advice penalties cannot vindicate the contamination triangle in the accept-or-silence setting while satisfying the adopted dominance conditions. That is a real limitation, not merely a failure of smooth constructions. Whether the full permitted class of accuracy rankings can vindicate it is still unresolved.
