# Assessment of R10–R13 and resolution of the three-world boundary gap

13 October 2026. New arguments below are author-checked, not independently refereed.

## Main outcome

The new round makes genuine progress. The forced-acceptance escape is closed for interior targets under strict guidance; the no-plateau theorem is a genuine single-target restriction; the sandwiching reduction supplies much more than merely making one target Bayes.

There is also a new result beyond the round: **the boundary-selection gap can be closed in three worlds without patching tie points individually.** A full proof is in [Closed Choice from Interior Bayes Uniqueness.tex](</Users/jk13942/Documents/CPMs/outputs/menu-domain-audit/Closed Choice from Interior Bayes Uniqueness.tex>) and its [PDF](</Users/jk13942/Documents/CPMs/outputs/menu-domain-audit/Closed Choice from Interior Bayes Uniqueness.pdf>).

## Assessment of the reported results

### Vertex anchoring

The central argument in R10a Theorem V / R10b Proposition V is sound with the R12 repairs. Local freedom near a target-boundary point with g_i=0 forces the world-i ideal to agree locally with the halfspace g_i>0. Convexity of that ideal then forces its entire open acceptance cone into that halfspace, so its credal set contains e_i.

For a target K contained in int Δ, this holds at every world. Any effectively forced accepted gamble belongs to every vertex model, so it cannot have a negative coordinate. This closes the specific proposed escape of forcing mixed-gamble acceptance inside the target. It does not prohibit all forced advice: forced unanimous acceptance and forced silence in other regions remain possible. The strict-guidance hypothesis is essential; the conclusion does not automatically transfer to Σ_T.

There is a minor additional wording issue in R10a §1: an arbitrary open (LF) neighbourhood cannot necessarily be shrunk to a conic neighbourhood containing the entire nonzero boundary. Its angular width might shrink with the radius. The local vertex proof needs only small balls, so no conic shrink is needed. Once the compatible union-of-cones availability has been proved, that availability can supply the conic neighbourhood used in subsequent cone arguments. Keep these two steps separate.

### No plateau

R10b's Lemma M and Theorem PL supply a genuine improvement over a prescribed-family obstruction. At a facet crossing, leaving a region where a target vertex remains present forces passage through the precise model at that vertex. Two such pinned vertices lead to the nearest-point contradiction. The R12 corrections to relative openness and the triangle crossing count should be retained.

This excludes a plateau of Bayes models for the stated targets under the full global hypotheses, including the unconditional n≥3 contamination extension. It does not exclude a family that moves immediately away from the target as the weighting changes.

### Concave chart obstruction and positive polygons

R10a's ray argument is useful and short: concavity plus the vanishing weighted sum makes the components linear on each target facet; the coordinate crossings identify positive slopes; matching at three independent corner rays gives a contradiction. Its scope is a concave homogeneous chart representative near the target, not arbitrary measurable local penalties.

The gauge-mixture formula and approximability overlap with the earlier work, as R12 records. Compatibility on maximal availability and the explicit polygonal examples are useful additions. The nearby covered polygons show that the no-plateau/zero-exterior-ratio condition itself is not a coverage obstruction. A triangle no-go needs a feature distinguishing triangles from those polygons; corner-ray structure is a promising route, not a proof that no other method could work.

### Sandwiching and the boundary

R13's countable reduction is correct: the finite-action L¹ penalty space is separable, and a dense countable subfamily still detects every strictly positive comparison gap. R11's aggregate then has a unique coherent Bayes model at every interior weighting, coherent vertex models, and the interior target as Bayes at a full-support weighting.

The countability of edge tie points is also correct, but countability alone does not solve the compatibility of boundary insertions. R13 correctly leaves the proposed one-point construction unverified in full. There is a simpler route, described next.

The full-support conclusion for the target uses K⊆int Δ. R11 gives only a possibly boundary supporting weight for a general boundary-touching target. Do not summarise the full-support conclusion as applying to every coherent target.

## New theorem: boundary ties do not obstruct closed choice in three worlds

Assume finite additive losses with integrable local envelopes and strict guidance on a menu domain. Suppose every interior weighted objective has a unique coherent Bayes model. Then the rankings satisfy (LA), (S), and (C), regardless of ties at boundary weights.

Two ingredients prove this.

1. **Every undominated loss profile has a unique coherent realisation.** Support the profile by a nonnegative weight. Interior supports are covered by hypothesis, and vertex supports have unique pointwise best advice. At an edge support w=(w₁,w₂,0), the supporting face has x₂ determined by x₁. At an interior value of x₁, its efficient lower boundary x₃=h(x₁) has a finite subgradient. Thus the model minimises a second objective v·L with v₃>0 among the w-minimisers. Such a directional minimiser is unique: a non-null tie would persist for some small positive s in the interior objective (w+sv)·L, contradicting interior uniqueness. It is coherent as the limit of these interior Bayes models. Endpoints of the face's x₁-range use the unique local minimum or maximum of L₁ among the w-minimisers.

2. **Choose profiles using a strictly convex auxiliary objective.** Let R be the compact convex attainable loss set and choose a_i<min_R x_i. At index p minimise Q_p(x)=Σ p_i(x_i−a_i)². At an edge index, minimise the omitted coordinate among the Q_p-minimisers. This determines a unique efficient profile. Every limit profile as indices approach p minimises Q_p; its supported coordinates agree with the chosen profile, and its omitted coordinate is at least the chosen one. Each selected loss coordinate is therefore lower semicontinuous. This is precisely closedness of the comparison sections in (S). Competitiveness follows because an improvement at every supported world would lower Q_p.

The quadratic objective is only a device for choosing the selection map. It does not alter the additive rankings. The construction also explains why a homeomorphic relabelling of the original closed simplex is not the required fix: several boundary selection indices can correspond to the same supporting weight.

This proof removes the need for a global countable-patching theorem in three worlds. It also corrects the possible degenerate-inward-direction issue in R13: ties among directional minimisers in an inward direction are already excluded by interior Bayes uniqueness.

## Consequences and limits

| Question | Updated status |
|---|---|
| Closed competitive choice for three-world additive fields with unique coherent interior Bayes models | Proved in the new note; author-checked |
| Boundary condition (BT) in R11 for n=3 | Unnecessary |
| Sandwiched ordinal coverage of an interior credal target ⇒ additive coverage on the same domain, n=3 | Proved using R11, R13, and the new theorem; author-checked |
| Cardinality of the sandwiching family | Arbitrary; R13's separability argument applies |
| Additive coverage of the contamination triangle | Still open |
| Reduction for arbitrary independent preorders | Still open |
| Same reduction for all boundary-touching targets | Not established here |
| Same theorem for n≥4 | Not established; boundary supports can omit several worlds |
| Extension to weakened guidance orders | Not established; the proof uses distinct local losses for distinct actions at every world |

For the three-world additive single-target problem, there is now no separate boundary-selection obligation once the entire interior Bayes family is unique and coherent. The remaining task is to construct such a strictly guiding field through the triangle, or rule it out. For sandwiched ordinal systems covering interior targets, exactly that same additive existence problem is decisive.
