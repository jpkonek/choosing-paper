# Assessment of the menu-domain results

12 October 2026. Assessment of the round report and R1–R9 in the Generalized dominance paper folder.

## Verdict

There is substantial progress, especially on two-world systems built from additive criteria. The report's overall inference is too strong. These results make a rigidity conjecture worth pursuing; they do not establish that arbitrary independent ordinal rankings behave additively, or reduce the three-world coverage problem to one exotic remaining construction.

The principal distinctions are:

1. Representing the rankings themselves is different from reproducing their undominated family. The former can fail even in successful systems (R2 Proposition 4).
2. Reproducing an entire undominated family is stronger than reproducing coverage of one target.
3. Excluding a prescribed parametrised Bayes family is different from excluding one member of it under every possible family and parametrisation.
4. The strict-guidance results do not automatically apply to the accepted conditional shunning systems.

This is a direct assessment of the main arguments, hypotheses, and logical dependencies. It is not a fresh line-by-line certification of the older CPM no-go chain or of every external theorem used in R4's topological argument. No additional referee was commissioned for this assessment.

## Results that deserve to be retained

### Additive uniqueness and no nesting

R1 Lemma 1.4 / R2 Lemma U has a clean argument. If distinct advice minimises the same strictly positive weighted additive objective on a non-null set, every splice of those minimisers remains Bayes and hence undominated. A splice that changes advice with the radius is not a coherent cone. This contradicts the consequence of (LA), (S), and (C) that every undominated model is coherent.

R2 Theorem N's sign-pattern argument also works with R6's repair: the stated sufficient nesting condition is K_A contained in the interior of K_B **relative to aff Δ**, not the topology of Δ. Boundary-sharing nested intervals are not excluded by this condition.

Neither result excludes an individual imprecise target. Each target can have its own ranking system; that system need not also vindicate a precise model in the target's interior.

### Two-world family rigidity

R2 Theorem R reduces additive realisability of the undominated family to the absence of strictly nested intervals. Its construction uses the resulting continuous monotone path of interval endpoints.

R5 Theorem UN is a useful extension: separately choose one additive criterion at each world, obtain a common interior supporting prior for a hypothetical nested pair, and use the same incoherent splice for all such choices. The strict-comparison detection condition ensures that this splice is undominated in the original ranking. This avoids an unjustified aggregation of uncountably many criteria. R8's additional argument is needed when the original component losses are only weakly guiding.

R7's two-level lexicographic result is the strongest new structural result. Its central Lemma SF is particularly clear: non-ideal interior levels form an open subset of an interval by convexity, but closed choice makes them countable, so there are none. The subsequent case analysis excludes nesting. R9's repairs to Lemma A and the cross-face optimality argument should be incorporated into the source.

These prove two-world family equivalence for the stated classes. In three or more worlds, the sandwiching results establish necessary pairwise restrictions, not additive realisability of the entire family. The proofs still exploit finite-dimensional convex ranges of additive functionals. They are not yet proofs for arbitrary (IB) preorders.

## Two clarifications with explicit examples

### Bayes uniqueness is not uniqueness of the (S) selection

Let an ordinary two-world additive guidance loss have unique Bayes models B_t = D_(t,1−t). For example use the local penalties (0, |g_i|, 2|g_i|, 4|g_i|) for good, silence, bad, and contradictory advice on all models.

The selection C_t = B_(t²) also satisfies (S). Its profiles are continuous; its endpoints are the appropriate world ideals; and at every interior index it is an undominated model in complete rankings, hence competitive on both worlds. Yet C_t is generally not Bayes for the weight t.

Thus the precise uniqueness statement is:

> For a fixed additive system satisfying the axioms, each interior weighted objective has a unique Bayes minimiser modulo null sets.

The axioms do not require every admissible selection map to assign that minimiser to that same index.

### Error-only primaries can coexist with closed choice

Here is a counterexample to the unconditional wording, not to R3 Theorem L with its hypotheses.

Use all measurable models and the ordinary additive guidance losses L_i just described. Let H represent binary problems and let Q = {g in H: every coordinate is positive}. Define the same primary at every world by

    F(X) = μ{g in Q: X gives bad or contradictory advice at g}.

This primary is error-only: both good advice and silence receive zero. Rank world i lexicographically by (F(X), L_i(X)).

* Both levels are additive; the primary is weakly guiding and the secondary strictly guiding. Thus (G) and (IB) hold.
* Every coherent precise B_p has F(B_p)=0.
* If F(X)>0, replacing the erroneous unanimous advice with good advice strictly dominates X at every world.
* If F(X)=0, comparisons with B_p are exactly the ordinary secondary comparisons. The ordinary coherent Bayes family weakly dominates every such X, and uniqueness gives precisely the same undominated family.
* The closed section for X is all of Δ when F(X)>0, and is the ordinary additive closed section when F(X)=0. Competitiveness follows in the same way.
* Equal profiles with a selected model give equal secondary profiles, and secondary Bayes uniqueness establishes (C). The all-model domain supplies (LF) at every target it covers and (E).

So this is a nonzero error-only primary compatible with (LA), (S), (C), strict (G), and (IB). It violates R3's vertex-payment hypothesis (H1): its coherent vertex models pay zero primary loss everywhere. The theorem must retain (H1)–(H3) in every summary.

## What the contamination results do and do not show

R1 Theorem 4.1 excludes the prescribed Bayes family

    K_q = (1−ε) σ(q) + ε Δ,

on an open set, for the stated diagonal-projective σ (and its stated belief-function generalisation). The sign argument uses the affine dependence on q in precisely that family. It does not exclude an additive family that passes through one contamination target but has a different shape at nearby priors. Nor does it cover an arbitrary nonlinear reparametrisation of the family.

R4 Theorems A and B supply useful additional geometry. If acceptance and rejection regions meet along an interior boundary, the selected credal set there lies in g-perpendicular: approaching from opposite sides forces both its lower and upper expectation of g to be zero. Full-dimensional selected sets are therefore impossible on that boundary. This does not make such degeneracies inadmissible: target-only (LF) expressly allows other selections to be tangent or lower-dimensional.

The reported exhaustive residual is not established. The following remain separate issues:

* **Forced advice away from the target boundary.** R4 Remark B3 explicitly leaves it open. (LF) does not imply its (H0), which requires acceptance and silence to be available throughout the auxiliary domain. Excluding forced advice there would add a new domain assumption.
* **Regularity.** (H1)/(H1+) are extra hypotheses. Continuity relative to a co-null set does not supply a continuous representative off a closed null set. R1 itself gives densely discontinuous examples.
* **Classification of precise regions.** R8 marks R4 Proposition D as a GAP: nonconstant does not yet imply injective. The diagonal-projective conclusion is supported with an injectivity/local-homeomorphism hypothesis. Proposition F inherits that restriction. Hence “only diagonal-projective caps remain” overstates the proved reduction.
* **Earlier dependencies.** The contamination no-go chain is conditional in the new notes. Its application also requires the added availability and regularity hypotheses.

Consequently, “measurability and menus add only a little” is not a mathematical conclusion established here. R6 explicitly rejects the stronger domain-reduction slogan in R1 after Proposition 2.5.

The chart description is also not yet the advertised unconditional iff characterisation. R1 and R5 distinguish interior/vertex uniqueness from possible ties at other boundary priors. Their sufficiency statement requiring uniqueness at every prior is stronger than the proved necessary conditions. Boundary choices remain part of the problem.

## Corrections not yet incorporated in the source notes

The supplied notes must presently be read together with the referee reports. Examples still present in the source files include:

* R1's “domain shape gives no gain” claim, rejected in R6.
* R2's ambiguous interior convention for nesting, repaired in R6.
* R2's “avoidable exactly when” countability slogan: the theorem proves a necessary condition, not sufficiency for (S).
* R4's Proposition D, explicitly found to have a gap in R8.
* R4's “f=0” conclusion in Example E; R8 repairs it to f≤0, which means the family is everywhere precise.
* R7's missing constant-primary hypothesis in Lemma A and its claim that improvable members occur only at vertices/edge endpoints; R9 repairs the former and supplies a counterexample to the unrestricted latter statement.

These do not collectively refute the principal two-world theorem. They do mean that “refereed” is not a substitute for a consolidated corrected statement.

## Recommended next questions

1. **A single target first.** Can one additive menu-domain system satisfying target-only (LF) cover the three-world interior contamination triangle? Keep forced interior advice and merely measurable penalties allowed. This is the actual unsolved coverage test, as distinct from fixed-family realisation.
2. **Use a weaker reduction goal if sufficient.** For each target covered by an ordinal system, does some additive system cover that target while retaining the required domain freedom? Proving equality of the entire undominated family is stronger than is needed for this coverage conclusion.
3. **Separate the ordinal problem from additive-component classes.** The decisive missing argument would derive a useful representation or structural property from (G), (IB), and (S) themselves. More levels of additive lexicographic criteria are worth studying, but do not exhaust arbitrary independent rankings.
4. **Keep strict and conditional guidance conclusions separate.** The no-nesting proofs use strictly signed local differences. They cannot be applied to Σ_T without revisiting that step.
5. **Do not infer all n≥3 from n=3 silently.** The older contamination scope note explicitly does not establish n>3. A reduction preserving menus, null-set identification, (LF), and closed competitive choice would be needed, unless an obstruction is proved directly in each dimension.

## Suggested replacement summary

Closed competitive choice rules out several natural ways of enlarging undominated families beyond those available additively. In two worlds this yields additive-family equivalence for sandwichable rankings and for two additive lexicographic levels. In three worlds, new geometric restrictions strengthen the obstruction to prescribed contamination constructions, but additive coverage of a single contamination target remains open, with multiple unresolved possibilities. Arbitrary ordinal coverage remains open as well. The results motivate rigidity as a research conjecture; they do not yet show that full coverage fails under the accepted menu-domain axioms, nor that any such failure extends to the accepted weakened guidance orders.
