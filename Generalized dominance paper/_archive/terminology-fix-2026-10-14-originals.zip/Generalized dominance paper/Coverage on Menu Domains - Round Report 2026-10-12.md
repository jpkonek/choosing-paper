# Coverage on menu domains: round report, 12 October 2026 (revised 23:30)

**Setting.** The accepted guidance orders: strict four-rank, the D_Δ exception, and Σ_T. Together with (IB), (LA), (S), (C), (E), (LF) at the target, and menu domains (SC plus closedness in measure). The working briefs are `menu-domains-2026-10-12/BRIEF.md` and `BRIEF2.md`.

**This revision follows the auditor's assessment** (`CPMs/outputs/menu-domain-audit/Assessment of Menu Domain Results 2026-10-12.md`). The earlier summary of this report overstated the results. In particular:
- it claimed that the evidence points decisively towards impossibility;
- it called Bayes uniqueness a uniqueness of the selection;
- it treated the contamination-family obstruction as an obstruction to the target;
- it said that only one exotic escape remained.

All four statements are withdrawn.

**Where the statements are.** Every result, in corrected form and with its status, is in `menu-domains-2026-10-12/Consolidated Statements - Menu Domains 2026-10-12.md`. The section below, "Round 3 addendum", covers R10a, R10b, R11, R12 and R13. Statuses are those of independent AI referee passes; nothing has been checked by a human.

## What is and is not established

**Closed choice and non-additive rankings.**
- Closed competitive choice rules out several natural ways of making the set of undominated models larger than additive rankings allow.
- In two worlds this gives additive-family equivalence for two classes: sandwichable rankings (R5 Thm UN with R2 Thm R) and two-level additive lexicographic rankings (R7 Thm 1′₂).
- In three or more worlds the sandwiching results give necessary pairwise restrictions only.
- For a single target there is a stronger reduction. If a sandwiched system of any cardinality vindicates a target T, then a single additive system on the same menu domain makes T Bayes at an interior prior. That system also satisfies every interior and vertex condition. This is R11 Thm W with R13 Prop S.
- That additive system satisfies (S) once the condition (BT) holds: no non-null Bayes ties at non-vertex boundary priors. In three worlds such ties can occur at only countably many points of each edge (R13 Prop E).

**The three-world contamination triangle T1.**
- **Not excluded.** Additive coverage of the single target T1 remains open.
- **Excluded unconditionally.** No additive system covers T1 with a Bayes family that is constant on an open set of priors (a "plateau"). The same holds for every interior target with two vertices whose credal-set boundary crosses a coordinate hyperplane, which includes every interior triangle and every ε-contamination in any n ≥ 3. This is R10b Thm PL.
- **Excluded for concave charts.** Concave charts cover no triangle in general position (R10a Thm R).
- **Excluded for one natural family, conditionally.** Full-dimensional selections near the target are excluded, conditional on the CPM-folder no-go chain and on regularity hypothesis (H1).
- **Open cases** (R10a, R10b, R12):
  - adjacent three-action charts with degenerate selected sets;
  - charts with dense discontinuities;
  - the "zero exterior ratio" regime. This regime is inhabited by covered polygons near T1, so arguments that use only facet crossings cannot close T1; corner rays are needed.

**Nearby positive results.**
- Gauge mixtures K_p = ν(Σ p_i M_i) cover hexagons and 9-gons arbitrarily close to T1 (R10a Thm M, Prop M′).
- These approximants are polygons. Approximation as such was already known from v19's parallel bodies (cor:approx-all), and the mixture formula is NAL prop:average.
- New here: condition (M2) is exactly what makes the charts sign-preserving on the largest availability set.

**Arbitrary ordinal coverage remains open.** None of this shows that full coverage fails under the adopted axioms. Nor does it show that a failure would extend to Σ_T, or to n > 3, without a separate argument.

## Round 3 addendum: statements and status

All statements below are as repaired by R12 and R13.

### R10a
- **Thm V: REFEREED-CORRECT.** Assume (S), strict (G), (LA), (LF) at D_K, and n ≥ 3. For every e_i ∉ K, the vertex model is D_{V_i} with e_i ∈ V_i. Consequently, no menu can force acceptance of a mixed gamble with a negative coordinate. Cor V3 is restricted to mixed gambles.
- **Prop V4: REFEREED-REPAIRED.** It characterises the compatible vertex tuples. Its converse produces the targets Σ p_i V_i, not a prescribed target.
- **Lemma E: REFEREED-CORRECT.** It concerns boundary priors. Its use in place of FA's step (K4) needs a limiting step; R10b Lemma FS supplies it.
- **Thm M: REFEREED-CORRECT; overlap noted.** The system is the gauge mixture: f_i(h) = min_{M_i} m·h, availability Av = ∪ D_{V_i}, and conditions (M1) and (M2). It gives a unique, coherent Bayes model D_{K_p} at every prior, with K_p = ν(Σ p_i M_i). Every K_{p*} with p* interior and K_{p*} ⊆ int Δ is covered with (LF).
  - The formula is NAL prop:average.
  - Restricting to a convex cone gives a v19 concave CPM realisation.
- **Prop M′: REFEREED-CORRECT.** It gives covered polygons W ⊆ K_u with Hausdorff distance to T1 of order a/b + (ε − ε′). Approximation itself was already known (v19 cor:approx-all).
- **Thm R (ray lemma): REFEREED-CORRECT.** No triangle in general position has a realisation with concave, sign-preserving chart components near ∂D_K, for any prior p*. For T1 this was implied by NOGO; the general-triangle version and the short proof are new.
- **Thm P: correct under non-adjacency (Sp) plus R4 (K1) and (K3).** Superseded by R10b Thm PL, which needs neither.
- **Theorem O's "plateaus excluded unconditionally": FALSE AS LABELLED in R10a.** The claim is true via R10b Thm PL.

### R10b
- **Prop V, Lemma FS, Lemma UVN, Prop L, Lemma M, Lemma P, Thm PL, Cor PL2: REFEREED-CORRECT.**
  - Lemma D: the set involved is only relatively open.
  - The claim that every interior triangle has at least two crossing vertices is true; R12 supplies a valid proof.
- **Thm PL.** Let K have two vertices that cross coordinate hyperplanes. Then no open set of priors keeps both vertices in K_q while staying in their crossing wedges. In particular, K_q = K on an open set is impossible. This is unconditional and holds for every n ≥ 3 and every interior baseline.
- **Prop L (locality barrier).** The constant family K_q ≡ K is realisable on compact subsets of int Δ. So any obstruction must use priors approaching ∂Δ.

### R11 (with R13)
- **Lemma V, Lemma IC, Lemma RS, Fact 0, Lemma K, Thm W (a)–(e), Cor W1, Lemma SF_n, Prop LX: REFEREED-CORRECT.**
  - Lemma IC remark (ii) is FALSE as worded.
  - Cor T's list of instances must drop R1 Thm 4.1.
- **Lemma BT: REFEREED-REPAIRED.** A non-null boundary tie makes (S) fail for selections indexed by interior Bayes models. Reindexing by a power, as in C_t = B_{t²}, cannot rescue this; only blow-up reindexing can.
- **R13 Prop S (new).** Every sandwiched world is countably sandwiched, because L¹ is separable. So Thm W applies to all sandwiched systems.
- **R13 Prop E (new).** In three worlds, non-null boundary ties occur at only countably many points of each edge.
- **Not verified:** the n = 3 blow-up reindexing (§4.3).

## Next questions (from the auditor, updated)

1. Additive coverage of T1. The remaining cases are those listed under "The three-world contamination triangle" above; corner-ray arguments are needed.
2. Remove (BT) from the single-target reduction. Countably many tie points per edge, plus a blow-up reindexing, would do it.
3. Find a structural property of arbitrary (IB) preorders under (S), beyond the classes built from additive components.
4. Keep the strict-guidance conclusions separate from Σ_T.
5. Do not infer the case n > 3 from n = 3.

## Round 4 addendum (13 October): negligible-stakes indifference (NSI_θ)

**Definition.** NSI_θ was accepted in principle by the author. At world i, on a mixed problem whose world-i stake satisfies |g_i| ≤ θ‖g‖, good advice and silence tie. Everything else is strict.

**Result (REFEREED, N4).** For additive rankings on menu domains, NSI_θ covers the contamination triangle T1 for NO θ > 0, in either norm and for every ε. The same holds for ε-contamination of every interior baseline in every n ≥ 3.
- **Mechanism.** (G) forces exact ties on band problems. So the decision on a band problem cannot depend on how much weight its world receives: acceptance is constant along lines through that world's corner. Near the corner, strict guidance forces acceptance of nearby gambles with larger stakes. Coherence then forces acceptance of band gambles that the target rejects.
- **Proofs.** There are two independent complete proofs: N2 Cor C1, and N1 Thm 4.3 with Lemma 4.2. Neither uses boundary priors or regularity hypotheses.
- **Small thresholds are the worst case.** Every full-dimensional interior target is excluded below a positive threshold θ_cap(K) (N2 Thm Z).
- **Σ_T is no help here.** Σ_T with T containing a relevant world also fails for T1 (N4).
- **Ties permitted rather than forced.** This class contains the strict systems, but nothing shows that it has the same coverage. *(Corrected 13 Oct: the earlier sentence "T1 is the open strict problem again" was wrong; see `Audit of Imported Assumptions - Addendum 2026-10-13.md`, A1.)*

**Positive by-products.**
- Closed choice follows from unique coherent interior Bayes models under any guidance order in three worlds (N1 Thm 3.1, Chebyshev selection; N3 Thm CC_θ via blow-up; both REFEREED).
- The extension of CCIBU's selection step to n ≥ 4 is open beyond vertices and edges (R14).
- Under (DF), (ND) and non-adjacency, T1 and every all-facing triangle are excluded for strictly guiding additive systems (R15 Thm 6.2, REFEREED R18).

**Lesson (corrected 13 Oct).** Forced indifference that stops partway through a world creates a new obstruction where the tie region meets the strict region *and meets the target boundary as in N2 Thm B* (N4's repaired statement). The earlier general principle, that every useful weakening must avoid such an interface, is withdrawn. Total indifference at a world, as in Σ_T, does not cover T1 either.

## Round 5 addendum (13 October, afternoon): permitted negligible-stakes ties

**Question.** The author accepted *permitted* ties: on band problems (|g_i| ≤ θ‖g‖) good advice may tie with silence, and the ranking chooses where, even target-dependently. Everything else stays strict. Does this give exact coverage of T1 for small θ? Brief: `menu-domains-2026-10-12/BRIEF4.md`. Notes: N5 (structural), N6 (constructive), referee N7.

**Answer: no new route.** Status: REFEREED (N7), additive rankings only.
- **No ties next to the target, from inside.** A tied problem is decided, near world i's corner, by the other worlds alone, so it is rejected on the side of a world where the gamble is bad. A strictly good problem just below it (coordinatewise) is accepted near the corner. Coherent models accept everything above an accepted gamble. So the tie is impossible (N5 Lemma 3.1, N6 Lemma DL; any n, any good~silence tie rule). For T1, ties are null on all of D_T for θ < Θ_NT (sup norm: θ < 1; Euclidean: Θ_NT ≈ 0.92 at ε = 0.3). Near the boundary they can sit only in thin outer "horns" at the six coordinate crossings (N6 Thm NT, N5 Prop 3.2).
- **Vertex anchoring survives** (N5 Prop 3.5, N6 Thm V′). The coordinator's sketch for this was not valid as written; the result holds by a different argument.
- **R15 Thm 6.2 transfers for every θ > 0.** No realisation of T1 satisfies (DF), (ND) and (NA_w), whatever the placement of ties, both norms, every ε, every interior target weight (N5 Thm 5.1; the crossing rows stay positive by a sign argument, N5 Lemma 4.2). The first-order system and the box are literally the strict ones.
- **Closed choice** under permitted ties: N3's blow-up selection still works (CHECKED).

**What remains open.**
- The strict residual, unchanged: R15's escapes (E1)–(E4), i.e. realisations that fail (DF), (ND) or (NA_w) (kinked facets, sliding edges, flat facets, adjacency near vertices).
- Horn ties, outer ties far from ∂D_T and ties on reversed orientations are not excluded; not shown to help a realisation that fails (DF).
- Euclidean θ ∈ [Θ_NT, θ_x): outer ties near corners open (irrelevant for small θ).
- Non-additive rankings: untouched.

**Consequence.** Stake-limited good~silence indifference is inert at the target boundary. For T1 the decisive question is again the exact strict problem: an additive realisation that is non-differentiable at the target weight (auditor's step 2), or a non-additive mechanism (step 3).

## Round 6 addendum (13 October, late afternoon): non-additive rankings

**Question** (brief: `menu-domains-2026-10-12/BRIEF5.md`). Do the additive obstructions to covering T1 hold for every ranking satisfying the axioms (preorders, possibly incomplete or non-additive)? Can a non-additive ranking cover T1? Notes: N8 (structure), N9 (constructions), referee N10.

**Correction to the brief.** The "plateau test" as posed was empty. Any selection can be re-parametrised so that it equals the target on an open set of indices (compose with a continuous self-map of the simplex that never enlarges supports; N8 C2/C8, N9.1, REFEREED). The additive no-plateau theorem concerns the Bayes map, not the selection.

**Results (REFEREED, N10, with the repairs recorded there).**
- **Ranking-level facts that survive:** vertex anchoring (the vertex model is the world-i best available model and contains e_i); T1 is competitive on no proper set of worlds, so its indices are interior; a corrected face lemma; no coherent model is competitive on all three pairs of worlds; uncountably many selected profiles on each edge; a nonempty open set of indices whose models are competitive on all worlds but on no pair, with T1's indices strictly inside it; the selected profile cannot factor continuously through a tree.
- **Proofs that do not lift:** interior Bayes uniqueness, R10b's no-plateau lemmas and R15's corner calculus all use a canonical index structure (half-plane charts with strict signs) that general rankings need not have. This shows only that the proofs do not lift, not that the obstruction disappears.
- **Lexicographic rankings are not a route.** Two-level lexicographic systems with additive levels have unique coherent interior lex-Bayes models (N9.5). A design with T1 as the primary ideal (constant lex-Bayes map) satisfies every axiom except (S), which fails by the face-continuum theorem (N9.6, N9.7). If the primary is blind near ∂T, an incoherent model is undominated (N9.8).
- **Normal form (N9.4).** On the binary domain (accept-or-silence on U = D_{K′}, K′ a shrunk copy of K; forced silence elsewhere), a ranking with (G) and (IB) at a world is exactly a strictly monotone comparative ordering of that world's error sets satisfying de Finetti's cancellation condition.

**Frontier (as restated by N10).** Coverage of T1 is open both ways; the additive case is only conditionally excluded. An impossibility proof must produce a forced incoherent undominated model; every known way to do this uses half-plane charts with strict signs, Archimedean continuity, or level counting, and none is available for general (IB) preorders. A construction amounts to three strictly monotone, cancellative comparative orderings of error sets (complete or not, representable by measures or not), plus a closed competitive coherent selection containing T1. "Thinness" of the undominated set is a design aim, not a well-posed criterion until a topology on U_L is named.

## Round 7 addendum (13 October, evening): rankings that are coherent preferences

**Question** (brief: `menu-domains-2026-10-12/BRIEF6.md`). Can T1 be shown uncoverable under the adopted axioms plus the hypothesis that each world's ranking is a coherent preference in Walley's sense (1991 §§3.7–3.8; 2000 §6), applied to the loss gambles of a rank-increasing penalty encoding? Notes: N11 (reduction), N12 (additive core); referees N13, N14.

**Correction.** The brief said additive rankings are instances of every Walley variant. That is false for the strict-preference variants (N13 Prop A).

**(A) Reduction to additive rankings (N11; REFEREED, N13).**
- *Almost-preference* (closed cone, credal set M_i of finitely additive previsions): if every strict comparison is detected by some countably additive member of M_i (for instance, if all members are countably additive), then coverage of T1 yields an integral, strictly guiding additive field on the same domain. Its interior Bayes models are unique and coherent, and T1 is Bayes at an interior weighting. In three worlds, CCIBU makes that field cover T1.
- Weaker conclusions hold under countable detection plus strong non-atomicity (charge-valued fields, attained minimisers only), or with one member having a full-support countably additive part (N13 Prop B).
- Not reached: atomic singular parts of the charges; the non-Archimedean variant of Walley 2000 (blocked at "T1 lies in the lexicographic family").
- *Strict preference with openness* (Walley 1991 §3.7.7–3.7.9): with countably additive credal sets of positive density it violates (S) whenever two worlds' ideals differ (N13 Prop A). The class it defines may be empty (Conjecture N13.A), so it is not a useful hypothesis.
- The author's worry (disagreement among complete additive rankings protecting coherent models): harmless for the reduction direction, which runs through competitiveness from (S), not through undominatedness alone (N11.11, REFEREED).

**(B) The additive core (N12; REFEREED, N14).**
- *Reduction to credal families:* on the accept-or-silence domain a realisation is the same as a family q ↦ K_q with K_q ⊇ K′, K_{p*} = T1, and half-plane positivity sets. The family is automatically Hausdorff-continuous, so the irregularity of the reward field is irrelevant.
- *The edge box holds unconditionally* (no differentiability, non-degeneracy or adjacency hypothesis).
- *Kinks excluded:* if the support functions q ↦ min_{K_q} m·h have one-sided directional derivatives at p*, continuous in the direction and taking both signs (condition (DD), strictly weaker than R15's (DF)+(ND)), T1 has no realisation, for every ε.
- *Charges* concentrated near a closed null set, or spread over dense null sets (small-carrier lemma, proved in N14), reduce to the integral case, provided interior Bayes minimisers exist.
- *Remaining gap:* a realisation would need a facet with a non-isolated set of rays where (DD) fails: oscillating difference quotients, direction-discontinuous derivatives, or flat/half-flat facets. On domains with three-action menus the adjacency escape (E4) is added.

**Status.** No clean impossibility yet. Conditionally: under almost-preference with countably additive detection, T1 cannot be covered by any ranking whose additive shadow satisfies (DD) at the target weighting. The single remaining analytic question is whether (DD) can fail in a realisation.

## Round 8 addendum (13 October, night): the additive core closed on non-adjacent domains

Notes: N15 (proof), N16 (adversary), N17 (rankings that don't add up), N21 (adjacent domains), N22 (reduction for coherent almost-preferences); referees N18, N19, N20, N23, N24. Consolidated write-up: **The Contamination Triangle.tex / .pdf** (25 pp.), with a faithfulness check report.

- **Main theorem (REFEREED twice, N18 and N20).** On every menu domain with (LF) whose pairs meeting D_{K′} are non-adjacent, in particular on the accept-or-silence domain, no strictly guiding additive ranking satisfying the axioms covers T1, for any ε ∈ (0,1) and any interior target weighting. No regularity is assumed. The same holds for every all-facing triangle in general position, hence every interior ε-contamination, and for bounded charge penalties given interior Bayes minimisers. Key new steps: straight level lines of q ↦ min_{K_q} m·h; no pinning (R10b Cor PL2 off the target weighting); pivot chords; no sliding edges; slope–rotation inequalities, which give Lipschitz control and rule out first-order-flat facets; a blow-up that makes the facet maps projective; then the corner equation and the box. N16's "ratchet" first-order data are not realisable (N18).
- **General (LF) menu domains (REFEREED once, N23; R23.1–R23.4 given a second reading in the check report).** A covering must fall into one of two narrowly described configurations, (E5a) or (E4′); neither has been excluded.
- **Coherent almost-preferences (REFEREED once, N24).** On non-adjacent domains: no cover of T1 when every world is complete (with condition (UN)), or when strict comparisons are detected by countably additive previsions. In general, a cover forces an exceptional tie weight; the residual property (U) is a continuity property and is open.
- **Rankings that don't add up (N17; REFEREED, N19).** Not closed and not shown viable. Finite-atom models are useless (they contradict (S)). Fine (NC)-violating worlds exist, but no system with (S) is known to use a violation where it matters.

## Round 9 addendum (14 October): exceptional ties, three-action menus, two repairs

Notes: N25 (exceptional ties, impossibility side), N26 (exceptional ties, construction side), N27 (the two repairs the auditor asked for), N28 (three-action menus). Each was checked by one independent referee: N25_referee to N28_referee. The write-up **The Contamination Triangle.tex / .pdf** (now 41 pp.) incorporates these results and the auditor's corrections of 14 October. **The Contamination Triangle - round 9 changes.md** lists every change and its source. The 13 October version is kept as "The Contamination Triangle (13 Oct, pre-round 9)".

New terms.
- *Exceptional weighting:* an interior weighting at which the supporting additive assessment ψ ties a non-null set of problems. There, coherent and incoherent Bayes models coexist.
- *Atom chord:* a straight chord of the simplex made of exceptional weightings. It arises from a non-null set of problems (an *atom*) that all share the same chart line. (A problem's *chart line* is the set of weightings at which ψ is indifferent on that problem.)
- *Fan point:* a single exceptional weighting through which the chart lines of a non-null set of problems pass in a spread of directions.

**Exceptional ties (case M0).**
- **Shape of the exceptional set.** Proved in N25 and confirmed by the referee. The exceptional set is a countable union of atom chords, each cutting off one vertex of the simplex. It may be dense.
- **No fan points.** Proved only in the referee report (Prop F), so nobody else has checked it. It uses only the fact that ψ's Bayes models are coherent at almost every weighting.
- **Chords cannot be avoided.** If a ranking covers T1, then every supporting assessment has at least one atom chord. Choosing a different supporting assessment cannot remove them.
- **When the main theorem's argument fails.** If the target weighting lies on a chord, the argument cannot start: P(·,h) does not tend to 0 there for an open set of boundary gambles h. Proved, and confirmed with a repair.
- **Remaining configurations, both open:**
  - R-a′: the target weighting lies on a chord;
  - R-b′: the target weighting lies off the chords, but chords exist.
- **An ordinal mechanism exists, in two worlds.** N26.1, every axiom re-checked by the referee. It is an explicit two-world ranking that adds up and satisfies every axiom. The target is an intermediate tied model at the exceptional weighting, and every incoherent tied model is strictly dominated at both worlds. So an ordinal ranking can resolve an exceptional additive tie that its supporting assessment cannot. It adds no coverage, since in two worlds every target is already covered.
- **Two-level lexicographic rankings in three worlds.** N26.2–N26.7, confirmed with repairs. Their exceptional chords cannot cross, are rigid, and keep away from the target weighting. The referee's Prop R1 (one reader) adds: if the pivot step of the main proof still holds, there are no chords at all, so no such ranking covers T1. None of this transfers to general rankings that add up.

**Three-action menus (N28, confirmed with repairs).**
- **(E5a) is impossible.** One of the two round-8 residual configurations is closed. In every additive cover of T1 on an (LF) menu domain, almost every problem near the target offers both acceptances, and they compete.
- **Further consequences:**
  - the cuts converge to the vertices;
  - no interior credal set contains a vertex of the simplex;
  - credal sets on the crossing chords are never single points.
- **(E4′) becomes a problem about credal families.** It reduces to a geometric problem, CF(T1), about families of credal sets. Coverage holds iff CF(T1) has a solution. The converse direction rests on CCIBU, which so far only the author has checked.
- **Correction.** N28 inferred that nothing in (E4′) is consistent near the vertices. That inference was wrong: the referee's numerical "sector cap" example passes every constraint derived so far.

**Repairs (N27, confirmed).**
- **(LF) neighbourhood.** Every use of a cone-shaped neighbourhood was at bounded scale, so a compact collar inside the (LF) neighbourhood suffices. Nothing needs to be added to (LF), and the accept-or-silence theorem was never affected.
- **Permitted negligible-stakes ties.** The main theorem holds when such ties are allowed:
  - in the sup norm, for every band width θ < 1;
  - in the Euclidean norm, for θ < √((κ²+1)/(κ²+2)), which is above √(2/3) for every ε.
  - The remaining Euclidean window is open; the missing input is (VP), stated in N27.

**Status.** Coverage of T1 is still open. The auditor's two concrete questions stand, now sharper:
- (Q1) Can a ranking that adds up resolve its supporting assessment's atom-chord ties in configuration R-a′ or R-b′?
- (Q2) Does CF(T1) have a solution?

## Interpretation correction (14 October, 12:30; author)

A domain restriction is only a restriction on the class of evaluable models. A gamble f always represents the binary choice {f,0}, equivalently {g,h} for any g,h with f = g − h. On the U-domain the evaluable models are the measurable subsets D of U. For f ∈ U, D advises choosing g in {g,h} iff f ∈ D, and otherwise gives no advice. For f with f, −f ∉ U, every evaluated model gives no advice; nothing more follows.

Everything above that speaks of "menus", "forced silence", "available actions" or "the accept-or-silence domain" is superseded and must be read in these terms. The write-up now uses "decomposable domain", "advice range" and "U-domain". A check of the whole write-up found no argument that uses more than the restriction of the evaluable class (see "The Contamination Triangle - interpretation changes.md").
