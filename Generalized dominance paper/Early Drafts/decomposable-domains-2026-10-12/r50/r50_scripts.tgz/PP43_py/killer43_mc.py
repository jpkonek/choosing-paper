"""PP43 NUMERICS (no proof depends on it).  Run: python3 -I -B killer43_mc.py [N] > killer43_mc.out
For B = B_12(t), t in {1/2, 2}, eps = 3/10: Monte Carlo estimate of p = Phi(B -> T) = L(T) - L(B) and of the
margin h = mu . p (Thm 3.1's h(t)); then Thm 3.1's arithmetic in the most favourable case for B's gate,
v := V^B(B -> T) = 0: tail vector pi(D) = v - p, q = -pi(D), d = q - delta*1, and the killer value
eps*(d - q) = -eps*delta*(1,1,1) < 0 at every world.  Independent numpy implementation of l^T."""
import sys
import numpy as np

EPS = 0.3
c = (1 - EPS) / 3; L = (c + EPS) / c; dd = 1 / (1 + L)


def F(x):
    return np.where(x <= dd, x / (2 * dd), np.where(x <= 1 / L, 0.5 + L * (x - dd) / (2 * dd), L * x))


def G(s):
    return 1 / F(1 / s)


def field(g):
    a = np.abs(g); al, be, ga = a.copy(), a.copy(), a.copy()
    pos = (g > 0).sum(1)
    k = np.full(len(g), -1)
    k[pos == 1] = np.argmax(g[pos == 1] > 0, 1); k[pos == 2] = np.argmax(g[pos == 2] < 0, 1)
    for kk in range(3):
        m = k == kk
        for j in range(3):
            if j != kk:
                s = a[m, j] / a[m, kk]
                al[m, j] = a[m, kk] * G(s); be[m, j] = a[m, kk] * F(s)
    return al, be, ga


def pen(adv, g, fl):
    al, be, ga = fl
    corr = adv[:, None] * np.sign(g) > 0
    r = np.where(adv[:, None] == 0, 1, np.where(corr, 0, 2))
    return np.where(r == 0, 0, np.where(r == 1, al, al + be))


def Tans(g):
    S = g.sum(1); lo = c * S + EPS * g.min(1); hi = c * S + EPS * g.max(1)
    return np.where(lo > 0, 1, np.where(hi < 0, -1, 0))


def bayes(g, lam, fl):
    cs = np.stack([pen(np.full(len(g), a), g, fl) @ np.asarray(lam) for a in (1, -1, 0)], 1)
    return np.array([1, -1, 0])[np.argmin(cs, 1)]


N = int(sys.argv[1]) if len(sys.argv) > 1 else 400000
rng = np.random.default_rng(43)
g = rng.standard_normal((N, 3)); fl = field(g)
lT = pen(Tans(g), g, fl)
print(f"eps={EPS}, N={N}")
for t in (0.5, 2.0):
    mu = np.array([t / (1 + t), 1 / (1 + t), 0.0])
    lB = pen(bayes(g, mu, fl), g, fl)
    diff = lT - lB
    p = diff.mean(0); se = diff.std(0) / np.sqrt(N)
    h = mu @ p
    print(f"t={t}: p = Phi(B->T) = {np.round(p, 4)} (s.e. {np.round(se, 4)}),  h = mu.p = {h:.4f}")
    v = np.zeros(3)
    q = -(v - p); cq = mu @ q; delta = cq / 2; d = q - delta
    print(f"   v=0: pi(D) = v - p = {np.round(v - p, 4)}, mu.pi(D) = {mu @ (v - p):.4f} < 0;"
          f" d = q - delta*1 = {np.round(d, 4)}, mu.d = {mu @ d:.4f} > 0;"
          f" killer value / eps = d - q = {np.round(d - q, 4)}")
    # largest v (componentwise equal, v = s*1) for which the argument still applies: mu.v < h
    print(f"   Thm 3.1 applies whenever max_w v_w < h = {h:.4f}; PP40 Lemma 2.2 gives h >= h_0 > 0 on all t")
