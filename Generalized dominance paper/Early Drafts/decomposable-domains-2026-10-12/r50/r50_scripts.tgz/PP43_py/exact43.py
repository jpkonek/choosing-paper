"""PP43 exact checks (CHECKED).  Rational arithmetic only.  Run: python3 -I -B exact43.py > exact43.out

(a) Thm 2.3 design: witness points of R (T silent, B_12(t) strictly 3-better), the rank-linear tail
    fields psi^T, psi^B = psi^T + c*1[a != T]; check weak guidance of both, T pointwise u-optimal for psi^T,
    B pointwise mu-optimal for psi^B, kappa >= 0 on records out of T and <= 0 on records out of B,
    and the world-3 sign of Pi^T(T -> B) on R.  t in {1/3, 1/2, 9/10, 11/10, 2, 3}, eps in {3/10, 1/10}.
(b) Lemma 3.2 (local attainability for B_12(t)): exact generator points on M_1 with F(s2) = t +- eta,
    B_12(t)'s exact Bayes answers there, the exact l^T change vectors, and an exact decomposition
    d = sum c_i g_i with all c_i > 0 for 40 random rational targets d with mu.d > 0.
"""
from fractions import Fraction as Fr
import random

random.seed(43)
ADV = (1, -1, 0, 2)          # accept g, accept -g, silent, contradiction


def consts(eps):
    c = (1 - eps) / 3
    L = (c + eps) / c
    return c, L, 1 / (1 + L)


def F(th, eps):
    c, L, d = consts(eps)
    if th <= d:
        return th / (2 * d)
    if th <= 1 / L:
        return Fr(1, 2) + L * (th - d) / (2 * d)
    return L * th


def Finv(y, eps):
    c, L, d = consts(eps)
    if y <= Fr(1, 2):
        return 2 * d * y
    if y <= 1:
        return d + (y - Fr(1, 2)) * 2 * d / L
    return y / L


def G(s, eps):
    return 1 / F(1 / s, eps)


def sgn(x):
    return (x > 0) - (x < 0)


def minority(g):
    pos = sum(1 for x in g if x > 0)
    if pos in (0, 3):
        return -1
    if pos == 1:
        return [i for i in range(3) if g[i] > 0][0]
    return [i for i in range(3) if g[i] < 0][0]


def field(g, eps):
    a = [abs(x) for x in g]
    al, be, ga = a[:], a[:], a[:]
    k = minority(g)
    if k >= 0:
        for j in range(3):
            if j != k:
                s = a[j] / a[k]
                al[j] = a[k] * G(s, eps)
                be[j] = a[k] * F(s, eps)
    return al, be, ga


def rank(adv, g, w):
    if adv == 2:
        return 3
    if adv == 0:
        return 1
    return 0 if adv * sgn(g[w]) > 0 else 2


def pen(adv, g, w, fl):
    al, be, ga = fl
    r = rank(adv, g, w)
    return [0, al[w], al[w] + be[w], al[w] + be[w] + ga[w]][r]


def T_answer(g, eps):
    c = (1 - eps) / 3
    s = sum(g)
    lo = c * s + eps * min(g)
    hi = c * s + eps * max(g)
    return 1 if lo > 0 else (-1 if hi < 0 else 0)


def bayes(g, lam, fl, strict=True):
    costs = {a: sum(lam[w] * pen(a, g, w, fl) for w in range(3)) for a in ADV}
    m = min(costs.values())
    best = [a for a in ADV if costs[a] == m]
    if strict and len(best) != 1:
        return None
    return best[0]


def mu_of(t):
    return (t / (1 + t), 1 / (1 + t), Fr(0))


FAIL = []


def check(cond, msg):
    if not cond:
        FAIL.append(msg)


# ---------------------------------------------------------------- (a)
def part_a():
    print("(a) Thm 2.3 design on R (T silent, B_12(t) strictly 3-better)")
    for eps in (Fr(3, 10), Fr(1, 10)):
        for t in (Fr(1, 3), Fr(1, 2), Fr(9, 10), Fr(11, 10), Fr(2), Fr(3)):
            mu = mu_of(t)
            wits = []
            for _ in range(20000):
                k = 0 if t < 1 else 1
                s = [Fr(random.randint(1, 400), 100), Fr(random.randint(1, 400), 100)]
                g = [None] * 3
                g[k] = Fr(1)
                others = [j for j in range(3) if j != k]
                g[others[0]], g[others[1]] = -s[0], -s[1]
                fl = field(g, eps)
                Ta = T_answer(g, eps)
                Ba = bayes(g, mu, fl)
                if Ta == 0 and Ba is not None and rank(Ba, g, 2) < rank(Ta, g, 2):
                    wits.append((g, Ta, Ba))
                if len(wits) >= 25:
                    break
            check(len(wits) > 0, f"no R witness eps={eps} t={t}")
            # rank patterns on R
            pats = {tuple(rank(Ba, g, w) for w in range(3)) for g, Ta, Ba in wits}
            check(len(pats) == 1, f"pattern not unique {pats}")
            K = Fr(1)
            c = [Fr(1, 4), Fr(1, 4), Fr(1, 4)]
            if t < 1:      # R in M_1: phi1 = phi2 + phi3, (1-t) phi2 >= t phi3 + t c1 + c2
                phi2 = (t * K + t * c[0] + c[1]) / (1 - t) + 1
                phi = [phi2 + K, phi2, K]
            else:          # mirror on M_2: phi2 = phi1 + phi3, (t-1) phi1 >= phi3 + t c1 + c2
                phi1 = (K + t * c[0] + c[1]) / (t - 1) + 1
                phi = [phi1, phi1 + K, K]
            for w in range(3):
                check(c[w] <= phi[w], "c > phi")
            for g, Ta, Ba in wits:
                psiT = {a: [phi[w] * rank(a, g, w) for w in range(3)] for a in ADV}
                psiB = {a: [psiT[a][w] + (c[w] if a != Ta else 0) for w in range(3)] for a in ADV}
                for psi, name in ((psiT, "psiT"), (psiB, "psiB")):      # weak guidance per world
                    for w in range(3):
                        for a in ADV:
                            for b in ADV:
                                if rank(a, g, w) <= rank(b, g, w):
                                    check(psi[a][w] <= psi[b][w], f"{name} not weakly guiding")
                uT = {a: sum(psiT[a]) for a in ADV}
                check(all(uT[Ta] <= uT[a] for a in ADV), "T not u-optimal for psiT")
                mB = {a: sum(mu[w] * psiB[a][w] for w in range(3)) for a in ADV}
                check(all(mB[Ba] <= mB[a] for a in ADV), "B not mu-optimal for psiB")
                for a in ADV:   # kappa = psiB - psiT: >= 0 on changes out of T, <= 0 on changes out of B
                    for w in range(3):
                        kap_T = (psiB[a][w] - psiT[a][w]) - (psiB[Ta][w] - psiT[Ta][w])
                        kap_B = (psiB[a][w] - psiT[a][w]) - (psiB[Ba][w] - psiT[Ba][w])
                        check(kap_T >= 0 and kap_B <= 0, "kappa sign")
                d3 = psiT[Ba][2] - psiT[Ta][2]
                check(d3 == -K, "Pi^T_3(T->B) density != -K")
            print(f"  eps={eps} t={t}: {len(wits)} witnesses, T->B rank pattern on R = "
                  f"{[tuple(rank(Ba, wits[0][0], w) - rank(Ta, wits[0][0], w) for w in range(3))]}, "
                  f"phi={[str(x) for x in phi]}, c={[str(x) for x in c]}; psi^T_3(B)-psi^T_3(T) = -K")


# ---------------------------------------------------------------- (b)
def part_b():
    print("(b) Lemma 3.2: generators at B_12(t)'s 1-correct/silent threshold on M_1")
    for eps in (Fr(3, 10), Fr(1, 10)):
        for t in (Fr(1, 3), Fr(1, 2), Fr(9, 10), Fr(11, 10), Fr(2), Fr(3)):
            mu = mu_of(t)
            eta = Fr(1, 1000) * t
            gens = []
            for a3 in (Fr(1, 2), Fr(2)):
                s3 = Finv(a3, eps)
                for side in (+1, -1):
                    s2 = Finv(t + side * eta, eps)
                    g = [Fr(1), -s2, -s3]
                    check(minority(g) == 0, "not M_1")
                    fl = field(g, eps)
                    Ba = bayes(g, mu, fl)
                    want = 0 if side > 0 else 1          # silent above threshold, B (= +1, 1-correct) below
                    check(Ba == want, f"B_12(t) answer {Ba} != {want} at F(s2)=t{'+' if side > 0 else '-'}eta")
                    alt = 1 if Ba == 0 else 0
                    vec = [pen(alt, g, w, fl) - pen(Ba, g, w, fl) for w in range(3)]
                    check(vec[0] == -side and vec[1] == side * (t + side * eta) and vec[2] == side * a3,
                          f"change vector {vec}")
                    check(sum(mu[w] * vec[w] for w in range(3)) > 0, "mu-value not > 0")
                    gens.append(vec)
            # gens: [ +tau(a1)+eta e2, -tau(a1)+eta e2, +tau(a2)+eta e2, -tau(a2)+eta e2 ]
            ok = 0
            for _ in range(40):
                while True:
                    d = [Fr(random.randint(-50, 50), 10) for _ in range(3)]
                    md = sum(mu[w] * d[w] for w in range(3))
                    if md > 0:
                        break
                # d = x tau1 + y tau2 + (mu.d)(1+t) e2, tau(a) = (-1, t, a)
                a1, a2 = Fr(1, 2), Fr(2)
                # solve x + y = -d1 ; x a1 + y a2 = d3
                y = (d[2] + d[0] * a1) / (a2 - a1)
                x = -d[0] - y
                tot = md * (1 + t)
                e = eta
                m = (tot / e - abs(x) - abs(y)) / 4
                if m <= 0:
                    FAIL.append("eta too large for target"); continue
                cpos1 = (x if x > 0 else 0) + m
                cneg1 = (-x if x < 0 else 0) + m
                cpos2 = (y if y > 0 else 0) + m
                cneg2 = (-y if y < 0 else 0) + m
                cs = [cpos1, cneg1, cpos2, cneg2]
                comb = [sum(cs[i] * gens[i][w] for i in range(4)) for w in range(3)]
                check(comb == d, f"decomposition mismatch {comb} vs {d}")
                check(all(ci > 0 for ci in cs), "nonpositive coefficient")
                ok += 1
            print(f"  eps={eps} t={t}: generators {[[str(v) for v in gv] for gv in gens]}; "
                  f"{ok}/40 targets decomposed with all coefficients > 0")


if __name__ == "__main__":
    part_a()
    part_b()
    print("ALL PASS" if not FAIL else f"FAILURES ({len(FAIL)}): {FAIL[:10]}")
