#!/bin/bash
cd "$(dirname "$0")"
for d in PP37 PP38 PP40 PP41; do
  for s in $d/*.py; do
    b=$(basename $s .py)
    case $b in field38|field40) continue;; esac
    arg=""
    [ "$b" = "twofield_lp" ] && arg=4000
    start=$(date +%s)
    ( cd $d && timeout 1500 python3 -I -B $b.py $arg > $b.out 2> $b.err )
    echo "$d/$b exit=$? secs=$(( $(date +%s)-start ))" >> times.log
  done
done
echo DONE >> times.log
