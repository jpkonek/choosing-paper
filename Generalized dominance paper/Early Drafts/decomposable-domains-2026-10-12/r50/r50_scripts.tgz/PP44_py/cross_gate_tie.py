"""PP44 cross_gate_tie.py -- counterexample to PP41 Prop 4.1(b) (all-world tie through two gates).

CHECKED (exact rational):
 (1) witness points, with strict margins, of four cones of D_t = {T != B_12(t)}, t = 1/2, eps = 3/10:
     (i)   Sil(T) n M_3            T = S, B = A
     (ii)  R_t c Sil(T) n M_1       T = S, B = A   (G(theta) > t)
     (iii) M_2, T = A, B = B        (G(theta) > t)
     (iv)  Sil(T) n M_1, B = B      (F(theta) < t)
     and the rank-change pattern of T -> B on each.
 (2) rank-linear angular tail fields pi^T (on (iii),(iv)) and pi^B (on (i),(ii)), coefficients >= 0
     (weakly guiding), zero elsewhere; T is pi^T-Bayes at u and B is pi^B-Bayes at mu = (t,1,0)/(1+t)
     against all four advice options, on each region's class.
 (3) Pi^T(T -> B) > 0 at all three worlds and Pi^B(B -> T) > 0 at all three worlds (unit angular
     weights per region).
NUMERICS (Gaussian MC, n = 400000): envelope bound E_w = int (alpha+beta+gamma)_w dmu, the value
     Phi(T -> B_12(t)), and the resulting scale K making V^T(T->X) > 0 and V^B(X->T) > 0 everywhere.
Run: python3 -I -B cross_gate_tie.py > cross_gate_tie.out
"""
from fractions import Fraction as Fr
import random
import numpy as np

random.seed(4402)
EPS = Fr(3, 10); C = (1 - EPS) / 3
L = (C + EPS) / C; D = 1 / (1 + L)
MV = [tuple(C + (EPS if i == j else 0) for j in range(3)) for i in range(3)]
TT = Fr(1, 2)


def Fx(th):
    if th <= D: return th / (2 * D)
    if th <= 1 / L: return Fr(1, 2) + L * (th - D) / (2 * D)
    return L * th


def Gx(s): return 1 / Fx(1 / s)
def sgn(x): return (x > 0) - (x < 0)
def dot(a, b): return sum(x * y for x, y in zip(a, b))


def cls(g):
    s = [sgn(x) for x in g]
    for k in range(3):
        o = [w for w in range(3) if w != k]
        if s[k] != s[o[0]] and s[o[0]] == s[o[1]]:
            return k
    return -1


def T(g):
    v = [dot(p, g) for p in MV]
    return 1 if min(v) > 0 else (-1 if max(v) < 0 else 0)


def B12(g, t=TT):
    k = cls(g)
    if k in (-1, 2): return sgn(g[0])
    th = abs(g[1]) / abs(g[0])
    if Fx(th) < t: return sgn(g[0])
    if Gx(th) > t: return sgn(g[1])
    return 0


def rank(a, g, w):
    if a == 2: return 3
    if a == 0: return 1
    return 0 if a * sgn(g[w]) > 0 else 2


out = []
def log(s): out.append(s); print(s)
ok = True


def rnd(signs):
    return tuple(sg * Fr(random.randint(1, 80), random.randint(1, 9)) for sg in signs)


regions = {
    'i':   ((-1, -1, 1), lambda g: T(g) == 0 and B12(g) == sgn(g[0])),
    'ii':  ((1, -1, -1), lambda g: T(g) == 0 and B12(g) == sgn(g[1])),
    'iii': ((-1, 1, -1), lambda g: T(g) == sgn(g[0]) and B12(g) == sgn(g[1])),
    'iv':  ((1, -1, -1), lambda g: T(g) == 0 and B12(g) == sgn(g[0])),
}
wit, pat = {}, {}
for name, (signs, pred) in regions.items():
    for _ in range(400000):
        g = rnd(signs)
        if pred(g):
            wit[name] = g
            pat[name] = [rank(B12(g), g, w) - rank(T(g), g, w) for w in range(3)]
            break
    th = abs(wit[name][1]) / abs(wit[name][0])
    log(f"(1) region ({name}): g = {tuple(str(x) for x in wit[name])}, theta = {th}, "
        f"T = {T(wit[name])}, B = {B12(wit[name])}, rank change T->B = {pat[name]}")
ok &= len(wit) == 4


def bayes_ok(c, lam, g, adv):
    cost = lambda a: sum(lam[w] * c[w] * rank(a, g, w) for w in range(3))
    best = cost(adv)
    return all(cost(a) >= best for a in (1, -1, 0, 2))


u = (Fr(1, 3),) * 3
mu = (TT / (1 + TT), 1 / (1 + TT), Fr(0))
piT = {'iii': (1, 0, 1), 'iv': (1, 1, 0)}
piB = {'i': (1, 1, 0), 'ii': (0, 1, 1)}
for name, c in piT.items():
    b = bayes_ok(c, u, wit[name], T(wit[name]))
    log(f"(2) pi^T on ({name}): c = {c} >= 0; T u-Bayes for pi^T on this class: {b}")
    ok &= b and min(c) >= 0
for name, c in piB.items():
    b = bayes_ok(c, mu, wit[name], B12(wit[name]))
    log(f"(2) pi^B on ({name}): c = {c} >= 0; B mu-Bayes for pi^B on this class: {b}")
    ok &= b and min(c) >= 0
PiT = [sum(piT[n][w] * pat[n][w] for n in piT) for w in range(3)]
PiB = [sum(piB[n][w] * (-pat[n][w]) for n in piB) for w in range(3)]
log(f"(3) Pi^T(T -> B) per unit angular weight = {PiT};  Pi^B(B -> T) = {PiB}")
ok &= min(PiT) > 0 and min(PiB) > 0
log("CHECKED part: " + ("ALL PASS" if ok else "FAIL"))

# NUMERICS
rng = np.random.default_rng(4402)
n = 400000
g = rng.standard_normal((n, 3))
a = np.abs(g)
eps = float(EPS); Lf = float(L); df = float(D)
def Fv(th):
    return np.piecewise(th, [th <= df, (th > df) & (th <= 1 / Lf), th > 1 / Lf],
                        [lambda x: x / (2 * df), lambda x: 0.5 + Lf * (x - df) / (2 * df), lambda x: Lf * x])
def Gv(s): return 1.0 / Fv(1.0 / s)
pos = (g > 0).sum(1)
k = np.full(n, -1); m1 = pos == 1; m2 = pos == 2
k[m1] = np.argmax(g[m1] > 0, 1); k[m2] = np.argmax(g[m2] < 0, 1)
al, be, ga = a.copy(), a.copy(), a.copy()
for kk in range(3):
    m = k == kk
    for j in range(3):
        if j != kk:
            s = a[m, j] / a[m, kk]
            al[m, j] = a[m, kk] * Gv(s); be[m, j] = a[m, kk] * Fv(s)
env = (al + be + ga).mean(0)
c = (1 - eps) / 3
S_ = g.sum(1); lo = c * S_ + eps * g.min(1); hi = c * S_ + eps * g.max(1)
Tv = np.where(lo > 0, 1, np.where(hi < 0, -1, 0))
th = np.where(k >= 0, a[:, 1] / np.maximum(a[:, 0], 1e-300), 0)
Bv = np.where((k == -1) | (k == 2), np.sign(g[:, 0]),
              np.where(Fv(th) < float(TT), np.sign(g[:, 0]), np.where(Gv(th) > float(TT), np.sign(g[:, 1]), 0)))
def rk(adv):
    corr = adv[:, None] * np.sign(g) > 0
    return np.where(adv[:, None] == 0, 1, np.where(corr, 0, 2))
def pen(adv):
    r = rk(adv)
    return np.where(r == 0, 0.0, np.where(r == 1, al, al + be))
Phi = (pen(Bv) - pen(Tv)).mean(0)
log(f"NUMERICS: envelope E_w = int(alpha+beta+gamma)_w = {np.round(env, 3)}; Phi(T -> B_12(1/2)) = {np.round(Phi, 4)}")
K = 1.1 * env.max() / min(PiT); K2 = 1.1 * env.max() / min(PiB)
log(f"  any K > max E_w / min Pi^T_w works for T's gate regardless of the ball removed; e.g. K = {K:.3f}, K' = {K2:.3f}")
log(f"  V^T(T->B) = Phi + K Pi^T = {np.round(Phi + K * np.array(PiT, float), 3)} (all > 0)")
log(f"  V^B(B->T) = -Phi + K' Pi^B = {np.round(-Phi + K2 * np.array(PiB, float), 3)} (all > 0)")
open("cross_gate_tie.out", "w").write("\n".join(out) + "\n")
