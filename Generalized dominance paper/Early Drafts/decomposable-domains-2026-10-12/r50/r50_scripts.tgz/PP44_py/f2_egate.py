"""PP44 f2_egate.py -- CHECKED (exact rational arithmetic).  Referee round 49, items on PP37 Thm 5.6 / Prop 5.5.

(a) Per-unit-mass rank changes on M_1 for the record  r = (O_A, A -> S) u (O_B, B -> S)
    and its values under the L-gate (rho = (2,1,1) on M_1) and ANY two-world balanced E-gate
    (sigma_1 = sigma_2 = sigma on W_12) when mu(O_A) = mu(O_B) and sigma(O_A) = sigma(O_B):
    all values are 0 at every world.  Hence under S = {w0} (L strict at w0 only) with the E-gate
    symmetric at w0 (forced by PP37 Prop 5.2), T and X = T[O_A u O_B -> S] are tied at all worlds.
(b) Witness points with strict margins (so non-null neighbourhoods) of
      M_1 n {T = A} n {D = A}   and   M_1 n {T = B} n {D = B}
    for D a non-vertex member of PP37 Prop 4.3's edge family (thresholds (alpha, tau), tau = 1).
(c) Prop 5.5 without (H5): S -> A and S -> B on equal-mass pieces of Sil(T) n M_k have zero
    L-value at every world (no registered R needed: T realises one side of each direction);
    witness points of Sil(T) n M_k for k = 1, 2, 3.
eps = 3/10.  Run: python3 -I -B f2_egate.py > f2_egate.out
"""
from fractions import Fraction as Fr
import random

random.seed(4401)
EPS = Fr(3, 10); C = (1 - EPS) / 3
ALPHA = C / (C + EPS); BETA = (C + EPS) / C
MV = [tuple(C + (EPS if i == j else 0) for j in range(3)) for i in range(3)]


def sgn(x): return (x > 0) - (x < 0)
def dot(a, b): return sum(x * y for x, y in zip(a, b))


def cls(g):
    s = [sgn(x) for x in g]
    for k in range(3):
        o = [w for w in range(3) if w != k]
        if s[k] != s[o[0]] and s[o[0]] == s[o[1]]:
            return k
    return -1


def ans_K(points, g):
    v = [dot(p, g) for p in points]
    return 1 if min(v) > 0 else (-1 if max(v) < 0 else 0)


def T(g): return ans_K(MV, g)


def rank(a, g, w):
    if a == 2: return 3
    if a == 0: return 1
    return 0 if a * sgn(g[w]) > 0 else 2


out = []
def log(s): out.append(s); print(s)

ok = True
# (a) rank tables on M_1 (class index 0): representative g = (1,-1,-1) direction
g0 = (Fr(1), Fr(-1), Fr(-1))
A_adv = -1 * sgn(g0[0]) * -1  # majority answer: sign agreeing with worlds 2,3 -> advice = sgn(g0[1])
A_adv = sgn(g0[1]); B_adv = sgn(g0[0])
rA = [rank(A_adv, g0, w) for w in range(3)]
rS = [rank(0, g0, w) for w in range(3)]
rB = [rank(B_adv, g0, w) for w in range(3)]
log(f"(a) ranks on M_1: A {rA}, S {rS}, B {rB}")
dA = [rS[w] - rA[w] for w in range(3)]   # A -> S
dB = [rS[w] - rB[w] for w in range(3)]   # B -> S
rho = [2, 1, 1]
L_A = [rho[w] * dA[w] for w in range(3)]; L_B = [rho[w] * dB[w] for w in range(3)]
log(f"    per unit mass: A->S delta {dA}, rho*delta {L_A};  B->S delta {dB}, rho*delta {L_B}")
Lsum = [L_A[w] + L_B[w] for w in range(3)]
Esum = [dA[w] + dB[w] for w in (0, 1)]  # sigma_1 = sigma_2 = sigma, equal sigma-mass
log(f"    equal mu-mass and equal sigma-mass: L-values {Lsum}, E-values (worlds 1,2) {Esum}")
ok &= Lsum == [0, 0, 0] and Esum == [0, 0]

# (b) witnesses
TAU0, TAU1 = ALPHA, Fr(1)
def D_edge(g):
    k = cls(g)
    if k == -1: return sgn(g[0])
    if k == 2: return sgn(g[0])           # A on M_3 (= sign of worlds 1,2)
    th = abs(g[1]) / abs(g[0])
    if th < TAU0: return sgn(g[0])        # 1-correct
    if th > TAU1: return sgn(g[1])        # 2-correct
    return 0
# strict margins: D's thresholds strict, T's min/max strict
def margins(g):
    lo = min(dot(p, g) for p in MV); hi = max(dot(p, g) for p in MV)
    th = abs(g[1]) / abs(g[0])
    return lo, hi, th
wA = wB = None
for _ in range(200000):
    g = (Fr(random.randint(1, 60), random.randint(1, 9)), -Fr(random.randint(1, 60), random.randint(1, 9)),
         -Fr(random.randint(1, 60), random.randint(1, 9)))
    if cls(g) != 0: continue
    t, d = T(g), D_edge(g)
    lo, hi, th = margins(g)
    if t == sgn(g[1]) and d == sgn(g[1]) and hi < 0 and th > TAU1 and wA is None: wA = (g, hi, th)
    if t == sgn(g[0]) and d == sgn(g[0]) and lo > 0 and th < TAU0 and wB is None: wB = (g, lo, th)
    if wA and wB: break
log(f"(b) D = edge segment with theta-thresholds ({TAU0}, {TAU1}) (Prop 4.3 family, alpha < 1 < beta = {BETA})")
log(f"    M_1, T = A = D: g = {wA[0]}, max_m m.g = {wA[1]} < 0, theta = {wA[2]} > {TAU1}")
log(f"    M_1, T = B = D: g = {wB[0]}, min_m m.g = {wB[1]} > 0, theta = {wB[2]} < {TAU0}")
ok &= wA is not None and wB is not None

# (c) Prop 5.5 without (H5)
for k in range(3):
    o = [w for w in range(3) if w != k]
    wit = None
    for _ in range(200000):
        g = [None] * 3
        g[k] = Fr(random.randint(1, 60), random.randint(1, 9))
        for w in o: g[w] = -Fr(random.randint(1, 60), random.randint(1, 9))
        g = tuple(g)
        lo = min(dot(p, g) for p in MV); hi = max(dot(p, g) for p in MV)
        if lo < 0 < hi: wit = (g, lo, hi); break
    A_a, B_a = sgn(wit[0][o[0]]), sgn(wit[0][k])
    rr = lambda a: [rank(a, wit[0], w) for w in range(3)]
    dSA = [rr(A_a)[w] - rr(0)[w] for w in range(3)]
    dSB = [rr(B_a)[w] - rr(0)[w] for w in range(3)]
    rh = [2 if w == k else 1 for w in range(3)]
    tot = [rh[w] * (dSA[w] + dSB[w]) for w in range(3)]
    log(f"(c) Sil(T) n M_{k+1}: witness g = {wit[0]} (min {wit[1]} < 0 < max {wit[2]});"
        f" S->A {dSA}, S->B {dSB}; L-values on equal mass {tot}")
    ok &= tot == [0, 0, 0]
log("ALL PASS" if ok else "FAIL")
