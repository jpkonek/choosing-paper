"""PP42 script 3 (NUMERICS; no proof depends on it). Vertex caps under l^T, and one repair.

(a) Phi^T(T -> C^v_delta) for v = 3 and several delta (eps = 0.3): world v positive, the two
    other worlds negative and equal (symmetry), and u.Phi / Phi_v -> 0 (Lemma 4.1(iii)-(iv)).
(b) The cap's own field l^C (= l^T, except on H := {C != T}: worlds w != v scaled by a, world v
    scaled by b) makes C the pointwise u-Bayes model on sampled points of H (Thm 4.2(a)).
(c) One repair (Thm 4.2(b)): the fill X = T[G -> V_1], G a ball deep in Sil(T) ∩ M_1, has
    Phi^T_3(T -> X) > 0; the cap C^3 with suitable (a, b) satisfies Phi^C_w(C -> X) > 0 at all w.
Run: python3 -I -B caps_mc.py > caps_mc.out
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from field40 import field, pen, T, consts

rng = np.random.default_rng(2026)
EPS = 0.3
c, L, d = consts(EPS)
Mv = np.array([[c + (EPS if i == j else 0) for j in range(3)] for i in range(3)])


def cap_verts(v, delta):
    others = [Mv[i] for i in range(3) if i != v]
    ps = [Mv[v] + (delta / EPS) * (o - Mv[v]) for o in others]
    return np.array(others + ps)


def DK(verts, g):
    vals = g @ verts.T
    return np.where(vals.min(1) > 0, 1, np.where(vals.max(1) < 0, -1, 0))


N = 2_000_000
g = rng.standard_normal((N, 3))
fl = field(g, EPS)
tg = T(g, EPS)
v = 2  # world 3 (0-based index 2)
print(f"(a) eps={EPS}, v=3, N={N} Gaussian samples; Phi^T(T->C) = E[l^T(C) - l^T(T)] per world")
for delta in (EPS / 5, EPS / 10, EPS / 20, EPS / 40):
    cg = DK(cap_verts(v, delta), g)
    H = cg != tg
    diff = np.zeros(3)
    se = np.zeros(3)
    pc, pt = pen(cg, g, fl), pen(tg, g, fl)
    for w in range(3):
        x = (pc[:, w] - pt[:, w]) * H
        diff[w] = x.mean()
        se[w] = x.std() / np.sqrt(N)
    ratio = diff.sum() / 3 / diff[v]
    print(f"   delta={delta:.4f}: mu(H)={H.mean():.2e}  Phi=({diff[0]:+.3e}, {diff[1]:+.3e}, {diff[2]:+.3e})"
          f"  s.e.={se.max():.1e}  u.Phi/Phi_v={ratio:.3f}")

# (b) own-field Bayes on H
delta = EPS / 20
verts = cap_verts(v, delta)
cg = DK(verts, g)
H = cg != tg
a_amp, b_disc = 1.0, 0.001
al, be, ga = fl


def pen_C(adv, idx):
    """penalties of advice adv on sample indices idx under l^C (H points)."""
    gg = g[idx]
    sub = (al[idx], be[idx], ga[idx])
    p = pen(adv, gg, sub).astype(float)
    scale = np.full(3, a_amp)
    scale[v] = b_disc
    return p * scale


idx = np.where(H)[0]
sig = cg[idx]
cost = {}
for name, adv in (("sigma", sig), ("silent", np.zeros_like(sig)), ("opposite", -sig), ("contra", np.full_like(sig, 2))):
    cost[name] = pen_C(adv, idx) @ np.full(3, 1 / 3)
best = all((cost["sigma"] < cost[k]).all() for k in ("silent", "opposite", "contra"))
print(f"(b) delta={delta:.4f}, a={a_amp}, b={b_disc}: |H sample|={len(idx)}; cap answer is the strict u-optimum under l^C"
      f" at every sampled H point: {best}")

# (c) one repair
ctr = np.array([1.0, -0.6, -0.6])     # in Sil(T) ∩ M_1, deep inside the silent cone
rad = 0.05
M2 = 400_000
u = rng.standard_normal((M2, 3))
u = u / np.linalg.norm(u, axis=1, keepdims=True) * rad * rng.random(M2)[:, None] ** (1 / 3)
pts = ctr + u
vol = 4 / 3 * np.pi * rad ** 3
dens = np.exp(-0.5 * (pts ** 2).sum(1)) / (2 * np.pi) ** 1.5
assert (T(pts, EPS) == 0).all(), "ball not in Sil(T)"
assert (DK(verts, pts) == 0).all(), "ball meets H"
flG = field(pts, EPS)
V1 = np.where(pts[:, 0] > 0, 1, -1)
fillvals = ((pen(V1, pts, flG) - pen(np.zeros(M2, int), pts, flG)) * (dens * vol)[:, None]).mean(0)
print("(c) fill X = T[G -> V_1], G = ball(", ctr, ",", rad, "): Phi^T(T->X) =", np.round(fillvals, 7))
# H-part of rec(C, X) under l^C: C -> T on H, i.e. sigma -> silent
hpart = np.zeros(3)
pc, pt = pen(cg, g, fl), pen(tg, g, fl)
for w in range(3):
    sc = b_disc if w == v else a_amp
    hpart[w] = sc * ((pt[:, w] - pc[:, w]) * H).mean()
tot = hpart + fillvals
print("    H-part under l^C =", np.round(hpart, 6), " total Phi^C(C->X) =", np.round(tot, 6),
      " dominated at every world:", bool((tot > 0).all()))
print("NUMERICS DONE")
