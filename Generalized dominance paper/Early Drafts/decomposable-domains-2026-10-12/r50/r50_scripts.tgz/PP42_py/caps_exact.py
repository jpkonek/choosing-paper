"""PP42 script 2 (CHECKED, exact rationals). Lemma 4.1 (vertex caps).

K^v_delta := M ∩ {m_v <= c + eps - delta}, M = c*1 + eps*Delta, C := D_K.
Checks on rational problems g (random, and concentrated near planes through the vertex m_v):
 (i)  C(g) != T(g)  =>  T(g) is silent and C's answer sigma is v-wrong (sigma*g_v < 0);
 (ii) the disagreement set meets all three answer families associated with m_v:
      A on M_v, and B on M_j for both j != v  (so world v is one-signed, the others mixed);
 (iii) K is invariant under swapping the two non-v coordinates.
Run: python3 -I -B caps_exact.py > caps_exact.out
"""
from fractions import Fraction as Fr
import random

random.seed(7)
OK = True


def check(cond, msg):
    global OK
    if not cond:
        OK = False
        print("FAIL:", msg)


def verts_M(c, eps):
    return [[c + (eps if i == j else 0) for j in range(3)] for i in range(3)]


def verts_K(c, eps, v, delta):
    M = verts_M(c, eps)
    mv = M[v]
    others = [M[i] for i in range(3) if i != v]
    ps = [[mv[t] + (delta / eps) * (o[t] - mv[t]) for t in range(3)] for o in others]
    return others + ps


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def D(verts, g):
    vals = [dot(m, g) for m in verts]
    if min(vals) > 0:
        return 1
    if max(vals) < 0:
        return -1
    return 0


def cls(g):
    pos = sum(1 for x in g if x > 0)
    if pos == 1:
        return [i for i in range(3) if g[i] > 0][0]
    if pos == 2:
        return [i for i in range(3) if g[i] < 0][0]
    return -1


def rr(n=40):
    return Fr(random.randint(-n, n), random.randint(1, n))


total_hits = 0
for eps in (Fr(1, 10), Fr(3, 10)):
    c = (1 - eps) / 3
    M = verts_M(c, eps)
    for v in range(3):
        for delta in (eps / 10, eps / 40):
            K = verts_K(c, eps, v, delta)
            # (iii) symmetry
            a, b = [i for i in range(3) if i != v]
            Ksw = [[m[{a: b, b: a}.get(t, t)] for t in range(3)] for m in K]
            check(sorted(map(tuple, Ksw)) == sorted(map(tuple, K)), "symmetry")
            fam = set()
            hits = 0
            for trial in range(6000):
                if trial % 2 == 0:
                    g = [rr(), rr(), rr()]
                else:  # near a plane through m_v: g with m_v.g small
                    h = [rr(), rr(), rr()]
                    mv = M[v]
                    lam = dot(mv, h) / dot(mv, mv)
                    g = [h[t] - lam * mv[t] + Fr(random.randint(-3, 3), 200) * mv[t] for t in range(3)]
                if any(x == 0 for x in g):
                    continue
                tg, cg = D(M, g), D(K, g)
                if cg != tg:
                    hits += 1
                    check(tg == 0, "T not silent on H")
                    check(cg * g[v] < 0, "answer not v-wrong")
                    k = cls(g)
                    ans = "B" if (cg * g[k] > 0) else "A"   # minority answer = sign of g_k
                    fam.add((k, ans))
            want = {(v, "A")} | {(j, "B") for j in range(3) if j != v}
            check(fam == want, f"families {fam} != {want}")
            print(f"eps={eps} v={v+1} delta={delta}: disagreements={hits}, families={sorted((k+1,a) for k,a in fam)}")
            total_hits += hits
print("total disagreement points checked:", total_hits)
print("ALL PASS" if OK else "SOME CHECK FAILED")
