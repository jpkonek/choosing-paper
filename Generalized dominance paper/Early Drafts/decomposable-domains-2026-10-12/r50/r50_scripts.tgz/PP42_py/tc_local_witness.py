"""PP42 script 1 (CHECKED, exact rationals). Algebra behind Theorems 3.1, 3.2 and Prop 3.4-3.5.

(a) Pointwise reduction lemma (Lemma 3.0): at one problem and one world, with gates whose
    old values lie among the regular advice values, a weakly monotone potential U dominating
    c_N * (gate increments out of N's value) exists  <=>  no positive 2- or 3-cycle among gate
    edges between old values.  Tested against Bellman-Ford on the full 4-value graph.
(b) Two-gate P1 test (Thm 3.1, CG2): on finitely many atoms, a mixture D with
    sum_D f1 > 0 and sum_D f2 < 0 exists  <=>  the sandwich fails.  Exact search over
    two-atom mixtures (enough, by the planar argument in the note) vs the sandwich test.
(c) A 4-cycle of difference constraints that is consistent on every triple but not globally
    (Prop 3.5): triangle-local witnesses without a global witness.
(d) REFEREE_round49 sec 4.4 numbers: the F2 pair violates the sign-transfer consequence of CG2.
Run: python3 -I -B tc_local_witness.py > tc_local_witness.out
"""
from fractions import Fraction as Fr
import itertools, random

random.seed(42)
OK = True


def check(cond, msg):
    global OK
    if not cond:
        OK = False
        print("FAIL:", msg)


# ---------- (a) pointwise reduction lemma ----------
VALUES = ["A", "S", "B", "X"]  # X = contradiction (never an old value)


def rand_ranks():
    # at one world on a mixed problem: one of A,B correct (0), S = 1, other wrong (2), X = 3
    if random.random() < 0.5:
        return {"A": 0, "S": 1, "B": 2, "X": 3}
    return {"B": 0, "S": 1, "A": 2, "X": 3}


def rand_field(r):
    # strictly increasing in rank, positive rationals
    steps = [Fr(random.randint(1, 9), random.randint(1, 9)) for _ in range(3)]
    lev = [Fr(0), steps[0], steps[0] + steps[1], steps[0] + steps[1] + steps[2]]
    return {a: lev[r[a]] for a in VALUES}


def potential_exists(edges):
    """edges: list (a,b,w) meaning U(b)-U(a) >= w. Feasible iff no positive cycle."""
    # longest-path Bellman-Ford: d(b) >= d(a)+w ; positive cycle -> infeasible
    d = {a: Fr(0) for a in VALUES}
    for _ in range(len(VALUES) + 1):
        changed = False
        for a, b, w in edges:
            if d[a] + w > d[b]:
                d[b] = d[a] + w
                changed = True
        if not changed:
            return True
    return False


def gate_cycles_ok(gates, c):
    """gates: list of (oldvalue, field). No positive simple 2/3-cycle among gate edges
    between old values (edge x->z from a gate with old value x, weight c*(l(z)-l(x)))."""
    olds = sorted(set(o for o, _ in gates))
    w = {}
    for (o, f), cc in zip(gates, c):
        for z in olds:
            if z != o:
                val = cc * (f[z] - f[o])
                w[(o, z)] = max(w.get((o, z), val), val)
    for x, z in itertools.permutations(olds, 2):
        if (x, z) in w and (z, x) in w and w[(x, z)] + w[(z, x)] > 0:
            return False
    for x, y, z in itertools.permutations(olds, 3):
        if all(e in w for e in [(x, y), (y, z), (z, x)]) and w[(x, y)] + w[(y, z)] + w[(z, x)] > 0:
            return False
    return True


na = 0
agree = 0
for trial in range(6000):
    r = rand_ranks()
    k = random.randint(1, 3)
    gates = [(random.choice(["A", "S", "B"]), rand_field(r)) for _ in range(k)]
    c = [Fr(random.randint(1, 6), random.randint(1, 6)) for _ in range(k)]
    edges = []
    for (o, f), cc in zip(gates, c):
        for b in VALUES:
            if b != o:
                edges.append((o, b, cc * (f[b] - f[o])))
    for a in VALUES:
        for b in VALUES:
            if a != b and r[b] >= r[a]:
                edges.append((a, b, Fr(0)))  # monotone (weakly guiding) constraints
    lhs = potential_exists(edges)
    rhs = gate_cycles_ok(gates, c)
    na += 1
    agree += (lhs == rhs)
    check(lhs == rhs, f"(a) mismatch trial {trial}")
print(f"(a) reduction lemma: {agree}/{na} random instances agree (potential exists <=> no positive gate 2/3-cycle)")


# ---------- (b) two-gate sandwich vs P1 mixtures ----------
def sandwich_ok(f1, f2):
    P = [b / a for a, b in zip(f1, f2) if a > 0]
    Q = [b / a for a, b in zip(f1, f2) if a < 0]
    if not P or not Q:
        return True
    return max(Q) <= min(P)


def p1_violation(f1, f2):
    # mixture weights x_i in [0,1]; with sign agreement, a violating mixture exists iff some
    # pair (p in P, q in Q) admits x,y>0 with x f1p + y f1q > 0 and x f2p + y f2q < 0.
    n = len(f1)
    for i in range(n):
        for j in range(n):
            a1, b1, a2, b2 = f1[i], f2[i], f1[j], f2[j]
            if a1 > 0 and a2 < 0:
                # need x a1 + y a2 > 0 and x b1 + y b2 < 0, x,y>0  <=>  -a2/a1 < x/y < -b2/b1
                if (-a2) / a1 < (-b2) / b1:
                    return True
    return False


nb = 0
for trial in range(4000):
    n = random.randint(2, 6)
    f1, f2 = [], []
    for _ in range(n):
        s = random.choice([1, -1])
        f1.append(s * Fr(random.randint(1, 9), random.randint(1, 9)))
        f2.append(s * Fr(random.randint(1, 9), random.randint(1, 9)))
    check(sandwich_ok(f1, f2) == (not p1_violation(f1, f2)), f"(b) mismatch {trial}")
    nb += 1
print(f"(b) two-gate test: sandwich <=> no P1 mixture on {nb}/{nb} random atom sets")


# ---------- (c) 4-cycle: triangle-consistent, globally inconsistent ----------
# x_i = log c_i ; pair constraint x_j - x_i in [lo, hi]. Cycle pairs tight with sum != 0.
import math
L = {(0, 1): (1, 1), (1, 2): (1, 1), (2, 3): (1, 1), (3, 0): (1, 1),  # tight: x_j - x_i = 1
     (0, 2): (-10, 10), (1, 3): (-10, 10)}                                  # wide diagonals


def feasible(nodes):
    cons = []
    for (i, j), (lo, hi) in L.items():
        if i in nodes and j in nodes:
            cons.append((i, j, hi))   # x_j - x_i <= hi
            cons.append((j, i, -lo))  # x_i - x_j <= -lo
    d = {v: 0 for v in nodes}
    for _ in range(len(nodes) + 1):
        ch = False
        for i, j, w in cons:
            if d[i] + w < d[j]:
                d[j] = d[i] + w
                ch = True
        if not ch:
            return True
    return False


tri = [feasible(set(t)) for t in itertools.combinations(range(4), 3)]
glob = feasible({0, 1, 2, 3})
check(all(tri) and not glob, "(c) 4-cycle")
print(f"(c) 4-cycle: every triple feasible = {all(tri)}, global system feasible = {glob}")

# ---------- (d) REFEREE_round49 sec 4.4 F2 pair ----------
Phi = [Fr(53, 1000), Fr(-183, 1000), Fr(507, 1000)]   # Phi(T->B), NUMERICS there
PiT = [1, 1, 2]       # Pi^T(T->B)
PiB = [1, 2, 1]       # Pi^B(B->T)
K = Fr(296, 100)
VT = [Phi[w] + K * PiT[w] for w in range(3)]          # V^T(T->X) on the far splice
VB_back = [-Phi[w] + K * PiB[w] for w in range(3)]    # V^B(X->T)
# CG2 sign transfer (Lemma 3.3): V^B(T->X) = -VB_back must be >= kappa_w * V^T(T->X) > 0.
viol = all(VT[w] > 0 for w in range(3)) and all(-VB_back[w] < 0 for w in range(3))
check(viol, "(d)")
print("(d) referee F2 pair: V^T(T->X) =", [float(x) for x in VT], " V^B(T->X) =",
      [float(-x) for x in VB_back], "-> opposite strict signs at every world, so CG2 fails:", viol)

print("ALL PASS" if OK else "SOME CHECK FAILED")
