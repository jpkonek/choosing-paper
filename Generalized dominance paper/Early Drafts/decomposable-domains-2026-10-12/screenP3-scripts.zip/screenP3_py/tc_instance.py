"""SCREEN_P3: exact cell-model instance of a (TC) failure for a pair-indexed rule that uses
two different strictly guiding additive scores on chained records (anchoring mechanism, §3).

Cell model: each cell is a thin angular sector of mixed problems g=(a,-b), a+b=1, tau=b,
represented by its representative tau and a rational mass (integrals = mass x penalty at rep).
All inequalities used have slack, so they persist for genuine thin sectors.

Scores: FC_w (FC v3 table): + -> (0,b), 0 -> (c,c), - -> (a,0), x -> (2a,2b), c = ab/(1+w).
Rule R: on a record whose changed set meets the anchor cells V (sectors adjacent at tau=1/4)
use score A = FC_{1/4}; otherwise use score B = FC_{1/3}.  X <=_i Y iff L_i(X) <= L_i(Y) under
the score attached to the (unordered) record.
Selected family: FC v3 width 1/3, K_p = [max(0,(4p-1)/3), min(1,4p/3)]; anchor model C = C_{3/16}
= D_[0,1/4].
Run: python3 -I tc_instance.py
"""
from fractions import Fraction as F

def pen(w, tau, adv, world):
    a, b = 1 - tau, tau
    c = a * b / (1 + w)
    t = {'+': (F(0), b), '0': (c, c), '-': (a, F(0)), 'x': (2 * a, 2 * b)}
    return t[adv][world]

def coh(l, u, tau):
    return '+' if tau < l else ('-' if tau > u else '0')

def K(p):
    return (max(F(0), (4 * p - 1) / 3), min(F(1), 4 * p / 3))

# cells: name -> (rep tau, mass)
eps = F(1, 1000)
cells = {
    'E1': (F(1, 10), F(1)),
    'E2': (F(9, 10), F(23, 10)),
    'Vm': (F(6, 25), eps),      # sector just below 1/4
    'Vp': (F(13, 50), eps),     # sector just above 1/4
    'W':  (F(1, 20), None),     # mass fixed below
}
p = F(3, 16)
l, u = K(p)
C = {k: coh(l, u, cells[k][0]) for k in cells}
X = dict(C); Z = dict(C)
X.update({'E1': '0', 'E2': '0', 'Vm': '-', 'Vp': '0', 'W': '-'})
Z.update({'E1': '+', 'E2': '-', 'Vm': '-', 'Vp': '0', 'W': '-'})
A, B = F(1, 4), F(1, 3)
anchor = {'Vm', 'Vp'}

def loss(model, w, world, cellset, mass):
    return sum(mass[k] * pen(w, cells[k][0], model[k], world) for k in cellset)

def rule_leq(M1, M2, world, mass):
    N = {k for k in cells if M1[k] != M2[k]}
    w = A if N & anchor else B
    return loss(M1, w, world, N, mass) <= loss(M2, w, world, N, mass), w, N

# choose W mass so that L^A(Z) <= L^A(C) <= L^A(X) at world 1 (midpoint of the admissible interval)
mass = {k: cells[k][1] for k in cells if cells[k][1] is not None}
mass['W'] = F(0)
DX = loss(X, A, 0, cells, mass) - loss(C, A, 0, cells, mass)
DZ = loss(Z, A, 0, cells, mass) - loss(C, A, 0, cells, mass)
per = pen(A, cells['W'][0], '-', 0) - pen(A, cells['W'][0], C['W'], 0)
target = -(DX + DZ) / 2                      # d in (-DX, -DZ)
mass['W'] = target / per
print('C = C_p, p =', p, 'K_p =', (l, u), 'advice', C)
print('X', X); print('Z', Z); print('W mass', mass['W'])
for (M1, n1), (M2, n2) in [((Z, 'Z'), (C, 'C')), ((C, 'C'), (X, 'X')), ((X, 'X'), (Z, 'Z')), ((Z, 'Z'), (X, 'X'))]:
    ok, w, N = rule_leq(M1, M2, 0, mass)
    print(f'world 1: {n1} <= {n2} ? {ok}   score FC_{w}  changed {sorted(N)}')
# record X vs Z on E1,E2 under both scores
for w in (A, B):
    d = loss(Z, w, 0, {'E1', 'E2'}, mass) - loss(X, w, 0, {'E1', 'E2'}, mass)
    print(f'L_1(Z)-L_1(X) on E under FC_{w}: {d} = {float(d):.6f}')
# competitiveness of C on the anchored records under A: C is FC_{1/4}-Bayes at weight t0=u/(1+w)=1/5
t0 = u / (1 + A)
for k in cells:
    tau = cells[k][0]
    best = min('+0-x', key=lambda s: t0 * pen(A, tau, s, 0) + (1 - t0) * pen(A, tau, s, 1))
    assert best == C[k], (k, best, C[k])
print('C pointwise FC_1/4-Bayes at weight', t0, 'on all cells: OK')
# decoding sets: which selected models agree with C on the anchor sectors [6/25,1/4) and (1/4,13/50]
print('(TC) violated: Z <= C <= X and X < Z at world 1')
