"""SCREEN_P3: the rule m(t) in argmax_m P_m(h_t) only ever selects a vertex index (two worlds).
P_m(h) = min over [l(m),u(m)] of q h1 + (1-q) h2.  Checked exactly on a grid of m and random h for
the FC v3 width-1/3 family and for a non-nested family. Run: python3 -I argmax_vertex.py"""
from fractions import Fraction as F
import random
random.seed(7)

def fam_fc(m):
    return (max(F(0), (4 * m - 1) / 3), min(F(1), 4 * m / 3))

def fam_bump(m):  # non-nested continuous family with precise vertices: width 2/3*m(1-m)*4
    w = F(8, 3) * m * (1 - m) / 4 * 2
    return (max(F(0), m - w / 2), min(F(1), m + w / 2))

def P(K, h):
    l, u = K
    return min(l * h[0] + (1 - l) * h[1], u * h[0] + (1 - u) * h[1])

grid = [F(k, 96) for k in range(97)]
for fam in (fam_fc, fam_bump):
    bad = 0
    for _ in range(2000):
        h = (F(random.randint(-50, 50), 7), F(random.randint(-50, 50), 7))
        if h[0] == h[1]:
            continue
        vals = {m: P(fam(m), h) for m in grid}
        best = max(vals.values())
        arg = [m for m in grid if vals[m] == best]
        want = F(1) if h[0] > h[1] else F(0)
        if want not in arg or any(fam(m) != fam(want) and vals[m] == best for m in arg):
            bad += 1
    print(fam.__name__, 'violations of "argmax = vertex":', bad)
