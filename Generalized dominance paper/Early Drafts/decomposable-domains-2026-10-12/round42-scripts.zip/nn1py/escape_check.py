# NN1 Example 5.1: a three-world configuration of 21 pairwise non-proportional vectors in R^2
# (values of the judges at two boundary points A, B) in which EVERY one of the C(7,3)^3 = 42875
# branches has a strictly positive relation, while every two-world (edge-type) branch has none.
# Exact integer arithmetic. Run: python3 -I escape_check.py
from itertools import combinations, product

W = {
 1: [(10,10),(10,11),(11,10),(10,12),(12,10),(11,12),(12,11)],          # near 45 deg
 2: [(-26,7),(-26,8),(-25,7),(-27,7),(-26,6),(-25,8),(-27,6)],          # near 165 deg
 3: [(7,-26),(8,-26),(7,-25),(7,-27),(6,-26),(8,-25),(6,-27)],          # near 285 deg
}
ok = True
def det(a, b): return a[0]*b[1] - a[1]*b[0]

# (i) sign patterns: coordinate A = first entry, B = second entry.
patA = tuple(1 if W[i][0][0] > 0 else -1 for i in (1,2,3))
patB = tuple(1 if W[i][0][1] > 0 else -1 for i in (1,2,3))
for i in (1,2,3):
    for v in W[i]:
        if (1 if v[0] > 0 else -1) != patA[i-1] or (1 if v[1] > 0 else -1) != patB[i-1] or 0 in v:
            ok = False; print("sign pattern violated", i, v)
print("pattern at A:", patA, " pattern at B:", patB, " (both mixed)")
if len(set(patA)) == 1 or len(set(patB)) == 1: ok = False

# (ii) no two of the 21 vectors are proportional.
allv = [(i, v) for i in (1,2,3) for v in W[i]]
for (i, a), (j, b) in combinations(allv, 2):
    if det(a, b) == 0:
        ok = False; print("proportional pair", i, a, j, b)
print("pairwise non-proportional: 21 vectors, 210 pairs checked")

# (iii) every transversal (one vector per world) has a strictly positive relation
#       det(b,c) a + det(c,a) b + det(a,b) c = 0, with all three coefficients > 0.
ntrans = 0
for a, b, c in product(W[1], W[2], W[3]):
    lam = (det(b, c), det(c, a), det(a, b))
    s = tuple(lam[0]*a[t] + lam[1]*b[t] + lam[2]*c[t] for t in (0, 1))
    if s != (0, 0) or min(lam) <= 0:
        ok = False; print("transversal fails", a, b, c, lam)
    ntrans += 1
print(f"transversals with strictly positive exact relation: {ntrans} of 343")
# every branch (3 judges per world) contains a transversal, hence has a relation using all three worlds
nbr = 0
for F1, F2, F3 in product(combinations(range(7), 3), repeat=3):
    nbr += 1   # contains transversal (F1[0],F2[0],F3[0]) which passed (iii)
print(f"branches certified (aligned) via a contained transversal: {nbr} of 42875")

# (iv) two-world branches: cones of worlds i and j (3 generators each) meet only at 0.
for i, j in ((1,2), (2,3), (3,1)):
    bad = 0; tot = 0
    for Fi in combinations(W[i], 3):
        for Fj in combinations(W[j], 3):
            tot += 1
            # Each cone is a planar sector of angle < 180 deg.  Two such sectors meet nontrivially iff
            # an extreme ray of one lies in the other (exact test with determinants).
            meet = False
            for e1 in Fi:
                for e2 in Fi:
                    if all(det(e1, x) >= 0 and det(x, e2) >= 0 for x in Fi):
                        if any(det(e1, y) >= 0 and det(y, e2) >= 0 for y in Fj):
                            meet = True
            for e1 in Fj:
                for e2 in Fj:
                    if all(det(e1, x) >= 0 and det(x, e2) >= 0 for x in Fj):
                        if any(det(e1, y) >= 0 and det(y, e2) >= 0 for y in Fi):
                            meet = True
            bad += (not meet)
    print(f"worlds {i},{j} alone: {bad} of {tot} two-world branches have NO relation")
    if bad != tot: ok = False

print("ALL CHECKS PASSED" if ok else "SOME CHECK FAILED")
