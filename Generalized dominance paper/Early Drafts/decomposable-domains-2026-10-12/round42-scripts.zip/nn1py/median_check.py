# NN1: checks for the two-colour median-coincidence lemma (NN1 Lemma 2.1).
# Exact (integers / Fractions). Run: python3 -I median_check.py
from itertools import combinations, combinations_with_replacement, product
from fractions import Fraction as Fr
import random

ok = True

# ---------- Part 1: exhaustive one-dimensional check ----------
# Two colours of n points on a line (values in 0..G-1, as multisets).  Blocking size k.
# "All branches meet": every k-subset interval of colour a meets every k-subset interval of colour b.
# Lemma (1D form): all branches meet  =>  sorted positions k..n-k+1 of a and of b all carry one common value.
# Exact characterisation in 1D (also proved in the note): all meet <=> a_(n-k+1) <= b_(k) and b_(n-k+1) <= a_(k).
def all_meet(a, b, k):
    n = len(a)
    for A in combinations(range(n), k):
        lo1 = min(a[i] for i in A); hi1 = max(a[i] for i in A)
        for B in combinations(range(n), k):
            lo2 = min(b[i] for i in B); hi2 = max(b[i] for i in B)
            if hi1 < lo2 or hi2 < lo1:
                return False
    return True

def middle_common(a, b, k):
    n = len(a)
    vals = set(a[k-1:n-k+1]) | set(b[k-1:n-k+1])
    return len(vals) == 1

for (n, k, G) in [(4, 2, 5), (5, 2, 4), (5, 3, 4), (7, 3, 4)]:
    ms = list(combinations_with_replacement(range(G), n))
    cnt = 0; good = 0
    for a in ms:
        for b in ms:
            m = all_meet(a, b, k)
            crit = (a[n-k] <= b[k-1]) and (b[n-k] <= a[k-1])
            if m != crit:
                ok = False; print("1D criterion mismatch", n, k, a, b)
            if m and not middle_common(a, b, k):
                ok = False; print("1D lemma FAILS", n, k, a, b)
            cnt += 1; good += m
    print(f"1D exhaustive n={n} k={k} values<{G}: {cnt} pairs, {good} with all branches meeting; "
          f"each such pair has a common value at sorted positions {k}..{n-k+1} (multiplicity {n-2*k+2})")

# ---------- Part 2: random exact checks in R^3 (cones) = triangles in the plane chart ----------
# Generators are positive vectors; normalise to the chart x+y+z=1 and use (x,y).
def norm(v):
    s = sum(v); return (Fr(v[0], 1)/s, Fr(v[1], 1)/s)

def cross(o, a, b):
    return (a[0]-o[0])*(b[1]-o[1]) - (a[1]-o[1])*(b[0]-o[0])

def hull_axes(P):
    # candidate separating directions: normals of all segments between points of P
    axes = []
    for p, q in combinations(P, 2):
        if p != q:
            axes.append((q[1]-p[1], p[0]-q[0]))
    return axes

def polys_meet(P, Q):
    # P, Q finite point sets (conv hulls, possibly degenerate). Separating-axis test, exact.
    axes = hull_axes(P) + hull_axes(Q)
    # degenerate cases: add axes along segment directions too
    for p, q in list(combinations(P, 2)) + list(combinations(Q, 2)):
        if p != q:
            axes.append((q[0]-p[0], q[1]-p[1]))
    axes += [(1, 0), (0, 1)]
    for ax in axes:
        pv = [ax[0]*x + ax[1]*y for (x, y) in P]
        qv = [ax[0]*x + ax[1]*y for (x, y) in Q]
        if max(pv) < min(qv) or max(qv) < min(pv):
            return False
    # also test with axes orthogonal to differences between P and Q points (covers point-segment cases)
    for p in P:
        for q in Q:
            if p != q:
                ax = (q[1]-p[1], p[0]-q[0])
                pv = [ax[0]*x + ax[1]*y for (x, y) in P]
                qv = [ax[0]*x + ax[1]*y for (x, y) in Q]
                if max(pv) < min(qv) or max(qv) < min(pv):
                    return False
    return True

def all_branches_meet_2col(A, B, k):
    for S in combinations(range(len(A)), k):
        PS = [A[i] for i in S]
        for T in combinations(range(len(B)), k):
            if not polys_meet(PS, [B[j] for j in T]):
                return False
    return True

def has_common_triple(A, B, m):
    for z in set(A):
        if A.count(z) >= m and B.count(z) >= m:
            return True
    return False

random.seed(20261019)
def rvec(): return tuple(random.randint(1, 9) for _ in range(3))
n, k = 7, 3
stats = {"generic": [0, 0], "tripled_distinct_rays": [0, 0], "tripled_common_ray": [0, 0]}
for trial in range(25):
    # generic
    A = [norm(rvec()) for _ in range(n)]; B = [norm(rvec()) for _ in range(n)]
    m = all_branches_meet_2col(A, B, k)
    stats["generic"][0] += 1; stats["generic"][1] += m
    if m and not has_common_triple(A, B, 3):
        ok = False; print("2D lemma FAILS (generic)", A, B)
    # tripled at distinct rays
    z1, z2 = norm(rvec()), norm(rvec())
    if z1 != z2:
        A = [z1]*3 + [norm(rvec()) for _ in range(4)]
        B = [z2]*3 + [norm(rvec()) for _ in range(4)]
        m = all_branches_meet_2col(A, B, k)
        stats["tripled_distinct_rays"][0] += 1; stats["tripled_distinct_rays"][1] += m
        if m:
            ok = False; print("2D lemma FAILS (distinct rays)", A, B)
    # tripled common ray, other points placed as two opposite pairs through z (sufficient pattern)
    z = (Fr(1, 3), Fr(1, 3))
    d1 = (Fr(random.randint(1, 5), 60), Fr(random.randint(-5, 5), 60))
    d2 = (Fr(random.randint(-5, 5), 60), Fr(random.randint(1, 5), 60))
    def add(p, d, s): return (p[0]+s*d[0], p[1]+s*d[1])
    four = [add(z, d1, 1), add(z, d1, -1), add(z, d2, 1), add(z, d2, -1)]
    A = [z]*3 + four
    d3 = (Fr(random.randint(1, 5), 70), Fr(random.randint(-5, 5), 70))
    d4 = (Fr(random.randint(-5, 5), 70), Fr(random.randint(1, 5), 70))
    B = [z]*3 + [add(z, d3, 1), add(z, d3, -1), add(z, d4, 1), add(z, d4, -1)]
    m = all_branches_meet_2col(A, B, k)
    stats["tripled_common_ray"][0] += 1; stats["tripled_common_ray"][1] += m
    if not m:
        ok = False; print("expected pass failed (common ray, crosses)", A, B)
for key, (tot, mt) in stats.items():
    print(f"2D exact random, n=7 k=3, {key}: {tot} instances, all 1225 branch pairs meet in {mt}")

print("ALL CHECKS PASSED" if ok else "SOME CHECK FAILED")
