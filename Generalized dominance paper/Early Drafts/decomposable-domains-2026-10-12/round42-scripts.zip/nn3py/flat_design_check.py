"""NN3 Part B: exact checks for the smooth flat test design S = M x (MM1 Part A design).

Design.  Min-cells M_k = {g_k strictly minimal}.  Judge (i,v) has switch value
    sigma_iv(g) = M(g) * kappa_iv[k] * g_i   on M_k,
with M(g) = H(g1-g2) H(g2-g3) H(g3-g1), H(t) = exp(-1/t^2) (t != 0), H(0) = 0.
M is C-infinity, even, positive off the walls, flat on the walls.  kappa: MM1 Part A,
    kappa*_i = (c0 + eps*delta_ik)_k, kappa*_i +- delta*tau_i (delta = c0/2,
    tau_i = e_{i+1} - e_{i+2}), 2 kappa*_i.
M is a common positive factor, so every sign question below is about kappa only.

Part 1. For each of the 216 branches, an exact alpha >= 0 with sum_{v in F_i} alpha_iv kappa_iv = kappa*_i
        at every world i.  Then sum alpha sigma = M * P_T1 on every cell (P_T1 = v_k.g on M_k), so T1 is
        strictly certified in every branch (MM1 Lemma 1.1(b)).
Part 2. MM2 Thm 6.4 edge identities for the branch (doubled pair, doubled pair) on the planes Pi_s crossing
        the wall {g_j = g_k} near each corner ray, both switch types c and d: the cross-world ratio must be
        equal on the two cells; it is not (exact).
Part 3. Symbolic: any min-cell design for which T1 is weak Bayes in all 216 branches has doubled rays
        z_i(k) = (v_k)_i d_k / lambda_i (MM1 Thm 4.1(b)).  Type-c identities fail identically (factor eps);
        type-d identities force d_p > d_j and d_p > d_k at the corner with positive coordinate p, which is
        contradictory across two corners.
All arithmetic exact (Fractions / sympy rationals).
"""
from fractions import Fraction as Fr
from itertools import combinations, product
import sympy as sp

FAIL = []
def check(cond, msg):
    if not cond:
        FAIL.append(msg)
    return cond

def judges(eps):
    c0 = (1 - eps) / 3
    dl = c0 / 2
    K = []
    for i in range(3):
        ks = [c0 + (eps if k == i else 0) for k in range(3)]
        tau = [0, 0, 0]; tau[(i + 1) % 3] = 1; tau[(i + 2) % 3] = -1
        K.append([ks,
                  [ks[k] + dl * tau[k] for k in range(3)],
                  [ks[k] - dl * tau[k] for k in range(3)],
                  [2 * ks[k] for k in range(3)]])
    return c0, K

def pair_alpha(target, a, b):
    """alpha >= 0, not both 0, with alpha_a a + alpha_b b = target (vectors in Q^3), or None."""
    # try a alone, b alone, then 2x2 solve
    for (x, y) in ((a, None), (b, None)):
        r = None
        ok = True
        for k in range(3):
            if x[k] == 0:
                if target[k] != 0: ok = False
            else:
                q = target[k] / x[k]
                if r is None: r = q
                elif q != r: ok = False
        if ok and r is not None and r > 0:
            return (r, 0) if x is a else (0, r)
    for (p, q) in ((0, 1), (0, 2), (1, 2)):
        D = a[p] * b[q] - a[q] * b[p]
        if D != 0:
            s = (target[p] * b[q] - target[q] * b[p]) / D
            u = (a[p] * target[q] - a[q] * target[p]) / D
            if all(s * a[k] + u * b[k] == target[k] for k in range(3)) and s >= 0 and u >= 0:
                return (s, u)
            return None
    return None

print("Part 1: all 216 branches give exactly M*P_T1 (strict certificate of T1)")
for eps in (Fr(1, 10), Fr(3, 10), Fr(1, 2)):
    c0, K = judges(eps)
    vk = [[c0 + (eps if i == k else 0) for i in range(3)] for k in range(3)]
    # P_T1 = v_k.g on M_k means the cell-k normal is v_k, i.e. omega^k_i = (v_k)_i = kappa*_i[k]
    for i in range(3):
        check(all(K[i][0][k] == vk[k][i] for k in range(3)), "kappa* != cell normals")
    nb = 0
    for F in product(list(combinations(range(4), 2)), repeat=3):
        ok = True
        for i in range(3):
            al = pair_alpha(K[i][0], K[i][F[i][0]], K[i][F[i][1]])
            ok = ok and al is not None
        nb += ok
    print(f"  eps={eps}: branches certified = {nb}/216")
    check(nb == 216, f"Part 1 eps={eps}")
    # a check that P_T1(g) = v_k.g on M_k at sample rational points
    import random
    random.seed(1)
    for _ in range(500):
        g = [Fr(random.randint(-50, 50), random.randint(1, 9)) for _ in range(3)]
        if len(set(g)) < 3: continue
        k = g.index(min(g))
        P = min(sum(vk[j][i] * g[i] for i in range(3)) for j in range(3))
        check(P == sum(vk[k][i] * g[i] for i in range(3)), "P_T1 cell form")

print("Part 2: edge identities, branch (doubled pair A,D ; doubled pair A,D), types c and d")
corners = {(0,): None}
for eps in (Fr(1, 10), Fr(3, 10), Fr(1, 2)):
    c0, K = judges(eps)
    for p in range(3):              # positive coordinate of the corner ray
        j, k = (p + 1) % 3, (p + 2) % 3   # the two negative coordinates, wall g_j = g_k
        for other in (j, k):        # edge {p, other}; the plane contains the third direction and crosses the wall
            kp, ko = K[p][0], K[other][0]   # judge A at each world (D = 2A is proportional)
            # type c on cell l: |sigma_p| / |sigma_other| = (g_p/|g_other|) * kappa_p[l]/kappa_other[l]
            rc = [kp[l] / ko[l] for l in (j, k)]
            # type d: -g lies in cell M_p, d = M g_i (kappa[l] + kappa[p])
            rd = [(kp[l] + kp[p]) / (ko[l] + ko[p]) for l in (j, k)]
            fc = rc[0] != rc[1]; fd = rd[0] != rd[1]
            print(f"  eps={eps} corner +{p+1} edge {{{p+1},{other+1}}}: type c ratios {rc[0]} vs {rc[1]} -> "
                  f"{'FAIL' if fc else 'pass'}; type d ratios {rd[0]} vs {rd[1]} -> {'FAIL' if fd else 'pass'}")
            check(fc and fd, f"Part 2 eps={eps} p={p} other={other}")

print("Part 3: symbolic, all min-cell designs with T1 weak Bayes in all branches")
e = sp.symbols('epsilon', positive=True)
d = sp.symbols('d1:4', positive=True)
lam = sp.symbols('l1:4', positive=True)
c0 = (1 - e) / 3
v = [[c0 + (e if i == k else 0) for i in range(3)] for k in range(3)]
z = [[v[kk][i] * d[kk] / lam[i] for kk in range(3)] for i in range(3)]   # z[i][cell]
conds_d = {}
for p in range(3):
    j, k = (p + 1) % 3, (p + 2) % 3
    for other in (j, k):
        rc = [sp.simplify(z[p][l] / z[other][l]) for l in (j, k)]
        diffc = sp.factor(sp.simplify(rc[0] - rc[1]))
        num_c = sp.factor(sp.numer(sp.together(diffc)))
        rd = [(z[p][l] + z[p][p]) / (z[other][l] + z[other][p]) for l in (j, k)]
        num_d = sp.factor(sp.numer(sp.together(rd[0] - rd[1])))
        print(f"  corner +{p+1}, edge {{{p+1},{other+1}}}: type c numerator = {num_c}")
        print(f"      type d numerator = {num_d}")
        # type c: nonzero for every eps in (0,1) and positive d, lambda
        check(sp.simplify(num_c.subs(e, 0)) == 0 and num_c != 0, "type c")
        conds_d[(p, other)] = num_d
# type d: each numerator is (const*eps) * (linear-in-one-variable factor); solve for the sign requirement
print("  type-d conditions, solved:")
req = {}
for (p, other), num in conds_d.items():
    j, k = (p + 1) % 3, (p + 2) % 3
    third = k if other == j else j
    # the identity requires num = 0; num is affine in d[third]
    sol = sp.solve(sp.Eq(num, 0), d[third])
    print(f"    corner +{p+1}, edge {{{p+1},{other+1}}}: d{third+1} = {[sp.factor(s) for s in sol]}")
    check(len(sol) == 1, "type d solve")
    s0 = sp.factor(sol[0])
    # positivity of d[third] requires d[p] > d[other]
    nu, de = sp.fraction(sp.together(s0))
    print(f"      numerator {sp.factor(nu)}, denominator {sp.factor(de)}")
    req[(p, other)] = (sp.factor(nu), sp.factor(de))
# Verify: denominator is a positive multiple of (d_p - d_other) or its negative, numerator is of fixed sign
ok_all = True
for (p, other), (nu, de) in req.items():
    # evaluate sign of numerator at a positive point (it is a monomial-type product, check it has no sign change)
    test_pts = [{e: sp.Rational(1, 10), d[0]: 1, d[1]: 2, d[2]: 3},
                {e: sp.Rational(1, 2), d[0]: 3, d[1]: 1, d[2]: 2},
                {e: sp.Rational(9, 10), d[0]: 2, d[1]: 3, d[2]: 1}]
    sn = {sp.sign(nu.subs(t)) for t in test_pts}
    # denominator, as polynomial: is it c*(d_p - d_other) with c of fixed sign?
    q = sp.cancel(de / (d[p] - d[other]))
    sq = {sp.sign(q.subs(t)) for t in test_pts}
    fixed = len(sn) == 1 and len(sq) == 1 and q.free_symbols <= {e}
    sgn = (list(sn)[0] * list(sq)[0]) if fixed else None
    print(f"    corner +{p+1}, edge {{{p+1},{other+1}}}: d_third = N/D with D = q*(d{p+1}-d{other+1}), "
          f"q = {sp.factor(q)}; sign(N/q) = {sgn}  => requires d{p+1} {'>' if sgn == 1 else '<'} d{other+1}")
    ok_all = ok_all and fixed and sgn == 1
check(ok_all, "type d requirement d_p > d_other at every (corner, edge)")
print("  => type d at corner +1 needs d1 > d2; at corner +2 needs d2 > d1: contradictory.")

print()
print("ALL CHECKS PASSED" if not FAIL else "FAILURES: " + "; ".join(FAIL))
