# NN2: exact checks for the blocking-cone collapse theorem (NN2 Theorem 2.3).
# Run: python3 -I collapse_check.py   (from inside nn2py/)
# Exact arithmetic only (fractions.Fraction, integers).
from fractions import Fraction as Fr
from itertools import combinations, combinations_with_replacement, product
import random

N, B = 7, 3          # judges per world, blocking-set size n-q+1 (q = 5)
fails = []

def ok(cond, msg):
    if not cond:
        fails.append(msg)
        print("FAIL:", msg)

# ---------- Part 1: exhaustive one-dimensional check ----------
# Points on a line; the cone of a triple is the interval [min, max].
def triple_intervals(xs):
    return [(min(t), max(t)) for t in combinations(xs, B)]

def middle_equal(xs):
    s = sorted(xs)
    return s[B-1] == s[N-B]          # x(3) = x(5)  (1-based)

vals2 = list(combinations_with_replacement(range(4), N))   # 120 multisets
cnt = 0; npass = 0
for X in vals2:
    IX = triple_intervals(X)
    for Y in vals2:
        IY = triple_intervals(Y)
        allmeet = all(max(a[0], b[0]) <= min(a[1], b[1]) for a in IX for b in IY)
        pred = middle_equal(X) and middle_equal(Y) and sorted(X)[3] == sorted(Y)[3]
        ok(allmeet == pred, "1D two worlds %s %s" % (X, Y))
        cnt += 1; npass += allmeet
print("Part 1a: two worlds, values in {0..3}: %d configurations, %d pass; pass <=> common middle triple" % (cnt, npass))

vals3 = list(combinations_with_replacement(range(3), N))   # 36 multisets
cnt = 0; npass = 0
IV = {X: triple_intervals(X) for X in vals3}
for X, Y, Z in product(vals3, repeat=3):
    allmeet = True
    for a in set(IV[X]):
        for b in set(IV[Y]):
            lo = max(a[0], b[0]); hi = min(a[1], b[1])
            if lo > hi:
                allmeet = False; break
            for c in set(IV[Z]):
                if max(lo, c[0]) > min(hi, c[1]):
                    allmeet = False; break
            if not allmeet: break
        if not allmeet: break
    pred = all(middle_equal(W) for W in (X, Y, Z)) and len({sorted(W)[3] for W in (X, Y, Z)}) == 1
    ok(allmeet == pred, "1D three worlds")
    cnt += 1; npass += allmeet
print("Part 1b: three worlds, values in {0,1,2}: %d configurations, %d pass; pass <=> common middle triple" % (cnt, npass))

# ---------- helpers for exact cone membership ----------
def solve_exact(cols, rhs):
    """Solve sum_j lam_j cols[j] = rhs exactly; cols linearly independent.
    Returns lam or None if inconsistent."""
    m = len(rhs); k = len(cols)
    M = [[Fr(cols[j][i]) for j in range(k)] + [Fr(rhs[i])] for i in range(m)]
    r = 0; piv = []
    for c in range(k):
        p = next((i for i in range(r, m) if M[i][c] != 0), None)
        if p is None:
            return None            # dependent columns: skip (Caratheodory uses independent subsets)
        M[r], M[p] = M[p], M[r]
        inv = 1 / M[r][c]
        M[r] = [x * inv for x in M[r]]
        for i in range(m):
            if i != r and M[i][c] != 0:
                f = M[i][c]
                M[i] = [a - f * b for a, b in zip(M[i], M[r])]
        piv.append(c); r += 1
    for i in range(r, m):
        if M[i][k] != 0:
            return None
    return [M[i][k] for i in range(k)]

def in_cone(z, gens):
    """Exact test z in cone(gens), by Caratheodory over independent subsets."""
    for size in range(1, len(gens) + 1):
        for S in combinations(gens, size):
            lam = solve_exact(list(S), z)
            if lam is not None and all(l >= 0 for l in lam):
                return True
    return False

def dot(a, b):
    return sum(x * y for x, y in zip(a, b))

def proj_cert(worlds, phi, rng, tries=200):
    """Exact certificate that some colourful choice has trivial intersection:
    a linear f and triples T_i, T_j (i != j) whose f-images of the normalised
    points are disjoint intervals."""
    m = len(worlds[0][0])
    for _ in range(tries):
        f = [Fr(rng.randint(-50, 50), rng.randint(1, 20)) for _ in range(m)]
        img = [[dot(f, a) / dot(phi, a) for a in W] for W in worlds]
        for i, j in combinations(range(len(worlds)), 2):
            for Ti in combinations(range(N), B):
                vi = [img[i][v] for v in Ti]
                for Tj in combinations(range(N), B):
                    vj = [img[j][v] for v in Tj]
                    if max(vi) < min(vj) or max(vj) < min(vi):
                        return (f, i, Ti, j, Tj)
    return None

def three_proportional(W):
    for a, b, c in combinations(W, 3):
        def prop(x, y):
            return all(x[s] * y[t] == x[t] * y[s] for s in range(len(x)) for t in range(len(x)))
        if prop(a, b) and prop(a, c):
            return True
    return False

rng = random.Random(20261018)

def rvec(m, lo=1, hi=9):
    return [Fr(rng.randint(lo, hi)) for _ in range(m)]

# ---------- Part 2: random exact instances in R^4 and R^5 ----------
for m in (4, 5):
    phi = [Fr(1)] * m
    # (a) generic: must fail, with an exact projection certificate
    nfail = 0
    for _ in range(15):
        worlds = [[rvec(m) for _ in range(N)] for _ in range(3)]
        cert = proj_cert(worlds, phi, rng)
        ok(cert is not None, "generic instance without certificate, m=%d" % m)
        nfail += cert is not None
    print("Part 2a (m=%d): 15 generic configurations, %d exact failure certificates" % (m, nfail))
    # (b) one world collapsed, others generic: must fail
    nfail = 0
    for _ in range(10):
        z = rvec(m, 5, 9)
        u = [Fr(rng.randint(-2, 2)) for _ in range(m)]
        w = [Fr(rng.randint(-2, 2)) for _ in range(m)]
        W1 = [[3 * x for x in z], [2 * x for x in z], z,
              [a + b for a, b in zip(z, u)], [a - b for a, b in zip(z, u)],
              [a + b for a, b in zip(z, w)], [a - b for a, b in zip(z, w)]]
        worlds = [W1] + [[rvec(m) for _ in range(N)] for _ in range(2)]
        cert = proj_cert(worlds, phi, rng)
        ok(cert is not None, "one-collapsed instance without certificate")
        nfail += cert is not None
    print("Part 2b (m=%d): 10 one-world-collapsed configurations, %d exact failure certificates" % (m, nfail))
    # (c) every world collapsed on its OWN ray: must fail
    nfail = 0
    for _ in range(10):
        worlds = []
        for i in range(3):
            z = rvec(m, 5, 9)
            u = [Fr(rng.randint(-2, 2)) for _ in range(m)]
            w = [Fr(rng.randint(-2, 2)) for _ in range(m)]
            worlds.append([[3 * x for x in z], [2 * x for x in z], z,
                           [a + b for a, b in zip(z, u)], [a - b for a, b in zip(z, u)],
                           [a + b for a, b in zip(z, w)], [a - b for a, b in zip(z, w)]])
        cert = proj_cert(worlds, phi, rng)
        ok(cert is not None, "distinct-ray instance without certificate")
        nfail += cert is not None
    print("Part 2c (m=%d): 10 configurations collapsed on distinct rays, %d exact failure certificates" % (m, nfail))
    # (d) collapsed on a COMMON ray: every b-cone of every world contains z
    npass = 0
    for _ in range(5):
        z = rvec(m, 5, 9)
        worlds = []
        for i in range(3):
            u = [Fr(rng.randint(-2, 2)) for _ in range(m)]
            w = [Fr(rng.randint(-2, 2)) for _ in range(m)]
            sc = [Fr(rng.randint(1, 5)) for _ in range(7)]
            base = [z, z, z, [a + b for a, b in zip(z, u)], [a - b for a, b in zip(z, u)],
                    [a + b for a, b in zip(z, w)], [a - b for a, b in zip(z, w)]]
            worlds.append([[s * x for x in v] for s, v in zip(sc, base)])
        good = all(in_cone(z, [W[v] for v in T]) for W in worlds for T in combinations(range(N), B))
        ok(good, "common-ray instance: some triple cone misses z")
        npass += good
    print("Part 2d (m=%d): 5 configurations collapsed on a common ray: %d have z in all 3x35 triple cones" % (m, npass))
    # (e) perturb ONE vector of a common-ray configuration so that world 1 keeps only
    #     two vectors on the ray: must fail (Theorem 2.3 needs >= 3 at every world)
    nfail = 0
    for _ in range(10):
        z = rvec(m, 5, 9)
        worlds = []
        for i in range(3):
            u = [Fr(rng.randint(-2, 2)) for _ in range(m)]
            w = [Fr(rng.randint(-2, 2)) for _ in range(m)]
            worlds.append([z, [2 * x for x in z], [3 * x for x in z],
                           [a + b for a, b in zip(z, u)], [a - b for a, b in zip(z, u)],
                           [a + b for a, b in zip(z, w)], [a - b for a, b in zip(z, w)]])
        e = [Fr(0)] * m; e[rng.randrange(m)] = Fr(1, 7)
        worlds[0][2] = [a + b for a, b in zip(worlds[0][2], e)]
        ok(not three_proportional(worlds[0]), "perturbation left three proportional vectors")
        cert = proj_cert(worlds, phi, rng)
        ok(cert is not None, "perturbed instance without certificate")
        nfail += cert is not None
    print("Part 2e (m=%d): 10 one-vector perturbations of common-ray configurations, %d exact failure certificates" % (m, nfail))

# ---------- Part 3: the depth count (Lemma 2.1) ----------
# If z lies in all 35 triple cones of one world, at least n-2b+2 = 3 vectors are proportional to z.
# Exhaustive over sign patterns: with a generic phi in z-perp, the non-z vectors have signs;
# a triple of non-z vectors with one common sign cannot contain z.
for k in range(0, N + 1):          # k = number of vectors on the ray z
    rest = N - k
    possible = any(all(not (len(T) == B and len(set(T)) == 1) for T in combinations(sg, B))
                   for sg in product((1, -1), repeat=rest))
    # possible = some sign assignment of the rest has no monochromatic triple
    ok(possible == (rest <= 2 * (B - 1)), "depth count k=%d" % k)
print("Part 3: a sign pattern on the non-z vectors with no monochromatic triple exists iff their number is <= 2b-2 = 4,"
      " i.e. iff at least n-2b+2 = 3 vectors lie on z")

print()
print("ALL CHECKS PASSED" if not fails else "%d FAILURES" % len(fails))
