# NN2 Section 6: an exact rank-two configuration in the three-world SUM form
# that satisfies all 42,875 branch conditions with no proportional judges.
# Run: python3 -I sumform_escape.py   (from inside nn2py/)
from fractions import Fraction as Fr
from itertools import combinations, product

N, B = 7, 3
fails = []
def ok(c, msg):
    if not c:
        fails.append(msg); print("FAIL:", msg)

def det(a, b):
    return a[0] * b[1] - a[1] * b[0]
def dot(a, b):
    return a[0] * b[0] + a[1] * b[1]

D = [(Fr(1), Fr(-2)), (Fr(2), Fr(1)), (Fr(-2), Fr(1))]          # base directions of worlds 1,2,3
def perp(d):
    return (-d[1], d[0])
COLS = [[(d[0] + Fr(k, 20) * perp(d)[0], d[1] + Fr(k, 20) * perp(d)[1]) for k in range(-3, 4)] for d in D]

print("Columns c_iv (boundary switch data: sigma_iv(g) = <c_iv, beta(g)> on the region N):")
for i in range(3):
    print("  world %d:" % (i + 1), ", ".join("(%s,%s)" % c for c in COLS[i]))

# (1) no two columns of one world are proportional
for i in range(3):
    for a, b in combinations(COLS[i], 2):
        ok(det(a, b) != 0, "proportional columns at world %d" % (i + 1))
print("(1) no two columns at any world are proportional: checked")

# (2) every choice of one column per world is positively dependent with all weights > 0
def posdep(a, b, c):
    w = (det(b, c), det(c, a), det(a, b))      # w_a a + w_b b + w_c c = 0
    if all(x > 0 for x in w):
        return w
    if all(x < 0 for x in w):
        return tuple(-x for x in w)
    return None
cnt = 0
for a, b, c in product(*COLS):
    w = posdep(a, b, c)
    ok(w is not None, "triple not positively dependent")
    if w is not None:
        s = (w[0] * a[0] + w[1] * b[0] + w[2] * c[0], w[0] * a[1] + w[1] * b[1] + w[2] * c[1])
        ok(s == (0, 0), "dependence check")
        cnt += 1
print("(2) all %d single-column triples (one per world) are positively dependent, all three weights > 0" % cnt)

# (3) all 35^3 = 42,875 branches: explicit w >= 0 supported in F, nonzero at all three worlds
nb = 0
T = list(combinations(range(N), B))
for F1, F2, F3 in product(T, T, T):
    w = posdep(COLS[0][F1[0]], COLS[1][F2[0]], COLS[2][F3[0]])
    ok(w is not None, "branch")
    nb += 1
print("(3) %d branches, each with an explicit nonnegative annihilating weight meeting all three worlds" % nb)

# (4) each branch's columns positively span R^2 (so every r in R^2 is w^T C for some w >= 0 on F)
#     It suffices that a positively dependent triple of pairwise independent vectors exists in F (3).
for a, b, c in product(*COLS):
    ok(det(a, b) != 0 and det(b, c) != 0 and det(a, c) != 0, "span")
print("(4) each positively dependent triple is pairwise independent, hence positively spans R^2")

# (5) the six mixed sign patterns are realised by explicit rational beta_s:
#     sgn <c_iv, beta_s> = s_i for every judge (i,v)
cands = [(Fr(x), Fr(y)) for x in range(-12, 13) for y in range(-12, 13) if (x, y) != (0, 0)]
found = {}
for s in product((1, -1), repeat=3):
    if len(set(s)) == 1:
        continue
    for beta in cands:
        if all((dot(c, beta) > 0) == (s[i] > 0) and dot(c, beta) != 0 for i in range(3) for c in COLS[i]):
            found[s] = beta; break
    ok(s in found, "pattern %s not realised" % (s,))
for s, beta in sorted(found.items()):
    print("(5) pattern %s realised by beta = (%s, %s)" % (s, beta[0], beta[1]))
# pure patterns are NOT realisable (columns positively span R^2), as stated in Section 6
for s in ((1, 1, 1), (-1, -1, -1)):
    ok(not any(all((dot(c, b) > 0) == (s[i] > 0) and dot(c, b) != 0 for i in range(3) for c in COLS[i]) for b in cands),
       "pure pattern unexpectedly realised")
print("(5') the pure patterns (+,+,+), (-,-,-) are realised by no candidate beta (they cannot be: columns positively span R^2)")

# (6) edge branches: for each pair of worlds, all 14 columns lie in an open half-plane,
#     so r = w^T C != 0 for every nonzero w >= 0 on an edge branch (hypothesis of Proposition 6.4)
for i, j in combinations(range(3), 2):
    good = None
    for f in cands:
        if all(dot(f, c) > 0 for c in COLS[i] + COLS[j]):
            good = f; break
    ok(good is not None, "edge %d%d: no strictly separating functional" % (i + 1, j + 1))
    print("(6) edge {%d,%d}: functional (%s,%s) is positive on all 14 columns" % (i + 1, j + 1, good[0], good[1]))

print()
print("ALL CHECKS PASSED" if not fails else "%d FAILURES" % len(fails))
