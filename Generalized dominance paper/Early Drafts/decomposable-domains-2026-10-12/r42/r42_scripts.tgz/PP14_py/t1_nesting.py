"""PP14 t1: the nesting criterion and its failure on the rescaled family (exact).

(a) Projected intervals.  For edge (i,j) (third world k) the e_k-perspective coordinate is rho = x_j/x_i.
    For every index p with p_i, p_j > 0 (interior, or on the edge (i,j)), the rescaled K_p projects to
    [rho_p * c/(c+eps), rho_p * (c+eps)/c] with rho_p = p_j/p_i: a multiplicative translate of one interval.
    We verify hi/lo = ((c+eps)/c)^2 exactly, and that no edge model's interval is strictly nested (either way)
    in an interior model's interval.  Contrast: the homothetic family (precise edge models).
(b) Brute force on lines (exact): for random a (interior and boundary) and r in the open edge, random lines of
    M_i and of M_j; "C_r is A-ward of C_a" (order A > S > B) on a line.  The nesting lemma predicts:
      witness in M_i  =>  lo_r > lo_a or hi_r > hi_a;   witness in M_j  =>  hi_r < hi_a or lo_r < lo_a.
    Rescaled: never witnesses in both classes for one (a, r).  Homothetic: both occur (Theorem J's patterns)."""
import sys, os, random
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from lib14 import *

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

ORD = {'A': 2, 'S': 1, 'B': 0}

def rand_simplex(rng, zeros=()):
    a = [0 if t in zeros else rng.randint(1, 1000) for t in W]; s = sum(a)
    return tuple(F(x, s) for x in a)

def rand_line_class(rng, m, near=None):
    """random line of class m.  If near = (polytope vertices), make it pass near a random point of the polytope."""
    if near is None:
        g = [rng.randint(1, 1000) for _ in W]; g[m] = -g[m]
        return tuple(g)
    for _ in range(200):
        lam = [rng.randint(1, 50) for _ in near]; s = sum(lam)
        x = tuple(sum(l*v[t] for l, v in zip(lam, near))/s for t in W)
        # a second point: random point on a random edge of the simplex
        i, j = rng.choice(EDGES); z = F(rng.randint(1, 999), 1000)
        e = [F(0)]*3; e[i] = 1 - z; e[j] = z
        g = line_through(x, tuple(e))
        if g is not None and cls(g) == m and all(v != 0 for v in g): return g
    return rand_line_class(rng, m)

if __name__ == '__main__':
    rng = random.Random(14)
    # ---------------- (a) ----------------
    pr('== (a) projected intervals (ratio rho = x_j/x_i, edge (i,j))')
    for eps in (F(3, 10), F(1, 10), F(1, 100)):
        c = (1 - eps)/3; ratio = ((c + eps)/c)**2
        P = [(F(1, 3),)*3, (F(98, 100), F(1, 100), F(1, 100)), (F(1, 100), F(1, 100), F(98, 100))] + \
            [rand_simplex(rng) for _ in range(40)]
        Ed = []
        for (i, j) in EDGES:
            for _ in range(15):
                z = F(rng.randint(1, 999), 1000); r = [F(0)]*3; r[i] = 1 - z; r[j] = z; Ed.append(((i, j), tuple(r)))
        okw = 0; tot = 0; nest_resc = 0; nest_homo = 0; pairs = 0; homo_all = 0; homo_tot = 0
        for p in P:
            for (i, j) in EDGES:
                lo, hi = theta_range(resc_verts(p, eps), i, j)
                tot += 1; okw += (hi/lo == ratio and lo == (p[j]/p[i])*c/(c + eps))
        for (e, r) in Ed:
            i, j = e
            lo, hi = theta_range(resc_verts(r, eps), i, j)
            tot += 1; okw += (hi/lo == ratio and lo == (r[j]/r[i])*c/(c + eps))
        for p in P:
            for (e, r) in Ed:
                i, j = e; pairs += 1
                la, ha = theta_range(resc_verts(p, eps), i, j); lr, hr = theta_range(resc_verts(r, eps), i, j)
                nest_resc += (la < lr and hr < ha) or (lr < la and ha < hr)
                la, ha = theta_range(homo_verts(p, eps), i, j); lr, hr = theta_range(homo_verts(r, eps), i, j)
                nest_homo += (la < lr and hr < ha) or (lr < la and ha < hr)
            # homothetic: the edge point with the same rho as p is strictly inside, on every edge
            for (i, j) in EDGES:
                homo_tot += 1
                r = [F(0)]*3; r[i] = p[i]/(p[i] + p[j]); r[j] = p[j]/(p[i] + p[j])
                la, ha = theta_range(homo_verts(p, eps), i, j); lr, hr = theta_range(homo_verts(tuple(r), eps), i, j)
                homo_all += (la < lr and hr < ha)
        pr('eps=%s: hi/lo = ((c+eps)/c)^2 and lo = rho_p c/(c+eps) exactly: %d/%d models;' % (eps, okw, tot),
           'strictly nested (interior a, edge r) pairs: rescaled %d/%d, homothetic %d/%d;' % (nest_resc, pairs, nest_homo, pairs),
           'homothetic window nonempty at every interior index and edge: %d/%d' % (homo_all, homo_tot))

    # ---------------- (b) ----------------
    pr('\n== (b) brute force on lines: C_r A-ward of C_a on M_i lines / on M_j lines, same (a, r)')
    for fam in ('resc', 'homo'):
        VF = resc_verts if fam == 'resc' else homo_verts
        for eps in (F(3, 10), F(1, 10)):
            n_pairs = 0; both = 0; pred_viol = 0; wi_tot = 0; wj_tot = 0; ifdir_tot = 0; ifdir_ok = 0
            kinds = {'interior': 0, 'edge ij': 0, 'edge ik/jk': 0, 'vertex': 0}
            for trial in range(250):
                (i, j) = rng.choice(EDGES); k = 3 - i - j
                kind = rng.choice(['interior']*5 + ['edge ij', 'edge ik/jk', 'vertex'])
                if kind == 'interior': a = rand_simplex(rng)
                elif kind == 'edge ij': a = rand_simplex(rng, zeros=(k,))
                elif kind == 'edge ik/jk': a = rand_simplex(rng, zeros=(rng.choice((i, j)),))
                else:
                    a = tuple(F(1) if t == rng.choice(W) else F(0) for t in W)
                    if sum(a) != 1: a = tuple(F(1) if t == i else F(0) for t in W)
                if fam == 'homo' and kind != 'interior': continue   # contrast only needed in the interior
                kinds[kind] += 1
                z = F(rng.randint(1, 999), 1000); r = [F(0)]*3; r[i] = 1 - z; r[j] = z; r = tuple(r)
                Va, Vr = VF(a, eps), VF(r, eps)
                # bias half the trials so that r's projection is close to a's (hardest case)
                if trial % 2 == 0 and a[i] > 0 and a[j] > 0:
                    z = a[j]/(a[i] + a[j]) + F(rng.randint(-50, 50), 10000)
                    if 0 < z < 1:
                        r = [F(0)]*3; r[i] = 1 - z; r[j] = z; r = tuple(r); Vr = VF(r, eps)
                wit = {i: False, j: False}
                for m in (i, j):
                    for t in range(100):
                        g = rand_line_class(rng, m, near=(Va if t % 3 else Vr))
                        aa, ar = adviceK(Va, g), adviceK(Vr, g)
                        if 'Z' in (aa, ar): continue
                        if ORD[ar] > ORD[aa]: wit[m] = True; break
                n_pairs += 1; both += wit[i] and wit[j]; wi_tot += wit[i]; wj_tot += wit[j]
                ta, tr = theta_range(Va, i, j), theta_range(Vr, i, j)
                if ta is not None:
                    (la, ha), (lr, hr) = ta, tr
                    if wit[i] and not (lr > la or hr > ha): pred_viol += 1
                    if wit[j] and not (hr < ha or lr < la): pred_viol += 1
                    if fam == 'resc' and kind == 'interior' and lr != la:
                        ifdir_tot += 1; ifdir_ok += wit[i] if lr > la else wit[j]
            pr('%s eps=%s: %d (a,r) pairs %s; witnesses in M_i: %d, in M_j: %d, in BOTH: %d; '
               'violations of the necessary condition: %d' % (fam, eps, n_pairs, dict((k_, v) for k_, v in kinds.items() if v),
                                                             wi_tot, wj_tot, both, pred_viol) +
               '')
    # ---------------- (c) ----------------
    pr('\n== (c) the "if" direction, constructively (exact): explicit witness lines')
    def edge_pt(i, j, t):     # point of edge (i,j) with ratio x_j/x_i = t
        e = [F(0)]*3; e[i] = 1/(1 + t); e[j] = t/(1 + t); return tuple(e)
    def witness(Va, Vr, i, j, m, typ):
        k = 3 - i - j; other = j if m == i else i
        (la, ha), (lr, hr) = theta_range(Va, i, j), theta_range(Vr, i, j)
        if m == i and typ == 'A': t = (la + lr)/2
        elif m == i: t = (max(lr, ha) + hr)/2
        elif typ == 'A': t = (hr + ha)/2
        else: t = (min(hr, la) + lr)/2
        z = edge_pt(i, j, t)
        for n in range(1, 60):
            d = F(1, 2**n); y = [F(0)]*3; y[m] = d; y[k] = 1 - d   # point of edge (m,k) near e_k
            g = line_through(z, tuple(y))
            if g is None or cls(g) != m: continue
            aa, ar = adviceK(Va, g), adviceK(Vr, g)
            if typ == 'A' and ar == 'A' and aa in ('S', 'B'): return g, aa, ar
            if typ == 'SB' and ar == 'S' and aa == 'B': return g, aa, ar
        return None
    for fam in ('resc', 'homo'):
        VF = resc_verts if fam == 'resc' else homo_verts
        for eps in (F(3, 10), F(1, 10), F(1, 100)):
            pred = 0; found = 0; spurious = 0
            for _ in range(300):
                a = rand_simplex(rng); (i, j) = rng.choice(EDGES)
                z = F(rng.randint(1, 999), 1000); r = [F(0)]*3; r[i] = 1 - z; r[j] = z; r = tuple(r)
                Va, Vr = VF(a, eps), VF(r, eps)
                (la, ha), (lr, hr) = theta_range(Va, i, j), theta_range(Vr, i, j)
                for m, typ, cond in ((i, 'A', lr > la), (i, 'SB', hr > max(ha, lr)), (j, 'A', hr < ha), (j, 'SB', lr < min(la, hr))):
                    w = witness(Va, Vr, i, j, m, typ)
                    if cond: pred += 1; found += w is not None
                    else: spurious += w is not None
            pr('%s eps=%s: predicted witnesses constructed exactly %d/%d; witnesses constructed where not predicted: %d'
               % (fam, eps, found, pred, spurious))
    open(os.path.join(HERE, 't1_nesting.out'), 'w').write('\n'.join(out) + '\n')
