"""PP14 t4: edge models of the rescaled family are threshold sets of the log-odds translation key (exact).

For r in the open edge (i,j) (third world k), with rho_r = r_j/r_i, lo_r = rho_r c/(c+eps), hi_r = rho_r (c+eps)/c,
and a line g of M_i u M_j crossing [e_i,e_j] at ratio t(g) = x_j/x_i = -g_i/g_j, the claim is:
  world-i rank of C_r on g  >= 1  iff  t(g) < hi_r ,   = 2  iff  t(g) < lo_r ;
  world-j rank of C_r on g  >= 1  iff  t(g) > lo_r ,   = 2  iff  t(g) > hi_r ;
  on M_k, C_r says A (world-i and world-j rank 0).
So U_i(C_r) = {(g,1): t < hi_r} u {(g,2): t < lo_r} = {key_i >= -log rho_r} with key_i(g,1) = L - log t(g),
key_i(g,2) = -L - log t(g), L = log((c+eps)/c): the gate2d keys l^{-1}, u^{-1}, here translations in log-odds."""
import sys, os, random
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from lib14 import *

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

if __name__ == '__main__':
    rng = random.Random(4)
    for eps in (F(3, 10), F(1, 10), F(1, 100)):
        c = (1 - eps)/3; tot = ok = 0
        for _ in range(300):
            (i, j) = rng.choice(EDGES); k = 3 - i - j
            z = F(rng.randint(1, 999), 1000); r = [F(0)]*3; r[i] = 1 - z; r[j] = z
            V = resc_verts(tuple(r), eps); rho = r[j]/r[i]; lo, hi = rho*c/(c + eps), rho*(c + eps)/c
            for _ in range(20):
                m = rng.choice(W)
                g = [rng.randint(1, 3000) for _ in W]; g[m] = -g[m]; g = tuple(g)
                adv = adviceK(V, g)
                if adv == 'Z': continue
                ri, rj = rank(adv, g, i), rank(adv, g, j)
                if m == k: pred = (adv == 'A')
                else:
                    t = F(-g[i], g[j])
                    if t in (lo, hi): continue
                    pred = ((ri >= 1) == (t < hi) and (ri == 2) == (t < lo) and (rj >= 1) == (t > lo) and (rj == 2) == (t > hi))
                tot += 1; ok += pred
        pr('eps=%s: threshold description of U_i(C_r), U_j(C_r), and A on M_k: %d/%d exact checks' % (eps, ok, tot))
    open(os.path.join(HERE, 't4_threshold_keys.out'), 'w').write('\n'.join(out) + '\n')
