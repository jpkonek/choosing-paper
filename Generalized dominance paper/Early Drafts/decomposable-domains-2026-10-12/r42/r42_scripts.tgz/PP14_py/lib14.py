"""PP14 shared library: exact (Fraction) geometry for the rescaled contamination family.

Conventions (as in PP2 / PP11):
  * worlds 0,1,2 in code = worlds 1,2,3 in the note;
  * a problem is a line of the simplex, given by an integer/rational normal g (no zero coordinate);
  * class of g = the minority world (the coordinate whose sign differs from the other two);
  * orient(g): the sign of g making the two majority coordinates positive.  Advice 'A' = accept orient(g)
    (good for both majority worlds), 'B' = accept -orient(g) (good for the minority world), 'S' = silent;
  * D_K for a polytope K (list of vertices): A if orient(g).v > 0 for all vertices, B if < 0 for all,
    S if signs are strictly mixed; 'Z' if some vertex lies exactly on the line (non-generic; we avoid it);
  * ranks: majority world A 0, S 1, B 2; minority world A 2, S 1, B 0.

Families:
  * rescaled:  K_p = conv{ p*v_l / (p.v_l) : v_l vertex of M },  M = c1 + eps*Delta, c = (1-eps)/3;
  * homothetic (PP11): K_p = p + 3 eps min(p) (Delta - u).

Anchor faces of an advice pattern  old: {line -> advice}  (= the old side of a record on its disagreement):
  * vertex e_i: D_{e_i} equals old on every line;
  * open edge (i,j): some r in relint Delta_ij with C_r = old on every line (exact, 1-parameter rho = r_j/r_i);
  * interior: some q in the open simplex with C_q = old on every line (exact, vertical decomposition of the
    arrangement of the affine sign functions in the (q_1,q_2)-plane).
All tests use open conditions only (a germ/tiny cone around each line), so they are a.e.-correct."""
from fractions import Fraction as F
import itertools

W = (0, 1, 2)
EDGES = ((0, 1), (0, 2), (1, 2))

def dot(a, b): return sum(x*y for x, y in zip(a, b))
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])

def cls(g):
    s = [x > 0 for x in g]
    if all(s) or not any(s): return None
    for i in W:
        if sum(1 for j in W if s[j] == s[i]) == 1: return i

def orient(g):
    m = cls(g); j = [t for t in W if t != m][0]
    return tuple(g) if g[j] > 0 else tuple(-x for x in g)

def adviceK(V, g):
    go = orient(g); s = [dot(go, v) for v in V]
    if any(x == 0 for x in s): return 'Z'
    if all(x > 0 for x in s): return 'A'
    if all(x < 0 for x in s): return 'B'
    return 'S'

def rank(adv, g, w):
    m = cls(g)
    if adv == 'S': return 1
    if w == m: return {'A': 2, 'B': 0}[adv]
    return {'A': 0, 'B': 2}[adv]

def Mverts(eps):
    c = (1 - eps)/3
    return [tuple(c + (eps if t == l else 0) for t in W) for l in W]

def resc_verts(p, eps):
    out = []
    for v in Mverts(eps):
        pv = tuple(p[t]*v[t] for t in W); s = sum(pv)
        w = tuple(x/s for x in pv)
        if w not in out: out.append(w)
    return out

def homo_verts(p, eps):
    m = min(p); u = F(1, 3)
    out = []
    for l in W:
        w = tuple(p[t] + 3*eps*m*((1 if t == l else 0) - u) for t in W)
        if w not in out: out.append(w)
    return out

def theta_range(V, i, j):
    """range of the e_k-perspective coordinate x_j/x_i over a polytope (as ratios, exact)."""
    rs = [v[j]/v[i] for v in V if v[i] > 0]
    return (min(rs), max(rs)) if rs else None

def vertex_advice(i, g):
    go = orient(g); return 'A' if go[i] > 0 else 'B'

# ---------- exact anchor faces ----------
def _sign_ok(vals, adv):
    if any(x == 0 for x in vals): return False
    if adv == 'A': return all(x > 0 for x in vals)
    if adv == 'B': return all(x < 0 for x in vals)
    return any(x > 0 for x in vals) and any(x < 0 for x in vals)

def edge_anchor(old, i, j, eps, family='resc'):
    """Is there r in the open edge (i,j) with C_r = old on every line?  Returns a witness rho=r_j/r_i or None.
    rescaled: sign of orient(g).(r*v)/(r.v) = sign of go_i v_i + rho go_j v_j  (v vertex of M);
    homothetic: C_r = D_{r} (precise), sign of go_i + rho go_j."""
    fns = []   # per line: list of (a, b) meaning a + rho*b
    for g, adv in old.items():
        go = orient(g)
        if family == 'resc':
            fns.append(([(go[i]*v[i], go[j]*v[j]) for v in Mverts(eps)], adv))
        else:
            fns.append(([(go[i], go[j])], adv))
    bps = set()
    for fl, _ in fns:
        for a, b in fl:
            if b != 0:
                r = -a/b
                if r > 0: bps.add(r)
    bps = sorted(bps)
    cands = []
    if not bps: cands = [F(1)]
    else:
        cands.append(bps[0]/2)
        for x, y in zip(bps, bps[1:]): cands.append((x+y)/2)
        cands.append(bps[-1]*2)
    for rho in cands:
        if all(_sign_ok([a + rho*b for a, b in fl], adv) for fl, adv in fns): return rho
    return None

def interior_anchor(old, eps, family='resc'):
    """Is there q in the open simplex with C_q = old on every line?  rescaled only (sign functions affine in q):
    orient(g).(q*v) = sum_t q_t v_t go_t, with q_3 = 1-q_1-q_2.  Returns a witness q or None."""
    assert family == 'resc'
    V = Mverts(eps)
    fns = []
    lines2d = []   # affine functions alpha*x + beta*y + gamma in (x,y)=(q1,q2)
    for g, adv in old.items():
        go = orient(g); fl = []
        for v in V:
            a0, a1, a2 = v[0]*go[0], v[1]*go[1], v[2]*go[2]
            fl.append((a0 - a2, a1 - a2, a2))
        fns.append((fl, adv)); lines2d.extend(fl)
    lines2d += [(F(1), F(0), F(0)), (F(0), F(1), F(0)), (F(-1), F(-1), F(1))]
    # x-coordinates of all pairwise intersections and vertical lines, within [0,1]
    xs = {F(0), F(1)}
    L = list(set(lines2d))
    for (a, b, c) in L:
        if b == 0 and a != 0: xs.add(-c/a)
    for (a1, b1, c1), (a2, b2, c2) in itertools.combinations(L, 2):
        det = a1*b2 - a2*b1
        if det != 0:
            x = (-c1*b2 + c2*b1)/det
            xs.add(x)
    xs = sorted(x for x in xs if 0 <= x <= 1)
    for x0, x1 in zip(xs, xs[1:]):
        x = (x0 + x1)/2
        ys = {F(0), 1 - x}
        for (a, b, c) in L:
            if b != 0: ys.add(-(a*x + c)/b)
        ys = sorted(y for y in ys if 0 <= y <= 1 - x)
        for y0, y1 in zip(ys, ys[1:]):
            y = (y0 + y1)/2
            if all(_sign_ok([a*x + b*y + c for a, b, c in fl], adv) for fl, adv in fns):
                return (x, y, 1 - x - y)
    return None

def anchor_faces(old, eps, family='resc', interior=True):
    """faces met by the anchor set of the pattern old: list of frozensets of worlds (0-based)."""
    faces = []
    for i in W:
        if all(vertex_advice(i, g) == adv for g, adv in old.items()): faces.append(frozenset([i]))
    for (i, j) in EDGES:
        if edge_anchor(old, i, j, eps, family) is not None: faces.append(frozenset([i, j]))
    if interior and family == 'resc':
        if interior_anchor(old, eps) is not None: faces.append(frozenset(W))
    return faces

# ---------- records ----------
def record(X, Y):
    """rec(X,Y) on the union of their line sets: canonical frozenset of (g, oldadv, newadv) with old != new."""
    keys = set(X) | set(Y)
    return frozenset((g, X[g], Y[g]) for g in keys if X[g] != Y[g])

def guidance(rec):
    """per world: +1 if accepted by weak guidance (new weakly worse everywhere), -1 if refused by strict
    guidance (new strictly better somewhere and weakly better everywhere), 0 otherwise.  Trivial record: +1."""
    out = []
    for w in W:
        diffs = [rank(n, g, w) - rank(o, g, w) for g, o, n in rec]
        if all(d >= 0 for d in diffs): out.append(1)
        elif all(d <= 0 for d in diffs): out.append(-1)
        else: out.append(0)
    return tuple(out)

def line_through(P, Q):
    g = cross(P, Q)
    # clear denominators
    from math import lcm
    den = 1
    for x in g: den = lcm(den, F(x).denominator)
    g = tuple(int(x*den) for x in g)
    from math import gcd
    h = 0
    for x in g: h = gcd(h, abs(x))
    if h == 0: return None
    return tuple(x//h for x in g)
