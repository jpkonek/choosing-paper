"""PP14 t3: the Theorem-J module with EXACT anchors, rescaled family vs homothetic family (same T1, same rivals).

Geometry (edge (i,j), third world k; a interior; K_a the selected credal set at a):
  side-i lines: n lines of M_i through a point x of int K_a near the vertex of K_a with the smallest ratio
                x_j/x_i, crossing [e_i,e_j] slightly on the e_j side of x  (Lemma J0's construction);
  side-j lines: n lines of M_j through a point x' near the vertex with the largest ratio.
  C_a is silent on all 2n lines (checked).  Each line stands for a tiny cone (open conditions only).
Pool:
  1-parameter family X_m = C_a + A on (side-i lines m+1..n) u (side-j lines 1..m), m = 0..n;
  2-parameter family X_{s,t} = C_a + A on (side-i lines 1..s) u (side-j lines 1..t), (s,t) != (0,0).
Clauses (axioms only; one variable per record and world, so (IB) is built in):
  (G) units; OBL for every face met by the exact anchor set of every record (rescaled: vertices, open edges and
  interior, all exact; homothetic: vertices and open edges, a relaxation); FWD (competitiveness of C_a on
  {1,2,3}: every rec(C_a, X) is anchored at a itself); UND for the selected C_a; (TC) on all triples at all
  worlds.  No closed-section clause is needed (one selected model).
Queries: base SAT; backbone on the edge-world verdicts; 'no edge-world defence' (every interior member's reverse
record refused at both edge worlds: the closed allocation L_i = {n}, L_j = {0}); every cut position; inversions
(d_mu in R_i, d_nu in R_j with X_nu better for world i than X_mu), with and without a member strictly between."""
import sys, os, itertools, random
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from lib14 import *
from pysat.solvers import Solver

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def j_lines(Va, i, j, n):
    k = 3 - i - j
    cen = tuple(sum(v[t] for v in Va)/len(Va) for t in W)
    pts = [tuple(cen[t] + F(3, 4)*(v[t] - cen[t]) for t in W) for v in Va]
    ratio = lambda x: x[j]/x[i]
    x, xp = min(pts, key=ratio), max(pts, key=ratio)
    mid = (ratio(x) + ratio(xp))/2
    def ept(t):
        e = [F(0)]*3; e[i] = 1/(1 + t); e[j] = t/(1 + t); return tuple(e)
    side_i, side_j = [], []
    for l in range(1, n + 1):
        gi = line_through(x, ept(ratio(x) + (mid - ratio(x))*F(l, 2*n + 2)))
        gj = line_through(xp, ept(ratio(xp) - (ratio(xp) - mid)*F(l, 2*n + 2)))
        assert cls(gi) == i and cls(gj) == j, (gi, gj)
        assert adviceK(Va, gi) == 'S' and adviceK(Va, gj) == 'S'
        side_i.append(gi); side_j.append(gj)
    return side_i, side_j

class Module:
    def __init__(self, models, selected, eps, family):
        self.models = models; self.sel = selected; self.eps = eps; self.fam = family
        self.var = {}; self.cls = []; self.recinfo = {}
    def v(self, key):
        if key not in self.var: self.var[key] = len(self.var) + 1
        return self.var[key]
    def acc(self, x, y, w):
        if x == y: return True
        rec = record(self.models[x], self.models[y])
        if rec not in self.recinfo:
            old = {g: o for g, o, _ in rec}
            gd = guidance(rec)
            faces = anchor_faces(old, self.eps, family=self.fam, interior=(self.fam == 'resc'))
            self.recinfo[rec] = (gd, faces)
        gd, _ = self.recinfo[rec]
        if gd[w] == 1: return True
        if gd[w] == -1: return False
        return self.v((rec, w))
    def clause(self, lits):
        o = []
        for l in lits:
            if l is True: return
            if l is False: continue
            o.append(l)
        self.cls.append(o)
    def build(self):
        names = list(self.models)
        neg = lambda l: (not l) if isinstance(l, bool) else -l
        for x, y in itertools.permutations(names, 2):
            for w in W: self.acc(x, y, w)
            rec = record(self.models[x], self.models[y]); gd, faces = self.recinfo[rec]
            for f in faces: self.clause([self.acc(x, y, w) for w in f])
        for c in self.sel:
            for x in names:
                if x == c: continue
                # competitiveness of the selected (interior) C itself: rec(C, x) is anchored at C's own index
                # (exact; this is the FWD clause, needed explicitly in the homothetic run where interior anchors
                #  are not computed)
                self.clause([self.acc(c, x, w) for w in W])
                L = [self.acc(x, c, w) for w in W]; Fw = [self.acc(c, x, w) for w in W]
                for jj in W: self.clause([neg(L[0]), neg(L[1]), neg(L[2]), Fw[jj]])
        for w in W:
            for x, y, z in itertools.permutations(names, 3):
                self.clause([neg(self.acc(x, y, w)), neg(self.acc(y, z, w)), neg(self.acc(z, x, w)), self.acc(x, z, w)])
    def solve(self, assumptions=()):
        S = Solver(name='cd19', bootstrap_with=self.cls)
        ok = S.solve(assumptions=list(assumptions)); m = S.get_model() if ok else None; S.delete()
        return ok, m
    def lit(self, x, y, w):
        return self.acc(x, y, w)

def backbone(mod, keys):
    ok, m = mod.solve()
    assert ok
    ms = set(m)
    forced = []
    for key in keys:
        l = mod.lit(*key)
        if isinstance(l, bool): continue
        cur = l if l in ms else -l
        ok2, _ = mod.solve([-cur])
        if not ok2: forced.append((key, cur > 0))
    return forced

def one_param(a, eps, i, j, n, fam):
    VF = resc_verts if fam == 'resc' else homo_verts
    Va = resc_verts(a, eps)   # same C_a in both families when a = u; for other a we use each family's own K_a
    Va = VF(a, eps)
    si, sj = j_lines(Va, i, j, n)
    lines = si + sj
    base = {g: adviceK(Va, g) for g in lines}
    models = {'C': dict(base)}
    for m in range(n + 1):
        X = dict(base)
        for g in si[m:]: X[g] = 'A'
        for g in sj[:m]: X[g] = 'A'
        models['X%d' % m] = X
    mod = Module(models, ['C'], eps, fam); mod.build()
    return mod, models, si, sj

def describe_faces(mod, models, x, y):
    rec = record(models[x], models[y]); gd, faces = mod.recinfo[rec]
    fs = ','.join('{' + ''.join(str(w+1) for w in sorted(f)) + '}' for f in faces)
    return 'guid=%s faces=%s' % (''.join({1: '+', -1: '-', 0: '.'}[g] for g in gd), fs)

if __name__ == '__main__':
    n = 4
    cases = [((F(1, 3),)*3, F(3, 10), (0, 1)), ((F(1, 3),)*3, F(1, 10), (0, 1)),
             ((F(1, 2), F(3, 10), F(1, 5)), F(3, 10), (1, 2)), ((F(1, 2), F(3, 10), F(1, 5)), F(3, 10), (0, 2))]
    for a, eps, (i, j) in cases:
        k = 3 - i - j
        for fam in ('resc', 'homo'):
            mod, models, si, sj = one_param(a, eps, i, j, n, fam)
            tag = '%s a=%s eps=%s edge=(%d,%d)' % (fam, tuple(map(str, a)), eps, i+1, j+1)
            ok, _ = mod.solve()
            pr('== 1-parameter module, %s: %d models, %d variables, %d clauses, SAT=%s' % (tag, len(models), len(mod.var), len(mod.cls), ok))
            for m in range(n + 1):
                pr('   d_%d = rec(X_%d, C_a): %s    e_%d = rec(C_a, X_%d): %s' % (m, m, describe_faces(mod, models, 'X%d' % m, 'C'),
                                                                               m, m, describe_faces(mod, models, 'C', 'X%d' % m)))
            # no edge-world defence of any interior member
            asm = []
            for m in range(1, n):
                for w in (i, j):
                    l = mod.lit('X%d' % m, 'C', w)
                    if not isinstance(l, bool): asm.append(-l)
            ok_none, _ = mod.solve(asm)
            # cut positions: L_j = [0, c), L_i = [c, n] (exactly one), c = 1..n
            cuts = []
            for c in range(1, n + 1):
                asm2 = []
                for m in range(n + 1):
                    li, lj = mod.lit('X%d' % m, 'C', i), mod.lit('X%d' % m, 'C', j)
                    want_i, want_j = (m >= c), (m < c)
                    for l, wnt in ((li, want_i), (lj, want_j)):
                        if isinstance(l, bool):
                            if l != wnt: asm2 = None; break
                        else: asm2.append(l if wnt else -l)
                    if asm2 is None: break
                cuts.append(asm2 is not None and mod.solve(asm2)[0])
            # residual order constraint: no far inversion d_mu in R_i, d_nu in R_j with nu >= mu+2 (a member between)
            far = []; adj = []
            for mu in range(n + 1):
                for nu in range(mu + 1, n + 1):
                    li, lj = mod.lit('X%d' % mu, 'C', i), mod.lit('X%d' % nu, 'C', j)
                    if li is False or lj is False: continue
                    asm3 = [l for l in (li, lj) if not isinstance(l, bool)]
                    (far if nu >= mu + 2 else adj).append(mod.solve(asm3)[0])
            pr('   inversions d_mu in R_%d, d_nu in R_%d (mu<nu): with a member between: %d tested, %d SAT; adjacent: %d tested, %d SAT'
               % (i+1, j+1, len(far), sum(far), len(adj), sum(adj)))
            keys = [('X%d' % m, 'C', w) for m in range(n + 1) for w in (i, j)] + [('C', 'X%d' % m, w) for m in range(n + 1) for w in (i, j)]
            bb = backbone(mod, keys)
            pr('   interior members refused at BOTH edge worlds %d,%d (closed allocation L_%d={n}, L_%d={0}): SAT=%s' % (i+1, j+1, i+1, j+1, ok_none))
            pr('   cut positions c=1..%d realisable: %s' % (n, cuts))
            pr('   backbone on the edge-world verdicts of d_m, e_m (beyond guidance): %d literals %s' %
               (len(bb), ['%s<=_%d%s:%s' % (x, w+1, y, 'T' if v else 'F') for (x, y, w), v in bb][:12]))
    # ---------- 2-parameter module ----------
    for a, eps, (i, j) in cases[:2] + cases[2:3]:
        for fam in ('resc', 'homo'):
            VF = resc_verts if fam == 'resc' else homo_verts
            Va = VF(a, eps); nn = 3
            si, sj = j_lines(Va, i, j, nn)
            base = {g: adviceK(Va, g) for g in si + sj}
            models = {'C': dict(base)}
            for s in range(nn + 1):
                for t in range(nn + 1):
                    if s == t == 0: continue
                    X = dict(base)
                    for g in si[:s]: X[g] = 'A'
                    for g in sj[:t]: X[g] = 'A'
                    models['X%d%d' % (s, t)] = X
            mod = Module(models, ['C'], eps, fam); mod.build()
            ok, _ = mod.solve()
            two = [x for x in models if x != 'C' and x[1] != '0' and x[2] != '0']
            asm = []
            for x in two:
                for w in (i, j):
                    l = mod.lit(x, 'C', w)
                    if not isinstance(l, bool): asm.append(-l)
            ok_none, _ = mod.solve(asm)
            n_edge = sum(1 for x in two if frozenset([i, j]) in mod.recinfo[record(models[x], models['C'])][1])
            # order: y better than x for world i iff s_y <= s_x and t_y >= t_x (strictly somewhere)
            st = lambda x: (int(x[1]), int(x[2]))
            better = lambda x, y: st(y)[0] <= st(x)[0] and st(y)[1] >= st(x)[1] and st(x) != st(y)
            mem = [x for x in models if x != 'C']
            far = []
            for x in mem:
                for y in mem:
                    if not better(x, y): continue
                    if not any(better(x, z) and better(z, y) for z in mem): continue
                    li, lj = mod.lit(x, 'C', i), mod.lit(y, 'C', j)
                    if li is False or lj is False: continue
                    far.append(mod.solve([l for l in (li, lj) if not isinstance(l, bool)])[0])
            keys = [(x, 'C', w) for x in models if x != 'C' for w in (i, j)]
            bb = backbone(mod, keys)
            pr('== 2-parameter module (n=%d), %s a=%s eps=%s edge=(%d,%d): %d models, SAT=%s; two-class members whose reverse record '
               'is anchored on the edge: %d/%d; all two-class members refused at both edge worlds: SAT=%s; backbone on reverse '
               'edge-world verdicts: %d literals' % (nn, fam, tuple(map(str, a)), eps, i+1, j+1, len(models), ok, n_edge, len(two), ok_none, len(bb)))
            pr('   2-parameter inversions (x in L_%d below y in L_%d, a member between, along the world-%d order): %d tested, %d SAT'
               % (i+1, j+1, i+1, len(far), sum(far)))
    open(os.path.join(HERE, 't3_skeleton.out'), 'w').write('\n'.join(out) + '\n')
