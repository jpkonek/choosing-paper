"""PP14 t2: Theorem N on exact records into selected models (no forced exclusivity on the rescaled family).

For a record d = rec(C_q|D, C_a|D) (old side = the selected C_q on D, new side = the selected C_a), with D a
finite set of generic lines of D(C_q, C_a) (each standing for a tiny cone), we compute exactly:
  * guidance per world (+1 accepted / -1 refused / 0 free);
  * every face met by the anchor set A(d): vertices, open edges, interior (rescaled: all exact);
  * the feasible acceptance sets W of d alone under (G), the face obligations and undominatedness of C_a
    (W = {1,2,3} is excluded whenever some world is guidance-decided, since then no all-world tie exists;
     when no world is guidance-decided we also exclude it, which only makes forcing MORE likely).
We report:
  N1  if Guid+ is nonempty, Guid+ meets every anchor face            (Theorem N: always, rescaled);
  N2  the clause system of d is satisfiable                           (always);
  FX  'forced exclusivity': some pair {i,j}, neither guidance-decided, such that every feasible W contains
      exactly one of i, j  (the record-level content of Theorem J (1)).
Contrast: the homothetic family (precise edge models), with vertex and edge anchors only (dropping interior
anchors is a relaxation; it can only remove forcing, so forcing found there is genuine)."""
import sys, os, random, itertools
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from lib14 import *
from t1_nesting import rand_simplex, rand_line_class

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

ORD = {'A': 2, 'S': 1, 'B': 0}
SUBSETS = [frozenset(s) for n in (1, 2, 3) for s in itertools.combinations(W, n)]

def feasible_sets(gd, faces):
    plus = {w for w in W if gd[w] == 1}; minus = {w for w in W if gd[w] == -1}
    res = []
    for S in SUBSETS:
        if not plus <= S or S & minus: continue
        if not all(S & f for f in faces): continue
        if len(S) == 3: continue
        res.append(S)
    return res

def forced_exclusivity(gd, feas):
    for i, j in EDGES:
        if gd[i] != 0 or gd[j] != 0: continue
        if feas and all(len(S & {i, j}) == 1 for S in feas): return (i, j)
    return None

def rand_index(rng):
    kind = rng.choice(['int']*4 + ['edge', 'vertex'])
    if kind == 'int': return rand_simplex(rng)
    if kind == 'edge': return rand_simplex(rng, zeros=(rng.choice(W),))
    v = rng.choice(W); return tuple(F(1) if t == v else F(0) for t in W)

def sample_lines(rng, Vq, Va, nlines, targeted=None):
    L = []
    tries = 0
    while len(L) < nlines and tries < 4000:
        tries += 1
        m = rng.choice(W) if targeted is None else rng.choice(targeted)
        g = rand_line_class(rng, m, near=(Va if tries % 2 else Vq))
        aq, aa = adviceK(Vq, g), adviceK(Va, g)
        if 'Z' in (aq, aa) or aq == aa: continue
        if any(v == 0 for v in g): continue
        L.append((g, aq, aa))
    return L

def run(fam, eps, trials, rng, targeted=False):
    VF = resc_verts if fam == 'resc' else homo_verts
    stats = dict(records=0, n1_fail=0, n2_fail=0, fx=0, guided=0, edge_anch_with_third_guid=0, both_classes_pairs=0, pairs=0)
    example = None
    for t in range(trials):
        if targeted:
            (i, j) = rng.choice(EDGES); k = 3 - i - j
            a = rand_simplex(rng)
            z = a[j]/(a[i] + a[j]) + F(rng.randint(-200, 200), 10000)
            if not 0 < z < 1: continue
            q = [F(0)]*3; q[i] = 1 - z; q[j] = z; q = tuple(q)
        else:
            a, q = rand_index(rng), rand_index(rng)
        Va, Vq = VF(a, eps), VF(q, eps)
        if targeted:
            L = sample_lines(rng, Vq, Va, 40, targeted=(i, j))
            # keep the lines where C_q is A-ward of C_a (third-world guidance candidates)
            L = [x for x in L if ORD[x[1]] > ORD[x[2]]]
            stats['pairs'] += 1
            cl = {cls(g) for g, _, _ in L}
            if len(cl) == 2: stats['both_classes_pairs'] += 1
            pools = [L]
        else:
            L = sample_lines(rng, Vq, Va, 8)
            pools = [L]
        if not L: continue
        for _ in range(6):
            n = rng.randint(1, min(5, len(L)))
            if targeted and len({cls(g) for g, _, _ in L}) == 2:
                by = {}
                for x in L: by.setdefault(cls(x[0]), []).append(x)
                D = [rng.choice(by[i]), rng.choice(by[j])] + rng.sample(L, n - 1)
            else:
                D = rng.sample(L, n)
            D = list({x[0]: x for x in D}.values())
            old = {g: o for g, o, _ in D}
            rec = frozenset((g, o, nw) for g, o, nw in D)
            gd = guidance(rec)
            faces = anchor_faces(old, eps, family=fam, interior=(fam == 'resc'))
            stats['records'] += 1
            plus = {w for w in W if gd[w] == 1}
            if plus: stats['guided'] += 1
            if plus and not all(plus & f for f in faces): stats['n1_fail'] += 1
            for f in faces:
                if len(f) == 2:
                    kk = (set(W) - f).pop()
                    if gd[kk] == 1 and gd[min(f)] == 0 and gd[max(f)] == 0: stats['edge_anch_with_third_guid'] += 1
            feas = feasible_sets(gd, faces)
            if not feas: stats['n2_fail'] += 1
            fx = forced_exclusivity(gd, feas)
            if fx:
                stats['fx'] += 1
                if example is None:
                    example = dict(a=a, q=q, D=[(g, o, nw) for g, o, nw in D], gd=gd, faces=[sorted(x+1 for x in f) for f in faces],
                                   pair=(fx[0]+1, fx[1]+1))
    return stats, example

if __name__ == '__main__':
    rng = random.Random(1414)
    for fam in ('resc', 'homo'):
        for eps in (F(3, 10), F(1, 10)):
            st, ex = run(fam, eps, 120, rng, targeted=False)
            pr('%s eps=%s random records into selected models: %s' % (fam, eps, st))
            st, ex = run(fam, eps, 120, rng, targeted=True)
            pr('%s eps=%s TARGETED (q on an edge near a\'s projection, D inside {C_q A-ward of C_a} in M_i u M_j): %s' % (fam, eps, st))
            if ex:
                pr('   example of forced exclusivity (Theorem J record):', 'a=%s q=%s guidance=%s faces=%s exactly-one-of=%s' %
                   (tuple(map(str, ex['a'])), tuple(map(str, ex['q'])), ex['gd'], ex['faces'], ex['pair']))
                for g, o, nw in ex['D']: pr('      line', g, 'class', cls(g)+1, 'old', o, 'new', nw)
    open(os.path.join(HERE, 't2_records.out'), 'w').write('\n'.join(out) + '\n')
