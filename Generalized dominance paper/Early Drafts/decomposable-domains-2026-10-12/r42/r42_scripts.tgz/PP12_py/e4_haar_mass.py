"""PP12 e4 (NUMERICS): translates of T1 disagree on infinite Haar mass.
Class Q_0 chart (x, y) = (log h1/|h0|, log h2/|h0|), Haar = Lebesgue dx dy.
C_q is T1 translated by v = (log q1/q0, log q2/q0).  We estimate the Lebesgue area of
{C_q != C_{q'}} inside [-R, R]^2; linear growth in R means infinite Haar mass, so for a
fixed rival X the record rec(C_p, X) has finite Haar mass for at most one p (Lemma D).
"""
import math
eps = 0.3; c = (1 - eps) / 3
def reg(x, y):
    X, Y = math.exp(x), math.exp(y)
    if c * (X + Y - 1) + eps * max(X, Y) < 0: return 0
    if c * (X + Y - 1) - eps > 0: return 2
    return 1
lines = []
for v in ((0.5, 0.0), (0.0, 0.2), (0.3, -0.3), (1.0, 1.0)):
    row = []
    for R in (5, 10, 20, 40):
        n = 400; h = 2 * R / n; area = 0.0
        for i in range(n):
            x = -R + (i + 0.5) * h
            for j in range(n):
                y = -R + (j + 0.5) * h
                if reg(x, y) != reg(x + v[0], y + v[1]): area += h * h
        row.append(f"R={R}: {area:.2f}")
    lines.append(f"v={v}: " + ", ".join(row))
open('e4_haar_mass.out', 'w').write("\n".join(lines) + "\n")
print("\n".join(lines))
