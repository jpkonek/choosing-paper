"""PP12 shared library: exact rational geometry of T1 and its rescaled family.

Conventions (as in PP12_equivariance.md):
  * T1 = D_M, M = c*1 + eps*Delta, c = (1-eps)/3; vertices v_i = c*1 + eps*e_i.
  * Advice of a coherent model D_K on gamble h: 'A' (accept h) if min_K q.h > 0,
    'B' (accept -h) if max_K q.h < 0, else 'S'.  K is given by its vertices.
  * Rescaled family: M_p = { p*m/(p.m) : m in M }, vertices p*v_i/(p.v_i).
  * Classes: a mixed problem has a unique majority orientation h (two positive
    coordinates); its class is the index of the negative coordinate (0-based).
    Advice relative to h: 'M' (accept h), 'S', 'O' (accept -h), 'X' (both).
  * Ranks at world i on class c: i != c: M0 S1 O2 X3;  i == c: O0 S1 M2 X3.
    Unanimous (h > 0): correct 'C' 0, 'S' 1, wrong 'W' 2, 'X' 3.
"""
from fractions import Fraction as F
import random

def T1_vertices(eps):
    c = (1 - eps) / 3
    return [tuple(c + (eps if j == i else 0) for j in range(3)) for i in range(3)]

def dot(a, b):
    return sum(x * y for x, y in zip(a, b))

def had(a, b):
    return tuple(x * y for x, y in zip(a, b))

def advice_DK(verts, h):
    vals = [dot(v, h) for v in verts]
    if min(vals) > 0:
        return 'A'
    if max(vals) < 0:
        return 'B'
    return 'S'

def T1_advice(eps, h):
    """Closed form: A iff c*sum h + eps*min h > 0; B iff c*sum h + eps*max h < 0."""
    c = (1 - eps) / 3
    s = sum(h)
    if c * s + eps * min(h) > 0:
        return 'A'
    if c * s + eps * max(h) < 0:
        return 'B'
    return 'S'

def Mp_vertices(eps, p):
    return [tuple(x / dot(p, v) for x in had(p, v)) for v in T1_vertices(eps)]

def C_advice(eps, p, g):
    """Advice of C_p = D_{M_p} on gamble g (via the vertices of M_p)."""
    return advice_DK(Mp_vertices(eps, p), g)

def orient(g):
    """Return (class, h) for a mixed g (h = majority orientation), or ('U', h)."""
    pos = [x > 0 for x in g]
    if all(pos):
        return 'U', tuple(g)
    if not any(pos):
        return 'U', tuple(-x for x in g)
    h = tuple(g) if sum(pos) == 2 else tuple(-x for x in g)
    c = [i for i in range(3) if h[i] < 0][0]
    return c, h

def rel_advice(model_advice_on_h):
    """Translate 'A'/'B'/'S' on the majority orientation h into 'M'/'O'/'S'."""
    return {'A': 'M', 'B': 'O', 'S': 'S'}[model_advice_on_h]

RANK_MAJ = {'M': 0, 'S': 1, 'O': 2, 'X': 3}
RANK_ODD = {'O': 0, 'S': 1, 'M': 2, 'X': 3}
RANK_U = {'C': 0, 'S': 1, 'W': 2, 'X': 3}

def rank(i, cls, adv):
    if cls == 'U':
        return RANK_U[adv]
    return RANK_ODD[adv] if i == cls else RANK_MAJ[adv]

def rand_frac(rng, lo=-5, hi=5, den=97):
    return F(rng.randint(lo * den, hi * den), den)

def rand_simplex(rng, den=997, zero=()):
    while True:
        w = [F(0) if i in zero else F(rng.randint(1, den)) for i in range(3)]
        s = sum(w)
        if s > 0:
            return tuple(x / s for x in w)

def rand_gamble(rng, den=101):
    while True:
        g = tuple(F(rng.randint(-10 * den, 10 * den), den) for _ in range(3))
        if all(x != 0 for x in g):
            return g
