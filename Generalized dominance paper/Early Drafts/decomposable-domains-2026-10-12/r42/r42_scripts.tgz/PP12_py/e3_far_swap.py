"""PP12 e3: geometry of Theorem L (X2.9 under (TC) for locally complete worlds).

World 0, class Q_0 chart h = (-1, X, Y), X = e^x, Y = e^y > 0 (exact rationals).
T1 on Q_0:  O iff c(X+Y-1) + eps*max(X,Y) < 0  (a down-set in (X,Y));
            M iff c(X+Y-1) - eps > 0          (an up-set);   S otherwise.
C_q at (X,Y) is T1 at (q1/q0 X, q2/q0 Y).
P   = box [1-d,1+d]^2 (around h = (-1,1,1)); far pieces are images p*P.
      d = (A-1)/(8A), A = 1+eps/c; E1 centred at R = 2+eps/c; t >= t0 = 4+4eps/c+1/d
      (the eps-dependent choices of the X12 referee, section 2.7).
Pi1 = p1*P, p1 = nu(t1,1,1)        -> box around (1/t1, 1/t1)
q   = nu(1, 1/t2, t1)
Pi2 = S_q^{-1}(p2*P), p2 = nu(t2,1,1) -> box around (1, 1/(t1 t2))
E1  = box [R-d,R+d]^2.
Checked on whole boxes via corners (down-set / up-set monotonicity):
  T1: O on Pi1, S on Pi2, M on E1;   C_q: S on Pi1, O on Pi2;  boxes disjoint.
Then rho1 = rec(T1, T1[Pi2,E1 -> O; Pi1 -> S]) and rho2 = rec(C_q, C_q[Pi1 -> O; Pi2 -> S])
compose (middles match) to T1 -> T1[E1 -> O], a strict world-0 improvement.
"""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F

def regionT1(eps, X, Y):
    c = (1 - eps) / 3
    if c * (X + Y - 1) + eps * max(X, Y) < 0:
        return 'O'
    if c * (X + Y - 1) - eps > 0:
        return 'M'
    return 'S'

def box_region(eps, box, sx=F(1), sy=F(1)):
    (x0, x1), (y0, y1) = box
    lo = regionT1(eps, sx * x0, sy * y0)
    hi = regionT1(eps, sx * x1, sy * y1)
    if hi == 'O':
        return 'O'          # down-set: whole box O
    if lo == 'M':
        return 'M'          # up-set: whole box M
    if lo != 'O' and hi != 'M':
        return 'S'          # not O anywhere, not M anywhere
    return 'mixed'

lines = []
allok = True
EPS = [F(1, 10**4), F(1, 10**3), F(1, 100), F(1, 10), F(3, 10), F(1, 2), F(5, 8), F(7, 10), F(9, 10), F(999, 1000)]
for eps in EPS:
    c = (1 - eps) / 3
    A = 1 + eps / c
    d = (A - 1) / (8 * A)            # box half-width (X12 referee's choice)
    R = 2 + eps / c                  # E1 centre, deep in the A(=M) region
    t0 = 4 + 4 * eps / c + 1 / d
    for f1 in (1, 10, 10**6):
        for f2 in (1, 37, 10**5):
            t1, t2 = t0 * f1, t0 * f2
            Pi1 = (((1 - d) / t1, (1 + d) / t1), ((1 - d) / t1, (1 + d) / t1))
            Pi2 = ((1 - d, 1 + d), ((1 - d) / (t1 * t2), (1 + d) / (t1 * t2)))
            E1 = ((R - d, R + d), (R - d, R + d))
            q = (F(1), 1 / t2, t1)
            sx, sy = q[1] / q[0], q[2] / q[0]
            r = dict(T1_Pi1=box_region(eps, Pi1), T1_Pi2=box_region(eps, Pi2), T1_E1=box_region(eps, E1),
                     Cq_Pi1=box_region(eps, Pi1, sx, sy), Cq_Pi2=box_region(eps, Pi2, sx, sy))
            far2 = ((sx * Pi2[0][0], sx * Pi2[0][1]), (sy * Pi2[1][0], sy * Pi2[1][1])) == \
                   (((1 - d) / t2, (1 + d) / t2), ((1 - d) / t2, (1 + d) / t2))
            disj = Pi1[0][1] < Pi2[0][0] and Pi2[0][1] < E1[0][0]
            want = dict(T1_Pi1='O', T1_Pi2='S', T1_E1='M', Cq_Pi1='S', Cq_Pi2='O')
            comp = (('S', 'O') == (r['Cq_Pi1'], r['Cq_Pi2']))
            ok = (r == want) and far2 and disj and comp
            allok &= ok
            lines.append(f"eps={eps} t1=t0*{f1} t2=t0*{f2}: {r} far2={far2} disjoint={disj} composable={comp} -> {'OK' if ok else 'FAIL'}")
lines.append("ALL OK" if allok else "SOME FAIL")
lines.append("Composite record T1 -> T1[E1: M -> O]: world 0 is the odd world on Q_0, ranks O0 S1 M2, so the composite is a strict world-0 improvement.")
open('e3_far_swap.out', 'w').write("\n".join(lines) + "\n")
print("\n".join(lines[-3:]))
