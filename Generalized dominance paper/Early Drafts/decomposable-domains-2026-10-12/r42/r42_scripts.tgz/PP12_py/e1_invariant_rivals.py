"""PP12 e1: Theorem E (invariant rivals) on the class-constant models.

A G-invariant model is a.e. constant on each class Q_0,Q_1,Q_2 (mixed) and on U.
For such X, invariance makes every interior section {p in int Delta : C_p <=_i X}
empty or full; closedness then forces C_r <=_i X at every boundary r.  So world i
is excluded for X if X is a strict pointwise world-i improvement of some boundary
selected model C_r (strict half of (G)).

(1) Advice sets (positive measure) of the boundary models on each class, by exact
    sampling of random gambles.
(2) For each of the 4^4 = 256 class-constant models: worlds not excluded, under
    full invariance and under each type of one-parameter subgroup (limits r+, r-).
(3) Two-world analogue with the vacuous model D_Delta.
"""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import itertools, random
from fractions import Fraction as F
from pp12lib import *

eps = F(3, 10)
rng = random.Random(7)

def advice_sets(p, N=6000):
    sets = {c: set() for c in (0, 1, 2, 'U')}
    for _ in range(N):
        g = rand_gamble(rng)
        cls, h = orient(g)
        a = C_advice(eps, p, h)
        if cls == 'U':
            sets['U'].add({'A': 'C', 'B': 'W', 'S': 'S'}[a])
        else:
            sets[cls].add(rel_advice(a))
    return {k: frozenset(v) for k, v in sets.items()}

E = [tuple(F(int(i == j)) for j in range(3)) for i in range(3)]
bnd = {}
for k in range(3):
    bnd[('v', k)] = advice_sets(E[k])
for (a, b) in ((0, 1), (0, 2), (1, 2)):
    r = [F(0)] * 3; r[a] = F(2, 5); r[b] = F(3, 5)
    s1 = advice_sets(tuple(r))
    r = [F(0)] * 3; r[a] = F(9, 10); r[b] = F(1, 10)
    s2 = advice_sets(tuple(r))
    assert s1 == s2, (a, b)
    bnd[('e', a, b)] = s1
lines = ["(1) boundary advice sets (class: advices of positive measure):"]
for key, s in bnd.items():
    lines.append(f"   {key}: " + ", ".join(f"Q{c}:{''.join(sorted(s[c]))}" if c != 'U' else f"U:{''.join(sorted(s[c]))}" for c in (0, 1, 2, 'U')))

def strictly_better(i, X, S):
    """X class-constant (dict class->advice); S advice sets of a boundary model."""
    strict = False
    for c in (0, 1, 2, 'U'):
        rx = rank(i, c, X[c])
        for b in S[c]:
            rb = rank(i, c, b)
            if rx > rb:
                return False
            if rx < rb:
                strict = True
    return strict

def faces_of(theta):
    """limits of nu(exp(t theta) * q) as t -> +inf, -inf: index sets of argmax/argmin."""
    mx, mn = max(theta), min(theta)
    return tuple(i for i in range(3) if theta[i] == mx), tuple(i for i in range(3) if theta[i] == mn)

def bkey(face):
    return ('v', face[0]) if len(face) == 1 else ('e',) + tuple(sorted(face))

thetas = [(2, 1, 0), (2, 0, 1), (1, 2, 0), (0, 2, 1), (1, 0, 2), (0, 1, 2),
          (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 0, 0), (0, 1, 0), (0, 0, 1)]

models = []
for adv in itertools.product('MSOX', repeat=3):
    for u in 'CSWX':
        models.append({0: adv[0], 1: adv[1], 2: adv[2], 'U': u})

def name(X):
    return f"Q0:{X[0]} Q1:{X[1]} Q2:{X[2]} U:{X['U']}"

full_killers, sub_killers_all = [], []
per_theta_killers = {t: 0 for t in thetas}
for X in models:
    allowed = [i for i in range(3) if not any(strictly_better(i, X, S) for S in bnd.values())]
    if not allowed:
        full_killers.append(X)
    killed_all = True
    for th in thetas:
        fp, fm = faces_of(th)
        Sp, Sm = bnd[bkey(fp)], bnd[bkey(fm)]
        al = [i for i in range(3) if not (strictly_better(i, X, Sp) or strictly_better(i, X, Sm))]
        if not al:
            per_theta_killers[th] += 1
        else:
            killed_all = False
    if killed_all:
        sub_killers_all.append(X)

LAM = {0: 'M', 1: 'M', 2: 'M', 'U': 'C'}
lines.append(f"(2) class-constant models: {len(models)}")
lines.append(f"    full invariance: models X with every world excluded: {len(full_killers)}")
lines.append(f"    Lambda = {name(LAM)} among them: {LAM in full_killers}")
regular_killers = [X for X in full_killers if X['U'] == 'C' and 'X' not in (X[0], X[1], X[2])]
lines.append(f"    regular (no X, correct on U) killers: " + "; ".join(name(X) for X in regular_killers))
for th in thetas:
    fp, fm = faces_of(th)
    lines.append(f"    theta={th}: limits {bkey(fp)} / {bkey(fm)}: killers {per_theta_killers[th]}")
lines.append(f"    killers for EVERY one-parameter type: {len(sub_killers_all)}; Lambda among them: {LAM in sub_killers_all}")
lines.append("    worlds left for coherent class-constant rivals (full invariance):")
for nm, X in (("B^0", {0: 'O', 1: 'M', 2: 'M', 'U': 'C'}), ("edge01", {0: 'S', 1: 'S', 2: 'M', 'U': 'C'}),
              ("D_Delta", {0: 'S', 1: 'S', 2: 'S', 'U': 'C'})):
    allowed = [i for i in range(3) if not any(strictly_better(i, X, S) for S in bnd.values())]
    lines.append(f"      {nm}: {allowed}")

# (3) two worlds
def adv2(lo, hi, p, g):   # interval target [lo,hi] for m_1, rescaled by p; g=(g1,g2)
    verts = [(lo, 1 - lo), (hi, 1 - hi)]
    w = [tuple(x / dot(p, v) for x in had(p, v)) for v in verts]
    return advice_DK(w, g)
lo, hi = F(1, 3), F(2, 3)
sets2 = {}
for nm, p in (("e1", (F(1), F(0))), ("e2", (F(0), F(1)))):
    s = set()
    for _ in range(3000):
        g = (F(rng.randint(1, 999), 97), -F(rng.randint(1, 999), 97))   # mixed, g1>0>g2
        s.add(adv2(lo, hi, p, g))
    sets2[nm] = s
# ranks on the mixed class: world 1 (index 0): A0 S1 B2; world 2: B0 S1 A2
r2 = [{'A': 0, 'S': 1, 'B': 2}, {'B': 0, 'S': 1, 'A': 2}]
def sb2(i, a, S):
    return all(r2[i][a] <= r2[i][b] for b in S) and any(r2[i][a] < r2[i][b] for b in S)
lines.append("(3) two worlds, target [1/3,2/3]: vertex advice sets on the mixed class: " +
             ", ".join(f"{k}:{''.join(sorted(v))}" for k, v in sets2.items()))
lines.append("    D_Delta (silent on every mixed problem): world 1 excluded via e2: %s; world 2 excluded via e1: %s"
             % (sb2(0, 'S', sets2['e2']), sb2(1, 'S', sets2['e1'])))
open('e1_invariant_rivals.out', 'w').write("\n".join(lines) + "\n")
print("\n".join(lines))
