"""PP12 e0: Observation 1 (the family is one orbit), exactly.
Checks, with exact rationals, for eps in {3/10, 1/10}:
 (a) D_{M_p}(g) == T1(p*g) for interior, edge and vertex p      [C_p = T1 o S_p]
 (b) C_{nu(d*p)}(g) == C_p(d*g) for positive diagonal d           [equivariance]
 (c) edge model p=(p1,p2,0): 'M' on class 2 (third world), and on classes 0,1 a
     function of the single ratio h_1/|h_0| (resp. h_0/|h_1|): strip structure
 (d) vertex model p=e_k equals B^k = {h: h_k > 0}
 (e) convergence C_{p_n}(g) -> C_p(g) along p_n -> boundary point (eventual equality)
"""
import random
from fractions import Fraction as F
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pp12lib import *

rng = random.Random(20261021)
out = []
for eps in (F(3, 10), F(1, 10)):
    bad = {k: 0 for k in 'abcde'}
    tot = {k: 0 for k in 'abcde'}
    for _ in range(4000):
        g = rand_gamble(rng)
        for zero in ((), (2,), (0,), (1,), (1, 2), (0, 2), (0, 1)):
            p = rand_simplex(rng, zero=zero)
            tot['a'] += 1
            if C_advice(eps, p, g) != T1_advice(eps, had(p, g)):
                bad['a'] += 1
        p = rand_simplex(rng)
        d = tuple(F(rng.randint(1, 50), rng.randint(1, 50)) for _ in range(3))
        dp = had(d, p); s = sum(dp); dp = tuple(x / s for x in dp)
        tot['b'] += 1
        if C_advice(eps, dp, g) != C_advice(eps, p, had(d, g)):
            bad['b'] += 1
        # (c) edge model on the edge {p_3 = 0} (0-based index 2)
        pe = rand_simplex(rng, zero=(2,))
        cls, h = orient(g)
        if cls != 'U':
            tot['c'] += 1
            a = rel_advice(C_advice(eps, pe, h))
            if cls == 2:
                ok = (a == 'M')
            else:
                # rescale the third coordinate arbitrarily: advice must not change
                h2 = (h[0], h[1], h[2] * F(rng.randint(1, 1000), rng.randint(1, 1000)))
                ok = (a == rel_advice(C_advice(eps, pe, h2)))
            if not ok:
                bad['c'] += 1
        # (d) vertex
        k = rng.randrange(3)
        pv = tuple(F(1) if j == k else F(0) for j in range(3))
        tot['d'] += 1
        if C_advice(eps, pv, g) != ('A' if g[k] > 0 else 'B'):
            bad['d'] += 1
        # (e) convergence along p_n = nu(p1, p2, 1/n)
        tot['e'] += 1
        target = C_advice(eps, pe, g)
        seq = []
        for n in (10, 10**3, 10**6, 10**9, 10**12):
            q = (pe[0], pe[1], F(1, n)); s = sum(q); q = tuple(x / s for x in q)
            seq.append(C_advice(eps, q, g))
        if seq[-1] != target:
            bad['e'] += 1
    out.append(f"eps={eps}: " + ", ".join(f"({k}) {tot[k]-bad[k]}/{tot[k]} agree" for k in 'abcde'))
open('e0_orbit.out', 'w').write("\n".join(out) + "\n")
print("\n".join(out))
