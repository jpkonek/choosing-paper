"""PP12 e2: Theorem J's hypothesis (ii) fails for the rescaled family.

Lemma P (projection): for interior a and a problem of class 0 or 1, the advice of
C_a is weakly M-ward of the advice of the edge model C_{pi(a)}, pi(a) = (a0,a1,0)/norm.
(So C_r strictly M-ward of C_a forces C_r strictly M-ward of C_{pi(a)}.)
Lemma Q (edge monotonicity): along the edge {p_2 = 0}, edge-model advice on class 0
is M-ward-monotone in r1/r0, and on class 1 M-ward-monotone in r0/r1.
Corollary: no edge model C_r (r in the open edge 01) is strictly M-ward of an interior
C_a on non-null parts of BOTH class 0 and class 1; in particular Lemma J0 has no
instance (C_a silent, C_r saying M on both classes).
Sanity: for the homothetic family K_p = p + 3 eps min(p) (Delta - u), J0 instances
are found (as PP11 reports).
"""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import random
from fractions import Fraction as F
from pp12lib import *

POS = {'O': 0, 'S': 1, 'M': 2}
rng = random.Random(11)
lines = []

def pos_resc(eps, p, h):
    return POS[rel_advice(C_advice(eps, p, h))]

def homo_vertices(eps, p):
    m = min(p)
    return [tuple(p[j] + 3 * eps * m * ((1 if j == i else 0) - F(1, 3)) for j in range(3)) for i in range(3)]

def pos_homo(eps, p, h):
    return POS[rel_advice(advice_DK(homo_vertices(eps, p), h))]

def rand_class(rng, c):
    while True:
        g = rand_gamble(rng)
        cls, h = orient(g)
        if cls == c:
            return h

for eps in (F(3, 10), F(1, 10), F(1, 100)):
    nP = badP = 0
    nQ = badQ = 0
    for _ in range(3000):
        a = rand_simplex(rng)
        pa = (a[0], a[1], F(0)); s = sum(pa); pa = tuple(x / s for x in pa)
        for c in (0, 1):
            h = rand_class(rng, c)
            nP += 1
            if pos_resc(eps, a, h) < pos_resc(eps, pa, h):
                badP += 1
        r = rand_simplex(rng, zero=(2,)); r2 = rand_simplex(rng, zero=(2,))
        for c in (0, 1):
            h = rand_class(rng, c)
            nQ += 1
            ratio = (lambda q: q[1] / q[0]) if c == 0 else (lambda q: q[0] / q[1])
            lo, hi = (r, r2) if ratio(r) <= ratio(r2) else (r2, r)
            if pos_resc(eps, lo, h) > pos_resc(eps, hi, h):
                badQ += 1
    # J0 search, rescaled vs homothetic
    hitsR = hitsR_strict = hitsH = trials = 0
    for _ in range(20000):
        a = rand_simplex(rng)
        r = rand_simplex(rng, zero=(2,))
        h0 = rand_class(rng, 0); h1 = rand_class(rng, 1)
        trials += 1
        # rescaled: C_r strictly M-ward of C_a on both classes?
        if pos_resc(eps, r, h0) > pos_resc(eps, a, h0) and pos_resc(eps, r, h1) > pos_resc(eps, a, h1):
            hitsR_strict += 1
        if (pos_resc(eps, a, h0) == 1 and pos_resc(eps, a, h1) == 1 and
                pos_resc(eps, r, h0) == 2 and pos_resc(eps, r, h1) == 2):
            hitsR += 1
        if (pos_homo(eps, a, h0) == 1 and pos_homo(eps, a, h1) == 1 and
                pos_homo(eps, r, h0) == 2 and pos_homo(eps, r, h1) == 2):
            hitsH += 1
    lines.append(f"eps={eps}: Lemma P violations {badP}/{nP}; Lemma Q violations {badQ}/{nQ}; "
                 f"J0 search {trials} draws: rescaled J0 hits {hitsR}, rescaled 'strictly M-ward on both' {hitsR_strict}, "
                 f"homothetic J0 hits {hitsH}")
open('e2_J0_rescaled.out', 'w').write("\n".join(lines) + "\n")
print("\n".join(lines))
