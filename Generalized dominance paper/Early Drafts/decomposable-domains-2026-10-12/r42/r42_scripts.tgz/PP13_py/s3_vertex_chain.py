"""Step 3: a second certified (TC) violation, from VERTEX repair indices
(far repairs, whole-class disagreement sets).  Worlds k=1, l=2, m=3.
   X1 = I_2 on classes M_1, M_2;  on M_3: A except silence on a cone W1.
   X2 = on M_2: A;  on M_1: S;  on M_3: A except silence on a cone W2.
   d1 = rec(I_1, X1)  (repair from the vertex e_1),  d2 = rec(I_2, X2) (from e_2).
   X1 agrees with I_2 on D2 = {X2 != I_2}, so a copy of d2 applies in context X1:
   I_1 <=_3 X1 <=_3 U'',  U'' = I_1 except S on M_1 u W1 u W2, a strict world-3
   improvement of I_1.  Both repair pairs are certified (a)+(b) exactly.
Run: python3 -u -I -B s3_vertex_chain.py
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from s2_instances import *

e1, e2 = [F(1), F(0), F(0)], [F(0), F(1), F(0)]
def cls(g):
    pos = [x > 0 for x in g]
    if pos.count(True) == 1: return pos.index(True)
    if pos.count(True) == 2: return pos.index(False)
    return None
w1c = [F(-1, 3), F(-1, 3), F(1)]; w2c = [F(-1, 5), F(-3, 5), F(1)]     # class M_3 lines
W1 = cone_gens(w1c, F(1, 100)); W2 = cone_gens(w2c, F(1, 100))
def inW(g, W): return in_cone(g, W) or in_cone([-x for x in g], W)
def X1(g):
    k = cls(g)
    if k is None: return advice_strict(P, e1, g)                # unanimous: correct
    if k in (0, 1): return advice_strict(P, e2, g)
    return ('S', True) if inW(g, W1) else advice_strict(P, e1, g)   # I_1 = I_2 = A on M_3
def X2(g):
    k = cls(g)
    if k is None: return advice_strict(P, e1, g)
    if k == 1: return advice_strict(P, e1, g)                   # A on M_2 (= I_1)
    if k == 0: return ('S', True)
    return ('S', True) if inW(g, W2) else advice_strict(P, e2, g)
ok = True
ex = lines_in_cone(W1) + lines_in_cone(W2)
ga, gb = [F(1), F(-1, 10), F(-1, 10)], [F(1), F(-10), F(-10)]     # two far-apart class-1 lines
for name, X, p in [("d1 = rec(I_1, X1)", X1, e1), ("d2 = rec(I_2, X2)", X2, e2)]:
    res = certificate(X, p, Pool(X, ex))
    if res is None and X is X2:
        # (a) as computed by certificate(); exposure by an explicit two-line witness:
        # X2 is silent on all of M_1, I_2 says A there; no family member is silent on both lines
        pool = Pool(X, ex + [ga, gb]); Cp = fam(p)
        adv, rob = pool.fam_float(p)
        worse = [None] * 3
        for n, g in enumerate(pool.L):
            ax, sx = pool.xa[n]; ac, sc = Cp(g)
            for i in range(3):
                if worse[i] is None and sx and sc and rank(ax, g, i) > rank(ac, g, i): worse[i] = g
        Wt = [(ga, 'S'), (gb, 'S')]
        okW = all(X(g)[0] == 'S' and X(g)[1] and Cp(g) == ('N', True) for g, _ in Wt)
        if all(w is not None for w in worse) and okW and not closed_feasible(P, Wt)[0]:
            res = (worse, Wt)
    print(f"{name}: (a)+(b) certified exactly: {res is not None}")
    if res:
        worse, W = res
        for g, a in W: print(f"     exposure line g={[str(x) for x in g]}: X says {a}")
    ok &= res is not None
# context check and composite on all pool lines (exact)
bad = 0; strict = False
for g in BASE + ex:
    if cls(g) is None: continue
    a1, _ = X1(g); a2, _ = X2(g); i2, _ = advice_strict(P, e2, g); i1, _ = advice_strict(P, e1, g)
    if a2 != i2 and a1 != i2: bad += 1          # X1 must equal I_2 on D2
    U2 = a2 if a2 != i2 else a1
    d = rank(U2, g, 2) - rank(i1, g, 2)
    if d > 0: bad += 1
    if d < 0: strict = True
print(f"context X1 = I_2 on D2 and composite I_1 -> U'' never worse at world 3: {bad == 0}; strictly better somewhere: {strict}")
ok &= bad == 0 and strict
print("ALL CHECKS PASSED" if ok else "SOME CHECK FAILED")
