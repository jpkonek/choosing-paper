"""Step 2, further classes (eps = 3/10): rescaled analogues of PP8's doubly
anchored rival and of PP11's Theorem-J rival, an edge-majority rival, and the
overlapping-hull coherent rival.  Also the exact check behind the splice
monotonicity lemma (PP13 section 2.4).  Run: python3 -u -I -B s2_more.py
"""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from s2_instances import *

random.seed(7)
Mq = lambda q: posterior_vertices(P, q)
vtx_lines = lambda pts: [l for x in pts for l in lines_through(x, n=80, shifts=(F(1,20000),F(-1,20000),F(1,2000),F(-1,2000)))]

# --- splice monotonicity: C_q is somewhere more majority-ward than C_a on class k
#     iff r_k < max_{i!=k} r_i  (r = q/a); check exactly on random lines
def more_A_somewhere(a, q, k, lines):
    order = {'P': 0, 'S': 1, 'N': 2}       # class-k representative: P = minority, N = majority
    for g in lines:
        gg = class_rep(g, k)
        if gg is None: continue
        aa, sa = advice_strict(P, a, gg); qa, sq = advice_strict(P, q, gg)
        if sa and sq and order[qa] > order[aa]: return True
    return False
viol = 0; tests = 0
for _ in range(60):
    a = normalise([random.randint(1, 30) for _ in range(3)])
    q = normalise([random.randint(0, 30) if j == 2 and random.random() < .3 else random.randint(1, 30) for j in range(3)])
    r = [q[j] / a[j] for j in range(3)]
    for k in range(3):
        pred = r[k] < max(r[j] for j in range(3) if j != k)
        obs = more_A_somewhere(a, q, k, BASE)
        tests += 1
        if obs and not pred: viol += 1          # the lemma's 'only if' direction is exact
print(f"splice monotonicity, 'only if' direction: {tests} (a,q,class) tests, {viol} counterexamples")

# --- Theorem-J configuration: an edge model r in D_12 saying A on a class-1 AND a
#     class-2 line where an interior C_a is silent.  Exhaustive random search:
hits = 0
for _ in range(300):
    a = normalise([random.randint(1, 30) for _ in range(3)])
    r = normalise([random.randint(1, 30), random.randint(1, 30), 0])
    ok = []
    for k in (0, 1):
        found = False
        for g in BASE:
            gg = class_rep(g, k)
            if gg is None: continue
            if advice_strict(P, a, gg) == ('S', True) and advice_strict(P, r, gg) == ('N', True):
                found = True; break
        ok.append(found)
    hits += all(ok)
print(f"Theorem-J configuration (edge model says A on classes 1 and 2 where C_a is silent): {hits} of 300 random (a, r)")

a = normalise([50, 30, 20])
# --- two-class doubly anchored rival: q with r_3 = max, A on class-1 and class-2 cones
q = normalise([F(49), F(29), F(22)])
cs = [find_cone([(a, 'S'), (q, 'N')], k) for k in (0, 1)]
print("two-class pump cones found:", [c is not None for c in cs])
if all(cs):
    Y2 = patch(a, [(G, 'N') for G in cs])
    # Y2 is a strict pointwise world-3 improvement of C_a (A on classes 1,2 is world-3 correct)
    print("   Y2 = C_a + A on S_1 (class 1) and S_2 (class 2), both where C_q says A: Y2 in Betw(C_a, C_q);")
    print("   Y2 strictly improves C_a at world 3 pointwise, so a is NOT an (a)-index; nor is the splice partner q exposed.")
    search("two-class doubly anchored rival Y2", Y2, CANDS, [l for G in cs for l in lines_in_cone(G)] + vtx_lines(Mq(a)))
# --- edge-majority rival: C_r (r on D_12) + A on a class-1 cone where C_r is silent
r = normalise([3, 2, 0])
G1 = find_cone([(r, 'S')], 0)
search("edge-majority rival: C_r + A on a class-1 cone where C_r is silent", patch(r, [(G1, 'N')]), CANDS,
       lines_in_cone(G1) + vtx_lines(Mq(r)))
# --- overlapping hull
p1, p2 = normalise([34, 33, 33]), normalise([33, 34, 33])
Kh = Mq(p1) + Mq(p2)
search("coherent: D_K, K = conv(M_p1 u M_p2), overlapping (X is a C_p1/C_p2 splice)", coherent(Kh), CANDS,
       vtx_lines(Kh))
