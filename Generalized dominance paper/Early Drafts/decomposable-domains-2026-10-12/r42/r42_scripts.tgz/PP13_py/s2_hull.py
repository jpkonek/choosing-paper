"""Step 2: exact certificate for the overlapping-hull coherent rival
X = D_K, K = conv(M_p1 u M_p2) (X is a C_p1/C_p2 splice, so p1 and p2 are not
exposed).  Exposure at a near-vertex index is certified by an exact cutting-plane
loop: solve the closed family system on the current witness set W exactly; if a
family index q survives, add a line of D on which C_q violates X's closed
condition; repeat until the closed system is infeasible.
Run: python3 -u -I -B s2_hull.py
"""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from s2_instances import *

def violates(q, g, a):
    f = phis(P, q, g)
    if a == 'P': return min(f) < 0
    if a == 'N': return max(f) > 0
    return min(f) > 0 or max(f) < 0

def cutting_plane_certificate(X, p, extra, maxit=200):
    pool = Pool(X, extra); Cp = fam(p)
    adv, rob = pool.fam_float(p)
    worse = [None] * 3; D = []
    for n, g in enumerate(pool.L):
        ax, sx = pool.xa[n]
        if not (sx and rob[n]): continue
        ac, sc = Cp(g)
        if not sc: continue
        if ax != ac: D.append((g, ax))
        for i in range(3):
            if worse[i] is None and rank(ax, g, i) > rank(ac, g, i): worse[i] = g
    if any(w is None for w in worse): return None
    W = []
    for it in range(maxit):
        feas, q, _ = closed_feasible(P, W)
        if not feas: return worse, W
        cand = [(g, a) for g, a in D if a != 'S' and violates(q, g, a)]
        if not cand:
            if sum(1 for _, a in W if a == 'S') >= 4: return None     # keep the exact branch count small
            cand = [(g, a) for g, a in D if a == 'S' and violates(q, g, a)]
        if not cand: return None           # q agrees with X on all of the pool's D
        W.append(cand[0])
    return None

p1, p2 = normalise([40, 30, 30]), normalise([30, 40, 30])
Kh = posterior_vertices(P, p1) + posterior_vertices(P, p2)
random.seed(3)
ex = [l for x in Kh for l in lines_through(x, n=80, shifts=(F(1, 20000), F(-1, 20000), F(1, 2000), F(-1, 2000)))]
X = coherent(Kh)
for p in near_vertices()[:21]:
    print('trying', [str(x) for x in p], flush=True)
    res = cutting_plane_certificate(X, p, ex)
    if res:
        worse, W = res
        print(f"[coherent hull rival D_conv(M_p1 u M_p2), p1={[str(x) for x in p1]}, p2={[str(x) for x in p2]}]")
        print(f"   repair index p = {[str(x) for x in p]} : (a) and (b) CERTIFIED (exact)")
        for i, g in enumerate(worse): print(f"     (a) world {i+1}: X worse than C_p at g = {[str(x) for x in g]}")
        print(f"     (b) {len(W)} lines of D, closed family system infeasible (exact):")
        for g, a in W: print(f"         g = {[str(x) for x in g]} : X says {a}, C_p says {fam(p)(g)[0]}")
        break
else:
    print("no certificate found")
