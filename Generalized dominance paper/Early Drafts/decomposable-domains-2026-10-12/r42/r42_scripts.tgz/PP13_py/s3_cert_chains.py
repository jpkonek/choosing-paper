"""Step 3, certificate-involving chains.  A forbidden triangle with a strict
guidance closing link needs two non-guidance links whose composite is a strict
pointwise improvement (PP13 section 3.3).  With a certificate record
c_k = rec(C_{p_k}, Y_k) as one link and a repair d as the other (either order),
the old side of d must contain: 'not accept g' on every E_{j,k} (j != k) and
'accept g' on a non-null part of S_k (proof in PP13 section 3.3).  With the
E_{j,k} chosen measure-dense in S_j this forces, for the family member C_q
realising the old side, the CLOSED conditions
     min_m phi_m(q, g_j) <= 0  (j != k),   min_m phi_m(q, g_k') >= 0
at the central line g_j of S_j and some line g_k' of S_k.  We test this closed
system exactly at g_k' = g_k (and on a ring of nearby lines of S_k).
Run: python3 -I -B s3_cert_chains.py
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from pp13core import *
from s1_certificate import build

def notB_options(g):
    return [[(g, 'S')], [(g, 'N')]]

for eps, slopes in [(F(3,10), [F(-11,4), F(-7,2), F(-19,4)]), (F(1,10), [F(-7,4), F(-9,4), F(-11,4)])]:
    P, ps, gs, vs, zs = build(eps, slopes, F(1,4000))
    print(f"eps = {eps}")
    for k in range(4):
        others = [j for j in range(4) if j != k]
        found = None
        import itertools
        for choice in itertools.product(*[notB_options(gs[j]) for j in others]):
            pat = [x for c in choice for x in c] + [(gs[k], 'P')]
            feas, q, _ = closed_feasible(P, pat)
            if feas: found = (q, [c[0][1] for c in choice]); break
        print(f"  k={k}: exists C_q with not-B on S_j (j!={k}) and B on S_{k}?",
              "YES q="+str([str(x) for x in found[0]])+" with "+str(found[1]) if found else "NO (exact)")
