"""PP13 core: exact rational primitives for the rescaled contamination family.

Family: M = c*1 + eps*Delta, vertices m_k = c*1 + eps*e_k.  For index q in the
closed simplex, C_q = D_{M_q}, M_q = {q*m/(q.m)}.  For a problem g,
    phi_k(q,g) = sum_j m_kj q_j g_j      (k = 0,1,2)
C_q accepts g ('P') iff min_k phi_k > 0, accepts -g ('N') iff max_k phi_k < 0,
and is silent ('S') otherwise.  (Boundary q are the limits; the same formula
gives them because phi is linear in q.)

Ranks at world i (0-based): accept g is good iff g_i > 0.
All arithmetic is fractions.Fraction.
"""
from fractions import Fraction as F
import itertools

def setup(eps):
    eps = F(eps)
    c = (1 - eps) / 3
    m = [[c + (eps if j == k else 0) for j in range(3)] for k in range(3)]
    return dict(eps=eps, c=c, kap=eps / c, m=m)

def phis(P, q, g):
    return [sum(P['m'][k][j] * q[j] * g[j] for j in range(3)) for k in range(3)]

def advice(P, q, g):
    """exact advice and whether it is strict (open condition)."""
    f = phis(P, q, g)
    if min(f) > 0: return 'P'
    if max(f) < 0: return 'N'
    return 'S'

def advice_strict(P, q, g):
    f = phis(P, q, g)
    if min(f) > 0: return 'P', True
    if max(f) < 0: return 'N', True
    strict = (min(f) < 0 < max(f))
    return 'S', strict

def rank(adv, g, i):
    if adv == 'S': return 1
    if adv == 'C': return 3
    good = (g[i] > 0) if adv == 'P' else (g[i] < 0)
    return 0 if good else 2

def posterior_vertices(P, q):
    out = []
    for k in range(3):
        w = [q[j] * P['m'][k][j] for j in range(3)]
        s = sum(w)
        out.append([x / s for x in w])
    return out

def lower_upper(P, q, g):
    vs = posterior_vertices(P, q)
    vals = [sum(v[j] * g[j] for j in range(3)) for v in vs]
    return min(vals), max(vals)

def normalise(v):
    s = sum(v)
    return [F(x) / s for x in v]

# ---------------------------------------------------------------- cones
def cone_gens(g, d):
    """simplicial cone of problems around g=(g0,g1,g2): three generators
    whose average is g (so g is interior)."""
    d = F(d)
    g = [F(x) for x in g]
    return [[g[0], g[1] * (1 + d), g[2]],
            [g[0], g[1], g[2] * (1 + d)],
            [g[0], g[1] * (1 - d), g[2] * (1 - d)]]

def cone_advice(P, q, gens):
    """advice of C_q certified on the whole (closed) cone, or None.
    P/N: every phi_k positive/negative at every generator (linear in g).
    S: some phi_k <0 at all generators and some phi_k' >0 at all generators."""
    F_ = [phis(P, q, g) for g in gens]
    if all(min(f) > 0 for f in F_): return 'P'
    if all(max(f) < 0 for f in F_): return 'N'
    neg = any(all(f[k] < 0 for f in F_) for k in range(3))
    pos = any(all(f[k] > 0 for f in F_) for k in range(3))
    if neg and pos: return 'S'
    return None

# ------------------------------------------------- exact 2D feasibility
def _feasible_halfplanes(rows):
    """rows: list of (a0,a1,a2) meaning a.q >= 0 on q in closed simplex.
    Returns a feasible q (exact) or None.  Vertex enumeration in the plane
    sum q = 1."""
    base = [(F(1), F(0), F(0)), (F(0), F(1), F(0)), (F(0), F(0), F(1))]
    allr = base + [tuple(F(x) for x in r) for r in rows]
    def ok(q):
        return all(sum(r[j] * q[j] for j in range(3)) >= 0 for r in allr)
    n = len(allr)
    for i in range(n):
        for j in range(i + 1, n):
            # solve r_i.q = 0, r_j.q = 0, sum q = 1
            A = [list(allr[i]), list(allr[j]), [F(1), F(1), F(1)]]
            b = [F(0), F(0), F(1)]
            q = solve3(A, b)
            if q is not None and ok(q):
                return q
    return None

def solve3(A, b):
    A = [row[:] + [bb] for row, bb in zip(A, b)]
    for col in range(3):
        piv = None
        for r in range(col, 3):
            if A[r][col] != 0: piv = r; break
        if piv is None: return None
        A[col], A[piv] = A[piv], A[col]
        for r in range(3):
            if r != col and A[r][col] != 0:
                fac = A[r][col] / A[col][col]
                A[r] = [x - fac * y for x, y in zip(A[r], A[col])]
    return [A[r][3] / A[r][r] for r in range(3)]

def closed_feasible(P, pattern):
    """pattern: list of (g, adv) with adv in P/N/S.  Is there q in the closed
    simplex with the CLOSED version of every condition?  P: phi_k>=0 all k;
    N: phi_k<=0 all k; S: exists k phi_k<=0 and exists k' phi_k'>=0.
    Returns (True, q, branch) or (False, None, None).  Exact."""
    lin, sil = [], []
    for g, a in pattern:
        rows = [[P['m'][k][j] * g[j] for j in range(3)] for k in range(3)]
        if a == 'P': lin += rows
        elif a == 'N': lin += [[-x for x in r] for r in rows]
        elif a == 'S': sil.append(rows)
        else: raise ValueError(a)
    for choice in itertools.product(range(3), range(3), repeat=len(sil)) if False else _choices(len(sil)):
        rows = list(lin)
        for (k, kp), r3 in zip(choice, sil):
            rows.append([-x for x in r3[k]])   # phi_k <= 0
            rows.append(list(r3[kp]))          # phi_k' >= 0
        q = _feasible_halfplanes(rows)
        if q is not None:
            return True, q, choice
    return False, None, None

def _choices(n):
    pairs = [(k, kp) for k in range(3) for kp in range(3) if k != kp]
    return itertools.product(pairs, repeat=n)

def is_mixed_class(g):
    s = [x > 0 for x in g]
    return (any(s) and not all(s)) and all(x != 0 for x in g)

def strict_feasible(P, pattern, eta=F(1, 10**6)):
    """like closed_feasible but with margin eta (homogeneous: a.q >= eta*sum q,
    and q_i >= eta): returns q satisfying the STRICT conditions, or None."""
    lin, sil = [], []
    for g, a in pattern:
        rows = [[P['m'][k][j] * g[j] for j in range(3)] for k in range(3)]
        if a == 'P': lin += rows
        elif a == 'N': lin += [[-x for x in r] for r in rows]
        else: sil.append(rows)
    def shift(r):  # r.q >= eta*(q1+q2+q3)
        return [x - eta for x in r]
    for choice in _choices(len(sil)):
        rows = [shift(r) for r in lin]
        for (k, kp), r3 in zip(choice, sil):
            rows.append(shift([-x for x in r3[k]]))
            rows.append(shift(list(r3[kp])))
        rows += [[1 - eta, -eta, -eta], [-eta, 1 - eta, -eta], [-eta, -eta, 1 - eta]]
        q = _feasible_halfplanes(rows)
        if q is not None:
            return q
    return None

def lp_witness(P, pattern):
    """float LP (scipy) maximising a common margin; returns (margin, q rational
    approximation) for the best branch.  Used only to FIND witnesses; every
    witness is re-verified exactly by the caller."""
    import numpy as np
    from scipy.optimize import linprog
    lin, sil = [], []
    for g, a in pattern:
        rows = [[float(P['m'][k][j] * g[j]) for j in range(3)] for k in range(3)]
        if a == 'P': lin += rows
        elif a == 'N': lin += [[-x for x in r] for r in rows]
        else: sil.append(rows)
    best = (-1, None)
    for choice in _choices(len(sil)):
        rows = [r[:] for r in lin]
        for (k, kp), r3 in zip(choice, sil):
            rows.append([-x for x in r3[k]]); rows.append(r3[kp][:])
        # normalise rows, variables q1,q2,q3,t ; maximise t s.t. r.q/|r| >= t, q>=t, sum q = 1
        A, b = [], []
        for r in rows:
            n = sum(x * x for x in r) ** 0.5 or 1.0
            A.append([-x / n for x in r] + [1.0]); b.append(0.0)
        for i in range(3):
            e = [0.0, 0.0, 0.0, 1.0]; e[i] = -1.0; A.append(e); b.append(0.0)
        res = linprog([0, 0, 0, -1], A_ub=A, b_ub=b, A_eq=[[1, 1, 1, 0]], b_eq=[1],
                      bounds=[(0, 1)] * 3 + [(None, 1)], method='highs')
        if res.status == 0 and -res.fun > best[0]:
            best = (-res.fun, [F(x).limit_denominator(10**9) for x in res.x[:3]])
    if best[1] is not None:
        q = best[1]; s = sum(q); best = (best[0], [x / s for x in q])
    return best
