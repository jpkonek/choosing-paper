# helper (exploratory): choose circle slopes giving large certificate margins
import os, sys, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from s1_certificate import build
from pp13core import lower_upper
def margin(eps, slopes):
    try:
        P, ps, gs, vs, zs = build(eps, slopes, F(1,100))
    except AssertionError:
        return -1
    m = 1e9
    for j,p in enumerate(ps):
        for l,g in enumerate(gs):
            lo, up = lower_upper(P, p, g)
            m = min(m, float(-lo) if l==j else float(lo))
    return m
for eps, cand in [(F(3,10), [F(-n,4) for n in range(10,80)]), (F(1,10), [F(-n,4) for n in range(6,40)])]:
    best = None
    for s in itertools.combinations(cand, 3):
        mg = margin(eps, list(s))
        if best is None or mg > best[0]: best = (mg, s)
    print(eps, best[0], [str(x) for x in best[1]])
