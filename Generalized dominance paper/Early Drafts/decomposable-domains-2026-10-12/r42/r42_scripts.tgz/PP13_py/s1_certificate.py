"""Step 1: the four-model non-additivity certificate inside the rescaled family.

Construction (PP13 section 1).  World-1-minority problems g = (1,-x,-y), x,y>0.
With a = p2/p1, b = p3/p1, kappa = eps/c:
   C_p accepts g  iff  F_p(x,y) := max(v_p.(x,y), w_p.(x,y)) < 1,
   v_p = ((1+kappa)a, b),  w_p = (a, (1+kappa)b);
   C_p accepts -g iff  a x + b y > 1 + kappa.
p_0 = u gives v_0 = (1+kappa, 1).  p_1..p_3 are chosen with v_j on the circle
|v| = |v_0| and b_j < a_j (then |w_j| < |v_0|): each v_j is then the unique
maximiser of z -> max over all eight vectors at z = v_j, so z_j = t_j v_j with
t_j |v_0|^2 slightly above 1 gives the certificate.
Everything below is exact (fractions).  Run: python3 -I -B s1_certificate.py
"""
from fractions import Fraction as F
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pp13core import *

def rational_circle_point(x0, y0, mslope):
    # second intersection of the circle x^2+y^2 = x0^2+y0^2 with the line
    # through (x0,y0) of direction (1, m); for m < -x0/y0 the second point lies
    # clockwise from (x0,y0) (larger x, smaller y)
    d = (F(1), F(mslope))
    t = -2 * (x0 * d[0] + y0 * d[1]) / (d[0] ** 2 + d[1] ** 2)
    return (x0 + t * d[0], y0 + t * d[1])

def build(eps, slopes, delta):
    P = setup(eps)
    k1 = 1 + P['kap']
    v0 = (k1, F(1))
    R2 = v0[0] ** 2 + v0[1] ** 2
    idx = [(F(1), F(1), F(1))]            # (1,a,b) for p0 = u
    vs = [v0]
    for m in slopes:
        x, y = rational_circle_point(v0[0], v0[1], m)
        assert x > 0 and y > 0 and x * x + y * y == R2
        a, b = x / k1, y
        assert b < a, "need b<a so that |w|<|v|"
        idx.append((F(1), a, b)); vs.append((x, y))
    ps = [normalise(list(t)) for t in idx]
    # vectors
    def vw(t):
        _, a, b = t
        return ((k1 * a, b), (a, k1 * b))
    allvec = [vw(t) for t in idx]
    zs = []
    for j, vj in enumerate(vs):
        Mj = max(max(u[0] * vj[0] + u[1] * vj[1] for u in allvec[k])
                 for k in range(4) if k != j)
        wj = allvec[j][1]
        assert wj[0] * vj[0] + wj[1] * vj[1] < R2 and Mj < R2
        # t with t*R2 > 1 > t*Mj ; take t = 2/(R2+Mj)
        t = 2 / (R2 + Mj)
        zs.append((t * vj[0], t * vj[1]))
    gs = [[F(1), -z[0], -z[1]] for z in zs]
    return P, ps, gs, vs, zs

def report(eps, slopes, delta):
    P, ps, gs, vs, zs = build(eps, slopes, delta)
    print(f"=== eps = {eps}, c = {P['c']}, kappa = {P['kap']}")
    for j, p in enumerate(ps):
        print(f" p_{j} = {tuple(str(x) for x in p)}")
    for j, g in enumerate(gs):
        print(f" g_{j} = {tuple(str(x) for x in g)}   (class: world-1 minority)")
    print(" lower/upper expectations, row C_{p_j}, column g_l:")
    ok = True
    for j, p in enumerate(ps):
        row = []
        for l, g in enumerate(gs):
            lo, up = lower_upper(P, p, g)
            row.append(f"({float(lo):+.5f},{float(up):+.5f})")
            if l == j: ok &= (lo < 0 < up)
            else: ok &= (lo > 0)
        print("  C_%d: " % j + " ".join(row))
    print(" diagonal silent, off-diagonal accept g (world-1 correct):", ok)
    # cones
    cones = [cone_gens(g, delta) for g in gs]
    okc = True
    for j, p in enumerate(ps):
        for l, G in enumerate(cones):
            a = cone_advice(P, p, G)
            want = 'S' if l == j else 'P'
            okc &= (a == want)
    print(f" cone version (aperture delta={delta}): C_pj silent on all of B_j and"
          f" accepts g on all of B_l (l!=j), verified at generators:", okc)
    # disjointness of the cones: separate in the (x,y)-chart by a box test
    boxes = []
    for G in cones:
        xs = [-gg[1] / gg[0] for gg in G]; ys = [-gg[2] / gg[0] for gg in G]
        boxes.append((min(xs), max(xs), min(ys), max(ys)))
    disj = all(b1[1] < b2[0] or b2[1] < b1[0] or b1[3] < b2[2] or b2[3] < b1[2]
               for i, b1 in enumerate(boxes) for b2 in boxes[i + 1:])
    print(" cones pairwise disjoint (bounding boxes in the chart g=(1,-x,-y)):", disj)
    # silence also needs the upper condition: a x + b y <= 1+kappa  (automatic,
    # but checked):
    for j, (p, z) in enumerate(zip(ps, zs)):
        a, b = p[1] / p[0], p[2] / p[0]
        assert a * z[0] + b * z[1] < 1 + P['kap']
    return P, ps, gs, cones, ok and okc and disj

def audit_section6(nk=4):
    """Rebuild audit's four world-1 defences out of C_{p_k}.  Only the
    combinatorics of the records matters (audit's ranking reads cell integrals).
    Cell measures: S_j has mass s=4 (units), E_{j,k} mass 1, one unused quarter.
    Returns the world-1 cell integrals and the additive contradiction."""
    s = F(4)
    out = []
    for k in range(nk):
        # rec(C_k, Y_k): world-1 rank change: S_k: S(1)->B(0) : -1 on mass s
        #                E_{j,k} (j!=k): B(0)->S(1) : +1 on mass s/4
        integ = {j: (-s if j == k else s / 4) for j in range(nk)}
        Dmass = s + (nk - 1) * s / 4
        eta0 = F(1, 8)
        acc1 = (sum(1 for j in integ if integ[j] >= eta0 * Dmass) >= 3)
        # worlds 2,3: increments reversed on M_1 regular advice
        neg23 = sum(1 for j in integ if -integ[j] < 0)
        out.append((k, integ, Dmass, acc1, neg23))
    # additive contradiction: nu>0 on the world-1 good/silence step;
    # sum_k [ sum_{j!=k} nu(E_{j,k}) - nu(S_k) ] = - sum_j nu(unused quarter of S_j)
    return out

if __name__ == "__main__":
    allok = True
    # slopes chosen by s1_search.py (largest min margin on a 1/4-grid)
    for eps, slopes, delta in [(F(3, 10), [F(-11, 4), F(-7, 2), F(-19, 4)], F(1, 4000)),
                               (F(1, 10), [F(-7, 4), F(-9, 4), F(-11, 4)], F(1, 4000))]:
        P, ps, gs, cones, ok = report(eps, slopes, delta)
        allok &= ok
    print()
    print("audit section 6 rebuilt with sources C_{p_0..p_3} (p_0 = u):")
    for k, integ, Dm, acc1, neg23 in audit_section6():
        print(f"  rec(C_p{k},Y_{k}): world-1 P0-cell integrals {[str(integ[j]) for j in range(4)]},"
              f" mu(D)={Dm}; accepted at world 1 (clause 2, level 0): {acc1};"
              f" negative cells at worlds 2,3: {neg23} (>=3 at every level => refused)")
    print("  sum over k of the four endorsement inequalities = -nu(four unused quarters) < 0:"
          " no strictly positive charge endorses all four (exact identity).")
    print("ALL CHECKS PASSED" if allok else "SOME CHECK FAILED")
