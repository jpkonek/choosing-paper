"""Step 3: (TC) for repair records.  Certified violations (exact arithmetic).

One pencil of world-1-minority problems g_t = (1,-t,-t); three disjoint small
cones K1,K2,K3 around t = 1, 27/20, 4.  Two selected models:
   C_p  with p  = (200,74,37)/311 : silent on K1,K2,K3
   C_p' with p' = (200,59,59)/318 : accepts g on K1, accepts -g on K3.
Advice letters: P = accept g (world-1 correct here), N = accept -g, S = silent.

Violation at world 1 (two repairs + one strict guidance link):
   d1 = rec(C_p , X1), X1 = C_p  with (P,P,N) on (K1,K2,K3)
   d2 = rec(C_p', X2), X2 = C_p' with (S,  ,P) on (K1,  ,K3)
   C_p  <=  X1  (d1)      X1 <= U''  (copy of d2: X1 agrees with C_p' on K1,K3)
   U'' = C_p with (S,P,P) is a strict pointwise world-1 improvement of C_p.
Violation at worlds 2 and 3: the mirror pair
   d1' : (S,S,S) -> (P,N,N),   d2' : (P,.,N) -> (N,.,S) on (K1,.,K3),
   composite (S,S,S) -> (N,N,S): strict improvement at worlds 2 and 3.
Run: python3 -I -B s3_tc_violation.py
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from pp13core import *

def main(eps=F(3, 10)):
    P = setup(eps)
    ts = [F(1), F(27, 20), F(4)]
    gc = [[F(1), -t, -t] for t in ts]                 # central lines
    delta = F(1, 200)
    K = [cone_gens(g, delta) for g in gc]
    p = normalise([200, 74, 37]); pp = normalise([200, 59, 59])
    ok = True
    print(f"eps={eps}, kappa={P['kap']}, precision window on a pencil:"
          f" [(1+k)(1+k/2), (1+k)^2] = [{(1+P['kap'])*(1+P['kap']/2)}, {(1+P['kap'])**2}]"
          f" = [{float((1+P['kap'])*(1+P['kap']/2)):.4f}, {float((1+P['kap'])**2):.4f}]")
    print(f"t3/t1 = {ts[2]/ts[0]},  t3/t2 = {ts[2]/ts[1]} = {float(ts[2]/ts[1]):.4f}")
    a = [cone_advice(P, p, G) for G in K]
    b = [cone_advice(P, pp, G) for G in K]
    print("C_p  on K1..K3 (certified on cones):", a)
    print("C_p' on K1..K3 (certified on cones):", b)
    ok &= a == ['S', 'S', 'S'] and b[0] == 'P' and b[2] == 'N'
    # exposure: closed infeasibility at the central lines
    tests = {
        "d1  new side (P,P,N) on K1,K2,K3": [(gc[0], 'P'), (gc[1], 'P'), (gc[2], 'N')],
        "   its sub-pattern (P,N) on K2,K3": [(gc[1], 'P'), (gc[2], 'N')],
        "d2  new side (S,P) on K1,K3":       [(gc[0], 'S'), (gc[2], 'P')],
        "d1' new side (P,N,N) on K1,K2,K3": [(gc[0], 'P'), (gc[1], 'N'), (gc[2], 'N')],
        "d2' new side (N,S) on K1,K3":       [(gc[0], 'N'), (gc[2], 'S')],
    }
    for name, pat in tests.items():
        feas, q, _ = closed_feasible(P, pat)
        print(f"  family pattern? {name}: {'FEASIBLE q='+str(q) if feas else 'infeasible (closed system, exact)'}")
        ok &= not feas
    # old sides are family patterns (witnesses above) ; ranks / mixedness
    def ranks(pattern, i):
        return [rank(x, g, i) for x, g in zip(pattern, gc)]
    recs = {
        "d1 ": (['S', 'S', 'S'], ['P', 'P', 'N'], [0, 1, 2]),
        "d2 ": (['P', None, 'N'], ['S', None, 'P'], [0, 2]),
        "d1'": (['S', 'S', 'S'], ['P', 'N', 'N'], [0, 1, 2]),
        "d2'": (['P', None, 'N'], ['N', None, 'S'], [0, 2]),
    }
    for name, (old, new, D) in recs.items():
        line = []
        for i in range(3):
            inc = [rank(new[c], gc[c], i) - rank(old[c], gc[c], i) for c in D]
            mixed = any(x > 0 for x in inc) and any(x < 0 for x in inc)
            line.append(f"w{i+1}:{inc}{'(mixed)' if mixed else ''}")
            ok &= mixed
        print(f"  {name} rank increments on D: " + "  ".join(line))
    # compositions
    def compose(U, d1, d2):
        old1, new1, D1 = d1; old2, new2, D2 = d2
        U1 = list(U)
        assert all(U1[c] == old1[c] for c in D1)
        for c in D1: U1[c] = new1[c]
        assert all(U1[c] == old2[c] for c in D2), "context mismatch"
        U2 = list(U1)
        for c in D2: U2[c] = new2[c]
        return U1, U2
    U = ['S', 'S', 'S']                                # = C_p on the cones
    for tag, (r1, r2) in {"world-1 chain": ("d1 ", "d2 "), "worlds-2,3 chain": ("d1'", "d2'")}.items():
        U1, U2 = compose(U, recs[r1], recs[r2])
        print(f"  {tag}: C_p|K={U} -> X|K={U1} -> U''|K={U2}")
        for i in range(3):
            inc = [rank(U2[c], gc[c], i) - rank(U[c], gc[c], i) for c in range(3)]
            strict = all(x <= 0 for x in inc) and any(x < 0 for x in inc)
            print(f"     world {i+1}: composite increments {inc}"
                  f"{'  STRICT POINTWISE IMPROVEMENT -> forbidden (TC) triangle' if strict else ''}")
    # the inequality behind the precision window (exact symbolic check at central lines)
    print("ALL CHECKS PASSED" if ok else "SOME CHECK FAILED")

if __name__ == "__main__":
    main(F(3, 10))
