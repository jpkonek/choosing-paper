# exploratory (not a certificate): one-pencil chain search for two repair-eligible
# records composing to a strict world-1 improvement.  Cells are points on one pencil
# of M_1 lines, at log-positions s.  Family pattern on a pencil: B for s<L, S on
# [L,L+w], A for s>L+w, with w in [wmin,wmax]; or all-A (edge e2e3 / vertices e2,e3);
# or all-B (vertex e1).
import itertools, math
kap = 9/7
wmin = math.log((1+kap)*(1+kap/2)); wmax = 2*math.log(1+kap)
R = {'B':0,'S':1,'A':2}

def family(cells, pat, pos):
    # is there a family pattern matching pat on cells?
    if all(pat[c]=='A' for c in cells) or all(pat[c]=='B' for c in cells):
        return True
    ss = sorted(cells, key=lambda c: pos[c])
    r = [R[pat[c]] for c in ss]
    if any(r[i] > r[i+1] for i in range(len(r)-1)):
        return False
    S = [pos[c] for c in ss if pat[c]=='S']
    Bm = max([pos[c] for c in ss if pat[c]=='B'], default=-1e9)
    Am = min([pos[c] for c in ss if pat[c]=='A'], default=1e9)
    # need L > Bm, L+w < Am, L <= min S, L+w >= max S, w in [wmin,wmax]
    lo_w = max(wmin, (max(S)-min(S)) if S else 0.0)
    # choose w as small as allowed, L as large as allowed s.t. constraints
    for w in [lo_w, wmax]:
        if w < lo_w - 1e-12 or w > wmax + 1e-12: continue
        Lmin = Bm + 1e-9
        Lmax = min(min(S) if S else 1e9, Am - w - 1e-9)
        if S: Lmin = max(Lmin, max(S) - w)
        if Lmin <= Lmax: return True
    return False

def mixed(cells, old, new):
    d = [R[new[c]]-R[old[c]] for c in cells]
    return any(x>0 for x in d) and any(x<0 for x in d)

def search(pos):
    n = len(pos); found = []
    for U in itertools.product('BSA', repeat=n):
        for U1 in itertools.product('BSA', repeat=n):
            D1 = [c for c in range(n) if U[c]!=U1[c]]
            if not D1 or not mixed(D1,U,U1): continue
            if not family(D1,U,pos) or family(D1,U1,pos): continue
            for U2 in itertools.product('BSA', repeat=n):
                D2 = [c for c in range(n) if U1[c]!=U2[c]]
                if not D2 or not mixed(D2,U1,U2): continue
                if not family(D2,U1,pos) or family(D2,U2,pos): continue
                d = [R[U2[c]]-R[U[c]] for c in range(n)]
                if all(x<=0 for x in d) and any(x<0 for x in d):
                    found.append((''.join(U),''.join(U1),''.join(U2),'w1 better'))
                if all(x>=0 for x in d) and any(x>0 for x in d):
                    found.append((''.join(U),''.join(U1),''.join(U2),'w2,3 better'))
    return found

for pos in [(0.0,0.5,1.0),(0.0,0.3,1.4),(0.0,0.7,1.5),(0.0,1.0,1.6),(0.0,0.2,0.4,1.5),(0,0.5,1.0,2.0)]:
    f = search(list(pos))
    print(pos, len(f), f[:6])
