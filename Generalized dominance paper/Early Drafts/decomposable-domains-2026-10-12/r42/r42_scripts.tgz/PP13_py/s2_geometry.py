"""exact convex-polygon helpers in barycentric coordinates (points of the simplex)."""
from fractions import Fraction as F

def _to2(p): return (p[0], p[1])
def _to3(x): return [x[0], x[1], 1 - x[0] - x[1]]

def _ccw(poly):
    a = sum(poly[i][0] * poly[(i + 1) % len(poly)][1] - poly[(i + 1) % len(poly)][0] * poly[i][1]
            for i in range(len(poly)))
    return poly if a > 0 else poly[::-1]

def clip(subject, clipper):
    """Sutherland-Hodgman, both convex, ccw, 2D exact."""
    out = subject
    n = len(clipper)
    for i in range(n):
        A, B = clipper[i], clipper[(i + 1) % n]
        def inside(P): return (B[0] - A[0]) * (P[1] - A[1]) - (B[1] - A[1]) * (P[0] - A[0]) >= 0
        def inter(P, Q):
            x1, y1 = P; x2, y2 = Q; x3, y3 = A; x4, y4 = B
            den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
            t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / den
            return (x1 + t * (x2 - x1), y1 + t * (y2 - y1))
        inp, out = out, []
        if not inp: break
        for j in range(len(inp)):
            P, Q = inp[j], inp[(j + 1) % len(inp)]
            if inside(Q):
                if not inside(P): out.append(inter(P, Q))
                out.append(Q)
            elif inside(P):
                out.append(inter(P, Q))
    return out

def intersect_triangles(tris):
    polys = [_ccw([_to2(v) for v in t]) for t in tris]
    cur = polys[0]
    for p in polys[1:]:
        cur = clip(cur, p)
    # dedupe
    res = []
    for x in cur:
        if not res or res[-1] != x: res.append(x)
    return [_to3(x) for x in res]
