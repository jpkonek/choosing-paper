"""Step 2: exact repair certificates for named classes of rivals (eps = 3/10).

For a rival X and an index p we certify
  (a) for every world i a line g, with strict (open) advice for X and for C_p,
      where X is world-i-WORSE than C_p: so X is not a pointwise world-i
      improvement of C_p (a small cone around g is non-null);
  (b) exposure: a finite set W of lines, each with strict advice for X and C_p
      and X(g) != C_p(g) (so small cones around them lie in D = {C_p != X}),
      whose X-pattern is realised by NO family member: the CLOSED system at
      those lines is infeasible over the closed simplex (exact rational check).
      If some C_q agreed with X a.e. on D it would satisfy the closed system.
Search uses floats (numpy/scipy); every reported certificate is re-verified
exactly.  Run: python3 -u -I -B s2_instances.py
"""
import os, sys, random, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
import numpy as np
from scipy.optimize import linprog
from pp13core import *
from pp13core import _choices
from s2_geometry import intersect_triangles

P = setup(F(3, 10))
MM = np.array([[float(x) for x in row] for row in P['m']])
random.seed(13)

def flip(a): return {'P': 'N', 'N': 'P', 'S': 'S'}[a]
def fam(q): return lambda g: advice_strict(P, q, g)

def in_cone(g, gens):
    A = [[gens[0][r], gens[1][r], gens[2][r]] for r in range(3)]
    lam = solve3(A, list(g))
    return lam is not None and all(x > 0 for x in lam)

def patch(base, patches):
    def X(g):
        for gens, a in patches:
            if in_cone(g, gens): return a, True
            if in_cone([-x for x in g], gens): return flip(a), True
        return advice_strict(P, base, g)
    return X

def coherent(K):
    def X(g):
        vals = [sum(v[j] * g[j] for j in range(3)) for v in K]
        if min(vals) > 0: return 'P', True
        if max(vals) < 0: return 'N', True
        return 'S', (min(vals) < 0 < max(vals))
    return X

def splice(qa, qb, region):
    return lambda g: advice_strict(P, qa if region(g) else qb, g)

# ------------------------------------------------------------------ lines
def rand_line():
    while True:
        g = [F(random.randint(-400, 400), 400) for _ in range(3)]
        if is_mixed_class(g): return g

def lines_through(v, n=60, shifts=(F(0), F(1, 2000), F(-1, 2000), F(1, 200), F(-1, 200))):
    out = []
    for _ in range(n):
        w = [F(random.randint(-300, 300), 300) for _ in range(3)]
        g0 = [w[j] - sum(w[i] * v[i] for i in range(3)) for j in range(3)]
        for d in shifts:
            g = [x + d for x in g0]
            if is_mixed_class(g): out.append(g)
    return out

def lines_in_cone(gens, n=40):
    out = []
    for _ in range(n):
        l = [F(random.randint(1, 50)) for _ in range(3)]
        out.append([sum(l[i] * gens[i][j] for i in range(3)) for j in range(3)])
    return out

BASE = [rand_line() for _ in range(2500)]

def lp_feasible(rows):
    if not rows: return True
    A = -np.array(rows, dtype=float)
    A = A / np.maximum(np.linalg.norm(A, axis=1, keepdims=True), 1e-300)
    res = linprog([0, 0, 0], A_ub=A, b_ub=np.full(len(rows), 1e-12), A_eq=[[1, 1, 1]], b_eq=[1],
                  bounds=[(0, 1)] * 3, method='highs')
    return res.status == 0

def rows_of(g, a):
    r = [[float(P['m'][k][j] * g[j]) for j in range(3)] for k in range(3)]
    return r if a == 'P' else [[-x for x in rr] for rr in r]

def feas_f(Wl):
    lin = [r for g, a in Wl if a != 'S' for r in rows_of(g, a)]
    sil = [g for g, a in Wl if a == 'S']
    if not sil: return lp_feasible(lin)
    for ch in _choices(len(sil)):
        rr = list(lin)
        for (k, kp), g in zip(ch, sil):
            r3 = [[float(P['m'][kk][j] * g[j]) for j in range(3)] for kk in range(3)]
            rr += [[-x for x in r3[k]], r3[kp]]
        if lp_feasible(rr): return True
    return False

class Pool:
    def __init__(self, X, extra):
        self.L = list(extra) + BASE
        self.GA = np.array([[float(x) for x in g] for g in self.L])
        self.xa = [X(g) for g in self.L]
    def fam_float(self, q):
        qf = np.array([float(x) for x in q])
        ph = (MM * qf) @ self.GA.T
        mn, mx = ph.min(0), ph.max(0)
        adv = np.where(mn > 1e-9, 'P', np.where(mx < -1e-9, 'N', 'S'))
        return adv, (np.abs(ph) > 1e-7).all(0)

def certificate(X, p, pool):
    Cp = fam(p)
    adv_c, rob_c = pool.fam_float(p)
    worse = [None, None, None]
    D_lin, D_sil = [], []
    for n, g in enumerate(pool.L):
        ax, sx = pool.xa[n]
        if not (sx and rob_c[n]): continue
        ac = adv_c[n]
        if ax != ac: (D_sil if ax == 'S' else D_lin).append((g, ax))
        for i in range(3):
            if worse[i] is None and rank(ax, g, i) > rank(ac, g, i):
                ae, st = Cp(g)
                if st and rank(ax, g, i) > rank(ae, g, i): worse[i] = g
    if any(w is None for w in worse): return None
    rows = [r for g, a in D_lin for r in rows_of(g, a)]
    W = None
    if D_lin and not lp_feasible(rows): W = list(D_lin)
    else:
        for extra in D_sil[:3000]:
            if not feas_f(D_lin + [extra]): W = D_lin + [extra]; break
    if W is None: return None
    i = 0
    while i < len(W):
        trial = W[:i] + W[i + 1:]
        if trial and not feas_f(trial): W = trial
        else: i += 1
    for g, a in W:
        ax, sx = X(g); ac, sc = Cp(g)
        if not (sx and sc and ax == a and ac != a): return None
    if closed_feasible(P, W)[0]: return None
    return worse, W

def search(name, X, cands, extra=()):
    pool = Pool(X, extra)
    for p in cands:
        res = certificate(X, p, pool)
        if res:
            worse, W = res
            print(f"[{name}]\n   repair index p = {[str(x) for x in p]} : (a) and (b) CERTIFIED (exact)")
            for i, g in enumerate(worse):
                print(f"     (a) world {i+1}: X worse than C_p at g = {[str(x) for x in g]}")
            print(f"     (b) {len(W)} lines of D, closed family system infeasible:")
            for g, a in W:
                print(f"         g = {[str(x) for x in g]} : X says {a}, C_p says {fam(p)(g)[0]}")
            return p
    print(f"[{name}]\n   no certificate among {len(cands)} candidate indices")
    return None

def near_vertices():
    out = []
    for k in range(3):
        for (s, t) in [(1, 2), (2, 1), (1, 1), (3, 1), (1, 3), (7, 2), (2, 7)]:
            v = [F(0)] * 3; v[k] = F(200)
            o = [j for j in range(3) if j != k]
            v[o[0]] = F(s); v[o[1]] = F(t)
            out.append(normalise(v))
    return out

GRID = [normalise([a, b, 20 - a - b]) for a in range(1, 19, 2) for b in range(1, 19, 2) if a + b < 20]
CANDS = near_vertices() + GRID
u = normalise([1, 1, 1])

def class_rep(g, k):
    """representative of the problem g with the minority coordinate k positive, or None."""
    if g[k] > 0 and all(g[j] < 0 for j in range(3) if j != k): return g
    if g[k] < 0 and all(g[j] > 0 for j in range(3) if j != k): return [-x for x in g]
    return None

def find_cone(conds, k, delta=F(1, 1000), tries=400000):
    """a cone of class-k problems on which every (q, adv) in conds holds."""
    for _ in range(tries):
        g = class_rep(rand_line(), k)
        if g is None: continue
        if all(advice_strict(P, q, g) == (a, True) for q, a in conds):
            G = cone_gens(g, delta)
            if all(cone_advice(P, q, G) == a for q, a in conds): return G
    return None

if __name__ == "__main__":
    c, e = P['c'], P['eps']
    v = [[c + (e if j == k else 0) for j in range(3)] for k in range(3)]
    mid = lambda x, y, t: [x[j] * (1 - t) + y[j] * t for j in range(3)]
    Mq = lambda q: posterior_vertices(P, q)
    vtx_lines = lambda pts: [l for x in pts for l in lines_through(x)]
    # 1. rivals near T1
    g0 = [F(1), F(-1, 2), F(-1, 2)]
    E = cone_gens(g0, F(1, 100)); assert cone_advice(P, u, E) == 'S'
    ex = lines_in_cone(E) + vtx_lines(Mq(u))
    search("near T1: T1 + B on a cone where T1 is silent (world-1 improvement)", patch(u, [(E, 'P')]), CANDS, ex)
    search("near T1: T1 + A on a cone where T1 is silent (worlds-2,3 improvement)", patch(u, [(E, 'N')]), CANDS, ex)
    Kcap = [mid(v[0], v[1], F(1, 5)), mid(v[0], v[2], F(1, 5)), v[1], v[2]]
    search("near T1, coherent: D_K, K = M minus the cap at its vertex 1", coherent(Kcap), CANDS, vtx_lines(Kcap))
    Kcap2 = [v[0], mid(v[1], v[0], F(1, 10)), mid(v[1], v[2], F(1, 10)), v[2]]
    search("near T1, coherent: D_K, K = M minus a thin cap at its vertex 2", coherent(Kcap2), CANDS, vtx_lines(Kcap2))
    b = normalise([31, 34, 35])
    search("near T1, splice: T1 on {|g1|>|g2|}, C_b (b near u) elsewhere",
           splice(u, b, lambda g: abs(g[0]) > abs(g[1])), CANDS, vtx_lines(Mq(u) + Mq(b)))
    # 2. doubly anchored (PP8-type) rival
    a = normalise([50, 30, 20])
    pump = None
    for trial in range(200):
        q = normalise([F(50) + F(random.randint(-30, 30), 10), F(30) + F(random.randint(-30, 30), 10),
                       F(20) + F(random.randint(-30, 30), 10)])
        cs = []
        for k in range(3):
            G = find_cone([(a, 'S'), (q, 'N')], k, tries=4000)
            if G is None: break
            cs.append(G)
        if len(cs) == 3: pump = (q, cs); break
    if pump:
        q, cs = pump
        Yplus = patch(a, [(G, 'N') for G in cs])
        print(f"doubly anchored: a = {[str(x) for x in a]}, q = {[str(x) for x in q]}; Y_plus = C_a + A on one"
              f" cone per class where C_a is silent and C_q says A.\n   Y_plus is a C_a/C_q splice, so it is NOT"
              f" exposed at p = a or p = q (both are (a)-admissible: Y_plus is mixed against C_a at every world).")
        search("doubly anchored Y_plus", Yplus, CANDS, [l for G in cs for l in lines_in_cone(G)] + vtx_lines(Mq(a)))
    else:
        print("doubly anchored: no pump configuration found")
    # 3. Theorem-J rival
    r = normalise([3, 2, 0])
    GJ = [find_cone([(a, 'S'), (r, 'N')], k) for k in (0, 1)]
    if all(GJ):
        print("Theorem-J rival: X = C_a + A on G1 (class 1) u G2 (class 2), where the edge model C_r,"
              f" r = {[str(x) for x in r]}, says A.")
        search("Theorem-J rival", patch(a, [(G, 'N') for G in GJ]), CANDS,
               [l for G in GJ for l in lines_in_cone(G)] + vtx_lines(Mq(a)))
    else:
        print("Theorem-J rival: cones not found", [x is not None for x in GJ])
    # 4. edge rival
    E3 = find_cone([(r, 'N')], 2)
    search("edge rival: C_r (r on the open edge D_12) + B on a class-3 cone", patch(r, [(E3, 'P')]), CANDS,
           lines_in_cone(E3) + vtx_lines(Mq(r)))
    # 5. vertex rival
    e1 = [F(1), F(0), F(0)]
    gv = [F(1), F(-1, 3), F(-1, 4)]
    Ev = cone_gens(gv, F(1, 100))
    search("vertex rival: I_1 + silence on a cone", patch(e1, [(Ev, 'S')]), CANDS, lines_in_cone(Ev))
    # 6. coherent rivals
    p1, p2 = normalise([34, 33, 33]), normalise([33, 34, 33])
    Kh = Mq(p1) + Mq(p2)
    search("coherent: D_K, K = conv(M_p1 u M_p2) (overlapping: X is a C_p1/C_p2 splice)", coherent(Kh), CANDS,
           vtx_lines(Kh))
    search("coherent: precise interior model", coherent([normalise([5, 3, 2])]), CANDS, vtx_lines([normalise([5, 3, 2])]))
    qs = [normalise([F(1) if j != k else F(9, 10) for j in range(3)]) for k in range(3)]
    Kint = intersect_triangles([Mq(x) for x in qs])
    search("coherent: D_K, K = M_q1 n M_q2 n M_q3 (q_k = u moved away from e_k)", coherent(Kint), CANDS,
           vtx_lines(Kint))
    # 7. BBB / AAA
    def minority(g):
        pos = [x > 0 for x in g]
        k = pos.index(True) if pos.count(True) == 1 else pos.index(False)
        return ('P' if g[k] > 0 else 'N'), True
    search("BBB: minority advice on every mixed problem", minority, CANDS)
    search("AAA: majority advice on every mixed problem", lambda g: (flip(minority(g)[0]), True), CANDS)
