"""Step 3: a certified forbidden triangle  certificate defence + repair + guidance.
   C_k  <=_1  Y_k          (audit's world-1 defence c_k, source C_{p_k}, k = 3 or 0)
   Y_k  <=_1  V''          (copy of a repair rec(C_q, X_d), accepted at all worlds)
   V'' = C_k with B on (S_k \ T) u W : strict world-1 improvement of C_k.
The repair d changes: S->B on every E_{j,k} (j != k), B->S on a sub-cone T of
S_k, S->B on a cone W further out on the pencil through g_k.
Old side realised by C_q (strictly, on whole cones); new side not a family
pattern (closed system infeasible: S on T and B on W violates monotonicity
along the pencil).  Run: python3 -I -B s3_cert_violation.py
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from pp13core import *
from s1_certificate import build

eps, slopes = F(3,10), [F(-11,4), F(-7,2), F(-19,4)]
P, ps, gs, vs, zs = build(eps, slopes, F(1,4000))
cones = [cone_gens(g, F(1,4000)) for g in gs]
allok = True
for k in (3, 0):
    others = [j for j in range(4) if j != k]
    pat = [(gs[j], 'S') for j in others] + [(gs[k], 'P')]
    found = None
    for tW in [F(12,10), F(11,10), F(21,20), F(103,100)]:
        gW = [F(1), gs[k][1]*tW, gs[k][2]*tW]
        if advice_strict(P, ps[k], gW) != ('S', True): continue
        mg, q = lp_witness(P, pat + [(gW, 'S')])      # float search, exact check below
        if q is not None and mg > 0:
            found = (tW, gW, q); break
    tW, gW, q = found
    # simplify the witness: smallest denominator that still passes the exact checks
    for Dn in [10**2, 10**3, 10**4, 10**5, 10**6]:
        q2 = normalise([F(x).limit_denominator(Dn) for x in q])
        if (all(cone_advice(P, q2, cones[j]) == 'S' for j in others)
                and cone_advice(P, q2, cone_gens(gs[k], F(1,40000))) == 'P'
                and cone_advice(P, q2, cone_gens(gW, F(1,4000))) == 'S'):
            q = q2; break
    T = cone_gens(gs[k], F(1, 40000)); W = cone_gens(gW, F(1, 4000))
    chk = {
      "C_q silent on every certificate cone S_j, j != k": all(cone_advice(P, q, cones[j]) == 'S' for j in others),
      "C_q accepts g (B) on the sub-cone T of S_k": cone_advice(P, q, T) == 'P',
      "C_q silent on W": cone_advice(P, q, W) == 'S',
      "C_{p_k} silent on W": cone_advice(P, ps[k], W) == 'S',
      "C_{p_k} silent on T (T inside S_k)": cone_advice(P, ps[k], T) == 'S',
      "W disjoint from S_k (W lies further out on the pencil)": tW*(1-F(1,4000)) > (1+F(1,4000)),
      "W disjoint from every certificate cone (chart bounding boxes)": all(
          max(-w[1] for w in W) < min(-c[1] for c in cones[j]) or min(-w[1] for w in W) > max(-c[1] for c in cones[j])
          or max(-w[2] for w in W) < min(-c[2] for c in cones[j]) or min(-w[2] for w in W) > max(-c[2] for c in cones[j])
          for j in range(4)),
    }
    newside = [(gs[j], 'P') for j in others] + [(gs[k], 'S'), (gW, 'P')]
    feas, _, _ = closed_feasible(P, newside)
    chk["new side (B on all E_{j,k}, S on T, B on W) is NOT a family pattern (closed, exact)"] = not feas
    print(f"k={k}: q = {[str(x) for x in q]},  W at t = {tW} on the pencil of g_{k}")
    for name, v in chk.items():
        print(f"   {name}: {v}"); allok &= v
    print("   ranks at world 1 (B=0,S=1): d is S->B on E's, B->S on T, S->B on W: mixed at every world;")
    print("   composite C_k -> V'': S->B on S_k\\T and on W, unchanged elsewhere: STRICT world-1 improvement.")
print("ALL CHECKS PASSED" if allok else "SOME CHECK FAILED")
