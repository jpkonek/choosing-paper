"""PP28: one (TC) violation created at world 2 by moving the forced A-holder (core + q'')."""
import sys, io, contextlib, numpy as np
with contextlib.redirect_stdout(io.StringIO()):
    import cells28 as C
from cells28 import *
fam2 = C.fam + [C.cell(C.extra["q''"])]
rz = C.realised(fam2)
cov = [rz & (C.LEX[w] >= 0) for w in range(3)]
cov[0] &= ~(cov[1] | cov[2])
t, td = C.t, C.td
movers = []
for q in range(C.NM):
    if q in (t, td) or not (rz[td, q] and rz[q, t]): continue
    if cov[0][td, q] and cov[0][q, t]:
        movers.append((q, C.keyof(td, q)))
print('forced pairs at world 1 (Q):', [''.join(C.NAME[v] for v in C.models[q]) for q, _ in movers])
mv = C.same_record_mask([k for _, k in movers])
INVd = C.same_record_mask([C.keyof(t, td)])
w = 1
acc = C.guid[w] | (cov[w] | mv) | INVd
Ai = acc.astype(np.int32); two = (Ai @ Ai) > 0
viol = np.argwhere(two & acc.T & ~acc)
P_, R_ = viol[0]
Q_ = next(q for q in range(C.NM) if acc[P_, q] and acc[q, R_])
s = lambda i: ''.join(C.NAME[v] for v in C.models[i])
print('world 2 violation: P=%s <= Q=%s <= R=%s, R <= P accepted, P <= R refused' % (s(P_), s(Q_), s(R_)))
for a, b in ((P_, Q_), (Q_, R_), (R_, P_)):
    print('  %s -> %s : guidance %s, moved A-holder %s, base(realised, Omega_2>=0) %s, Omega0_2 = %s'
          % (s(a), s(b), bool(C.guid[w][a, b]), bool(mv[a, b]), bool(cov[w][a, b]), float(C.lev0[w][a, b])))
