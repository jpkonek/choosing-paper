"""PP28 cells (CHECKED, exact): radially split class-1 cells with a steep silent padding line
(F) and a steep line on which T answers B (G).  Regular values only (sub-domain: no X, no U).
Checks Theorem 3.1 / 4.1 (intersecting core) and Theorem 5.1 (forcing pairs) on cells."""
import itertools, sys
import numpy as np
from fractions import Fraction as F
from lib28 import *

LINES = {'B': (F(4, 5), F(11, 20)), 'A': (F(41, 50), F(57, 100)),
         'F': (F(1, 2), F(9, 10)), 'G': (F(3, 4), F(97, 100))}
PIECES = [('B', 0), ('B', 1), ('A', 0), ('A', 1), ('F', 0), ('G', 0)]
MASS = [F(2), F(2), F(1), F(1), F(3), F(3, 2)]          # beta = 4 > alpha = 2 (B-heavy)
n = len(PIECES)
LZ = [LINES[l] for l, _ in PIECES]

def cell(K):
    return tuple(advice(K, z) for z in LZ)

m0 = M[1]                                                 # common point of the core
p1 = (F(3, 10), F(1, 20), F(13, 20))
core = {'T': M, 'P0': [m0], 'S1': [m0, p1], 'S2': [m0, (F(1, 10), F(1, 10), F(4, 5))],
        'S3': [m0, (F(6, 10), F(3, 10), F(1, 10))],
        'S4': [m0, (F(1, 5), F(7, 10), F(1, 10)), (F(1, 2), F(2, 5), F(1, 10))],
        'S5': [m0, (F(7, 10), F(1, 10), F(1, 5))]}
extra = {'q': [(F(3, 10), F(1, 50), F(17, 25))], "q'": [(F(11, 50), F(77, 100), F(1, 100))],
         "q''": [(F(7, 20), F(11, 20), F(1, 10))]}
vert = {'V1': tuple([B] * n), 'V2': tuple([A] * n), 'V3': tuple([A] * n)}

print('== geometry (exact) ==')
for l, z in LINES.items():
    print('  line %s z=(%s,%s): T=%s  m0=%s' % (l, z[0], z[1], NAME[advice(M, z)], NAME[advice([m0], z)]))
print('  B <= A:', leq(LINES['B'], LINES['A']), '| F steep: z12(F)<z12(B), z13(F)>z13(A):',
      LINES['F'][0] < LINES['B'][0] and LINES['F'][1] > LINES['A'][1])
for k, K in list(core.items()) + list(extra.items()):
    print('  %-4s cells %s  contains m0: %s' % (k, ''.join(NAME[v] for v in cell(K)), any(x == m0 for x in K) or k == 'T'))

models = np.array(list(itertools.product(range(3), repeat=n)), dtype=np.int8)
NM = len(models)
idx = {tuple(m): i for i, m in enumerate(models)}
R = np.array([[rank(w, v) for v in range(3)] for w in range(3)])
ranks = np.stack([R[w][models] for w in range(3)])           # (3, NM, n)
mass = np.array([float(x) for x in MASS])
P, Q = np.meshgrid(np.arange(NM), np.arange(NM), indexing='ij')
supp = models[:, None, :] != models[None, :, :]              # (NM, NM, n)
delta = ranks[:, None, :, :] - ranks[:, :, None, :]          # delta[w, P, Q, piece] = r(Q) - r(P)
delta = np.transpose(ranks[:, None, :, :] - ranks[:, :, None, :], (0, 1, 2, 3))
# levels: total then piece by piece (a pi-system on cells -> linear order)
lev0 = np.einsum('wpqk,k->wpq', delta, mass) * np.array(W)[:, None, None]
def lexpos(w):
    lv = [lev0[w]] + [delta[w, :, :, k] * W[w] * mass[k] for k in range(n)]
    res = np.zeros((NM, NM), dtype=np.int8); decided = np.zeros((NM, NM), bool)
    for L in lv:
        pos = (L > 1e-9) & ~decided; neg = (L < -1e-9) & ~decided
        res[pos] = 1; res[neg] = -1; decided |= pos | neg
    return res                                               # 0 only on the diagonal
LEX = [lexpos(w) for w in range(3)]
guid = [(delta[w] >= 0).all(-1) for w in range(3)]            # weak worsening at w (incl. trivial)
pureimp = [(delta[w] <= 0).all(-1) & (delta[w] < 0).any(-1) for w in range(3)]

line_of = [l for l, _ in PIECES]
LEQ = np.array([[leq(LINES[a], LINES[b]) for b in line_of] for a in line_of])
def inverted_mask():
    oldS = np.where(supp, models[:, None, :] == S, True).all(-1)
    newAB = np.where(supp, models[None, :, :] != S, True).all(-1)
    isB = supp & (models[None, :, :] == B); isA = supp & (models[None, :, :] == A)
    hasB = isB.any(-1); hasA = isA.any(-1)
    ok = oldS & newAB & hasB & hasA
    # every B piece line <= every A piece line
    bad = np.zeros((NM, NM), bool)
    for a in range(n):
        for b in range(n):
            if not LEQ[b, a]:
                bad |= isB[:, :, b] & isA[:, :, a]
    return ok & ~bad
INV = inverted_mask()

def realised(fam):
    out = np.zeros((NM, NM), bool)
    for v in fam:
        agree = (models == np.array(v)[None, :])              # (NM, n)
        out |= np.where(supp, agree[:, None, :], True).all(-1)
    return out

def system(fam, polarity=False):
    rz = realised(fam)
    acc = []
    for w in range(3):
        cov = rz & (LEX[w] >= 0)
        acc.append(guid[w] | cov | INV)
    return acc, rz

def check(fam_cells, label, sel):
    acc, rz = system(fam_cells)
    tc = 0; g = 0
    for w in range(3):
        Ai = acc[w].astype(np.int32)
        two = (Ai @ Ai) > 0
        viol = two & acc[w].T & ~acc[w]
        tc += int(viol.sum())
        g += int((acc[w] & pureimp[w]).sum())
    comp = [all(any(acc[w][idx[s], x] for w in range(3)) for x in range(NM)) for s in sel]
    dom = []
    for s in sel:
        i = idx[s]
        weak = acc[0][:, i] & acc[1][:, i] & acc[2][:, i]
        strict = weak & ~(acc[0][i, :] & acc[1][i, :] & acc[2][i, :])
        strict[i] = False
        dom.append(int(strict.sum()))
    print('[%s] (TC) violations: %d | accepted pure improvements: %d | selected competitive vs all %d models: %s'
          ' | dominators of selected: %s' % (label, tc, g, NM, all(comp), dom))
    return acc, rz

def decompositions(rz, label, T, Td):
    t, td = idx[T], idx[Td]
    dbl = []
    for q in range(NM):
        if q in (t, td):
            continue
        if rz[td, q] and rz[q, t]:
            dbl.append(q)
    print('[%s] decompositions x.y = d^-1 with both old sides realised by non-vertex selected models: %d'
          % (label, len(dbl)))
    for q in dbl[:6]:
        o = [int(LEX[w][td, q]) for w in range(3)], [int(LEX[w][q, t]) for w in range(3)]
        x0 = [float(lev0[w][td, q]) for w in range(3)]; y0 = [float(lev0[w][q, t]) for w in range(3)]
        print('   Q=%s  Omega0(x)=%s Omega0(y)=%s' % (''.join(NAME[v] for v in models[q]), x0, y0))
    return dbl

Tcell = cell(M)
d_new = list(Tcell); d_new[0] = d_new[1] = B; d_new[2] = d_new[3] = A
Td = tuple(d_new)
print('T cells', ''.join(NAME[v] for v in Tcell), ' T.d cells', ''.join(NAME[v] for v in Td),
      ' d inverted:', bool(INV[idx[Tcell], idx[Td]]), ' Omega0(d) per world:',
      [float(lev0[w][idx[Tcell], idx[Td]]) for w in range(3)])

print('\n== (1) intersecting core + vertices ==')
fam = [cell(K) for K in core.values()]
sel = list(dict.fromkeys(fam + list(vert.values())))
acc, rz = check(fam, 'core', sel)
t, td = idx[Tcell], idx[Td]
print('  T <=_w T.d at all worlds:', [bool(acc[w][t, td]) for w in range(3)],
      ' reverse T.d <=_w T:', [bool(acc[w][td, t]) for w in range(3)])
# Prop 4.7 split x realised?  x = (A pieces: A->S) + (F: S->A)
Q47 = list(Td); Q47[2] = Q47[3] = S; Q47[4] = A; q47 = idx[tuple(Q47)]
print('  Prop 4.7 split: x old side realised: %s (by %s) ; y old side realised: %s' % (
      bool(rz[td, q47]), [k for k, K in core.items() if realised([cell(K)])[td, q47]], bool(rz[q47, t])))
print('  x accepted at worlds', [bool(acc[w][td, q47]) for w in range(3)],
      '; y accepted at worlds', [bool(acc[w][q47, t]) for w in range(3)])
decompositions(rz, 'core', Tcell, Td)

for add in (['q', "q'"], ["q''"], ['q', "q'", "q''"]):
    print('\n== (2) core + separated %s ==' % add)
    fam2 = fam + [cell(extra[k]) for k in add]
    acc2, rz2 = check(fam2, 'core+' + '+'.join(add), list(dict.fromkeys(fam2 + list(vert.values()))))
    print('  T <=_w T.d:', [bool(acc2[w][t, td]) for w in range(3)])
    dbl = decompositions(rz2, 'core+' + '+'.join(add), Tcell, Td)
    only1 = [q for q in dbl if LEX[1][td, q] < 0 and LEX[2][td, q] < 0 and LEX[1][q, t] < 0 and LEX[2][q, t] < 0]
    print('  of these, both pieces Omega-acceptable only at the owner world 1:', len(only1))

print('\n== (3) allocations: canonical vs owner-minimal vs polarity (core + separated pairs) ==')
reckey = np.where(supp, models[:, None, :] * 3 + models[None, :, :], -1)   # per-piece (old,new) code
def keyof(p, q):
    return tuple(reckey[p, q])
def same_record_mask(keys):
    m = np.zeros((NM, NM), bool)
    kk = set(keys)
    if not kk:
        return m
    flat = reckey.reshape(NM * NM, n)
    hit = np.array([tuple(r) in kk for r in map(tuple, flat)])
    return hit.reshape(NM, NM)
def run_alloc(fam_cells, mode, label):
    rz = realised(fam_cells)
    cov = [rz & (LEX[w] >= 0) for w in range(3)]
    if mode in ('minimal', 'polarity'):
        elsewhere = cov[1] | cov[2]
        cov[0] = cov[0] & ~elsewhere            # owner world keeps only what nobody else can take
    if mode == 'polarity':
        movers = []
        for q in range(NM):
            if q in (t, td) or not (rz[td, q] and rz[q, t]):
                continue
            if cov[0][td, q] and cov[0][q, t]:  # forced pair at world 1
                # the A-holder: piece whose old side is A on both A-line pieces
                xa = models[td][2] == A and supp[td, q][2] and supp[td, q][3]
                movers.append(keyof(td, q) if xa else keyof(q, t))
        mv = same_record_mask(movers)
        cov[0] &= ~mv; cov[1] |= mv; cov[2] |= mv
    acc = [guid[w] | cov[w] | INV for w in range(3)]
    out = []
    for w in range(3):
        Ai = acc[w].astype(np.int32)
        out.append(int(((Ai @ Ai) > 0).__and__(acc[w].T).__and__(~acc[w]).sum()))
    sel = list(dict.fromkeys(fam_cells + list(vert.values())))
    comp = all(any(acc[w][idx[s], x] for w in range(3)) for s in sel for x in range(NM))
    print('  [%s | %s] (TC) violations per world %s | competitive: %s | T<=T.d all worlds: %s'
          % (label, mode, out, comp, all(acc[w][t, td] for w in range(3))))
for add in (['q', "q'"], ["q''"]):
    fam2 = fam + [cell(extra[k]) for k in add]
    for mode in ('canonical', 'minimal', 'polarity'):
        run_alloc(fam2, mode, 'core+' + '+'.join(add))
for mode in ('canonical', 'minimal'):
    run_alloc(fam, mode, 'core')

print('\n== (4) same, with the certificate layer restricted to the copies of d alone ==')
INV_ALL = INV
INV = same_record_mask([keyof(t, td)])
print('  copies of d on cells:', int(INV.sum()))
for add in ([], ['q', "q'"], ["q''"]):
    fam2 = fam + [cell(extra[k]) for k in add]
    for mode in ('canonical', 'minimal', 'polarity'):
        run_alloc(fam2, mode, 'core+' + '+'.join(add) if add else 'core')
INV = INV_ALL
