"""PP28 Lemma 2.1 / Cor 2.2 on cells (CHECKED; disjointness by exact rational test of the
separating class-1 line, plus an LP cross-check).  Pool: random rational credal sets in int(Delta)
(points, segments, triangles).  For every inverted departure d out of the all-silent cell model
and every intermediate Q, whenever both old sides of x = rec(N.d, Q), y = rec(Q, N) are realised by
pool members, test that the two realisers have disjoint credal sets."""
import itertools, random
import numpy as np
from fractions import Fraction as F
from scipy.optimize import linprog
from lib28 import *
from cells28 import LINES, PIECES, LZ, cell, n, models, NM, idx, INV
random.seed(28)
def rp():
    a = [random.randint(1, 40) for _ in range(3)]; s = sum(a)
    return tuple(F(x, s) for x in a)
pool = []
for _ in range(400):
    k = random.choice([1, 2, 3]); base = rp(); K = [base]
    for _ in range(k - 1):
        o = rp(); t = F(random.randint(1, 6), 10)
        K.append(tuple(base[i] * (1 - t) + o[i] * t for i in range(3)))
    pool.append(K)
pc = [cell(K) for K in pool]
def disjoint(K1, K2):
    nv1, nv2 = len(K1), len(K2)
    Aeq = np.zeros((4, nv1 + nv2)); beq = np.zeros(4)
    for i in range(3):
        Aeq[i, :nv1] = [float(m[i]) for m in K1]; Aeq[i, nv1:] = [-float(m[i]) for m in K2]
    Aeq[3, :nv1] = 1; beq[3] = 1
    r = linprog(np.zeros(nv1 + nv2), A_eq=Aeq, b_eq=beq, bounds=[(0, None)] * (nv1 + nv2), method='highs')
    return r.status != 0
N0 = idx[tuple([S] * n)]
cases = pairs = fails = 0
for dd in range(NM):
    if not INV[N0, dd]:
        continue
    for q in range(NM):
        if q in (N0, dd):
            continue
        sx = models[dd] != models[q]; sy = models[q] != models[N0]
        rx = [i for i, v in enumerate(pc) if all(v[k] == models[dd][k] for k in range(n) if sx[k])]
        ry = [i for i, v in enumerate(pc) if all(v[k] == models[q][k] for k in range(n) if sy[k])]
        if rx and ry:
            cases += 1
            for a in rx[:5]:
                for b in ry[:5]:
                    pairs += 1
                    if not disjoint(pool[a], pool[b]):
                        fails += 1
print('inverted departures out of the silent model:', int(INV[N0].sum()))
print('doubly realised decompositions found (pool of %d credal sets): %d' % (len(pool), cases))
print('realiser pairs tested: %d ; pairs with intersecting credal sets: %d' % (pairs, fails))
