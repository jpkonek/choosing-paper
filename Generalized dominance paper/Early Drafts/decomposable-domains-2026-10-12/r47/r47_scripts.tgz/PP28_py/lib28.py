"""PP28 shared geometry (exact rationals). Class-1 lines are given by edge coordinates
(z12, z13): the line meets [e1,e2] at distance z12 from e1 and [e1,e3] at z13 from e1.
Its e1-triangle is {m : m2/z12 + m3/z13 < 1}. Advice of D_K on the line (oriented so that
'A' = majority answer, correct at worlds 2,3): A if K misses the closed triangle, B if K is
inside the open triangle, S otherwise. ranks: owner world 1: A2 S1 B0; worlds 2,3: A0 S1 B2."""
from fractions import Fraction as F
A, S, B = 0, 1, 2
NAME = 'ASB'
eps = F(3, 10); c = (1 - eps) / 3
M = [tuple(c + (eps if i == k else 0) for i in range(3)) for k in range(3)]
u = (F(1, 3),) * 3

def tri_val(m, z):            # < 1 : strictly inside the e1-triangle
    return m[1] / z[0] + m[2] / z[1]

def advice(K, z):
    vals = [tri_val(m, z) for m in K]
    if all(v < 1 for v in vals):
        return B
    if all(v > 1 for v in vals):
        return A
    return S

def leq(z, w):                 # line order: e1-triangle of z inside that of w
    return z[0] <= w[0] and z[1] <= w[1]

def rank(world, v):            # class-1 problems only
    return (2 - v) if world == 0 else v

W = [2, 1, 1]                  # Omega weights on M_1
