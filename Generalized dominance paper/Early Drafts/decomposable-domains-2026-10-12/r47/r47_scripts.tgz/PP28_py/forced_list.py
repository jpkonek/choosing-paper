"""PP28: list the decompositions whose two pieces are both selected-realised and both
Omega-acceptable only at the owner world (the forced pairs of Theorem 5.1), with realisers."""
import io, contextlib
with contextlib.redirect_stdout(io.StringIO()):
    import cells28 as C
names = dict(list(C.core.items()) + list(C.extra.items()))
s = lambda i: ''.join(C.NAME[v] for v in C.models[i])
for add in (['q', "q'"], ["q''"]):
    fam = {k: C.cell(K) for k, K in C.core.items()}
    fam.update({k: C.cell(C.extra[k]) for k in add})
    rz = {k: C.realised([v]) for k, v in fam.items()}
    print('family core +', add)
    for q in range(C.NM):
        if q in (C.t, C.td): continue
        rx = [k for k in fam if rz[k][C.td, q]]; ry = [k for k in fam if rz[k][q, C.t]]
        if rx and ry and all(C.LEX[w][C.td, q] < 0 and C.LEX[w][q, C.t] < 0 for w in (1, 2)):
            print('   Q=%s  x: %s -> %s realised by %s | y: %s -> %s realised by %s | Omega0_1(x),(y) = %s, %s'
                  % (s(q), s(C.td), s(q), rx, s(q), s(C.t), ry, float(C.lev0[0][C.td, q]), float(C.lev0[0][q, C.t])))
