"""PP30 kill_mc.py -- NUMERICS for Theorem 3.2 with genuine balls and Gaussian mu.

For a grid of p and several eps, take h+- = +-g_p + t*1 as in the proof, a radius r
that provably keeps each ball inside Sil(T) and inside {p.x > 0} (computed from the
supporting planes of Sil), and estimate by Monte Carlo
   v_w = int_{B+ u B-} x_w * sign(p.x) dmu(x)      (mu = standard Gaussian on R^3)
and the proof's lower bound  mu(B+)(t - r) + mu(B-)(t - r)  (here mu(B+) = mu(B-)).
Also re-checks on every sample that x is in Sil(T) and p.x > 0.
The proof does not depend on these numbers; they illustrate the margins.
Run: python3 -I -B kill_mc.py > kill_mc.out
"""
import numpy as np

rng = np.random.default_rng(20261022)


def setup(p, eps):
    u = np.ones(3) / 3
    pm = p - u
    g = np.cross(pm, np.ones(3)) if np.linalg.norm(pm) > 1e-12 else np.array([1.0, -1.0, 0.0])
    t = eps * min(g.max(), -g.min()) / 2
    hp, hm = g + t, -g + t
    c = (1 - eps) / 3
    normals = [c * np.ones(3) + eps * np.eye(3)[w] for w in range(3)]
    rs = []
    for h in (hp, hm):
        vals = [n @ h for n in normals]
        wlo, whi = int(np.argmin(vals)), int(np.argmax(vals))
        assert vals[wlo] < 0 < vals[whi]
        rs.append(min(-vals[wlo] / np.linalg.norm(normals[wlo]), vals[whi] / np.linalg.norm(normals[whi])))
    r = 0.9 * min(min(rs), t / 2)  # t/2 keeps p.x >= t - |p| r > 0 and the bound t - r > 0
    return g, t, hp, hm, r, c


def in_sil(x, c, eps):
    s = x.sum(axis=1)
    lo = c * s + eps * x.min(axis=1)
    hi = c * s + eps * x.max(axis=1)
    return (lo < 0) & (hi > 0)


def ball_integral(h, r, p, c, eps, n=200000):
    d = rng.normal(size=(n, 3))
    d /= np.linalg.norm(d, axis=1, keepdims=True)
    rad = r * rng.random(n) ** (1 / 3)
    x = h + d * rad[:, None]
    assert in_sil(x, c, eps).all()
    sp = np.sign(x @ p)
    assert (sp > 0).all()
    dens = np.exp(-0.5 * (x ** 2).sum(axis=1)) / (2 * np.pi) ** 1.5
    vol = 4 / 3 * np.pi * r ** 3
    mass = vol * dens.mean()
    integ = vol * (x * sp[:, None] * dens[:, None]).mean(axis=0)
    se = vol * (x * sp[:, None] * dens[:, None]).std(axis=0) / np.sqrt(n)
    return mass, integ, se


def main():
    N = 6
    grid = [np.array([a, b, N - a - b]) / N for a in range(N + 1) for b in range(N + 1 - a)]
    for eps in [0.1, 0.3, 0.6]:
        worst = np.inf
        for p in grid:
            g, t, hp, hm, r, c = setup(p, eps)
            m1, i1, s1 = ball_integral(hp, r, p, c, eps)
            m2, i2, s2 = ball_integral(hm, r, p, c, eps)
            v = i1 + i2
            se = np.sqrt(s1 ** 2 + s2 ** 2)
            bound = (m1 + m2) * (t - r)
            ratio = (v / bound).min()
            worst = min(worst, ratio)
            assert (v - 4 * se > 0).all(), (p, v, se)
        print(f"eps={eps}: {len(grid)} grid points; every v_w > 0 by > 4 s.e.; "
              f"min over grid and worlds of v_w / proof-bound = {worst:.3f} (>= 1 expected)")
    p = np.array([1.0, 0, 0])
    g, t, hp, hm, r, c = setup(p, 0.3)
    m1, i1, _ = ball_integral(hp, r, p, c, 0.3)
    m2, i2, _ = ball_integral(hm, r, p, c, 0.3)
    print(f"example p=e1, eps=0.3: h+={hp}, h-={hm}, t={t:.3f}, r={r:.4f}, mu(G)={m1 + m2:.3e}, v={i1 + i2}")
    print("ALL PASS")


if __name__ == '__main__':
    main()
