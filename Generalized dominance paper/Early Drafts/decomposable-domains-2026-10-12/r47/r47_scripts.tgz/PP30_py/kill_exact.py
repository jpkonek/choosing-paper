"""PP30 kill_exact.py -- exact (rational) bookkeeping check of Theorem 3.2.

Theorem 3.2 (the three-record kill): for every p in the closed simplex there is a
bounded G inside Sil(T) (T = T1 = D_M, M = c*1 + eps*Delta) such that the S_0 values
  v_w := int_G g_w * sign(p.g) dmu
are > 0 at all three worlds.  The proof uses two small balls around
  h+ = g_p + t*1,  h- = -g_p + t*1,  g_p in u^perp cap p^perp,
with equal mass.  Here the balls are replaced by ATOMS of mass 1 at h+ and h-
(a cell model).  This checks only the bookkeeping:
  (a) h+- lie in Sil(T)   (exact: c*sum(h) + eps*min(h) < 0 < c*sum(h) + eps*max(h));
  (b) D_p accepts h+- in the represented sign (p.h = t > 0);
  (c) v = h+ + h- = 2t*1 > 0;
  (d) for each world w, with E_w = a fraction theta of one atom, the record
      rec(X, Y_w) (X = T[G->D_p], Y_w = T[E_w -> w-correct]) is a genuine (IB) copy of
      rec(D_p, Z_w) (Z_w = D_p[G -> S, E_w -> w-correct]), its S_0 value is
      v_w - theta*|h_w| > 0 (accepted by S_0), Y_w is a strict pointwise
      w-improvement of T, and the S_0 value of T <=_w X is -v_w < 0.
It is NOT evidence about (S) or about the continuum beyond what the proof uses.
Run: python3 -I -B kill_exact.py > kill_exact.out
"""
from fractions import Fraction as F
from itertools import product

ONE = (F(1), F(1), F(1))


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def sgn(x):
    return (x > 0) - (x < 0)


def T_answer(h, eps):
    c = (1 - eps) / 3
    lo = c * sum(h) + eps * min(h)
    hi = c * sum(h) + eps * max(h)
    if lo > 0:
        return 1
    if hi < 0:
        return -1
    if lo < 0 < hi:
        return 0
    return None  # boundary (null set) -- must not occur for atoms


def rank(ans, h, w):
    """ans: +1 accept h, -1 accept -h, 0 silent, 'X' contradiction."""
    if ans == 'X':
        return 3
    if ans == 0:
        return 1
    return 0 if ans * sgn(h[w]) > 0 else 2


def wcorrect(h, w):
    return sgn(h[w])


def check(p, eps, theta=F(1, 100)):
    u = (F(1, 3),) * 3
    pm = tuple(pi - ui for pi, ui in zip(p, u))
    g = cross(pm, ONE) if any(pm) else (F(1), F(-1), F(0))
    assert dot(g, ONE) == 0 and dot(g, p) == 0 and any(g)
    t = eps * min(max(g), -min(g)) / 2
    # atoms must avoid the null coordinate planes g_w = 0 (in the continuum the balls do)
    while any(x + t == 0 or -x + t == 0 for x in g):
        t = t * 2 / 3
    hp = tuple(x + t for x in g)
    hm = tuple(-x + t for x in g)
    assert all(hp) and all(hm)
    atoms = [hp, hm]
    out = {}
    # (a), (b)
    for h in atoms:
        assert T_answer(h, eps) == 0, ('not silent', p, eps, h)
        assert dot(p, h) == t > 0
    # (c)
    v = tuple(sum(h[w] * sgn(dot(p, h)) for h in atoms) for w in range(3))
    assert v == tuple(2 * t for _ in range(3)), v
    # (d)
    for w in range(3):
        for ai, a in enumerate(atoms):  # E_w = theta part of atom a
            # pieces: (atom, mass, X answer, Y answer, T answer, Dp answer, Z answer)
            pieces = []
            for bi, b in enumerate(atoms):
                Dp = sgn(dot(p, b))
                if bi == ai:
                    pieces.append((b, theta, Dp, wcorrect(b, w), 0, Dp, wcorrect(b, w)))
                    pieces.append((b, 1 - theta, Dp, 0, 0, Dp, 0))
                else:
                    pieces.append((b, F(1), Dp, 0, 0, Dp, 0))
            # (IB): records agree piece by piece (support, old side, new side)
            recXY = [(i, X, Y) for i, (b, m, X, Y, Tn, Dp, Z) in enumerate(pieces) if X != Y]
            recDZ = [(i, Dp, Z) for i, (b, m, X, Y, Tn, Dp, Z) in enumerate(pieces) if Dp != Z]
            assert recXY == recDZ
            # S_0 value of X <=_w Y_w  (= L_w(Y) - L_w(X))
            val = sum(m * abs(b[w]) * (rank(Y, b, w) - rank(X, b, w)) for (b, m, X, Y, Tn, Dp, Z) in pieces)
            expected = v[w] - theta * abs(a[w])
            assert val == expected, (val, expected)
            assert val > 0
            # Y_w strict pointwise improvement of T at w
            assert all(rank(Y, b, w) <= rank(Tn, b, w) for (b, m, X, Y, Tn, Dp, Z) in pieces)
            assert any(rank(Y, b, w) < rank(Tn, b, w) and m > 0 for (b, m, X, Y, Tn, Dp, Z) in pieces)
            # S_0 value of T <=_w X
            valTX = sum(m * abs(b[w]) * (rank(X, b, w) - rank(Tn, b, w)) for (b, m, X, Y, Tn, Dp, Z) in pieces)
            assert valTX == -v[w] < 0
    return t, v


def far_example(eps):
    """Kill for p = u supported away from u^perp: atoms at (1,1,-3/2) and permutations."""
    p = (F(1, 3),) * 3
    base = (F(1), F(1), F(-3, 2))
    atoms = [base, (base[0], base[2], base[1]), (base[2], base[0], base[1])]
    ok = all(T_answer(h, eps) == 0 for h in atoms)
    v = tuple(sum(h[w] * sgn(dot(p, h)) for h in atoms) for w in range(3))
    cosang = [float(dot(h, ONE)) / (float(dot(h, h)) ** 0.5 * 3 ** 0.5) for h in atoms]
    return ok, v, cosang


def main():
    epss = [F(1, 10), F(3, 10), F(1, 2), F(9, 10)]
    N = 12
    grid = [(F(a, N), F(b, N), F(N - a - b, N)) for a in range(N + 1) for b in range(N + 1 - a)]
    n = 0
    for eps in epss:
        tmin = None
        for p in grid:
            t, v = check(p, eps)
            n += 1
            tmin = t if tmin is None else min(tmin, t)
        print(f"eps={eps}: all {len(grid)} grid points p (denominator {N}) PASS; min t = {tmin}")
    for p, name in [((F(1), F(0), F(0)), 'e1'), ((F(1, 2), F(1, 2), F(0)), 'mid-edge'), ((F(1, 3),) * 3, 'u')]:
        t, v = check(p, F(3, 10))
        print(f"  eps=3/10, p={name}: t={t}, v=2t*(1,1,1)={v}")
    print(f"TOTAL configurations checked: {n} (x 3 worlds x 2 atoms for E_w)")
    for eps in epss:
        ok, v, cosang = far_example(eps)
        print(f"far-from-u^perp kill for p=u, eps={eps}: atoms silent under T: {ok}; v={v}; "
              f"cos(angle to 1)={[round(x, 3) for x in cosang]}")
    print("ALL PASS")


if __name__ == '__main__':
    main()
