"""PP30 ans_rigidity.py -- checks for Section 5 (surgery in problem space).

(a) CHECKED (exact rationals): on T's answered region Ans(T), T's answer is the unique
    minimiser of the S_0 per-problem cost  sum_w m_w |g_w| r_w(g, .)  over the four
    advice values, for every m in M (tested at the three vertices of M, the centre, and
    random rational points of M; random rational g in Ans(T)).  This is the pointwise
    fact behind Theorem 5.1 (no three-link kill when S_0 is kept on Ans(T)-records).
(b) NUMERICS: Lemma 5.3 (geometry).  For a coherent D_K and a precise D_lam,
    D_K = D_lam a.e. on Ans(T)  iff  K = {lam}  or  (K subset of M and lam in M).
    We sample g in Ans(T) and look for a robust disagreement (margins > 1e-3) for
    random K (convex hulls of 1-3 random points) and random lam, and compare with the
    prediction.
Run: python3 -I -B ans_rigidity.py > ans_rigidity.out
"""
from fractions import Fraction as F
import random
import numpy as np

random.seed(30)
rng = np.random.default_rng(30)
EPS = F(3, 10)
C = (1 - EPS) / 3


def sgn(x):
    return (x > 0) - (x < 0)


def T_ans(g):
    s = sum(g)
    lo, hi = C * s + EPS * min(g), C * s + EPS * max(g)
    return 1 if lo > 0 else (-1 if hi < 0 else (0 if lo < 0 < hi else None))


def rank(a, g, w):
    if a == 'X':
        return 3
    if a == 0:
        return 1
    return 0 if a * sgn(g[w]) > 0 else 2


def part_a(n=20000):
    Mpts = [tuple(C + (EPS if v == w else 0) for v in range(3)) for w in range(3)]
    Mpts.append((F(1, 3),) * 3)
    for _ in range(20):
        x = [F(random.randint(0, 50)) for _ in range(3)]
        s = sum(x) or F(1)
        Mpts.append(tuple(C + EPS * xi / s for xi in x))
    cnt = 0
    while cnt < n:
        g = tuple(F(random.randint(-60, 60), random.randint(1, 20)) for _ in range(3))
        if 0 in g:
            continue
        a = T_ans(g)
        if a not in (1, -1):
            continue
        cnt += 1
        for m in Mpts:
            cost = {b: sum(m[w] * abs(g[w]) * rank(b, g, w) for w in range(3)) for b in (1, -1, 0, 'X')}
            best = min(cost.values())
            assert cost[a] == best and sum(1 for b in cost if cost[b] == best) == 1
    print(f"(a) CHECKED: T's answer is the unique S_0-Bayes answer for all {len(Mpts)} test points m of M "
          f"at {n} random rational g in Ans(T)")


def part_b(trials=400, n=60000):
    eps, c = float(EPS), float(C)
    g = rng.normal(size=(n, 3))
    s = g.sum(axis=1)
    lo, hi = c * s + eps * g.min(axis=1), c * s + eps * g.max(axis=1)
    ans = (lo > 1e-3) | (hi < -1e-3)
    G = g[ans]

    def rand_simplex(k):
        return rng.dirichlet(np.ones(3), size=k)

    def rand_M(k):
        return c + eps * rng.dirichlet(np.ones(3), size=k)

    def in_M(x):
        return ((x - c) / eps >= -1e-12).all()

    def DK(Kpts, gg):
        v = gg @ Kpts.T  # n x k
        acc = (v > 1e-3).all(axis=1)
        rej = (v < -1e-3).all(axis=1)
        sil = ~acc & ~rej
        return acc, rej, sil, (np.abs(v) > 1e-3).all(axis=1)

    stats = {}
    for trial in range(trials):
        kind = trial % 5
        if kind == 0:   # K in M, lam in M  -> predicted equal
            K, lam = rand_M(rng.integers(1, 4)), rand_M(1)[0]
        elif kind == 1:  # K in M (non-singleton), lam outside M -> predicted differ
            K = rand_M(rng.integers(2, 4))
            lam = rand_simplex(1)[0]
            while in_M(lam):
                lam = rand_simplex(1)[0]
        elif kind == 2:  # K not in M, non-singleton, lam in K -> predicted differ
            K = rand_simplex(rng.integers(2, 4))
            while all(in_M(k) for k in K):
                K = rand_simplex(rng.integers(2, 4))
            lam = K.mean(axis=0)
        elif kind == 3:  # K = {lam} -> predicted equal
            lam = rand_simplex(1)[0]
            K = lam[None, :]
        else:            # K = {k}, k != lam, not both in M -> predicted differ
            k, lam = rand_simplex(1)[0], rand_simplex(1)[0]
            while in_M(k) and in_M(lam):
                k, lam = rand_simplex(1)[0], rand_simplex(1)[0]
            K = k[None, :]
        predicted_equal = (len(K) == 1 and np.allclose(K[0], lam)) or (all(in_M(k) for k in K) and in_M(lam))
        acc, rej, sil, _ = DK(K, G)
        lv = G @ lam
        robust = np.abs(lv) > 1e-3
        dlam_acc = lv > 1e-3
        differ = robust & ((acc != dlam_acc) | sil) & (acc | rej | sil)
        # require robust disagreement: K strictly on one side or strictly straddling
        found = differ.any()
        key = ('pred_equal' if predicted_equal else 'pred_differ', 'found_diff' if found else 'no_diff')
        stats[key] = stats.get(key, 0) + 1
    print("(b) NUMERICS, Lemma 5.3: counts (prediction, sampled outcome):")
    for k in sorted(stats):
        print("   ", k, stats[k])
    assert stats.get(('pred_equal', 'found_diff'), 0) == 0


if __name__ == '__main__':
    part_a()
    part_b()
    print("ALL PASS (pred_differ/no_diff cases, if any, are sampling misses near the boundary; see note)")
