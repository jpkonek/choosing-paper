"""PP29 library: cell record algebra (regular values A,S,B; X and U omitted) with
SUPPORT-SENSITIVE realisability: for every record, the faces of the simplex on which some
coherent D_K with K inside that face realises its old side.

Values: 0 = A (majority answer), 1 = S, 2 = B (minority answer).
A line of class k is given by its edge coordinates (z_kj, z_kl), j<l the other worlds,
measured from e_k (as in PP23 cellsat.direction).
"""
import itertools
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import linprog

A, S, B = 0, 1, 2
PAIRS = [(o, n) for o in range(3) for n in range(3) if o != n]   # codes 1..6
CODE = {p: i + 1 for i, p in enumerate(PAIRS)}
VN = 'ASB'


def rank(world, cls, v):
    return (2 - v) if world == cls else v


def direction(cls, z1, z2):
    others = [w for w in range(3) if w != cls]
    g = np.zeros(3)
    g[cls] = -1.0
    g[others[0]] = (1 - z1) / z1
    g[others[1]] = (1 - z2) / z2
    return g


FACES = {  # name -> (support worlds); K must lie in the face spanned by these vertices
    'int': (0, 1, 2),
    'e01': (0, 1), 'e02': (0, 2), 'e12': (1, 2),
    'v0': (0,), 'v1': (1,), 'v2': (2,),
}


def realisable(pattern, dirs, face, eps=1e-7):
    """pattern: dict line-index -> value (A,S,B). Is there a closed convex K inside the face
    with D_K equal to the pattern on these lines?  K exists iff the open region
    R = {m in face : m.g>0 on A-lines, m.g<0 on B-lines} is nonempty and meets every S-line."""
    sup = FACES[face]
    A_ub, b_ub = [], []
    for d, v in pattern.items():
        g = dirs[d]
        if v == A:
            A_ub.append(-g); b_ub.append(-eps)
        elif v == B:
            A_ub.append(g); b_ub.append(-eps)
    bounds = [(0, None) if j in sup else (0, 0) for j in range(3)]
    Ss = [dirs[d] for d, v in pattern.items() if v == S] or [None]
    for s in Ss:
        A_eq = [np.ones(3)]; b_eq = [1.0]
        if s is not None:
            A_eq.append(s); b_eq.append(0.0)
        res = linprog(np.zeros(3), A_ub=np.array(A_ub) if A_ub else None,
                      b_ub=np.array(b_ub) if b_ub else None,
                      A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=bounds, method='highs')
        if res.status != 0:
            return False
    return True


class Cells:
    def __init__(self, dirs, classes, R):
        self.dirs, self.classes = dirs, classes
        Rs = R if isinstance(R, (list, tuple)) else [R] * len(dirs)
        self.pieces = [(d, h) for d in range(len(dirs)) for h in range(Rs[d])]
        self.n = len(self.pieces)
        self.pcls = [classes[d] for d, h in self.pieces]
        self.records = list(itertools.product(range(7), repeat=self.n))
        self.idx = {r: i for i, r in enumerate(self.records)}
        self.N = len(self.records)
        self.delta = np.zeros((3, self.n, 7), dtype=int)
        for w in range(3):
            for p in range(self.n):
                for c in range(1, 7):
                    o, nw = PAIRS[c - 1]
                    self.delta[w, p, c] = rank(w, self.pcls[p], nw) - rank(w, self.pcls[p], o)
        arr = np.array(self.records)
        self.kind = np.zeros((3, self.N), dtype=int)   # 0 trivial, 1 W (worsening), 2 I, 3 M
        for w in range(3):
            pos = np.zeros(self.N, bool); neg = np.zeros(self.N, bool)
            for p in range(self.n):
                dd = self.delta[w, p][arr[:, p]]
                pos |= dd > 0; neg |= dd < 0
            self.kind[w] = np.where(pos & neg, 3, np.where(pos, 1, np.where(neg, 2, 0)))
        invcode = [0] + [CODE[(n_, o)] for (o, n_) in PAIRS]
        self.inv = np.array([self.idx[tuple(invcode[c] for c in r)] for r in self.records])
        # realisability of old sides, per face (cached by line-pattern)
        cache = {}
        self.faces = []          # list of face-name tuples per record
        self.newfaces = []
        for r in self.records:
            self.faces.append(self._faces(r, 0, cache))
            self.newfaces.append(self._faces(r, 1, cache))

    def side(self, r, which):
        """line pattern of old (which=0) or new (which=1) side on the support; None if not conic."""
        need = {}
        for p, c in enumerate(r):
            if c:
                d = self.pieces[p][0]; v = PAIRS[c - 1][which]
                if need.get(d, v) != v:
                    return None
                need[d] = v
        return need

    def _faces(self, r, which, cache):
        pat = self.side(r, which)
        if not pat:
            return ()
        key = tuple(sorted(pat.items()))
        if key not in cache:
            cache[key] = tuple(f for f in FACES if realisable(pat, self.dirs, f))
        return cache[key]

    def compose_piece(self, c1, c2):
        if c1 == 0:
            return c2
        if c2 == 0:
            return c1
        o1, n1 = PAIRS[c1 - 1]; o2, n2 = PAIRS[c2 - 1]
        if n1 != o2:
            return None
        return 0 if o1 == n2 else CODE[(o1, n2)]

    def compose(self, r1, r2):
        out = []
        for c1, c2 in zip(self.records[r1], self.records[r2]):
            c = self.compose_piece(c1, c2)
            if c is None:
                return None
            out.append(c)
        return self.idx[tuple(out)]

    def pairs(self):
        opts = [(c1, c2, self.compose_piece(c1, c2)) for c1 in range(7) for c2 in range(7)]
        opts = [o for o in opts if o[2] is not None]
        for combo in itertools.product(opts, repeat=self.n):
            yield (self.idx[tuple(x[0] for x in combo)], self.idx[tuple(x[1] for x in combo)],
                   self.idx[tuple(x[2] for x in combo)])

    def leq_line(self, d1, d2):
        g1, g2 = self.dirs[d1], self.dirs[d2]
        k = self.classes[d1]
        z = lambda g: [(-g[k]) / (-g[k] + g[j]) for j in range(3) if j != k]
        return all(a <= b + 1e-12 for a, b in zip(z(g1), z(g2)))

    def inverted(self, r):
        if not any(r):
            return False
        lines = {}
        for p, c in enumerate(r):
            if c:
                o, nw = PAIRS[c - 1]
                if o != S or nw not in (A, B):
                    return False
                d = self.pieces[p][0]
                lines.setdefault(self.classes[d], {A: set(), B: set()})[nw].add(d)
        for k, s in lines.items():
            if not s[A] or not s[B]:
                return False
            if not all(self.leq_line(b, a) for b in s[B] for a in s[A]):
                return False
        return True

    def show(self, r):
        return ' '.join('.' if c == 0 else VN[PAIRS[c - 1][0]] + '>' + VN[PAIRS[c - 1][1]]
                        for c in self.records[r])


def t1_silent(g, eps=Fr(3, 10)):
    """is T1 = D_M (M = c1 + eps*Delta) silent on direction g?"""
    c = (1 - eps) / 3
    vals = [sum((c + (eps if i == j else 0)) * g[i] for i in range(3)) for j in range(3)]
    return min(vals) < 0 < max(vals)
