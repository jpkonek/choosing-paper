"""PP29 Theorem 4.1 on cells (CHECKED): for every inverted departure d in T1's silence and EVERY
intermediate model Q (all 3^n regular patterns), the explicit assignment

   realisable piece whose old side is A on all of D^A  -> accepted exactly at the two opponents
   realisable piece whose old side is B on all of D^B  -> accepted exactly at the owner
   realisable piece with neither mark                   -> its guidance-forced worlds, or any
                                                           admissible world if none
   non-realisable piece                                 -> exactly its guidance-forced worlds

(i) accepts every weak pure worsening, (ii) refuses every pure improvement, (iii) meets every
SUPPORT-SENSITIVE obligation of a maximal selection (for each face F of the simplex on which a
coherent D_K, K inside F, realises the old side: some accepting world lies in F), and
(iv) never accepts x and y at a common world.  T1 (eps = 3/10) supplies the context values.
Lines may lie in all three classes, so padding can sit off M_k.
Usage: python3 -B single_d_check.py"""
import itertools
from fractions import Fraction as Fr
import numpy as np
from lib29 import direction, realisable, FACES, rank, A, S, B, VN

EPS = Fr(3, 10)


def t1_value(g):
    c = (1 - EPS) / 3
    vals = [sum((c + (EPS if i == j else 0)) * Fr(g[i]).limit_denominator(10**6) for i in range(3))
            for j in range(3)]
    if min(vals) > 0: return A
    if max(vals) < 0: return B
    return S


CONFIGS = {
    'k1_steep':  [(0, .55, .55), (0, .65, .65), (0, .40, .95), (0, .95, .40)],
    'k1_mixed':  [(0, .55, .55), (0, .65, .65), (0, .40, .95), (1, .50, .60), (2, .60, .50)],
    'k1_answer': [(0, .55, .55), (0, .65, .65), (0, .20, .20), (0, .90, .90), (1, .30, .30)],
    'k2_steep':  [(1, .55, .55), (1, .65, .65), (1, .40, .95), (0, .60, .60), (2, .10, .10)],
    # radial splits (repeated directions = two radial pieces of one line): many departures,
    # radial interleaving included
    'k1_radial': [(0, .55, .55), (0, .55, .55), (0, .65, .65), (0, .65, .65), (0, .40, .95), (1, .50, .60)],
    'k1_three':  [(0, .50, .50), (0, .60, .60), (0, .70, .70), (0, .40, .95), (0, .95, .40), (0, .70, .45)],
}


def run(name, spec, R=1):
    dirs = [direction(c, a, b) for c, a, b in spec]
    cls = [c for c, a, b in spec]
    n = len(dirs)
    T = [t1_value(g) for g in dirs]
    zc = lambda d: [(-dirs[d][cls[d]]) / (-dirs[d][cls[d]] + dirs[d][j]) for j in range(3) if j != cls[d]]
    leq = lambda a, b: cls[a] == cls[b] and all(x <= y + 1e-12 for x, y in zip(zc(a), zc(b)))
    cache = {}
    def faces(pat):
        if not pat: return ()
        key = tuple(sorted(pat.items()))
        if key not in cache:
            cache[key] = tuple(f for f in FACES if realisable(pat, dirs, f))
        return cache[key]
    def changes(old, new, w):
        dl = [rank(w, cls[i], new[i]) - rank(w, cls[i], old[i]) for i in range(n) if old[i] != new[i]]
        return any(v > 0 for v in dl), any(v < 0 for v in dl)
    sil = [i for i in range(n) if T[i] == S]
    ndep = npairs = nreal2 = 0
    bad = []
    for k in range(3):
        lines = [i for i in sil if cls[i] == k]
        for sub in itertools.product((None, A, B), repeat=len(lines)):
            DA = [l for l, v in zip(lines, sub) if v == A]; DB = [l for l, v in zip(lines, sub) if v == B]
            if not DA or not DB or not all(leq(b, a) for b in DB for a in DA): continue
            ndep += 1
            Td = list(T)
            for l in DA: Td[l] = A
            for l in DB: Td[l] = B
            opp = [w for w in range(3) if w != k]
            for Q in itertools.product((A, S, B), repeat=n):
                Q = list(Q)
                if Q == Td or Q == T: continue
                npairs += 1
                pcs = []
                for old, new in ((Td, Q), (Q, T)):
                    pat = {i: old[i] for i in range(n) if old[i] != new[i]}
                    fs = faces(pat)
                    G = {w for w in range(3) if changes(old, new, w) == (True, False)}
                    I = {w for w in range(3) if changes(old, new, w) == (False, True)}
                    adm = set(range(3)) - I
                    markA = fs and all(pat.get(l) == A for l in DA)
                    markB = fs and all(pat.get(l) == B for l in DB)
                    pcs.append(dict(pat=pat, fs=fs, G=G, I=I, adm=adm, mA=markA, mB=markB))
                x, y = pcs
                if x['fs'] and y['fs']: nreal2 += 1
                # assignment
                for p, q in ((x, y), (y, x)):
                    if p['mA'] and p['mB']: bad.append((name, 'double mark', p['pat'])); p['acc'] = set()
                    elif p['mA']: p['acc'] = set(opp)
                    elif p['mB']: p['acc'] = {k}
                    elif not p['fs']: p['acc'] = set(p['G'])
                for p, q in ((x, y), (y, x)):
                    if 'acc' not in p:   # realisable, unmarked: partner is non-realisable (G-only)
                        p['acc'] = set(p['G'])
                        cand = [set(c) | p['G'] for r_ in range(0, 4)
                                for c in itertools.combinations(sorted(p['adm']), r_)]
                        for c in cand:
                            if c <= p['adm'] and not (c & q.get('acc', set())) and \
                                    all(c & set(FACES[f]) for f in p['fs']):
                                p['acc'] = c; break
                for p in (x, y):
                    if not p['G'] <= p['acc']: bad.append((name, 'guidance', p['pat']))
                    if p['acc'] & p['I']: bad.append((name, 'improvement', p['pat']))
                    for f in p['fs']:
                        if not (p['acc'] & set(FACES[f])): bad.append((name, 'obligation ' + f, p['pat']))
                if x['acc'] & y['acc']: bad.append((name, 'collision', x['pat'], y['pat']))
    print(f'{name}: lines {len(dirs)} (T1 values {"".join(VN[t] for t in T)}), inverted departures {ndep}, '
          f'decompositions {npairs}, both pieces realisable {nreal2}, failures {len(bad)}')
    for b in bad[:10]:
        print('   ', b)
    return len(bad)


if __name__ == '__main__':
    tot = sum(run(k, v) for k, v in CONFIGS.items())
    print('ALL PASS' if tot == 0 else f'FAILURES: {tot}')
