"""PP29 cell SAT (CHECKED on cells): can EVERY inverted departure in T's silence be accepted at
EVERY world (T weakly dominates all its inverted rivals, strictly somewhere) when the
defence obligations are the SUPPORT-SENSITIVE ones of a maximal selection, with full (TC)
(P1/P2 over all composable pairs), strict (G), steep padding lines present?

Obligation modes
  sel   : for every record and every face F (interior, three edges, three vertices) on which
          SOME coherent D_K with K inside F realises the old side, the record is accepted at
          some world of F.  This is the MOST demanding selection: it assumes every realisable
          pattern is selected at an index of every face where it could be.  Any actual selection
          has a subset of these clauses, so SAT here is SAT for every selection.
  univ  : PP23's universal covering: accepted at some world if the old side is coherent.
  omega : univ, plus PP23's Omega-subset restriction (accept at w only if Omega_w >=lex 0),
          departures exempt.  (Sanity check: reproduces Prop 4.7's UNSAT when B-heavy.)
Extra (S)-consequences (flags): undom = every coherent-old record whose reverse is accepted at
all worlds is accepted at all worlds (selected models undominated); dirC = no all-world tie
across a record whose new side is not coherent-realisable; strict = d^-1 refused at every
world (what PP29 Lemma 2.3 gives once T also dominates the enlargements of d).

Usage: python3 -B forced_sat.py <config> <mode> [undom] [dirC]"""
import sys, time
from fractions import Fraction as Fr
import numpy as np
from pysat.solvers import Cadical153
from lib29 import Cells, direction, PAIRS, rank, A, S, B, t1_silent, FACES

# lines of class M_1 (index 0) by (z12, z13); all chosen to meet T1's credal set (T silent)
L = {
    'lB': (0.55, 0.55),   # low line (B-part of d)
    'lA': (0.65, 0.65),   # high line (A-part of d)
    'F':  (0.40, 0.95),   # steep padding: z12 < lB - eps, z13 > lA + eps  (Prop 4.7 / P2)
    'G':  (0.95, 0.40),   # mirror-steep line
    'lS': (0.70, 0.45),   # crossing line (incomparable with lA), low line of a second departure
    'lT': (0.75, 0.50),   # above lS
}
CONF = {
    'C1': (['lB', 'lA', 'F'], [2, 2, 1]),            # Prop 4.7 geometry, radial split
    'C2': (['lB', 'lA', 'lS', 'lT', 'F'], 1),        # two departures + steep padding
    'C3': (['lB', 'lA', 'F', 'G'], [2, 1, 1, 1]),    # both steep directions
    'C4': (['lB', 'lA', 'F', 'G', 'lS'], 1),
    'C0': (['lB', 'lA', 'F'], 1),
    'C5': (['lB', 'lA', 'mB', 'mA', 'F'], 1),
    'C1noF': (['lB', 'lA'], [2, 2]),                    # control: C1 without the steep padding line          # departures in two classes (M_1 and M_2)
}
CLS = {'mB': 1, 'mA': 1}                               # lines of class M_2 (same coordinates)
L.update({'mB': (0.55, 0.55), 'mA': (0.65, 0.65)})


def main(name, mode, flags):
    t0 = time.time()
    names, R = CONF[name]
    dirs = [direction(CLS.get(k, 0), *L[k]) for k in names]
    sil = [t1_silent([Fr(x).limit_denominator(10**6) for x in g]) for g in dirs]
    m = Cells(dirs, [CLS.get(k, 0) for k in names], R)
    N = m.N
    print(f'config {name} lines {names} R={R} T1-silent={sil}; mode={mode} flags={flags}')
    # masses (only used in omega mode): B-heavy on lB, light on lA, padding on F
    mass = []
    for d, h in m.pieces:
        mass.append({'lB': Fr(3), 'lA': Fr(1)}.get(names[d], Fr(2)))
    var = lambda w, r: int(1 + w * N + r)
    s = Cadical153()
    nclauses = 0
    def add(c):
        nonlocal nclauses
        s.add_clause([int(x) for x in c]); nclauses += 1
    triv = m.idx[tuple([0] * m.n)]
    inv_dep = [r for r in range(N) if m.inverted(m.records[r])]
    dep_set = set(inv_dep)
    def omega_ok(w, r):
        per = []
        for p, c in enumerate(m.records[r]):
            if c == 0: per.append(Fr(0)); continue
            o, nw = PAIRS[c - 1]; cls = m.pcls[p]
            wt = 2 if cls == w else 1
            per.append(wt * mass[p] * (rank(w, cls, nw) - rank(w, cls, o)))
        return (sum(per),) + tuple(per) >= tuple([Fr(0)] * (m.n + 1))
    for w in range(3):
        for r in range(N):
            k = m.kind[w, r]
            if r == triv or k == 1: add([var(w, r)])
            elif k == 2: add([-var(w, r)])
            elif mode == 'omega' and r not in dep_set and not omega_ok(w, r): add([-var(w, r)])
    nob = 0
    for r in range(N):
        fs = m.faces[r]
        if not fs: continue
        use = fs if mode == 'sel' else [f for f in fs if f == 'int']
        for f in use:
            add([var(w, r) for w in FACES[f]]); nob += 1
    if 'undom' in flags:
        for r in range(N):
            if m.faces[r] and r != triv:
                ri = int(m.inv[r])
                for w0 in range(3):
                    add([-var(w, ri) for w in range(3)] + [var(w0, r)])
    if 'dirC' in flags:
        for r in range(N):
            if m.faces[r] and r != triv and not m.newfaces[r]:
                ri = int(m.inv[r])
                add([-var(w, r) for w in range(3)] + [-var(w, ri) for w in range(3)])
    np1 = np2 = 0
    for i1, i2, i12 in m.pairs():
        if i12 == triv: continue
        for w in range(3):
            if m.kind[w, i1] != 3 or m.kind[w, i2] != 3: continue
            k12 = m.kind[w, i12]
            if k12 == 2:
                add([-var(w, i1), -var(w, i2)]); np1 += 1
            elif k12 == 3:
                i3 = int(m.inv[i12])
                base = [-var(w, i1), -var(w, i2), -var(w, i3)]
                for j in (int(m.inv[i1]), int(m.inv[i2]), i12):
                    add(base + [var(w, j)])
                np2 += 1
    for d in inv_dep:
        di = int(m.inv[d])
        add([-var(w, di) for w in range(3)])     # T.d is incoherent: no all-world tie (direct (C))
        if 'strict' in flags:                     # Lemma 2.3 (enlargement): d^-1 refused at every world
            for w in range(3): add([-var(w, di)])
    ass = [var(w, d) for d in inv_dep for w in range(3)]
    res = s.solve(assumptions=ass)
    print(f'  pieces {m.n}, records {N}, inverted departures {len(inv_dep)}, obligation clauses {nob}, '
          f'P1 {np1}, P2 {np2}, clauses {nclauses}')
    print(f'  all inverted departures accepted at every world: {"SAT" if res else "UNSAT"} '
          f'({time.time()-t0:.0f}s)')
    if res:
        model = set(x for x in s.get_model() if x > 0)
        acc = lambda r: ''.join(str(w + 1) for w in range(3) if var(w, r) in model) or '-'
        refd = lambda r: ''.join(str(w + 1) for w in range(3) if var(w, r) not in model)
        for d in inv_dep:
            print(f'    d = {m.show(d)} ; d^-1 refused at worlds {refd(int(m.inv[d]))}')
        # every decomposition x.y = d^-1 with both pieces realisable: report verdicts
        print('  decompositions x.y = d^-1 with both old sides coherent-realisable (faces listed):')
        shown = 0
        for d in inv_dep:
            dinv = int(m.inv[d])
            for x in range(N):
                if x == triv or x == dinv or not m.faces[x]: continue
                y = m.compose(int(m.inv[x]), dinv)
                if y is None or y == triv or not m.faces[y]: continue
                if shown < 40:
                    print(f'    d={m.show(d)} | x={m.show(x)} [{",".join(m.faces[x])}] acc {acc(x)}'
                          f' | y={m.show(y)} [{",".join(m.faces[y])}] acc {acc(y)}')
                shown += 1
        print(f'    ({shown} such decompositions in total)')
        # rule sigma (PP29 Thm 4.1): B-pieces only at the owner (world 1), A-pieces only at the
        # opponents (2,3); and the mirror rule sigma'.  Imposed on ALL realisable-pair pieces of
        # ALL departures at once (the multi-departure test of the single-departure rule).
        def mark(r, d):
            rec = m.records[r]; dr = m.records[d]
            oldA = all(rec[p] and PAIRS[rec[p]-1][0] == A for p, c in enumerate(dr) if c and PAIRS[c-1][1] == A)
            oldB = all(rec[p] and PAIRS[rec[p]-1][0] == B for p, c in enumerate(dr) if c and PAIRS[c-1][1] == B)
            return 'A' if oldA else ('B' if oldB else '?')
        marks = {}
        for d in inv_dep:
            if len({m.pcls[p] for p, c in enumerate(m.records[d]) if c}) > 1:
                continue   # sigma is defined for one-class departures only (Theorem 4.1)
            dinv = int(m.inv[d])
            for x in range(N):
                if x == triv or x == dinv or not m.faces[x]: continue
                y = m.compose(int(m.inv[x]), dinv)
                if y is None or y == triv or not m.faces[y]: continue
                kd = m.pcls[next(p for p, c in enumerate(m.records[d]) if c)]
                for r in (x, y):
                    marks.setdefault(r, set()).add((mark(r, d), kd))
        both = [r for r, v in marks.items() if len(v) > 1]
        print(f'  records carrying two different (mark, owner) labels from different departures: {len(both)}')
        for r in both[:5]:
            print('     e.g.', m.show(r), '[' + ','.join(m.faces[r]) + ']')
        for label, own in (('sigma (B-pieces at owner, A-pieces at opponents)', 'B'),
                           ("sigma' (A-pieces at owner, B-pieces at opponents)", 'A')):
            extra = []
            for r, v in marks.items():
                if len(v) != 1 or not v <= {('A', k) for k in range(3)} | {('B', k) for k in range(3)}:
                    continue
                (mk, kk), = v
                if mk == own: extra += [-var(w, r) for w in range(3) if w != kk]
                else: extra += [-var(kk, r)]
            ok = s.solve(assumptions=ass + extra)
            print(f'  imposing {label} on single-mark pieces: {"SAT" if ok else "UNSAT"}')
        # targeted forced-verdict check: whole-line pieces touching the padding line F (if any)
        if 'F' in names:
            fl = names.index('F')
            fpieces = [p for p, (d, h) in enumerate(m.pieces) if d == fl]
            tgt = [r for r in marks if all(m.records[r][p] for p in fpieces)][:60]
            forced = []
            for r in tgt:
                for w in range(3):
                    if m.kind[w, r] == 3 and not s.solve(assumptions=ass + [-var(w, r)]):
                        forced.append((m.show(r), w + 1))
            print(f'  forced acceptances among {len(tgt)} padding pieces on F:', forced or 'none')
    sys.stdout.flush()


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], sys.argv[3:])
