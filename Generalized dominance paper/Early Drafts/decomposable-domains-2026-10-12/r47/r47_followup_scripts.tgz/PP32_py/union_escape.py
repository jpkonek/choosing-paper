"""PP32 union_escape.py -- exact check of the Bayes-level escape for unions of endorsers (§6.1).

Family at each world: {Omega_w, S0_w}, Omega_w = 2 on M_w and 1 elsewhere, S0_w = |g_w|.
 (a) At lambda = u, every non-contradictory answer has the same Omega-cost on each mixed
     problem, and the correct answer is the unique minimiser on unanimous problems.
     Hence T1 (indeed every regular model) is pointwise Omega-Bayes at u.
 (b) For r on the edge [e_1,e_2], D_r's answer minimises r_1|g_1| rank_1 + r_2|g_2| rank_2,
     i.e. D_r is S_0-Bayes at weights (r_1, r_2, 0).
So the necessary (Bayes-level) consequences of 'each accepted comparison is endorsed by
SOME member of the family' hold for T and for every precise edge model at once.
Run: python3 -I -B union_escape.py > union_escape.out
"""
import random
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from lib import DK_answer, rank, minority, sgn

random.seed(3202)
ANS = [1, -1, 0, 'X']
fails = 0
na = nb = 0
for _ in range(20000):
    g = tuple(F(random.randint(-999, 999), 101) for _ in range(3))
    if 0 in [sgn(x) for x in g]:
        continue
    k = minority(g)
    om = [2 if (k is not None and w == k) else 1 for w in range(3)]
    cost = {a: sum(F(1, 3) * om[w] * rank(a, g, w) for w in range(3)) for a in ANS}
    regular = [cost[1], cost[-1], cost[0]]
    if k is not None:
        if len(set(regular)) != 1 or cost['X'] <= regular[0]:
            fails += 1
            print("FAIL (a) mixed", g)
    else:
        corr = 1 if g[0] > 0 else -1
        if any(cost[a] <= cost[corr] for a in ANS if a != corr):
            fails += 1
            print("FAIL (a) unanimous", g)
    na += 1
    x = F(random.randint(1, 999), 1000)
    r = (x, 1 - x, F(0))
    a_r = DK_answer([r], g)
    if a_r is None:
        continue
    cost2 = {a: r[0] * abs(g[0]) * rank(a, g, 0) + r[1] * abs(g[1]) * rank(a, g, 1) for a in ANS}
    if cost2[a_r] > min(cost2.values()):
        fails += 1
        print("FAIL (b)", r, g)
    nb += 1
print(f"(a) {na} problems; (b) {nb} (problem, edge point) pairs")
print("ALL PASS" if fails == 0 else f"{fails} FAILURES")
