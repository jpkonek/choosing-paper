"""PP32 seam_witness_mc.py -- NUMERICS illustration of the two explicit witnesses (§4).

eps = 3/10, r = (1/2,1/2,0) (tau_r = 1), edge model C = D_r.  Three small cones:
  A1 around (1,-1.15,-0.15)  in Sil(T) n M_1, theta > 1   (C rejects g: 2-correct)
  A2 around (1,-0.85, 0.15)  in Sil(T) n M_2, theta < 1   (C accepts g: 1-correct)
  A3 around (1, 1, -2)       in Sil(T) n M_3
Each rival changes a fraction f_i of A_i (Lyapunov: any fraction of the vector
measure is realised by a subset).  Values are int rho_w (r_w(new) - r_w(old)) dmu.

 (1) Field Omega (rho_w = 2 on M_w, 1 elsewhere; T is u-Bayes, balanced).
     Threshold swap out of C: A1 -> 1-correct, A2 -> 2-correct.  Expect a choice of
     (f1,f2) with negative value at worlds 1 AND 2.  (Theorem 4.1(b).)
     Control: T's majority fill has values summing to 0 (never negative at all 3).
 (2) Field S_0 (rho_w = |g_w|; D_r is S_0-Bayes at weights (1/2,1/2)).
     Majority fill out of T on A1, A2, A3.  Expect fractions with negative value at
     all three worlds.  (Theorem 4.1(a).)
     Control: the threshold swap out of C has a nonnegative value at world 1 or 2.
Monte Carlo with 4e6 Gaussian samples; standard errors reported.  No proof uses this.
Run: python3 -I -B seam_witness_mc.py > seam_witness_mc.out
"""
import numpy as np

rng = np.random.default_rng(32)
eps = 0.3
c = (1 - eps) / 3
N = 4_000_000
G = rng.standard_normal((N, 3))


def silent(g):
    s = g.sum(1)
    lo = c * s + eps * g.min(1)
    hi = c * s + eps * g.max(1)
    return (lo < 0) & (hi > 0)


def cone(center, ang):
    d = np.array(center, float)
    d /= np.linalg.norm(d)
    cosang = np.abs(G @ d) / np.linalg.norm(G, axis=1)
    return cosang > np.cos(ang)


# orient every sample so that g_1 > 0 (problems are modulo sign)
G *= np.sign(G[:, :1])
sil = silent(G)
th = np.abs(G[:, 1]) / np.abs(G[:, 0])
s = np.sign(G)
M1 = (s[:, 1] < 0) & (s[:, 2] < 0)          # g_1 > 0 minority
M2 = (s[:, 1] < 0) & (s[:, 2] > 0)          # g_2 < 0 alone: g_2 minority
M3 = (s[:, 1] > 0) & (s[:, 2] < 0)          # g_3 < 0 alone: g_3 minority
A1 = cone((1, -1.15, -0.15), 0.05) & sil & M1 & (th > 1)
A2 = cone((1, -0.85, 0.15), 0.05) & sil & M2 & (th < 1)
A3 = cone((1, 1, -2), 0.05) & sil & M3
print("sample counts:", A1.sum(), A2.sum(), A3.sum())

cls = np.where(M1, 0, np.where(M2, 1, np.where(M3, 2, -1)))
rho_om = np.ones((N, 3))
for w in range(3):
    rho_om[cls == w, w] = 2.0
rho_s0 = np.abs(G)


def I(rho, A, w):
    v = rho[:, w] * A
    return v.mean(), v.std() / np.sqrt(N)


def table(rho, name):
    out = {}
    for nm, A in (("A1", A1), ("A2", A2), ("A3", A3)):
        out[nm] = [I(rho, A, w) for w in range(3)]
        print(f"  {name} {nm}: " + ", ".join(f"I_{w+1}={m:.6f}(+-{e:.6f})" for w, (m, e) in enumerate(out[nm])))
    return {k: [m for m, _ in v] for k, v in out.items()}


fails = 0
grid = np.linspace(0, 1, 201)

# (1) Omega, threshold swap out of D_r: on A1 2-correct -> 1-correct: d = (-2*rho1, +2*rho2)
#                                          on A2 1-correct -> 2-correct: d = (+2*rho1, -2*rho2)
print("(1) field Omega")
I_om = table(rho_om, "Omega")
best = None
for f1 in grid:
    for f2 in grid:
        v1 = 2 * (f2 * I_om["A2"][0] - f1 * I_om["A1"][0])
        v2 = 2 * (f1 * I_om["A1"][1] - f2 * I_om["A2"][1])
        m = max(v1, v2)
        if best is None or m < best[0]:
            best = (m, f1, f2, v1, v2)
print(f"  swap out of D_r: best f1={best[1]:.3f}, f2={best[2]:.3f}: values w1={best[3]:.6f}, w2={best[4]:.6f}")
if not best[0] < 0:
    fails += 1
    print("  FAIL: no swap negative at both edge worlds")
# control: T majority fill under Omega, values sum to zero
f = (0.5, 0.5, 0.5)
dmaj = {"A1": (+1, -1, -1), "A2": (-1, +1, -1), "A3": (-1, -1, +1)}
vals = [sum(fi * dmaj[k][w] * I_om[k][w] for fi, k in zip(f, ("A1", "A2", "A3"))) for w in range(3)]
print(f"  control, majority fill of T (f=1/2 each): values {[round(float(v), 6) for v in vals]}, sum {sum(vals):.2e}")

# (2) S_0, majority fill out of T
print("(2) field S_0")
I_s0 = table(rho_s0, "S_0")
best = None
for f1 in grid:
    for f2 in grid:
        for f3 in grid[:41]:
            vals = [sum(fi * dmaj[k][w] * I_s0[k][w] for fi, k in zip((f1, f2, f3), ("A1", "A2", "A3"))) for w in range(3)]
            m = max(vals)
            if best is None or m < best[0]:
                best = (m, (f1, f2, f3), vals)
print(f"  majority fill out of T: best f={tuple(round(float(x), 3) for x in best[1])}: values {[round(float(v), 7) for v in best[2]]}")
if not best[0] < 0:
    fails += 1
    print("  FAIL: no majority fill negative at all worlds")
# control: swap out of D_r under S_0 is nonnegative at world 1 or 2 for every (f1,f2)
worst = min(max(2 * (f2 * I_s0["A2"][0] - f1 * I_s0["A1"][0]), 2 * (f1 * I_s0["A1"][1] - f2 * I_s0["A2"][1]))
            for f1 in grid for f2 in grid)
print(f"  control, swap out of D_r: min over fractions of max(w1,w2) value = {worst:.2e} (>= 0 expected)")
if worst < -1e-6:
    fails += 1
    print("  FAIL: control")
print("ALL PASS" if fails == 0 else f"{fails} FAILURES")
