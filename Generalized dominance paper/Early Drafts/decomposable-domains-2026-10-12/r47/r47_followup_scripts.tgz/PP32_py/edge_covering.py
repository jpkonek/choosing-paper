"""PP32 edge_covering.py -- exact checks of the pointwise comparisons in Lemma 2.2.

Lemma 2.2: if K = [k0,k1] lies in the edge [e_1,e_2] (first coordinates x0 <= x1) and
r = (x,1-x,0) is not in K, then D_r is pointwise no worse than D_K at world 2 when
x < x0, and at world 1 when x > x1, strictly better on a non-null set; and D_r, D_K
agree off W_12 = {g_1 g_2 < 0}.  Also Lemma 2.1(ii): if m in K has m_3 > 0, D_K fails
to accept g = (d, d, -1) for small d > 0, a problem where worlds 1 and 2 agree.
Random rational K, r and g (all classes, including U and M_3).
Run: python3 -I -B edge_covering.py > edge_covering.out
"""
import random
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from lib import DK_answer, rank, sgn

random.seed(3201)
fails = 0
n_pairs = 0
n_pts = 0
strict_hits = 0


def rq(lo, hi, den=997):
    return F(random.randint(int(lo * den), int(hi * den)), den)


for trial in range(300):
    a, b = sorted([rq(0.01, 0.99), rq(0.01, 0.99)])
    if a == b:
        continue
    K = [(a, 1 - a, F(0)), (b, 1 - b, F(0))]
    # r outside K, below or above
    if random.random() < 0.5 and a > F(2, 100):
        x = rq(0.005, float(a) - 0.001)
        w = 1  # world 2 (index 1)
    elif b < F(98, 100):
        x = rq(float(b) + 0.001, 0.995)
        w = 0  # world 1 (index 0)
    else:
        continue
    if x <= 0 or x >= 1 or (a <= x <= b):
        continue
    r = [(x, 1 - x, F(0))]
    n_pairs += 1
    strict = 0
    for _ in range(400):
        g = tuple(F(random.randint(-500, 500), 97) for _ in range(3))
        A_K, A_r = DK_answer(K, g), DK_answer(r, g)
        if A_K is None or A_r is None or 0 in [sgn(v) for v in g]:
            continue
        n_pts += 1
        if g[0] * g[1] > 0:  # off W_12
            if A_K != A_r:
                fails += 1
                print("FAIL off-W12 disagreement", K, r, g)
            continue
        rk, rr = rank(A_K, g, w), rank(A_r, g, w)
        if rr > rk:
            fails += 1
            print("FAIL D_r worse at predicted world", K, r, g, w)
        if rr < rk:
            strict += 1
    if strict == 0:
        print("note: no strict point sampled for pair", K, r)
    strict_hits += (strict > 0)

# Lemma 2.1(ii)
n_ii = 0
for _ in range(2000):
    m = [F(random.randint(1, 1000)) for _ in range(3)]
    s = sum(m)
    m = tuple(v / s for v in m)
    d = m[2] / (2 * (m[0] + m[1]))
    g = (d, d, F(-1))
    if DK_answer([m], g) == 1:
        fails += 1
        print("FAIL (ii)", m)
    n_ii += 1

print(f"pairs (K, r) tested: {n_pairs}; sample points: {n_pts}; "
      f"pairs with a sampled strict improvement: {strict_hits}")
print(f"Lemma 2.1(ii) instances: {n_ii}")
print("ALL PASS" if fails == 0 else f"{fails} FAILURES")
