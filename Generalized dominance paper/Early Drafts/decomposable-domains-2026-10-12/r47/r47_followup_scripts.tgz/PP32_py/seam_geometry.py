"""PP32 seam_geometry.py -- exact checks of the band geometry used in Theorem 3.1.

Worlds are 1,2,3 in the note and 0,1,2 in code.  theta = |g_2|/|g_1| on W_12.
alpha = c/(c+eps), beta = (c+eps)/c.  Claims checked (exact rationals):
 (a) For tau in J = (alpha, beta) (rational grid): the seam ray g* = (1,-tau,0) is
     strictly silent under T1; the nearby points (1,-tau(1+h),-h) lie in Sil(T) n M_1
     with theta > tau, and (1,-tau(1-h),h) lie in Sil(T) n M_2 with theta < tau.
 (b) Sharp ranges: every silent point of M_1 has theta < beta; every silent point of
     M_2 has theta > alpha (random rational points); points approaching the bounds
     are silent.
 (c) tau_r in J  <=>  the segment [r, e_3] meets int M  (r on the edge [e_1,e_2]).
 (d) Sil(T) n M_3 is nonempty (e.g. (1,1,-2)), and T1 gives the minority answer at
     (1,1,-2/c) for these eps (used in Remark 5.3).
Run: python3 -I -B seam_geometry.py > seam_geometry.out
"""
import random
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from lib import T_answer, minority, theta12

random.seed(32)
EPS = [F(1, 10), F(3, 10), F(1, 2), F(9, 10)]
fails = 0


def check(cond, msg):
    global fails
    if not cond:
        fails += 1
        print("FAIL:", msg)


for eps in EPS:
    c = (1 - eps) / 3
    alpha, beta = c / (c + eps), (c + eps) / c
    # (a)
    n_a = 0
    for k in range(1, 40):
        tau = alpha + (beta - alpha) * F(k, 40)
        gs = (F(1), -tau, F(0))
        check(T_answer(gs, eps) == 0, f"seam not silent eps={eps} tau={tau}")
        for h in [F(1, 10**3), F(1, 10**5)]:
            g1 = (F(1), -tau * (1 + h), -h)
            g2 = (F(1), -tau * (1 - h), h)
            check(minority(g1) == 0 and theta12(g1) > tau and T_answer(g1, eps) == 0,
                  f"P1 point eps={eps} tau={tau} h={h}")
            check(minority(g2) == 1 and theta12(g2) < tau and T_answer(g2, eps) == 0,
                  f"P2 point eps={eps} tau={tau} h={h}")
            n_a += 2
    # (b)
    n_b = 0
    for _ in range(20000):
        t = F(random.randint(1, 4000), 1000)
        tp = F(random.randint(1, 4000), 1000)
        g = (F(1), -t, -tp)          # M_1 (g_1 minority)
        if T_answer(g, eps) == 0:
            check(theta12(g) < beta, f"M1 silent with theta>=beta eps={eps} g={g}")
            n_b += 1
        g = (-t, F(1), -tp)          # M_2 (g_2 minority), theta = 1/t
        if T_answer(g, eps) == 0:
            check(theta12(g) > alpha, f"M2 silent with theta<=alpha eps={eps} g={g}")
            n_b += 1
    d = F(1, 10**6)
    check(T_answer((F(1), -(beta - d), -d / 2), eps) == 0, "near-beta point not silent")
    check(T_answer((-(beta - d), F(1), -d / 2), eps) == 0, "near-alpha point not silent")
    # (c)
    n_c = 0
    for k in range(1, 200):
        x = F(k, 200)
        r = (x, 1 - x, F(0))
        tau_r = x / (1 - x)
        in_J = alpha < tau_r < beta
        # (1-l) r + l e3 in int M  <=>  l > c and (1-l)*min(r1,r2) > c, for some l in (0,1)
        mr = min(r[0], r[1])
        lam_max = 1 - c / mr  # need l < lam_max
        meets = lam_max > c
        check(in_J == meets, f"(c) mismatch eps={eps} r={r}")
        n_c += 1
    # (d)
    check(minority((F(1), F(1), F(-2))) == 2 and T_answer((F(1), F(1), F(-2)), eps) == 0,
          "(1,1,-2) not in Sil(T) n M_3")
    check(T_answer((F(1), F(1), -2 / c), eps) == -1, "(1,1,-2/c): T not minority (3-correct)")
    print(f"eps={eps}: alpha={alpha}, beta={beta}; (a) {n_a} seam-side points ok; "
          f"(b) {n_b} silent random points within ranges; (c) {n_c} edge points ok")

print("ALL PASS" if fails == 0 else f"{fails} FAILURES")
