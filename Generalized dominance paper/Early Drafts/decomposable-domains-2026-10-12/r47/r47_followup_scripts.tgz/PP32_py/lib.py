"""PP32 shared helpers (exact rational arithmetic where possible).

Conventions (Brief 47): problems g in R^3 modulo sign; an answer is +1 (accept g),
-1 (accept -g), 0 (silent), 'X' (contradiction).  Rank at world w: correct 0,
silent 1, wrong 2, contradiction 3.  T = T1 = D_M, M = c*1 + eps*Delta = {m : m_w >= c},
c = (1-eps)/3.  D_K for a polytope K with vertex list V accepts g iff min_V m.g > 0.
"""
from fractions import Fraction as F


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def sgn(x):
    return (x > 0) - (x < 0)


def T_answer(g, eps):
    """T1's answer; None on the (null) boundary."""
    c = (1 - eps) / 3
    lo = c * sum(g) + eps * min(g)
    hi = c * sum(g) + eps * max(g)
    if lo > 0:
        return 1
    if hi < 0:
        return -1
    if lo < 0 < hi:
        return 0
    return None


def DK_answer(V, g):
    """Answer of the coherent model D_K, K = conv(V); None on a (null) boundary."""
    vals = [dot(v, g) for v in V]
    if min(vals) > 0:
        return 1
    if max(vals) < 0:
        return -1
    if min(vals) < 0 < max(vals):
        return 0
    return None


def rank(ans, g, w):
    if ans == 'X':
        return 3
    if ans == 0:
        return 1
    return 0 if ans * sgn(g[w]) > 0 else 2


def minority(g):
    """Index k of the minority world (g in M_k), or None if unanimous / degenerate."""
    s = [sgn(x) for x in g]
    if 0 in s:
        return None
    pos = [w for w in range(3) if s[w] > 0]
    neg = [w for w in range(3) if s[w] < 0]
    if len(pos) == 1:
        return pos[0]
    if len(neg) == 1:
        return neg[0]
    return None


def theta12(g):
    """theta = |g_2|/|g_1| (worlds indexed 0,1,2 in code: |g[1]|/|g[0]|)."""
    return abs(F(g[1])) / abs(F(g[0]))
