"""PP31 (referee, round 47). Exact check of PP30 Theorem 3.2 with genuine balls (not atoms). CHECKED.

For p on the 1/12-grid of the closed simplex and eps in {1/10, 3/10, 1/2, 9/10}:
  g_p = (p-u) x 1 (or (1,-1,0) at p = u), t = eps*min(max g, -min g)/2, h+- = +-g_p + t*1.
Exact margins: lo+- = -min_M m.h+-, hi+- = max_M m.h+-, and p.h+- = t.  Since |m|_2 <= 1 on the
simplex, a closed ball of radius r < min(lo, hi, t) about h lies in Sil(T) cap {p.x > 0}.
We take r = min(lo+, lo-, hi+, hi-, t/2)/2 and verify exactly:
  (i) r > 0;  (ii) |h+| = |h-| (so equal radii give equal Gaussian mass);
  (iii) the balls are disjoint modulo sign: |h+ - h-| > 2r and |h+ + h-| > 2r (squared, exact);
  (iv) the proof's lower bound v_w >= mu(B)*(h+_w + h-_w - 2r) = mu(B)*2(t - r) > 0.
Also: Remark 3.6 segment escape, exact on random rational problems (CHECKED on samples).
Run: python3 -I -B pp30_kill_balls_exact.py > pp30_kill_balls_exact.out
"""
from fractions import Fraction as F
import random

ONE = (F(1),) * 3


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


fails = 0; total = 0
for eps in [F(1, 10), F(3, 10), F(1, 2), F(9, 10)]:
    c = (1 - eps) / 3
    Mv = [tuple(c + (eps if i == k else 0) for i in range(3)) for k in range(3)]
    minr = None
    for a in range(13):
        for b in range(13 - a):
            p = (F(a, 12), F(b, 12), F(12 - a - b, 12))
            u = (F(1, 3),) * 3
            pm = tuple(x - y for x, y in zip(p, u))
            g = cross(pm, ONE) if any(pm) else (F(1), F(-1), F(0))
            t = eps * min(max(g), -min(g)) / 2
            hp = tuple(x + t for x in g); hm = tuple(-x + t for x in g)
            ok = dot(g, ONE) == 0 and dot(g, p) == 0 and any(g)
            lo = [-min(dot(m, h) for m in Mv) for h in (hp, hm)]
            hi = [max(dot(m, h) for m in Mv) for h in (hp, hm)]
            ok &= all(x > 0 for x in lo + hi) and dot(p, hp) == t and dot(p, hm) == t and t > 0
            r = min(lo + hi + [t / 2]) / 2
            ok &= r > 0
            ok &= dot(hp, hp) == dot(hm, hm)
            dpm = tuple(x - y for x, y in zip(hp, hm)); spm = tuple(x + y for x, y in zip(hp, hm))
            ok &= dot(dpm, dpm) > 4 * r * r and dot(spm, spm) > 4 * r * r
            ok &= all(hp[w] + hm[w] - 2 * r == 2 * (t - r) for w in range(3)) and t - r > 0
            total += 1; fails += not ok
            minr = r if minr is None or r < minr else minr
    print(f'eps={eps}: 91 grid points, radius bound min r = {minr}; failures so far {fails}')
print(f'Theorem 3.2 with genuine balls: {total} configurations, {fails} failures')

# Remark 3.6 segments: p on line ab outside the open segment escapes with lambda = far endpoint.
random.seed(31)
a = (F(1, 2), F(1, 4), F(1, 4)); b = (F(1, 4), F(1, 2), F(1, 4))
bad = 0; tested = 0
for s in [F(0), F(1, 3), F(1)]:          # p = b + s(b-a), beyond b (s=0: p=b); and mirror beyond a
    for (near, far) in [(b, a), (a, b)]:
        p = tuple(n + s * (n - f) for n, f in zip(near, far))
        if min(p) < 0:
            continue
        for _ in range(4000):
            g = tuple(F(random.randint(-50, 50), 7) for _ in range(3))
            if dot(a, g) * dot(b, g) < 0:           # g in Sil(D_[a,b])
                tested += 1
                if dot(far, g) * dot(p, g) > 0:
                    bad += 1
print(f'Remark 3.6 segment escape: {tested} silent rational problems, (lambda.g)(p.g) > 0 in {bad} cases (expect 0)')
print('ALL PASS' if fails == 0 and bad == 0 else 'FAIL')
