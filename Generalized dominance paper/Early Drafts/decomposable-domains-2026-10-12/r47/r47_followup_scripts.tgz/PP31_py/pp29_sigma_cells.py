"""PP31 (referee, round 47). Independent cell check of PP29 Theorem 4.1 (retreat split sigma).
CHECKED (exact rationals; my own record algebra and realisability test, not lib29).

Cells: pieces = non-null neighbourhoods of single lines (class k, edge coordinates z from e_k).
Values A,S,B,X; ranks at the owner of a piece's class: B0 S1 A2 X3; at the two opponents A0 S1 B2 X3.
Realisability of an old side on a face F by a coherent D_K, K closed convex inside F:
  F = 'int' (any K in the closed simplex; interior indices), 'eij' (K in the closed edge; open-edge
  indices), 'vi' (K = {e_i}).  Feasible region R = F cap {f>0 on A-lines} cap {f<0 on B-lines};
  S on a line needs R to meet both open sides.  Exact LP by vertex enumeration (int), exact
  interval arithmetic (edges), direct evaluation (vertices).
Maximal obligations: for every record and every face on which its old side is realisable, the
accepted set must meet supp(F) (int: all worlds; eij: {i,j}; vi: {i}).
For every inverted departure d in one class and EVERY decomposition x.y = d^-1 (all contexts P with
P = S on D, all intermediate Q, values in {A,S,B,X}), check PP29 Thm 4.1 properties 1-3 for sigma,
with H = (all worlds) minus I(r) for realisable unmarked records.
Run: python3 -I -B pp29_sigma_cells.py > pp29_sigma_cells.out
"""
from fractions import Fraction as F
from itertools import product, combinations
from functools import lru_cache

A, S, B, X = 0, 1, 2, 3
NM = 'ASBX'
eps = F(3, 10); c = (1 - eps) / 3
Mv = [tuple(c + (eps if i == k else 0) for i in range(3)) for k in range(3)]
FACES = {'int': (0, 1, 2), 'e01': (0, 1), 'e02': (0, 2), 'e12': (1, 2), 'v0': (0,), 'v1': (1,), 'v2': (2,)}


def others(k):
    return [x for x in range(3) if x != k]


def fval(piece, m):          # < 0: inside e_k corner (B side), > 0: A side
    k, z = piece[0], piece[1]
    j, l = others(k)
    return m[j] / z[0] + m[l] / z[1] - 1


def rank(world, k, v):
    if v == X:
        return 3
    if world == k:
        return {B: 0, S: 1, A: 2}[v]
    return {A: 0, S: 1, B: 2}[v]


def lp_int(cons):
    """cons: list of (piece, sign) meaning sign*f(m) >= s.  Maximise s over closed simplex, s <= 1.
    Variables (m1, m2, s), m0 = 1 - m1 - m2.  Returns max s (exact)."""
    rows = []   # a1*m1 + a2*m2 + a3*s <= b
    rows += [((-1, 0, 0), 0), ((0, -1, 0), 0), ((1, 1, 0), 1), ((0, 0, 1), 1)]
    for pc, sg in cons:
        # f(m) = alpha0*m0 + alpha1*m1 + alpha2*m2 - 1, with m0 = 1 - m1 - m2
        k, z = pc[0], pc[1]; j, l = others(k)
        al = [F(0)] * 3; al[j] = 1 / z[0]; al[l] = 1 / z[1]
        # f = al0 + (al1-al0) m1 + (al2-al0) m2 - 1 ;  constraint: s - sg*f <= 0
        rows.append(((sg * (al[1] - al[0]) * -1, sg * (al[2] - al[0]) * -1, 1), sg * (al[0] - 1)))
    best = None
    for (r1, r2, r3) in combinations(rows, 3):
        Mx = [list(map(F, r1[0])), list(map(F, r2[0])), list(map(F, r3[0]))]
        bb = [F(r1[1]), F(r2[1]), F(r3[1])]
        sol = solve3(Mx, bb)
        if sol is None:
            continue
        if all(sum(F(a) * x for a, x in zip(rw[0], sol)) <= rw[1] for rw in rows):
            if best is None or sol[2] > best:
                best = sol[2]
    return best


def solve3(Mx, b):
    M = [row[:] + [bi] for row, bi in zip(Mx, b)]
    for col in range(3):
        piv = next((r for r in range(col, 3) if M[r][col] != 0), None)
        if piv is None:
            return None
        M[col], M[piv] = M[piv], M[col]
        for r in range(3):
            if r != col and M[r][col] != 0:
                fct = M[r][col] / M[col][col]
                M[r] = [a - fct * b2 for a, b2 in zip(M[r], M[col])]
    return [M[i][3] / M[i][i] for i in range(3)]


def edge_interval(i, j, cons):
    """K inside closed edge [e_i,e_j], m = (1-th) e_i + th e_j, th in [0,1].  cons: (piece, sign) with
    sign*f > 0 strict.  Returns True iff the set of th is nonempty."""
    lo, lo_open, hi, hi_open = F(0), False, F(1), False
    for pc, sg in cons:
        ei = [F(0)] * 3; ei[i] = F(1); ej = [F(0)] * 3; ej[j] = F(1)
        a = sg * fval(pc, ei); b = sg * fval(pc, ej)   # g(th) = a + (b-a) th > 0
        sl = b - a
        if sl == 0:
            if a <= 0:
                return False
            continue
        root = -a / sl
        if sl > 0:   # th > root
            if root > lo or (root == lo):
                lo, lo_open = root, True
        else:        # th < root
            if root < hi or (root == hi):
                hi, hi_open = root, True
    if lo < hi:
        return True
    return lo == hi and not lo_open and not hi_open


@lru_cache(maxsize=None)
def realisable_on(face, pattern):
    """pattern: tuple of (piece, value) pairs.  Coherent D_K with K in face realises it?"""
    if any(v == X for _, v in pattern):
        return False
    hard = [(pc, 1 if v == A else -1) for pc, v in pattern if v in (A, B)]
    soft = [pc for pc, v in pattern if v == S]
    if face == 'int':
        base = lp_int(hard)
        if base is None or base <= 0:
            return False
        for pc in soft:
            for sg in (1, -1):
                r = lp_int(hard + [(pc, sg)])
                if r is None or r <= 0:
                    return False
        return True
    if face[0] == 'e':
        i, j = int(face[1]), int(face[2])
        if not edge_interval(i, j, hard):
            return False
        for pc in soft:
            for sg in (1, -1):
                if not edge_interval(i, j, hard + [(pc, sg)]):
                    return False
        return True
    i = int(face[1]); e = [F(0)] * 3; e[i] = F(1)
    if soft:
        return False
    return all(sg * fval(pc, e) > 0 for pc, sg in hard)


def analyse(rec, pieces, DA, DB, k):
    """rec: tuple of (piece_index, old, new) sorted.  Returns dict."""
    G = set(); I = set()
    for w in range(3):
        ds = [rank(w, pieces[pi][0], nw) - rank(w, pieces[pi][0], od) for pi, od, nw in rec]
        if all(x > 0 for x in ds):
            G.add(w)
        if all(x < 0 for x in ds):
            I.add(w)
    pat = tuple(sorted((pieces[pi], od) for pi, od, nw in rec))
    faces = [f for f in FACES if realisable_on(f, pat)]
    old = {pi: od for pi, od, nw in rec}
    Am = all(pi in old and old[pi] == A for pi in DA)
    Bm = all(pi in old and old[pi] == B for pi in DB)
    real = 'int' in faces
    j, l = others(k)
    if not real:
        sig = set(G); kind = 'unreal'
    elif Am and Bm:
        sig = None; kind = 'BOTH'      # impossible by Lemma 1.1
    elif Am:
        sig = G | {j, l}; kind = 'A'
    elif Bm:
        sig = G | {k}; kind = 'B'
    else:
        sig = {0, 1, 2} - I; kind = 'unmarked'
    return dict(G=G, I=I, faces=faces, sig=sig, kind=kind)


def inverted(pieces, DA, DB, k):
    return all(pieces[b][0] == k and pieces[a][0] == k and pieces[b][1][0] <= pieces[a][1][0]
               and pieces[b][1][1] <= pieces[a][1][1] for a in DA for b in DB)


def run(name, pieces, k, departures):
    n = len(pieces)
    assert all(inverted(pieces, a, b, k) for a, b in departures), name
    stats = dict(dec=0, both_real=0, fail1=0, fail2=0, fail3=0, both_marks=0, unmarked_real=0)
    cache = {}
    for DA, DB in departures:
        D = set(DA) | set(DB)
        rest = [i for i in range(n) if i not in D]
        for Pv in product(range(4), repeat=len(rest)):
            P = [S] * n
            for i, v in zip(rest, Pv):
                P[i] = v
            Pd = P[:]
            for i in DA:
                Pd[i] = A
            for i in DB:
                Pd[i] = B
            for Q in product(range(4), repeat=n):
                x = tuple((i, Pd[i], Q[i]) for i in range(n) if Pd[i] != Q[i])
                y = tuple((i, Q[i], P[i]) for i in range(n) if Q[i] != P[i])
                if not x or not y:
                    continue
                stats['dec'] += 1
                res = []
                for r in (x, y):
                    key = (r, tuple(DA), tuple(DB))
                    if key not in cache:
                        cache[key] = analyse(r, pieces, DA, DB, k)
                    res.append(cache[key])
                rx, ry = res
                if rx['kind'] == 'BOTH' or ry['kind'] == 'BOTH':
                    stats['both_marks'] += 1
                    continue
                if rx['kind'] != 'unreal' and ry['kind'] != 'unreal':
                    stats['both_real'] += 1
                for rr in res:
                    if rr['kind'] == 'unmarked':
                        stats['unmarked_real'] += 1
                    if not (rr['G'] <= rr['sig'] and not (rr['sig'] & rr['I'])):
                        stats['fail1'] += 1
                    for f in rr['faces']:
                        if not (rr['sig'] & set(FACES[f])):
                            stats['fail2'] += 1
                if rx['sig'] & ry['sig']:
                    stats['fail3'] += 1
    sil = []
    for pc in pieces:
        vals = [fval(pc, m) for m in Mv]
        sil.append('S' if min(vals) < 0 < max(vals) else ('B' if max(vals) < 0 else 'A'))
    print(f'{name}: owner k={k}, pieces {n}, T1 values {"".join(sil)}, inverted departures {len(departures)}, '
          f'decompositions {stats["dec"]}, both pieces realisable {stats["both_real"]}, realisable unmarked pieces '
          f'{stats["unmarked_real"]}, double-marked realisable {stats["both_marks"]}, failures (1,2,3) = '
          f'({stats["fail1"]},{stats["fail2"]},{stats["fail3"]})')
    return stats['fail1'] + stats['fail2'] + stats['fail3'] + stats['both_marks']


def Z(a, b):
    return (F(a), F(b))


lB, lA, lF, lG = Z('0.55', '0.55'), Z('0.65', '0.65'), Z('0.40', '0.95'), Z('0.95', '0.40')
tot = 0
# owner class 0 (world 1 in 1-based numbering)
pcs = [(0, lB, 'lB'), (0, lA, 'lA'), (0, lF, 'F')]
tot += run('k0_steep', pcs, 0, [((1,), (0,))])
pcs = [(0, lB, 'lB'), (0, lA, 'lA'), (0, lF, 'F'), (0, lG, 'G')]
tot += run('k0_both_steep', pcs, 0, [((1,), (0,))])
pcs = [(0, lB, 'lB1'), (0, lB, 'lB2'), (0, lA, 'lA1'), (0, lA, 'lA2'), (0, lF, 'F')]
deps = [(a, b) for a in [(2,), (3,), (2, 3)] for b in [(0,), (1,), (0, 1)]]
tot += run('k0_radial', pcs, 0, deps)
# padding in another class (class 1 line meeting M) and a T-answering line
pcs = [(0, lB, 'lB'), (0, lA, 'lA'), (1, Z('0.5', '0.5'), 'm1'), (0, Z('0.2', '0.2'), 'Tans')]
tot += run('k0_mixed', pcs, 0, [((1,), (0,))])
# owner class 2 (world 3), steep padding in class 2
pcs = [(2, lB, 'lB'), (2, lA, 'lA'), (2, lF, 'F'), (1, Z('0.6', '0.45'), 'm1')]
tot += run('k2_steep', pcs, 2, [((1,), (0,))])
# crossing departures in class 0 (two departures sharing no piece)
lS, lT = Z('0.70', '0.45'), Z('0.75', '0.50')
pcs = [(0, lB, 'lB'), (0, lA, 'lA'), (0, lS, 'lS'), (0, lT, 'lT'), (0, lF, 'F')]
tot += run('k0_two_deps', pcs, 0, [((1,), (0,)), ((3,), (2,))])
print('ALL PASS' if tot == 0 else f'FAILURES {tot}')
