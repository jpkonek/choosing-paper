"""PP31 (referee, round 47). Exact (rational) checks of PP28 geometry. CHECKED.

(1) PP28 Section 4.2 instance: every geometric fact the obligation table uses.
(2) PP28 Section 1 'e1-below' criterion, verified against an exact 2-variable feasibility
    test for random rational point pairs (class 1, and classes 2, 3 via the charts).
(3) PP28 Prop 5.2 type conditions: 1A, 2B, 3B, 1B as stated agree with the exact test;
    the stated 2A and 3A conditions are incomplete (exact counterexample printed).
Run: python3 -I -B pp28_geometry_exact.py > pp28_geometry_exact.out
"""
from fractions import Fraction as F
import random, math

eps = F(3, 10); c = (1 - eps) / 3
Mv = [tuple(c + (eps if i == k else 0) for i in range(3)) for k in range(3)]  # vertices of M
m0 = Mv[1]
E = [(F(1), F(0), F(0)), (F(0), F(1), F(0)), (F(0), F(0), F(1))]


def tv(m, z):            # class-1 line (z12, z13); < 1 : strictly inside e1-triangle (B side)
    return m[1] / z[0] + m[2] / z[1]


def adv(K, z):           # K: list of vertices of a polytope (advice is decided at vertices)
    vals = [tv(m, z) for m in K]
    if all(v < 1 for v in vals):
        return 'B'
    if all(v > 1 for v in vals):
        return 'A'
    return 'S'


def inM(p):
    return all(x >= c for x in p)


out = []
P = out.append
lB, lA, lF, lG = (F(4, 5), F(11, 20)), (F(41, 50), F(57, 100)), (F(1, 2), F(9, 10)), (F(3, 4), F(97, 100))
p1 = (F(3, 10), F(1, 20), F(13, 20)); p2 = (F(1, 10), F(1, 10), F(4, 5))
P('== (1) PP28 Sec 4.2 instance, eps=3/10 ==')
P(f'm0 = {m0} is a vertex of M: {m0 in Mv}; c = {c}')
for nm, z in [('lB', lB), ('lA', lA), ('lF', lF), ('lG', lG)]:
    P(f'  T on {nm}={z}: {adv(Mv, z)};  m0: {adv([m0], z)};  V1,V2,V3: {[adv([e], z) for e in E]}')
P(f'  lB <= lA (line order): {lB[0] <= lA[0] and lB[1] <= lA[1]}')
P(f'  P2 for F: z12(F)={lF[0]} < z12(B)={lB[0]}, z13(F)={lF[1]} > z13(A)={lA[1]}: {lF[0] < lB[0] and lF[1] > lA[1]}')
P(f'  p1={p1} interior, outside M: {all(x > 0 for x in p1) and not inM(p1)}')
P(f'  [m0,p1] on lA: {adv([m0, p1], lA)} ; on lF: {adv([m0, p1], lF)}  (x of Prop 4.7 split needs A, S)')
P(f'  p2={p2} interior, outside M: {all(x > 0 for x in p2) and not inM(p2)}')
P(f'  [m0,p2] on lA: {adv([m0, p2], lA)} ; on lG: {adv([m0, p2], lG)}  (x of the lG route needs A, B)')
P(f'  y needs B on lB: m0 gives {adv([m0], lB)} so no D_[m0,p] and not T gives B there; '
  f'V1 on lF: {adv([E[0]], lF)} (y needs A on F); V2,V3 on lB: {adv([E[1]], lB)},{adv([E[2]], lB)}')
P(f'  margins |tv-1| at the decisive vertices: m0/lB {float(tv(m0, lB) - 1):.4f}, '
  f'p1/lA {float(tv(p1, lA) - 1):.4f}, p1/lF {float(tv(p1, lF) - 1):.4f}, m0/lF {float(tv(m0, lF) - 1):.4f}, '
  f'p2/lG {float(tv(p2, lG) - 1):.4f}, m0/lG {float(tv(m0, lG) - 1):.4f}')

# ---------- (2)/(3): exact feasibility of 'a class-i line with point a strictly in the e_i-corner
# and point b strictly outside'.  Class-i line: -m_i + al*m_j + be*m_l = 0, al, be > 0; corner: < 0.
# Feasible iff exist al, be > 0 with al*a_j/a_i + be*a_l/a_i < 1 < al*b_j/b_i + be*b_l/b_i.
# Exact test: the open set is nonempty iff b_j/b_i > a_j/a_i or b_l/b_i > a_l/a_i (proved in PP31 report);
# we do NOT use that formula here: we search a fine rational grid of (al, be) on a log scale AND test
# the extreme rays, and compare with the stated chart conditions.


def corner_sep(i, a, b):
    """Exact LP: sup of al*rb0+be*rb1 over the open triangle {al,be>0, al*ra0+be*ra1<1}
    equals the max over its closed vertices (0,0),(1/ra0,0),(0,1/ra1); feasible iff > 1."""
    j, l = [x for x in range(3) if x != i]
    ra = (a[j] / a[i], a[l] / a[i]); rb = (b[j] / b[i], b[l] / b[i])
    return max(rb[0] / ra[0], rb[1] / ra[1]) > 1


class R:
    """exact log-ratio chart: u = log m2/m1, v = log m3/m1, compared through ratios"""
    def __init__(s, a):
        s.U = a[1] / a[0]; s.V = a[2] / a[0]; s.W = a[2] / a[1]   # exp(u), exp(v), exp(v-u)


def ch(a):
    return R(a)


random.seed(47)
mism = {k: 0 for k in ['1A', '2B', '3B', '1B', '2A_stated', '3A_stated', '2A_true', '3A_true']}
cnt = 0; crossed_forcing_ok = 0; nested_noforce_ok = 0
for _ in range(400):
    def rp():
        while True:
            x = [F(random.randint(1, 60), 60) for _ in range(2)]
            q = (c + eps * x[0] * (1 - x[1]), c + eps * x[1], 0)
            q = (q[0], q[1], 1 - q[0] - q[1])
            if all(t > c for t in q):
                return q
    k, kp = rp(), rp()
    if k == kp:
        continue
    cnt += 1
    r, rp_ = ch(k), ch(kp)
    # K at k is 'C', K' at kp is 'C''.  "C' is A-ward of C on M_i": k in e_i-corner, k' outside.
    t1A = corner_sep(0, k, kp); t1B = corner_sep(0, kp, k)
    t2A = corner_sep(1, k, kp); t2B = corner_sep(1, kp, k)
    t3A = corner_sep(2, k, kp); t3B = corner_sep(2, kp, k)
    s1A = rp_.U > r.U or rp_.V > r.V
    s2B = rp_.U > r.U or rp_.W < r.W
    s3B = rp_.V > r.V or rp_.W > r.W
    s1B = r.U > rp_.U or r.V > rp_.V
    s2A = r.W < rp_.W                          # as stated in PP28 Prop 5.2
    s3A = rp_.W < r.W                          # as stated
    r2A = rp_.U < r.U or rp_.W > r.W           # referee's corrected condition
    r3A = rp_.V < r.V or rp_.W < r.W
    mism['1A'] += t1A != s1A; mism['2B'] += t2B != s2B; mism['3B'] += t3B != s3B; mism['1B'] += t1B != s1B
    mism['2A_stated'] += t2A != s2A; mism['3A_stated'] += t3A != s3A
    mism['2A_true'] += t2A != r2A; mism['3A_true'] += t3A != r3A
    # forcing in some order <=> crossed at e1 (Prop 5.2):
    strad_b = s1B            # K A-side: needs k outside a corner containing k'
    strad_c = s1A            # K' A-side
    force_b = strad_b and (t1A or (t2B and t3B))
    force_c = strad_c and (t1B or (t2A and t3A))
    crossed = (rp_.U - r.U) * (rp_.V - r.V) < 0
    if crossed == (force_b or force_c):
        crossed_forcing_ok += 1
P('\n== (2),(3) chart conditions vs exact line search, random rational pairs in int M ==')
P(f'pairs tested: {cnt}')
for kk, vv in mism.items():
    P(f'  mismatches {kk}: {vv}')
P(f'  "forcing in some order <=> crossed at e1": agrees on {crossed_forcing_ok}/{cnt}')
# explicit counterexample to the stated 2A condition
k = (F(1, 3), F(1, 3), F(1, 3)); kp = (F(41, 100), F(30, 100), F(29, 100))
al, be = F(9, 10), F(1, 20)
fk = -k[1] + al * k[0] + be * k[2]; fkp = -kp[1] + al * kp[0] + be * kp[2]
r, rp_ = ch(k), ch(kp)
u, v, up, vp = math.log(r.U), math.log(r.V), math.log(rp_.U), math.log(rp_.V)
P('\nCounterexample to PP28 Prop 5.2 "2A iff v-u < v\'-u\'":')
P(f'  k={k}, k\'={kp}, both in int M: {all(t > c for t in k) and all(t > c for t in kp)}')
P(f'  class-2 line -m2 + {al} m1 + {be} m3 = 0: f(k)={fk} (<0, k in e2-corner), f(k\')={fkp} (>0, k\' outside)')
P(f'  so 2A holds; stated condition v-u < v\'-u\': {v - u:.4f} < {vp - up:.4f} is {v - u < vp - up}')
P(f'  correct condition (u\' < u or v\'-u\' > v-u): {up < u or vp - up > v - u}')
print('\n'.join(out))

# ---------- (4) PP28 Cor 5.1' cone criterion over all 63 subsets of the six step directions
from itertools import combinations
from scipy.optimize import linprog
Vd = {'1A': (-1, -1), '1B': (1, 1), '2A': (2, -1), '2B': (-2, 1), '3A': (-1, 2), '3B': (1, -2)}
badc = 0; ns = 0
for r_ in range(1, 7):
    for Sx in combinations(Vd, r_):
        vs = [Vd[s] for s in Sx]; ns += 1
        res = linprog([0] * len(vs) + [-1], A_ub=[[v[0] for v in vs] + [1], [v[1] for v in vs] + [1], [1] * len(vs) + [0]],
                      b_ub=[0, 0, 1], bounds=[(0, None)] * len(vs) + [(None, 1)])
        badc += (-res.fun > 1e-12) != (('1A' in Sx) or ('2B' in Sx and '3B' in Sx))
print(f'\n== (4) Cor 5.1\' cone criterion: {ns} subsets, mismatches with "1A or (2B and 3B)": {badc} (LP) ==')
