"""PP31 (referee, round 47). NUMERICS: is a fixed-rival section of PP28's Sec 4.2 instance closed?

Instance: eps = 3/10, C_p = T on M, C_p = D_[m0,p] off M (interior), Omega-lex base restricted to
records realised at interior indices, all bounded inverted departures at every world.
Fixed rival X := D_[m0,p*], p* in the boundary of M (X is coherent, so it is never T.d or C.d,
and A_w(X) = {p : Omega_w(rec(C_p, X)) >=lex 0}).  C_{p*} = T.
If for some w the leading level Omega^(0)_w(rec(D_[m0,p_s], X)) > 0 along p_s -> p* from outside M
while Omega^(0)_w(rec(T, X)) < 0, then p_s in A_w(X) but p* not in A_w(X): the section is not closed.
Omega^(0)_w(r) = int w_w(g) (rank_w(new) - rank_w(old)) dmu, w_w = 2 on M_w, 1 elsewhere.
Monte Carlo over Gaussian g (ranks depend on direction only); standard errors printed.
"""
import numpy as np

eps = 0.3; c = (1 - eps) / 3
m0 = np.array([c, c + eps, c]); ma = np.array([c + eps, c, c]); mc = np.array([c, c, c + eps])
Mv = np.array([ma, m0, mc])


def advice(V, G):           # V: (k,3) vertices; G: (N,3). +1 accept g, -1 accept -g, 0 silent
    P = G @ V.T
    lo, hi = P.min(1), P.max(1)
    return np.where(lo > 0, 1, np.where(hi < 0, -1, 0))


def ranks(a, G):            # (N,3) ranks per world
    sg = np.sign(G)
    r = np.where(a[:, None] == 0, 1, np.where(a[:, None] * sg > 0, 0, 2))
    return r


def weights(G):
    sg = np.sign(G); s = sg.sum(1)
    W = np.ones_like(G)
    for w in range(3):
        W[:, w] = np.where((np.abs(s) == 1) & (sg[:, w] == -np.sign(s)), 2.0, 1.0)
    return W


def omega(V_old, V_new, G, W):
    d = (ranks(advice(V_new, G), G) - ranks(advice(V_old, G), G)) * W
    return d.mean(0), d.std(0) / np.sqrt(len(G))


rng = np.random.default_rng(4701)
N = 4_000_000
G = rng.standard_normal((N, 3)); W = weights(G)
cases = [('mid[ma,mc]', (ma + mc) / 2), ('mid[m0,ma]', (m0 + ma) / 2), ('mid[m0,mc]', (m0 + mc) / 2)]
dirs = {'radial (from m0)': None, 'toward e1': np.array([1., -.5, -.5]), 'toward e3': np.array([-.5, -.5, 1.]),
        'toward e2': np.array([-.5, 1., -.5])}
for name, ps in cases:
    X = np.array([m0, ps])
    oT, sT = omega(Mv, X, G, W)
    print(f'p* = {name} = {np.round(ps, 4)}: Omega0(rec(T, X)) = {np.round(oT, 5)} (s.e. {np.round(sT, 5)})')
    for dn, dv in dirs.items():
        v = (ps - m0) if dv is None else dv
        v = v - v.mean(); v = v / np.linalg.norm(v)
        row = []
        for s in [0.04, 0.02, 0.01]:
            p = ps + s * v
            if np.all(p >= c - 1e-12):      # still in M: skip (outward directions only)
                row = None; break
            o, se = omega(np.array([m0, p]), X, G, W)
            row.append((s, o, se))
        if row is None:
            continue
        txt = '; '.join(f's={s}: {np.round(o / s, 4)} +- {np.round(2 * se / s, 4)}' for s, o, se in row)
        print(f'   approach {dn:17s} Omega0(rec(C_ps, X))/s: {txt}')
        for w in range(3):
            if all(o[w] - 3 * se[w] > 0 for s, o, se in row) and oT[w] + 3 * sT[w] < 0:
                print(f'      -> world {w + 1}: p_s in A_w(X) for all three s, but p* = limit has T not <=_w X: '
                      f'section A_{w + 1}(X) NOT closed (NUMERICS)')
