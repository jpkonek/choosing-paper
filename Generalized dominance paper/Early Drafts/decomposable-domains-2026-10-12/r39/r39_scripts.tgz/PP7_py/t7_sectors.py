"""PP7 t7 (NUMERICS): hypothesis of the continuum tie-gluing theorem at the four centres.
dL(p0) by central differences of the perimeter formula (mpmath, 50 digits); the positive normal lambda
(lambda . dL = 0, normalised to sum 1); the lonely-world sectors Gamma_j = directions v where sign l_j(v)
differs from the (equal) signs of the other two, and their angular widths (each is a double cone)."""
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mpmath as mp
mp.mp.dps = 50
from fractions import Fraction as F
HERE = os.path.dirname(os.path.abspath(__file__))

def L(p, eps):
    m = min(p); s = 3*eps*m
    V = [[p[i] + s*((1 if i == k else 0) - mp.mpf(1)/3) for i in range(3)] for k in range(3)]
    def th(x, y):
        cr = [x[1]*y[2]-x[2]*y[1], x[2]*y[0]-x[0]*y[2], x[0]*y[1]-x[1]*y[0]]
        return mp.atan2(mp.sqrt(sum(a*a for a in cr)), sum(a*b for a, b in zip(x, y)))
    out = []
    for i in range(3):
        E = [1 if k == i else 0 for k in range(3)]
        j, k = [x for x in range(3) if x != i]
        out.append((th(E, V[j]) + th(E, V[k]) + th(V[j], V[k])/2 - th(V[i], V[j])/2 - th(V[i], V[k])/2)/mp.pi)
    return out

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s); out.append(s)
e1 = [mp.mpf(1)/mp.sqrt(2), -mp.mpf(1)/mp.sqrt(2), 0]; e2 = [mp.mpf(1)/mp.sqrt(6), mp.mpf(1)/mp.sqrt(6), -2/mp.sqrt(6)]
for lab, p0, eps in [('e1_3', (F(9,10), F(6,100), F(4,100)), F(3,10)), ('e1_1', (F(9,10), F(6,100), F(4,100)), F(1,10)),
                     ('u_3', (F(35,100), F(33,100), F(32,100)), F(3,10)), ('u_1', (F(35,100), F(33,100), F(32,100)), F(1,10))]:
    p = [mp.mpf(x.numerator)/x.denominator for x in p0]; ep = mp.mpf(eps.numerator)/eps.denominator
    h = mp.mpf(10)**-12
    G = []
    for d in (e1, e2):
        Lp = L([p[t] + h*d[t] for t in range(3)], ep); Lm = L([p[t] - h*d[t] for t in range(3)], ep)
        G.append([(Lp[i]-Lm[i])/(2*h) for i in range(3)])
    l = [(G[0][i], G[1][i]) for i in range(3)]        # gradient of L_i in the tangent basis
    # positive normal: lambda in kernel of the 2x3 matrix
    a = [l[i][0] for i in range(3)]; b = [l[i][1] for i in range(3)]
    lam = [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]
    s = sum(lam); lam = [x/s for x in lam]
    # sectors: angles where l_i(v) = 0
    def sgn(th):
        v = (mp.cos(th), mp.sin(th)); return [1 if l[i][0]*v[0]+l[i][1]*v[1] > 0 else -1 for i in range(3)]
    N = 7200; width = [0, 0, 0]
    for k in range(N):
        sg = sgn(2*mp.pi*k/N)
        lone = [j for j in range(3) if sg.count(sg[j]) == 1][0]
        width[lone] += 360/N
    pr('%s: lambda = (%s)  min component %.4f;  lonely sector widths (deg, each a double cone, per side):'
       % (lab, ', '.join('%.4f' % float(x) for x in lam), float(min(lam))), ['%.1f' % (w/2) for w in width])
open(os.path.join(HERE, 't7_sectors.out'), 'w').write('\n'.join(out)+'\n')
