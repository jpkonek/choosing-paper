"""Validation of core.py against PP5's certified values (eps = 3/10) and the perimeter formula."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from core import *
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s); out.append(s)
eps = F(3, 10)
a = (F(9,10), F(5,100), F(5,100)); b = (F(901,1000), F(8,100), F(19,1000)); c = (F(902,1000), F(49,1000), F(49,1000))
A, B = Model(a, eps), Model(b, eps)
r = record(A, B, use_iv=True)
pr('rec(C_a,C_b) Phi^2 =', [ivs(phik(r, 2, i), 10) for i in range(3)], '(PP5: .01858309588, -.0153228815, .04952336143)')
La, Lb = L_iv(a, eps), L_iv(b, eps)
pr('add via cells   =', [ivs(r['add'][i], 12) for i in range(3)])
pr('add via L_iv    =', [ivs(Lb[i]-La[i], 12) for i in range(3)])
# silent masses per class for a few centres
for eps_ in (F(3,10), F(1,10)):
    for p0 in [(F(9,10), F(6,100), F(4,100)), (F(35,100), F(33,100), F(32,100))]:
        cells = base_cells(p0, eps_)
        tot = {0: 0.0, 1: 0.0, 2: 0.0}; big = {0: 0.0, 1: 0.0, 2: 0.0}
        for cc in cells:
            g = interior(cc)
            if cls(g) == 'U': continue
            if sel_advice(p0, g, eps_) == '0':
                m = mass_float(cc); w = cls(g); tot[w] += m; big[w] = max(big[w], m)
        pr('eps', eps_, 'p0', tuple(str(t) for t in p0), 'silent cone-mass per class', {k: '%.3e' % v for k, v in tot.items()},
           'largest silent cell', {k: '%.3e' % v for k, v in big.items()}, ' L =', ['%.6f' % x for x in L_float(p0, eps_)])
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 't0_validate.out'), 'w').write('\n'.join(out)+'\n')
