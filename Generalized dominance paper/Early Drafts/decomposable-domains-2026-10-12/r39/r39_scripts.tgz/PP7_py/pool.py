"""PP7 pool machinery: AF verdicts on a finite pool of selected models and spliced rivals,
the exact face obligations (anchor sets), incoherence certificates, an exact SAT encoding of
'AF + symmetric thinning' (with the brief's freedom to choose the sticky subset), and a greedy
repair-cascade simulator.

AF (with the Phi^4 pool) on a record d at world j:
  guidance (Q_j null)                     -> accepted, never removed
  additive branch (add_j >= 0)            -> accepted; removable only by symmetric thinning
  sticky branch (all add < 0, Phi^4_j>=0) -> may be accepted (free choice of subset)
  otherwise                               -> refused
Symmetric thinning of {u,v} at world j removes both directions at j (never guidance)."""
import itertools, random
from core import *
from pysat.solvers import Solver

class Pool:
    def __init__(self, models, use_iv=False, anchors=True, verbose=False):
        self.M = models; n = len(models); self.n = n
        self.rec = {}; self.guid = {}; self.faces = {}; self.add = {}; self.phi4 = {}
        self.uncertified = []; self.iv = {}
        for u in range(n):
            for v in range(n):
                if u == v: continue
                X, Y = models[u], models[v]
                cells, _ = record_cells(X, Y)
                r = record(X, Y, use_iv=use_iv, cells=cells)
                val = (lambda x: ivmid(x)) if use_iv else (lambda x: x)
                self.add[(u, v)] = [val(r['add'][i]) for i in range(3)]
                self.phi4[(u, v)] = [val(phik(r, 4, i)) for i in range(3)]
                if use_iv:
                    unc = [i for i in range(3) if ivsign(r['add'][i]) == 0 or ivsign(phik(r, 4, i)) == 0]
                    if unc and r['changed']: self.uncertified.append(((u, v), unc))
                    self.iv[(u, v)] = (r['add'], [phik(r, 4, i) for i in range(3)], r['P'], r['Q'])
                # exact guidance: no changed cell where Y has a lower world-j rank than X
                g = []
                for j in range(3):
                    g.append(len(r['changed']) > 0 and all(rank(ay, interior(c), j) >= rank(ax, interior(c), j)
                                                          for c, ax, ay in r['changed']))
                self.guid[(u, v)] = g
                if anchors:
                    self.faces[(u, v)] = faces_met(anchor_set(r['changed'], X.eps))
                if verbose: print('rec', u, v, ['%.2e' % a for a in self.add[(u, v)]], self.faces.get((u, v)), flush=True)
        self.incoh = {u: incoherence_certificate(models[u]) for u in range(n)}

    def base(self, u, v, j):
        """'G' guidance, 'A' additive, 'S' sticky-eligible, None refused."""
        if self.guid[(u, v)][j]: return 'G'
        a = self.add[(u, v)]
        if a[j] >= 0: return 'A'
        if all(x < 0 for x in a) and self.phi4[(u, v)][j] >= 0: return 'S'
        return None

# ------------------------------------------------------------------ incoherence certificates
def incoherence_certificate(X):
    """HH3 Lemma 1.2: X gives 'C' on a cell, or g3 = g1 + t g2 (t rational > 0) lies in a cell
    where X does not accept although X accepts at g1 and g2 (interior points of open cells)."""
    if X.selected: return None
    planes = dedup_planes(X.planes() + DIAG)
    cells = arrangement(planes)
    acc = []
    for c in cells:
        g = interior(c); a = X.advice(g)
        if a == 'C': return ('C', g)
        if a == '+': acc.append(g)
    # try pairs involving override-cone points first
    ovp = [interior(list(r)) for r, a in X.ov if a == '+'] + [neg(interior(list(r))) for r, a in X.ov if a == '-']
    cands = ovp + acc
    for g1 in ovp:
        for g2 in cands:
            for t in (F(1), F(1, 4), F(4), F(1, 16), F(16)):
                g3 = tuple(F(g1[k]) + t*g2[k] for k in range(3))
                g3 = prim(g3) if any(g3) else None
                if g3 is None: continue
                # g3 must be interior to an open cell (not on any plane)
                if any(dot(n, g3) == 0 for n in planes + [(1, 0, 0), (0, 1, 0), (0, 0, 1)]): continue
                if X.advice(g3) != '+': return ('nonconvex', g1, g2, t, g3, X.advice(g3))
    return None

# ------------------------------------------------------------------ SAT encoding
class Enc:
    def __init__(self, P, nodes, dom=True, directC=True, oneSided=(), obl_selected_only=False):
        """oneSided: set of (u,v) whose ADDITIVE acceptance may be refused alone (variant)."""
        self.P = P; self.nodes = list(nodes); self.var = {}; self.cl = []
        self.oneSided = set(oneSided)
        V = self.V
        for u, v in itertools.permutations(self.nodes, 2):
            for j in range(3):
                b = P.base(u, v, j)
                if b in ('A', 'S') and (P.base(v, u, j) == 'G'):
                    pass  # thinning of {u,v} at j impossible (guidance must stay); handled below
        # obligations
        for u, v in itertools.permutations(self.nodes, 2):
            if obl_selected_only and not P.M[u].selected: continue
            for I in P.faces.get((u, v), []):
                lits = [self.acc(u, v, j) for j in I]
                if any(l is True for l in lits): continue
                self.cl.append([l for l in lits if l is not False])
        # dominance and direct (C)
        if dom or directC:
            for s in self.nodes:
                if not P.M[s].selected: continue
                for x in self.nodes:
                    if x == s: continue
                    if dom:
                        for j0 in range(3):
                            c = [self.neg(self.acc(x, s, j)) for j in range(3)] + [self.acc(s, x, j0)]
                            self.add_clause(c)
                    if directC and P.incoh.get(x) is not None:
                        c = [self.neg(self.acc(x, s, j)) for j in range(3)] + [self.neg(self.acc(s, x, j)) for j in range(3)]
                        self.add_clause(c)
        # (TC)
        for j in range(3):
            for A, B, C in itertools.permutations(self.nodes, 3):
                ab, bc, ca, ac = self.acc(A, B, j), self.acc(B, C, j), self.acc(C, A, j), self.acc(A, C, j)
                self.add_clause([self.neg(ab), self.neg(bc), self.neg(ca), ac])

    def V(self, key):
        if key not in self.var: self.var[key] = len(self.var) + 1
        return self.var[key]
    @staticmethod
    def neg(l):
        if l is True: return False
        if l is False: return True
        return -l
    def add_clause(self, lits):
        if any(l is True for l in lits): return
        self.cl.append([l for l in lits if l is not False])
    def thin(self, u, v, j):
        if self.P.base(u, v, j) == 'G' or self.P.base(v, u, j) == 'G': return False   # cannot thin guidance
        a, b = min(u, v), max(u, v)
        return self.V(('t', j, a, b))
    def acc(self, u, v, j):
        b = self.P.base(u, v, j)
        if b == 'G': return True
        if b is None: return False
        t = self.thin(u, v, j)
        if b == 'A':
            if (u, v) in self.oneSided:
                a = self.V(('o', j, u, v))      # may be refused alone
                if t is not False and ('ot', j, u, v) not in self.var:
                    self.V(('ot', j, u, v)); self.cl.append([-a, -t])
                return a
            return self.neg(t) if t is not False else True
        # sticky: free choice, and refused if thinned
        a = self.V(('s', j, u, v))
        if t is not False and ('st', j, u, v) not in self.var:
            self.V(('st', j, u, v)); self.cl.append([-a, -t])
        return a

def sat(P, nodes, **kw):
    E = Enc(P, nodes, **kw)
    with Solver(name='g4', bootstrap_with=E.cl) as S:
        ok = S.solve(); model = S.get_model() if ok else None
    return ok, E, model

def min_core(P, nodes, keep=(), **kw):
    core_ = list(nodes)
    for u in list(nodes):
        if u in keep: continue
        trial = [x for x in core_ if x != u]
        if not sat(P, trial, **kw)[0]: core_ = trial
    return core_

def relation_from_model(P, E, model):
    mset = set(l for l in model if l > 0)
    def val(l):
        if l is True or l is False: return l
        return (l in mset) if l > 0 else (-l not in mset)
    return {(u, v, j): val(E.acc(u, v, j)) for u, v in itertools.permutations(E.nodes, 2) for j in range(3)}

def check_relation(P, nodes, R):
    """independent brute-force check: TC violations, unmet obligations, dominated selected, bad ties."""
    def r(u, v, j): return True if u == v else R[(u, v, j)]
    tc = []
    for j in range(3):
        for A, B, C in itertools.permutations(nodes, 3):
            if r(A, B, j) and r(B, C, j) and r(C, A, j) and not r(A, C, j): tc.append((j, A, B, C))
    obl = [(u, v, I) for u, v in itertools.permutations(nodes, 2) for I in P.faces.get((u, v), [])
           if not any(r(u, v, j) for j in I)]
    dom = [(x, s) for s in nodes if P.M[s].selected for x in nodes if x != s
           and all(r(x, s, j) for j in range(3)) and not all(r(s, x, j) for j in range(3))]
    tie = [(x, s) for s in nodes if P.M[s].selected for x in nodes if x != s and P.incoh.get(x) is not None
           and all(r(x, s, j) and r(s, x, j) for j in range(3))]
    return tc, obl, dom, tie

# ------------------------------------------------------------------ greedy cascade
def cascade(P, nodes, prefer=None, log=print, maxsteps=10000):
    """Start from AF with every eligible sticky acceptance; repeatedly repair the first violation found:
    TC triangle -> deselect a sticky link, or symmetric-thin a non-guidance link at that world;
    dominance / all-world tie -> symmetric-thin {X,S} at a world where X <= S.
    A repair is allowed only if every face obligation of both directions stays met.
    Returns ('stable', R) or ('blocked', violation, R)."""
    R = {}
    for u, v in itertools.permutations(nodes, 2):
        for j in range(3): R[(u, v, j)] = P.base(u, v, j) is not None
    def obligations_ok(u, v):
        return all(any(R[(u, v, j)] for j in I) for I in P.faces.get((u, v), []))
    def try_thin(u, v, j):
        if P.base(u, v, j) == 'G' or P.base(v, u, j) == 'G': return False
        old = (R[(u, v, j)], R[(v, u, j)])
        R[(u, v, j)] = False; R[(v, u, j)] = False
        if obligations_ok(u, v) and obligations_ok(v, u): return True
        R[(u, v, j)], R[(v, u, j)] = old; return False
    def try_desel(u, v, j):
        if P.base(u, v, j) != 'S' or not R[(u, v, j)]: return False
        R[(u, v, j)] = False
        if obligations_ok(u, v): return True
        R[(u, v, j)] = True; return False
    steps = []
    for it in range(maxsteps):
        tc, obl, dom, tie = check_relation(P, nodes, R)
        assert not obl
        if not (tc or dom or tie):
            return 'stable', R, steps
        if dom or tie:
            x, s = (dom or tie)[0]
            done = False
            for j in range(3):
                if R[(x, s, j)] and try_thin(x, s, j):
                    steps.append(('dom/tie', x, s, j)); done = True; break
            if not done: return 'blocked', ('dom' if dom else 'tie', x, s), R, steps
            continue
        j, A, B, C = tc[0]
        links = [(A, B), (B, C), (C, A)]
        cand = []
        for (u, v) in links:
            if P.base(u, v, j) == 'S': cand.append(('desel', u, v))
        for (u, v) in links:
            if P.base(u, v, j) in ('A', 'S'): cand.append(('thin', u, v))
        if prefer: cand.sort(key=lambda c: prefer(c, j))
        done = False
        for kind, u, v in cand:
            ok = try_desel(u, v, j) if kind == 'desel' else try_thin(u, v, j)
            if ok:
                steps.append((kind, u, v, j, (A, B, C))); done = True; break
        if not done:
            return 'blocked', ('tc', j, A, B, C), R, steps
    return 'maxsteps', R, steps
