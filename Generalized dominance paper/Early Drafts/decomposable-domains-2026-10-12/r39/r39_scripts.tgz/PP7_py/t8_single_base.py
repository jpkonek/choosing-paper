"""PP7 t8: guidance-gluing with ONE selected model (CHECKED).

Rivals Y(t) = C_p0 with A on nested exact cones S_w(t_w) = shrunk(T_w, t_w) in the silent region of class
M_w (w = 1,2,3), t in a grid G^3.  If t'_u >= t_u, t'_v >= t_v, t'_w = t_w (u,v != w), then Y(t') has A on
more lines of M_u and M_v, where world w is in the majority: Y(t') is a pointwise strict world-w
improvement of Y(t) (guidance; checked exactly by cells).  Every Y(t) additively dominates C_p0 (certified),
so each needs a sticky defence, which under AF is a tie (Lemma 4.1).  Two rivals tied with C_p0 at the same
world w and strictly ordered there by guidance violate (TC).  Hence a colouring of G^3 by defending worlds
with: no two points of colour w differing only in the two coordinates other than w, in the same direction.
Exact SAT over all symmetric-thinning states (pool.py) + independent colouring search."""
import sys, os, itertools, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from core import *
from pool import *

HERE = os.path.dirname(os.path.abspath(__file__))
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def base_cones(p0, eps):
    cells = base_cells(p0, eps)
    sil = {0: [], 1: [], 2: []}
    for c in cells:
        g = interior(c)
        if cls(g) != 'U' and sel_advice(p0, g, eps) == '0': sil[cls(g)].append(c)
    big = {w: max(sil[w], key=lambda c: mass_float(largest_triangle(c))) for w in range(3)}
    tau = 0.25*min(mass_float(largest_triangle(big[w])) for w in range(3))
    return [cone_with_mass(big[w], tau) for w in range(3)]

def colouring_exists(pts, forbid):
    n = len(pts); col = [None]*n
    def bt(i):
        if i == n: return True
        for c in range(3):
            if all(not (col[b] == c and c in forbid.get((b, i), ())) for b in range(i)):
                col[i] = c
                if bt(i+1): return True
        col[i] = None
        return False
    return bt(0)

def run(p0, eps, label_, grid):
    t0 = time.time()
    T = base_cones(p0, eps)
    C0 = Model(p0, eps, name='C_p0')
    rivals = []
    for t in itertools.product(grid, repeat=3):
        ov = []
        for w in range(3):
            S = shrunk(T[w], t[w]) if t[w] != 1 else T[w]
            ov.append((S, adv_from_label(interior(list(S)), 'A')))
        rivals.append(Model(p0, eps, ov, name='Y%s' % ''.join(str(grid.index(x)) for x in t)))
    models = [C0] + rivals
    pr('\n=== %s: eps = %s, p0 = %s; grid of shrink parameters %s -> %d rivals' % (label_, eps, tuple(str(x) for x in p0), [str(g) for g in grid], len(rivals)))
    P = Pool(models, use_iv=True)
    pr('uncertified signs: %s' % P.uncertified)
    st = [u for u in range(1, len(models)) if all(ivsign(a) < 0 for a in P.iv[(0, u)][0])]
    pr('rivals certified to dominate C_p0 additively (all add(rec(C_p0,Y)) < 0): %d of %d' % (len(st), len(rivals)))
    mx = max(max(ivmid(a) for a in P.iv[(0, u)][0]) for u in st)
    pr('   max over rivals of max_i add_i(rec(C_p0,Y)) = %.3e' % mx)
    # guidance structure among rivals
    gl = {}
    for a, b in itertools.permutations(range(1, len(models)), 2):
        ws = [j for j in range(3) if P.guid[(a, b)][j] and not P.guid[(b, a)][j]]
        if ws: gl[(a, b)] = ws
    pr('strict guidance links between rivals: %d (ordered pairs with a strict pointwise improvement at some world)' % len(gl))
    # predicted pattern: Y(ta) strictly better than Y(tb) at w  iff  ta_u >= tb_u, ta_v >= tb_v (bigger A-cones where
    # w is in the majority) and ta_w <= tb_w (smaller A-cone where w is the minority), not all equal
    tup = {u: tuple(t) for u, t in zip(range(1, len(models)), itertools.product(grid, repeat=3))}
    mism = 0
    for a, b in itertools.permutations(range(1, len(models)), 2):
        pred = [w for w in range(3) if tup[a] != tup[b] and all((tup[a][x] >= tup[b][x]) if x != w else (tup[a][x] <= tup[b][x]) for x in range(3))]
        if sorted(pred) != sorted(gl.get((a, b), [])): mism += 1
    pr('   exact guidance pattern = predicted product-order pattern: %s (%d mismatches)' % (mism == 0, mism))
    ok, E, model = sat(P, list(range(len(models))))
    pr('exact SAT (AF + symmetric thinning + sticky subset + undominated + direct (C) + faces): %s' % ('SAT' if ok else 'UNSAT'))
    ok2 = sat(P, list(range(len(models))), dom=False, directC=False)[0]
    pr('   without undominated / direct (C): %s' % ('SAT' if ok2 else 'UNSAT'))
    # independent colouring check: colour = a defending world of rec(C_p0, Y); forbidden: same colour w for a
    # pair strictly ordered by guidance at w (guidance can never be thinned)
    idx = list(range(1, len(models)))
    forbid = {}
    for i, a in enumerate(idx):
        for k, b in enumerate(idx):
            if k < i:
                f = set(gl.get((a, b), [])) | set(gl.get((b, a), []))
                if f: forbid[(k, i)] = f
    ce = colouring_exists(idx, forbid)
    pr('independent check: colouring of rivals by defending worlds avoiding same-world guidance pairs exists: %s' % ce)
    if not ok:
        core_ = min_core(P, list(range(len(models))), keep=(0,))
        pr('   deletion-minimal core: C_p0 +', [models[u].name for u in core_ if u != 0],
           '(digit k of Y = index of the shrink parameter of S_k; 0 = largest cone)')
        cidx = [u for u in core_ if u != 0]
        forb = {}
        for i, a in enumerate(cidx):
            for k, b in enumerate(cidx):
                if k < i:
                    f = set(gl.get((a, b), [])) | set(gl.get((b, a), []))
                    if f: forb[(k, i)] = f
        pr('   colouring check on the core alone: colouring exists = %s' % colouring_exists(cidx, forb))
        okx = sat(P, core_, obl_selected_only=True)[0]
        pr('   core with obligations kept only for records whose old side is C_p0 itself: %s' % ('SAT' if okx else 'UNSAT'))
        rr = [(models[a].name, models[b].name, P.faces[(a, b)], [P.base(a, b, j) for j in range(3)])
              for a, b in itertools.permutations(cidx, 2) if P.faces[(a, b)]]
        pr('   rival-to-rival records in the core with nonempty anchor sets: %d, e.g. %s' % (len(rr), rr[:3]))
        for a, b in itertools.combinations(cidx, 2):
            f = sorted(set(gl.get((a, b), [])) | set(gl.get((b, a), [])))
            if f: pr('      %s vs %s: strictly ordered by guidance at world(s) %s' % (models[a].name, models[b].name, [w+1 for w in f]))
    else:
        R = relation_from_model(P, E, model)
        tc, obl, dom, tie = check_relation(P, list(range(len(models))), R)
        pr('   re-check: TC %d, obligations %d, dominated %d, ties %d' % (len(tc), len(obl), len(dom), len(tie)))
    one = set((u, v) for u, v in itertools.permutations(range(len(models)), 2) if all(a < 0 for a in P.add[(v, u)]))
    ok1, E1, m1 = sat(P, list(range(len(models))), oneSided=one)
    pr('sticky-strict variant: %s' % ('SAT' if ok1 else 'UNSAT'))
    if ok1:
        R1 = relation_from_model(P, E1, m1)
        tc1, obl1, dom1, tie1 = check_relation(P, list(range(len(models))), R1)
        pr('   re-check: TC %d, obligations %d, dominated %d, ties %d' % (len(tc1), len(obl1), len(dom1), len(tie1)))
    pr('time %.0fs' % (time.time()-t0))
    return ok

if __name__ == '__main__':
    cfg = {
        'e1_3': ((F(9,10), F(6,100), F(4,100)), F(3,10)),
        'e1_1': ((F(9,10), F(6,100), F(4,100)), F(1,10)),
        'u_3':  ((F(35,100), F(33,100), F(32,100)), F(3,10)),
        'u_1':  ((F(35,100), F(33,100), F(32,100)), F(1,10)),
    }
    for key in (sys.argv[1:] or list(cfg)):
        for grid in ([F(1), F(9, 10)], [F(1), F(19, 20), F(9, 10)]):
            if not run(*cfg[key], key, grid): break
    open(os.path.join(HERE, 't8_single_base_%s.out' % '_'.join(sys.argv[1:] or ['all'])), 'w').write('\n'.join(out)+'\n')
