"""PP7 t6: the nearby rule ('sticky-strict' = one-sided refusal), tested on rival families that cross the
boundary of the sticky region.

Sticky-strict variant of AF: an additive record d may be refused at world j ALONE (without its reverse)
when rev(d) is in the sticky branch (all add(rev d) < 0); everything else as in AF + symmetric thinning.
So a sticky defence C_q <=_j Y can be strict (C_q <_j Y) instead of a tie.

Pool (centre p0; float masses with exact determinants, NUMERICS; cores re-run with intervals):
  selected: a 3x3 lattice inside N(Y) (t3's step);
  Y = t3's balanced sticky rival (masses m,m,m on S_1,S_2,S_3);
  family Y_t: Y with the S_3 mass scaled to t*m (t = .8,.6,.4,.2) and with the S_2 mass scaled likewise:
     for t < 1/2... the family leaves the sticky region of C_q (some add >= 0): 'Y_out' rivals;
  pump partners: Y + contradiction (Xc), returns Z_j, YZ_j."""
import sys, os, itertools, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from core import *
from pool import *
from t3_tieglue import build_Y, lattice
from t1_pairs_pumps import build as build_pumps

HERE = os.path.dirname(os.path.abspath(__file__))
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def scaled_Y(Y, p0, eps, ws, t):
    """Y with the cones in the classes ws replaced by sub-cones of mass ~ t * (their mass):
    masses (m, t m, t m) up to permutation -- PP5's family; sticky iff t > 1/2."""
    ov = []
    for rays, a in Y.ov:
        if cls(interior(list(rays))) in ws:
            target = t*mass_float(rays)
            lo, hi = F(0), F(1)
            for _ in range(30):
                mid = (lo+hi)/2
                if mass_float(shrunk(rays, mid)) <= target: lo = mid
                else: hi = mid
            ov.append((shrunk(rays, lo), a))
        else: ov.append((rays, a))
    return Model(Y.p, Y.eps, ov, name='Y%s_%s' % (''.join(str(w+1) for w in ws), t))

def sticky_strict_set(P, nodes):
    return set((u, v) for u, v in itertools.permutations(nodes, 2) if all(a < 0 for a in P.add[(v, u)]))

def run(p0, eps, label_, k=1, ts=(F(7,10), F(11,20), F(9,20), F(3,10))):
    t0 = time.time()
    Y, m, add = build_Y(p0, eps, 'small')
    pts, h, _ = lattice(p0, eps, add, 3)
    sel = [q for (ij, q) in pts if max(abs(ij[0]), abs(ij[1])) <= k]
    pump = build_pumps(p0, eps)
    models = [Model(q, eps) for q in sel] + [pump[1], pump[2]] + pump[4:10]
    for ws in ((1, 2), (0, 2)):
        for t in ts: models.append(scaled_Y(Y, p0, eps, ws, t))
    for i, M in enumerate(models):
        M.name = ('C%d' % i) if M.selected else ('%s#%d' % (M.name, i))
    pr('\n=== %s: eps = %s, p0 = %s: %d selected + %d rivals' % (label_, eps, tuple(str(x) for x in p0), len(sel), len(models)-len(sel)))
    P = Pool(models)
    nodes = list(range(len(models)))
    for u in nodes:
        if models[u].selected: continue
        n_st = sum(1 for v in nodes if models[v].selected and all(a < 0 for a in P.add[(v, u)]))
        pr('   %-10s sticky against %d of %d selected' % (models[u].name, n_st, len(sel)))
    ok, E, model = sat(P, nodes)
    pr('AF + symmetric thinning: %s' % ('SAT' if ok else 'UNSAT'))
    if not ok:
        core_ = min_core(P, nodes)
        pr('   deletion-minimal core (AF + symmetric thinning):', [models[u].name for u in core_])
        Pc = Pool([models[u] for u in core_], use_iv=True)
        okc = sat(Pc, list(range(len(core_))))[0]
        pr('   core re-run with interval masses: %s; uncertified signs: %s' % ('SAT' if okc else 'UNSAT', Pc.uncertified))
        okd = sat(Pc, list(range(len(core_))), dom=False, directC=False)[0]
        pr('   same core without the undominated / direct (C) clauses: %s' % ('SAT' if okd else 'UNSAT'))
        sel_c = [u for u in core_ if models[u].selected]
        for a_, b_ in itertools.combinations(range(len(core_)), 2):
            if models[core_[a_]].selected and models[core_[b_]].selected:
                pass
        pr('   selected in core: %d; rivals in core: %d' % (len(sel_c), len(core_) - len(sel_c)))
    one = sticky_strict_set(P, nodes)
    ok1, E1, m1 = sat(P, nodes, oneSided=one)
    pr('sticky-strict variant (%d records may be refused alone): %s' % (len(one), 'SAT' if ok1 else 'UNSAT'))
    if ok1:
        R1 = relation_from_model(P, E1, m1)
        tc1, obl1, dom1, tie1 = check_relation(P, nodes, R1)
        pr('   re-check: TC %d, obligations %d, dominated %d, ties %d' % (len(tc1), len(obl1), len(dom1), len(tie1)))
        st = sorted(set((models[u].name, models[v].name, j+1) for (u, v, j), a in R1.items() if a and P.base(u, v, j) == 'S' and models[u].selected))
        pr('   sticky acceptances out of selected models: %d' % len(st))
        strict = sum(1 for (u, v, j) in st if True)
        ties = sum(1 for (u, v, j), a in R1.items() if a and P.base(u, v, j) == 'S' and models[u].selected and R1[(v, u, j)])
        pr('   of which ties (reverse also accepted): %d' % ties)
    else:
        rv = [u for u in nodes if not models[u].selected]
        core_ = list(nodes)
        for u in rv + [u for u in nodes if models[u].selected]:
            trial = [x for x in core_ if x != u]
            if not sat(P, trial, oneSided=sticky_strict_set(P, trial))[0]: core_ = trial
        pr('   deletion-minimal core:', [models[u].name for u in core_])
        Pc = Pool([models[u] for u in core_], use_iv=True)
        nc = list(range(len(core_)))
        okc = sat(Pc, nc, oneSided=sticky_strict_set(Pc, nc))[0]
        pr('   core re-run with interval masses: %s; uncertified: %s' % ('SAT' if okc else 'UNSAT', Pc.uncertified))
        for u in core_:
            for v in core_:
                if u < v:
                    pass
        # explain: print the add vectors among core rivals and selected
        for u, v in itertools.permutations(core_, 2):
            if not (models[u].selected and models[v].selected):
                pr('      rec(%s,%s): add = %s  Phi4 = %s  bases %s' % (models[u].name, models[v].name,
                   ['%.2e' % a for a in P.add[(u, v)]], ['%.2e' % a for a in P.phi4[(u, v)]], [P.base(u, v, j) for j in range(3)]))
    pr('time %.0fs' % (time.time()-t0))

if __name__ == '__main__':
    cfg = {
        'e1_3': ((F(9,10), F(6,100), F(4,100)), F(3,10)),
        'e1_1': ((F(9,10), F(6,100), F(4,100)), F(1,10)),
        'u_3':  ((F(35,100), F(33,100), F(32,100)), F(3,10)),
        'u_1':  ((F(35,100), F(33,100), F(32,100)), F(1,10)),
    }
    for key in (sys.argv[1:] or list(cfg)):
        run(*cfg[key], key)
    open(os.path.join(HERE, 't6_onesided_%s.out' % '_'.join(sys.argv[1:] or ['all'])), 'w').write('\n'.join(out)+'\n')
