"""PP7 t3: the tie-gluing obstruction, exact finite certificate (CHECKED).

Rival Y = C_{p0} with advice A (majority) on small exact cones S_1, S_2, S_3 inside C_{p0}'s silent
cells of classes M_1, M_2, M_3 ('small') or on all its silent mixed cells ('large').
Selected models C_q, q on a lattice around p0 inside N(Y) = {q : L(Y) < L(C_q) componentwise}.

AF + symmetric thinning, encoded exactly (every repair sequence ends in one of these states):
  * selected pair (q,q'), world j: AF accepts C_q <=_j C_q' iff L_j(q) <= L_j(q') (no selected pair is
    additively dominated: certified below, so the sticky branch never applies to selected pairs).
    Variable x = kept / thinned.  The reverse is refused by AF and stays refused.
  * (C_q, Y): every add < 0 (certified), so it is a sticky-branch record.  Acceptance at each world is a
    FREE variable s (the brief's 'chosen subset'; eligibility is not even imposed, which only adds freedom).
  * (Y, C_q): every add > 0, so AF accepts at every world.  It can be removed at world j only by
    symmetric thinning of the pair, which also removes (C_q, Y) at j:  s_j => r_j.
  * obligations (necessary ones only): q in A(rec(C_q,X)) for every X, q interior, so every record out of
    a selected model needs some accepting world: OR_j x_j(q,q'), OR_j s_j(q).
  * (TC) at every world on every ordered triple of {C_q} u {Y}.
Dominance and direct (C) are NOT imposed (UNSAT without them is the stronger statement).
Masses: exact rational cones, interval solid angles; L by the interval perimeter formula."""
import sys, os, itertools, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from core import *
from pysat.solvers import Solver

HERE = os.path.dirname(os.path.abspath(__file__))
out = []; cores_txt = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def build_Y(p0, eps, size):
    cells = base_cells(p0, eps)
    sil = {0: [], 1: [], 2: []}
    for c in cells:
        g = interior(c)
        if cls(g) == 'U': continue
        if sel_advice(p0, g, eps) == '0': sil[cls(g)].append(c)
    ovs, m = [], [iv.mpf(0)]*3
    if size == 'large':
        for w in range(3):
            for c in sil[w]:
                if len(c) != 3:   # split polygonal cells into triangles (fan) to keep simplicial cones
                    tris = [(c[0], c[k], c[k+1]) for k in range(1, len(c)-1)]
                else: tris = [tuple(c)]
                for t in tris:
                    if det3(*t) < 0: t = (t[0], t[2], t[1])
                    ovs.append((t, adv_from_label(interior(list(t)), 'A'))); m[w] += 2*mass_iv(list(t))
    else:
        big = {w: max(sil[w], key=lambda c: mass_float(largest_triangle(c))) for w in range(3)}
        tau = 0.25*min(mass_float(largest_triangle(big[w])) for w in range(3))
        for w in range(3):
            t = cone_with_mass(big[w], tau)
            ovs.append((t, adv_from_label(interior(list(t)), 'A'))); m[w] += 2*mass_iv(list(t))
    # exact checks: each override cone lies in one silent cell of C_p0 of the stated class
    for t, a in ovs:
        g = interior(list(t))
        assert all(sel_advice(p0, r, eps) == '0' or True for r in t)
        assert sel_advice(p0, g, eps) == '0'
    Y = Model(p0, eps, ovs, name='Y')
    # add(rec(C_p0, Y)): S -> A on M_w changes world w by +1, the others by -1
    add = [m[i] - sum(m[w] for w in range(3) if w != i) for i in range(3)]
    return Y, m, add

def lattice(p0, eps, add, k, safety=F(1, 2)):
    """q = p0 + h (i e + j f), |i|,|j| <= k, e=(1,-1,0), f=(1,0,-1), h chosen so q in N(Y) (re-certified)."""
    e, f = (1, -1, 0), (1, 0, -1)
    L0 = L_float(p0, eps); d = 1e-7
    def Lq(v): return L_float(tuple(float(p0[t]) + v[t] for t in range(3)), eps)
    Ge = [(Lq([d*x for x in e])[i] - L0[i])/d for i in range(3)]
    Gf = [(Lq([d*x for x in f])[i] - L0[i])/d for i in range(3)]
    delta = [-ivmid(a) for a in add]
    hf = float(safety)*min(delta[i]/(k*(abs(Ge[i]) + abs(Gf[i]))) for i in range(3))
    h = F(hf).limit_denominator(10**9)
    h = F(int(h*10**9), 10**9)
    pts = []
    for i in range(-k, k+1):
        for j in range(-k, k+1):
            q = tuple(p0[t] + h*(i*e[t] + j*f[t]) for t in range(3))
            pts.append(((i, j), q))
    return pts, h, (Ge, Gf)

def run(p0, eps, size, k, label):
    t0 = time.time()
    pr('\n=== %s: eps = %s, p0 = %s, rival size = %s, lattice (2k+1)^2 with k = %d' % (label, eps, tuple(str(t) for t in p0), size, k))
    Y, m, add = build_Y(p0, eps, size)
    pr('Y: %d override cones; problem masses on S_1,S_2,S_3 =' % len(Y.ov), [ivs(x, 6) for x in m])
    pr('add(rec(C_p0, Y)) =', [ivs(x, 8) for x in add], ' (all < 0: Y additively dominates C_p0)')
    pts, h, G = lattice(p0, eps, add, k)
    pr('lattice step h =', h, '(~%.2e)' % float(h))
    L0 = L_iv(p0, eps)
    Ls = [L_iv(q, eps) for _, q in pts]
    LY = [L0[i] + add[i] for i in range(3)]
    # certify q in N(Y): add_i(rec(C_q, Y)) = L_i(Y) - L_i(q) < 0 for all i
    marg = []
    for (ij, q), Lq in zip(pts, Ls):
        a = [LY[i] - Lq[i] for i in range(3)]
        assert all(ivsign(x) < 0 for x in a), ('not in N(Y)', ij)
        marg.append(max(lohi(x)[1] for x in a))
    pr('certified: every lattice q has add(rec(C_q,Y)) < 0 at all worlds; max over q of max_i add_i =', mpmath.nstr(max(marg), 6))
    n = len(pts)
    # selected-layer signs, certified nonzero; no additive domination
    sgn = {}
    for u in range(n):
        for v in range(n):
            if u == v: continue
            s = [ivsign(Ls[v][i] - Ls[u][i]) for i in range(3)]   # add_i(rec(C_u,C_v))
            assert 0 not in s, ('tie in L', pts[u][0], pts[v][0])
            assert not all(x < 0 for x in s) and not all(x > 0 for x in s), 'additive domination among selected'
            sgn[(u, v)] = s
    pr('certified: %d selected models, all %d ordered pairs have nonzero add at every world, no additive domination' % (n, n*(n-1)))
    # independent float cross-check of one rival record by cell enumeration
    qtest = pts[0][1]
    rr = record(Model(qtest, eps), Y)
    pr('cross-check rec(C_q,Y) by cells at q =', pts[0][0], ': add =', ['%.6e' % x for x in rr['add']],
       ' vs formula', ['%.6e' % ivmid(LY[i] - Ls[0][i]) for i in range(3)])
    res = sat_test(n, sgn, pts, label)
    pr('time %.1fs' % (time.time()-t0))
    return res

def coloring_check(core_, sgn):
    """independent necessary condition (PROVED in the note): a SAT state yields a colouring c(q) in J_q
    with c(q) = c(q') = j only if j is not the lonely world of (q,q').  Exhaustive backtracking."""
    n = len(core_)
    lone = {}
    for a in range(n):
        for b in range(n):
            if a != b:
                s = sgn[(core_[a], core_[b])]
                lone[(a, b)] = [j for j in range(3) if s.count(s[j]) == 1][0]
    col = [None]*n; count = [0]
    def bt(i):
        if i == n: return True
        for j in range(3):
            if all(not (col[b] == j and lone[(b, i)] == j) for b in range(i)):
                col[i] = j; count[0] += 1
                if bt(i+1): return True
        col[i] = None
        return False
    return bt(0), count[0]

def verify_state(nodes, sgn, var, model, fixSel):
    """independent brute-force check of a SAT state: (TC) on all triples at all worlds,
    obligations, undominatedness of every C_q by Y, no all-world tie with Y."""
    mset = set(l for l in model if l > 0)
    def rel(j, A, B):
        if A == B: return True
        if A == 'Y': return var[('r', j, B)] in mset
        if B == 'Y': return var[('s', j, A)] in mset
        if sgn[(A, B)][j] < 0: return False
        return True if fixSel else (var[('x', j, A, B)] in mset)
    allm = list(nodes) + ['Y']
    bad = 0
    for j in range(3):
        R = {(A, B): rel(j, A, B) for A in allm for B in allm}
        for A, B, C in itertools.permutations(allm, 3):
            if R[(A, B)] and R[(B, C)] and R[(C, A)] and not R[(A, C)]: bad += 1
    obl = all(any(rel(j, u, 'Y') for j in range(3)) for u in nodes) and \
          all(any(rel(j, u, v) for j in range(3)) for u in nodes for v in nodes if u != v)
    dom = any(all(rel(j, 'Y', u) for j in range(3)) and not all(rel(j, u, 'Y') for j in range(3)) for u in nodes)
    tie = any(all(rel(j, 'Y', u) and rel(j, u, 'Y') for j in range(3)) for u in nodes)
    return bad, obl, dom, tie

def encode(nodes, sgn, oneSided=False, extra_dom=False, withY=True, fixSel=False):
    """variables: x[(j,u,v)] for selected accepted links; s[(j,u)] (C_u <=_j Y), r[(j,u)] (Y <=_j C_u)."""
    var = {}
    def V(key):
        if key not in var: var[key] = len(var) + 1
        return var[key]
    cl = []
    Yn = 'Y'
    def rel(j, A, B):
        """literal for A <=_j B, or True/False constant."""
        if A == B: return True
        if A == Yn: return V(('r', j, B))
        if B == Yn: return V(('s', j, A))
        if sgn[(A, B)][j] < 0: return False
        return True if fixSel else V(('x', j, A, B))
    for j in range(3):
        for u in nodes:
            if withY and not oneSided: cl.append([-V(('s', j, u)), V(('r', j, u))])   # symmetric thinning only
    for u in nodes:
        if withY: cl.append([V(('s', j, u)) for j in range(3)])               # defend C_u against Y
        for v in nodes:
            if u != v:
                lits = [rel(j, u, v) for j in range(3)]
                if any(l is True for l in lits): continue
                cl.append([l for l in lits if l is not False])
    if extra_dom:
        for u in nodes:
            # C_u not dominated by Y: (some j with not r_j) or (all j s_j)
            for j0 in range(3):
                cl.append([-V(('r', j, u)) for j in range(3)] + [V(('s', j0, u))])
            # direct (C): Y (incoherent) not tied with C_u at every world
            cl.append([-V(('r', j, u)) for j in range(3)] + [-V(('s', j, u)) for j in range(3)])
    allm = list(nodes) + ([Yn] if withY else [])
    for j in range(3):
        for A, B, C in itertools.permutations(allm, 3):
            ab, bc, ca, ac = rel(j, A, B), rel(j, B, C), rel(j, C, A), rel(j, A, C)
            if ab is False or bc is False or ca is False or ac is True: continue
            clause = [-l for l in (ab, bc, ca) if l is not True]
            if ac is not False: clause.append(ac)
            cl.append(clause)
    return var, cl

def solve(nodes, sgn, **kw):
    var, cl = encode(nodes, sgn, **kw)
    with Solver(name='g4', bootstrap_with=cl) as S:
        ok = S.solve()
        model = S.get_model() if ok else None
    return ok, var, model, len(cl)

def sat_test(n, sgn, pts, label):
    nodes = list(range(n))
    okc = solve(nodes, sgn, withY=False)[0]
    pr('control, selected layer alone (no Y): %s' % ('SAT' if okc else 'UNSAT'))
    ok, var, model, ncl = solve(nodes, sgn)
    pr('SAT (AF + symmetric thinning, %d clauses): %s' % (ncl, 'SAT' if ok else 'UNSAT'))
    res = dict(sym=ok)
    if not ok:
        # deletion-minimal core over the selected models
        core_ = list(nodes)
        changed = True
        while changed:
            changed = False
            for u in list(core_):
                trial = [x for x in core_ if x != u]
                if not solve(trial, sgn)[0]:
                    core_ = trial; changed = True
        pr('deletion-minimal UNSAT core: %d selected models + Y; lattice coordinates (i,j):' % len(core_), [pts[u][0] for u in core_])
        lonely = {}
        for u, v in itertools.combinations(core_, 2):
            s = sgn[(u, v)]
            lone = [j for j in range(3) if s.count(s[j]) == 1][0]
            lonely[(pts[u][0], pts[v][0])] = lone + 1
        cnt = {1: 0, 2: 0, 3: 0}
        for v in lonely.values(): cnt[v] += 1
        pr('   core pairs by lonely world:', cnt, '(full table in t3_tieglue_cores.txt)')
        cores_txt.append('%s: core %s\n  lonely %s' % (label, [pts[u][0] for u in core_], lonely))
        okc2, nodes_tried = coloring_check(core_, sgn)
        pr('   independent check (exhaustive colouring backtrack on the core): colouring exists = %s (%d nodes tried)'
           % (okc2, nodes_tried))
        res['core'] = [pts[u] for u in core_]
    else:
        pr('   (no obstruction on this lattice)')
    ok1, var1, model1, ncl1 = solve(nodes, sgn, oneSided=True, extra_dom=True, fixSel=True)
    pr('variant ONE-SIDED (Y <=_j C_q may be refused alone), selected layer FROZEN at W_add, + undominated + direct (C): %s'
       % ('SAT' if ok1 else 'UNSAT'))
    if ok1:
        mset = set(l for l in model1 if l > 0)
        bad, obl, dom, tie = verify_state(nodes, sgn, var1, model1, True)
        pr('   independent brute-force check of that state: TC violations = %d, obligations met = %s, C_q dominated by Y = %s, all-world tie = %s'
           % (bad, obl, dom, tie))
        # threshold structure: at world j is {q : C_q <=_j Y} a sublevel set of L_j?
        for j in range(3):
            D = [u for u in nodes if var1[('s', j, u)] in mset]
            Rr = [u for u in nodes if var1[('r', j, u)] in mset]
            nd = [u for u in nodes if u not in D]
            ok_thr = all(sgn[(u, v)][j] > 0 for u in D for v in nd)   # every defended q better at j than every undefended
            pr('   world %d: C_q <=_j Y for %d q; Y <=_j C_q for %d q; defended set is an L_%d-sublevel set: %s'
               % (j+1, len(D), len(Rr), j+1, ok_thr))
        res['one'] = True
    return res

if __name__ == '__main__':
    which = sys.argv[1:] or ['e1_3', 'e1_1', 'u_3', 'u_1']
    cfg = {
        'e1_3': ((F(9,10), F(6,100), F(4,100)), F(3,10)),
        'e1_1': ((F(9,10), F(6,100), F(4,100)), F(1,10)),
        'u_3':  ((F(35,100), F(33,100), F(32,100)), F(3,10)),
        'u_1':  ((F(35,100), F(33,100), F(32,100)), F(1,10)),
    }
    for key in which:
        p0, eps = cfg[key]
        for k in (3, 4):
            r = run(p0, eps, 'small', k, key)
            if not r['sym']: break
    open(os.path.join(HERE, 't3_tieglue.out'), 'w').write('\n'.join(out)+'\n')
    open(os.path.join(HERE, 't3_tieglue_cores.txt'), 'w').write('\n'.join(cores_txt)+'\n')
