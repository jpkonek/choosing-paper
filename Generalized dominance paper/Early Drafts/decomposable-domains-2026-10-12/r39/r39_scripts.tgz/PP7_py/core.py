"""PP7 core: audit's family K_p = p + 3 eps min(p) (Delta - u), C_p = D_{K_p}, for general eps,
plus RIVALS = a selected base model whose advice is overridden on finitely many exact cones.

Conventions (same as PP5/PP6):
  * a problem is {g,-g}, g standard Gaussian on R^3; integrating over all cells of R^3 with
    mass = solid angle/(4 pi) counts each problem once in total (g and -g each carry half);
  * advice at g: '+' accept g, '-' accept -g, '0' silent, 'C' contradictory (both);
  * world-i rank: '0' -> 1, 'C' -> 3, '+' -> 0 if g_i>0 else 2, '-' -> 2 if g_i>0 else 0;
  * rec(X,Y): P_i = U_i(Y) minus U_i(X) (steps Y adds), Q_i = U_i(X) minus U_i(Y);
    add_i = nu(P_i) - nu(Q_i) = L_i(Y) - L_i(X);  Phi^k_i = k nu(P_i) - nu(Q_i).
  * X <=_i Y ("X at least as good as Y at world i") is accepted on the record rec(X,Y).
Everything geometric is exact (integer rays, Fractions); masses are float (scans) or
mpmath interval (certificates)."""
from fractions import Fraction as F
from math import gcd
import math, itertools
import mpmath
from mpmath import iv
iv.dps = 40

# ------------------------------------------------------------------ exact vector utilities
def dot(a, b): return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def det3(a, b, c): return dot(a, cross(b, c))
def neg(v): return tuple(-t for t in v)

def prim(v):
    den = 1
    for x in v:
        x = F(x); den = den*x.denominator//gcd(den, x.denominator)
    w = [int(F(x)*den) for x in v]
    g = 0
    for x in w: g = gcd(g, abs(x))
    return tuple(x//g for x in w)

def Fr(p): return tuple(F(x) for x in p)

# ------------------------------------------------------------------ the family
def verts(p, eps):
    p = Fr(p); m = min(p)
    return [tuple(p[i] - eps*m + (3*eps*m if i == j else 0) for i in range(3)) for j in range(3)]

def normals(p, eps):
    p = Fr(p)
    if min(p) == 0: return [prim(p)]
    return [prim(v) for v in verts(p, eps)]

def sel_advice(p, g, eps):
    p = Fr(p)
    if min(p) == 0:
        s = dot(p, g); return '+' if s > 0 else ('-' if s < 0 else '0')
    s = [dot(n, g) for n in normals(p, eps)]
    if all(x > 0 for x in s): return '+'
    if all(x < 0 for x in s): return '-'
    return '0'

FLIP = {'+': '-', '-': '+', '0': '0', 'C': 'C'}

def rank(adv, g, i):
    if adv == '0': return 1
    if adv == 'C': return 3
    good = (adv == '+') == (g[i] > 0)
    return 0 if good else 2

def in_cone(g, rays):
    """g in the open simplicial cone spanned by rays (r0,r1,r2) (exact)."""
    r0, r1, r2 = rays
    d = det3(r0, r1, r2)
    s = (det3(g, r1, r2), det3(r0, g, r2), det3(r0, r1, g))
    return all((x > 0) if d > 0 else (x < 0) for x in s)

def facet_planes(rays):
    r0, r1, r2 = rays
    return [prim(cross(r0, r1)), prim(cross(r1, r2)), prim(cross(r2, r0))]

class Model:
    """base selected index p (Fractions) + overrides [(rays, adv)] on open simplicial cones.
    The override (rays, adv) also sets advice FLIP[adv] on the antipodal cone."""
    def __init__(self, p, eps, overrides=(), name=None):
        self.p = Fr(p); self.eps = F(eps); self.ov = list(overrides)
        self.name = name or ('C%s' % (tuple(str(x) for x in self.p),))
    @property
    def selected(self): return len(self.ov) == 0
    def advice(self, g):
        for rays, a in self.ov:
            if in_cone(g, rays): return a
            if in_cone(neg(g), rays): return FLIP[a]
        return sel_advice(self.p, g, self.eps)
    def planes(self):
        pl = list(normals(self.p, self.eps))
        for rays, _ in self.ov: pl += facet_planes(rays)
        return pl
    def with_ov(self, extra, name=None):
        return Model(self.p, self.eps, self.ov + list(extra), name)

# ------------------------------------------------------------------ exact cone clipping
def clean(poly):
    if poly is None or len(poly) < 3: return None
    out = []
    for v in poly:
        if not out or prim(v) != prim(out[-1]): out.append(v)
    if len(out) > 1 and prim(out[0]) == prim(out[-1]): out.pop()
    if len(out) < 3: return None
    v0 = out[0]
    for a in range(1, len(out)-1):
        if det3(v0, out[a], out[a+1]) != 0: return out
    return None

def clip(poly, n):
    s = [dot(n, v) for v in poly]
    pos, negp = [], []
    k = len(poly)
    for a in range(k):
        b = (a+1) % k
        va, vb, sa, sb = poly[a], poly[b], s[a], s[b]
        if sa >= 0: pos.append(va)
        if sa <= 0: negp.append(va)
        if (sa > 0 and sb < 0) or (sa < 0 and sb > 0):
            w = tuple(sa*vb[t] - sb*va[t] for t in range(3))
            if sa < 0: w = neg(w)
            w = prim(w); pos.append(w); negp.append(w)
    return clean(pos), clean(negp)

OCTANTS = []
for sx in (1, -1):
    for sy in (1, -1):
        for sz in (1, -1):
            e = [(sx, 0, 0), (0, sy, 0), (0, 0, sz)]
            if sx*sy*sz < 0: e = [e[0], e[2], e[1]]
            OCTANTS.append(e)
DIAG = [(1, -1, 0), (1, 0, -1), (0, 1, -1)]

def dedup_planes(pl):
    seen, out = set(), []
    for n in pl:
        k = prim(n)
        if k not in seen and neg(k) not in seen:
            seen.add(k); out.append(k)
    return out

def arrangement(planes, start=None):
    cells = [list(o) for o in OCTANTS] if start is None else [list(c) for c in start]
    for n in planes:
        new = []
        for c in cells:
            a, b = clip(c, n)
            if a is not None: new.append(a)
            if b is not None: new.append(b)
        cells = new
    return cells

def interior(poly): return tuple(sum(v[t] for v in poly) for t in range(3))

# ------------------------------------------------------------------ solid angles
def tri_angle_float(a, b, c):
    """Van Oosterom-Strackee with the determinant and dot products taken EXACTLY on the integer
    rays and only then rounded (tiny cones with huge integer rays would cancel in floats)."""
    k = [max(abs(t) for t in x).bit_length() for x in (a, b, c)]
    r = [math.sqrt(dot(x, x) / (1 << (2*kx))) for x, kx in zip((a, b, c), k)]   # |x| / 2^kx, int/int is correctly rounded
    num = abs(det3(a, b, c)) / (1 << (k[0]+k[1]+k[2])) / (r[0]*r[1]*r[2])
    ab = dot(a, b) / (1 << (k[0]+k[1])) / (r[0]*r[1])
    ac = dot(a, c) / (1 << (k[0]+k[2])) / (r[0]*r[2])
    bc = dot(b, c) / (1 << (k[1]+k[2])) / (r[1]*r[2])
    return 2*math.atan2(num, 1 + ab + ac + bc)

def mass_float(poly):
    return sum(tri_angle_float(poly[0], poly[k], poly[k+1]) for k in range(1, len(poly)-1))/(4*math.pi)

def tri_angle_iv(a, b, c):
    num = abs(det3(a, b, c))
    if num == 0: return iv.mpf(0)
    na, nb, nc = (iv.sqrt(iv.mpf(dot(x, x))) for x in (a, b, c))
    den = na*nb*nc + dot(a, b)*nc + dot(a, c)*nb + dot(b, c)*na
    return 2*iv.atan2(iv.mpf(num), den)

def mass_iv(poly):
    s = iv.mpf(0)
    for k in range(1, len(poly)-1): s += tri_angle_iv(poly[0], poly[k], poly[k+1])
    return s/(4*iv.pi)

def lohi(x): return mpmath.mpf(x._mpi_[0]), mpmath.mpf(x._mpi_[1])
def ivsign(x):
    lo, hi = lohi(x)
    return 1 if lo > 0 else (-1 if hi < 0 else 0)
def ivs(x, d=8):
    lo, hi = lohi(x); return '[%s, %s]' % (mpmath.nstr(lo, d), mpmath.nstr(hi, d))
def ivmid(x):
    lo, hi = lohi(x); return float((lo+hi)/2)

# ------------------------------------------------------------------ records
def record_cells(X, Y, diag=True):
    """cells on which X and Y both have constant advice (and argmin/argmax fixed if diag).
    Same base: only the override region needs refinement (everything else is unchanged)."""
    extra = DIAG if diag else []
    if X.p == Y.p and X.eps == Y.eps:
        cones = [r for r, _ in X.ov] + [r for r, _ in Y.ov]
        cones = cones + [tuple(neg(v) for v in r) for r in cones]
        planes = dedup_planes(normals(X.p, X.eps) + [n for r in cones for n in facet_planes(r)] + extra
                              + [(1, 0, 0), (0, 1, 0), (0, 0, 1)])
        cells = []
        for idx, r in enumerate(cones):
            for c in arrangement(planes, start=[list(r)]):
                g = interior(c)
                if any(in_cone(g, cones[j]) for j in range(idx)):  # counted already
                    continue
                cells.append(c)
        return cells, True
    planes = dedup_planes(X.planes() + Y.planes() + extra)
    return arrangement(planes), False

def record(X, Y, use_iv=False, cells=None):
    if cells is None: cells, _ = record_cells(X, Y)
    M = mass_iv if use_iv else mass_float
    z = iv.mpf(0) if use_iv else 0.0
    P = [z]*3; Q = [z]*3; changed = []
    for c in cells:
        g = interior(c)
        ax, ay = X.advice(g), Y.advice(g)
        if ax == ay: continue
        m = M(c); changed.append((c, ax, ay))
        for i in range(3):
            rx, ry = rank(ax, g, i), rank(ay, g, i)
            if ry > rx: P[i] += (ry-rx)*m
            elif rx > ry: Q[i] += (rx-ry)*m
    return dict(P=P, Q=Q, add=[P[i]-Q[i] for i in range(3)], changed=changed)

def phik(r, k, i): return k*r['P'][i] - r['Q'][i]

# ------------------------------------------------------------------ problem classes and labels
def cls(g):
    sg = [1 if t > 0 else -1 for t in g]
    if abs(sum(sg)) == 3: return 'U'
    return [i for i in range(3) if sg[i] != (1 if sum(sg) > 0 else -1)][0]

def label(g, adv):
    """A/S/B/C relative to the majority on a mixed problem; for unanimous: A = correct."""
    if adv == '0': return 'S'
    if adv == 'C': return 'C'
    sg = [1 if t > 0 else -1 for t in g]
    maj = 1 if sum(sg) > 0 else -1
    acc = 1 if adv == '+' else -1
    return 'A' if acc == maj else 'B'

def adv_from_label(g, lab):
    if lab in ('S', '0'): return '0'
    if lab == 'C': return 'C'
    sg = [1 if t > 0 else -1 for t in g]
    maj = 1 if sum(sg) > 0 else -1
    want = maj if lab == 'A' else -maj
    return '+' if want > 0 else '-'

# ------------------------------------------------------------------ anchors (general old side)
def lin_lowprev(r, k, sign, eps):
    """c with P_q(sign*r) = c.q on the q-chamber {q_k = min q}; r in a cell with argmin/argmax fixed."""
    if sign > 0:
        c = [F(t) for t in r]; c[k] += eps*(3*min(r) - sum(r))
    else:
        c = [F(-t) for t in r]; c[k] += eps*(sum(r) - 3*max(r))
    return c

def to2d(c): return (c[0]-c[2], c[1]-c[2], c[2])

def clip2(poly, h):
    A1, A2, B = h
    val = [A1*v[0] + A2*v[1] + B for v in poly]
    out = []
    n = len(poly)
    for i in range(n):
        j = (i+1) % n
        vi, vj, si, sj = poly[i], poly[j], val[i], val[j]
        if si >= 0: out.append(vi)
        if (si > 0 and sj < 0) or (si < 0 and sj > 0):
            t = si/(si-sj)
            out.append((vi[0]+t*(vj[0]-vi[0]), vi[1]+t*(vj[1]-vi[1])))
    res = []
    for v in out:
        if not res or v != res[-1]: res.append(v)
    if len(res) > 1 and res[0] == res[-1]: res.pop()
    return res

def chamber(k):
    poly = [(F(0), F(0)), (F(1), F(0)), (F(0), F(1))]
    for j in range(3):
        if j != k:
            c = [F(0)]*3; c[j] += 1; c[k] -= 1
            poly = clip2(poly, to2d(c))
    return poly

def anchor_set(changed, eps):
    """A(d) for a record whose changed cells (with old advice) are given; exact polygons per
    chamber.  Empty if the old side is contradictory anywhere on D."""
    H = {0: [], 1: [], 2: []}
    for c, ax, ay in changed:
        if ax == 'C': return {0: [], 1: [], 2: []}
        for r in c:
            for k in range(3):
                if ax == '+': H[k].append(to2d(lin_lowprev(r, k, +1, eps)))
                elif ax == '-': H[k].append(to2d(lin_lowprev(r, k, -1, eps)))
                else:
                    for s in (+1, -1):
                        H[k].append(to2d([-t for t in lin_lowprev(r, k, s, eps)]))
    polys = {}
    for k in range(3):
        poly = chamber(k)
        for h in dict.fromkeys(H[k]):
            if not poly: break
            poly = clip2(poly, h)
        polys[k] = poly
    return polys

def faces_met(polys):
    pts = [(v[0], v[1], 1-v[0]-v[1]) for k in polys for v in polys[k]]
    out = []
    for I in [(0,), (1,), (2,), (0, 1), (0, 2), (1, 2), (0, 1, 2)]:
        if any(all(q[j] == 0 for j in range(3) if j not in I) for q in pts): out.append(I)
    return out

# ------------------------------------------------------------------ closed-form L (PP6 Lemma 2)
def L_iv(p, eps):
    """certified L_i(C_p) for interior rational p (perimeter formula, interval arithmetic)."""
    V = verts(p, F(eps))
    def th(x, y):
        x = prim(x); y = prim(y)
        cr = cross(x, y)
        return iv.atan2(iv.sqrt(iv.mpf(dot(cr, cr))), iv.mpf(dot(x, y)))
    E = [(1, 0, 0), (0, 1, 0), (0, 0, 1)]
    out = []
    for i in range(3):
        j, k = [x for x in range(3) if x != i]
        out.append((th(E[i], V[j]) + th(E[i], V[k]) + th(V[j], V[k])/2
                    - th(V[i], V[j])/2 - th(V[i], V[k])/2)/iv.pi)
    return out

def L_float(p, eps):
    V = [tuple(float(t) for t in v) for v in verts(p, F(eps))]
    def th(x, y):
        cr = cross(x, y); return math.atan2(math.sqrt(dot(cr, cr)), dot(x, y))
    E = [(1.0, 0, 0), (0, 1.0, 0), (0, 0, 1.0)]
    out = []
    for i in range(3):
        j, k = [x for x in range(3) if x != i]
        out.append((th(E[i], V[j]) + th(E[i], V[k]) + th(V[j], V[k])/2
                    - th(V[i], V[j])/2 - th(V[i], V[k])/2)/math.pi)
    return out

# ------------------------------------------------------------------ building rival cones
def base_cells(p, eps, extra=()):
    planes = dedup_planes(normals(p, eps) + DIAG + list(extra))
    return arrangement(planes)

def small_cone(cell, N, frac=None):
    """an exact simplicial sub-cone of a cell, around its interior point: rays N*g0 + r_k
    (for three rays of the cell); larger N -> smaller cone."""
    g0 = interior(cell)
    rs = [cell[0], cell[len(cell)//3], cell[(2*len(cell))//3]]
    if len(cell) == 3: rs = list(cell)
    rays = tuple(prim(tuple(N*g0[t] + r[t] for t in range(3))) for r in rs)
    if det3(*rays) < 0: rays = (rays[0], rays[2], rays[1])
    return rays

def fan(cell):
    tris = [(cell[0], cell[k], cell[k+1]) for k in range(1, len(cell)-1)]
    return [t if det3(*t) > 0 else (t[0], t[2], t[1]) for t in tris]

def largest_triangle(cell): return max(fan(cell), key=mass_float)

def shrunk(tri, t):
    """exact sub-cone of the simplicial cone tri: rays (1-t) cen + t r_k (normalised by rational
    approximations of 1/|r_k|, which does not change directions); t in (0,1]."""
    s = [F(1/math.sqrt(float(dot(r, r)))) for r in tri]     # exact binary rationals, > 0
    rn = [tuple(s[k]*x for x in tri[k]) for k in range(3)]
    cen = tuple(sum(rn[k][i] for k in range(3))/3 for i in range(3))
    rays = tuple(prim(tuple((1-t)*cen[i] + t*rn[k][i] for i in range(3))) for k in range(3))
    return rays if det3(*rays) > 0 else (rays[0], rays[2], rays[1])

def cone_with_mass(cell, target, steps=30):
    """exact simplicial sub-cone of the cell's largest fan triangle with cone mass <= target, close to it."""
    tri = largest_triangle(cell)
    if mass_float(tri) <= target: return tri
    lo, hi = F(0), F(1)
    for _ in range(steps):
        mid = (lo+hi)/2
        if mass_float(shrunk(tri, mid)) <= target: lo = mid
        else: hi = mid
    return shrunk(tri, lo)
