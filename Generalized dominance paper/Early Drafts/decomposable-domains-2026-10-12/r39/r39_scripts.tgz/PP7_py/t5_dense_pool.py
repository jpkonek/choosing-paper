"""PP7 t5: dense mixed pool.  t3's sticky rival Y and a 5x5 lattice of selected models inside N(Y),
plus pump partners (Y + contradiction, Y + unanimous silence), returns, random small modifications and
splices, all on the same centre.  Full AF + symmetric thinning (+ sticky subset, undominated, direct (C),
exact faces).  Purpose: does the obstruction survive in a mixed pool, and is its minimal core still
'selected lattice + Y' (no other rival needed)?  Masses: float with exact integer determinants (NUMERICS);
the core is re-run with interval masses (CHECKED if all signs certified)."""
import sys, os, itertools, random, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from core import *
from pool import *
from t3_tieglue import build_Y, lattice
from t1_pairs_pumps import build as build_pumps
from t4_mixed_pool import random_rival

HERE = os.path.dirname(os.path.abspath(__file__))
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def run(p0, eps, label_, k=3, seed=7):
    t0 = time.time()
    rng = random.Random(seed)
    Y, m, add = build_Y(p0, eps, 'small')
    pts, h, _ = lattice(p0, eps, add, 3)
    sel = [q for (ij, q) in pts if max(abs(ij[0]), abs(ij[1])) <= k]
    pump = build_pumps(p0, eps)              # [C0, Y, Xc, Xu, Z1..3, YZ1..3]
    models = [Model(q, eps) for q in sel] + pump[1:4] + pump[4:7]
    for kd in ['R', 'R', 'R', 'SP', 'SP']:
        models.append(random_rival(rng, rng.choice(sel), eps, kd, sel))
    for i, M in enumerate(models):
        M.name = ('C%d' % i) if M.selected else ('%s#%d' % (M.name, i))
    pr('\n=== %s: eps = %s, p0 = %s: %d selected (lattice step %s) + %d rivals' % (
        label_, eps, tuple(str(t) for t in p0), len(sel), h, len(models) - len(sel)))
    P = Pool(models)
    nodes = list(range(len(models)))
    R0 = {(u, v, j): P.base(u, v, j) is not None for u, v in itertools.permutations(nodes, 2) for j in range(3)}
    tc, obl, dom, tie = check_relation(P, nodes, R0)
    pr('maximal AF: %d TC violations, %d dominated, %d incoherent ties' % (len(tc), len(dom), len(tie)))
    res = cascade(P, nodes)
    cnt = {}
    for s_ in res[-1]: cnt[s_[0]] = cnt.get(s_[0], 0) + 1
    pr('greedy cascade: %s after %d repairs %s' % (res[0], len(res[-1]), cnt))
    if res[0] == 'blocked' and res[1][0] == 'tc':
        j, A, B, C = res[1][1:]
        pr('   blocked at world %d: %s <= %s <= %s, %s < %s; links %s %s %s' % (j+1, models[A].name, models[B].name, models[C].name,
           models[C].name, models[A].name, P.base(A, B, j), P.base(B, C, j), P.base(C, A, j)))
    ok, E, model = sat(P, nodes)
    pr('exact SAT over all symmetric-thinning states: %s' % ('SAT' if ok else 'UNSAT'))
    if not ok:
        rivals_only = [u for u in nodes if not models[u].selected]
        core_ = list(nodes)
        for u in rivals_only:
            trial = [x for x in core_ if x != u]
            if not sat(P, trial)[0]: core_ = trial
        pr('   rivals that cannot be deleted (deletion over rivals only): %s' % [models[u].name for u in core_ if not models[u].selected])
    # the one-sided variant on the whole pool: additive acceptances INTO a selected model from a rival
    # that additively dominates it may be refused alone
    one = [(u, v) for u, v in itertools.permutations(nodes, 2) if models[v].selected and not models[u].selected
           and all(a > 0 for a in P.add[(u, v)])]
    ok1, E1, m1 = sat(P, nodes, oneSided=one)
    pr('one-sided variant (refuse alone: additive records X -> C_q with X additively dominating C_q; %d such records): %s'
       % (len(one), 'SAT' if ok1 else 'UNSAT'))
    if ok1:
        R1 = relation_from_model(P, E1, m1)
        tc1, obl1, dom1, tie1 = check_relation(P, nodes, R1)
        pr('   re-check: TC %d, obligations %d, dominated %d, ties %d' % (len(tc1), len(obl1), len(dom1), len(tie1)))
        st = sum(1 for (u, v, j), a in R1.items() if a and P.base(u, v, j) == 'S' and models[u].selected)
        pr('   sticky (non-additive) acceptances out of selected models: %d; additive acceptances refused: %d'
           % (st, sum(1 for (u, v, j), a in R1.items() if (not a) and P.base(u, v, j) == 'A')))
    pr('time %.0fs' % (time.time() - t0))

if __name__ == '__main__':
    cfg = {
        'e1_3': ((F(9,10), F(6,100), F(4,100)), F(3,10)),
        'u_1':  ((F(35,100), F(33,100), F(32,100)), F(1,10)),
    }
    for key in (sys.argv[1:] or list(cfg)):
        run(*cfg[key], key)
    open(os.path.join(HERE, 't5_dense_pool.out'), 'w').write('\n'.join(out)+'\n')
