"""PP7 t1: pair level and pump level, exact (CHECKED: rational cones, interval masses).

Configuration around one selected model C_p0 (near e_1 and near u; eps = 3/10 and 1/10):
  Y    = C_p0 with A on S_1, S_2, S_3 (t3's sticky rival: additively dominates C_p0);
  Xc   = Y with contradiction on a tiny cone W (a pure worsening of Y at every world);
  Xu   = Y silent on a tiny cone of unanimous problems (a regular pure worsening of Y at every world);
  Z_j  = C_p0 improved at world j only on a tiny cone T_j (S -> B on silent M_j lines; j = 1,2,3);
  YZ_j = Y with the same improvement T_j.
Checks:
  (1) literal AF: Y <=_i C_p0 at every i (add > 0), so undominatedness forces an all-world tie,
      and direct (C) fails because Y is certified incoherent;
  (2) the pumps (Xc, C_p0, Y) etc. at each world where C_p0 <=_j Y is accepted;
  (3) the greedy symmetric-thinning cascade and the exact SAT over all symmetric-thinning states."""
import sys, os, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from core import *
from pool import *
from t3_tieglue import build_Y

HERE = os.path.dirname(os.path.abspath(__file__))
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def tiny_cone_where(p0, eps, pred, target, avoid=()):
    cells = base_cells(p0, eps, extra=[n for r in avoid for n in facet_planes(r)])
    good = [c for c in cells if pred(interior(c)) and not any(in_cone(interior(c), r) or in_cone(neg(interior(c)), r) for r in avoid)]
    c = max(good, key=lambda c: mass_float(largest_triangle(c)))
    return cone_with_mass(c, target)

def build(p0, eps):
    Y, m, add = build_Y(p0, eps, 'small')
    S = [r for r, _ in Y.ov]
    tau = 0.02*ivmid(m[0])/2
    C0 = Model(p0, eps, name='C_p0')
    # W: unanimous problems (C_p0 correct there), contradiction
    W = tiny_cone_where(p0, eps, lambda g: cls(g) == 'U', tau, avoid=S)
    Xc = Y.with_ov([(W, 'C')], name='Xc')
    U2 = tiny_cone_where(p0, eps, lambda g: cls(g) == 'U' and not in_cone(g, W) and not in_cone(neg(g), W), tau, avoid=S + [W])
    Xu = Y.with_ov([(U2, '0')], name='Xu')
    Z, YZ = [], []
    for j in range(3):
        T = tiny_cone_where(p0, eps, lambda g, j=j: cls(g) == j and sel_advice(p0, g, eps) == '0', tau, avoid=S)
        adv = adv_from_label(interior(list(T)), 'B')
        Z.append(C0.with_ov([(T, adv)], name='Z%d' % (j+1)))
        YZ.append(Y.with_ov([(T, adv)], name='YZ%d' % (j+1)))
    return [C0, Y, Xc, Xu] + Z + YZ

def run(p0, eps, label):
    pr('\n=== %s: eps = %s, p0 = %s' % (label, eps, tuple(str(t) for t in p0)))
    models = build(p0, eps)
    names = [M.name for M in models]
    P = Pool(models, use_iv=True)
    pr('models:', names)
    pr('uncertified signs (should be none):', P.uncertified)
    C0, Yi, Xc, Xu = 0, 1, 2, 3
    # (1) pair level
    pr('(1) rec(C_p0,Y): add =', [ivs(x, 6) for x in P.iv[(C0, Yi)][0]], ' Phi^4 =', [ivs(x, 6) for x in P.iv[(C0, Yi)][1]])
    pr('    rec(Y,C_p0): add =', [ivs(x, 6) for x in P.iv[(Yi, C0)][0]], '-> literal AF accepts Y <=_i C_p0 at every world')
    pr('    faces met by A(rec(C_p0,Y)):', P.faces[(C0, Yi)], '; by A(rec(Y,C_p0)):', P.faces[(Yi, C0)])
    cert = P.incoh[Yi]
    pr('    incoherence certificate for Y:', cert[0], 'g1 =', cert[1] if len(cert) > 1 else '', ' g2 =', cert[2] if len(cert) > 2 else '',
       ' t =', cert[3] if len(cert) > 3 else '', ' advice at g1+t g2 =', cert[5] if len(cert) > 5 else '')
    pr('    => undominated forces C_p0 <=_i Y at all i (all-world tie with an incoherent model): direct (C) fails.')
    # (2) pumps under maximal AF
    R0 = {(u, v, j): P.base(u, v, j) is not None for u, v in itertools.permutations(range(len(models)), 2) for j in range(3)}
    tc, obl, dom, tie = check_relation(P, list(range(len(models))), R0)
    by = {}
    for j, A, B, C in tc:
        key = (j+1, P.base(A, B, j), P.base(B, C, j), P.base(C, A, j))
        by.setdefault(key, 0); by[key] += 1
    pr('(2) maximal AF (all eligible sticky accepted): %d (TC) violations, %d dominations, %d direct-(C) ties' % (len(tc), len(dom), len(tie)))
    pr('    violations by world and link pattern (A<=B, B<=C, C<=A; G guidance, A additive, S sticky):')
    for key in sorted(by): pr('      world %d  %s %s %s : %d' % (key[0], key[1], key[2], key[3], by[key]))
    sel_tc = [t for t in tc if C0 in t[1:]]
    pr('    violations containing C_p0: %d (all of shape  X <= C_p0 <= W, W < X  or rotations)' % len(sel_tc))
    for j in range(3):
        ex = [t for t in tc if t[0] == j and set(t[1:]) == {C0, Yi, Xc}]
        if ex:
            _, A, B, C = ex[0]
            pr('    example world %d: %s <= %s <= %s, %s < %s strictly (bases: %s, %s, %s)' % (
               j+1, names[A], names[B], names[C], names[C], names[A], P.base(A, B, j), P.base(B, C, j), P.base(C, A, j)))
    pr('    faces of A(rec(Xc,C_p0)) =', P.faces[(Xc, C0)], ' faces of A(rec(Xu,C_p0)) =', P.faces[(Xu, C0)])
    # (3) cascade and SAT
    nodes = list(range(len(models)))
    res = cascade(P, nodes)
    cnt = {}
    for s in res[-1]: cnt[s[0]] = cnt.get(s[0], 0) + 1
    pr('(3) greedy cascade (first violation, first allowed repair): %s after %d repairs %s' % (res[0], len(res[-1]), cnt))
    if res[0] == 'blocked':
        v = res[1]
        pr('    greedy blocked at', v[0], 'world', v[1]+1 if v[0] == 'tc' else '', [names[x] for x in v[2:]] if v[0] == 'tc' else [names[x] for x in v[1:]])
    ok, E, model = sat(P, nodes)
    pr('    exact SAT over ALL symmetric-thinning states (+ sticky subset choice, undominated, direct (C)):', 'SAT' if ok else 'UNSAT')
    if ok:
        R = relation_from_model(P, E, model)
        tc, obl, dom, tie = check_relation(P, nodes, R)
        pr('    independent re-check of that state: TC %d, unmet obligations %d, dominated %d, incoherent all-world ties %d' % (len(tc), len(obl), len(dom), len(tie)))
        for j in range(3):
            pr('    world %d: C_p0<=Y %-5s Y<=C_p0 %-5s | Xc<=C_p0 %-5s | Y<=YZ%d %-5s Y<=Z%d %-5s' % (
               j+1, R[(C0, Yi, j)], R[(Yi, C0, j)], R[(Xc, C0, j)], j+1, R[(Yi, 7+j, j)], j+1, R[(Yi, 4+j, j)]))
        sticky_kept = sorted(set((names[u], names[v], j+1) for (u, v, j), a in R.items() if a and P.base(u, v, j) == 'S' and models[u].selected))
        pr('    sticky (non-additive) acceptances out of the selected model in that state:', sticky_kept)
        thinned_add = sorted(set((names[u], names[v], j+1) for (u, v, j), a in R.items() if (not a) and P.base(u, v, j) == 'A'))
        pr('    additive acceptances removed by thinning: %d, e.g.' % len(thinned_add), thinned_add[:8])

if __name__ == '__main__':
    cfg = {
        'e1_3': ((F(9,10), F(6,100), F(4,100)), F(3,10)),
        'e1_1': ((F(9,10), F(6,100), F(4,100)), F(1,10)),
        'u_3':  ((F(35,100), F(33,100), F(32,100)), F(3,10)),
        'u_1':  ((F(35,100), F(33,100), F(32,100)), F(1,10)),
    }
    for key in (sys.argv[1:] or list(cfg)):
        run(*cfg[key], key)
    open(os.path.join(HERE, 't1_pairs_pumps.out'), 'w').write('\n'.join(out)+'\n')
