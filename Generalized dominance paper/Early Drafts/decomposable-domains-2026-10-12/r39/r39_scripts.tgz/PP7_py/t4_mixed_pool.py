"""PP7 t4: mixed triples on random pools (NUMERICS; exact cone geometry, double-precision solid
angles with exact integer determinants; exact anchor polygons; every UNSAT core is re-run with
interval masses and reported as CHECKED only if all signs are certified).

Pool around a centre p0 (near e_1 and near u):
  selected: p0 and 6 neighbours at distance r (a hexagon);
  rivals (spliced, each on a selected base):
    R  random small modifications: 1-2 small exact cones in random cells, random new advice (A/S/B/C);
    SP splices: C_p with C_q's advice on 1-3 random cells of D(C_p, C_q);
    ST sticky (PP5 Prop 4.3 type): silence -> majority on S_1,S_2,S_3 with masses (m, s m, s m), random s, m, base;
    RT returns: base improved at one world on a tiny cone.
Reports: maximal-AF violations by triple type ((C_q,C_p,X): two selected; (X,Y,C_p)/(C_p,X,Y): one selected),
greedy cascade outcome, exact SAT over all symmetric-thinning states, minimal cores."""
import sys, os, itertools, random, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from core import *
from pool import *

HERE = os.path.dirname(os.path.abspath(__file__))
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def hexagon(p0, r):
    dirs = [(2, -1, -1), (1, 1, -2), (-1, 2, -1), (-2, 1, 1), (-1, -1, 2), (1, -2, 1)]
    return [tuple(p0[t] + r*F(d[t], 3) for t in range(3)) for d in dirs]

def random_rival(rng, base, eps, kind, sel):
    B = Model(base, eps)
    cells = base_cells(base, eps)
    if kind == 'R':
        ov = []
        for _ in range(rng.choice([1, 2])):
            c = rng.choice(cells)
            g = interior(c)
            t = cone_with_mass(c, 10**rng.uniform(-5, -3.3))
            if any(in_cone(interior(list(t)), r) or in_cone(neg(interior(list(t))), r) for r, _ in ov): continue
            old = label(g, B.advice(g))
            new = rng.choice([x for x in 'ASBC' if x != old])
            ov.append((t, adv_from_label(interior(list(t)), new)))
        return B.with_ov(ov, name='R')
    if kind == 'SP':
        q = rng.choice([s for s in sel if s != base])
        Q = Model(q, eps)
        jc = arrangement(dedup_planes(normals(base, eps) + normals(q, eps) + DIAG))
        D = [c for c in jc if B.advice(interior(c)) != Q.advice(interior(c)) and dot(interior(c), (1, 1, 1)) > 0]
        rng.shuffle(D)
        ov = []
        for c in D[:rng.choice([1, 2, 3])]:
            t = largest_triangle(c)
            ov.append((t, Q.advice(interior(list(t)))))
        return B.with_ov(ov, name='SP')
    if kind == 'ST':
        sil = {0: [], 1: [], 2: []}
        for c in cells:
            g = interior(c)
            if cls(g) != 'U' and sel_advice(base, g, eps) == '0': sil[cls(g)].append(c)
        big = {w: max(sil[w], key=lambda c: mass_float(largest_triangle(c))) for w in range(3)}
        cap = min(mass_float(largest_triangle(big[w])) for w in range(3))
        s = rng.uniform(0.55, 1.0); m = cap*rng.uniform(0.05, 0.3); lead = rng.randrange(3)
        ov = []
        for w in range(3):
            t = cone_with_mass(big[w], m if w == lead else s*m)
            ov.append((t, adv_from_label(interior(list(t)), 'A')))
        return B.with_ov(ov, name='ST')
    if kind == 'RT':
        j = rng.randrange(3)
        sil = [c for c in cells if cls(interior(c)) == j and sel_advice(base, interior(c), eps) == '0']
        c = rng.choice(sil)
        t = cone_with_mass(c, 10**rng.uniform(-5.5, -4.5))
        return B.with_ov([(t, adv_from_label(interior(list(t)), 'B'))], name='RT%d' % (j+1))

def classify(P, tc):
    by = {}
    for j, A, B, C in tc:
        nsel = sum(P.M[x].selected for x in (A, B, C))
        typ = {2: '(C_q,C_p,X)', 1: '(X,Y,C_p)/(C_p,X,Y)', 0: 'rivals only', 3: 'selected only'}[nsel]
        pat = ''.join(P.base(A, B, j) + P.base(B, C, j) + P.base(C, A, j))
        by[(typ, pat)] = by.get((typ, pat), 0) + 1
    return by

def run(p0, eps, r, kinds, seed, label_):
    t0 = time.time()
    rng = random.Random(seed)
    sel = [p0] + hexagon(p0, r)
    models = [Model(p, eps) for p in sel]
    for kd in kinds:
        base = rng.choice(sel)
        models.append(random_rival(rng, base, eps, kd, sel))
    for k, M in enumerate(models):
        if not M.selected: M.name = '%s%d' % (M.name, k)
        else: M.name = 'C%d' % k
    pr('\n=== %s: eps = %s, p0 = %s, hexagon radius %s, rivals %s, seed %d' % (label_, eps, tuple(str(t) for t in p0), r, ''.join(kinds), seed))
    P = Pool(models)
    nodes = list(range(len(models)))
    nst = sum(1 for (u, v) in P.add if models[u].selected and all(a < 0 for a in P.add[(u, v)]))
    pr('records: %d; sticky records out of selected models (all add < 0): %d; incoherence certificates: %d of %d rivals'
       % (len(P.add), nst, sum(1 for u in nodes if P.incoh[u] is not None), sum(1 for u in nodes if not models[u].selected)))
    R0 = {(u, v, j): P.base(u, v, j) is not None for u, v in itertools.permutations(nodes, 2) for j in range(3)}
    tc, obl, dom, tie = check_relation(P, nodes, R0)
    pr('maximal AF: %d TC violations, %d dominated selected, %d incoherent all-world ties, %d unmet obligations' % (len(tc), len(dom), len(tie), len(obl)))
    for k, v in sorted(classify(P, tc).items()): pr('   %-22s links %s : %d' % (k[0], k[1], v))
    res = cascade(P, nodes)
    cnt = {}
    for s_ in res[-1]: cnt[s_[0]] = cnt.get(s_[0], 0) + 1
    pr('greedy cascade: %s after %d repairs %s' % (res[0], len(res[-1]), cnt))
    if res[0] == 'blocked':
        v = res[1]
        if v[0] == 'tc':
            j, A, B, C = v[1:]
            pr('   blocked at world %d: %s <= %s <= %s, %s < %s; links %s %s %s' % (j+1, models[A].name, models[B].name, models[C].name,
               models[C].name, models[A].name, P.base(A, B, j), P.base(B, C, j), P.base(C, A, j)))
        else: pr('   blocked at', v[0], [models[x].name for x in v[1:]])
    ok, E, model = sat(P, nodes)
    pr('exact SAT over all symmetric-thinning states: %s' % ('SAT' if ok else 'UNSAT'))
    info = dict(sat=ok)
    if ok:
        Rm = relation_from_model(P, E, model)
        tc2, obl2, dom2, tie2 = check_relation(P, nodes, Rm)
        pr('   re-check: TC %d, obligations %d, dominated %d, ties %d' % (len(tc2), len(obl2), len(dom2), len(tie2)))
        stick = sorted(set((models[u].name, models[v].name, j+1) for (u, v, j), a in Rm.items()
                           if a and P.base(u, v, j) == 'S' and models[u].selected))
        pr('   sticky acceptances out of selected models in the state: %d' % len(stick))
    else:
        core_ = min_core(P, nodes)
        pr('   deletion-minimal core:', [models[u].name for u in core_])
        # certify the core with interval masses
        Pc = Pool([models[u] for u in core_], use_iv=True)
        okc = sat(Pc, list(range(len(core_))))[0]
        pr('   core re-run with interval masses: %s; uncertified signs: %s' % ('SAT' if okc else 'UNSAT', Pc.uncertified))
        info['core'] = [models[u].name for u in core_]
    pr('time %.0fs' % (time.time() - t0))
    return info

if __name__ == '__main__':
    cfgs = [
        ('e1_3', (F(9,10), F(6,100), F(4,100)), F(3,10), F(1, 2000)),
        ('u_3',  (F(35,100), F(33,100), F(32,100)), F(3,10), F(1, 200)),
        ('e1_1', (F(9,10), F(6,100), F(4,100)), F(1,10), F(1, 4000)),
        ('u_1',  (F(35,100), F(33,100), F(32,100)), F(1,10), F(1, 500)),
    ]
    which = sys.argv[1:] or [c[0] for c in cfgs]
    for lab, p0, eps, r in cfgs:
        if lab not in which: continue
        # random modifications and splices only (no PP5-type sticky rivals)
        run(p0, eps, r, ['R']*6 + ['SP']*4 + ['RT']*2, 1, lab + ' / R+SP+RT')
        run(p0, eps, r, ['R']*6 + ['SP']*4 + ['RT']*2, 2, lab + ' / R+SP+RT')
        # with sticky rivals
        run(p0, eps, r, ['ST']*3 + ['R']*4 + ['SP']*2 + ['RT']*2, 3, lab + ' / ST+R+SP+RT')
    open(os.path.join(HERE, 't4_mixed_pool_%s.out' % '_'.join(which)), 'w').write('\n'.join(out)+'\n')
