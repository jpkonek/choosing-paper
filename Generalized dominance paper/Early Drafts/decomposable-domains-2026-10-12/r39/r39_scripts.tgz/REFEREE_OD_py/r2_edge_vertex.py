"""Edge and vertex versions of Theorem 3 (referee supplement).  Exact rationals + LP cross-checks.
C coherent with K supported on the edge I={i,j} = {0,1} (k=2), imprecise (A,S,B on M0,M1) or precise
(A,B only: audit's family at boundary indices).  Rival X arbitrary (four advices).
Run: python3 -I -B r2_edge_vertex.py   (writes r2_edge_vertex.out)"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
from scipy.optimize import linprog

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s); out.append(s)

i, j, k = 0, 1, 2
for precise in (False, True):
    T = change_types((i, j), precise)
    pr('== edge {1,2}, precise=%s: %d change types' % (precise, len(T)))
    for t in T:
        pr('   ', t[0], t[1], '->', t[2], 'delta', t[3])
    # E0 edge count: delta_i+delta_j >= 0, equality iff regular change on M_i or M_j
    eq = [t for t in T if t[3][i] + t[3][j] == 0]
    pr('E0 min(delta_i+delta_j) =', min(t[3][i] + t[3][j] for t in T),
       '; equality types:', [(t[0], t[1], t[2]) for t in eq])
    pr('   equality types are exactly regular changes on M_i u M_j:',
       all(t[0] in ('M0', 'M1') and t[2] != 'C' for t in eq) and
       len(eq) == sum(1 for t in T if t[0] in ('M0', 'M1') and t[2] != 'C'))
    pr('   on non-equality types delta_i,delta_j >= 1:', all(t[3][i] >= 1 and t[3][j] >= 1 for t in T if t not in eq),
       ' min(delta_i+delta_j) there:', min(t[3][i] + t[3][j] for t in T if t not in eq))
    for kap in [F(1), F(3, 2), F(2), F(3), F(4), F(10)]:
        e1 = min(phi_int(t[3][i], kap) + phi_int(t[3][j], kap) for t in T)
        e2 = min(min(phi_int(t[3][j], kap) + (kap + 1) / 2 * t[3][i], phi_int(t[3][i], kap) + (kap + 1) / 2 * t[3][j]) for t in T)
        pr('   kappa=%s: E1 min(Phi_i+Phi_j)=%s [claim kappa-1=%s]; E2 min(Phi_j+((k+1)/2)delta_i)=%s [claim (kappa-1)/2=%s]'
           % (kap, e1, kap - 1, e2, (kap - 1) / 2))
    # LP optimality of E2 coefficients
    for kap in [1.5, 2, 3, 4, 8]:
        A = []; bb = []
        for t in T:
            d = t[3]
            A.append([-d[i], 1.0]); bb.append(float(phi_int(d[j], kap)))
        res = linprog([0, -1], A_ub=A, b_ub=bb, bounds=[(0, None), (None, None)])
        pr('   LP kappa=%s: best (alpha,gamma) for Phi_j+alpha*b_i>=gamma mu(D): (%.6f,%.6f); claim (%.6f,%.6f)'
           % (kap, res.x[0], res.x[1], (kap + 1) / 2, (kap - 1) / 2))
    # LP: min b_i subject to Phi_j<=0 , mu(D)=1
    for kap in [1.5, 2, 3, 4, 8]:
        nT = len(T)
        res = linprog([float(t[3][i]) for t in T],
                      A_ub=[[float(phi_int(t[3][j], kap)) for t in T]], b_ub=[0.0],
                      A_eq=[[1.0] * nT], b_eq=[1.0], bounds=[(0, None)] * nT)
        pr('   LP kappa=%s: min b_i given Phi_j<=0 = %.6f ; (kappa-1)/(kappa+1) = %.6f' % (kap, res.fun, (kap - 1) / (kap + 1)))
    # LP: min second-in-I margin, i.e. min over records of min(Phi_i,Phi_j) given max(b_i,b_j) <= beta
    for kap in [2, 4]:
        nT = len(T)
        for beta in [0.0, 0.1, (kap - 1) / (kap + 1) - 1e-9, (kap - 1) / (kap + 1) + 0.05]:
            # vars w, z : maximise -z ... we want min of min(Phi_i,Phi_j): minimise z s.t. Phi_j <= z (by symmetry use j), b_i,b_j<=beta
            A = [[float(phi_int(t[3][j], kap)) for t in T] + [-1.0],
                 [float(t[3][i]) for t in T] + [0.0], [float(t[3][j]) for t in T] + [0.0]]
            res = linprog([0.0] * nT + [1.0], A_ub=A, b_ub=[0.0, beta, beta],
                          A_eq=[[1.0] * nT + [0.0]], b_eq=[1.0], bounds=[(0, None)] * nT + [(None, None)])
            pr('   LP kappa=%s beta=%.4f: min Phi_j given b_i,b_j<=beta = %.6f ; formula (k-1)/2-(k+1)/2*beta = %.6f'
               % (kap, beta, res.fun, (kap - 1) / 2 - (kap + 1) / 2 * beta))

# Counterexample: no kappa guarantees two eligible defenders on an edge (precise edge model suffices)
pr('== no-kappa counterexample (M_i: A->S mass m improves i; B->S mass e worsens i)')
d_imp = delta('M0', 'A', 'S'); d_wor = delta('M0', 'B', 'S')
pr('   deltas', d_imp, d_wor)
for kap in [F(2), F(4), F(100), F(10 ** 6)]:
    m = F(1); e = m / (2 * kap)
    Phi, b, P, Q, mu = agg([(d_imp, m), (d_wor, e)], kap)
    pr('   kappa=%s e=%s: nu(P)=%s nu(Q)=%s Phi=%s b=%s ; guidance at i? %s at j? %s ; eligible in I: %s'
       % (kap, e, [str(x) for x in P[:2]], [str(x) for x in Q[:2]], [str(x) for x in Phi[:2]], [str(x) for x in b[:2]],
          Q[i] == 0, Q[j] == 0, [l + 1 for l in (i, j) if Phi[l] >= 0]))
# kappa<1: edge coverage by the pool fails
pr('== kappa<1: balanced regular changes on M_i have Phi_i=Phi_j<0')
for kap in [F(1, 2), F(9, 10)]:
    Phi, b, P, Q, mu = agg([(d_imp, F(1)), (d_wor, F(1))], kap)
    pr('   kappa=%s Phi=%s' % (kap, [str(x) for x in Phi[:2]]))
# Sharp examples for E1/E2 equality and for the (kappa-1)/(kappa+1) margin
for kap in [F(2), F(4)]:
    Phi, b, P, Q, mu = agg([(d_imp, F(1, 2)), (d_wor, F(1, 2))], kap)
    pr('   E1/E2 equality kappa=%s (balanced): Phi_i+Phi_j=%s=(kappa-1)mu, Phi_j+((k+1)/2)b_i=%s' % (kap, Phi[i] + Phi[j], Phi[j] + (kap + 1) / 2 * b[i]))
    x = 1 / (kap + 1)  # mass worsening j  (= improving i ... ) ; choose weights so Phi_j = 0
    # d_imp improves i, worsens j ; d_wor worsens i, improves j.  Phi_j = kap*w(d_imp) - w(d_wor) = 0
    Phi, b, P, Q, mu = agg([(d_imp, x), (d_wor, 1 - x)], kap)
    pr('   margin example kappa=%s: Phi=%s b=%s -> b_i=%s=(k-1)/(k+1)' % (kap, [str(t) for t in Phi[:2]], [str(t) for t in b[:2]], b[i]))

# Vertex: K = {e_i}
pr('== vertex {1}')
Tv = change_types((0,), True)
pr('   types', len(Tv), ' min delta_i =', min(t[3][0] for t in Tv), '(every change worsens world 1: guidance, Phi_1>=kappa mu(D), b_1>=mu(D))')
pr('   other worlds on vertex records can be pure improvements, e.g.', [(t[0], t[1], t[2], t[3]) for t in Tv if t[3][1] < 0 and t[3][2] < 0][:3])

open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'r2_edge_vertex.out'), 'w').write('\n'.join(out) + '\n')
