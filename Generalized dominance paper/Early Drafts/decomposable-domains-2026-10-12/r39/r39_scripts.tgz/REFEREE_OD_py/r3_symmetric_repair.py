"""Symmetric version of PP5's local repair, on PP5's 227-model local scan (NUMERICS: exact cones,
double-precision masses; reads PP5_py/scan_local.npz and PP5_py modules, writes nothing there).
World 1 loses BOTH directions of every record within rho<=eta of d_ab=rec(C_a,C_b) and of d_bc=rec(C_b,C_c);
the forward balls are added at worlds 3 and 2, the reverse balls at worlds 2 and 3 (audit section 3).
Run: python3 -I -B r3_symmetric_repair.py"""
import sys, os
here = os.path.dirname(os.path.abspath(__file__))
pp5 = os.path.join(os.path.dirname(here), 'PP5_py')
sys.path.insert(0, pp5)
sys.dont_write_bytecode = True
import numpy as np
from fast import Model, rho
from tc_analyse import relations, violations

D = dict(np.load(os.path.join(pp5, 'scan_local.npz')))
pts = [tuple(p) for p in D['pts']]; N = len(pts)
M = [Model(p) for p in pts]
idx = {tuple(round(t, 6) for t in p): k for k, p in enumerate(pts)}
ia, ib, ic = idx[(0.9, 0.05, 0.05)], idx[(0.901, 0.08, 0.019)], idx[(0.902, 0.049, 0.049)]
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def near(k, r): return [j for j in range(N) if max(abs(pts[j][t] - pts[k][t]) for t in range(3)) <= r + 1e-12]
rows = {}
for (s, t) in [(ia, ib), (ib, ic)]:
    rows[(s, t)] = [(x, y, rho(M[x], M[y], M[s], M[t])) for x in near(s, 0.0091) for y in near(t, 0.0091) if x != y]
# isometry check: rho(rec(y,x), rec(t,s)) == rho(rec(x,y), rec(s,t)) on a sample
smp = rows[(ia, ib)][:40]
iso = max(abs(rho(M[y], M[x], M[ib], M[ia]) - r) for (x, y, r) in smp)
pr('rev is a rho-isometry (sample of 40): max |difference| = %.2e' % iso)
Phi, Add = D['Phi'], D['Add']
pr('centre records (kappa=2 Phi):')
for (s, t, nm) in [(ia, ib, 'd_ab'), (ib, ic, 'd_bc')]:
    pr('  %s Phi=%s add=%s | rev Phi=%s add=%s | greedy W=%s rev W=%s' % (
        nm, np.round(Phi[s, t], 6), np.round(Add[s, t], 6), np.round(Phi[t, s], 6), np.round(Add[t, s], 6),
        [i + 1 for i in range(3) if D['WG'][s, t, i]], [i + 1 for i in range(3) if D['WG'][t, s, i]]))

G = relations(D, 'G')
def tc_counts(R):
    res = []
    for i in range(3):
        A = R[i].astype(np.int64); S = R[i] & ~R[i].T
        bad = ((A @ A) > 0) & S.T; np.fill_diagonal(bad, False); res.append(bad)
    return res
badG = tc_counts(G)
pr('greedy violating (x,z) pairs per world:', [int(b.sum()) for b in badG])

def build(eta, minimal):
    R = [r.copy() for r in G]
    eye = np.eye(N, dtype=bool)
    guid = [(D['Q'][:, :, i] <= 1e-12) & ~eye for i in range(3)]
    elig_ok = True; touched_guid = False
    for (s, t), wf, wr in [((ia, ib), 2, 1), ((ib, ic), 1, 2)]:
        F = np.zeros((N, N), dtype=bool)
        for (x, y, r) in rows[(s, t)]:
            if r <= eta: F[x, y] = True
        for Mk, w in [(F, wf), (F.T, wr)]:
            if (Mk & guid[0]).any(): touched_guid = True
            R[0][Mk] = False
            for (x, y) in zip(*np.nonzero(Mk)):
                if minimal and (R[1][x, y] or R[2][x, y]):
                    continue
                if Phi[x, y, w] < 0: elig_ok = False
                R[w][x, y] = True
    for i in range(3): R[i] |= eye
    return R, elig_ok, touched_guid

for eta in [0.001, 0.0025, 0.005]:
    for minimal in (False, True):
        R, ok, tg = build(eta, minimal)
        bad = tc_counts(R)
        new = [int((bad[i] & ~badG[i]).sum()) for i in range(3)]
        cover = all(R[0][x, y] or R[1][x, y] or R[2][x, y] for x in range(N) for y in range(N))
        # domination among selected models: y dominates x iff y<=_i x at all i and strictly at some i
        dom = 0
        for x in range(N):
            for y in range(N):
                if x != y and all(R[i][y, x] for i in range(3)) and any(not R[i][x, y] for i in range(3)):
                    dom += 1
        diag = R[0][ia, ib] and R[0][ib, ic] and R[0][ic, ia] and not R[0][ia, ic]
        pr('eta=%.4f %s: receiving-world eligibility %s; world-1 guidance touched %s; W nonempty everywhere %s; dominated pairs %d'
           % (eta, 'minimal-add' if minimal else 'add-all  ', ok, tg, cover, dom))
        pr('    violating pairs per world %s ; NEW vs greedy per world %s ; diagnostic triple violating: %s'
           % ([int(b.sum()) for b in bad], new, bool(diag)))
        for i in (1, 2):
            if new[i]:
                ex = list(zip(*np.nonzero(bad[i] & ~badG[i])))[:2]
                for (x, z) in ex:
                    ys = [y for y in np.nonzero(R[i][x] & R[i][:, z])[0] if y not in (x, z)]
                    pr('      world %d new: x=%s y=%s z=%s' % (i + 1, pts[x], pts[ys[0]] if ys else None, pts[z]))
open(os.path.join(here, 'r3_symmetric_repair.out'), 'w').write('\n'.join(out) + '\n')
