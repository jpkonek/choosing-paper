"""Referee checks of AUDIT_optional_defenders sections 1-2 (interior / three worlds).  Exact rationals.
Run: python3 -I -B r1_interior.py   (writes r1_interior.out)"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
from itertools import combinations
import numpy as np
from scipy.optimize import linprog

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s); out.append(s)

# ---- 0. every advice change changes rank at every world (any old, any new) --------------------
bad = [(c, o, n) for c in CLASSES for o in ADV for n in ADV if o != n and 0 in delta(c, o, n)]
pr('0. changes (any old/new, 4 advices, 4 classes) that leave some world rank unchanged:', bad)

# ---- 1. Lemma 1 on every face I: each coherent-old change worsens some world of I ---------------
for r in (1, 2, 3):
    for I in combinations(range(3), r):
        T = change_types(I)
        fails = [t for t in T if not any(t[3][w] > 0 for w in I)]
        pr('1. Lemma 1, I=%s: %d change types, failures %s' % (I, len(T), fails))

# ---- 2. Theorem 3 pointwise inequality --------------------------------------------------------
T = change_types()
pr('2. interior change types (coherent old, 4-advice new):', len(T))
# LHS - RHS is affine in kappa; check at kappa=3 and slope
def lhs_minus_rhs(d, i, j, k, kap):
    return phi_int(d[j], kap) + phi_int(d[k], kap) + (kap + 1) / F(2) * d[i] - (kap - 3) / F(2)
viol = []; n = 0; mins = {}
for kap in [F(3), F(7, 2), F(4), F(10), F(100)]:
    for (c, o, nw, d) in T:
        for (i, j, k) in permutations(range(3)):
            n += 1
            v = lhs_minus_rhs(d, i, j, k, kap)
            mins[kap] = min(mins.get(kap, v), v)
            if v < 0: viol.append((kap, c, o, nw, i))
slopes = [lhs_minus_rhs(d, i, j, k, F(4)) - lhs_minus_rhs(d, i, j, k, F(3)) for (_, _, _, d) in T for (i, j, k) in permutations(range(3))]
pr('   checks', n, 'violations', len(viol), 'min slack per kappa', {str(a): str(b) for a, b in mins.items()},
   'min slope in kappa', min(slopes))
pr('   => holds for every kappa>=3 (affine in kappa, >=0 at 3, slope>=0).')
# at kappa<3 the inequality fails (A<->B changes, a=2)
for kap in [F(2), F(5, 2), F(29, 10)]:
    worst = min(lhs_minus_rhs(d, i, j, k, kap) for (_, _, _, d) in T for (i, j, k) in permutations(range(3)))
    pr('   kappa=%s: min pointwise slack %s (negative => statement needs kappa>=3)' % (kap, worst))
# optimal coefficients: maximise gamma s.t. Phi_j+Phi_k+alpha*delta_i >= gamma on every type (LP in alpha,gamma)
for kap in [3, 3.5, 4, 6]:
    A = []; bvec = []
    for (_, _, _, d) in T:
        for (i, j, k) in permutations(range(3)):
            # -(alpha*d_i) + gamma <= Phi_j+Phi_k
            A.append([-d[i], 1.0]); bvec.append(float(phi_int(d[j], kap) + phi_int(d[k], kap)))
    res = linprog([0, -1], A_ub=A, b_ub=bvec, bounds=[(0, None), (None, None)])
    pr('   LP kappa=%s: best (alpha,gamma)=(%.6f,%.6f); audit (%.6f,%.6f)' % (kap, res.x[0], res.x[1], (kap + 1) / 2, (kap - 3) / 2))

# ---- 3. sharpness of 3: PP5 silence-to-majority example ----------------------------------------
SA = {k: delta('M%d' % k, 'S', 'A') for k in range(3)}
pr('3. silence->majority deltas:', SA)
for kap in [F(2), F(9, 4), F(5, 2), F(11, 4), F(29, 10)]:
    lo, hi = F(1, 2), min(kap / 2, 1 / (kap - 1))
    s = (lo + hi) / 2
    m = F(1)
    Phi, b, P, Q, mu = agg([(SA[0], m), (SA[1], s * m), (SA[2], s * m)], kap)
    pr('   kappa=%s s=%s: b=%s Phi=%s  #eligible=%d' % (kap, s, [str(x) for x in b], [str(x) for x in Phi], sum(x >= 0 for x in Phi)))
for kap in [F(2), F(4)]:
    Phi, b, P, Q, mu = agg([(SA[0], F(1)), (SA[1], F(3, 4)), (SA[2], F(3, 4))], kap)
    pr('   s=3/4 kappa=%s: Phi/m=%s' % (kap, [str(x) for x in Phi]))
# kappa<2: some records have no eligible world at all (counting coverage needs kappa>=2)
for kap in [F(1), F(3, 2), F(19, 10)]:
    Phi, b, P, Q, mu = agg([(SA[0], F(1)), (SA[1], F(1)), (SA[2], F(1))], kap)
    pr('   kappa=%s equal masses: Phi=%s (no eligible world)' % (kap, [str(x) for x in Phi]))
# pointwise sum Phi_1+Phi_2+Phi_3 >= (kappa-2) per unit mass
for kap in [F(2), F(3), F(4)]:
    mn = min(sum(phi_int(d[l], kap) for l in range(3)) for (_, _, _, d) in T)
    pr('   kappa=%s: min pointwise sum of Phi = %s (=kappa-2: %s)' % (kap, mn, mn == kap - 2))

# ---- 4. second-largest bound (kappa-3)/4 and its sharpness -------------------------------------
for kap in [F(7, 2), F(4), F(6)]:
    # exact sharp example: masses 2,1,1 (/4) of silence->majority on M1,M2,M3
    Phi, b, P, Q, mu = agg([(SA[0], F(1, 2)), (SA[1], F(1, 4)), (SA[2], F(1, 4))], kap)
    srt = sorted(Phi)
    pr('4. kappa=%s example mu(D)=%s b=%s Phi=%s second-largest=%s bound=%s' % (kap, mu, [str(x) for x in b], [str(x) for x in Phi], srt[1], (kap - 3) / 4))
# LP: minimise second-largest Phi subject to b<=0, mu(D)=1 (over all interior change types)
for kap in [3.5, 4, 6]:
    best = None
    for (j, k) in [(1, 2)]:  # by symmetry of the type set under world permutations
        nT = len(T)
        # vars: w_t (nT), z ; minimise z s.t. Phi_j<=z, Phi_k<=z, b_l<=0, sum w=1
        c = [0.0] * nT + [1.0]
        A = []; bb = []
        for l in (j, k):
            A.append([float(phi_int(t[3][l], kap)) for t in T] + [-1.0]); bb.append(0.0)
        for l in range(3):
            A.append([float(t[3][l]) for t in T] + [0.0]); bb.append(0.0)
        res = linprog(c, A_ub=A, b_ub=bb, A_eq=[[1.0] * nT + [0.0]], b_eq=[1.0], bounds=[(0, None)] * nT + [(None, None)])
        best = res.fun
    pr('   LP kappa=%s: min second-largest Phi = %.6f; (kappa-3)/4 = %.6f' % (kap, best, (kap - 3) / 4))
# relaxed hypothesis: two eligible whenever max_l b_l < (kappa-3)/(kappa+1) mu(D); LP check that it is the exact threshold
for kap in [3.5, 4, 6]:
    nT = len(T)
    # maximise min_l... : find min over records with Phi_2<0,Phi_3<0 (closure: <=0) of max_l b_l ; by symmetry
    # vars w, z: minimise z s.t. b_l<=z (all l), Phi_1<=0 , Phi_2<=0, sum w=1  (two ineligible worlds 1,2 -> index 0,1)
    c = [0.0] * nT + [1.0]
    A = []; bb = []
    for l in range(3):
        A.append([float(t[3][l]) for t in T] + [-1.0]); bb.append(0.0)
    for l in (0, 1):
        A.append([float(phi_int(t[3][l], kap)) for t in T] + [0.0]); bb.append(0.0)
    res = linprog(c, A_ub=A, b_ub=bb, A_eq=[[1.0] * nT + [0.0]], b_eq=[1.0], bounds=[(0, None)] * nT + [(None, None)])
    pr('   LP kappa=%s: min of max_l b_l when two worlds are (weakly) ineligible = %.6f; (kappa-3)/(kappa+1) = %.6f'
       % (kap, res.fun, (kap - 3) / (kap + 1)))

open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'r1_interior.out'), 'w').write('\n'.join(out) + '\n')
