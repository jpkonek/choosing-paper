"""Theorem 4 (symmetric thinning) exhaustively on 3 and 4 objects, plus the one-sided contrast.
(TC): x<=y, y<=z  =>  not (z<x), where z<x means z<=x and not x<=z.  Triples may repeat objects.
Run: python3 -I -B r4_thinning.py"""
import os
from itertools import combinations, product

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s); out.append(s)

def viol(n, R):
    V = set()
    for x, y, z in product(range(n), repeat=3):
        if (x, y) in R and (y, z) in R and (z, x) in R and (x, z) not in R:
            V.add((x, y, z))
    return V

for n in (3, 4):
    off = [(x, y) for x in range(n) for y in range(n) if x != y]
    pairs = list(combinations(range(n), 2))
    refl = {(x, x) for x in range(n)}
    cases = new_sym = new_one = 0
    for bits in range(1 << len(off)):
        R = refl | {off[t] for t in range(len(off)) if bits >> t & 1}
        V = viol(n, R)
        for mask in range(1 << len(pairs)):
            cases += 1
            dele = [pairs[t] for t in range(len(pairs)) if mask >> t & 1]
            Rs = R - {(x, y) for (x, y) in dele} - {(y, x) for (x, y) in dele}
            if viol(n, Rs) - V: new_sym += 1
            Ro = R - {(x, y) for (x, y) in dele}          # one-sided deletion (x->y only)
            if viol(n, Ro) - V: new_one += 1
    pr('n=%d: %d (relation, deletion-mask) cases; symmetric deletions creating a new violation: %d; '
       'one-sided deletions creating one: %d' % (n, cases, new_sym, new_one))
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'r4_thinning.out'), 'w').write('\n'.join(out) + '\n')
