"""Exact change-type enumeration for three worlds (referee of AUDIT_optional_defenders).

Ranks (BRIEF36 convention): good 0 < silent 1 < bad 2 < contradictory 3.
A problem {g,-g} is oriented so that the majority worlds have positive sign.
Classes: 'U' (unanimous; all three worlds positive), and 'M0','M1','M2' (world k is the minority).
Advice: 'A' accept the oriented gamble, 'S' silence, 'B' accept its negation, 'C' contradiction.
"""
from fractions import Fraction as F
from itertools import permutations

ADV = ['A', 'S', 'B', 'C']
CLASSES = ['U', 'M0', 'M1', 'M2']


def sign(cls, w):
    if cls == 'U':
        return +1
    return -1 if int(cls[1]) == w else +1


def rank(cls, w, adv):
    s = sign(cls, w)
    if adv == 'S':
        return 1
    if adv == 'C':
        return 3
    good = 'A' if s > 0 else 'B'
    return 0 if adv == good else 2


def delta(cls, old, new):
    return tuple(rank(cls, w, new) - rank(cls, w, old) for w in range(3))


def coherent_old(cls, I, precise=False):
    """Advice options a coherent D_K with K supported on the face I can give on class cls
    (up to null sets).  On problems unanimous within I the advice is forced (correct for I).
    On problems mixed within I: A, S, B for an imprecise K with suitable shape; a precise K
    (a point) is never silent.  For |I|=3 'precise=False' is the interior case."""
    sg = {sign(cls, w) for w in I}
    if len(sg) == 1:
        return ['A'] if sg == {+1} else ['B']
    return ['A', 'B'] if precise else ['A', 'S', 'B']


def change_types(I=(0, 1, 2), precise=False):
    """All (cls, old, new, delta) with old coherent for support I and new != old (four-advice)."""
    out = []
    for cls in CLASSES:
        for old in coherent_old(cls, I, precise):
            for new in ADV:
                if new != old:
                    out.append((cls, old, new, delta(cls, old, new)))
    return out


def phi_int(d, k):
    """pointwise integrand of Phi^kappa = kappa*nu(P) - nu(Q):  kappa*d^+ - d^-."""
    return k * max(d, 0) - max(-d, 0)


def agg(types_weights, k):
    """types_weights: list of (delta, weight).  Returns (Phi^k vector, b vector, nu(P), nu(Q), mu(D))."""
    P = [F(0)] * 3
    Q = [F(0)] * 3
    mu = F(0)
    for d, w in types_weights:
        mu += w
        for l in range(3):
            P[l] += w * max(d[l], 0)
            Q[l] += w * max(-d[l], 0)
    Phi = [k * P[l] - Q[l] for l in range(3)]
    b = [P[l] - Q[l] for l in range(3)]
    return Phi, b, P, Q, mu
