"""Negative controls for Lemma Y3.3 and Theorem Y3.2 (exact):
 (i)  eta above 1/(A+1): the B1-corner decision at u and the T1 decision DO differ somewhere on Gamma_eta;
 (ii) the cube [1,A]^3 corner decision at u differs from T1 on near-plane gambles (so the cube family cannot replace B1);
 (iii) the box {1} x [1/A, A]^2 (posterior-type edges) also differs."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from y3common import *
rng = random.Random(7)
for eps in [Fr(1, 10), Fr(3, 10), Fr(1, 2)]:
    eps_, c0, lam, A = params(eps)
    V = T1_vertices(eps)
    B1 = [(Fr(1), Fr(1)), (Fr(1), A), (Fr(1), A)]
    cube = [(Fr(1), A)] * 3
    Bp = [(Fr(1), Fr(1)), (1 / A, A), (1 / A, A)]
    res = {}
    for name, eta, B in [("B1, eta=1.6/(A+1)", Fr(16, 10) / (A + 1), B1),
                         ("cube, eta=1/(2(A+1))", 1 / (2 * (A + 1)), cube),
                         ("{1}x[1/A,A]^2, eta=1/(2(A+1))", 1 / (2 * (A + 1)), Bp)]:
        bad = 0; ex = None
        for _ in range(20000):
            g2 = Fr(1); g3 = -Fr(rng.randint(0, 2000), 2000) * 2 / A
            g1 = eta * Fr(rng.randint(-1000, 1000), 1000)
            g = (g1, g2, g3) if rng.random() < .5 else (g1, g3, g2)
            s1, s2 = sgn(dot(box_corner(B, g), g)), sgn(P(V, g))
            if s1 and s2 and s1 != s2:
                bad += 1; ex = ex or g
        res[name] = (bad, ex)
    print(f"eps={eps}, A={A}")
    for k, (b, ex) in res.items():
        print(f"   {k}: {b} mismatches of 20000; example g = {tuple(str(x) for x in ex) if ex else None}")
