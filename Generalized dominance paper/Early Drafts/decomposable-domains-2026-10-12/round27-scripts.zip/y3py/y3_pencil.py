"""CHECK (exact) of the pointwise feasibility remark in Y3 section 5 (question Q_Y3).
Blow-up coordinates at e1: weights p ~ (1,s,t), credal points k ~ (1,k2,k3).  With the posterior edge family
K'(s0,0) = [s0/A, s0 A] x {0}, an additive plan with T1 in C_L needs, at every (s,t) on the line through (1,1)
and (s0,0):   max_{K'(s,t)} (c k3 - k2) = -s0/A  with c = (1 - s0/A)/A        (pencil of F3-crossing gambles)
              max_{K'(s,t)} (c' k2 - k3) = A c' - 1 with c' = 1/(A - s0 A)    (pencil of F2-crossing gambles).
We evaluate both sides for the posterior triangle and the cube hexagon at (s,t) = (1/50, 1/100), A = 3/2."""
from fractions import Fraction as Fr
A = Fr(3, 2); s = Fr(1, 50); t = Fr(1, 100)
s0 = (s - t) / (1 - t)
c = (1 - s0 / A) / A; cp = 1 / (A - s0 * A)
post = [(s / A, t / A), (s * A, t), (s, t * A)]
cube = post + [(s * A, t * A), (s / A, t), (s, t / A)]
req1 = -s0 / A; req2 = A * cp - 1
# T1 boundary check of the two gambles (g1, 1, -c) and (g1', -c', 1): P_T1 = 0
lam = A - 1
def PT1(g): return min(sum(x for x in g) + lam * g[k] for k in range(3))
print("T1-boundary checks:", PT1((A * c - 1, Fr(1), -c)), PT1((A * cp - 1, -cp, Fr(1))))
for name, K in [("posterior", post), ("cube", cube)]:
    v1 = max(c * k3 - k2 for k2, k3 in K); v2 = max(cp * k2 - k3 for k2, k3 in K)
    print(f"{name:9s}: max(c k3 - k2) = {float(v1):+.6f} (required {float(req1):+.6f});  "
          f"max(c' k2 - k3) = {float(v2):+.6f} (required {float(req2):+.6f})")
v2p = max(cp * k2 - k3 for k2, k3 in post); v2c = max(cp * k2 - k3 for k2, k3 in cube)
print("pencil (ii) met exactly:", v2p == req2, v2c == req2, " (attained at the shared vertex (sA, t))")
print("pencil (i): posterior < required < cube:", max(c*k3-k2 for k2,k3 in post) < req1 < max(c*k3-k2 for k2,k3 in cube))
