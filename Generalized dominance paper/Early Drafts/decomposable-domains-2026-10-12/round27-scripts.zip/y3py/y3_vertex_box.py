"""CHECK (exact rational arithmetic) of the pointwise facts behind Theorem Y3.2.

Field Psi^(1): for a gamble g put m(g) := corner of B1 = {1} x [1,A] x [1,A] for the signs of g when
g is in Gamma_eta := {|g1| <= eta * max(|g2|,|g3|)}, and m(g) := 1 + lam e_k(g), k(g) = argmin_k v_k.g
(the T1 vertex active at g) otherwise.  Bayes at weight w accepts g iff w.(m(g) (.) g) > 0.

(a) Lemma Y3.3: on Gamma_eta, sign(corner_B1(g).g) == sign(P_T1(g))   [box decision at u = T1 decision]
(b) on N = {A (w2+w3) <= eta' w1}: field decision == decision of D_{nu(w (.) B1)} for every g
(c) at u: field decision == D_T1 decision for every g
Samples: generic, adversarial (|g1| close to eta*M, |g3| tiny, near T1's boundary), and w on edges / at e1.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from y3common import *

def field_m(g, eps, eta):
    eps_, c0, lam, A = params(eps)
    M = max(abs(g[1]), abs(g[2]))
    if abs(g[0]) <= eta * M:
        B1 = [(Fr(1), Fr(1)), (Fr(1), A), (Fr(1), A)]
        return box_corner(B1, g)
    V = T1_vertices(eps)
    k = min(range(3), key=lambda k: dot(V[k], g))
    return tuple(1 + (lam if j == k else 0) for j in range(3))

def gen_g(rng, eps, eta, mode):
    if mode == 0:   # generic
        return tuple(rand_rat(rng) for _ in range(3))
    g2, g3 = rand_rat(rng), rand_rat(rng)
    M = max(abs(g2), abs(g3))
    if mode == 1:   # inside Gamma_eta, |g1| up to eta*M
        return (eta * M * rand_rat(rng), g2, g3)
    if mode == 2:   # |g3| tiny relative to |g1|  (sub-case g1 < -|g3| of Lemma Y3.3)
        g2 = abs(g2) + Fr(1, 10)
        g1 = -eta * g2 * Fr(rng.randint(500, 1000), 1000)
        return (g1, g2, -abs(g1) * Fr(rng.randint(0, 999), 1000))
    if mode == 3:   # near T1's boundary through the crossing (0, A, -1) and (0,-1,A)
        eps_, c0, lam, A = params(eps)
        a = eta * Fr(rng.randint(-1000, 1000), 1000) / 2
        c = (1 + a) / A + Fr(rng.randint(-50, 50), 100000)
        return (a, Fr(1), -c) if rng.random() < .5 else (a, -c, Fr(1))
    if mode == 4:   # just outside Gamma_eta
        return (eta * M * (1 + Fr(rng.randint(1, 50), 1000)) * (1 if rng.random() < .5 else -1), g2, g3)

def gen_w(rng, eps, etap):
    eps_, c0, lam, A = params(eps)
    t = rng.random()
    s23 = etap / A * Fr(rng.randint(0, 1000), 1000)   # (w2+w3)/w1 <= eta'/A
    if t < .2: a = Fr(0)                               # edge e1-e3
    elif t < .4: a = Fr(1)                             # edge e1-e2
    else: a = Fr(rng.randint(0, 1000), 1000)
    w = (Fr(1), s23 * a, s23 * (1 - a))
    s = sum(w)
    return tuple(x / s for x in w)

rng = random.Random(20261016)
for eps in [Fr(1, 20), Fr(1, 10), Fr(3, 10), Fr(1, 2), Fr(4, 5)]:
    eps_, c0, lam, A = params(eps)
    eta = 1 / (2 * (A + 1)); etap = eta / 2
    V = T1_vertices(eps)
    B1 = [(Fr(1), Fr(1)), (Fr(1), A), (Fr(1), A)]
    mis_a = mis_b = mis_c = 0; na = nb = nc = 0; skipped = 0
    for it in range(6000):
        mode = it % 5
        g = gen_g(rng, eps, eta, mode)
        M = max(abs(g[1]), abs(g[2]))
        # (a)
        if abs(g[0]) <= eta * M:
            s1, s2 = sgn(dot(box_corner(B1, g), g)), sgn(P(V, g))
            if s1 == 0 or s2 == 0: skipped += 1
            else:
                na += 1; mis_a += (s1 != s2)
        # (b)
        w = gen_w(rng, eps, etap)
        if w[0] < 1 or True:
            m = field_m(g, eps, eta)
            s1 = sgn(dot(w, had(m, g)))
            s2 = sgn(P(family_vertices(w, B1), g))
            if s1 == 0 or s2 == 0: skipped += 1
            else:
                nb += 1; mis_b += (s1 != s2)
        # (c)
        m = field_m(g, eps, eta)
        s1, s2 = sgn(sum(had(m, g))), sgn(P(V, g))
        if s1 == 0 or s2 == 0: skipped += 1
        else:
            nc += 1; mis_c += (s1 != s2)
    # vertex e1 itself
    e1 = (Fr(1), Fr(0), Fr(0))
    mis_e = 0
    for _ in range(500):
        g = gen_g(rng, eps, eta, rng.randrange(5))
        if g[0] == 0: continue
        m = field_m(g, eps, eta)
        mis_e += (sgn(dot(e1, had(m, g))) != sgn(g[0]))
    print(f"eps={eps}: A={A}, eta={eta}, eta'={etap}")
    print(f"  (a) corner(B1)-decision at u vs T1 on Gamma_eta: {na} gambles, {mis_a} mismatches")
    print(f"  (b) field vs nu(w.B1) on N (edges, interior, near e1): {nb} gambles, {mis_b} mismatches")
    print(f"  (c) field at u vs T1, all gambles: {nc} gambles, {mis_c} mismatches")
    print(f"  (e1) field at e1 vs B^1 = {{g1>0}}: mismatches {mis_e};  exact ties skipped: {skipped}")
