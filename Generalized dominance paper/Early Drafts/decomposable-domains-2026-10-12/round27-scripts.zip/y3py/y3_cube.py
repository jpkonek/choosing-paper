"""CHECK (exact) for Proposition Y3.5 / Y3.6 (the cube family nu(p (.) [1,A]^3)).
(1) cube decision == 'double attribution' field F^D (X2.6 with the caution cost charged to BOTH majority worlds)
(2) cube family == posterior family nu(p (.) T1) at every boundary p (edges, vertices): decisions agree exactly
(3) interior: they differ; NUMERICS: Monte-Carlo measure and location of the difference set as p -> e1
(4) algebra of the pinned-line certificate of Prop. Y3.6, for sample a."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from y3common import *

def majority(h):
    """majority orientation and odd world of a mixed gamble h (or its negative)"""
    neg = [j for j in range(3) if h[j] < 0]
    if len(neg) == 1: return h, neg[0]
    hh = tuple(-x for x in h); return hh, [j for j in range(3) if hh[j] < 0][0]

def FD_position(w, h, lam):
    """position (0=M,1=S,2=O) of the w-Bayes advice of F^D on the pair with majority orientation h, odd world o"""
    h, o = majority(h)
    wh = dot(w, h)
    if wh + lam * w[o] * h[o] > 0: return 0
    if wh + lam * sum(w[j] * h[j] for j in range(3) if j != o) < 0: return 2
    return 1

def K_position(K, h):
    h, o = majority(h)
    if P(K, h) > 0: return 0
    if P(K, tuple(-x for x in h)) > 0: return 2
    return 1

rng = random.Random(11)
for eps in [Fr(1, 10), Fr(3, 10), Fr(1, 2)]:
    eps_, c0, lam, A = params(eps)
    V = T1_vertices(eps)
    cube = [(Fr(1), A)] * 3
    m1 = m2 = m3 = 0; n1 = n2 = n3 = 0; d3 = 0
    for _ in range(8000):
        h = tuple(rand_rat(rng) for _ in range(3))
        if len({sgn(x) for x in h}) < 2 or 0 in h: continue
        w = rand_simplex(rng)
        Kc = family_vertices(w, cube)
        try:
            pc = K_position(Kc, h); pd = FD_position(w, h, lam)
            n1 += 1; m1 += (pc != pd)
        except Exception: pass
        # boundary weight: zero out one coordinate (edge) or two (vertex)
        z = rng.randrange(3); wb = list(w); wb[z] = Fr(0)
        if rng.random() < .1: wb[(z + 1) % 3] = Fr(0)
        s = sum(wb)
        if s == 0: continue
        wb = tuple(x / s for x in wb)
        Kc = family_vertices(wb, cube); Kp = [had(wb, v) for v in V]
        n2 += 1; m2 += (K_position(Kc, h) != K_position(Kp, h))
        # interior: count differences cube vs posterior
        Kc = family_vertices(w, cube); Kp = [had(w, v) for v in V]
        if min(w) > 0:
            n3 += 1; d3 += (K_position(Kc, h) != K_position(Kp, h))
    print(f"eps={eps}: (1) cube vs F^D, {n1} pairs: {m1} mismatches;  (2) cube vs posterior on boundary p, "
          f"{n2} pairs: {m2} mismatches;  interior differences: {d3}/{n3}")

# (3) NUMERICS: where cube and posterior differ as p -> e1 (Gaussian sample, float)
import numpy as np
rs = np.random.default_rng(3)
X = rs.standard_normal((400000, 3))
eps = 0.3; c0 = (1 - eps) / 3; A = (c0 + eps) / c0
V = np.array([[c0 + (eps if j == k else 0) for j in range(3)] for k in range(3)])
cubev = np.array([[a, b, c] for a in (1, A) for b in (1, A) for c in (1, A)])
print("\n(3) NUMERICS eps=0.3: Gaussian mass of {cube model != posterior model} at p=(1-2r,r,r), and median |h1|/|h|"
      " on the difference set")
for r in [0.2, 0.05, 0.01, 0.002]:
    p = np.array([1 - 2 * r, r, r])
    Pc = np.min((cubev * p) @ X.T, axis=0); Pcm = np.min((cubev * p) @ (-X).T, axis=0)
    Pp = np.min((V * p) @ X.T, axis=0); Ppm = np.min((V * p) @ (-X).T, axis=0)
    posc = np.where(Pc > 0, 0, np.where(Pcm > 0, 2, 1)); posp = np.where(Pp > 0, 0, np.where(Ppm > 0, 2, 1))
    D = posc != posp
    ratio = np.abs(X[D, 0]) / np.linalg.norm(X[D], axis=1) if D.any() else np.array([np.nan])
    print(f"   r={r}: mass {D.mean():.5f}   median |h1|/|h| on it {np.median(ratio):.5f}   max {ratio.max():.5f}")

# (4) pinned-line algebra of Prop Y3.6
print("\n(4) Prop. Y3.6 algebra (exact):")
for eps in [Fr(1, 10), Fr(3, 10)]:
    eps_, c0, lam, A = params(eps)
    V = T1_vertices(eps)
    # (-,+,-) family g = (-a, 1, -c): T1 boundary at c = (1-a)/A
    for a in [Fr(1, 100), Fr(1, 1000)]:
        cT = (1 - a) / A
        assert P(V, (-a, Fr(1), -cT)) == 0
        assert P(V, (-a, Fr(1), -(cT - Fr(1, 10**6)))) > 0 > P(V, (-a, Fr(1), -(cT + Fr(1, 10**6))))
    # forced w* from the two coefficient equations: -A a w1 + w2 - (1-a) w3 = 0 for all a  =>  w* ~ (1, A, A)
    w = (Fr(1), A, A)
    ok = all(-A * a * w[0] + w[1] - (1 - a) * w[2] == 0 for a in [Fr(1, 7), Fr(2, 9), Fr(0)])
    # (+,+,-) family g = (a, 1, -c), cube corner (1,1,A): zero of w*.(a,1,-A c) at c = (a+A)/A^2; T1 at (1+a)/A
    a = Fr(1, 100); c_cube = (a + A) / A**2; cT = (1 + a) / A
    assert P(V, (a, Fr(1), -cT)) == 0
    cm = (c_cube + cT) / 2
    s_T1 = sgn(P(V, (a, Fr(1), -cm))); s_fld = sgn(dot(w, (a, Fr(1), -A * cm)))
    print(f"   eps={eps}: w*=(1,A,A) solves the (-,+,-) pinning: {ok};  (+,+,-) at a=1/100: field zero c={c_cube}, "
          f"T1 zero c={cT}; at c={cm}: T1 sign {s_T1}, field sign {s_fld}  -> mismatch {s_T1 != s_fld}")
