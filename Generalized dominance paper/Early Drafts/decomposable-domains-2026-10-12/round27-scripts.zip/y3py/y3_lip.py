"""NUMERICS for Lemma Y3.4 (reservation radii) and the thin-competitor discussion.
Empirical Gaussian measure (fixed sample, so the empirical system is exactly additive).
L_i(Sigma_q) = - sum over sample gambles g with q.n(g) > 0 of n_i(g) / n_sample,  n(g) = m(g) (.) g (field Psi^(1)).
Checks: |L_i(Sigma_q) - L_i(Sigma_p)| <= Lip |q-p| with Lip = 16 sqrt(6/pi) A^2 on N (pairs of random points,
edges included); margins and radii of thin competitors X_theta (Sigma_p corrected for world 1 on a wedge of angular
width theta at the plane h1 = 0)."""
import numpy as np
rs = np.random.default_rng(1)
G = rs.standard_normal((600000, 3))
for eps in [0.1, 0.3, 0.5]:
    c0 = (1 - eps) / 3; lam = eps / c0; A = 1 + lam
    eta = 1 / (2 * (A + 1)); etap = eta / 2
    Mx = np.maximum(np.abs(G[:, 1]), np.abs(G[:, 2]))
    inGam = np.abs(G[:, 0]) <= eta * Mx
    corner = np.ones_like(G); corner[:, 1:] = np.where(G[:, 1:] > 0, 1.0, A)
    V = np.array([[c0 + (eps if j == k else 0) for j in range(3)] for k in range(3)])
    k = np.argmin(G @ V.T, axis=1)
    mT = np.ones_like(G); mT[np.arange(len(G)), k] = A
    m = np.where(inGam[:, None], corner, mT)
    n = m * G
    def L(q):
        acc = (n @ q) > 0
        return -(n * acc[:, None]).sum(axis=0) / len(G)
    def randN():
        s = etap / A * rs.random(); a = rs.random() if rs.random() > .3 else rs.choice([0.0, 1.0])
        w = np.array([1.0, s * a, s * (1 - a)]); return w / w.sum()
    Lip = 16 * np.sqrt(6 / np.pi) * A**2
    worst = 0.0
    for _ in range(300):
        p, q = randN(), randN()
        d = np.linalg.norm(p - q)
        if d < 1e-9: continue
        worst = max(worst, np.max(np.abs(L(p) - L(q))) / d)
    print(f"eps={eps}: Lip bound {Lip:.2f}; worst empirical |dL|/|dq| over 300 pairs in N: {worst:.3f}")
    # thin competitors near the plane h1 = 0 at an interior p of N
    p = np.array([1.0, 0.3 * etap / A, 0.5 * etap / A]); p /= p.sum()
    accp = (n @ p) > 0
    ang = np.abs(G[:, 0]) / np.linalg.norm(G, axis=1)
    for theta in [1e-1, 1e-2, 1e-3]:
        W = ang < theta
        # X_theta: Sigma_p, but on W the world-1-correct advice (accept g iff g1 > 0); elsewhere Sigma_p
        accX = np.where(W, G[:, 0] > 0, accp)
        LX1 = -(n[:, 0] * accX).sum() / len(G)       # world-1 loss uses the field's world-1 penalties
        margin = L(p)[0] - LX1
        print(f"   theta={theta:g}: world-1 margin L1(Sigma_p)-L1(X_theta) = {margin:.3e}; reserved radius "
              f"{max(margin,0)/Lip:.3e}; sample pairs in wedge {W.sum()}")
