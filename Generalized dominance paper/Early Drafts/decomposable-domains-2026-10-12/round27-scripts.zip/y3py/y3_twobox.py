"""CHECK (exact) for Proposition Y3.7(b): box-vertex plans at e1 (box B1) and at e2 (box B2) cannot share one
additive field.  For g = (x, -y, 1) the e1-plan pins the field's acceptance vector to (1,A,1)(.)g and the e2-plan
pins it to (1,1,1)(.)g; both lines cross the interiors of the respective vertex neighbourhoods."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from y3common import *
for eps in [Fr(1, 10), Fr(3, 10), Fr(1, 2)]:
    eps_, c0, lam, A = params(eps)
    eta = 1 / (2 * (A + 1)); etap = eta / 2
    def inN(p, i):   # N_i = {A (sum of other coords) <= eta' p_i}
        return A * (sum(p) - p[i]) <= etap * p[i]
    y = etap / (4 * A); x = etap * y / 4
    g = (x, -y, Fr(1))
    n1 = had((Fr(1), A, Fr(1)), g)          # B1 corner for the sign pattern (+,-,+)
    n2 = had((Fr(1), Fr(1), Fr(1)), g)      # B2 corner (coordinate 2 fixed at 1)
    # points of N1 on both sides of n1-line, points of N2 on both sides of n2-line
    def nz(p):
        s = sum(p); return tuple(t / s for t in p)
    s = etap / (2 * A)
    P1a = nz((Fr(1), s, Fr(0))); P1b = nz((Fr(1), Fr(0), Fr(0)))     # e1-side and the e1e2-edge point
    P2a = nz((Fr(0), Fr(1), Fr(0))); P2b = nz((Fr(0), Fr(1), s))
    print(f"eps={eps}: g=({x},{-y},1) in Gamma_eta at e1: {abs(g[0]) <= eta*max(abs(g[1]),abs(g[2]))}, at e2: "
          f"{abs(g[1]) <= eta*max(abs(g[0]),abs(g[2]))}")
    print(f"   e1-line signs on N1 points: {sgn(dot(P1a,n1))}, {sgn(dot(P1b,n1))} (in N1: {inN(P1a,0)}, {inN(P1b,0)})")
    print(f"   e2-line signs on N2 points: {sgn(dot(P2a,n2))}, {sgn(dot(P2b,n2))} (in N2: {inN(P2a,1)}, {inN(P2b,1)})")
    # the two lines are distinct: n1, n2 not proportional
    cross = (n1[1]*n2[2]-n1[2]*n2[1], n1[2]*n2[0]-n1[0]*n2[2], n1[0]*n2[1]-n1[1]*n2[0])
    print(f"   n1 x n2 = {tuple(str(t) for t in cross)}  (nonzero => distinct lines)")
    # and the e1-line evaluated at the N2 points / e2-line at N1 points: a single line cannot do both
    print(f"   e1-line on N2 points: {sgn(dot(P2a,n1))}, {sgn(dot(P2b,n1))};  e2-line on N1 points: {sgn(dot(P1a,n2))}, {sgn(dot(P1b,n2))}")
