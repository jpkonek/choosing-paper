"""Common exact-arithmetic helpers for note Y3 (vertex reservation plans at e1).
Worlds are indexed 0,1,2 in code (= 1,2,3 in the note); the vertex is e1 = index 0."""
from fractions import Fraction as Fr
import random

def params(eps):
    eps = Fr(eps)
    c0 = (1 - eps) / 3
    lam = eps / c0
    A = 1 + lam
    return eps, c0, lam, A

def dot(a, b): return sum(x * y for x, y in zip(a, b))
def had(a, b): return tuple(x * y for x, y in zip(a, b))
def sgn(x): return (x > 0) - (x < 0)

def T1_vertices(eps):
    eps, c0, lam, A = params(eps)
    return [tuple(c0 + (eps if j == k else 0) for j in range(3)) for k in range(3)]

def P(K, g):
    """lower prevision of gamble g on the polytope with vertex list K"""
    return min(dot(k, g) for k in K)

def box_corner(B, g):
    """corner of the box B = [(lo,hi)]*3 minimising m.z for z with the sign pattern of g"""
    return tuple(B[j][0] if g[j] > 0 else B[j][1] for j in range(3))

def box_vertices(B):
    out = []
    for a in B[0]:
        for b in B[1]:
            for c in B[2]:
                out.append((a, b, c))
    return out

def family_vertices(w, B):
    """vertices (unnormalised; normalisation is irrelevant for signs) of nu(w (.) B)"""
    return [had(w, m) for m in box_vertices(B)]

def rand_rat(rng, lo=-1, hi=1, den=997):
    return Fr(rng.randint(int(lo * den), int(hi * den)), den)

def rand_simplex(rng, den=1000):
    p = [Fr(rng.randint(0, den)) for _ in range(3)]
    s = sum(p)
    if s == 0: return (Fr(1), Fr(0), Fr(0))
    return tuple(x / s for x in p)
