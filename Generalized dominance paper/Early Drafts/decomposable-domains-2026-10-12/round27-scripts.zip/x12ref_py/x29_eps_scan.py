"""Referee check (exact rational arithmetic) of the geometry of Theorem X2.9 for MANY eps, with the box
half-width and the piece E1 chosen depending on eps.  Also shows that a fixed box (1% or 3%) and the fixed
E1 around (-1,3,3) fail for some eps.

World k = 0; Q_0: h_0 < 0 < h_1, h_2.  Posterior selection; T1 vertices v_m = c0*1 + eps*e_m.
Pieces: P = box around (-1,1,1) with half-width eta (relative), cones over boxes.
  P_t = (t,1,1)(.)P must be at O for T1;
  Pi2 = g(.)P_t2 and g^{-1}(.)P_t1 must be at S for T1, g = (1, 1/t1, t2);
  E1 = box around (-1,R,R) must be at M for T1.
A linear form has constant strict sign on a box iff it has it at the 8 vertices.
Run: python3 -I x29_eps_scan.py
"""
from fractions import Fraction as Fr
import itertools


def verts(eps):
    c0 = (1 - eps) / 3
    return [tuple(c0 + (eps if i == k else 0) for i in range(3)) for k in range(3)]


def pos_box(K, c, w):
    P, N = [], []
    for m in K:
        vals = [sum(m[i] * (c[i] + s[i] * w[i]) for i in range(3)) for s in itertools.product((-1, 1), repeat=3)]
        P.append(all(v > 0 for v in vals)); N.append(all(v < 0 for v in vals))
    if all(P): return 'M'
    if all(N): return 'O'
    if any(P) and any(N): return 'S'
    return '?'


def check(eps, eta, R, t1, t2):
    K = verts(eps)
    Pc = (Fr(-1), Fr(1), Fr(1)); Pw = (eta, eta, eta)
    out = {}
    for name, t in (("P_t1", t1), ("P_t2", t2)):
        d = (t, 1, 1)
        out[name] = pos_box(K, tuple(d[i] * Pc[i] for i in range(3)), tuple(d[i] * Pw[i] for i in range(3)))
    g = (Fr(1), 1 / t1, t2); gi = (Fr(1), t1, 1 / t2)
    d2 = tuple(g[i] * (t2 if i == 0 else 1) for i in range(3))
    d1 = tuple(gi[i] * (t1 if i == 0 else 1) for i in range(3))
    out["Pi2"] = pos_box(K, tuple(d2[i] * Pc[i] for i in range(3)), tuple(d2[i] * Pw[i] for i in range(3)))
    out["ginvPi1"] = pos_box(K, tuple(d1[i] * Pc[i] for i in range(3)), tuple(d1[i] * Pw[i] for i in range(3)))
    out["E1"] = pos_box(K, (Fr(-1), R, R), (eta, eta * R, eta * R))
    ok = out["P_t1"] == 'O' and out["P_t2"] == 'O' and out["Pi2"] == 'S' and out["ginvPi1"] == 'S' and out["E1"] == 'M'
    return ok, out


EPSS = [Fr(1, 10 ** 4), Fr(1, 1000), Fr(1, 100), Fr(1, 10), Fr(3, 10), Fr(1, 2), Fr(5, 8), Fr(7, 10), Fr(9, 10),
        Fr(99, 100), Fr(999, 1000)]
print("== eps-dependent choices: eta = (A-1)/(8A) (so (1+eta)/(1-eta) < A, (1-eta)/(1+eta) > beta),"
      " R = 2 + eps/c0, t0 = 4 + 4 eps/c0 + 1/eta")
allok = True
for eps in EPSS:
    c0 = (1 - eps) / 3
    A = 1 + eps / c0; beta = c0 / (c0 + eps)
    eta = (A - 1) / (8 * A)
    assert (1 + eta) / (1 - eta) < A and (1 - eta) / (1 + eta) > beta
    R = 2 + eps / c0
    t0 = int(4 + 4 * eps / c0 + 1 / eta) + 1
    for (a, b) in ((1, 1), (3, 1), (1, 7), (50, 50)):
        ok, out = check(eps, eta, R, Fr(a * t0), Fr(b * t0))
        allok &= ok
        if not ok:
            print("  FAIL", eps, a, b, out)
    print("  eps=%-10s eta=%-.3g R=%-.4g t0=%d : %s" % (eps, float(eta), float(R), t0, "OK" if ok else "FAIL"))
print("all eps-dependent cases OK:", allok)

print("== fixed choices from the note/script: eta = 1/100 or 3/100, E1 around (-1,3,3), t1=t2=10^4")
for eps in EPSS:
    for eta in (Fr(1, 100), Fr(3, 100)):
        ok, out = check(eps, eta, Fr(3), Fr(10 ** 4), Fr(10 ** 4))
        if not ok:
            bad = {k: v for k, v in out.items() if (k.startswith("P_") and v != 'O') or (k in ("Pi2", "ginvPi1") and v != 'S') or (k == "E1" and v != 'M')}
            print("  eps=%s eta=%s FAILS at %s" % (eps, eta, bad))
