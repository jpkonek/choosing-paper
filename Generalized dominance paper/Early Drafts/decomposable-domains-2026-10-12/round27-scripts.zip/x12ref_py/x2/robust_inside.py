"""NUMERICS for Lemma X2.3 (robust-inside lemma):
a coherent D_K that is never silent on the mixed gambles of D_T1 has K inside T1 or K a singleton.
(a) random K inside T1: D_K is never silent on mixed D_T1 gambles (expect 0 silent hits);
(b) random non-singleton K not inside T1: D_K is silent on a positive fraction of mixed D_T1 gambles."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from geom import V, P_K, advice, sphere, mixed, in_T1

rng = np.random.default_rng(1)
g = sphere(400000, rng)
g = g[mixed(g)]
g = g[P_K(V, g) > 0]          # mixed gambles of D_T1
print("mixed D_T1 sample size:", len(g))

def rand_simplex_pts(k):
    x = rng.exponential(size=(k, 3))
    return x / x.sum(axis=1, keepdims=True)

# (a)
bad_a = 0
for trial in range(300):
    lam = rand_simplex_pts(rng.integers(1, 5))
    K = lam @ V                   # points of T1
    a = advice(K, g)
    bad_a += np.sum(a == 0)
print("(a) K inside T1: total silent hits on mixed D_T1 =", bad_a)

# (b)
minfrac = 1.0
cnt = 0
for trial in range(300):
    K = rand_simplex_pts(rng.integers(2, 5))
    if all(in_T1(m) for m in K):
        continue
    if np.max(np.abs(K - K[0])) < 1e-3:
        continue
    cnt += 1
    a = advice(K, g)
    frac = np.mean(a == 0)
    minfrac = min(minfrac, frac)
print("(b) %d non-singleton K not inside T1: min fraction silent on mixed D_T1 = %.4g" % (cnt, minfrac))
