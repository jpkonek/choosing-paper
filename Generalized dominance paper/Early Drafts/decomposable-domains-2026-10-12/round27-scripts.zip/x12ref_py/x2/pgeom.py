"""X2 shared geometry (round 26): the posterior (multiplicative-tilt) selection on the full two-sided domain.

T1 = conv{v_k}, v_k = c0*1 + eps*e_k.  Posterior family  K_p = { nu(p (.) m) : m in T1 } = conv{ nu(p (.) v_k) }.
Positions on a mixed pair, indexed by its MAJORITY orientation h (h_o < 0 < h_j, h_l; o = odd world):
   0 = M (accept h),  1 = S (silence),  2 = O (accept -h).
World i rank of position x on a pair with odd world o:  x if i != o,  2 - x if i == o.
Exact arithmetic: fractions.Fraction throughout (no floating point in any clause).
"""
from fractions import Fraction as Fr
import itertools

EPS = Fr(3, 10)
C0 = (1 - EPS) / 3


def vert(k, eps=EPS):
    c0 = (1 - eps) / 3
    return tuple(c0 + (eps if i == k else 0) for i in range(3))


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def had(p, m):
    return tuple(x * y for x, y in zip(p, m))


def odd_world(h):
    neg = [i for i in range(3) if h[i] < 0]
    pos = [i for i in range(3) if h[i] > 0]
    assert len(neg) == 1 and len(pos) == 2, h
    return neg[0]


def position(K_pts, h):
    """position of D_K (K = conv K_pts, unnormalised positive multiples allowed) at majority orientation h."""
    vals = [dot(m, h) for m in K_pts]
    if min(vals) > 0:
        return 0
    if max(vals) < 0:
        return 2
    if min(vals) < 0 < max(vals):
        return 1
    raise ValueError("boundary tie: piece centre on a switching plane")


def posterior_pts(p, eps=EPS):
    return [had(p, vert(k, eps)) for k in range(3)]


def contamination_pts(p, r):
    """K = (1-r) p + r Delta, as unnormalised points."""
    return [tuple((1 - r) * p[i] + (r if i == k else 0) for i in range(3)) for k in range(3)]


def rank(i, o, x):
    return x if i != o else 2 - x


def robust_position(K_pts, h, rad=Fr(1, 200)):
    """position of D_K at h, certified constant on the cone over the box h + [-rad,rad]^3: each linear form
    m_k . x has constant strict sign on the box iff it has that sign at the 8 box vertices."""
    signs = []
    for m in K_pts:
        vals = [dot(m, tuple(h[i] + s[i] * rad for i in range(3))) for s in itertools.product((-1, 1), repeat=3)]
        if all(v > 0 for v in vals):
            signs.append(1)
        elif all(v < 0 for v in vals):
            signs.append(-1)
        else:
            return None
    if min(signs) > 0:
        return 0
    if max(signs) < 0:
        return 2
    return 1
