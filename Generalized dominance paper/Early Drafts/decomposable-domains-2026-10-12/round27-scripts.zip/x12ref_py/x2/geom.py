"""Shared geometry for X2 numerics (T1 = eps-contamination of uniform, n = 3)."""
import numpy as np

EPS = 0.3
C0 = (1 - EPS) / 3
V = np.array([C0 * np.ones(3) + EPS * np.eye(3)[k] for k in range(3)])  # v_1, v_2, v_3 (rows)


def P_K(verts, g):
    """lower prevision min_{m in K} m.g for K = conv(verts); g has shape (N,3)."""
    return np.min(g @ np.asarray(verts).T, axis=1)


def advice(verts, g):
    """advice of D_K on representative g: +1 accept g, -1 accept -g, 0 silence."""
    lo = P_K(verts, g)
    hi = -P_K(verts, -g)
    return np.where(lo > 0, 1, np.where(hi < 0, -1, 0))


def sphere(n, rng):
    x = rng.normal(size=(n, 3))
    return x / np.linalg.norm(x, axis=1, keepdims=True)


def mixed(g):
    return (g.max(axis=1) > 0) & (g.min(axis=1) < 0)


def in_T1(m, tol=1e-12):
    """m (shape (3,)) in T1 = conv(v_k) iff barycentric coords w.r.t. V are >= 0."""
    lam = np.linalg.solve(V.T, m)
    return np.all(lam >= -tol)
