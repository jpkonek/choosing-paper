"""CHECK (exact rational arithmetic) of the geometric input of Theorem X2.9 (no equivariant cover), eps = 3/10.

World k = 0 (index), region Q_0: majority orientation h = (-1, e^x, e^y) up to scale, i.e. h_0 < 0 < h_1, h_2.
Group action: d (.) h, d in R^3_{>0}.  Posterior selection: position of C_p at h = position of T1 at p (.) h.
Pieces are small boxes (cones over them); constancy of position on a box is certified by pgeom.robust_position.

Verified, for several (t1, t2) up to 10^6:
  (a) P_t := d_t (.) P lies in O_0(T1) (T1 accepts -h: k-correct), d_t = (t, 1, 1);
  (b) with the translation g = (1, a, b) chosen below, g (.) P_{t2} lies in S_0(T1) and g^{-1} (.) P_{t1} lies in S_0(T1);
  (c) the vertex model B^0 = {h_0 > 0} is at O on every piece used (so X_P = B^0 + S(P) is strictly better than B^0 at
      worlds 1, 2 on P).
(b) is the 2-cycle condition: Pi_1 = g1 P_{t1}, Pi_2 = g2 P_{t2} with g1^{-1} g2 = g."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pgeom import *

T1 = [vert(k) for k in range(3)]

def box_image(d, centre, rad):
    return tuple(d[i] * centre[i] for i in range(3)), rad

def pos_box(K, centre, halfw):
    """position of D_K certified constant on the box centre +- halfw: M if every form m.h is > 0 on the box, O if
    every form is < 0 on the box, S if some form is < 0 on the whole box and some form is > 0 on the whole box
    (a linear form has constant sign on a box iff it has that sign at the 8 vertices); None otherwise."""
    pos_all, neg_all = [], []
    for m in K:
        vals = [dot(m, tuple(centre[i] + s[i] * halfw[i] for i in range(3))) for s in itertools.product((-1, 1), repeat=3)]
        pos_all.append(all(v > 0 for v in vals)); neg_all.append(all(v < 0 for v in vals))
    if all(pos_all): return 0
    if all(neg_all): return 2
    if any(pos_all) and any(neg_all): return 1
    return None

A = 1 + EPS / C0          # M-threshold: e^y > A  (x -> -inf strip)
B = C0 / (C0 + EPS)       # O-threshold: e^y < B
print("strip for x -> -inf: B < e^y < A with B = %s, A = %s, B*A = %s" % (B, A, B * A))
P_c = (Fr(-1), Fr(1), Fr(1))           # piece centre (majority orientation in Q_0)
P_w = (Fr(1, 100), Fr(1, 100), Fr(1, 100))
ym = (A + B) / 2                       # middle of the strip, as a value of e^y
ok_all = True
for t1, t2 in [(10, 10), (100, 37), (1000, 10 ** 4), (10 ** 6, 20)]:
    t1 = Fr(t1); t2 = Fr(t2)
    # (a): P_t = (t,1,1)(.)P
    a1 = pos_box(T1, (t1 * P_c[0], P_c[1], P_c[2]), (t1 * P_w[0], P_w[1], P_w[2]))
    a2 = pos_box(T1, (t2 * P_c[0], P_c[1], P_c[2]), (t2 * P_w[0], P_w[1], P_w[2]))
    # (b): g = (1, a, b) acting on P_{t2}: centre (-t2, a, b), want x -> -inf (a small vs t2) and e^y = b/t2 = ym
    a = 1 / t1                          # g = (1, 1/t1, t2) as in X2_notes Thm X2.9 (strip centre e^y = 1, beta*A = 1)
    b = t2
    g = (Fr(1), a, b)
    c2 = tuple(g[i] * (t2 if i == 0 else 1) * P_c[i] for i in range(3))
    w2 = tuple(g[i] * (t2 if i == 0 else 1) * P_w[i] for i in range(3))
    b2 = pos_box(T1, c2, w2)
    ginv = (Fr(1), 1 / a, 1 / b)
    c1 = tuple(ginv[i] * (t1 if i == 0 else 1) * P_c[i] for i in range(3))
    w1 = tuple(ginv[i] * (t1 if i == 0 else 1) * P_w[i] for i in range(3))
    b1 = pos_box(T1, c1, w1)
    # (c): B^0 at O on all pieces (h_0 < 0 on the boxes)
    c_ok = all(c[0] + w[0] < 0 for c, w in [((t1 * P_c[0],) + P_c[1:], (t1 * P_w[0],) + P_w[1:]), (c1, w1), (c2, w2)])
    # E1: cone piece around (-1, 3, 3), must lie in M_0(T1) and be disjoint from the other pieces
    e1 = pos_box(T1, (Fr(-1), Fr(3), Fr(3)), P_w)
    c_ok = c_ok and e1 == 0
    names = {None: '?', 0: 'M', 1: 'S', 2: 'O'}
    ok = (a1 == 2 and a2 == 2 and b1 == 1 and b2 == 1 and c_ok)
    ok_all &= ok
    print("t1=%s t2=%s : T1 on P_t1 %s, on P_t2 %s | T1 on g(.)P_t2 %s, on g^-1(.)P_t1 %s | B^0 at O and E1 in M_0(T1): %s -> %s"
          % (t1, t2, names[a1], names[a2], names[b2], names[b1], c_ok, "OK" if ok else "FAIL"))
print("all cases verified:", ok_all)
