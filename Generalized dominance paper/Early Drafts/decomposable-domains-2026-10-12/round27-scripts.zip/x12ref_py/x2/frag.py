"""X2 exact finite-fragment test (NUMERICS tooling; a returned UNSAT core is a proof, see X2_notes.md section 6).

Pieces: N small cones of pairs, piece n in region Q_{o_n} (odd world o_n), on which every selected model used has a
constant position (certified by pgeom.robust_position).  Patterns: x in {0,1,2}^N (0=M,1=S,2=O).  A record x->y
is encoded per piece by code 0 (identity) or 1..6 (ordered pair a!=b).  Variable acc[i][r]: "record r accepted at
world i".  Clauses (each one is a consequence of the axioms for the selection used; X2_notes section 6):
  (G+)  record weakly worse at i on every piece            -> acc[i][r]        (unit)
  (G-)  record weakly better at i everywhere, strictly once -> not acc[i][r]   (unit)
  (T)   acc[i][r1] & acc[i][r2] -> acc[i][r1 o r2]   (realizable composition; lazily generated, CEGAR)
  (K)   for selected pattern s with support S and x != s:  OR_{i in S} acc[i][s->x]
  (U)   for selected s and x != s:  not (acc[1][x->s] & acc[2][x->s] & acc[3][x->s])
        [undominatedness + (C): x = C_p modified on whole pieces is incoherent, so it may neither dominate nor tie]
"""
import itertools
import numpy as np
from pysat.solvers import Solver

PAIRS = [(a, b) for a in range(3) for b in range(3) if a != b]      # codes 1..6
CODE = {pr: n + 1 for n, pr in enumerate(PAIRS)}


def comp_table():
    """T[c1][c2] = composite code, or -1 if not composable (middle advice mismatch)."""
    T = -np.ones((7, 7), dtype=np.int64)
    for c1 in range(7):
        for c2 in range(7):
            if c1 == 0:
                T[c1, c2] = c2
            elif c2 == 0:
                T[c1, c2] = c1
            else:
                a, b = PAIRS[c1 - 1]
                b2, c = PAIRS[c2 - 1]
                if b == b2:
                    T[c1, c2] = 0 if a == c else CODE[(a, c)]
    return T


TAB = comp_table()


class Fragment:
    def __init__(self, regions, selected, solver='cadical153'):
        """regions: list of odd worlds o_n (0,1,2); selected: list of (pattern tuple, support tuple)."""
        self.o = list(regions)
        self.N = len(regions)
        self.sel = [(tuple(s), tuple(S)) for s, S in selected]
        self.R = 7 ** self.N
        self.base = 7 ** np.arange(self.N)
        codes = (np.arange(self.R)[:, None] // self.base[None, :]) % 7
        self.codes = codes
        # per world: guidance status of each record: +1 forced true, -1 forced false, 0 free
        self.status = np.zeros((3, self.R), dtype=np.int64)
        for i in range(3):
            d = np.zeros((self.R, self.N), dtype=np.int64)
            for n in range(self.N):
                for c in range(1, 7):
                    a, b = PAIRS[c - 1]
                    ra = a if i != self.o[n] else 2 - a
                    rb = b if i != self.o[n] else 2 - b
                    d[codes[:, n] == c, n] = rb - ra
            worse = (d >= 0).all(1)
            better = (d <= 0).all(1) & (d < 0).any(1)
            self.status[i][worse] = 1
            self.status[i][better] = -1
        self.solver = Solver(name=solver)
        self.nclauses = 0
        for i in range(3):
            for r in range(self.R):
                if self.status[i][r] == 1:
                    self.add([self.v(i, r)])
                elif self.status[i][r] == -1:
                    self.add([-self.v(i, r)])
        pats = list(itertools.product(range(3), repeat=self.N))
        self.pats = pats
        for s, S in self.sel:
            for x in pats:
                if x == s:
                    continue
                self.add([self.v(i, self.rec(s, x)) for i in S])            # (K)
                self.add([-self.v(i, self.rec(x, s)) for i in range(3)])     # (U)
        self.extra = []

    def v(self, i, r):
        return 1 + i * self.R + int(r)

    def rec(self, x, y):
        r = 0
        for n in range(self.N):
            if x[n] != y[n]:
                r += CODE[(x[n], y[n])] * int(self.base[n])
        return r

    def add(self, cl):
        self.solver.add_clause(cl)
        self.nclauses += 1

    def compose(self, r1, r2):
        c1 = self.codes[r1]
        c2 = self.codes[r2]
        cc = TAB[c1[:, None, :], c2[None, :, :]] if c1.ndim == 2 else None
        return cc

    def solve(self, assumptions=(), max_iter=500, verbose=False):
        for it in range(max_iter):
            ok = self.solver.solve(assumptions=list(assumptions))
            if not ok:
                return False, it
            model = self.solver.get_model()
            mset = np.array(model[: 3 * self.R]) > 0
            added = 0
            for i in range(3):
                acc = np.nonzero(mset[i * self.R:(i + 1) * self.R])[0]
                accset = np.zeros(self.R, dtype=bool)
                accset[acc] = True
                C = self.codes[acc]                          # (m, N)
                # chunked all-pairs composition
                for st in range(0, len(acc), 400):
                    A = C[st:st + 400]
                    T = TAB[A[:, None, :], C[None, :, :]]     # (a, m, N)
                    okc = (T >= 0).all(2)
                    rec = (np.where(T >= 0, T, 0) * self.base[None, None, :]).sum(2)
                    bad = okc & ~accset[rec]
                    ia, ib = np.nonzero(bad)
                    for a_, b_ in zip(ia[:200], ib[:200]):
                        r1 = int(acc[st + a_]); r2 = int(acc[b_]); r3 = int(rec[a_, b_])
                        self.add([-self.v(i, r1), -self.v(i, r2), self.v(i, r3)])
                        added += 1
                    if added > 3000:
                        break
            if verbose:
                print("  iter", it, "added", added, flush=True)
            if added == 0:
                return True, model
        return None, None

    def accepted(self, model, i):
        mset = np.array(model[: 3 * self.R]) > 0
        return np.nonzero(mset[i * self.R:(i + 1) * self.R])[0]

    def decode(self, r):
        out = []
        for n in range(self.N):
            c = self.codes[r][n]
            out.append('.' if c == 0 else 'MSO'[PAIRS[c - 1][0]] + 'MSO'[PAIRS[c - 1][1]])
        return ' '.join(out)
