"""CHECK of Lemma X2.1 (ladder bijection on R_ij) and of the block-swap realisability used in Thm X2.4.
On a pair g in R_ij oriented so that + is i-correct (g_i>0>g_j), world ranks are
  r_i(+,0,-) = (0,1,2), r_j(+,0,-) = (2,1,0); ladder profile lam_k(a) = (1[r>=1], 1[r>=2]).
tau maps i-step 1 <-> j-step 2 and i-step 2 <-> j-step 1. Claim: lam_j(a)[tau s] = 1 - lam_i(a)[s]."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import itertools
ri = {'+': 0, '0': 1, '-': 2}
rj = {'+': 2, '0': 1, '-': 0}
lam = lambda r: (int(r >= 1), int(r >= 2))
tau = {0: 1, 1: 0}          # index 0 = step 1, index 1 = step 2
ok = True
for a in '+0-':
    li, lj = lam(ri[a]), lam(rj[a])
    for s in (0, 1):
        ok &= (lj[tau[s]] == 1 - li[s])
print("tau identity holds for all three advices:", ok)
# nested profiles <-> advices; removing / adding whole blocks keeps nestedness
nested = {(0, 0): '+', (1, 0): '0', (1, 1): '-'}
okb = True
for X, C in itertools.product(nested, nested):
    # at a pair, profiles of two models are comparable (nested chains) -> difference is one block
    up = tuple(max(x, c) for x, c in zip(X, C))
    dn = tuple(min(x, c) for x, c in zip(X, C))
    okb &= (up in nested) and (dn in nested) and (up in (X, C)) and (dn in (X, C))
print("profiles at a pair are totally ordered; block swaps stay realisable:", okb)
# non-nested blind type {2}: list what C can add/remove relative to X = '+' (empty profile)
print("relative to X='+' at a wrong-blind pair (Lambda={2}): C='0' adds {1}; C='-' adds {1,2}; step 1 always added")
