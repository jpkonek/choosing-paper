"""NUMERICS: random exact fragments for the posterior selection (7 interior priors), N pieces."""
import sys, os, random, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pgeom import *
from frag import Fragment
from scan import perm, priors

def candidates(ps):
    out = []
    grid = [Fr(x, 20) for x in range(1, 60)]
    for o in range(3):
        for a in grid:
            for b in grid:
                h = perm((a, b, Fr(-1)), o)
                pos = [robust_position(posterior_pts(p), h) for p in ps]
                if None in pos or len(set(pos)) == 1:
                    continue
                out.append((o, h, tuple(pos)))
    return out

if __name__ == "__main__":
    N = int(sys.argv[1]); trials = int(sys.argv[2]); seed = int(sys.argv[3])
    ps = priors()
    C = candidates(ps)
    # deduplicate by (region, pattern)
    seen = {}
    for o, h, pos in C:
        seen.setdefault((o, pos), (o, h, pos))
    C = list(seen.values())
    print("distinct (region,pattern) candidates:", len(C), flush=True)
    rng = random.Random(seed)
    for t in range(trials):
        pick = rng.sample(C, N)
        regions = [o for o, h, pos in pick]
        sel = [(tuple(pos[k] for o, h, pos in pick), (0, 1, 2)) for k in range(len(ps))]
        t0 = time.time()
        F = Fragment(regions, sel)
        res, info = F.solve(max_iter=300)
        print(t, "regions", regions, "patterns", [''.join('MSO'[x] for x in pos) for o, h, pos in pick],
              "->", {True: "SAT", False: "UNSAT", None: "undecided"}[res], "%.1fs" % (time.time() - t0), flush=True)
