"""NUMERICS for the field-level analysis of the wrong-blind template (X2 section 4).
Ladder field: total density r_k = |g_k| (Brier-like) at every world; split
  - on pairs where T1 accepts the k-wrong orientation: s_k = |g_k|, w_k = 0   (wrong step blind);
  - on pairs where T1 is silent: s_k = th(g)|g_k|, w_k = (1-th(g))|g_k|, th = 0.5*min(P,N)/(P+N);
  - on pairs where T1 is k-correct: s_k = w_k = |g_k|/2.
Checks: (1) the strict Bayes model at u is T1 (a.e.);
        (2) at every q in a grid, the Bayes model is never silent on mixed D_T1 gambles (Lemma X2.6(a));
        (3) midpoint-convexity of the acceptance cone of the Bayes model B_q (coherence test).
Expected from Lemma X2.3: a coherent B_q must have K inside T1 or K a singleton."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from geom import V, P_K, advice, sphere, mixed

rng = np.random.default_rng(7)
G = sphere(300000, rng)
G = G[mixed(G)]
T = advice(V, G)                       # T1 advice on representative g: +1/0/-1

def field(G, T):
    a = np.abs(G)
    s = np.zeros_like(a); w = np.zeros_like(a)
    P = np.clip(G, 0, None).sum(1); N = np.clip(-G, 0, None).sum(1)
    th = 0.5 * np.minimum(P, N) / (P + N)
    sil = (T == 0)
    s[sil] = th[sil, None] * a[sil]; w[sil] = (1 - th[sil, None]) * a[sil]
    for k in range(3):
        # T1 accepts orientation T*g; it is k-wrong iff sign(T*g_k) < 0
        acc = (T != 0)
        kwrong = acc & (T * G[:, k] < 0)
        kright = acc & (T * G[:, k] > 0)
        s[kwrong, k] = a[kwrong, k]; w[kwrong, k] = 0.0
        s[kright, k] = a[kright, k] / 2; w[kright, k] = a[kright, k] / 2
    return s, w

S, W = field(G, T)

def bayes(q, G, S, W):
    # cost of advice +1 (accept g), 0, -1 (accept -g) at weight q
    cost = {}
    for adv in (1, 0, -1):
        c = np.zeros(len(G))
        for k in range(3):
            if adv == 0:
                ck = S[:, k]
            else:
                correct = (adv * G[:, k] > 0)
                ck = np.where(correct, 0.0, S[:, k] + W[:, k])
            c += q[k] * ck
        cost[adv] = c
    M = np.stack([cost[1], cost[0], cost[-1]], 1)
    return np.array([1, 0, -1])[np.argmin(M, 1)], np.sort(M, 1)

u = np.ones(3) / 3
Bu, Mu = bayes(u, G, S, W)
gap = Mu[:, 1] - Mu[:, 0]
print("(1) B_u != T1 on fraction %.2e of mixed pairs (min Bayes gap %.2e)" % (np.mean(Bu != T), gap.min()))

def convex_violations(B, n=60000):
    acc = np.concatenate([G[B == 1], -G[B == -1]])        # accepted gambles (both orientations)
    if len(acc) < 2: return 0.0
    i = rng.integers(0, len(acc), n); j = rng.integers(0, len(acc), n)
    mid = acc[i] + acc[j]; mid /= np.linalg.norm(mid, axis=1, keepdims=True)
    # evaluate B at mid: nearest sample direction is too crude; recompute advice of the field at mid directly
    Tm = advice(V, mid)
    Sm, Wm = field(mid, Tm)
    Bm, _ = bayes(qcur, mid, Sm, Wm)
    ok = mixed(mid)
    return np.mean((Bm[ok] != 1))           # midpoint of two accepted gambles not accepted

grid = []
for a in np.linspace(0.02, 0.96, 12):
    for b in np.linspace(0.02, 0.96, 12):
        if a + b < 0.98:
            grid.append(np.array([a, b, 1 - a - b]))
worst = []
for qcur in grid:
    B, M = bayes(qcur, G, S, W)
    dT = P_K(V, G) > 0
    silent_on_DT = np.mean(B[dT] == 0)
    viol = convex_violations(B)
    worst.append((viol, silent_on_DT, qcur))
worst.sort(key=lambda t: -t[0])
print("(2) max over grid of fraction silent on mixed D_T1: %.2e" % max(t[1] for t in worst))
print("(3) grid points with midpoint-convexity violations > 1e-3: %d of %d" % (sum(t[0] > 1e-3 for t in worst), len(worst)))
for v, sdt, q in worst[:6]:
    print("    q = (%.3f, %.3f, %.3f): violation fraction %.4f" % (q[0], q[1], q[2], v))
qn = [t for t in worst if t[0] <= 1e-3]
print("    coherent-looking grid points (violation <= 1e-3):", len(qn))
for v, sdt, q in sorted(qn, key=lambda t: np.linalg.norm(t[2] - u))[:6]:
    print("      q = (%.3f, %.3f, %.3f), |q-u| = %.3f" % (q[0], q[1], q[2], np.linalg.norm(q - u)))
