"""List candidate pieces and their positions under the posterior selection at a set of priors."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pgeom import *

def perm(h, o):
    """majority orientation with odd world o built from (a, b, -1) template: positions (j, l, o)."""
    j, l = [i for i in range(3) if i != o]
    out = [None] * 3
    out[j], out[l], out[o] = h
    return tuple(out)

def priors(delta=Fr(1, 10)):
    u = (Fr(1, 3),) * 3
    ps = [u]
    for i in range(3):
        for j in range(3):
            if i != j:
                p = list(u); p[i] += delta; p[j] -= delta
                ps.append(tuple(p))
    return ps

if __name__ == "__main__":
    ps = priors()
    cands = []
    grid = [Fr(x, 20) for x in range(1, 60)]
    for o in range(3):
        for a in grid:
            for b in grid:
                if b < a: continue
                h = perm((a, b, Fr(-1)), o)
                pos = [robust_position(posterior_pts(p), h) for p in ps]
                if None in pos: continue
                if len(set(pos)) > 1:
                    cands.append((o, (float(a), float(b)), ''.join('MSO'[x] for x in pos)))
    from collections import Counter
    print("priors:", [tuple(float(x) for x in p) for p in ps])
    c = Counter((o, s) for o, ab, s in cands)
    for (o, s), n in sorted(c.items()):
        ex = [ab for oo, ab, ss in cands if oo == o and ss == s][:3]
        print("region", o, "pattern over priors", s, "count", n, "e.g.", ex)
