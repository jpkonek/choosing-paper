"""CHECK (exact) of Proposition X2.6: for the posterior selection K_p = nu(p (.) T1), on a mixed pair with majority
orientation h and odd world o,
   C_p at M  iff  p.h + lam p_o h_o > 0,       C_p at O  iff  p.h + lam max_{j != o} p_j h_j < 0,     lam = eps/c0,
i.e. C_p is the pointwise p-Bayes advice of the strictly guiding additive field F^a with the caution cost of the
odd-favourable acceptance attributed to a(h) = argmax_{j != o} p_j h_j.  Also checks the equivariance identity
pos(C_p, h) = pos(T1, p (.) h)."""
import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pgeom import *

rng = random.Random(5)
lam = EPS / C0
T1 = [vert(k) for k in range(3)]
bad = 0; n = 0; ties = 0
for _ in range(20000):
    o = rng.randrange(3)
    h = [Fr(rng.randint(1, 400), rng.randint(1, 60)) for _ in range(3)]
    h[o] = -h[o]
    h = tuple(h)
    p = [Fr(rng.randint(1, 100)) for _ in range(3)]
    s = sum(p); p = tuple(x / s for x in p)
    try:
        pos = position(posterior_pts(p), h)
        pos2 = position(T1, had(p, h))
    except ValueError:
        ties += 1; continue
    ph = dot(p, h)
    mcond = ph + lam * p[o] * h[o] > 0
    ocond = ph + lam * max(p[j] * h[j] for j in range(3) if j != o) < 0
    pred = 0 if mcond else (2 if ocond else 1)
    n += 1
    bad += (pred != pos) + (pos2 != pos)
print("pairs checked:", n, " boundary ties skipped:", ties, " mismatches:", bad)
