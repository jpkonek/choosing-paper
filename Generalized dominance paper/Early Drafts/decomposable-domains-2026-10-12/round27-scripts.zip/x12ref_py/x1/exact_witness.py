"""X1: EXACT (rational) verification that each minimal model of the full-domain crossing fragment is contained in
a common-density Brier ranking (X1_notes.md Prop. X1.5.2).

With Lebesgue-normalised densities m_k on the balls pi_k (and 1 elsewhere), the world-j Brier value of a whole-
piece record r is  sum_k drank_j(r)_k * m_k * A_jk  with A_jj = 1, A_jk = a (k != j), exactly (a linear function
averages to its centre value on a ball inside an orthant).  For each minimal model we find a float LP solution
maximising the minimum slack over accepted non-tie records, rationalise it, and verify every accepted record
EXACTLY (ties must be exact zeros: we check whether minimal models contain world ties at all).
Run: python3 -I exact_witness.py
"""
import sys
from fractions import Fraction as F
sys.path.insert(0, ".")
from fullfrag import horn, kcnf, inv_var, minimal_models, W, bg, drank, inv
import numpy as np
from scipy.optimize import linprog


def coeffs(j, r, a):
    d = drank(j, r)
    return [d[k] * (1 if j == k else a) for k in range(3)]


def run(a):
    cl = horn() + kcnf(lambda s: W)
    mins = minimal_models(cl)
    nties = 0
    ok_all = True
    for m in mins:
        acc = [inv_var[v] for v in m]
        accset = set(acc)
        ties = [(j, r) for (j, r) in acc if (j, inv(r)) in accset and not bg(j, r) and r != inv(r)]
        nties += bool(ties)
        nontriv = [(j, r) for (j, r) in acc if not bg(j, r)]
        # maximise t subject to coeff.m >= t (non-tie), m_k in [1, 100]
        rows, b = [], []
        for (j, r) in nontriv:
            c = [float(x) for x in coeffs(j, r, float(a))]
            rows.append([-x for x in c] + [1.0]); b.append(0.0)
        res = linprog([0, 0, 0, -1], A_ub=np.array(rows), b_ub=np.array(b),
                      bounds=[(1, 100)] * 3 + [(None, 10)], method="highs")
        if res.status != 0 or res.x[3] <= 1e-9:
            ok_all = False
            print("   no strictly positive margin for a minimal model; t =", None if res.status else res.x[3])
            continue
        mq = [F(x).limit_denominator(10 ** 6) for x in res.x[:3]]
        for (j, r) in acc:
            val = sum(cq * mk for cq, mk in zip(coeffs(j, r, a), mq))
            if val < 0:
                ok_all = False
                print("   exact check failed", j, r, val)
                break
    print(f"a={a}: minimal models {len(mins)}; with a world tie {nties}; all exactly witnessed with positive margin: {ok_all}")


if __name__ == "__main__":
    for a in (F(1, 20), F(1, 5), F(3, 10), F(9, 20)):
        run(a)
