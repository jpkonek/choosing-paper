"""X1 exact finite checks on the three-piece crossing fragment (X1_notes.md §4.4, U-domain variant).

Records sigma in {-1,0,1}^3 on the pieces pi_0, pi_1, pi_2 (sigma_k = +1: the first model accepts pi_k and the
second does not).  World-j sign of piece k: +1 iff j == k.  Selected patterns s in {+,-}^3 minus (-,-,-).
A record is OUT OF pattern s if sigma_k = +1 only where s_k = + and sigma_k = -1 only where s_k = -.

Horn rules (natural extension, finitary part):  (P) background;  (Sigma) composition (ternary sums);
(R4) protection: if -sigma is accepted at every world, sigma is accepted at every world (sigma out of a pattern).
Forbidden: (N) strict reversal;  (Csel) a two-way tie at every world for sigma out of a pattern
(every such X is incoherent: it differs from a selected cone by whole balls).

Checks
 1. the dead triple rho_j@j (rho_j = -1 on pieces j, j+1): closure WITH (R4) is unclean (protection fires on
    tau^{-1}); closure WITHOUT (R4) is clean.
 2. exhaustive search over states L of k <= KMAX non-background world-labelled records with clean closure:
    is there a state and a pending (K)-clause (pattern s, sigma out of s, support S) such that no world of S
    can be added with a clean closure?  Done for S = Plus(s) (smallest support) and for S = Omega (interior).
 3. the same with (K)-consistency: does "clean closure" imply that the state extends to a model of the WHOLE
    fragment (all (K) clauses)?  (SAT check.)
Run: python3 -I horn_states.py
"""
import itertools
from pysat.solvers import Minisat22

W = (0, 1, 2)
RECS = list(itertools.product((-1, 0, 1), repeat=3))
ZERO = (0, 0, 0)
PATS = [s for s in itertools.product((1, -1), repeat=3) if s != (-1, -1, -1)]


def sgn(j, k):
    return 1 if j == k else -1


def st(j, sig):
    return tuple(sig[k] * sgn(j, k) for k in range(3))


def bg(j, sig):
    return all(x >= 0 for x in st(j, sig))


def forb(j, sig):
    return sig != ZERO and all(x <= 0 for x in st(j, sig))


def neg(sig):
    return tuple(-x for x in sig)


def add(a, b):
    c = tuple(x + y for x, y in zip(a, b))
    return c if all(abs(x) <= 1 for x in c) else None


def out_of(s):
    opts = [((0, 1) if s[k] == 1 else (0, -1)) for k in range(3)]
    return [o for o in itertools.product(*opts)]


OUT = sorted({sig for s in PATS for sig in out_of(s) if sig != ZERO})   # records out of some pattern


def closure(L, use_R4=True):
    A = {j: {sig for sig in RECS if bg(j, sig)} for j in W}
    for (j, sig) in L:
        A[j].add(sig)
    changed = True
    while changed:
        changed = False
        for j in W:
            new = set()
            for a_ in A[j]:
                for b_ in A[j]:
                    c = add(a_, b_)
                    if c is not None and c not in A[j]:
                        new.add(c)
            if new:
                A[j] |= new
                changed = True
        if use_R4:
            for sig in OUT:
                if all(neg(sig) in A[j] for j in W):
                    for j in W:
                        if sig not in A[j]:
                            A[j].add(sig)
                            changed = True
    return A


def clean(A):
    for j in W:
        for sig in A[j]:
            if forb(j, sig):
                return False, ("N", j, sig)
    for sig in OUT:
        if all(sig in A[j] and neg(sig) in A[j] for j in W):
            return False, ("Csel", sig)
    return True, None


def plus(s):
    return tuple(k for k in range(3) if s[k] == 1)


KCL = [(s, sig) for s in PATS for sig in out_of(s) if sig != ZERO]


def unmeetable(A, L, S_of):
    bad = []
    for (s, sig) in KCL:
        S = S_of(s)
        if any(sig in A[j] for j in S):
            continue
        if not any(clean(closure(L + [(j, sig)]))[0] for j in S):
            bad.append((s, sig, S))
    return bad


# SAT encoding of the whole fragment (as in crossing_fragment.py) for check 3
var = {(j, sig): 1 + 27 * j + RECS.index(sig) for j in W for sig in RECS}


def fragment_clauses(S_of):
    cl = []
    for j in W:
        for sig in RECS:
            if bg(j, sig):
                cl.append([var[(j, sig)]])
            if forb(j, sig):
                cl.append([-var[(j, sig)]])
        for a_ in RECS:
            for b_ in RECS:
                c = add(a_, b_)
                if c is not None:
                    cl.append([-var[(j, a_)], -var[(j, b_)], var[(j, c)]])
    for (s, sig) in KCL:
        cl.append([var[(j, sig)] for j in S_of(s)])
    for sig in OUT:
        for i in W:
            cl.append([-var[(j, neg(sig))] for j in W] + [var[(i, sig)]])
        cl.append([-var[(j, sig)] for j in W] + [-var[(j, neg(sig))] for j in W])
    return cl


if __name__ == "__main__":
    rho = [tuple(-1 if k in (j, (j + 1) % 3) else 0 for k in range(3)) for j in W]
    L = [(j, rho[j]) for j in W]
    print("1. dead triple", L)
    print("   closure with R4 clean?   ", clean(closure(L, True)))
    print("   closure without R4 clean?", clean(closure(L, False)))
    A0 = closure(L, False)
    print("   without R4: tau^{-1}=(-1,-1,-1) accepted at all worlds:", all((-1, -1, -1) in A0[j] for j in W))

    MIXED = [(j, sig) for j in W for sig in RECS if not bg(j, sig) and not forb(j, sig)]
    print("mixed world-labelled records:", len(MIXED))
    for name, S_of in (("Plus(s)", plus), ("Omega", lambda s: W)):
        clauses = fragment_clauses(S_of)
        for KMAX in (1, 2, 3):
            nclean = nbad = nnotK = 0
            first_bad = first_notK = None
            for k in range(KMAX, KMAX + 1):
                for L in itertools.combinations(MIXED, k):
                    L = list(L)
                    A = closure(L)
                    if not clean(A)[0]:
                        continue
                    nclean += 1
                    b = unmeetable(A, L, S_of)
                    if b:
                        nbad += 1
                        if first_bad is None:
                            first_bad = (L, b[:3])
                    with Minisat22(bootstrap_with=clauses) as Sv:
                        if not Sv.solve(assumptions=[var[x] for x in L]):
                            nnotK += 1
                            if first_notK is None:
                                first_notK = L
            print(f"2/3. S={name}, |L|={KMAX}: clean states {nclean}; with an unmeetable (K) clause {nbad}; "
                  f"clean but not K-consistent {nnotK}")
            if first_bad:
                print("      first state with unmeetable clause:", first_bad)
            if first_notK:
                print("      first clean, non-K-consistent state:", first_notK)
