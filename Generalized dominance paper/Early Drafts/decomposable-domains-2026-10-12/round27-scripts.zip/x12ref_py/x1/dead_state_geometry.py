"""X1 NUMERICS: geometry of the dead crossing state (X1_notes.md §5.1, U-domain variant of Theorem X1.5.1).

No proof depends on this file; it checks the elementary inequalities used in the proof on samples.

Setting: n = 3, T1 = (1-eps)u + eps*Delta, K' = u + s(T1 - u), U = D_{K'} (U-domain M_U),
Brier selection B_q = U ∩ {q.h > 0}.  Pieces pi_k = closed balls of radius rad around
h^(k) = e_k - a(1 - e_k)  (so h^(1) = (1,-a,-a), ...), with a < (1 - s*eps)/(2 + s*eps).

Checked:
 (1) every piece lies in U (P_{K'} > 0 on the ball);
 (2) u.h > 0 on every piece, so B_u contains all pieces (tau = 1_{pi_1 u pi_2 u pi_3} is a record out of B_u);
 (3) q_j.h < 0 on pi_j and pi_{j+1} for the chosen interior q_j (rho_j = -1 there is a record out of B_{q_j});
 (4) sign pattern: on pi_k, h_j > 0 iff j = k;
 (5) Comp(tau) = {q : q.h > 0 on all pieces} lies in int Delta (q_k > a/(1+a) - O(rad));
 (6) no q in Delta has q.h <= 0 on all three pieces (sum of centres = (1-2a)(1,1,1)).
 (7) for every two of the three generators there is a piecewise-constant density rho (common to all worlds)
     whose Brier ranking accepts both (so each pair lies in a successful system), while the three
     together force a^3 >= 1 (impossible).
Run: python3 -I dead_state_geometry.py
"""
import numpy as np

rng = np.random.default_rng(1)
E = np.eye(3)
u = np.ones(3) / 3


def setup(eps, s):
    T1v = np.array([(1 - eps) * u + eps * E[k] for k in range(3)])
    Kpv = np.array([u + s * (v - u) for v in T1v])
    return T1v, Kpv


def lower(Kv, h):
    return np.min(h @ Kv.T, axis=-1)


def ball(c, rad, N=40000):
    d = rng.normal(size=(N, 3))
    d /= np.linalg.norm(d, axis=1)[:, None]
    r = rad * rng.uniform(0, 1, size=(N, 1)) ** (1 / 3)
    return c + r * d


def run(eps, s, a, rad):
    T1v, Kpv = setup(eps, s)
    H = [E[k] - a * (1 - E[k]) for k in range(3)]
    th = a / (1 + a)
    qs = []
    for j in range(3):  # q_j: small weight on worlds j, j+1, large on j+2
        q = np.zeros(3)
        q[j] = q[(j + 1) % 3] = th / 3
        q[(j + 2) % 3] = 1 - 2 * th / 3
        qs.append(q)
    out = []
    pts = [ball(H[k], rad) for k in range(3)]
    ok1 = all((lower(Kpv, P) > 0).all() for P in pts)
    ok2 = all((P @ u > 0).all() for P in pts)
    ok3 = all(((pts[j] @ qs[j] < 0).all() and (pts[(j + 1) % 3] @ qs[j] < 0).all()) for j in range(3))
    ok4 = all(((np.sign(pts[k][:, j]) == (1 if j == k else -1)).all()) for k in range(3) for j in range(3))
    # (5) Comp(tau): sample the simplex
    Q = rng.dirichlet(np.ones(3), size=200000)
    inComp = np.ones(len(Q), bool)
    for k in range(3):
        # q.h > 0 on the whole ball  <=>  q.h^(k) > rad*|q|
        inComp &= (Q @ H[k] > rad * np.linalg.norm(Q, axis=1))
    minq = Q[inComp].min() if inComp.any() else np.nan
    # (6) any q with q.h <= 0 on all balls would have q.h^(k) <= 0 for all k
    allneg = np.ones(len(Q), bool)
    for k in range(3):
        allneg &= (Q @ H[k] <= 0)
    out.append(dict(eps=eps, s=s, a=a, rad=rad, inU=ok1, inBu=ok2, qj_excl=ok3, signs=ok4,
                    Comp_min_coord=round(float(minq), 4), any_q_excluding_all=bool(allneg.any())))
    # (7) pairwise witnesses.  Brier world-j weight of piece k ~ m_k * mean_{ball}|h_j|.
    absmean = np.array([[np.abs(pts[k][:, j]).mean() for k in range(3)] for j in range(3)])  # [j][k]
    def acc(j, m):  # rho_j at world j: C_{q_j} <=_j Y_j  iff  w_j(pi_{j+1}) >= w_j(pi_j)
        return m[(j + 1) % 3] * absmean[j][(j + 1) % 3] >= m[j] * absmean[j][j]
    pair_ok = {}
    for (j1, j2) in [(0, 1), (1, 2), (2, 0)]:
        # masses: m_{j1} small, m_{j1+1} medium, m_{j1+2} = 1 (the chain j1 -> j2 = j1+1 is acyclic)
        m = np.zeros(3)
        m[(j1 + 2) % 3] = 1.0
        m[(j1 + 1) % 3] = a / 2
        m[j1] = a * a / 4
        pair_ok[(j1 + 1, j2 + 1)] = bool(acc(j1, m) and acc(j2, m))
    out[-1]["pairs_witnessed"] = pair_ok
    # all three: product of the three ratio constraints gives prod(absmean ratios) >= 1
    prod = np.prod([absmean[j][(j + 1) % 3] / absmean[j][j] for j in range(3)])
    out[-1]["cyclic_product_(needs>=1)"] = round(float(prod), 5)
    return out


if __name__ == "__main__":
    for (eps, s, a, rad) in [(0.3, 0.9, 0.2, 0.02), (0.1, 0.5, 0.3, 0.02), (0.9, 0.9, 0.05, 0.005),
                             (0.5, 0.99, 0.15, 0.01)]:
        lim = (1 - s * eps) / (2 + s * eps)
        print(f"eps={eps} s={s} a={a} (need a < {lim:.4f}) rad={rad}")
        for r in run(eps, s, a, rad):
            for k, v in r.items():
                print(f"   {k}: {v}")
