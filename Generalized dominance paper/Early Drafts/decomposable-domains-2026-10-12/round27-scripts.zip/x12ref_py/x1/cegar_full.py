"""X1: is EVERY model of the full-domain crossing fragment (Horn part + all (K) clauses, S = Omega) contained in a
common-density Brier ranking?  CEGAR: take a model, try an LP witness; if found, block every model contained in
the witness's acceptance set; else report the non-witnessed model and minimise its non-background part
(keeping it a model) to show which acceptances are non-additive.
Run: python3 -I cegar_full.py
"""
import sys
sys.path.insert(0, ".")
from fullfrag import horn, kcnf, var, inv_var, W, RECS, bg, drank, common_witness, show
from pysat.solvers import Minisat22

A = 0.2


def accepted(m):
    acc = set()
    for j in W:
        for r in RECS:
            d = drank(j, r)
            if sum(d[k] * m[k] * (1.0 if j == k else A) for k in range(3)) >= -1e-9:
                acc.add((j, r))
    return acc


cl = horn() + kcnf(lambda s: W)
S = Minisat22(bootstrap_with=cl)
it = 0
res = None
while it < 3000:
    it += 1
    if not S.solve():
        res = "all models witnessed"
        break
    model = [inv_var[v] for v in S.get_model() if v > 0 and v in inv_var]
    w = common_witness(model, A)
    if w is None:
        res = model
        break
    acc = accepted(w)
    S.add_clause([var[x] for x in var if x not in acc])
print("CEGAR iterations:", it)
if isinstance(res, str) or res is None:
    print(res)
else:
    print("non-witnessed model found; non-background acceptances per world:",
          {j: len(v) for j, v in show(res).items()})
    # minimise: drop non-background literals while the set stays a model and stays non-witnessed
    cur = set(res)
    allv = sorted(inv_var)
    with Minisat22(bootstrap_with=cl) as T:
        changed = True
        while changed:
            changed = False
            for x in sorted(cur, key=str):
                if bg(*x):
                    continue
                trial = cur - {x}
                lits = [var[y] for y in trial] + [-var[y] for y in var if y not in trial]
                if T.solve(assumptions=lits) and common_witness(sorted(trial, key=str), A) is None:
                    cur = trial
                    changed = True
    print("locally minimal non-witnessed model, non-background acceptances:")
    for j, v in show(cur).items():
        print(f"   world {j}: {len(v)} records")
