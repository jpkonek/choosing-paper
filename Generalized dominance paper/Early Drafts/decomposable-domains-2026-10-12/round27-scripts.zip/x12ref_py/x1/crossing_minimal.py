"""X1 exact finite check: enumerate ALL inclusion-minimal models of the three-piece crossing fragment Gamma
(see crossing_fragment.py) and test each for a common-density Brier witness and for world-wise witnesses.
Minimal models are exactly the least closures Cl(kappa) of K-resolutions kappa that are clean (P3 Thm 3.1
restricted to Gamma, which has no limit rule).  Run: python3 -I crossing_minimal.py
"""
import itertools, sys
sys.path.insert(0, ".")
from crossing_fragment import fragment, var, inv, model_set, witness_LP, st, W
from pysat.solvers import Minisat22

cl = fragment()
allv = sorted(inv)
mins = []
S = Minisat22(bootstrap_with=cl)
while S.solve():
    m = set(v for v in S.get_model() if v > 0 and v in inv)
    # shrink to a minimal model
    while True:
        falses = [-v for v in allv if v not in m]
        with Minisat22(bootstrap_with=cl) as T:
            T.add_clause([-v for v in m])          # some currently-true var becomes false
            if T.solve(assumptions=falses):
                m = set(v for v in T.get_model() if v > 0 and v in inv)
            else:
                break
    mins.append(frozenset(m))
    S.add_clause([-v for v in m])                  # block all supersets of this minimal model
S.delete()
print("number of minimal models:", len(mins))
sizes = sorted(len(m) for m in mins)
print("sizes (min, max):", sizes[0], sizes[-1])
for a in (0.05, 0.2, 0.3, 0.45):
    nw = [m for m in mins if witness_LP({inv[v] for v in m}, a) is None]
    nww = [m for m in mins if witness_LP({inv[v] for v in m}, a, worldwise=True) is None]
    print(f"a={a}: minimal models without common-density witness: {len(nw)};  without world-wise witness: {len(nww)}")
    if nw and a == 0.2:
        ex = sorted({inv[v] for v in nw[0]})
        nontriv = [(j, s) for (j, s) in ex if not all(x >= 0 for x in st(j, s))]
        print("   example (non-background accepted records):", nontriv)
