"""X1 NUMERICS / exact finite checks: the three-piece crossing fragment (X1_notes.md §4.4 (U-domain variant)).

The fragment Gamma consists of the clauses of the finitary theory Theta_C (X1_notes.md §3) that mention only whole-piece records
on the three pieces pi_0, pi_1, pi_2 of the dead-state configuration, with the Brier selection B_q on M_U.
(Every clause of Gamma is a clause of Theta, so a model of Theta restricts to a model of Gamma; Gamma is a FINITE
fragment.  Exact Boolean reasoning; LPs are rational-data LPs solved in floating point with margins reported.)

Encoding.  Worlds j = 0,1,2.  Records sigma in {-1,0,1}^3 (sigma_k = +1: the first model accepts pi_k and the
second does not; -1: the reverse).  World-j sign of piece k: +1 iff j == k.  j-signed record
st_j(k) = sigma_k * sgn_j(k).  Selected models restricted to the pieces: patterns s in {+,-}^3 \ {---}
(B_q contains pi_k iff q_k > a/(1+a)); the smallest support of a q with pattern s is Plus(s).

Clauses:  (P) st_j >= 0 => x[j,sigma];  (N) st_j <= 0, sigma != 0 => not x[j,sigma];
(Sigma) x[j,s1] & x[j,s2] => x[j,s1+s2] if ternary;  (K) for each pattern s and record sigma != 0 out of s:
OR_{j in Plus(s)} x[j,sigma];  (R4) AND_j x[j,-sigma] => x[i,sigma];  (Csel) not AND_j (x[j,sigma] & x[j,-sigma]).

Checks:
 A. Gamma is satisfiable.
 B. Gamma + {rho_j at world j : j = 0,1,2} (rho_j = -1 on pieces j, j+1) is UNSATISFIABLE (dead state),
    and every two of the three units are satisfiable with Gamma.
 C. Witness classification (CEGAR): is every model of Gamma contained in a common-density Brier ranking
    Psi^m (world-j weight of piece k = m_k * (1 if k == j else a))?  If not, print a non-witnessed model.
 D. Same with world-wise weights c_j(k) > 0 (each world separately additive).
Run: python3 -I crossing_fragment.py
"""
import itertools
import numpy as np
from scipy.optimize import linprog
from pysat.solvers import Minisat22

W = range(3)
RECS = list(itertools.product((-1, 0, 1), repeat=3))
ZERO = (0, 0, 0)
PATS = [s for s in itertools.product((1, -1), repeat=3) if s != (-1, -1, -1)]


def sgn(j, k):
    return 1 if j == k else -1


def st(j, sig):
    return tuple(sig[k] * sgn(j, k) for k in range(3))


var = {}
for j in W:
    for sig in RECS:
        var[(j, sig)] = len(var) + 1
inv = {v: k for k, v in var.items()}


def out_of(s):
    """records out of pattern s"""
    opts = [((0, 1) if s[k] == 1 else (0, -1)) for k in range(3)]
    return list(itertools.product(*opts))


def neg(sig):
    return tuple(-x for x in sig)


def add(a, b):
    c = tuple(x + y for x, y in zip(a, b))
    return c if all(abs(x) <= 1 for x in c) else None


def fragment():
    cl = []
    for j in W:
        cl.append([var[(j, ZERO)]])
        for sig in RECS:
            t = st(j, sig)
            if all(x >= 0 for x in t):
                cl.append([var[(j, sig)]])
            if all(x <= 0 for x in t) and sig != ZERO:
                cl.append([-var[(j, sig)]])
        for a_ in RECS:
            for b_ in RECS:
                c = add(a_, b_)
                if c is not None:
                    cl.append([-var[(j, a_)], -var[(j, b_)], var[(j, c)]])
    for s in PATS:
        plus = [k for k in range(3) if s[k] == 1]
        for sig in out_of(s):
            if sig == ZERO:
                continue
            cl.append([var[(j, sig)] for j in plus])                       # (K)
            for i in W:                                                     # (R4)
                cl.append([-var[(j, neg(sig))] for j in W] + [var[(i, sig)]])
            cl.append([-var[(j, sig)] for j in W] + [-var[(j, neg(sig))] for j in W])  # (Csel)
    return cl


def solve(cl, assumptions=()):
    with Minisat22(bootstrap_with=cl) as S:
        ok = S.solve(assumptions=list(assumptions))
        return ok, (S.get_model() if ok else None)


def model_set(m):
    return {inv[v] for v in m if v > 0 and v in inv}


def witness_LP(A, a, worldwise=False):
    """Find m (or c_j) >= 1 with sum_k st_j(k) w_j(k) >= 0 for all (j,sig) in A."""
    if not worldwise:
        nv = 3
        rows = []
        for (j, sig) in A:
            t = st(j, sig)
            rows.append([-(t[k] * (1.0 if k == j else a)) for k in range(3)])
    else:
        nv = 9
        rows = []
        for (j, sig) in A:
            t = st(j, sig)
            r = [0.0] * 9
            for k in range(3):
                r[3 * j + k] = -t[k]
            rows.append(r)
    res = linprog(np.zeros(nv), A_ub=np.array(rows) if rows else None, b_ub=np.zeros(len(rows)) if rows else None,
                  bounds=[(1, None)] * nv, method="highs")
    return res.x if res.status == 0 else None


def accepted_by(m, a, worldwise=False, tol=1e-9):
    acc = set()
    for j in W:
        for sig in RECS:
            t = st(j, sig)
            if not worldwise:
                val = sum(t[k] * m[k] * (1.0 if k == j else a) for k in range(3))
            else:
                val = sum(t[k] * m[3 * j + k] for k in range(3))
            if val >= -tol:
                acc.add((j, sig))
    return acc


def cegar(a, worldwise=False, maxit=5000):
    cl = fragment()
    blocks = 0
    for it in range(maxit):
        ok, m = solve(cl)
        if not ok:
            return ("all models witnessed", blocks)
        A = model_set(m)
        w = witness_LP(A, a, worldwise)
        if w is None:
            return ("NON-WITNESSED model found", sorted(A))
        acc = accepted_by(w, a, worldwise)
        # block every model contained in acc
        cl.append([var[x] for x in var if x not in acc])
        blocks += 1
    return ("undecided", blocks)


if __name__ == "__main__":
    cl = fragment()
    print("variables:", len(var), " clauses:", len(cl))
    ok, m = solve(cl)
    print("A. fragment satisfiable:", ok)
    rho = [tuple(-1 if k in (j, (j + 1) % 3) else 0 for k in range(3)) for j in W]
    units = [var[(j, rho[j])] for j in W]
    print("   rho_j =", rho)
    print("B. fragment + all three rho_j@j satisfiable:", solve(cl, units)[0])
    for pair in itertools.combinations(range(3), 2):
        print(f"   fragment + rho_j@j for j in {pair}: satisfiable:", solve(cl, [units[j] for j in pair])[0])
    tau = (1, 1, 1)
    for j in W:
        print(f"   tau@{j} together with rho_{j}@{j}: satisfiable:", solve(cl, [units[j], var[(j, tau)]])[0])
    for a in (0.05, 0.2, 0.3, 0.45):
        print(f"C. a={a}: common-density witnesses:", cegar(a))
        print(f"D. a={a}: world-wise witnesses:", cegar(a, worldwise=True))
