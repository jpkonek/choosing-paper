"""X1: the three-piece crossing fragment on the FULL advice domain with the precise (Brier) selection D_q
(X1_notes.md §4).  Exact Boolean reasoning; LPs only as a posteriori diagnostics.

Pieces pi_0, pi_1, pi_2 (small balls around h^(k) = e_k - a(1 - e_k)); world-j sign of piece k is +1 iff j == k.
Advice on a piece: '+' (accept the U-orientation), '0' (silence), '-' (accept its negative).  [The fourth kind,
contradiction, is omitted: this is a FRAGMENT; every clause used is an instance of a real rule, so derivations of
a forbidden outcome are sound in the real system.]
World-j rank on piece k: good 0 < silence 1 < bad 2, good = '+' iff j == k.
Selected models D_q: advice on pi_k is '+' iff q_k > theta = a/(1+a); patterns s in {+,-}^3 \\ {---};
smallest support of a q with pattern s is Plus(s) (all supersets also occur).

Records: per piece either identity (None) or an ordered pair (x, y), x != y.  Composition: middle advice must match
where both are nontrivial; opposite arrows give identity.
Horn part H: (P) background, (N) strict reversal forbidden, (Sigma) composition, (R4) protection,
(Csel) no two-way tie at every world for records out of a selected pattern (all such competitors are incoherent).
Disjunctive part K: for pattern s and record r out of s (first advice = s_k where nontrivial): OR_{j in S} x[j,r].

Run: python3 -I fullfrag.py
"""
import itertools, sys
import numpy as np
from pysat.solvers import Minisat22
from scipy.optimize import linprog

W = (0, 1, 2)
ADV = ('+', '0', '-')
PIECE = [None] + [(x, y) for x in ADV for y in ADV if x != y]
RECS = list(itertools.product(PIECE, repeat=3))
ID = (None, None, None)
PATS = [s for s in itertools.product('+-', repeat=3) if s != ('-', '-', '-')]


def rank(j, k, x):
    good = '+' if j == k else '-'
    return 0 if x == good else (1 if x == '0' else 2)


def drank(j, r):
    """rank changes (second minus first) per piece"""
    return tuple(0 if r[k] is None else rank(j, k, r[k][1]) - rank(j, k, r[k][0]) for k in range(3))


def bg(j, r):
    return all(d >= 0 for d in drank(j, r))


def forb(j, r):
    return r != ID and all(d <= 0 for d in drank(j, r))


def inv(r):
    return tuple(None if p is None else (p[1], p[0]) for p in r)


def comp(r, s):
    out = []
    for p, q in zip(r, s):
        if p is None:
            out.append(q)
        elif q is None:
            out.append(p)
        else:
            if p[1] != q[0]:
                return None
            out.append(None if p[0] == q[1] else (p[0], q[1]))
    return tuple(out)


def out_of(s):
    opts = [[None] + [(s[k], y) for y in ADV if y != s[k]] for k in range(3)]
    return [r for r in itertools.product(*opts) if r != ID]


OUT = sorted({r for s in PATS for r in out_of(s)}, key=str)
var = {}
for j in W:
    for r in RECS:
        var[(j, r)] = len(var) + 1
inv_var = {v: k for k, v in var.items()}


def plus(s):
    return tuple(k for k in range(3) if s[k] == '+')


def horn():
    cl = []
    for j in W:
        for r in RECS:
            if bg(j, r):
                cl.append([var[(j, r)]])
            if forb(j, r):
                cl.append([-var[(j, r)]])
        for r in RECS:
            for s in RECS:
                c = comp(r, s)
                if c is not None and r != ID and s != ID:
                    cl.append([-var[(j, r)], -var[(j, s)], var[(j, c)]])
    for r in OUT:
        for i in W:
            cl.append([-var[(j, inv(r))] for j in W] + [var[(i, r)]])
        cl.append([-var[(j, r)] for j in W] + [-var[(j, inv(r))] for j in W])
    return cl


def kclauses(S_of):
    return [(s, r, S_of(s)) for s in PATS for r in out_of(s)]


def kcnf(S_of):
    return [[var[(j, r)] for j in S] for (s, r, S) in kclauses(S_of)]


A_DEF = 0.2


def psi_row(j, r, a=A_DEF):
    """Brier loss at world j is (rank - 1)|h_j|; |h_j| on pi_k is 1 if j == k else a.  Common masses m_k."""
    d = drank(j, r)
    return [d[k] * (1.0 if j == k else a) for k in range(3)]


def common_witness(acc, a=A_DEF):
    rows = [[-x for x in psi_row(j, r, a)] for (j, r) in acc]
    res = linprog(np.zeros(3), A_ub=np.array(rows), b_ub=np.zeros(len(rows)), bounds=[(1, None)] * 3,
                  method="highs")
    return res.x if res.status == 0 else None


def minimal_models(cl, cap=100000):
    allv = sorted(inv_var)
    mins = []
    S = Minisat22(bootstrap_with=cl)
    while S.solve() and len(mins) < cap:
        m = set(v for v in S.get_model() if v > 0)
        while True:
            falses = [-v for v in allv if v not in m]
            with Minisat22(bootstrap_with=cl) as T:
                T.add_clause([-v for v in m])
                if T.solve(assumptions=falses):
                    m = set(v for v in T.get_model() if v > 0)
                else:
                    break
        mins.append(frozenset(m))
        S.add_clause([-v for v in m])
    S.delete()
    return mins


def show(acc):
    return {j: sorted([r for (jj, r) in acc if jj == j and not bg(j, r)], key=str) for j in W}


if __name__ == "__main__":
    H = horn()
    print("variables", len(var), "Horn clauses", len(H), "records out of patterns", len(OUT))
    # dead triple: rho_j = '0'->'+' on pieces j, j+1 at world j ; tau = '+'->'0' on all pieces, out of D_u
    rho = [tuple(('0', '+') if k in (j, (j + 1) % 3) else None for k in range(3)) for j in W]
    tau = (('+', '0'),) * 3
    units = [var[(j, rho[j])] for j in W]
    Hnr4 = [c for c in H if not (len(c) == 4 and c[-1] > 0 and all(x < 0 for x in c[:-1]))]
    for name, cl in (("H (with R4)", H), ("H without R4", Hnr4)):
        with Minisat22(bootstrap_with=cl) as S:
            ok = S.solve(assumptions=units)
            print(f"dead triple rho_j@j consistent with {name}: {ok}")
            if ok:
                print("   ... and tau meetable at some world:",
                      any(S.solve(assumptions=units + [var[(j, tau)]]) for j in W))
    for S_name, S_of in (("Plus(s)", plus), ("Omega", lambda s: W)):
        cl = H + kcnf(S_of)
        mins = minimal_models(cl)
        print(f"[S={S_name}] minimal models of the full-domain crossing fragment: {len(mins)}")
        for a in (0.05, 0.2, 0.3, 0.45):
            nw = sum(1 for m in mins if common_witness([inv_var[v] for v in m], a) is None)
            print(f"   a={a}: minimal models without a common-density Brier witness: {nw}")
        if S_name == "Omega":
            for m in mins[:3]:
                print("   example minimal model (non-background records):", show([inv_var[v] for v in m]))
