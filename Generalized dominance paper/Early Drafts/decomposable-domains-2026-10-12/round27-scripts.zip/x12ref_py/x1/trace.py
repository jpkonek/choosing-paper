"""X1: forward chaining WITH PROVENANCE on the full-domain crossing fragment (rules (P), (Sigma), (R4); forbidden
(N), (Csel)), to print human-checkable derivations.  Used to (1) list the closure of a state, (2) print the
derivation of the forbidden outcome produced by adding a record at a world.
Run: python3 -I trace.py   (prints the analysis of the stuck states chosen in X1_notes.md §5.4)
"""
import sys
sys.path.insert(0, ".")
from fullfrag import W, RECS, ID, bg, forb, comp, inv, OUT, drank


def fc(L, maxrounds=50):
    """forward chaining; returns (acc dict (j,r)->reason, conflict or None)"""
    why = {}
    for j in W:
        for r in RECS:
            if bg(j, r):
                why[(j, r)] = ("bg",)
    for x in L:
        if x not in why:
            why[x] = ("given",)
    for _ in range(maxrounds):
        new = {}
        for j in W:
            Aj = [r for r in RECS if (j, r) in why]
            Aset = set(Aj)
            for r in Aj:
                if r == ID:
                    continue
                for s in Aj:
                    if s == ID:
                        continue
                    c = comp(r, s)
                    if c is not None and c not in Aset and (j, c) not in new:
                        new[(j, c)] = ("comp", (j, r), (j, s))
        for r in OUT:
            if all((j, inv(r)) in why for j in W):
                for j in W:
                    if (j, r) not in why and (j, r) not in new:
                        new[(j, r)] = ("R4", r)
        if not new:
            break
        why.update(new)
        for (j, r) in new:
            if forb(j, r):
                return why, ("N", (j, r))
        for r in OUT:
            if all((j, r) in why and (j, inv(r)) in why for j in W):
                return why, ("Csel", r)
    for (j, r) in why:
        if forb(j, r):
            return why, ("N", (j, r))
    for r in OUT:
        if all((j, r) in why and (j, inv(r)) in why for j in W):
            return why, ("Csel", r)
    return why, None


def explain(why, x, depth=0, seen=None, out=None):
    if out is None:
        out = []
    if seen is None:
        seen = set()
    if x in seen:
        return out
    seen.add(x)
    w = why[x]
    if w[0] == "comp":
        explain(why, w[1], depth + 1, seen, out)
        explain(why, w[2], depth + 1, seen, out)
        out.append(f"world {x[0]}: {x[1]}  = {w[1][1]} o {w[2][1]}")
    elif w[0] == "R4":
        for j in W:
            explain(why, (j, inv(x[1])), depth + 1, seen, out)
        out.append(f"world {x[0]}: {x[1]}  by (R4) (reverse accepted at every world)")
    elif w[0] == "given":
        out.append(f"world {x[0]}: {x[1]}  GIVEN")
    return out


def fmt(r):
    return "[" + ", ".join("." if p is None else p[0] + ">" + p[1] for p in r) + "]"


if __name__ == "__main__":
    P = lambda a, b: (a, b)
    states = {
        "S4": [(0, (P('0', '+'), P('+', '0'), P('0', '+'))), (2, (P('0', '-'), P('-', '+'), P('0', '+'))),
               (2, (P('-', '+'), P('0', '-'), P('0', '+'))), (2, (P('0', '+'), P('+', '0'), None))],
    }
    clause = (P('+', '0'), None, P('+', '0'))
    for name, L in states.items():
        why, conf = fc(L)
        print(name, "closure clean:", conf is None)
        nb = {j: sorted([fmt(r) for r in RECS if (j, r) in why and not bg(j, r)]) for j in W}
        for j in W:
            print(f"  world {j} non-background closure ({len(nb[j])}):", nb[j])
        for j in W:
            why2, conf2 = fc(L + [(j, clause)])
            print(f"  + clause record {fmt(clause)} at world {j}: conflict {conf2}")
            if conf2:
                target = conf2[1] if conf2[0] == "N" else (0, conf2[1])
                for line in explain(why2, target):
                    print("      ", line.replace(str(clause), fmt(clause)))
