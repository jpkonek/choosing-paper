"""Print the six minimal models of the crossing fragment: non-background records accepted per world,
and the cone of common-density witnesses (sampled).  Run: python3 -I crossing_minimal_show.py"""
import sys, itertools
sys.path.insert(0, ".")
from crossing_fragment import fragment, var, inv, st, W, accepted_by
from pysat.solvers import Minisat22
import numpy as np

cl = fragment(); allv = sorted(inv); mins = []
S = Minisat22(bootstrap_with=cl)
while S.solve():
    m = set(v for v in S.get_model() if v > 0 and v in inv)
    while True:
        falses = [-v for v in allv if v not in m]
        with Minisat22(bootstrap_with=cl) as T:
            T.add_clause([-v for v in m])
            if T.solve(assumptions=falses):
                m = set(v for v in T.get_model() if v > 0 and v in inv)
            else:
                break
    mins.append({inv[v] for v in m}); S.add_clause([-v for v in m])
a = 0.2
rng = np.random.default_rng(0)
M = np.exp(rng.uniform(-6, 6, size=(200000, 3)))
for idx, A in enumerate(mins):
    print(f"--- minimal model {idx}:")
    for j in W:
        nb = sorted(s for (jj, s) in A if jj == j and not all(x >= 0 for x in st(j, s)))
        print(f"   world {j}: non-background accepted records: {nb}")
    # sampled witnesses: masses m with A subset of Psi^m ; report the induced order of pieces by mass
    orders = set()
    for m in M[:20000]:
        acc = accepted_by(m, a)
        if A <= acc:
            orders.add(tuple(np.argsort(-m)))
    print("   sampled witness masses exist:", bool(orders), " orders of m (largest first):", sorted(orders))
