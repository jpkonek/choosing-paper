"""X1: random MAXIMAL clean Horn states of the full-domain crossing fragment.
A clean Horn state that is K-inconsistent stays K-inconsistent when enlarged, so a counterexample to
'clean natural extension => K-consistency' exists iff some maximal clean Horn state violates a (K)-clause.
We build random maximal clean states (add random literals, any record at any world, while the Horn closure
stays clean) and test every (K)-clause; we also record whether the maximal states are complete at each world
(for every record r, r or r^{-1} accepted) and whether they admit a common-density Brier witness.
Run: python3 -I maximal_states.py
"""
import sys, random
sys.path.insert(0, ".")
from fullfrag import bg, forb, horn, kclauses, var, inv_var, W, plus, RECS, inv, common_witness
from pysat.solvers import Minisat22


def run(S_name, S_of, trials=400, seed=1):
    H0 = horn()
    H = [c for c in H0 if len(c) > 1]
    BASE = [var[(j, r)] for j in W for r in RECS if bg(j, r)] + [-var[(j, r)] for j in W for r in RECS if forb(j, r)]
    KC = kclauses(S_of)
    S = Minisat22(bootstrap_with=H)
    rng = random.Random(seed)
    allv = sorted(inv_var)
    viol = 0
    complete = 0
    witnessed = 0
    ex = None
    for t in range(trials):
        L = []
        order = allv[:]
        rng.shuffle(order)
        ok, imp = S.propagate(assumptions=BASE + L)
        imp = set(imp)
        for v in order:
            if v in imp:
                continue
            ok2, imp2 = S.propagate(assumptions=BASE + L + [v])
            if ok2:
                L.append(v)
                imp = set(imp2)
        acc = {inv_var[v] for v in imp if v > 0}
        bad = [(s, r) for (s, r, Sx) in KC if not any((j, r) in acc for j in Sx)]
        if bad:
            viol += 1
            ex = ex or (sorted(acc, key=str), bad[:3])
        if all(((j, r) in acc) or ((j, inv(r)) in acc) for j in W for r in RECS):
            complete += 1
        if common_witness(sorted(acc, key=str)) is not None:
            witnessed += 1
    print(f"[S={S_name}] maximal clean states sampled {trials}: violating some (K)-clause {viol}; "
          f"complete at every world {complete}; common-density witnessed (a=0.2) {witnessed}")
    if ex:
        print("   example violation:", ex[1])
    S.delete()


if __name__ == "__main__":
    run("Omega", lambda s: W)
    run("Plus(s)", plus)
