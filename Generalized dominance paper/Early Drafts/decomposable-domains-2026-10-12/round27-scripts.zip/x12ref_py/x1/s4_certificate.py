"""X1: the fragment-stuck state S4 (X1_notes.md §5.4) has NO certificate of the Phi' type
(world 1 pointwise background; worlds 0, 2 additive Brier-type with piece densities kappa_j(k) >= 1, common
density off the pieces, protection condition kappa_0(0) >= kappa_2(0), kappa_2(2) >= kappa_0(2)).  LP check for
several a, plus the hand inequality chain printed for reference.  Run: python3 -I s4_certificate.py
"""
import sys
sys.path.insert(0, ".")
from fullfrag import drank
import numpy as np
from scipy.optimize import linprog

P = lambda x, y: (x, y)
S4 = [(0, (P('0', '+'), P('+', '0'), P('0', '+'))), (2, (P('0', '-'), P('-', '+'), P('0', '+'))),
      (2, (P('-', '+'), P('0', '-'), P('0', '+'))), (2, (P('0', '+'), P('+', '0'), None))]
for a in (0.05, 0.2, 0.3, 0.45, 0.49):
    # variables kappa_0(0..2), kappa_2(0..2)
    rows, b = [], []
    for (j, r) in S4:
        d = drank(j, r)
        row = [0.0] * 6
        off = 0 if j == 0 else 3
        for k in range(3):
            row[off + k] = -d[k] * (1.0 if j == k else a)
        rows.append(row); b.append(0.0)
    rows.append([-1, 0, 0, 1, 0, 0]); b.append(0.0)   # kappa_0(0) >= kappa_2(0)
    rows.append([0, 0, 1, 0, 0, -1]); b.append(0.0)   # kappa_2(2) >= kappa_0(2)
    res = linprog(np.zeros(6), A_ub=np.array(rows), b_ub=np.array(b), bounds=[(1, None)] * 6, method="highs")
    print(f"a={a}: Phi'-certificate for S4 feasible: {res.status == 0}")
    for (j, r) in S4:
        print("    world", j, r, "rank changes", drank(j, r))
    break
for a in (0.05, 0.2, 0.3, 0.45, 0.49):
    rows, b = [], []
    for (j, r) in S4:
        d = drank(j, r); row = [0.0] * 6; off = 0 if j == 0 else 3
        for k in range(3):
            row[off + k] = -d[k] * (1.0 if j == k else a)
        rows.append(row); b.append(0.0)
    rows.append([-1, 0, 0, 1, 0, 0]); b.append(0.0)
    rows.append([0, 0, 1, 0, 0, -1]); b.append(0.0)
    res = linprog(np.zeros(6), A_ub=np.array(rows), b_ub=np.array(b), bounds=[(1, None)] * 6, method="highs")
    print(f"a={a}: feasible {res.status == 0}")
