"""X1: does a CLEAN natural extension (Horn part H: (P),(N),(Sigma),(R4),(Csel)) suffice for the next
competitiveness disjunction?  Full-domain three-piece crossing fragment of fullfrag.py.

 (A) exhaustive over states L of 1 or 2 K-resolution literals (j, r), r out of a selected pattern, j in S;
 (B) random greedy constructions: resolve randomly chosen (K)-clauses by a random world whose addition keeps
     the Horn closure clean (unit propagation is complete for Horn theories); stop if some clause has no such
     world (STUCK = counterexample to the invariant 'clean natural extension').
Records the first stuck state, re-verifies it, and checks whether it is K-consistent (it cannot be).
Run: python3 -I greedy_stuck.py
"""
import sys, random, itertools
sys.path.insert(0, ".")
from fullfrag import bg, forb, horn, kclauses, var, inv_var, W, plus, show, OUT, PATS, out_of, RECS
from pysat.solvers import Minisat22


def main(S_name, S_of, trials=3000, seed=0):
    H0 = horn()
    H = [c for c in H0 if len(c) > 1]
    BASE = [var[(j, r)] for j in W for r in RECS if bg(j, r)] + [-var[(j, r)] for j in W for r in RECS if forb(j, r)]
    KC = kclauses(S_of)
    S = Minisat22(bootstrap_with=H)
    K = Minisat22(bootstrap_with=H + [[var[(j, r)] for j in Sx] for (s, r, Sx) in KC])

    def prop(lits):
        ok, implied = S.propagate(assumptions=BASE + lits)
        return ok, set(implied)

    lits_all = sorted({var[(j, r)] for (s, r, Sx) in KC for j in Sx if not bg(j, r)})
    # (A) exhaustive small states
    nA = 0
    stuckA = None
    for size in (1, 2):
        for L in itertools.combinations(lits_all, size):
            ok, imp = prop(list(L))
            if not ok:
                continue
            nA += 1
            for (s, r, Sx) in KC:
                if any(var[(j, r)] in imp for j in Sx):
                    continue
                if all(not prop(list(L) + [var[(j, r)]])[0] for j in Sx):
                    stuckA = stuckA or (L, s, r)
                    break
    print(f"[S={S_name}] (A) clean states of size<=2: {nA}; first one-step failure: {stuckA}")
    # (B) random greedy runs
    rng = random.Random(seed)
    nstuck = 0
    first = None
    lengths = []
    for t in range(trials):
        L = []
        order = KC[:]
        rng.shuffle(order)
        stuck = False
        for (s, r, Sx) in order:
            ok, imp = prop(L)
            if any(var[(j, r)] in imp for j in Sx):
                continue
            ws = [j for j in Sx if prop(L + [var[(j, r)]])[0]]
            if not ws:
                stuck = True
                nstuck += 1
                if first is None:
                    first = (list(L), s, r, Sx)
                break
            L.append(var[(rng.choice(ws), r)])
        lengths.append(len(L))
    print(f"[S={S_name}] (B) greedy runs {trials}: stuck {nstuck}; mean number of choices {sum(lengths)/len(lengths):.1f}")
    if first:
        L, s, r, Sx = first
        print("   first stuck state: chosen literals", [inv_var[v] for v in L])
        print("   unmeetable clause: pattern", s, "record", r, "worlds", Sx)
        print("   state K-consistent?", K.solve(assumptions=BASE + L))
        # minimise the stuck state: drop literals while the clause stays unmeetable and the state stays clean
        Lm = list(L)
        changed = True
        while changed:
            changed = False
            for x in list(Lm):
                L2 = [y for y in Lm if y != x]
                ok, imp = prop(L2)
                if ok and not any(var[(j, r)] in imp for j in Sx) and \
                        all(not prop(L2 + [var[(j, r)]])[0] for j in Sx):
                    Lm = L2
                    changed = True
        print("   minimised stuck state:", [inv_var[v] for v in Lm])
        for j in Sx:
            print(f"     adding the clause record at world {j}: clean? {prop(Lm + [var[(j, r)]])[0]}")
    S.delete(); K.delete()


if __name__ == "__main__":
    main("Omega", lambda s: W)
    main("Plus(s)", plus)
