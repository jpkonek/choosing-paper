"""X1: search for a REAL counterexample to the invariant 'clean natural extension' (X1_notes.md §5.4).

Real clean structures used as certificates (Lemma X1.6.2 in the notes): world 1 = pointwise background order,
worlds 0 and 2 = additive Brier-type orders whose densities on the three pieces are kappa_j(k) (common density
1 off the pieces).  Such a structure Phi' is closed under (R1)-(R5) and clean iff every selected D_q is a strict
constrained minimiser; this holds iff  kappa_0(0) >= kappa_2(0)  and  kappa_2(2) >= kappa_0(2)  (pieces pi_0, pi_2;
kappa(1) is free).  Every fragment derivation is a real derivation, so a fragment 'stuck' certificate is real.

Procedure: sample kappa in the admissible region; L_kappa := the fragment records accepted by Phi' at worlds 0, 2;
for every (K)-clause unmet by L_kappa test, by unit propagation on the Horn fragment, whether adding the clause
record at EVERY world of S yields a forbidden outcome.  Then minimise L.
Run: python3 -I pareto_witness.py
"""
import sys, random
sys.path.insert(0, ".")
from fullfrag import bg, forb, horn, kclauses, var, inv_var, W, RECS, drank, OUT, plus
from pysat.solvers import Minisat22

A = 0.2
H = [c for c in horn() if len(c) > 1]
BASE = [var[(j, r)] for j in W for r in RECS if bg(j, r)] + [-var[(j, r)] for j in W for r in RECS if forb(j, r)]
S = Minisat22(bootstrap_with=H)
KC = kclauses(lambda s: W) if "--plus" not in sys.argv else kclauses(plus)


def prop(L):
    ok, imp = S.propagate(assumptions=BASE + L)
    return ok, set(imp)


def phi_val(j, r, kap):
    d = drank(j, r)
    return sum(d[k] * kap[j][k] * (1.0 if j == k else A) for k in range(3))


def stuck(L, r, Sx):
    ok, imp = prop(L)
    if not ok or any(var[(j, r)] in imp for j in Sx):
        return False
    return all(not prop(L + [var[(j, r)]])[0] for j in Sx)


rng = random.Random(3)
hits = []
for t in range(4000):
    k0 = [rng.uniform(1, 30) for _ in range(3)]
    k2 = [rng.uniform(1, 30) for _ in range(3)]
    if not (k0[0] >= k2[0] and k2[2] >= k0[2]):
        continue
    kap = {0: k0, 2: k2}
    L = [var[(j, r)] for j in (0, 2) for r in RECS if not bg(j, r) and phi_val(j, r, kap) >= 1e-9]
    ok, imp = prop(L)
    assert ok, "Phi' contained an unclean fragment state: certificate lemma violated?"
    for (s, r, Sx) in KC:
        if stuck(L, r, Sx):
            hits.append((kap, L, s, r))
            break
    if len(hits) >= 5:
        break
print("samples with a stuck (K)-clause:", len(hits))
for (kap, L, s, r) in hits[:3]:
    SX = W if "--plus" not in sys.argv else plus(s)
    Lm = list(L)
    changed = True
    while changed:
        changed = False
        for x in list(Lm):
            L2 = [y for y in Lm if y != x]
            if stuck(L2, r, SX):
                Lm = L2
                changed = True
    print("kappa world0", [round(x, 2) for x in kap[0]], "world2", [round(x, 2) for x in kap[2]])
    print("   stuck clause: pattern", s, "record", r)
    print("   minimal stuck state:")
    for v in Lm:
        j, rr = inv_var[v]
        print(f"     world {j}: {rr}  rank changes {drank(j, rr)}  Phi' value {phi_val(j, rr, kap):.3f}")
