"""X1: extract a MINIMAL clean-but-stuck state of the full-domain crossing fragment from random maximal clean
states (see maximal_states.py), and print it.  A state L is 'stuck' for the (K)-clause (s, r, S) if its Horn
closure is clean, does not meet the clause, and the closure of L + {(j, r)} is unclean for every j in S.
Also reports: is each literal of the minimal state a K-resolution (r out of a selected pattern)?  Is the
minimal state contained in a common-density Brier witness (it cannot be: witnesses are K-models)?  Is it
contained in world-wise additive orders?
Run: python3 -I stuck_minimise.py
"""
import sys, random
sys.path.insert(0, ".")
from fullfrag import bg, forb, horn, kclauses, var, inv_var, W, RECS, OUT, drank
from pysat.solvers import Minisat22
import numpy as np
from scipy.optimize import linprog

H = [c for c in horn() if len(c) > 1]
BASE = [var[(j, r)] for j in W for r in RECS if bg(j, r)] + [-var[(j, r)] for j in W for r in RECS if forb(j, r)]
KC = kclauses(lambda s: W)
S = Minisat22(bootstrap_with=H)


def prop(L):
    ok, imp = S.propagate(assumptions=BASE + L)
    return ok, set(imp)


def stuck(L, r, Sx):
    ok, imp = prop(L)
    if not ok or any(var[(j, r)] in imp for j in Sx):
        return False
    return all(not prop(L + [var[(j, r)]])[0] for j in Sx)


def worldwise(acc, a=0.2):
    # world j weight of piece k: c[j][k] >= 1 ; Brier-type loss (rank-1)|h_j| * c
    rows = []
    for (j, r) in acc:
        d = drank(j, r)
        row = [0.0] * 9
        for k in range(3):
            row[3 * j + k] = -d[k] * (1.0 if j == k else a)
        rows.append(row)
    res = linprog(np.zeros(9), A_ub=np.array(rows), b_ub=np.zeros(len(rows)), bounds=[(1, None)] * 9, method="highs")
    return res.x if res.status == 0 else None


rng = random.Random(1)
allv = sorted(inv_var)
found = []
for t in range(2000):
    L = []
    order = allv[:]
    rng.shuffle(order)
    ok, imp = prop(L)
    for v in order:
        if v in imp:
            continue
        ok2, imp2 = prop(L + [v])
        if ok2:
            L.append(v)
            imp = imp2
    for (s, r, Sx) in KC:
        if stuck(L, r, Sx):
            Lm = list(L)
            changed = True
            while changed:
                changed = False
                for x in list(Lm):
                    L2 = [y for y in Lm if y != x]
                    if stuck(L2, r, Sx):
                        Lm = L2
                        changed = True
            found.append((len(Lm), Lm, s, r))
            break
    if len(found) >= 25:
        break
found.sort(key=lambda z: z[0])
print("stuck maximal states found:", len(found), " sizes of minimised stuck states:", [f[0] for f in found])
seen = set()
for (n, Lm, s, r) in found[:6]:
    key = (tuple(sorted(Lm)), r)
    if key in seen:
        continue
    seen.add(key)
    lits = [inv_var[v] for v in Lm]
    print(f"--- minimal stuck state ({n} literals); clause: pattern {s}, record {r}")
    for (j, rr) in lits:
        print(f"     world {j}: {rr}   out-of-pattern record: {rr in OUT}   rank changes at {j}: {drank(j, rr)}")
    ok, imp = prop(Lm)
    acc = [inv_var[v] for v in imp if v > 0] + [(j, rr) for j in W for rr in RECS if bg(j, rr)]
    print("     world-wise additive witness for its closure:", worldwise(sorted(set(acc), key=str)) is not None)
    for j in W:
        ok2, imp2 = prop(Lm + [var[(j, r)]])
        print(f"     adding clause record at world {j}: clean? {ok2}")
