"""Referee check (exact) of the audit's interior-locality lemma (AUDIT_X123.md): for the posterior family and
distinct interior p, q, rec(C_p, C_q) has support reaching a coordinate plane (log|h_k/h_i| -> -inf).

(1) The acceptance formula: for h = (h_i=-1, h_j=t, h_k=s), t, s > 0:  h in C_p  iff  p_j t + p_k s > A p_i,
    A = (c0+eps)/c0.  Checked against the vertex-form definition on random exact instances.
(2) For random pairs p != q, choose (i, j) with p_i/p_j != q_i/q_j, an interval of t strictly between
    A p_i/p_j and A q_i/q_j, and verify that C_p and C_q give different advice at (-1, t, s) for every t in a
    grid of that interval and s = 10^-1 ... 10^-12.
Run: python3 -I audit_locality_check.py
"""
from fractions import Fraction as Fr
import random

rng = random.Random(11)


def verts(eps):
    c0 = (1 - eps) / 3
    return [tuple(c0 + (eps if i == k else 0) for i in range(3)) for k in range(3)]


def accepts(p, h, eps):
    """C_p accepts h (posterior): min over vertices of v.(p (.) h) > 0."""
    return min(sum(v[i] * p[i] * h[i] for i in range(3)) for v in verts(eps)) > 0


def rand_p():
    x = [Fr(rng.randint(1, 50)) for _ in range(3)]
    s = sum(x)
    return tuple(y / s for y in x)


bad1 = 0
for _ in range(5000):
    eps = Fr(rng.randint(1, 99), 100); c0 = (1 - eps) / 3; A = (c0 + eps) / c0
    p = rand_p(); i, j, k = rng.sample(range(3), 3)
    t = Fr(rng.randint(1, 500), rng.randint(1, 50)); s = Fr(rng.randint(1, 500), rng.randint(1, 50))
    h = [None] * 3; h[i] = Fr(-1); h[j] = t; h[k] = s
    if p[j] * t + p[k] * s == A * p[i]:
        continue
    bad1 += accepts(p, h, eps) != (p[j] * t + p[k] * s > A * p[i])
print("(1) acceptance-formula mismatches:", bad1)

fails = 0; pairs = 0
for _ in range(300):
    eps = Fr(rng.randint(1, 99), 100); c0 = (1 - eps) / 3; A = (c0 + eps) / c0
    p, q = rand_p(), rand_p()
    if p == q:
        continue
    cand = [(i, j) for i in range(3) for j in range(3) if i != j and p[i] * q[j] != q[i] * p[j]]
    i, j = cand[0]; k = 3 - i - j
    lo, hi = sorted((A * p[i] / p[j], A * q[i] / q[j]))
    a, b = lo + (hi - lo) / 4, hi - (hi - lo) / 4
    pairs += 1
    for n in range(9):
        t = a + (b - a) * n / 8
        for e in range(1, 13):
            s = Fr(1, 10 ** e) * (hi - lo) / 8 * min(p[j], q[j]) / max(p[k], q[k]) * 1
            h = [None] * 3; h[i] = Fr(-1); h[j] = t; h[k] = s
            if accepts(p, h, eps) == accepts(q, h, eps):
                fails += 1
print("(2) random distinct pairs:", pairs, " (t,s) points with NO disagreement:", fails)
