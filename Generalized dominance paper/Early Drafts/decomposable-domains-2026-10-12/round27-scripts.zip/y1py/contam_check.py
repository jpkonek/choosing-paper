# NUMERICS: the contamination family K_p = (1-eps)p + eps*Delta (through T1 at u) has, near u,
# no pair (p,q), p != q, with C_q pointwise weakly better than C_p at any world: every
# difference record is crossing at every world.  (Contrast: posterior family, mono_check.)
import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from post import rank
def cadv(p, h, eps):
    o = [k for k in range(3) if h[k] < 0][0]
    ph = sum(p[k]*h[k] for k in range(3))
    if (1-eps)*ph + eps*h[o] > 0: return 'M'
    if (1-eps)*ph + eps*max(h) < 0: return 'O'
    return 'S'
random.seed(2)
for eps in [F(1,10), F(3,10), F(6,10)]:
    pairs = 0; crossing_all = 0
    for _ in range(60):
        p = [F(1,3)+F(random.randint(-500,500),10**4) for _ in range(2)]; p.append(1-p[0]-p[1])
        q = [p[0]+F(random.randint(-300,300),10**4), p[1]+F(random.randint(-300,300),10**4)]; q.append(1-q[0]-q[1])
        if q == p: continue
        pairs += 1
        ok = True
        for i in range(3):
            better = worse = False
            for _ in range(60000):
                o = random.randrange(3)
                h = [F(10**random.randint(0,6))/F(random.randint(1,10**4)) for _ in range(3)]; h[o] = -F(10**random.randint(0,6))/F(random.randint(1,10**4))
                r1, r2 = rank(i,h,cadv(p,h,eps)), rank(i,h,cadv(q,h,eps))
                better |= r2 < r1; worse |= r2 > r1
                if better and worse: break
            ok &= better and worse
        crossing_all += ok
    print(f"eps={eps}: pairs {pairs}, crossing at all three worlds {crossing_all}")
