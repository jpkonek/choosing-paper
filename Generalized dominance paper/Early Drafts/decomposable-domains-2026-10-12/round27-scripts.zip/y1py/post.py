# Exact posterior advice on the full domain (X2.6 form). Fractions throughout.
from fractions import Fraction as F
def lam(eps):
    c0 = (1-eps)/3
    return eps/c0
def advice(p, h, L):
    """p in simplex, h a mixed gamble with exactly one negative coord (majority orientation).
    Returns 'M' (accept h), 'O' (accept -h), 'S' (silent)."""
    neg = [k for k in range(3) if h[k] < 0]
    assert len(neg) == 1 and all(h[k] != 0 for k in range(3))
    o = neg[0]
    ph = sum(p[k]*h[k] for k in range(3))
    if ph + L*p[o]*h[o] > 0: return 'M'
    if ph + L*max(p[j]*h[j] for j in range(3) if j != o) < 0: return 'O'
    return 'S'
# world rank: majority worlds M<S<O ; odd world O<S<M
def rank(world, h, a):
    o = [k for k in range(3) if h[k] < 0][0]
    order = ['M','S','O'] if world != o else ['O','S','M']
    return order.index(a)
def ray(p, i, s):
    q = list(p); q[i] = q[i]*s
    t = sum(q); return [x/t for x in q]
