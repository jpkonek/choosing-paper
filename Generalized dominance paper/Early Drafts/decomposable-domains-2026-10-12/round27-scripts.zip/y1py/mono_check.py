# Y1.1 (NUMERICS/CHECKED on samples): moving p toward e_i (multiply p_i by s>1) is a pointwise
# weak world-i improvement; any other log-direction produces a world-i worsening somewhere.
import random
from fractions import Fraction as F
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); from post import *
random.seed(1)
for eps in [F(1,10), F(3,10), F(6,10)]:
    L = lam(eps); bad = 0; strict = 0; n = 0
    for _ in range(4000):
        a = [F(random.randint(20,60)) for _ in range(3)]; t = sum(a); p = [x/t for x in a]
        i = random.randrange(3); s = F(random.randint(101,160),100)
        q = ray(p, i, s)
        o = random.randrange(3)
        h = [F(random.randint(1,400),100) for _ in range(3)]; h[o] = -F(random.randint(1,800),100)
        ap, aq = advice(p,h,L), advice(q,h,L)
        n += 1
        if rank(i,h,aq) > rank(i,h,ap): bad += 1
        if rank(i,h,aq) < rank(i,h,ap): strict += 1
    print(f"eps={eps}: ray samples {n}, world-i worsenings {bad}, strict improvements {strict}")
    # converse: direction eta with eta_j != eta_l; construct the witness of the proof
    found = 0; trials = 0
    for _ in range(300):
        a = [F(random.randint(20,60)) for _ in range(3)]; t = sum(a); p = [x/t for x in a]
        i = random.randrange(3); j, l = [k for k in range(3) if k != i]
        d = [F(random.randint(50,200),100) for _ in range(3)]
        if d[j] == d[l]: continue
        if d[j] > d[l]: j, l = l, j       # now d_j < d_l ; odd world o := l
        q = [p[k]*d[k] for k in range(3)]; t = sum(q); q = [x/t for x in q]
        trials += 1
        # search h in Q_l with C_p at M and C_q not at M (worsening for majority world i)
        ok = False
        for _ in range(4000):
            h = [F(0)]*3
            h[i] = F(random.randint(1,50),1000); h[j] = F(random.randint(1,400),100); h[l] = -F(random.randint(1,800),100)
            ap, aq = advice(p,h,L), advice(q,h,L)
            if rank(i,h,aq) > rank(i,h,ap): ok = True; break
        found += ok
    print(f"eps={eps}: off-ray directions {trials}, world-i worsening witness found in {found}")
