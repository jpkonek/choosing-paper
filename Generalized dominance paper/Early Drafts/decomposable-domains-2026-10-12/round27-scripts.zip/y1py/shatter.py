# Y1.4 input (CHECKED, exact rationals): four points of a small polygon N0 around u are robustly
# shattered by the advice sets {q : C_q(h) = b} of the posterior family, using only pairs h whose
# box B(h) = {C_q(h) : q in N0} has exactly two elements.
import sys, os, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from post import lam, advice
import numpy as np
from scipy.optimize import linprog

def run(eps, R=F(1,100)):
    L = lam(eps); u = [F(1,3)]*3
    two = F(2)
    hstar = [-(two+L), F(1), F(1)]                 # wedge pair, odd world 0, apex at u
    g1 = [hstar[0], hstar[1]*(1+L), hstar[2]]       # f_1(u+w) = w.g1
    g2 = [hstar[0], hstar[1], hstar[2]*(1+L)]
    dot = lambda a,b: sum(x*y for x,y in zip(a,b))
    # directions in the sum-zero plane orthogonal to g1 (resp. g2): cross product with (1,1,1)
    def perp(g):
        one = [F(1)]*3
        return [g[1]*one[2]-g[2]*one[1], g[2]*one[0]-g[0]*one[2], g[0]*one[1]-g[1]*one[0]]
    r1 = perp(g1); r1 = r1 if dot(r1,g2) < 0 else [-x for x in r1]
    r2 = perp(g2); r2 = r2 if dot(r2,g1) < 0 else [-x for x in r2]
    def nrm(v):
        s = max(abs(x) for x in v); return [x/s for x in v]
    r1, r2 = nrm(r1), nrm(r2)
    out1 = nrm([g1[k] - sum(g1)/3 for k in range(3)])    # pushes to f_1 > 0
    out2 = nrm([g2[k] - sum(g2)/3 for k in range(3)])
    eta, push = R/1000, R/1000
    bis = [F(2),F(-1),F(-1)]
    add = lambda p,*vs: [p[k]+sum(v[k] for v in vs) for k in range(3)]
    sc = lambda c,v: [c*x for x in v]
    d = add(u, sc(eta, bis))
    a = add(u, sc(R, r1), sc(push, out1))
    b = add(u, sc(R, r2), sc(push, out2))
    c = add(u, sc(-R, bis))
    P = [a,b,c,d]; names = 'abcd'
    # N0: square (in coordinates 0,1) of half-width 3R around u
    w = 3*R
    N0 = [[u[0]+sx*w, u[1]+sy*w, 1-(u[0]+sx*w)-(u[1]+sy*w)] for sx in (-1,1) for sy in (-1,1)]
    assert all(min(v) > 0 for v in N0)
    real = {}
    # wedge pair: O-set should be {d}
    lab = [advice(p, hstar, L) for p in P]
    mfun = lambda p: dot(p,hstar) + L*p[0]*hstar[0]
    assert all(mfun(v) < 0 for v in N0), "wedge pair would reach M on N0"
    assert lab == ['S','S','S','O'], lab
    real[frozenset('d')] = ('wedge', hstar)
    # remaining complementary classes by lines -> M/S pairs
    subsets = [frozenset(s) for r in range(1,3) for s in itertools.combinations(names, r)]
    for S in subsets:
        comp = frozenset(names) - S
        if S in real or comp in real: continue
        # LP: find k (3-vector) with p.k >= 1 for p in S, p.k <= -1 for p in comp
        A, bb = [], []
        for nm, p in zip(names, P):
            row = [float(x) for x in p]
            if nm in S: A.append([-x for x in row]); bb.append(-1.0)
            else: A.append(row); bb.append(-1.0)
        res = linprog(np.zeros(3), A_ub=A, b_ub=bb, bounds=[(-1e9,1e9)]*3, method='highs')
        assert res.status == 0, (S, res.message)
        k = [F(x).limit_denominator(10**9) for x in res.x]
        if sum(1 for x in k if x < 0) != 1:
            k = [-x for x in k]; S, comp = comp, S
        assert sum(1 for x in k if x < 0) == 1 and all(x != 0 for x in k)
        o = [i for i in range(3) if k[i] < 0][0]
        h = list(k); h[o] = k[o]/(1+L)              # M iff p.k > 0
        lab = [advice(p, h, L) for p in P]
        want = ['M' if nm in S else 'S' for nm in names]
        assert lab == want, (S, lab, want)
        # box check: O impossible on N0 (some f_j > 0 at all vertices)
        fj = lambda p, j: dot(p,h) + L*p[j]*h[j]
        assert any(all(fj(v,j) > 0 for v in N0) for j in range(3) if j != o)
        real[S] = ('line', h)
    covered = set()
    for S in real: covered |= {S, frozenset(names)-S}
    allsub = {frozenset(s) for r in range(0,5) for s in itertools.combinations(names, r)}
    # empty set and full set: trivial (use any pair whose box is two-element and whose boundary misses the 4 points)
    missing = allsub - covered - {frozenset(), frozenset(names)}
    # all/none: a line through N0 with all four points on its M side and an N0 vertex on the other
    A = [[-float(x) for x in p] for p in P] + [[float(x) for x in N0[0]]]
    res = linprog(np.zeros(3), A_ub=A, b_ub=[-1.0]*5, bounds=[(-1e9,1e9)]*3, method='highs')
    assert res.status == 0
    k = [F(x).limit_denominator(10**9) for x in res.x]
    if sum(1 for x in k if x < 0) == 1 and all(x != 0 for x in k):
        o = [i for i in range(3) if k[i] < 0][0]; h = list(k); h[o] = k[o]/(1+L)
        assert [advice(p,h,L) for p in P] == ['M']*4 and advice(N0[0],h,L) != 'M'
        fj = lambda p, j: dot(p,h) + L*p[j]*h[j]
        assert any(all(fj(v,j) > 0 for v in N0) for j in range(3) if j != o)
        missing_trivial = False
    else:
        missing_trivial = True
    print(f"   all/none labelling realised by an M/S pair: {not missing_trivial}")
    print(f"eps={eps}: realised classes {len(real)} (with complements {len(covered)} of 14 nontrivial subsets); missing {sorted(map(sorted,missing))}")
    print("   d in triangle abc:", inside(d,a,b,c))
    return not missing

def inside(d,a,b,c):
    def cr(p,q,r): return (q[0]-p[0])*(r[1]-p[1]) - (q[1]-p[1])*(r[0]-p[0])
    s = [cr(a,b,d), cr(b,c,d), cr(c,a,d)]
    return all(x>0 for x in s) or all(x<0 for x in s)

for eps in [F(1,10), F(3,10), F(6,10), F(9,10)]:
    for R in [F(1,100), F(1,10**4), F(1,10**7)]:
        print("R =", R); assert run(eps, R)
print("ALL OK")
