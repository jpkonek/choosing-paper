"""Exact rational helpers for Y2 (round 27).  Worlds 0,1,2.  A pair is a gamble h (orientation);
advice: '+' accept h, '0' silence, '-' accept -h, 'x' both."""
from fractions import Fraction as Fr
import random

ADV = ['+', '0', '-']
ADV4 = ['+', '0', '-', 'x']

def params(eps):
    eps = Fr(eps)
    c0 = (1 - eps) / 3
    A = (c0 + eps) / c0
    lam = eps / c0
    V = [[c0 + (eps if k == m else 0) for m in range(3)] for k in range(3)]  # vertices v_k of T1
    return eps, c0, A, lam, V

def dot(a, b):
    return sum(x * y for x, y in zip(a, b))

def advice_of_set(vals):
    """advice of D_K given the values m.h over the extreme points of K"""
    if min(vals) > 0:
        return '+'
    if max(vals) < 0:
        return '-'
    return '0'

def posterior_advice(p, h, V):
    """D_{nu(p (.) T1)} at h: extreme points p(.)v_k (normalisation irrelevant)."""
    vals = [sum(p[m] * V[k][m] * h[m] for m in range(3)) for k in range(3)]
    return advice_of_set(vals)

def T1_advice(h, V):
    return advice_of_set([dot(V[k], h) for k in range(3)])

def precise_advice(p, h):
    s = dot(p, h)
    return '+' if s > 0 else ('-' if s < 0 else '0')

def correct(m, h):
    return '+' if h[m] > 0 else '-'

def rank(m, h, a):
    """world-m background rank: correct 0, silence 1, wrong 2, both 3"""
    if a == 'x':
        return 3
    if a == '0':
        return 1
    return 0 if a == correct(m, h) else 2

def rnd_frac(lo, hi, den=997):
    return Fr(random.randint(int(lo * den) + 1, int(hi * den) - 1), den)

def rnd_mixed(rng=None, den=211):
    while True:
        h = [Fr(random.randint(-den, den), den) for _ in range(3)]
        if all(x != 0 for x in h) and not (all(x > 0 for x in h) or all(x < 0 for x in h)):
            return h

def rnd_unanimous(den=211):
    s = random.choice([1, -1])
    return [s * Fr(random.randint(1, den), den) for _ in range(3)]

def majority(h):
    """majority orientation (two positive coords) and odd world"""
    neg = [m for m in range(3) if h[m] < 0]
    if len(neg) == 1:
        return h, neg[0]
    g = [-x for x in h]
    return g, [m for m in range(3) if g[m] < 0][0]

def rnd_edge_prior(i, j, den=997):
    t = Fr(random.randint(1, den - 1), den)
    p = [Fr(0)] * 3
    p[i] = 1 - t
    p[j] = t
    return p

def rnd_interior(den=97):
    while True:
        a, b = random.randint(1, den - 1), random.randint(1, den - 1)
        if a + b < den:
            return [Fr(a, den), Fr(b, den), Fr(den - a - b, den)]
