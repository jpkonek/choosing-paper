"""Y2 Prop. Y2.3 / Lemma Y2.1 checks (exact):
 (1) posterior edge models = edge Bayes models of the two-step Brier box field (s1=1, s2=A), uniquely;
 (2) they differ in the interior (posterior != box at interior p);
 (3) threshold formulas on Q_c for edge (c,a): O iff t_a < 1/(A o), M iff t_a > A/o, o = p_a/p_c;
 (4) T1 positions on Q_c: M iff t_a+t_b > A; O iff t_a+t_b+lam*max(t_a,t_b) < 1."""
import random, sys
from fractions import Fraction as Fr
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

def box_cost(m, h, a, s1, s2):
    r = rank(m, h, a)
    return [0, s1, s1 + s2, 2 * (s1 + s2)][r] * abs(h[m])

def argmin_unique(costs):
    best = min(costs.values())
    arg = [a for a, c in costs.items() if c == best]
    return arg[0] if len(arg) == 1 else None

random.seed(int(sys.argv[1]) if len(sys.argv) > 1 else 1)
for eps in [Fr(1, 10), Fr(3, 10), Fr(6, 10)]:
    e, c0, A, lam, V = params(eps)
    bad_edge = 0; nonuniq = 0; n_edge = 0
    for _ in range(6000):
        i, j = random.sample(range(3), 2)
        p = rnd_edge_prior(i, j)
        h = rnd_mixed() if random.random() < .85 else rnd_unanimous()
        post = posterior_advice(p, h, V)
        costs = {a: sum(p[m] * box_cost(m, h, a, Fr(1), A) for m in range(3)) for a in ADV4}
        b = argmin_unique(costs)
        n_edge += 1
        if b is None:
            nonuniq += 1
        elif b != post:
            bad_edge += 1
    # vertices
    bad_vx = 0
    for _ in range(1500):
        k = random.randrange(3)
        p = [Fr(int(m == k)) for m in range(3)]
        h = rnd_mixed()
        if posterior_advice(p, h, V) != ('+' if h[k] > 0 else '-'):
            bad_vx += 1
    # interior mismatches
    mism = 0; n_int = 0
    for _ in range(3000):
        p = rnd_interior()
        h = rnd_mixed()
        post = posterior_advice(p, h, V)
        costs = {a: sum(p[m] * box_cost(m, h, a, Fr(1), A) for m in range(3)) for a in ADV4}
        b = argmin_unique(costs)
        n_int += 1
        if b is not None and b != post:
            mism += 1
    # thresholds on Q_c, edge (c,a)
    bad_thr = 0
    for _ in range(3000):
        c, a = random.sample(range(3), 2)
        b_ = 3 - c - a
        p = rnd_edge_prior(c, a)
        o = p[a] / p[c]
        ta, tb = rnd_frac(0, 6), rnd_frac(0, 6)
        h = [None] * 3; h[c] = Fr(-1); h[a] = ta; h[b_] = tb
        exp = '-' if ta < 1 / (A * o) else ('+' if ta > A / o else '0')
        if posterior_advice(p, h, V) != exp:
            bad_thr += 1
    # T1 positions on Q_c
    bad_t1 = 0
    for _ in range(3000):
        c = random.randrange(3); a, b_ = [m for m in range(3) if m != c]
        ta, tb = rnd_frac(0, 4), rnd_frac(0, 4)
        h = [None] * 3; h[c] = Fr(-1); h[a] = ta; h[b_] = tb
        exp = '+' if ta + tb > A else ('-' if ta + tb + lam * max(ta, tb) < 1 else '0')
        if T1_advice(h, V) != exp:
            bad_t1 += 1
    print(f"eps={eps}: A={A}; edge trials {n_edge}: posterior!=box-Bayes {bad_edge}, box non-unique {nonuniq}; "
          f"vertex mismatches {bad_vx}; interior: posterior!=box in {mism}/{n_int}; "
          f"threshold-formula failures {bad_thr}; T1-formula failures {bad_t1}")
