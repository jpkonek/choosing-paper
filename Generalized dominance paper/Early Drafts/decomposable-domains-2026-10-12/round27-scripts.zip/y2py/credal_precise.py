"""Y2 Thm Y2.10 checks (exact rationals).
Member penalty of world m with split phi in (0,1):  l(h,a) = |h_m| * (0, phi, 1, 2)[rank].
(1) For p on an open edge ij and ANY phi_i, phi_j with phi_i+phi_j >= 1 (here drawn independently per pair, i.e. a
    measurable member), D_p's advice is the UNIQUE minimiser of p_i l_i + p_j l_j over {+,0,-,x}; at vertices B^i is the
    unique world-i minimiser.  Region-dependent splits: on Q_c odd world phi in [1/5,3/10], majority worlds [4/5,9/10].
(2) Necessity of the mediant: with phi_i+phi_j < 1 silence is sometimes the strict minimiser at an edge prior.
(3) Non-additivity: an explicit incomparable pair for the two-member family {phi-, phi+} on a finite cell model.
(4) Empirical (K) and protection on a cell model with the two-member unanimity (sanity only)."""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from common import *

def pen(m, h, a, phi):
    return abs(h[m]) * [Fr(0), phi, Fr(1), Fr(2)][rank(m, h, a)]

def split_interval(m, h, mode):
    if mode == 'uniform':
        return (Fr(1, 2), Fr(19, 20))
    # region dependent: odd world cheap silence, majority worlds expensive
    _, o = majority(h) if not (all(x > 0 for x in h) or all(x < 0 for x in h)) else (h, None)
    if o is None:
        return (Fr(1, 2), Fr(19, 20))
    return (Fr(1, 5), Fr(3, 10)) if m == o else (Fr(4, 5), Fr(9, 10))

random.seed(int(sys.argv[1]) if len(sys.argv) > 1 else 2)
for mode in ['uniform', 'regional']:
    fail = 0; n = 0
    for _ in range(20000):
        i, j = random.sample(range(3), 2)
        p = rnd_edge_prior(i, j)
        h = rnd_mixed() if random.random() < .85 else rnd_unanimous()
        phi = {}
        for m in (i, j):
            lo, hi = split_interval(m, h, mode)
            phi[m] = lo + (hi - lo) * Fr(random.randint(0, 100), 100)
        costs = {a: p[i] * pen(i, h, a, phi[i]) + p[j] * pen(j, h, a, phi[j]) for a in ADV4}
        best = min(costs.values())
        arg = [a for a in ADV4 if costs[a] == best]
        n += 1
        if arg != [precise_advice(p, h)]:
            fail += 1
    vfail = 0
    for _ in range(3000):
        k = random.randrange(3)
        h = rnd_mixed() if random.random() < .85 else rnd_unanimous()
        lo, hi = split_interval(k, h, mode)
        ph = lo + (hi - lo) * Fr(random.randint(0, 100), 100)
        costs = {a: pen(k, h, a, ph) for a in ADV4}
        best = min(costs.values())
        if [a for a in ADV4 if costs[a] == best] != [correct(k, h)]:
            vfail += 1
    print(f"(1) mode={mode}: edge trials {n}, D_p not the unique pairwise minimiser: {fail}; vertex failures {vfail}")

# (2) mediant necessary
cnt = 0
for _ in range(20000):
    i, j = random.sample(range(3), 2)
    p = rnd_edge_prior(i, j)
    h = rnd_mixed()
    if h[i] * h[j] > 0:
        continue
    phi_i, phi_j = Fr(random.randint(5, 40), 100), Fr(random.randint(5, 40), 100)   # sum < 1
    costs = {a: p[i] * pen(i, h, a, phi_i) + p[j] * pen(j, h, a, phi_j) for a in ADV4}
    best = min(costs.values())
    if [a for a in ADV4 if costs[a] == best] == ['0']:
        cnt += 1
print(f"(2) with phi_i+phi_j<1: silence strict minimiser at an edge prior in {cnt} trials (expected >0)")

# (3) incomparability for the two-member family, world 0, cell model
lo, hi = Fr(1, 2), Fr(9, 10)
# X = B^0 silent on a cell set S (one silence step), Y = B^0 wrong on a cell set W; with |h_0|-masses a, b
a_mass, b_mass = Fr(1), Fr(7, 10)          # lo*a < b < hi*a
LX = {phi: phi * a_mass for phi in (lo, hi)}
LY = {phi: b_mass for phi in (lo, hi)}
X_le_Y = all(LX[f] <= LY[f] for f in (lo, hi)); Y_le_X = all(LY[f] <= LX[f] for f in (lo, hi))
print(f"(3) |h_0|-mass of silenced set {a_mass}, of wrong set {b_mass}: X<=Y {X_le_Y}, Y<=X {Y_le_X} (incomparable)")

# (4) empirical cell model sanity: (K) and protection for the two-member unanimity, uniform splits
N = 60
cells = [rnd_mixed() for _ in range(N)]
def L(m, model, phi):
    return sum(pen(m, cells[c], model[c], phi) for c in range(N))
def le(m, X, Y):  # X <=_m Y
    return all(L(m, X, f) <= L(m, Y, f) for f in (lo, hi))
kfail = pfail = 0
for _ in range(400):
    i, j = random.sample(range(3), 2)
    p = rnd_edge_prior(i, j)
    C = [precise_advice(p, h) for h in cells]
    X = [random.choice(ADV4) if random.random() < .3 else C[c] for c in range(N)]
    if not (le(i, C, X) or le(j, C, X)):
        kfail += 1
    if X != C and all(le(m, X, C) for m in range(3)):
        pfail += 1
print(f"(4) cell model ({N} cells, 400 random competitors): (K) failures {kfail}, protection failures {pfail}")
