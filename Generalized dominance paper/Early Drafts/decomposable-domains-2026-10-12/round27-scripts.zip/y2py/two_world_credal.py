"""Y2 Example Y2.9 (exact): a non-additive two-world credal edge system on the posterior edge [e_i,e_j].
Members of world i multiply each step weight of the box field (s1=1,s2=A) by Psi(level of that step), members of world j
by Psi'(level).  Levels are edge odds o=p_j/p_i: on Q_i, O|S level 1/(A t_j), S|M level A/t_j; on Q_j (u=h_i/|h_j|),
O|S level A u, S|M level u/A.  With Psi/Psi' nondecreasing, K(o)=o*Psi(o)/Psi'(o) is strictly increasing and the
posterior edge model is the UNIQUE minimiser at weights (1,K(o)) for every member pair -- (K), protection, (C)."""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from common import *

eps = Fr(3, 10); _, c0, A, lam, V = params(eps)
PI = [lambda o: Fr(1), lambda o: Fr(2) if o > 1 else Fr(1)]          # nondecreasing (world i)
PJ = [lambda o: Fr(1), lambda o: Fr(2) if o < 1 else Fr(1)]          # nonincreasing (world j)

def steps(i, j, h, Psi, Psj):
    """(first, second) step weights of worlds i and j at pair h (edge ij)."""
    g, c = majority(h)
    s = -g[c]
    if c == i:
        tj = g[j] / s; oB, oA = 1 / (A * tj), A / tj
        Fi, Si = abs(g[i]) * Psi(oB), A * abs(g[i]) * Psi(oA)       # i odd: first=B, second=A
        Fj, Sj = g[j] * Psj(oA), A * g[j] * Psj(oB)                 # j majority: first=A, second=B
    elif c == j:
        ui = g[i] / s; oB, oA = A * ui, ui / A
        Fj, Sj = abs(g[j]) * Psj(oB), A * abs(g[j]) * Psj(oA)       # j odd: first=B (level oB), second=A
        Fi, Si = g[i] * Psi(oA), A * g[i] * Psi(oB)                 # i majority: first=A, second=B
    else:   # Q_k: both majority, plain box
        Fi, Si = abs(g[i]), A * abs(g[i]); Fj, Sj = abs(g[j]), A * abs(g[j])
    return {i: (Fi, Si), j: (Fj, Sj)}

def cost(m, h, a, fs):
    F, S = fs[m]
    return [0, F, F + S][rank(m, h, a)]

random.seed(int(sys.argv[1]) if len(sys.argv) > 1 else 4)
fail = n = 0
for _ in range(20000):
    i, j = random.sample(range(3), 2)
    p = rnd_edge_prior(i, j); o = p[j] / p[i]
    h = rnd_mixed(den=97)
    a1, a2 = random.randrange(2), random.randrange(2)
    fs = steps(i, j, h, PI[a1], PJ[a2])
    K = o * PI[a1](o) / PJ[a2](o)
    costs = {a: cost(i, h, a, fs) + K * cost(j, h, a, fs) for a in ADV}
    best = min(costs.values()); arg = [a for a in ADV if costs[a] == best]
    n += 1
    if arg != [posterior_advice(p, h, V)]:
        fail += 1
print(f"member pairs x priors x pairs: {n}; posterior edge model not the unique minimiser: {fail}")
# non-proportionality of world i's two members on Q_i (B-step ratio as a function of t_j only)
vals = set()
for tj in [Fr(1, 10), Fr(1, 3), Fr(1), Fr(3)]:
    h = [Fr(-1), tj, Fr(1, 2)]
    a = steps(0, 1, h, PI[1], PJ[0])[0][0] / steps(0, 1, h, PI[0], PJ[0])[0][0]
    vals.add(a)
print("world-i member ratio (first step) on Q_i at t_j in {1/10,1/3,1,3}:", sorted(vals), "(non-constant)")
