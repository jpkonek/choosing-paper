"""Y2 Thms Y2.11-Y2.12 checks.
Fields are two-step: on a mixed pair, world m has first-step weight F_m (correct->silent) and second-step weight S_m
(silent->wrong); cost: correct 0, silent F_m, wrong F_m+S_m.  On Q_c (odd world c, majority orientation h=(−1,t_a,t_b)
up to scale) the odd world's B-step is its first step, a majority world's B-step (S–O) is its second step.
Pinned form for posterior edges (Thm Y2.7): a_c/b_a = K_ca(1/(A t_a)), b_c/a_a = K_ca(A t_a^{-1}).
 (A) flat two-valued K (1/2 on o<1, 2 on o>1, all edges): exact check that (i) T1 is a weak u-Bayes act on random
     pairs of every region, (ii) posterior edge models are weak pairwise Bayes acts at weight ratio K(o).
 (B) box field (K(o)=o): T1 fails to be q-Bayes for every q on a grid (NUMERICS) -- consistent with Thm Y2.11.
 (C) precise edges, random pinned fields with random nondecreasing K and splits obeying the mediant: for every q on a
     grid a T1 band pair violates weak q-Bayes (NUMERICS; Thm Y2.12 proves it)."""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from common import *

eps = Fr(3, 10)
_, c0, A, lam, V = params(eps)

def field_from_odd(h, base, Kfun):
    """h mixed. Returns per-world (F,S) on h's region. base(m,h)->(first,second) for the odd world.
    Kfun(c,a,o): Bayes-weight ratio function of edge (c,a) read with c odd (o = p_a/p_c)."""
    g, c = majority(h)
    s = -g[c]
    t = {m: g[m] / s for m in range(3) if m != c}
    Fc, Sc = base(c, g)            # c's first step (B-step O-S) and second (A-step S-M)
    out = {c: (Fc, Sc)}
    for a in t:
        RB = Kfun(c, a, 1 / (A * t[a]))   # = a_c / b_a   (b_a = a's second step)
        RA = Kfun(c, a, A / t[a])         # = b_c / a_a   (a_a = a's first step)
        out[a] = (Sc / RA, Fc / RB)
    return out

def cost(m, h, adv, fs):
    F, S = fs[m]
    r = rank(m, h, adv)
    return [0, F, F + S][r]

def weak_argmin(q, h, fs):
    costs = {a: sum(q[m] * cost(m, h, a, fs) for m in range(3)) for a in ADV}
    best = min(costs.values())
    return {a for a in ADV if costs[a] == best}

def base_brier(c, g):
    return (abs(g[c]), A * abs(g[c]))

def K_flat(c, a, o):
    return Fr(1, 2) if o < 1 else Fr(2)

def K_box(c, a, o):
    return o

random.seed(int(sys.argv[1]) if len(sys.argv) > 1 else 3)
u = [Fr(1, 3)] * 3

# (A)(i)
fail = 0; n = 0
for _ in range(20000):
    h = rnd_mixed(den=97)
    fs = field_from_odd(h, base_brier, K_flat)
    n += 1
    if T1_advice(h, V) not in weak_argmin(u, h, fs):
        fail += 1
print(f"(A)(i) flat K: T1 not a weak u-Bayes act on {fail}/{n} random mixed pairs")
# (A)(ii)
fail = 0; n = 0
for _ in range(20000):
    i, j = random.sample(range(3), 2)
    p = rnd_edge_prior(i, j)
    h = rnd_mixed(den=97)
    fs = field_from_odd(h, base_brier, K_flat)
    o = p[j] / p[i]
    if o == 1:
        continue
    w = [Fr(0)] * 3; w[i] = Fr(1); w[j] = K_flat(i, j, o)   # weights (1, K_ij(o)) on (i,j)
    n += 1
    if posterior_advice(p, h, V) not in weak_argmin(w, h, fs):
        fail += 1
print(f"(A)(ii) flat K: posterior edge model not a weak pairwise Bayes act on {fail}/{n} (pair, prior) trials")
# consistency: K_ac(o') = 1/K_ca(1/o') for flat K
print("(A) K_ac(o') == 1/K_ca(1/o') for o' in {1/3,3}:", all(K_flat(0, 1, o) == 1 / K_flat(1, 0, 1 / o) for o in (Fr(1, 3), Fr(3))))

# (A)(iii) box field: edge models are strict pairwise Bayes at weight o (sanity) and T1 is not q-Bayes on a q-grid
fail = 0; n = 0
for _ in range(5000):
    i, j = random.sample(range(3), 2)
    p = rnd_edge_prior(i, j)
    h = rnd_mixed(den=97)
    fs = field_from_odd(h, base_brier, K_box)
    w = [Fr(0)] * 3; w[i] = Fr(1); w[j] = p[j] / p[i]
    n += 1
    if weak_argmin(w, h, fs) != {posterior_advice(p, h, V)}:
        fail += 1
print(f"(B) box field: posterior edge model not the unique pairwise Bayes act in {fail}/{n} trials")
pairs = [rnd_mixed(den=97) for _ in range(3000)]
grid = [[Fr(a, 30), Fr(b, 30), Fr(30 - a - b, 30)] for a in range(0, 31) for b in range(0, 31 - a)]
ok_q = 0
for q in grid:
    if all(T1_advice(h, V) in weak_argmin(q, h, field_from_odd(h, base_brier, K_box)) for h in pairs):
        ok_q += 1
print(f"(B) box field: q-grid points ({len(grid)}) at which T1 is a weak q-Bayes act on all 3000 sample pairs: {ok_q}")
ok_q = 0
for q in grid:
    if all(T1_advice(h, V) in weak_argmin(q, h, field_from_odd(h, base_brier, K_flat)) for h in pairs):
        ok_q += 1
print(f"(B') flat field: q-grid points at which T1 is a weak q-Bayes act on all sample pairs: {ok_q} (u among them: "
      f"{all(T1_advice(h, V) in weak_argmin(u, h, field_from_odd(h, base_brier, K_flat)) for h in pairs)})")

# (C) precise edges: pinned totals tau_c/tau_a = K_ca(1/t_a); splits with mediant
def rand_K():
    # random nondecreasing step function on (0,inf) with values in [1/4,4], breakpoints in log-scale
    bps = sorted(Fr(random.randint(1, 60), 10) for _ in range(3))
    vals = sorted(Fr(random.randint(1, 16), 4) for _ in range(4))
    def K(o):
        k = sum(1 for b in bps if o > b)
        return vals[k]
    return K
viol_all = True
for trial in range(12):
    Ks = {}
    for c in range(3):
        for a in range(3):
            if a != c and (a, c) not in Ks:
                Ks[(c, a)] = rand_K()
    def Kfun(c, a, o):
        return Ks[(c, a)](o) if (c, a) in Ks else 1 / Ks[(a, c)](1 / o)
    phis = {}
    def precise_field(h):
        g, c = majority(h)
        s = -g[c]
        key = tuple(h)
        if key not in phis:
            pc = Fr(random.randint(10, 90), 100)
            pa = [max(1 - pc, Fr(random.randint(10, 95), 100)) for _ in range(2)]
            pa = [min(x, Fr(99, 100)) for x in pa]
            phis[key] = (pc, pa)
        pc, pa = phis[key]
        tc = abs(g[c])
        out = {c: (pc * tc, (1 - pc) * tc)}
        others = [m for m in range(3) if m != c]
        for idx, a in enumerate(others):
            ta = g[a] / s
            tau_a = tc / Kfun(c, a, 1 / ta)
            out[a] = (pa[idx] * tau_a, (1 - pa[idx]) * tau_a)
        return out
    # sanity: precise edge models are weak pairwise Bayes
    bad = 0
    for _ in range(1500):
        i, j = random.sample(range(3), 2)
        p = rnd_edge_prior(i, j)
        h = rnd_mixed(den=97)
        o = p[j] / p[i]
        w = [Fr(0)] * 3; w[i] = Fr(1); w[j] = Kfun(i, j, o)
        if precise_advice(p, h) not in weak_argmin(w, h, precise_field(h)):
            bad += 1
    # T1 band pairs
    band = [h for h in pairs if T1_advice(h, V) == '0'][:600]
    found_all = True
    for q in grid:
        if all(T1_advice(h, V) in weak_argmin(q, h, precise_field(h)) for h in band):
            found_all = False
    viol_all &= found_all
    print(f"(C) trial {trial}: precise-edge pairwise-Bayes sanity failures {bad} (these come only from jump levels "
          f"of K, a null set in the continuum; here breakpoints are exact rationals); "
          f"T1 violated on the band at every grid q: {found_all}")
print("(C) every trial: T1 not weakly q-Bayes for any grid q:", viol_all)
