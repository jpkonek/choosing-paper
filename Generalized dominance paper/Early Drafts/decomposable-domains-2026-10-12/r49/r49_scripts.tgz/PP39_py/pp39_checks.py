"""PP39 referee checks for round 48 (PP33, PP34, PP36).  Exact rational arithmetic throughout.

Run:  python3 -I -B pp39_checks.py      (writes pp39_checks.out next to this script)

(1) PP33 Lemma 1.2(a): the Sil(T) witness (-alpha, -2, 3) needs c(1-alpha) < 2 eps.  It fails for
    small eps; the witness (-alpha, -K, K+1+alpha) with K > c/eps works for every eps.
(2) PP36 §5 / P4 / §0(A): a single dominator serving ONE precise answerer C at ONE defence world
    can kill C at BOTH worlds of its support (Prop K with D = C).  C = D_lambda, lambda = (1/2,1/2,0).
    Checked on random rational points of two balls (open sets), for eps = 3/10 and eps = 1/20.
(3) PP34 Prop 5.2: blocked-world count when acceptance by GUIDANCE is also allowed (the literal
    hypothesis 'accepted at alpha(d) and at no other MIXED world' permits it).  Exhaustive on
    cell configurations.  Reports max blocked worlds, and max blocked worlds at which q is not a
    pure improvement.
(4) PP34 Prop 4.1(f): an edge model on [e_1, e_2] giving both answers on a one-class piece of
    Sil(T); its retreat is mixed at both worlds of its support.
(5) PP33 §5/§8: R_1(m) is not competitive against V_1 = R_1(0) in PP33's relation: the record
    rec(R_1(m), V_1) is a pure 1-improvement and mixed at worlds 2 and 3 (sampled on the wedge).
"""
from fractions import Fraction as F
import itertools, random, os

out = []
fails = 0
def log(s):
    out.append(s)
def check(cond, msg):
    global fails
    if not cond:
        fails += 1
        log("FAIL: " + msg)

def sgn(x):
    return (x > 0) - (x < 0)
def dot(a, b):
    return sum(x * y for x, y in zip(a, b))

def make_T(eps):
    c = (1 - eps) / 3
    def silent(g):
        S = sum(g)
        return c * S + eps * min(g) < 0 < c * S + eps * max(g)
    return c, silent

def cls(g):
    """minority world (0-based) of a mixed problem, 'U' if unanimous, None if a zero coordinate."""
    s = [sgn(x) for x in g]
    if 0 in s:
        return None
    for k in range(3):
        o = [s[w] for w in range(3) if w != k]
        if o[0] == o[1] and s[k] != o[0]:
            return k
    return 'U'

def rank(w, g, ans):
    """ans: +1/-1 = sign of the accepted gamble (an answer), 0 = silence."""
    if ans == 0:
        return 1
    return 0 if ans == sgn(g[w]) else 2

# ---------------------------------------------------------------- (1)
log("(1) PP33 Lemma 1.2(a), Sil(T) witness")
for eps in (F(3, 10), F(1, 7), F(1, 10), F(1, 20)):
    c, silent = make_T(eps)
    bad = 0; good = 0; tot = 0
    for tn in range(1, 100):
        t = F(tn, 100)
        al = t / (3 - 2 * t)
        g = (-al, F(-2), F(3))
        s0 = g[0] / (g[0] - sum(g) / 3)
        check(s0 == t, "s0 of old witness")
        bad += (not silent(g))
        K = int(c / eps) + 2
        a2 = t / (3 * (1 - t))
        g2 = (-a2, F(-K), K + 1 + a2)
        s02 = g2[0] / (g2[0] - sum(g2) / 3)
        check(s02 == t and silent(g2), f"repaired witness eps={eps} t={t}")
        good += silent(g2) and s02 == t
        tot += 1
    log(f"    eps={eps}: old witness (-a,-2,3) NOT in Sil(T) for {bad}/{tot} values of t; "
        f"repaired witness in Sil(T) with s0_1 = t for {good}/{tot}")
c, silent = make_T(F(1, 20))
check(not silent((-F(1, 10) / (3 - F(2, 10)), F(-2), F(3))), "expected failure of old witness at eps=1/20, t=1/10")

# ---------------------------------------------------------------- (2)
log("(2) PP36: one precise answerer, one defence world, two killed worlds")
lam = (F(1, 2), F(1, 2), F(0))
rnd = random.Random(39)
def ball(center, r, n):
    pts = [tuple(center)]
    for _ in range(n):
        pts.append(tuple(x + F(rnd.randint(-1000, 1000), 1000) * r for x in center))
    return pts
g1c = (F(-1), F(2), F(-11, 10))     # class M_2 (world 2 = index 1 is minority)
g2c = (F(2), F(-1), F(-11, 10))     # class M_1 (world 1 = index 0 is minority)
for eps in (F(3, 10), F(1, 20)):
    c, silent = make_T(eps)
    n_ok = 0
    for center, minority, killed in ((g1c, 1, 0), (g2c, 0, 1)):
        for g in ball(center, F(1, 20), 400):
            C = sgn(dot(lam, g))                    # C's answer
            ok = (silent(g) and cls(g) == minority and C == sgn(g[minority]))   # C says B (minority answer)
            # record (G, S -> C) is a weak 3-worsening (world index 2): guidance at world 3
            ok = ok and rank(2, g, C) > rank(2, g, 0)
            # Z = C[G -> 3-correct answer]; 3-correct is the majority answer A here
            z = sgn(g[2])
            ok = ok and z != C
            # Z <=_killed C strictly at g (Prop K with D = C), and also at world 3
            ok = ok and rank(killed, g, z) < rank(killed, g, C) and rank(2, g, z) < rank(2, g, C)
            check(ok, f"point {g} eps={eps}")
            n_ok += ok
    log(f"    eps={eps}: {n_ok}/802 sampled points satisfy all conditions "
        f"(Sil(T), class, C says B, guidance at world 3, Z strictly better than C at world 1 resp. 2)")
log("    => with G1 = ball around (-1,2,-1.1) and G2 = ball around (2,-1,-1.1), E = G, w = 3 for both,")
log("       one dominator N of Z1 and Z2 gives C not<=_1 N and C not<=_2 N (Prop K); supp(lambda) = {1,2}.")

# ---------------------------------------------------------------- (3)
log("(3) PP34 Prop 5.2 with guidance acceptances included")
A_, S_, B_ = 'A', 'S', 'B'
def crank(w, k, v):
    """rank at world w on a piece of class k (k = minority world) of advice v in {A,S,B}."""
    if v == S_:
        return 1
    if v == A_:
        return 2 if w == k else 0
    return 0 if w == k else 2
def icorrect(i, k):
    return B_ if k == i else A_
def alpha(loss, prio=(0, 1, 2)):
    m = max(loss)
    for w in prio:
        if loss[w] == m:
            return w
pieces_types = [(k, a) for k in range(3) for a in (A_, B_)]
worst_all = 0; worst_np = 0; ex = None; n_cfg = 0
for npieces in (1, 2):
    for types in itertools.product(pieces_types, repeat=npieces):
        for masses in itertools.product((1, 2), repeat=npieces):
            for bvals in itertools.product((S_, A_, B_), repeat=npieces):
                if all(bv == t[1] for bv, t in zip(bvals, types)):
                    continue  # q trivial
                n_cfg += 1
                lossO = [sum(m for (k, a), m in zip(types, masses) if crank(w, k, a) == 2) for w in range(3)]
                blocked = set(); pure = set()
                for i in range(3):
                    # pure improvement test of q at i
                    ch = [crank(i, k, bv) - crank(i, k, a) for (k, a), bv in zip(types, bvals) if bv != a]
                    if all(x <= 0 for x in ch) and any(x < 0 for x in ch):
                        pure.add(i)
                    # b must take values in {S, i-correct}
                    if not all(bv == S_ or bv == icorrect(i, k) for (k, a), bv in zip(types, bvals)):
                        continue
                    b_has_icorrect = any(bv != S_ for bv in bvals)
                    j, l = [w for w in range(3) if w != i]
                    # paddings: B on M_i (loss j,l), A on M_j (loss j), A on M_l (loss l)
                    for x1, x2, x3 in itertools.product(range(3), repeat=3):
                        Fnull = (x1 + x2 + x3 == 0)
                        if Fnull and not b_has_icorrect:
                            continue
                        loss = list(lossO)
                        loss[j] += x1 + x2; loss[l] += x1 + x3
                        acc = (alpha(loss) == i)
                        # guidance: d is a weak i-worsening iff F null and a is i-wrong on every piece
                        if Fnull and all(crank(i, k, a) == 2 for (k, a) in types):
                            acc = True
                        if acc:
                            blocked.add(i); break
                if len(blocked) > worst_all:
                    worst_all = len(blocked); ex = (types, masses, bvals, sorted(blocked), sorted(pure))
                worst_np = max(worst_np, len(blocked - pure))
log(f"    {n_cfg} configurations (1-2 pieces, masses 1-2, paddings 0-2 of each type)")
log(f"    max blocked worlds (alpha OR guidance acceptance): {worst_all}; example "
    f"(pieces (minority world, answer), masses, b, blocked worlds, pure-improvement worlds; 0-based): {ex}")
log(f"    max blocked worlds at which q is NOT a pure improvement: {worst_np}")
check(worst_all == 2 and worst_np <= 1, "Prop 5.2 repaired form")

# ---------------------------------------------------------------- (4)
log("(4) PP34 Prop 4.1(f): edge model on [e_1,e_2], one-class piece of Sil(T) with both answers")
c, silent = make_T(F(3, 10))
D = (F(1, 2), F(1, 2), F(0))
h1 = (F(-1), F(1, 2), F(1, 2)); h2 = (F(-3, 2), F(2), F(1, 2))
for h in (h1, h2):
    check(silent(h) and cls(h) == 0, f"{h} in Sil(T) and M_1")
a1, a2 = sgn(dot(D, h1)), sgn(dot(D, h2))
log(f"    D answers {'B' if a1 == sgn(h1[0]) else 'A'} at {h1} and {'B' if a2 == sgn(h2[0]) else 'A'} at {h2} (both M_1, both in Sil(T))")
for w in (0, 1):
    d1 = rank(w, h1, 0) - rank(w, h1, a1); d2 = rank(w, h2, 0) - rank(w, h2, a2)
    log(f"    retreat D -> S, world {w+1}: rank changes {d1:+d}, {d2:+d}  -> {'mixed' if d1*d2 < 0 else 'one-signed'}")
    check(d1 * d2 < 0, "expected mixed retreat")

# ---------------------------------------------------------------- (5)
log("(5) PP33: rec(R_1(m), V_1) on the wedge W_1(0,m), m = 1/5")
m = F(1, 5)
u = (F(1, 3),) * 3
lam_m = tuple((1 - m) * (1 if i == 0 else 0) + m * u[i] for i in range(3))
signs = {w: set() for w in range(3)}
cnt = 0
for _ in range(20000):
    g = tuple(F(rnd.randint(-50, 50), rnd.randint(1, 9)) for _ in range(3))
    if 0 in g or sum(g) == 0:
        continue
    old = sgn(dot(lam_m, g)); new = sgn(g[0])
    if old == 0 or old == new:
        continue
    cnt += 1
    for w in range(3):
        signs[w].add(sgn(rank(w, g, new) - rank(w, g, old)))
log(f"    {cnt} wedge points; signs of rank change old R_1(m) -> new V_1 by world: "
    + ", ".join(f"world {w+1}: {sorted(signs[w])}" for w in range(3)))
check(signs[0] == {-1} and signs[1] == {-1, 1} and signs[2] == {-1, 1}, "expected pure 1-improvement, mixed at 2 and 3")

log("ALL PASS" if fails == 0 else f"FAILURES: {fails}")
here = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(here, "pp39_checks.out"), "w") as fh:
    fh.write("\n".join(out) + "\n")
print("\n".join(out))
