"""PP34 check S2 (CHECKED on cells): a joint rule for the forced-defence family.

Cells (layout 'ab' by default; 'ad', 'bd' replace one radial split by a second cone cell d, so
that V_2 and V_3 also have coherent edge dominators on the cells): directions inside or near T1's silence, each silent direction split radially into an
inner atom ("_in", the bounded piece G lives here) and an outer atom ("_out"), so that a model
which differs on _in but not on _out is non-conic, hence incoherent (Lemma H).  Directions:
  a  = (0.15, -0.85, 1.15)  in M_2, T silent   (PP30's ball centre h+, eps = 3/10)
  b  = (0.15, 1.15, -0.85)  in M_3, T silent   (PP30's h-)
  c  = (-0.05, 1, 1)        in M_1, T answers A (a cone where edge models leave V_1)
  d  = (-1, 0.05, 1)        in M_1, T silent    (a cone where [e_2,e_1]- and [e_3,e_1]-models leave V_2, V_3)
A cell model is coherent iff it is conic (equal on _in/_out) and its pattern is realised by
some D_K (LP).  It may be selected on a face of the simplex iff realisable with K in that face.

Unknowns: verdict of every record at every world; which coherent patterns are selected, and on
which faces.  Fixed: T selected (interior), V_1, V_2, V_3 selected at the vertices.
Constraints (all exact):
  base     reflexivity, weak guidance, strict (G), (IB) (verdicts are per record), (TC) via
           PP23 Lemma 1.1 (P1/P2), at every world;
  sel      every selected pattern is competitive on its face's worlds against EVERY cell model,
           and undominated; no all-world tie of a selected pattern with an incoherent model
           (direct (C));
  dom      every target rival has a selected dominator (weak at all worlds, strict at one);
  edgeKKM  (flag) for every target rival and every edge {i,j}: some pattern selected on that
           edge is no worse than it at i and at j (1-D KKM, PP32 Lemma 2.2's step 1).
Targets: 'family' = all Z = V_j[G -> S, E -> w-correct] for j = 1, 2, 3 (G in {a_in, b_in, both},
         E a non-null sub-union, w != j) and the retreats R_G; 'all' = every incoherent cell model.
Flag maxsel: every coherent pattern is selected on every face where it is realisable (the most
demanding competitiveness/undominatedness load, as in PP29's 'sel' mode).
Flag wedge: the dominator of every R_1 / Z_1 target must be the silent-wedge model V_1[c -> S]
(c is the only cone cell; V_2, V_3 have no coherent silent wedge on these cells)
(the dominator rule of PP34 Section 5.4), selected on some face where it is realisable.
Flag v1: family of V_1 only.  On UNSAT a minimal core of target requirements is printed.
Usage: python3 -B forced_family_sat.py <targets> [layout=ab|ad|bd] [edgeKKM] [maxsel] [wedge] [v1] [nodirC]
"""
import sys, time, itertools
import numpy as np
from lib34 import Cells, Problem, CODE
from geom34 import orient, klass, t1, realisable, FACES, A, S, B

DIRS = {'a': (0.15, -0.85, 1.15), 'b': (0.15, 1.15, -0.85), 'c': (-0.05, 1, 1), 'd': (-1, 0.05, 1)}
LAYOUTS = {   # cell layouts (5 cells each; '_in'/'_out' = radial split of one direction)
    'ab': [('a', 'in'), ('a', 'out'), ('b', 'in'), ('b', 'out'), ('c', '')],
    'ad': [('a', 'in'), ('a', 'out'), ('b', ''), ('c', ''), ('d', '')],
    'bd': [('b', 'in'), ('b', 'out'), ('a', ''), ('c', ''), ('d', '')],
}
PIECES = LAYOUTS['ab']


def setup():
    dname = list(DIRS)
    dirs = [orient(DIRS[k]) for k in dname]
    pdir = [dname.index(d) for d, _ in PIECES]
    cls = [klass(dirs[i]) for i in pdir]
    cells = Cells(cls)
    n = len(PIECES)
    T = [t1(dirs[i]) for i in pdir]
    V = [[A if (dirs[i][j] > 0) else B for i in pdir] for j in range(3)]
    models = list(itertools.product(range(3), repeat=n))
    def conic(m):
        return all(m[p] == m[q] for p in range(n) for q in range(n) if pdir[p] == pdir[q])
    def faces_of(m):
        if not conic(m):
            return ()
        pat = [None] * len(dirs)
        for p in range(n):
            pat[pdir[p]] = m[p]
        return tuple(f for f in FACES if realisable(pat, dirs, f))
    fc = {m: faces_of(m) for m in models}
    return cells, dirs, pdir, cls, T, V, models, fc


def main(targets, flags):
    t0 = time.time()
    cells, dirs, pdir, cls, T, V, models, fc = setup()
    n = cells.n
    coh = [m for m in models if fc[m]]
    print(f'pieces {PIECES}; classes (minority world) {[k+1 for k in cls]}')
    print(f'T = {"".join("ASB"[v] for v in T)}; V1 = {"".join("ASB"[v] for v in V[0])}, '
          f'V2 = {"".join("ASB"[v] for v in V[1])}, V3 = {"".join("ASB"[v] for v in V[2])}')
    print(f'cell models {len(models)}, coherent {len(coh)}')
    P = Problem(cells)
    P.base()
    nv = 3 * cells.N
    pool = {}
    def newvar():
        nonlocal nv
        nv += 1
        return nv
    cand = [(m, f) for m in coh for f in fc[m]]
    for m, f in cand:
        pool[(m, f)] = newvar()
    fixed = [(tuple(T), 'int')] + [(tuple(V[j]), 'v%d' % (j + 1)) for j in range(3)]
    for key in fixed:
        assert key in pool, key
        P.add([pool[key]])
    if 'maxsel' in flags:      # every realisable pattern selected on every face where realisable
        for key, s_ in pool.items():
            P.add([s_])
    incoh = lambda m: not fc[m]
    for (m, f), s in pool.items():
        sup = FACES[f]
        recs = cells.records_from(list(m))
        for r in recs:
            if r == 0:
                continue
            P.add([-s] + [P.var(w, r) for w in sup])
            ri = int(cells.inv[r])
            for w0 in range(3):
                P.add([-s] + [-P.var(w, ri) for w in range(3)] + [P.var(w0, r)])
        if 'nodirC' not in flags:
            for X in models:
                if incoh(X):
                    r = cells.rec(list(m), list(X)); ri = int(cells.inv[r])
                    P.add([-s] + [-P.var(w, r) for w in range(3)] + [-P.var(w, ri) for w in range(3)])
    # targets
    gin = [p for p, (dn, t) in enumerate(PIECES) if t == 'in']
    tg = []
    if targets == 'family':
        for j in ((0,) if 'v1' in flags else range(3)):
            for Gs in ([[gin[0]], [gin[1]], gin] if len(gin) == 2 else [gin]):
                R = list(V[j])
                for p in Gs: R[p] = S
                tg.append(('R%d' % (j + 1), tuple(Gs), (), 0, tuple(R)))
                for k in range(1, len(Gs) + 1):
                    for Es in itertools.combinations(Gs, k):
                        for w in range(3):
                            if w == j: continue
                            Z = list(R)
                            for p in Es:
                                Z[p] = A if w != cls[p] else B
                            tg.append(('Z%d' % (j + 1), tuple(Gs), Es, w, tuple(Z)))
    else:
        tg = [('X', (), (), 0, m) for m in models if incoh(m)]
    tg = [t for t in tg if incoh(t[4])]
    seen = set(); tg2 = []
    for t in tg:
        if t[4] not in seen:
            seen.add(t[4]); tg2.append(t)
    tg = tg2
    print(f'targets: {len(tg)} incoherent rivals ({targets})')
    tlab = {}
    cpos = PIECES.index(('c', ''))   # V_1's silent wedge cell
    for kind, Gs, Es, w, Z in tg:
        ys = []
        allowed = None
        if 'wedge' in flags and kind in ('R1', 'Z1'):  # silent-wedge dominator V_1[c -> S] only
            jv = 0
            Wm = list(V[jv]); Wm[cpos] = S
            allowed = tuple(Wm)
        for (m, f), s in pool.items():
            if allowed is not None and m != allowed:
                continue
            y = newvar(); ys.append(y)
            r = cells.rec(list(m), list(Z)); ri = int(cells.inv[r])
            P.add([-y, s])
            for v in range(3):
                P.add([-y, P.var(v, r)])
            P.add([-y] + [-P.var(v, ri) for v in range(3)])
        tsel = newvar(); tlab[tsel] = f'{kind} G={[PIECES[p][0] for p in Gs]} E={[PIECES[p][0] for p in Es]} w={w+1} dominator'
        P.add([-tsel] + ys)
        if 'edgeKKM' in flags:
            for e in ('e12', 'e13', 'e23'):
                i, j = FACES[e]
                zs = []
                for (m, f), s in pool.items():
                    if f != e and not (f in ('v%d' % (i + 1), 'v%d' % (j + 1))):
                        continue
                    z = newvar(); zs.append(z)
                    r = cells.rec(list(m), list(Z))
                    P.add([-z, s]); P.add([-z, P.var(i, r)]); P.add([-z, P.var(j, r)])
                esel = newvar(); tlab[esel] = f'{kind} G={[PIECES[p][0] for p in Gs]} E={[PIECES[p][0] for p in Es]} w={w+1} edge-KKM {e}'
                P.add([-esel] + zs)
    ok = P.solve(assumptions=list(tlab))
    print(f'records {cells.N}, P1 {P.np1}, P2 {P.np2}, clauses {P.ncl}: {"SAT" if ok else "UNSAT"}'
          f' ({time.time()-t0:.0f}s)')
    if not ok:
        core = list(P.s.get_core())
        for lit in list(core):
            trial = [x for x in core if x != lit]
            if not P.solve(assumptions=trial):
                core = trial
        print('  minimal core of target requirements:')
        for lit in core:
            print('    ', tlab[lit])
        # which coherent patterns could serve on the edges named in the core
        return
    mdl = set(x for x in P.s.get_model() if x > 0)
    sh = lambda m: ''.join('ASB'[v] for v in m)
    sel = [(m, f) for (m, f), s in pool.items() if s in mdl]
    print('selected patterns:', ', '.join(f'{sh(m)}@{f}' for m, f in sel))
    # forced defences of T against X_G and the vertex refusals
    for j in range(3):
        for Gs in ([[gin[0]], [gin[1]], gin] if len(gin) == 2 else [gin]):
            X = list(T)
            for p in Gs: X[p] = V[j][p]
            r = cells.rec(list(T), X)
            print(f'  G = {[PIECES[p][0] + "_in" for p in Gs]}: T <=_w T[G->V{j+1}] at w = {P.acc(mdl, r)}')
    for kind, Gs, Es, w, Z in tg[:60]:
        doms = []
        for (m, f), s in pool.items():
            if s not in mdl: continue
            r = cells.rec(list(m), list(Z)); ri = int(cells.inv[r])
            if all(P.var(v, r) in mdl for v in range(3)) and not all(P.var(v, ri) in mdl for v in range(3)):
                doms.append(f'{sh(m)}@{f}')
        jv = int(kind[1]) - 1 if len(kind) > 1 else 0
        rv = cells.rec(list(V[jv]), list(Z))
        print(f'  {kind} G={[PIECES[p][0] for p in Gs]} E={[PIECES[p][0] for p in Es]} w={w+1}: '
              f'{sh(Z)}; V{jv+1} <= Z at {P.acc(mdl, rv)}; dominators {doms[:4]}')
    sys.stdout.flush()


if __name__ == '__main__':
    for a in sys.argv[2:]:
        if a.startswith('layout='):
            PIECES[:] = LAYOUTS[a.split('=')[1]]
    main(sys.argv[1], sys.argv[2:])
