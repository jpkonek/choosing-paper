"""PP33 geometry_exact.py -- exact rational checks (CHECKED) for PP33.

Run: python3 -I -B geometry_exact.py   (writes geometry_exact.out)

Checks:
 (1) record table of rho_j(G) = (G, S -> V_j) under the first level of PP25's rule L
     (weights 2 on a world's own minority class, 1 elsewhere), per unit mass and class;
 (2) ray threshold: for lambda_j(s) = (1-s)e_j + s*u, D_{lambda_j(s)} gives j's answer iff s < s0_j(g);
 (3) every wedge W_j(x,y) = {x <= s0_j < y} meets M_1, M_2, M_3 and Sil(T) (explicit points);
 (4) cross-family overlap W_j(0,s*) ∩ W_k(0,s*) lies in M_l (l the third world), where
     both families' j/k answers are the majority answer A and non-answers are B;
 (5) pointwise shadow test (Lemma 6 of PP25) for forward links: on the overlap of far
     supports, the member of one link never equals the dominator of the other;
     forward-backward pairs DO have shadows (explicit point);
 (6) compensation: on every wedge, a forward dominator beats the member at both
     non-vertex worlds (explicit points), and never at the vertex world.
Exact Fractions throughout; random rational sampling with a fixed seed.
"""
from fractions import Fraction as F
import random, itertools, sys

random.seed(33)
EPS = F(3, 10); C = (1 - EPS) / 3
U = (F(1, 3),) * 3
SSTAR = F(1, 5)
out = []
fails = 0

def log(s):
    out.append(s)

def check(cond, msg):
    global fails
    if not cond:
        fails += 1
        log("FAIL: " + msg)

def dot(a, b):
    return sum(x * y for x, y in zip(a, b))

def sgn(x):
    return (x > 0) - (x < 0)

def silent_T(g):
    S = sum(g)
    return C * S + EPS * min(g) < 0 < C * S + EPS * max(g)

def cls(g):
    s = [sgn(x) for x in g]
    if 0 in s:
        return None
    for k in range(3):
        if s[k] != s[(k + 1) % 3] and s[(k + 1) % 3] == s[(k + 2) % 3]:
            return k
    return 'U'

def lam(j, s):
    e = [F(0)] * 3; e[j] = F(1)
    return tuple((1 - s) * e[i] + s * U[i] for i in range(3))

def s0(j, g):
    S = sum(g)
    if g[j] * S < 0:
        return g[j] / (g[j] - S / 3)
    return None  # never switches for s in [0,1)

def ray_answer(j, s, g):
    """sign of the answer of D_{lambda_j(s)} at g."""
    return sgn(dot(lam(j, s), g))

def rank(w, g, ans):
    """rank at world w of answer with sign ans (0 = silence)."""
    if ans == 0:
        return 1
    return 0 if ans == sgn(g[w]) else 2

def rnd():
    return F(random.randint(-60, 60), random.randint(1, 20))

# (1) record table under L's first level (per unit mass)
log("(1) rho_j(G): first-level L values per unit mass, by class of the piece")
def rho(w, k):
    return 2 if w == k else 1
for j in range(3):
    rows = []
    for k in range(3):  # class of the piece
        # V_j answer on M_k: B (minority) if k == j else A (majority)
        vals = []
        for w in range(3):
            # rank change silence -> V_j's answer at world w
            if k == j:
                new = 0 if w == j else 2      # B correct only at minority world j
            else:
                new = 0 if w != k else 2      # A wrong only at minority world k
            vals.append(rho(w, k) * (new - 1))
        rows.append(vals)
        log(f"  j={j+1} piece in M_{k+1}: values at worlds 1,2,3 = {vals}")
    # sum of the two non-j values over any piece is positive; j-value negative
    for k in range(3):
        a, b = [w for w in range(3) if w != j]
        check(rows[k][a] + rows[k][b] > 0, f"nonj sum j={j} k={k}")
        check(rows[k][j] < 0, f"j value j={j} k={k}")
        check(sum(rows[k]) == 0, f"balance j={j} k={k}")

# (2) ray thresholds
n2 = 0
for _ in range(4000):
    g = (rnd(), rnd(), rnd())
    if 0 in g or sum(g) == 0:
        continue
    j = random.randrange(3)
    s = F(random.randint(1, 999), 1000)
    t = s0(j, g)
    ans = ray_answer(j, s, g)
    if ans == 0:
        continue
    jans = (ans == sgn(g[j]))
    expect = (t is None) or (s < t)
    check(jans == expect, f"threshold g={g} j={j} s={s}")
    n2 += 1
log(f"(2) ray threshold rule verified on {n2} random rational (g, j, s)")

# (3) wedge class coverage with explicit points
def perm_to(j, g1):
    """place a vector built for j=0 (coordinates (gj, ga, gb)) at family j."""
    g = [None] * 3
    others = [w for w in range(3) if w != j]
    g[j] = g1[0]; g[others[0]] = g1[1]; g[others[1]] = g1[2]
    return tuple(g)

n3 = 0
for _ in range(300):
    x = F(random.randint(0, 960), 1000); y = x + F(random.randint(1, 30), 1000)
    t = (x + y) / 2
    for j in range(3):
        a, b = [w for w in range(3) if w != j]
        # M_j point: (-alpha, 1, 1), s0 = 3alpha/(2alpha+2)
        al = 2 * t / (3 - 2 * t)
        pts = {'Mj': perm_to(j, (-al, F(1), F(1)))}
        # M_a point: (-alpha, 1, -beta)  [minority at the second slot]
        beta = F(1, 100)
        al = t * (1 - beta) / (3 - 2 * t)
        pts['Ma'] = perm_to(j, (-al, F(1), -beta))
        pts['Mb'] = perm_to(j, (-al, -beta, F(1)))
        # Sil(T) point: (-alpha, -2, 3): Sigma = 1 - alpha, s0 = 3alpha/(2alpha+1)
        al = t / (3 - 2 * t)
        pts['Sil'] = perm_to(j, (-al, F(-2), F(3)))
        for name, g in pts.items():
            st = s0(j, g)
            check(st is not None and x <= st < y, f"wedge point {name} j={j} t={t}")
            if name == 'Mj': check(cls(g) == j, "class Mj")
            if name == 'Ma': check(cls(g) == a, "class Ma")
            if name == 'Mb': check(cls(g) == b, "class Mb")
            if name == 'Sil': check(silent_T(g), f"Sil point {g}")
            n3 += 1
log(f"(3) {n3} explicit wedge points: every wedge W_j(x,y) (0<=x<y<=0.99) meets M_j, M_a, M_b and Sil(T)")

# (4) cross-family overlap
n4 = 0; seen = 0
for _ in range(20000):
    g = (rnd(), rnd(), rnd())
    if 0 in g:
        continue
    for j, k in [(0, 1), (0, 2), (1, 2)]:
        tj, tk = s0(j, g), s0(k, g)
        if tj is None or tk is None or not (tj < SSTAR and tk < SSTAR):
            continue
        l = 3 - j - k
        seen += 1
        check(cls(g) == l, f"overlap class g={g}")
        # j's answer and k's answer are the majority answer A on M_l
        check(sgn(g[j]) == sgn(g[k]) and sgn(g[l]) != sgn(g[j]), "overlap answers")
    n4 += 1
log(f"(4) overlap W_j ∩ W_k (s* = 1/5): {seen} hits among random problems; all in M_l with j-ans = k-ans = A")
# force hits near (-d,-d,1)
for _ in range(500):
    d = F(random.randint(1, 50), 1000); e = F(random.randint(-20, 20), 1000)
    g = (-d, -d - e * d, F(1))
    for (j, k) in [(0, 1)]:
        tj, tk = s0(j, g), s0(k, g)
        if tj is not None and tk is not None and tj < SSTAR and tk < SSTAR:
            check(cls(g) == 2, "forced overlap class")
            seen += 1
log(f"    plus forced points near (-d,-d,1): total overlap points checked {seen}")

# (5) shadows. A G link (member N=D_j(m), dominator C=D_j(d)) has far support W_j(min,max)
# and far advice old C -> new N. Shadow between consecutive links 1,2: N_1 = C_2 on S_1 ∩ S_2.
S0 = {}
def s0c(fam, g):
    k = (fam, g)
    if k not in S0:
        S0[k] = s0(fam, g)
    return S0[k]

def far_ans(fam, idx, g):
    # idx = 0: V_fam; else ray model; by (2) j's answer iff idx < s0
    t = s0c(fam, g)
    ja = sgn(g[fam])
    return ja if (idx == 0 or t is None or idx < t) else -ja

def in_support(fam, m, d, g):
    t = s0c(fam, g)
    lo, hi = min(m, d), max(m, d)
    # open wedge: threshold planes are null sets (there the ray model is silent)
    return t is not None and lo < t < hi

grid = [F(0), F(1, 50), F(1, 25), F(3, 50), F(2, 25), F(1, 10), F(3, 25), F(4, 25), F(1, 5)]
fwd = [(f, m, d) for f in range(3) for m in grid for d in grid if d > m]
bwd = [(f, m, d) for f in range(3) for m in grid for d in grid if d < m]
samples = []
for _ in range(3000):
    g = (rnd(), rnd(), rnd())
    if 0 in g or sum(g) == 0:
        continue
    samples.append(g)
# add points concentrated in wedges
for _ in range(6000):
    j = random.randrange(3); t = F(random.randint(0, 199), 1000)
    al = t / (3 - 2 * t)
    base = [(-al, F(-2), F(3)), (-2 * t / (3 - 2 * t), F(1), F(1)),
            (-al, F(1), F(-1, 100)), (-al, F(-1, 100), F(1)), (-al, F(3), F(-2))]
    samples.append(perm_to(j, random.choice(base)))
for _ in range(1500):
    d = F(random.randint(1, 40), 1000); e = F(random.randint(1, 40), 1000)
    pr = list(itertools.permutations([-d, -e, F(1)]))
    samples.append(tuple(random.choice(pr)))

def shadow_count(L1, L2):
    cnt = 0
    (f1, m1, d1), (f2, m2, d2) = L1, L2
    for g in samples:
        if in_support(f1, m1, d1, g) and in_support(f2, m2, d2, g):
            if far_ans(f1, m1, g) == far_ans(f2, d2, g):
                cnt += 1
    return cnt

pairs_ff = 0; sh_ff = 0
samples = [g for g in samples if any(s0c(f, g) is not None and s0c(f, g) < SSTAR for f in range(3))]
links_f = random.sample(fwd, 30)
for L1 in links_f:
    for L2 in links_f:
        pairs_ff += 1
        c = shadow_count(L1, L2)
        sh_ff += c
check(sh_ff == 0, f"forward-forward shadows found: {sh_ff}")
log(f"(5) forward-forward link pairs tested: {pairs_ff}, sample points {len(samples)}, shadow points: {sh_ff}")
# forward-backward shadow exists (same family)
L1 = (0, F(1, 25), F(2, 25)); L2 = (0, F(4, 25), F(0))
c = shadow_count(L1, L2)
check(c > 0, "expected a forward-backward shadow")
log(f"    forward (m=1/25->d=2/25) vs backward (m=4/25 -> V_1): shadow points {c} (expected > 0)")
L2x = (1, F(4, 25), F(0))
c2 = shadow_count(L1, L2x)
log(f"    forward family 1 vs backward family 2 (to V_2): shadow points {c2}")

# (6) compensation of forward dominators at non-vertex worlds, none at vertex world
n6 = 0
for (f, m, d) in random.sample(fwd, 40):
    a, b = [w for w in range(3) if w != f]
    better = {w: 0 for w in range(3)}; worse = {w: 0 for w in range(3)}
    for g in samples:
        if not in_support(f, m, d, g):
            continue
        Cn = far_ans(f, d, g); Nn = far_ans(f, m, g)
        if Cn == Nn:
            continue
        for w in range(3):
            rc, rn = rank(w, g, Cn), rank(w, g, Nn)
            better[w] += rc < rn; worse[w] += rc > rn
    check(better[a] > 0 and better[b] > 0, f"compensation missing {(f,m,d)}")
    check(better[f] == 0, f"unexpected compensation at vertex world {(f,m,d)}")
    n6 += 1
# (7) cross-family old-side exclusion: W_j(x,y) ∩ M_l contains points with s0_k > X for X up to 0.99
n7 = 0
for _ in range(300):
    x = F(random.randint(0, 960), 1000); y = x + F(random.randint(1, 30), 1000); t = (x + y) / 2
    X = F(99, 100)
    for j in range(3):
        for k in range(3):
            if k == j: continue
            l = 3 - j - k
            # g_j = -a, g_k = -K (K large), g_l = a + K + Sig, Sig > 0 small: class M_l
            K = F(1000); Sig = F(1)
            a = t * Sig / (3 * (1 - t))   # s0_j = a/(a + Sig/3) = t
            g = [None] * 3; g[j] = -a; g[k] = -K; g[l] = a + K + Sig
            g = tuple(g)
            check(cls(g) == l and x <= s0(j, g) < y and s0(k, g) > X, f"(7) j={j} k={k} t={t}")
            n7 += 1
log(f"(7) {n7} explicit points: every wedge W_j(x,y) ∩ M_l contains problems with s0_k > 0.99 (other families give A there)")
log(f"(6) {n6} forward links: dominator beats member on the wedge at both non-vertex worlds, never at the vertex world")

log("ALL PASS" if fails == 0 else f"FAILURES: {fails}")
with open("geometry_exact.out", "w") as fh:
    fh.write("\n".join(out) + "\n")
print("\n".join(out))
