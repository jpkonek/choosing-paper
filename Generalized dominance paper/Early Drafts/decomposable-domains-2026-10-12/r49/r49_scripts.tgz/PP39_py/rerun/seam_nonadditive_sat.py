"""PP34 check S1 (CHECKED on cells): PP32's seam configuration WITHOUT endorsement.

Pieces lie in T1's silence (T = S on every piece).  Hypothesis H_A: on each edge {i,j} some
selected model says A (majority) on every piece.  On cells all three edge models then coincide
with the model N_A = (A, ..., A), which must therefore be competitive on {1,2}, {1,3} and {2,3}:
every rival of N_A is accepted at two worlds at least.  T is competitive at all three worlds.
Both are undominated.  Strict (G), (IB) and full (TC) (P1/P2) at every world.

Question: is this satisfiable?  PP32 Theorem 3.1 says no single positive field endorses it;
UNSAT here would be a non-additive version.  Variants add the vertex retreat obligations.
Usage: python3 -B seam_nonadditive_sat.py
"""
import sys, time
from lib34 import Cells, Problem, A, S, B, VN

CONFIGS = [
    ('one piece per class', [0, 1, 2]),
    ('M_1 doubled', [0, 0, 1, 2]),
    ('two in M_1, two in M_2', [0, 0, 1, 1]),
    ('M_1, M_2 doubled + M_3', [0, 0, 1, 1, 2]),
    ('M_1 tripled + M_2 + M_3', [0, 0, 0, 1, 2]),
]


def run(name, classes, extra=None):
    t0 = time.time()
    c = Cells(classes)
    P = Problem(c)
    P.base()
    n = c.n
    T = [S] * n
    NA = [A] * n
    P.competitive(T, (0, 1, 2)); P.undominated(T)
    for e in ((0, 1), (0, 2), (1, 2)):
        P.competitive(NA, e)
    P.undominated(NA)
    if extra:
        extra(c, P)
    ok = P.solve()
    print(f'[{name}] classes {[k+1 for k in classes]}: records {c.N}, P1 {P.np1}, P2 {P.np2}, '
          f'clauses {P.ncl}: {"SAT" if ok else "UNSAT"} ({time.time()-t0:.1f}s)')
    if ok:
        mdl = set(x for x in P.s.get_model() if x > 0)
        # report T's departures S->A on the full piece set and N_A's retreats
        for H in range(1, 2 ** n):
            sub = [p for p in range(n) if H >> p & 1]
            new = [A if p in sub else S for p in range(n)]
            r = c.rec(T, new)
            q = c.rec(NA, [S if p in sub else A for p in range(n)])
            if len(sub) == n or len(sub) <= 2:
                print(f'     H={[p+1 for p in sub]}  T: S->A accepted at {P.acc(mdl, r)};'
                      f'  N_A: A->S accepted at {P.acc(mdl, q)}')
    sys.stdout.flush()
    return ok


if __name__ == '__main__':
    allok = True
    for name, cl in CONFIGS:
        run(name, cl)
    print('done')
