"""PP36 family: the forced-defence family of PP30 Theorem 3.1 on the cells of cells36.

For a model N answering on a bounded G inside T's silence (N = V_j to start):
  X = T[G -> N]       T must defend against X at some world w      (cmp T R_w X)
  R = N[G -> S]       (IB) copy: rec(T, X) = rec(R, N), so R R_w N is the same record
  Z = R[E -> w-correct], E subset of G       needs a coherent dominator D_K (dom)
The record rec(T, X) = (G, S -> N|G) is the only thing a w-rule may look at.
Its *pattern* is the set of (class, A/B) pairs that N's answers on G show.
"""
import itertools
from fractions import Fraction as Fr
from cells36 import Space36, standard

def vertex_models(S):
    return [S.model([tuple(Fr(int(i == j)) for i in range(3))]) for j in range(3)]

def wcorrect(S, k, w):
    return 0 if S.g[k][w] > 0 else 1

def fill(X, cells, vals):
    X = list(X)
    for k, v in zip(cells, vals): X[k] = v
    return tuple(X)

def pattern(S, N, G):
    """frozenset of (class, 'A'/'B') shown by N on G (cells)."""
    return frozenset((S.minworld[k], S.ab(k, N[k])) for k in G)

def pure_improvement_worlds(pat):
    """worlds at which the record (G, S -> answers) is a pure improvement."""
    out = []
    for w in range(3):
        if all((a == 'A' and w != k) or (a == 'B' and w == k) for k, a in pat): out.append(w)
    return out

def allowed_worlds(pat):
    bad = pure_improvement_worlds(pat)
    return [w for w in range(3) if w not in bad]

def guidance_worlds(pat):
    """worlds at which the record is a pure worsening (T's defence is guidance)."""
    return [w for w in range(3) if all((a == 'A' and w == k) or (a == 'B' and w != k) for k, a in pat)]

def pstr(pat):
    return '{' + ','.join(f'{k+1}{a}' for k, a in sorted(pat)) + '}'

class Instance:
    __slots__ = ('j', 'N', 'G', 'E', 'w', 'X', 'R', 'Z', 'pat', 'name', 'Nname')
    def __repr__(self): return self.name

def make(S, N, G, E, w, j=None, Nname=None):
    I = Instance()
    I.j, I.N, I.G, I.E, I.w = j, N, tuple(sorted(G)), tuple(sorted(E)), w
    I.Nname = Nname or (f'V{j+1}' if j is not None else '?')
    I.X = fill(S.T, I.G, [N[k] for k in I.G])
    I.R = fill(N, I.G, [2] * len(I.G))
    I.Z = fill(I.R, I.E, [wcorrect(S, k, w) for k in I.E])
    I.pat = pattern(S, N, I.G)
    I.name = f'{I.Nname}:G={"+".join(S.names[k] for k in I.G)}:E={"+".join(S.names[k] for k in I.E)}:w{w+1}'
    return I

def silent_bounded(S, N=None):
    N = S.T if N is None else N
    return [k for k in range(S.n) if S.bounded[k] and N[k] == 2 and S.minworld[k] is not None]

def G_family(S, kinds=('single', 'samedir', 'crosspair', 'classpair', 'triple'), base=None, piece0=True):
    """bounded G inside T's silence (or inside 'base' cells)."""
    sil = silent_bounded(S) if base is None else list(base)
    p0 = [k for k in sil if S.piece[k] == '0'] if piece0 else sil
    out = []
    if 'single' in kinds:
        out += [(k,) for k in p0]
    if 'samedir' in kinds:
        for d in range(S.nd):
            cs = [k for k in sil if S.dir_of[k] == d]
            if len(cs) == 2: out.append(tuple(cs))
    if 'crosspair' in kinds:
        for a, b in itertools.combinations(p0, 2):
            if S.minworld[a] != S.minworld[b]: out.append((a, b))
    if 'classpair' in kinds:
        for a, b in itertools.combinations(p0, 2):
            if S.minworld[a] == S.minworld[b] and S.dir_of[a] != S.dir_of[b]: out.append((a, b))
    if 'triple' in kinds:
        bycl = [[k for k in p0 if S.minworld[k] == c] for c in range(3)]
        out += [tuple(t) for t in itertools.product(*bycl)]
    return out

def E_family(G):
    out = [(k,) for k in G]
    if len(G) > 1: out.append(tuple(G))
    return out
