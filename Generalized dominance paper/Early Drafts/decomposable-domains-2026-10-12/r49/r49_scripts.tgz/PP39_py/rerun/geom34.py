"""PP34 geometry for cells: directions in R^3 oriented so the majority sign is positive;
T1's advice; realisability of a value pattern by a coherent D_K with K inside a face (LP).
Values: 0 = A (accept the majority-positive orientation), 1 = S, 2 = B."""
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import linprog

A, S, B = 0, 1, 2
EPS = Fr(3, 10)
FACES = {'int': (0, 1, 2), 'e12': (0, 1), 'e13': (0, 2), 'e23': (1, 2),
         'v1': (0,), 'v2': (1,), 'v3': (2,)}


def orient(g):
    g = [Fr(x).limit_denominator(10 ** 6) for x in g]
    pos = sum(1 for x in g if x > 0)
    return g if pos >= 2 else [-x for x in g]


def klass(g):
    """minority world (0-based) of a mixed direction (oriented majority-positive)"""
    neg = [i for i in range(3) if g[i] < 0]
    assert len(neg) == 1, g
    return neg[0]


def advice(Kpts, g):
    """advice of D_K for K = conv(Kpts) (exact)"""
    vals = [sum(m[i] * g[i] for i in range(3)) for m in Kpts]
    if min(vals) > 0: return A
    if max(vals) < 0: return B
    return S


def t1(g):
    c = (1 - EPS) / 3
    pts = [[c + (EPS if i == j else 0) for i in range(3)] for j in range(3)]
    return advice(pts, g)


def realisable(pattern, dirs, face, eps=1e-7):
    """pattern: list of values per direction (None = unconstrained)."""
    sup = FACES[face]
    A_ub, b_ub = [], []
    for g, v in zip(dirs, pattern):
        gg = np.array([float(x) for x in g])
        if v == A:
            A_ub.append(-gg); b_ub.append(-eps)
        elif v == B:
            A_ub.append(gg); b_ub.append(-eps)
    bounds = [(0, None) if j in sup else (0, 0) for j in range(3)]
    Ss = [np.array([float(x) for x in g]) for g, v in zip(dirs, pattern) if v == S] or [None]
    for s in Ss:
        A_eq = [np.ones(3)]; b_eq = [1.0]
        if s is not None:
            A_eq.append(s); b_eq.append(0.0)
        res = linprog(np.zeros(3), A_ub=np.array(A_ub) if A_ub else None,
                      b_ub=np.array(b_ub) if b_ub else None,
                      A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=bounds, method='highs')
        if res.status != 0:
            return False
    return True
