"""PP34 check S3 (CHECKED on cells): the largest-loss world rule for T's departures.

Rule alpha: a departure d = (H, S -> a) out of T's silence (any regular answers a) is accepted at
the world w maximising the loss mass  l_w(d) = nu(H and {a is w-wrong}); ties broken by a fixed
priority.  This is the w-rule of PP34 Section 5.  We impose it (in two strengths) on top of
full (TC) (P1/P2), strict (G), (IB), with
  - T competitive at all worlds and undominated (rivals: ALL cell models);
  - H_A: on every edge a selected model says A on every piece (cells: N_A competitive on each
    edge pair, undominated);
  - the vertex models (trivially competitive).
Strengths:  'exact'  = accepted at alpha(d) and refused at every other world where it is mixed
                       (a pure worsening at w is accepted at w by guidance and cannot be refused);
            'atleast'= accepted at alpha(d), other worlds free.
Every piece lies in T1's silence.  Masses nu are integers per piece.
Usage: python3 -B argmax_sat.py
"""
import sys, time, itertools
from lib34 import Cells, Problem, A, S, B, rank

CONFIGS = [
    ('M1 M2 M3, unit masses', [0, 1, 2], [1, 1, 1]),
    ('M1 M1 M2 M3', [0, 0, 1, 2], [1, 2, 2, 2]),
    ('M1 M1 M2 M2', [0, 0, 1, 1], [1, 2, 1, 2]),
    ('M1 M1 M2 M2 M3', [0, 0, 1, 1, 2], [1, 2, 1, 2, 2]),
    ('M1 M1 M2 M2 M3 (other masses)', [0, 0, 1, 1, 2], [2, 3, 3, 2, 4]),
    ('M1 M2 M2 M3 M3', [0, 1, 1, 2, 2], [3, 1, 2, 1, 2]),
]
PRIORITY = (0, 1, 2)    # tie-break: world 1 first, then 2, then 3


def alpha(cls, mass, newvals):
    loss = [0, 0, 0]
    for p, v in enumerate(newvals):
        if v is None:
            continue
        for w in range(3):
            if rank(w, cls[p], v) == 2:          # wrong at w
                loss[w] += mass[p]
    best = max(loss)
    for w in PRIORITY:
        if loss[w] == best:
            return w, loss
    raise AssertionError


def run(name, cls, mass, strength):
    t0 = time.time()
    c = Cells(cls)
    P = Problem(c)
    P.base()
    n = c.n
    T = [S] * n
    NA = [A] * n
    P.competitive(T, (0, 1, 2)); P.undominated(T)
    for e in ((0, 1), (0, 2), (1, 2)):
        P.competitive(NA, e)
    P.undominated(NA)
    ndep = 0
    for vals in itertools.product((None, A, B), repeat=n):
        if all(v is None for v in vals):
            continue
        new = [S if v is None else v for v in vals]
        r = c.rec(T, new)
        w0, loss = alpha(cls, mass, vals)
        P.add([P.var(w0, r)])
        if strength == 'exact':
            for w in range(3):
                if w != w0 and c.kind[w, r] == 3:      # mixed at w (pure worsenings are guidance)
                    P.add([-P.var(w, r)])
        ndep += 1
    ok = P.solve()
    print(f'[{name}] classes {[k+1 for k in cls]} masses {mass} rule={strength}: '
          f'{ndep} departures, clauses {P.ncl}: {"SAT" if ok else "UNSAT"} ({time.time()-t0:.0f}s)')
    sys.stdout.flush()
    return ok


if __name__ == '__main__':
    for name, cls, mass in CONFIGS:
        for strength in ('exact', 'atleast'):
            run(name, cls, mass, strength)
    print('done')
