"""PP36 cells: a radially split, exact cell model for the forced-defence family.

Directions (exact rational gambles; T = D_M, M = c*1 + eps*Delta, eps = 3/10):
  per class k (minority world k), obtained from the class-1 template by permuting
  coordinates so that coordinate k carries the negative entry:
    Gp_k   (-6/5, 1, 1)        T silent, uniform says majority   (axis)
    Gm_k   (-3, 1, 1)          T silent, uniform says minority   (axis)
    Kp_k   (-17, 3, 23)        T silent, steep (PP30 kill line through e_j side)
    Kq_k   (-17, 23, 3)        T silent, steep (mirror)
    F_k    (-9, 9, 1)          T silent, PP28's steep padding line l_F, cyclic image
    J_k    (-1/2, 1, 1)        T answers majority
    W_k    g_k = 5, others -1  T answers minority  (class k)
    U      (1, 2, 3)           unanimous
Radial splitting.  Every mixed direction d is split into three radial pieces
d.0, d.1 (bounded) and d.i (the unbounded outer piece).  A bounded set G is a
union of pieces among the .0/.1 pieces.  Coherent models are cone-structured:
they take the same advice on all pieces of a direction (Lemma H on cells).
Coherence of the direction vector is decided exactly (PP21 polygon clipping /
meet-closure catalogue).
Advice codes (PP21): 0 = P accept g, 1 = N accept -g, 2 = S, 3 = X.
"""
import os, sys, pickle, hashlib, itertools
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'PP21_py'))
from cells import (advice_of, T_VERTS, coherent_catalogue, is_coherent as clip_coherent,
                   lin, val, clip, area2, TRI)

EPS = Fr(3, 10)
C0 = (1 - EPS) / 3
ADV = 'PNSX'

def perm_to_class(tpl, k):
    """class-1 template (neg at coord 0) -> class k (neg at coord k); the two
    positive coords keep cyclic order."""
    a, b, c = tpl
    out = [None] * 3
    out[k] = a; out[(k + 1) % 3] = b; out[(k + 2) % 3] = c
    return tuple(out)

TEMPL = [('Gp', (Fr(-6, 5), Fr(1), Fr(1))), ('Gm', (Fr(-3), Fr(1), Fr(1))),
         ('Kp', (Fr(-17), Fr(3), Fr(23))), ('Kq', (Fr(-17), Fr(23), Fr(3))),
         ('F', (Fr(-9), Fr(9), Fr(1))), ('J', (Fr(-1, 2), Fr(1), Fr(1)))]

def directions(templ=TEMPL, with_W=True):
    D = []
    for nm, t in templ:
        for k in range(3):
            D.append((f'{nm}{k+1}', perm_to_class(t, k)))
    if with_W:
        for k in range(3):
            D.append((f'W{k+1}', tuple(Fr(5) if t == k else Fr(-1) for t in range(3))))
    D.append(('U', (Fr(1), Fr(2), Fr(3))))
    return D

PIECES = ('0', '1', 'i')      # '0','1' bounded radial pieces, 'i' unbounded

class Space36:
    def __init__(self, dirs=None, pieces=PIECES, split_answered=True):
        dirs = directions() if dirs is None else dirs
        self.dirs = dirs
        self.dname = [n for n, _ in dirs]
        self.dg = [g for _, g in dirs]
        self.nd = len(dirs)
        Tdir = tuple(advice_of(T_VERTS, g) for g in self.dg)
        self.Tdir = Tdir
        cells = []
        for d, (nm, g) in enumerate(dirs):
            mixed = len({x > 0 for x in g}) == 2
            if mixed and (Tdir[d] == 2 or split_answered):
                for p in pieces:
                    cells.append((f'{nm}.{p}', g, d, p))
            else:
                cells.append((nm, g, d, None))
        self.cells = cells
        self.names = [c[0] for c in cells]
        self.g = [c[1] for c in cells]
        self.dir_of = [c[2] for c in cells]
        self.piece = [c[3] for c in cells]
        self.n = len(cells)
        self.idx = {n: k for k, n in enumerate(self.names)}
        self.cells_of_dir = [[k for k in range(self.n) if self.dir_of[k] == d] for d in range(self.nd)]
        self.bounded = [self.piece[k] in ('0', '1') for k in range(self.n)]
        self.rank = []
        for w in range(3):
            self.rank.append([(0 if g[w] > 0 else 2, 2 if g[w] > 0 else 0, 1, 3) for g in self.g])
        # class data: minority world, majority answer code
        self.maj, self.mino, self.minworld, self.dmin = [], [], [], []
        for g in self.g:
            pos = [w for w in range(3) if g[w] > 0]
            if len(pos) == 3: self.maj.append(0); self.mino.append(None); self.minworld.append(None)
            elif len(pos) == 0: self.maj.append(1); self.mino.append(None); self.minworld.append(None)
            elif len(pos) == 2:
                self.maj.append(0); self.mino.append(1); self.minworld.append([w for w in range(3) if g[w] < 0][0])
            else:
                self.maj.append(1); self.mino.append(0); self.minworld.append(pos[0])
        self.T = self.lift(Tdir)
        self._cat = None
        self._catset = None

    # ------------------------------------------------------------ models
    def lift(self, dv):
        return tuple(dv[self.dir_of[k]] for k in range(self.n))

    def dirvec(self, X):
        """direction vector if X is cone-structured, else None"""
        out = []
        for d in range(self.nd):
            vs = {X[k] for k in self.cells_of_dir[d]}
            if len(vs) != 1: return None
            out.append(vs.pop())
        return tuple(out)

    def model(self, K):
        return self.lift(tuple(advice_of(K, g) for g in self.dg))

    def show(self, X):
        out = []
        for d in range(self.nd):
            out.append(''.join(ADV[X[k]] for k in self.cells_of_dir[d]))
        return '|'.join(out)

    def ab(self, k, v):
        """'A' (majority), 'B' (minority), 'S', 'X' for advice v at cell k"""
        if v == 2: return 'S'
        if v == 3: return 'X'
        if self.minworld[k] is None: return 'U'
        return 'A' if v == self.maj[k] else 'B'

    # --------------------------------------------------------- coherence
    def catalogue_dirs(self):
        if self._cat is None:
            key = hashlib.sha1(repr(self.dg).encode()).hexdigest()[:16]
            fn = os.path.join(HERE, f'cat36_{key}.pkl')
            if os.path.exists(fn):
                with open(fn, 'rb') as f: self._cat = pickle.load(f)
            else:
                self._cat = sorted(coherent_catalogue(self.dg))
                with open(fn, 'wb') as f: pickle.dump(self._cat, f)
            self._catset = set(self._cat)
        return self._cat

    def is_coherent(self, X):
        if any(v == 3 for v in X): return False
        dv = self.dirvec(X)
        if dv is None: return False
        self.catalogue_dirs()
        return dv in self._catset

    def is_coherent_clip(self, X):
        """independent test (polygon clipping), cone structure checked separately"""
        dv = self.dirvec(X)
        return dv is not None and clip_coherent(dv, self.dg)

    def coherent_models(self):
        return [self.lift(dv) for dv in self.catalogue_dirs()]

    # ------------------------------------------------- credal geometry
    def feasible_region(self, dv):
        """polygon (in (m1,m2) coordinates) of points m satisfying the strict
        accept/reject constraints of dv; K realising dv lies inside it."""
        poly = list(TRI)
        for v, g in zip(dv, self.dg):
            if v == 0: poly = clip(poly, lin(g), 1)
            elif v == 1: poly = clip(poly, lin(g), -1)
        return poly

    def classify(self, X):
        """relation of a coherent model's pattern to T's (cells only)."""
        dv = self.dirvec(X)
        T = self.Tdir
        mixed = [d for d in range(self.nd) if self.dg[d] and len({x > 0 for x in self.dg[d]}) == 2]
        opp = any(T[d] in (0, 1) and dv[d] in (0, 1) and dv[d] != T[d] for d in mixed)
        loses = any(T[d] in (0, 1) and dv[d] == 2 for d in mixed)      # silent where T answers
        gains = any(T[d] == 2 and dv[d] in (0, 1) for d in mixed)      # answers where T silent
        precise = all(dv[d] != 2 for d in mixed)
        if dv == T: kind = 'T'
        elif opp: kind = 'separated'
        elif loses and gains: kind = 'crossing'
        elif loses: kind = 'coarsening'
        elif gains: kind = 'tightening'
        else: kind = 'T'
        return kind + ('/precise' if precise else '')


def standard():
    return Space36()

if __name__ == '__main__':
    import time
    S = standard()
    print('directions:', S.nd, ' cells:', S.n)
    for d in range(S.nd):
        g = S.dg[d]
        k0 = S.cells_of_dir[d][0]
        mw = S.minworld[k0]
        print(f'  {S.dname[d]:4} g={tuple(str(x) for x in g)}  class={None if mw is None else mw+1}'
              f'  T={S.ab(k0, S.T[k0])}  pieces={len(S.cells_of_dir[d])}')
    t = time.time(); cat = S.catalogue_dirs(); print('coherent direction vectors:', len(cat), f'({time.time()-t:.1f}s)')
    import random
    rnd = random.Random(0); bad = 0
    for dv in rnd.sample(cat, 2000):
        if not clip_coherent(dv, S.dg): bad += 1
    print('catalogue sample (2000) failing clipping test:', bad)
    catset = set(cat); mism = 0; tested = 0
    for dv in rnd.sample(cat, 2000):
        y = list(dv); k = rnd.randrange(S.nd); y[k] = rnd.randrange(3); y = tuple(y)
        tested += 1
        if clip_coherent(y, S.dg) != (y in catset): mism += 1
    print(f'one-direction mutations: {tested}, mismatches catalogue vs clipping: {mism}')
    # vertex models and T
    from collections import Counter
    V = [S.model([tuple(Fr(int(i == j)) for i in range(3))]) for j in range(3)]
    print('T  =', S.show(S.T))
    for j in range(3): print(f'V{j+1} =', S.show(V[j]))
    print('kinds in catalogue:', Counter(S.classify(S.lift(dv)) for dv in cat))


def wedge_directions(delta=Fr(1, 10)):
    """directions of Sil(T) close to the planes e_j^perp but away from u^perp:
    g_j = -delta, the other two coordinates (1, -1/2) and (-1/2, 1).  On them,
    precise models D_lam with lam off e_j (e.g. on the median from e_j with
    lam_j < 5/7) disagree with V_j; the base cells cannot see this."""
    out = []
    for j in range(3):
        o = [t for t in range(3) if t != j]
        for s in (0, 1):
            g = [Fr(0)] * 3; g[j] = -delta
            g[o[s]] = Fr(1); g[o[1 - s]] = Fr(-1, 2)
            out.append((f'Y{j+1}{"ab"[s]}', tuple(g)))
    return out

def refined(delta=Fr(1, 10)):
    D = directions()
    return Space36(D[:-1] + wedge_directions(delta) + D[-1:])
