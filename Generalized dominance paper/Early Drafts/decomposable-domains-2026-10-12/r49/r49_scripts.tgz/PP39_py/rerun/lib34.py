"""PP34 library: exact cell record algebra with full (TC) via PP23 Lemma 1.1 (P1/P2), vectorised.

Values on a piece of class M_k (k = minority world): 0 = A (majority answer), 1 = S, 2 = B
(minority answer).  Contradiction X is omitted (it is the worst value at every world and never
helps a defence).  Rank at world w: B 0, S 1, A 2 if w == k; A 0, S 1, B 2 otherwise.

A record is a tuple of codes, one per piece: 0 = piece not in the support, 1..6 = (old, new).
Records are indexed in base 7.  kind[w, r]: 0 trivial, 1 weak worsening (W), 2 improvement (I),
3 mixed (M).  By PP23 Lemma 1.1, with weak guidance accepted, strict (G) and (TC) hold at w iff
(P1) no two accepted M-records compose to an I-record and (P2) every accepted triangle of
M-records has its reverses accepted.  Everything here is exact (integers).
"""
import itertools
import numpy as np
from pysat.solvers import Cadical153

A, S, B = 0, 1, 2
VN = 'ASB'
PAIRS = [(o, n) for o in range(3) for n in range(3) if o != n]      # codes 1..6
CODE = {p: i + 1 for i, p in enumerate(PAIRS)}


def rank(w, k, v):
    return (2 - v) if w == k else v


def comp_code(c1, c2):
    if c1 == 0:
        return c2
    if c2 == 0:
        return c1
    o1, n1 = PAIRS[c1 - 1]
    o2, n2 = PAIRS[c2 - 1]
    if n1 != o2:
        return None
    return 0 if o1 == n2 else CODE[(o1, n2)]


class Cells:
    def __init__(self, classes):
        self.cls = list(classes)
        self.n = n = len(classes)
        self.N = 7 ** n
        codes = np.array(list(itertools.product(range(7), repeat=n)), dtype=np.int8)  # big-endian
        self.codes = codes
        self.kind = np.zeros((3, self.N), dtype=np.int8)
        for w in range(3):
            pos = np.zeros(self.N, bool)
            neg = np.zeros(self.N, bool)
            for p in range(n):
                d = np.zeros(7, dtype=int)
                for c in range(1, 7):
                    o, nw = PAIRS[c - 1]
                    d[c] = rank(w, self.cls[p], nw) - rank(w, self.cls[p], o)
                dd = d[codes[:, p]]
                pos |= dd > 0
                neg |= dd < 0
            self.kind[w] = np.where(pos & neg, 3, np.where(pos, 1, np.where(neg, 2, 0)))
        invc = np.array([0] + [CODE[(nw, o)] for (o, nw) in PAIRS])
        self.inv = self.index(invc[codes])

    def index(self, codes):
        idx = np.zeros(codes.shape[0], dtype=np.int64)
        for p in range(self.n):
            idx = idx * 7 + codes[:, p]
        return idx

    def rec(self, old, new, support=None):
        """record from model `old` to model `new` (value vectors)"""
        c = []
        for p in range(self.n):
            if old[p] == new[p] or (support is not None and p not in support):
                c.append(0)
            else:
                c.append(CODE[(old[p], new[p])])
        return int(self.index(np.array([c])) [0])

    def show(self, r):
        cs = self.codes[r]
        return ' '.join('.' if c == 0 else VN[PAIRS[c - 1][0]] + '>' + VN[PAIRS[c - 1][1]] for c in cs)

    def records_from(self, model):
        """indices of all records whose old side equals `model` on the support (3^n of them)"""
        opts = [[0] + [CODE[(model[p], v)] for v in range(3) if v != model[p]] for p in range(self.n)]
        arr = np.array(list(itertools.product(*opts)), dtype=np.int8)
        return self.index(arr)

    def pair_arrays(self):
        """all composable pairs (r1, r2, r1.r2) as index arrays (25^n of them)"""
        opts = [(c1, c2, comp_code(c1, c2)) for c1 in range(7) for c2 in range(7)]
        opts = np.array([o for o in opts if o[2] is not None], dtype=np.int64)
        I1 = np.zeros(1, dtype=np.int64); I2 = I1.copy(); I3 = I1.copy()
        for p in range(self.n):
            I1 = (I1[:, None] * 7 + opts[None, :, 0]).ravel()
            I2 = (I2[:, None] * 7 + opts[None, :, 1]).ravel()
            I3 = (I3[:, None] * 7 + opts[None, :, 2]).ravel()
        return I1, I2, I3


class Problem:
    """SAT encoding: var(w, r) true iff record r is accepted at world w."""

    def __init__(self, cells, solver=Cadical153):
        self.c = cells
        self.s = solver()
        self.ncl = 0
        self.N = cells.N

    def var(self, w, r):
        return int(1 + w * self.N + r)

    def add(self, cl):
        self.s.add_clause([int(x) for x in cl])
        self.ncl += 1

    def base(self):
        """reflexivity, weak guidance, strict (G), (P1), (P2) at every world"""
        c = self.c
        for w in range(3):
            k = c.kind[w]
            for r in np.nonzero((k == 0) | (k == 1))[0]:
                self.add([self.var(w, r)])
            for r in np.nonzero(k == 2)[0]:
                self.add([-self.var(w, r)])
        I1, I2, I3 = c.pair_arrays()
        triv = 0
        self.np1 = self.np2 = 0
        for w in range(3):
            k = c.kind[w]
            m = (k[I1] == 3) & (k[I2] == 3) & (I3 != triv)
            a1, a2, a3 = I1[m], I2[m], I3[m]
            k3 = k[a3]
            p1 = k3 == 2
            for x, y in zip(a1[p1], a2[p1]):
                self.add([-self.var(w, x), -self.var(w, y)])
            self.np1 += int(p1.sum())
            p2 = k3 == 3
            b1, b2, b3 = a1[p2], a2[p2], a3[p2]
            b3i = c.inv[b3]
            for x, y, z, zi in zip(b1, b2, b3, b3i):
                base = [-self.var(w, x), -self.var(w, y), -self.var(w, zi)]
                self.add(base + [self.var(w, c.inv[x])])
                self.add(base + [self.var(w, c.inv[y])])
                self.add(base + [self.var(w, z)])
            self.np2 += int(p2.sum())

    def competitive(self, model, worlds, exclude_trivial=True):
        """model accepts every rival at some world of `worlds` (its index's support)"""
        for r in self.c.records_from(model):
            if r == 0:
                continue
            self.add([self.var(w, r) for w in worlds])

    def undominated(self, model):
        """no all-world weak dominator with a strict world: inv(r) at all worlds => r at all worlds"""
        for r in self.c.records_from(model):
            if r == 0:
                continue
            ri = int(self.c.inv[r])
            for w0 in range(3):
                self.add([-self.var(w, ri) for w in range(3)] + [self.var(w0, r)])

    def solve(self, assumptions=()):
        return self.s.solve(assumptions=[int(a) for a in assumptions])

    def acc(self, model_set, r):
        return ''.join(str(w + 1) for w in range(3) if self.var(w, r) in model_set) or '-'
