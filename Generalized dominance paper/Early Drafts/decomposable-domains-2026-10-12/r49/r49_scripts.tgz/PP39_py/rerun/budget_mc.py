"""PP33 budget_mc.py -- NUMERICS illustration of the joint rule of PP33 Section 4 for one vertex rival.

Run: python3 -I -B budget_mc.py   (writes budget_mc.out)

j = world 1. G = B+ ∪ B- (PP30's two balls for p = e_1, eps = 3/10), B+ around (0.15,-0.85,1.15) in M_2,
B- around (0.15,1.15,-0.85) in M_3. First level of PP25's rule L: weight 2 on a world's own minority class.
Shows: (a) rho_1(G) is accepted at worlds 2 and 3 (mixed record), refused at 1;
(b) for w = 2, E = B+, the vertex-world budget 3m of Z and the admissible ray parameters s' with
    L_1(D_{lambda_1(s')}) - L_1(V_1) < L_1(Z) - L_1(V_1) (Theorem 3.1 of PP33: forced endorsement at world 1);
(c) the first-level values of the installed domination record at worlds 1,2,3: positive at 1, sum 0
    (so negative at one of 2,3: not endorsed there), and compensation masses at worlds 2 and 3.
No proof depends on this script.
"""
import numpy as np
rng = np.random.default_rng(3333)
EPS = 0.3; C = (1 - EPS) / 3
N = 4_000_000
g = rng.standard_normal((N, 3))
S = g.sum(1)
sil = (C * S + EPS * g.min(1) < 0) & (C * S + EPS * g.max(1) > 0)
sg = np.sign(g)
# class: minority world index, -1 for unanimous
cls = np.full(N, -1)
for k in range(3):
    o = [w for w in range(3) if w != k]
    cls[(sg[:, k] != sg[:, o[0]]) & (sg[:, o[0]] == sg[:, o[1]])] = k
rho = np.where(cls[:, None] == np.arange(3)[None, :], 2.0, 1.0)   # rho[:, w]

def ball(c, r):
    c = np.array(c)
    return (np.linalg.norm(g - c, axis=1) < r) | (np.linalg.norm(g + c, axis=1) < r)
r = 0.12
Bp = ball((0.15, -0.85, 1.15), r); Bm = ball((0.15, 1.15, -0.85), r)
out = []
def log(s): out.append(s); print(s)
log(f"samples {N}; ball fractions {Bp.mean():.5f}, {Bm.mean():.5f}; in Sil(T): {sil[Bp].mean():.4f}, {sil[Bm].mean():.4f}; classes {set(cls[Bp])}, {set(cls[Bm])}")

def rank(ans, w):
    """ans: array of signs (0 = silent) per sample; rank at world w."""
    return np.where(ans == 0, 1, np.where(ans == sg[:, w], 0, 2))

def est(x):
    return x.mean(), x.std() / np.sqrt(N)

V1 = sg[:, 0].copy()
G = Bp | Bm
T_on_G = np.zeros(N)
# (a) record rho_1(G): S -> V_1 on G
log("(a) first-level L values of rho_1(G) = (G, S -> V_1):")
for w in range(3):
    m, se = est(np.where(G, rho[:, w] * (rank(V1, w) - 1), 0))
    log(f"    world {w+1}: {m:+.6f} (s.e. {se:.6f})")
# (b) Z for w = 2, E = B+ : Z = V_1[B- -> S, B+ -> 2-correct]
Z = V1.copy(); Z[Bm] = 0; Z[Bp] = sg[Bp, 1]
def L(model, w):
    return rho[:, w] * rank(model, w)
dZ, se = est(L(Z, 0) - L(V1, 0))
log(f"(b) L_1(Z) - L_1(V_1) = {dZ:.6f} (s.e. {se:.6f})  [vertex-world budget]")
s0 = np.full(N, np.inf)
opp = g[:, 0] * S < 0
s0[opp] = g[opp, 0] / (g[opp, 0] - S[opp] / 3)
def D(s):
    lam = np.array([(1 - s) + s / 3, s / 3, s / 3])
    return np.sign(g @ lam)
for s in [0.0005, 0.001, 0.0015, 0.003, 0.01]:
    Ds = D(s)
    cost, se2 = est(L(Ds, 0) - L(V1, 0))
    ok = cost + 3 * se2 < dZ - 3 * se
    log(f"    s'={s:.4f}: L_1(D(s')) - L_1(V_1) = {cost:.6f} (s.e. {se2:.6f}) -> endorsed at world 1: {ok}")
# (c) installed record for an admissible s'
s = 0.001
Ds = D(s)
log(f"(c) domination record rec(D(s'), Z), s' = {s}: first-level values L_w(Z) - L_w(D(s'))")
tot = 0
for w in range(3):
    m, se3 = est(L(Z, w) - L(Ds, w)); tot += m
    log(f"    world {w+1}: {m:+.6f} (s.e. {se3:.6f})")
log(f"    sum over worlds {tot:+.2e} (pointwise balance of the first level: exactly 0 sample by sample)")
wedge = (Ds != V1)
for w in (1, 2):
    better = (rank(Ds, w) < rank(V1, w)) & wedge
    log(f"    compensation at world {w+1}: mass where D(s') beats V_1 on the wedge = {better.mean():.6f}")
better1 = ((rank(Ds, 0) < rank(V1, 0)) & wedge).mean()
log(f"    at world 1: mass where D(s') beats V_1 = {better1:.6f} (no compensation, as Theorem 3.1 requires endorsement)")
with open("budget_mc.out", "w") as fh:
    fh.write("\n".join(out) + "\n")
