"""PP36 exp_split36 (CHECKED): persistence under further radial splitting.

Space with four radial pieces per direction (.0, .1, .2 bounded, .i outer).
(1) The minimal failures of the note, rebuilt on the finer space with G and E
    taken as single fine pieces: exposure of T against a retreat (F1/F2, 1 request),
    exposure of a fill's dominator (F2, 1 request), and the competitiveness kill
    of Proposition K (2 requests).
(2) The self-domination system (T's defences + T dominating every genuine Z) on
    the finer space for single and two-piece G: clean, and inert.
"""
from fractions import Fraction as Fr
from collections import Counter
from cells36 import Space36, directions
from family36 import *
from solver36 import *
from base36 import selfdom_requests
from exp_rules import mk_rule

S = Space36(directions(), pieces=('0', '1', '2', 'i'))
V = vertex_models(S)
print('cells', S.n)
ix = S.idx
cat = S.coherent_models()
print('catalogue', len(cat))
res = Counter()
# (1a) T cannot dominate a retreat: V1[Gp2.1 -> S]
R = fill(V[0], [ix['Gp2.1']], [2])
c = apply(new_closure(S, V), [('dom', S.T, R)])
print('(1a) dom(T, V1[Gp2.1 -> S]):', c.failure.kind if c.failure else 'clean')
R = fill(V[1], [ix['Gp1.2']], [2])
c = apply(new_closure(S, V), [('dom', S.T, R)])
print('     dom(T, V2[Gp1.2 -> S]):', c.failure.kind if c.failure else 'clean')
# (1b) fill dominator agreeing with V1 on G: the tightening T[Gp2 -> A]
X = fill(S.T, [ix['Gp2.1']], [V[0][ix['Gp2.1']]])
D = fill(S.T, S.cells_of_dir[S.dname.index('Gp2')], [V[0][ix['Gp2.1']]] * 4)
c = apply(new_closure(S, V), [('dom', D, X)])
print('(1b) dom(T[Gp2 -> A], T[Gp2.1 -> A]):', c.failure.kind if c.failure else 'clean', ' D coherent:', S.is_coherent(D))
# (1c) Proposition K: T dominates Z = V1[F2.2 -> w-correct] (G = E = F2.2, guidance world 2);
#      D = a precise model that is 1-wrong on F2 and differs from V1; D R_1 T must fail
k = ix['F2.2']
Z = fill(V[0], [k], [wcorrect(S, k, 1)])
prec = [C for C in cat if S.classify(C).endswith('precise') and C not in V and C[k] != V[0][k]]
nk = Counter()
for C in prec:
    base = apply(new_closure(S, V), [('cmp', S.T, fill(S.T, [k], [V[0][k]]), 1), ('dom', S.T, Z)])
    r = mk_rec(C, S.T)
    if improvement(S, r, 0): nk['n/a'] += 1; continue
    c = apply(base, [('cmp', C, S.T, 0)])
    nk['killed' if c.failure else 'not killed'] += 1
print('(1c) precise D (not V_j) that are 1-wrong on F2: D R_1 T after T dominates V1[F2.2 -> w2-correct]:', dict(nk))
# (2) self-domination system on the finer space
rule = mk_rule('bits0')
for Gk in (('single',), ('single', 'samedir', 'crosspair')):
    defs, doms, retreats = selfdom_requests(S, V, rule, Gk)
    cl = apply(new_closure(S, V), defs + doms)
    ni = sum(1 for w in range(3) for r, j in cl.inst[w].items() if j[0] != 'req')
    print(f'(2) self-domination system, G-kinds {Gk}: {len(defs)} defences, {len(doms)} dominations:',
          'clean' if cl.failure is None else cl.failure.kind, f'; non-requested records {ni}')
