"""PP36 exp_rounds (CHECKED): the repeatable extension, round by round.

Round 0: the vertex family (T's forced defences against T[G -> V_j]; dominators
for every Z at every accepting world and for every retreat R = V_j[G -> S]).
Round r+1: every defender D registered so far brings its own forced family
(Theorem 3.1 with D_p := D):  T R_w T[G' -> D] for bounded G' inside Sil(T)
where D answers (its partial sources), the Z' and the retreats D[G' -> S], all
needing dominators; and D's own defences against D[G' -> V_j] on the part of
D's silence outside Sil(T).  Every registered defender is also made competitive
(full support) against T, the vertex models, the other defenders and every rival.
Usage: python3 -B exp_rounds.py <std|ref> <Gkinds> <rule> <rounds> [noT] [sep|sepC] [mc=<max candidates>]
"""
import sys, time
from collections import Counter
from cells36 import standard, refined
from family36 import *
from solver36 import *
from joint36 import *
from exp_rules import mk_rule

if __name__ == '__main__':
    model = sys.argv[1]
    S = standard() if model == 'std' else refined()
    V = vertex_models(S)
    cat = S.coherent_models()
    Gk = tuple(sys.argv[2].split(','))
    rule = mk_rule(sys.argv[3])
    rounds = int(sys.argv[4])
    noT = 'noT' in sys.argv[5:]
    t = time.time()
    mc = [int(a[3:]) for a in sys.argv[5:] if a.startswith('mc=')]
    J = Joint(S, V, rule=rule, pool=cat, Gkinds=Gk, domXR='R', rounds=rounds, verbose=True,
              max_cands=mc[0] if mc else 400)
    if noT: J.exclude = {S.T}
    J.family_sep = 'C' if 'sepC' in sys.argv[5:] else ('sep' in sys.argv[5:])
    cl, st = J.solve()
    print(f'model {model} ({S.n} cells, catalogue {len(cat)}), G-kinds {Gk}, rule {sys.argv[3]}, rounds {rounds}'
          f'{", T barred as dominator" if noT else ""}{", one answerer per dominator" if J.family_sep == "C" else ", one vertex family per dominator" if J.family_sep else ""}: {"CLEAN" if cl is not None else "STUCK"} ({time.time()-t:.0f}s, {J.nodes} steps)')
    if cl is None:
        lines, fails = describe_failure(J, st)
        print('\n'.join(lines))
        print('\n'.join(minimal_failures(J, st, k=3)))
        for D in J.defenders: print('  ', J.names[D], S.classify(D), S.show(D))
    else:
        print(f'  |P| = {len(cl.P)}, installed records per world {[len(x) for x in cl.recs]}, '
              f'non-requested (rules II-IV): {sum(1 for w in range(3) for r, j in cl.inst[w].items() if j[0] != "req")}')
        print('  family records:', len(J.fam), ' rivals:', len(J.rivals))
        sil = [c for c in range(S.n) if S.T[c] == 2]
        for D in J.defenders:
            nd = sum(1 for Z, N in J.dom_of.items() if N == D)
            agreeV = [f'V{j+1}' for j in range(3) if all(D[c] == V[j][c] for c in sil)]
            print(f'  {J.names[D]:4} {S.classify(D):20} dominates {nd:4}  agrees with {agreeV} on Sil(T)  {S.show(D)}')
        by = Counter()
        for Z, N in J.dom_of.items():
            nmz = J.rivals.get(Z, '?')
            by[(nmz[0], 'T' if N == S.T else J.nm(N) if N in V else S.classify(N))] += 1
        print('  dominator use (rival type, dominator):', dict(by))
        from verify36 import verify_closure
        if max(len(x) for x in cl.recs) < 2500:
            print('  definition-level re-check violations:', len(verify_closure(cl)))
