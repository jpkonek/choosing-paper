"""PP34 check C1 (CHECKED, exact): bookkeeping for Lemma 2.1 and Proposition 5.2.

Part A (Lemma 2.1, padded undo).  On cells (one piece = one class label, values A, S, B), for
every departure d = (H, S -> a) out of silence, every world i at which d has a loss, every O with
Wr_i(a) & H <= O <= H, and every b on O with values in {S, i-correct}: if q = (O, a -> b) is
nontrivial and the composite d.q is nontrivial, then d.q is a pure i-improvement (so (P1) forbids
accepting d and q at i together).  Checked exhaustively for 1..5 pieces in all class patterns.

Part B (Proposition 5.2, blocked worlds).  A retreat-type record q = (O, a -> b) of a realiser is
*blocked at i* by a departure rule if some departure d = (O u F, S -> a + c), with c i-correct on a
fresh F (F may be empty only if b has an i-correct point), is accepted at i.  In loss coordinates
d's loss vector is l(O) + p, where p ranges over the paddings available to i-correct answers:
p in {(x at j and k) [B on M_i], (x at j only) [A on M_k], (x at k only) [A on M_j]}, x > 0.
For each rule we enumerate loss vectors l in {0..6}^3 and paddings x in {1..3} (and the empty
padding for retreat-improves) and report the maximum number of blocked worlds.
  - largest-loss rule, single-valued, fixed priority 1 > 2 > 3: at most ONE blocked world;
  - largest-loss rule, all tied worlds accepted: two or three blocked worlds occur (ties);
  - world-priority rule (accept at the highest-priority loss world): at most one;
  - balanced additive rule Omega on A-answers (accept at i iff 2 h_i >= h_j + h_k): two blocked
    worlds occur, e.g. o = (1, 1, 0): both edge-{1,2} worlds blocked (the R46.1 failure).
Usage: python3 -B coordination_check.py
"""
import itertools

A, S, B = 0, 1, 2


def rank(w, k, v):
    return (2 - v) if w == k else v


def wrong(w, k, v):
    return rank(w, k, v) == 2


def correct(w, k, v):
    return rank(w, k, v) == 0


def part_a():
    total = 0
    for n in range(1, 6):
        for cls in itertools.product(range(3), repeat=n):
            for a in itertools.product((A, B), repeat=n):
                # departure on all n pieces (H = everything; sub-departures are covered by smaller n)
                for i in range(3):
                    if not any(wrong(i, cls[p], a[p]) for p in range(n)):
                        continue
                    Wr = {p for p in range(n) if wrong(i, cls[p], a[p])}
                    rest = [p for p in range(n) if p not in Wr]
                    for k in range(len(rest) + 1):
                        for extra in itertools.combinations(rest, k):
                            O = sorted(Wr | set(extra))
                            # b on O: S or the i-correct answer
                            icor = {p: (B if cls[p] == i else A) for p in O}
                            for bs in itertools.product((0, 1), repeat=len(O)):
                                b = {p: (S if t == 0 else icor[p]) for p, t in zip(O, bs)}
                                q_nontriv = any(b[p] != a[p] for p in O)
                                comp = {}
                                for p in range(n):
                                    if p not in O:
                                        comp[p] = a[p]          # S -> a survives
                                    elif b[p] != S:
                                        comp[p] = b[p]          # S -> b
                                if not q_nontriv or not comp:
                                    continue
                                total += 1
                                assert all(rank(i, cls[p], v) < rank(i, cls[p], S)
                                           for p, v in comp.items()), (cls, a, i, O, b)
    print(f'Part A: {total} (d, i, O, b) configurations; every composite d.q is a pure '
          f'i-improvement: PASS')


def paddings(i):
    j, k = [w for w in range(3) if w != i]
    out = []
    for x in range(1, 4):
        for vec in ((j, k), (j,), (k,)):
            p = [0, 0, 0]
            for t in vec:
                p[t] += x
            out.append(tuple(p))
    return out


def blocked(rule, l, allow_empty):
    bl = set()
    for i in range(3):
        pads = paddings(i) + ([(0, 0, 0)] if allow_empty else [])
        for p in pads:
            v = tuple(l[t] + p[t] for t in range(3))
            if i in rule(v):
                bl.add(i)
                break
    return bl


def largest_single(v, prio=(0, 1, 2)):
    m = max(v)
    if m == 0:
        return set()
    for w in prio:
        if v[w] == m:
            return {w}


def largest_all(v):
    m = max(v)
    return {w for w in range(3) if v[w] == m and m > 0}


def world_priority(v, prio=(0, 1, 2)):
    for w in prio:
        if v[w] > 0:
            return {w}
    return set()


def part_b():
    rules = [('largest-loss, single-valued', largest_single), ('largest-loss, all ties', largest_all),
             ('world priority', world_priority)]
    res = {}
    for name, rule in rules:
        worst = 0; ex = None
        for l in itertools.product(range(7), repeat=3):
            if l == (0, 0, 0):
                continue
            for allow_empty in (False, True):
                bl = blocked(rule, l, allow_empty)
                if len(bl) > worst:
                    worst, ex = len(bl), (l, allow_empty, sorted(w + 1 for w in bl))
        res[name] = worst
        print(f'Part B: {name}: max blocked worlds = {worst}' + (f'  e.g. loss {ex[0]}, '
              f'{"retreat-improve" if ex[1] else "pure retreat"}, blocked at {ex[2]}' if worst > 1 else ''))
    assert res['largest-loss, single-valued'] <= 1 and res['world priority'] <= 1
    assert res['largest-loss, all ties'] >= 2
    # balanced additive Omega on A-answers: loss at i = mass on M_i; A-padding adds to one class
    worst = 0; ex = None
    for o in itertools.product(range(5), repeat=3):
        if o == (0, 0, 0):
            continue
        bl = set()
        for i in range(3):
            j, k = [w for w in range(3) if w != i]
            for x in range(1, 4):
                for t in (j, k):
                    h = list(o); h[t] += x
                    if 2 * h[i] >= h[j] + h[k] and h[i] > 0:
                        bl.add(i)
        if len(bl) > worst:
            worst, ex = len(bl), (o, sorted(w + 1 for w in bl))
    print(f'Part B: balanced additive Omega (A-answers): max blocked worlds = {worst}, e.g. class '
          f'masses {ex[0]} blocked at {ex[1]}')
    assert worst >= 2
    print('ALL PASS')


if __name__ == '__main__':
    part_a()
    part_b()
