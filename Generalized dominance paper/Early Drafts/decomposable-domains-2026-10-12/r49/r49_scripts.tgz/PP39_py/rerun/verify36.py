"""PP36 verification (CHECKED, exact).
(1) engine36.FastClosure vs PP21 engine.Closure on random request sets drawn from
    the forced-defence family: identical failure status, failure kind, installed
    records at every world, and P.
(2) verify_closure(cl): PP21 verify.verify (definition-level re-check of a clean
    closure: triangle completion for every composable pair, no installed weak
    improvement, rules III/IV against every P member, coherence of P by the
    independent clipping test with cone structure).
Run: python3 -B verify36.py [trials]
"""
import os, sys, random
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'PP21_py'))
import verify as V21
from engine import Closure
from engine36 import FastClosure
from cells36 import standard
from family36 import *

def verify_closure(cl):
    S = cl.S
    old = S.is_coherent
    S.is_coherent = S.is_coherent_clip
    try:
        return V21.verify(cl)
    finally:
        S.is_coherent = old

def random_requests(S, V, cat, rnd):
    reqs = []
    Gs = G_family(S, kinds=('single', 'crosspair', 'samedir'))
    for _ in range(rnd.randint(2, 9)):
        j = rnd.randrange(3); G = rnd.choice(Gs)
        pat = pattern(S, V[j], G)
        w = rnd.choice(allowed_worlds(pat))
        E = rnd.choice(E_family(G))
        I = make(S, V[j], G, E, w, j=j)
        u = rnd.random()
        if u < 0.4: reqs.append(('cmp', S.T, I.X, w))
        elif u < 0.8: reqs.append(('dom', rnd.choice(cat), I.Z))
        elif u < 0.9: reqs.append(('cmp', rnd.choice(cat), I.R, rnd.randrange(3)))
        else: reqs.append(('cmp', S.T, rnd.choice(cat), rnd.randrange(3)))
    return reqs

def run(cls, S, V, reqs):
    cl = cls(S, S.is_coherent); cl.request(('reg', S.T))
    for N in V: cl.request(('reg', N))
    for q in reqs: cl.request(q)
    cl.run()
    return cl

if __name__ == '__main__':
    trials = int(sys.argv[1]) if len(sys.argv) > 1 else 300
    S = standard(); V = vertex_models(S); cat = S.coherent_models()
    rnd = random.Random(7)
    same = diff = clean = fail = vbad = 0
    for t in range(trials):
        reqs = random_requests(S, V, cat, rnd)
        a = run(Closure, S, V, reqs); b = run(FastClosure, S, V, reqs)
        sa = None if a.failure is None else a.failure.kind
        sb = None if b.failure is None else b.failure.kind
        ok = (sa == sb)
        if ok and sa is None:
            ok = all(set(a.inst[w]) == set(b.inst[w]) for w in range(3)) and set(a.P) == set(b.P)
            clean += 1
            errs = verify_closure(b)
            vbad += len(errs)
        elif ok:
            fail += 1
        same += ok; diff += (not ok)
    print(f'engine equivalence on {trials} random family request sets: agree {same}, disagree {diff} '
          f'(clean {clean}, failing {fail}); definition-level violations in clean closures: {vbad}')
