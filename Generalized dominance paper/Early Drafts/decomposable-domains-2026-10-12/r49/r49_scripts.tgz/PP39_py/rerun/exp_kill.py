"""PP36 exp_kill (CHECKED, exact): the competitiveness kill of Proposition K.

On the self-domination base (T's forced defences by a rule; T dominating every
genuine Z), test for coherent models D and worlds i whether D R_i T can still be
added (closure of base + cmp(D, T, i)).  Compare with the pointwise criterion:
  killed at i  <=>  some self-dominated Z satisfies Z <=_i D pointwise, Z != D
(then D R_i T R_i Z and the strict guidance Z <_i D give a (TC) triangle).
Report agreement, the predicted characterisation (a free world exists iff D makes
no i-error on Sil(T) for some i), and which kinds of coherent models keep a free world
(i.e. could still be competitive against T at some world).
Usage: python3 -B exp_kill.py <std|ref> <Gkinds> <rule> [sample]
"""
import sys, random, time
import numpy as np
from collections import Counter
from cells36 import standard, refined
from family36 import *
from solver36 import *
from base36 import selfdom_base
from exp_rules import mk_rule

if __name__ == '__main__':
    model = sys.argv[1]
    S = standard() if model == 'std' else refined()
    V = vertex_models(S)
    Gk = tuple(sys.argv[2].split(','))
    rule = mk_rule(sys.argv[3])
    nsample = int(sys.argv[4]) if len(sys.argv) > 4 else 2000
    cat = S.coherent_models()
    t0 = time.time()
    base, defs, doms, retreats = selfdom_base(S, V, rule, Gk)
    print(f'model {model}: base with {len(defs)} defences and {len(doms)} self-dominations:',
          'clean' if base.failure is None else base.failure.kind, f'({time.time()-t0:.0f}s)')
    Zs = np.array([q[2] for q in doms], dtype=np.int8)
    RK = [np.array([S.rank[w][k] for k in range(S.n)], dtype=np.int8) for w in range(3)]
    ar = np.arange(S.n)
    rnd = random.Random(5)
    prec = [C for C in cat if S.classify(C).endswith('precise')]
    pool = list(dict.fromkeys(list(V) + prec + rnd.sample(cat, min(nsample, len(cat)))))
    agree = disagree = 0
    free = Counter(); total = Counter(); examples = {}; anchor = Counter()
    for D in pool:
        Da = np.array(D, dtype=np.int8)
        killed_pred = []
        for i in range(3):
            rz = RK[i][ar[None, :], Zs]; rd = RK[i][ar, Da]
            le = np.all(rz <= rd[None, :], axis=1) & np.any(Zs != Da[None, :], axis=1)
            killed_pred.append(bool(le.any()))
        kd = S.classify(D) if D not in V else 'vertex'
        if D == S.T: kd = 'T'
        total[kd] += 1
        freew = []
        rDT = mk_rec(D, S.T)
        for i in range(3):
            if D == S.T or base.accepted(rDT, i):
                eng_killed = False
            elif improvement(S, rDT, i):
                eng_killed = None          # not available anyway (pure improvement)
            else:
                c = apply(base, [('cmp', D, S.T, i)])
                eng_killed = c.failure is not None
            if eng_killed is None: continue
            if eng_killed == killed_pred[i]: agree += 1
            else:
                disagree += 1
                examples.setdefault('mismatch', (S.show(D), i, eng_killed, killed_pred[i]))
            if not eng_killed: freew.append(i + 1)
        sil = [k for k in range(S.n) if S.T[k] == 2 and S.bounded[k]]
        errfree = [i + 1 for i in range(3) if all(S.rank[i][k][D[k]] != 2 for k in sil)]
        anchor[(bool(freew), bool(errfree))] += 1
        if freew: free[kd] += 1
        else: examples.setdefault(kd, S.show(D))
    print(f'engine vs pointwise criterion on {len(pool)} models x 3 worlds: agree {agree}, disagree {disagree}')
    print('models keeping a world at which D R_i T is still addable, by kind:')
    for k in sorted(total): print(f'   {k:22} {free[k]:5} / {total[k]}')
    for k, v in examples.items(): print('   example with no free world:', k, v)
    print('  (has a free world, is error-free at some world on the bounded Sil(T) cells):', dict(anchor))
    print(f'time {time.time()-t0:.0f}s')
