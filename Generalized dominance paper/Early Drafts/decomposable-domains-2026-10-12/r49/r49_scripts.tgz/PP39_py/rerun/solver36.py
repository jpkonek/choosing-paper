"""PP36 solver utilities on top of the PP21 closure engine (rules I-IV, F1/F2).

compete(cl, A, B, worlds): obligation 'A R_w B for some w in worlds' (support-
sensitive competitiveness).  Options: already accepted, or install cmp(A, B, w).
dfs(cl, obligations): backtracking over the options of a list of obligations;
obligations may be generated lazily (a callable returning the list for the
current closure) so that newly registered defenders bring their own.
"""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'PP21_py'))
from engine import Closure, mk_rec, inv, comp, is_empty, ends_at, source_of
from engine36 import FastClosure

def improvement(S, r, w):
    ds = [S.rank[w][k][v % 4] - S.rank[w][k][v // 4] for k, v in enumerate(r) if v >= 0]
    return len(ds) > 0 and all(d <= 0 for d in ds)

def weak_improvement_any(S, A, B):
    r = mk_rec(A, B)
    return any(improvement(S, r, w) for w in range(3))

def new_closure(S, regs=(), fast=True):
    cl = (FastClosure if fast else Closure)(S, S.is_coherent)
    cl.request(('reg', S.T))
    for N in regs: cl.request(('reg', N))
    cl.run()
    return cl

def apply(cl, reqs):
    c2 = cl.clone()
    for q in reqs: c2.request(q)
    c2.run()
    return c2

def options_compete(cl, A, B, worlds, prefer=None):
    """requests that would satisfy A R_w B for some w in worlds; [] means
    already satisfied (returned as [[]])."""
    r = mk_rec(A, B)
    if any(cl.accepted(r, w) for w in worlds): return [[]]
    ws = [w for w in worlds if not improvement(cl.S, r, w)]
    if prefer is not None: ws = sorted(ws, key=lambda w: (w not in prefer, w))
    return [[('cmp', A, B, w)] for w in ws]

def dfs(cl, obligations, budget=[0], limit=20000):
    """obligations: list of (kind, A, B, worlds).  Returns (closure, None) or
    (None, (failed obligation, failures))."""
    def rec(cl, i):
        budget[0] += 1
        if budget[0] > limit: return None, 'budget'
        while i < len(obligations):
            kind, A, B, worlds = obligations[i]
            opts = options_compete(cl, A, B, worlds)
            if opts == [[]]: i += 1; continue
            fails = []
            for q in opts:
                c2 = apply(cl, q)
                if c2.failure is not None: fails.append((q, c2)); continue
                res, info = rec(c2, i + 1)
                if res is not None: return res, None
                if info == 'budget': return None, 'budget'
            return None, (obligations[i], fails)
        return cl, None
    return rec(cl, 0)
