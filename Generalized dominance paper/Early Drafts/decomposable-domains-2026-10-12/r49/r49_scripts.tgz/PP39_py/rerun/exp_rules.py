"""PP36 exp_rules (CHECKED): joint runs of the vertex family under named w-rules.

Rules are functions of the record's pattern only (classes met by G, with the
answer A/B shown there).  For each rule: greedy joint search (defence worlds fixed
by the rule; dominators chosen jointly, existing P members first, then the
catalogue ordered by distance from T); all obligations of joint36.
Usage: python3 -B exp_rules.py <Gkinds> <rule names comma-separated> [noT]
"""
import sys, time
from collections import Counter
from cells36 import standard
from family36 import *
from solver36 import *
from joint36 import *

def owner_B(pat):
    return [k for k, a in pat if a == 'B']

FREE = [frozenset({(0, 'A'), (1, 'A')}), frozenset({(0, 'A'), (2, 'A')}), frozenset({(1, 'A'), (2, 'A')}),
        frozenset({(0, 'B'), (1, 'A'), (2, 'A')}), frozenset({(1, 'B'), (0, 'A'), (2, 'A')}),
        frozenset({(2, 'B'), (0, 'A'), (1, 'A')})]

def mk_rule(name):
    """named rules; 'bits<n>': bit t of n chooses the higher allowed world for FREE[t]
    (the vertex-family patterns with no guidance world).  Where a guidance world
    exists the defence is automatic there and the rule returns it."""
    if name.startswith('bits'):
        n = int(name[4:])
        def rule(S, pat, G):
            allowed = allowed_worlds(pat); guid = guidance_worlds(pat)
            if guid: return guid[0]
            t = FREE.index(pat) if pat in FREE else None
            if t is None: return allowed[0]
            return allowed[-1] if (n >> t) & 1 else allowed[0]
        return rule
    def rule(S, pat, G):
        allowed = allowed_worlds(pat)
        guid = guidance_worlds(pat)
        A = sorted(k for k, a in pat if a == 'A'); B = owner_B(pat)
        if len(allowed) == 1: return allowed[0]
        if name == 'low': return allowed[0]
        if name == 'high': return allowed[-1]
        if name == 'guid_low': return guid[0] if guid else allowed[0]
        if name == 'guid_high': return guid[-1] if guid else allowed[-1]
        if name == 'mixed_low':
            m = [w for w in allowed if w not in guid]; return m[0] if m else allowed[0]
        if name == 'mixed_high':
            m = [w for w in allowed if w not in guid]; return m[-1] if m else allowed[-1]
        if name == 'cyc':            # successor of the B-owner, or of the larger A class
            b = B[0] if B else None
            if b is not None:
                w = (b + 1) % 3
                return w if w in allowed else allowed[0]
            w = (A[-1] + 1) % 3 if A else allowed[0]
            return w if w in allowed else allowed[0]
        if name == 'anticyc':
            b = B[0] if B else None
            if b is not None:
                w = (b + 2) % 3
                return w if w in allowed else allowed[0]
            w = (A[0] + 2) % 3 if A else allowed[-1]
            return w if w in allowed else allowed[-1]
        raise ValueError(name)
    return rule

if __name__ == '__main__':
    Gk = tuple(sys.argv[1].split(','))
    names = sys.argv[2].split(',')
    noT = 'noT' in sys.argv[3:]
    dx = 'R' if 'R' in sys.argv[3:] else ''
    S = standard(); V = vertex_models(S)
    cat = S.coherent_models()
    def dist(C): return sum(1 for d in range(S.nd) if C[S.cells_of_dir[d][0]] != S.T[S.cells_of_dir[d][0]])
    pool = sorted(cat, key=dist)
    for nmr in names:
        t = time.time()
        J = Joint(S, V, rule=mk_rule(nmr), pool=pool, Gkinds=Gk, domXR=dx)
        if noT: J.exclude = {S.T} | set(V)
        cl, st = J.solve()
        if cl is None:
            lines, fails = describe_failure(J, st)
            print(f'rule {nmr}: STUCK  ({time.time()-t:.0f}s)')
            print('\n'.join('   ' + l for l in lines))
            print('\n'.join(minimal_failures(J, st)))
            for D in J.defenders: print('   ', J.names[D], S.classify(D), S.show(D))
        else:
            print(f'rule {nmr}: CLEAN  |P|={len(cl.P)} records={[len(x) for x in cl.recs]} ({time.time()-t:.0f}s)')
            print('   realised:', {k: dict(v) for k, v in sorted(J.realised_rule().items())})
            print('   dominators:', Counter(S.classify(v) if v not in (S.T,) + tuple(V) else J.nm(v) for v in J.dom_of.values()))
        sys.stdout.flush()
