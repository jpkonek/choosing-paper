"""PP36 exp_selfdom (CHECKED): when can T itself be the replacement dominator of
Z = V_j[G -> S, E -> w-correct]?

(a) alone: closure of {T R_w X, dom(T, Z)} (T, V_1..V_3 in P);
(b) together with T's defences of every record of the family (rule given), and
    with dom(T, Z') for all other Z' -- the 'self-domination' system;
failures are minimised (deletion-minimal request sets) and printed with
derivations.  Also tests the prediction of Lemma SD (see PP36 note):
    T can dominate Z alone  iff  E' := E cap {V_j not w-correct} is non-null
by comparing the engine's verdict with a pointwise criterion.
Usage: python3 -B exp_selfdom.py <Gkinds> <rule>[,<rule>...]
"""
import sys
from collections import Counter, defaultdict
from cells36 import standard
from family36 import *
from solver36 import *
from exp_rules import mk_rule
sys.path.insert(0, '../PP21_py')
from engine import Closure

def minimise(S, V, reqs):
    def run(rs):
        cl = new_closure(S, V)
        return apply(cl, rs)
    cur = list(reqs)
    assert run(cur).failure is not None
    i = 0
    while i < len(cur):
        trial = cur[:i] + cur[i + 1:]
        if run(trial).failure is not None: cur = trial
        else: i += 1
    return cur, run(cur)

def run_rule(Gk, rname, verbose=True):
    rule = mk_rule(rname)
    print(f'=== rule {rname}, G-kinds {Gk}')
    S = standard(); V = vertex_models(S)
    names = {S.T: 'T', V[0]: 'V1', V[1]: 'V2', V[2]: 'V3'}
    insts = []
    defs = []
    for j in range(3):
        for G in G_family(S, kinds=Gk):
            pat = pattern(S, V[j], G)
            w = rule(S, pat, G)
            X = fill(S.T, G, [V[j][k] for k in G])
            defs.append(('cmp', S.T, X, w))
            # every world at which the record is a pure worsening is accepted by guidance too
            ws = sorted(set([w] + guidance_worlds(pat)))
            for ww in ws:
                for E in E_family(G):
                    insts.append(make(S, V[j], G, E, ww, j=j))
    print(f'family: {len(defs)} records, {len(insts)} Z rivals')
    alone = Counter(); fail_alone = []
    for I in insts:
        cl = apply(new_closure(S, V), [('cmp', S.T, I.X, I.w), ('dom', S.T, I.Z)])
        ok = cl.failure is None
        alone[ok] += 1
        if not ok: fail_alone.append(I)
    print('(a) T dominates Z alone:', dict(alone))
    pred = sum(1 for I in insts if (I in fail_alone) == (not any(V[I.j][k] != wcorrect(S, k, I.w) for k in I.E)))
    print(f"    criterion 'fails alone iff E-prime null' matches on {pred}/{len(insts)}")
    by = Counter((pstr(I.pat), I.w + 1, ''.join(S.ab(k, wcorrect(S, k, I.w)) for k in I.E), len(I.G) == len(I.E)) for I in fail_alone)
    for k, v in sorted(by.items()): print('    fails alone:', k, v)
    shown = set() if verbose else {None}
    for I in fail_alone:
        key = (pstr(I.pat), I.w)
        if not verbose or key in shown: continue
        shown.add(key)
        reqs, cl = minimise(S, V, [('cmp', S.T, I.X, I.w), ('dom', S.T, I.Z)])
        print(f'  example {I.name}: minimal failing set {len(reqs)} requests, {cl.failure.kind}')
        nm = dict(names); nm[I.Z] = 'Z'; nm[I.X] = 'X'
        for l in cl.derivation(names=nm): print('     ' + l)
    # (b) whole self-domination system
    good = [I for I in insts if I not in fail_alone]
    cl = new_closure(S, V)
    cl = apply(cl, defs)
    print('(b) defences alone:', 'clean' if cl.failure is None else cl.failure.kind)
    reqs = defs + [('dom', S.T, I.Z) for I in good]
    cl2 = apply(new_closure(S, V), reqs)
    print('(b) defences + dom(T, Z) for every Z that T dominates alone:',
          'clean' if cl2.failure is None else cl2.failure.kind, ' records', [len(x) for x in cl2.recs])
    if cl2.failure is not None:
        sub = [cl2.requests[i] for i in sorted(cl2.failure_support())]
        sub = [q for q in sub if not (q[0] == 'reg')]
        m, clm = minimise(S, V, sub)
        print('   minimal failing set:', len(m))
        for l in clm.derivation(names=names): print('     ' + l)
    else:
        from verify36 import verify_closure
        print('   definition-level re-check violations:', len(verify_closure(cl2)))
        inst2 = sum(1 for w in range(3) for r, j in cl2.inst[w].items() if j[0] != 'req')
        print('   records added by rules II-IV (non-requested):', inst2)

if __name__ == '__main__':
    Gk = tuple(sys.argv[1].split(','))
    for ri, rname in enumerate(sys.argv[2].split(',')):
        run_rule(Gk, rname, verbose=(ri == 0))

def _unused():
    pass
