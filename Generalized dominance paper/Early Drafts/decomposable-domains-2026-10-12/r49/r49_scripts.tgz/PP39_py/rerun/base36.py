"""PP36 base system: T's forced defences chosen by a w-rule, plus self-domination.

selfdom_base(S, V, rule, Gkinds): requests
   T R_w X        for every record (V_j, G) at the rule's world w
   T R_i Z (all i) for every Z = V_j[G -> S, E -> w'-correct] at every world w' at
                   which the record is accepted (rule world and guidance worlds),
                   provided E' := E cap {V_j not w'-correct} is non-null.
The remaining Z (E' null) are pure retreats V_j[G minus E -> S]; they are returned,
together with the retreats R = V_j[G -> S] themselves, as 'retreats'.
"""
from family36 import *
from solver36 import *

def family_records(S, V, rule, Gkinds):
    recs = []
    for j in range(3):
        for G in G_family(S, kinds=Gkinds):
            pat = pattern(S, V[j], G)
            w = rule(S, pat, G)
            recs.append((j, G, pat, w))
    return recs

def selfdom_requests(S, V, rule, Gkinds):
    defs, doms, retreats = [], [], {}
    for (j, G, pat, w) in family_records(S, V, rule, Gkinds):
        X = fill(S.T, G, [V[j][k] for k in G])
        defs.append(('cmp', S.T, X, w))
        R = fill(V[j], G, [2] * len(G))
        retreats.setdefault(R, (j, G))
        for ww in sorted(set([w] + guidance_worlds(pat))):
            for E in E_family(G):
                I = make(S, V[j], G, E, ww, j=j)
                Ep = [k for k in E if V[j][k] != wcorrect(S, k, ww)]
                if Ep:
                    doms.append(('dom', S.T, I.Z))
                else:
                    Gp = tuple(k for k in G if k not in E)
                    retreats.setdefault(I.Z, (j, Gp))
    return defs, doms, retreats

def selfdom_base(S, V, rule, Gkinds):
    defs, doms, retreats = selfdom_requests(S, V, rule, Gkinds)
    cl = apply(new_closure(S, V), defs + doms)
    return cl, defs, doms, retreats
