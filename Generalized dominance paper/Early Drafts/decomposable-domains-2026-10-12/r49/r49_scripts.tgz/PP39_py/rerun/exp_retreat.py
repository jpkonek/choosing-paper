"""PP36 exp_retreat (CHECKED, exact): who can dominate the pure retreats
R = V_j[G' -> S] (the Z's with E' null, and the R's themselves), on top of the
self-domination base (T's defences by a w-rule; T dominating every Z with E'
non-null; T competitive against V_1..V_3 at fixed worlds)?

For each retreat and each candidate C (all precise models, the vertex models, and
a fixed random sample of the catalogue) the request set
    dom(C, R) ; T R_w C for some w ; C R_w T for some w (full support)
is closed on top of the base.  Survivors are classified:
  'V_i'        another vertex model
  'pV'         precise, agrees with V_j on every cell of Sil(T)  (precise near e_j)
  'precise'    other precise models
  'tightening', 'crossing', 'coarsening', 'separated'  (cells pattern vs T)
and by whether C gives V_j's answer on (all of / part of / none of) G'.
Usage: python3 -B exp_retreat.py <Gkinds> <rule> [sample]
"""
import sys, random, time
from collections import Counter, defaultdict
from cells36 import standard
from family36 import *
from solver36 import *
from base36 import *
from exp_rules import mk_rule
from joint36 import Joint

def kind_of(S, V, j, C):
    for i in range(3):
        if C == V[i]: return f'V{i+1}' if i != j else 'V_j'
    k = S.classify(C)
    if k.endswith('precise'):
        sil = [c for c in range(S.n) if S.T[c] == 2]
        if all(C[c] == V[j][c] for c in sil): return 'pV'
        return 'precise'
    return k

if __name__ == '__main__':
    Gk = tuple(sys.argv[1].split(','))
    rule = mk_rule(sys.argv[2])
    nsample = int(sys.argv[3]) if len(sys.argv) > 3 else 3000
    S = standard(); V = vertex_models(S)
    cat = S.coherent_models()
    t0 = time.time()
    cl0, defs, doms, retreats = selfdom_base(S, V, rule, Gk)
    tv = [('cmp', S.T, V[j], (j + 1) % 3) for j in range(3)]
    base = apply(cl0, tv)
    print(f'base: {len(defs)} defences, {len(doms)} self-dominations, T R V_j at cyclic worlds:',
          'clean' if base.failure is None else base.failure.kind, f'({time.time()-t0:.0f}s)')
    prec = [C for C in cat if S.classify(C).endswith('precise')]
    rnd = random.Random(3)
    pool = list(dict.fromkeys(list(V) + prec + rnd.sample(cat, nsample)))
    J = Joint(S, V, pool=pool)          # only for its vectorised prefilter
    # representative retreats: per j, one per (class pattern of G', size)
    reps = {}
    for R, (j, Gp) in retreats.items():
        key = (j, tuple(sorted((S.minworld[k], S.dname[S.dir_of[k]][:-1]) for k in Gp)), len(Gp))
        reps.setdefault(key, (R, j, Gp))
    # keep single-piece retreats and the first 4 two-class retreats per vertex model
    keep, cnt = {}, {}
    for key, v in sorted(reps.items()):
        if key[2] == 1: keep[key] = v
        elif len({c for c, _ in key[1]}) == 2 and cnt.get(key[0], 0) < 4:
            keep[key] = v; cnt[key[0]] = cnt.get(key[0], 0) + 1
    reps = keep
    print(f'{len(retreats)} distinct retreats, {len(reps)} representatives tested; pool {len(pool)}')
    total = defaultdict(Counter)
    for key, (R, j, Gp) in sorted(reps.items()):
        ok = J.ok_mask(R)
        surv = Counter(); agree = Counter()
        for i in J.np.nonzero(ok)[0]:
            C = pool[i]
            c = apply(base, [('dom', C, R)])
            if c.failure is not None: continue
            rT = mk_rec(S.T, C)
            if not any(c.accepted(rT, w) for w in range(3)):
                good = None
                for w in range(3):
                    if improvement(S, rT, w): continue
                    c2 = apply(c, [('cmp', S.T, C, w)])
                    if c2.failure is None: good = c2; break
                if good is None: continue
                c = good
            rC = mk_rec(C, S.T)
            if not any(c.accepted(rC, w) for w in range(3)):
                good = None
                for w in range(3):
                    if improvement(S, rC, w): continue
                    c2 = apply(c, [('cmp', C, S.T, w)])
                    if c2.failure is None: good = c2; break
                if good is None: continue
            kd = kind_of(S, V, j, C)
            ag = sum(C[k] == V[j][k] for k in Gp)
            surv[kd] += 1
            agree['all' if ag == len(Gp) else 'part' if ag else 'none'] += 1
        pat = pstr(pattern(S, V[j], Gp))
        print(f"V{j+1} G'={'+'.join(S.names[k] for k in Gp):16} pat {pat:9} survivors {sum(surv.values()):5}  "
              f"{dict(surv)}  agree-with-V_j-on-G': {dict(agree)}")
        total[pat].update(surv)
        sys.stdout.flush()
    print(f'\ntime {time.time()-t0:.0f}s')
