"""PP36: a vectorised version of PP21's closure engine (same rules, same failures).

Only rule II's triangle scan is changed: for a newly installed record r at world w
all installed records s that compose with r (in either order) are processed at
once in numpy; the inverse composite is tested for acceptance (empty, guidance,
or installed) with exact rank arithmetic and a 64-bit record hash whose hits are
confirmed on the exact tuple.  Every triangle found is then completed by the
original PP21 code path (install with the same justification), so derivations
are unchanged.  verify36.py cross-checks this engine against PP21's on random
request sets (identical status, records and P).
"""
import os, sys
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'PP21_py'))
import engine as E21
from engine import Closure, mk_rec, inv, comp, is_empty

class FastClosure(Closure):
    def __init__(self, S, coherent=None, seed=12345):
        super().__init__(S, coherent)
        rng = np.random.default_rng(seed)
        self.H = rng.integers(-(1 << 62), 1 << 62, size=(S.n, 16), dtype=np.int64)
        self.RK = [np.array([S.rank[w][k] for k in range(S.n)], dtype=np.int8) for w in range(3)]
        self.hset = [set() for _ in range(3)]
        self.ar = np.arange(S.n)

    def rhash(self, r):
        return int(sum(int(self.H[k, v]) for k, v in enumerate(r) if v >= 0) & ((1 << 64) - 1))

    def install(self, w, r, just):
        if self.accepted(r, w): return False
        self.inst[w][r] = just
        self.recs[w].append(r)
        self._pend[w].append(r)
        self.queue.append((w, r))
        self.hset[w].add(self.rhash(r))
        return True

    def _hash_rows(self, code):
        # code: (R, n) int, -1 = absent
        m = code >= 0
        h = np.where(m, self.H[self.ar[None, :], np.where(m, code, 0)], 0)
        s = h.sum(axis=1, dtype=np.int64)      # wraps mod 2^64
        return s.astype(np.uint64)

    def _check_and_complete(self, w, oc, nc, pairs):
        """oc, nc: (R, n) old/new sides of composites (-1 absent); pairs: list of
        (r, s) in composition order."""
        if len(pairs) == 0: return
        present = (oc >= 0) & (oc != nc)
        nonempty = present.any(axis=1)
        if not nonempty.any(): return
        RK = self.RK[w]
        ocz = np.where(present, oc, 0); ncz = np.where(present, nc, 0)
        # inverse composite: new side -> old side; guidance iff rank(old) - rank(new) >= 0 on support
        dl = RK[self.ar[None, :], ocz].astype(np.int16) - RK[self.ar[None, :], ncz].astype(np.int16)
        guid = np.all(np.where(present, dl >= 0, True), axis=1)
        # installed?  hash of the inverse composite (code = new*4 + old)
        icode = np.where(present, ncz * 4 + ocz, -1)
        hs = self._hash_rows(icode)
        hw = self.hset[w]
        inst = np.array([int(h) in hw for h in hs], dtype=bool) if hw else np.zeros(len(hs), bool)
        cand = np.nonzero(nonempty & (guid | inst))[0]
        for idx in cand:
            r, s = pairs[idx]
            self._tri(w, r, s)

    def _rule2(self, w, r):
        O, Nw = self._arrays(w)
        if len(self.recs[w]) == 0: return
        recs = self.recs[w]
        nr = np.array([v % 4 if v >= 0 else -1 for v in r], dtype=np.int8)
        orr = np.array([v // 4 if v >= 0 else -1 for v in r], dtype=np.int8)
        # r then s
        ok1 = np.all((nr < 0)[None, :] | (O < 0) | (nr[None, :] == O), axis=1)
        i1 = np.nonzero(ok1)[0]
        if len(i1):
            Os, Ns = O[i1], Nw[i1]
            oc = np.where(orr[None, :] >= 0, orr[None, :], Os)
            nc = np.where(Ns >= 0, Ns, nr[None, :])
            self._check_and_complete(w, oc.astype(np.int16), nc.astype(np.int16), [(r, recs[i]) for i in i1])
        # s then r
        ok2 = np.all((Nw < 0) | (orr < 0)[None, :] | (Nw == orr[None, :]), axis=1)
        i2 = np.nonzero(ok2)[0]
        if len(i2):
            Os, Ns = O[i2], Nw[i2]
            oc = np.where(Os >= 0, Os, orr[None, :])
            nc = np.where(nr[None, :] >= 0, nr[None, :], Ns)
            self._check_and_complete(w, oc.astype(np.int16), nc.astype(np.int16), [(recs[i], r) for i in i2])

    def clone(self):
        c = super().clone()
        c.__class__ = FastClosure
        c.H, c.RK, c.ar = self.H, self.RK, self.ar
        c.hset = [set(x) for x in self.hset]
        return c
