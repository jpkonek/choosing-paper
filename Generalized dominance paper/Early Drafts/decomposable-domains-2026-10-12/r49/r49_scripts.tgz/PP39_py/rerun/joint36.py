"""PP36 joint search: defence worlds and replacement dominators chosen together.

Family (PP30 Thm 3.1, generalised: any target N in P with a support, any answerer C):
  for a target N, an answerer C and a bounded G inside Sil(N) where C answers:
    N R_w N[G -> C] for some w in supp(N)              ('def' obligation; w-rule)
    for every world w at which that record is accepted (it may become accepted at
    more worlds by closure), and every E in the E-family of G:
    Z = C[G -> S, E -> w-correct] needs a dominator in P   ('dom' obligation)
  Round 0: N = T, C in {V_1, V_2, V_3}.
  Later rounds (optional): C = registered defender (T's partial sources), and
  N = registered defender (its own forced defences against V_j), restricted to
  G-shapes 'single' and 'samedir' outside what earlier rounds already contain.
Obligations also include:
  T competitive against every rival and every member of P (any world);
  every registered defender competitive on its stated support against T, V_j,
  the other registered defenders and the family rivals X, R, Z.
The w-rule is a function of the record (G, S -> C|G) only: either a dict on
patterns, a callable on (S, record-pattern, G), or None (free: DFS chooses).
"""
import sys, time, itertools, random
from collections import Counter, defaultdict
from cells36 import standard
from family36 import *
from solver36 import *

FULL = (0, 1, 2)

class Joint:
    def __init__(self, S, V, rule=None, pool=None, support=None, Gkinds=('single', 'samedir', 'crosspair'),
                 Ekind='all', rounds=0, Kcompete=True, Kfamily=True, max_cands=400, verbose=False,
                 prefer_existing=True, w_pref=None, round_Gkinds=('single', 'samedir'), domXR='', order='nearZ'):
        self.S, self.V = S, V
        self.rule = rule
        self.pool = pool if pool is not None else S.coherent_models()
        self.support = support or (lambda C: FULL)
        self.Gkinds, self.Ekind, self.rounds = Gkinds, Ekind, rounds
        self.Kcompete, self.Kfamily = Kcompete, Kfamily
        self.max_cands = max_cands
        self.verbose = verbose
        self.prefer_existing = prefer_existing
        self.w_pref = w_pref
        self.round_Gkinds = round_Gkinds
        self.names = {S.T: 'T'}
        for j in range(3): self.names[V[j]] = f'V{j+1}'
        self.defenders = []           # registered D_K in order
        self.dom_of = {}              # Z -> dominator
        self.def_world = {}           # record -> chosen world
        self.log = []
        self.nodes = 0
        self.sat = set()
        self.family_sep = False
        self.ztags = {}
        self.serves = {}
        self.rcache = {}
        self.domXR = domXR
        self.order = order
        self.exclude = set()
        self._rc = {}
        self._gc = {}
        import numpy as np
        self.np = np
        self.PA = np.array(self.pool, dtype=np.int8)
        self.RK = [np.array([S.rank[w][k] for k in range(S.n)], dtype=np.int8) for w in range(3)]
        self.zcache = {}

    def rec_of(self, A, B):
        k = (A, B)
        r = self._rc.get(k)
        if r is None:
            r = mk_rec(A, B); self._rc[k] = r
        return r

    def acc(self, cl, r, w):
        if r in cl.inst[w]: return True
        k = (r, w)
        g = self._gc.get(k)
        if g is None:
            g = is_empty(r) or cl.guidance(r, w); self._gc[k] = g
        return g

    def nm(self, X):
        if X in self.names: return self.names[X]
        return self.S.show(X)

    # ----------------------------------------------------------- families
    def family(self, N, C, Nname, Cname, Gkinds):
        S = self.S
        base = [k for k in range(S.n) if S.bounded[k] and N[k] == 2 and C[k] in (0, 1) and S.minworld[k] is not None]
        if not base: return []
        Gs = G_family(S, kinds=Gkinds, base=base, piece0=('single' not in Gkinds or True))
        # also all single pieces (both .0 and .1)
        singles = [(k,) for k in base]
        Gs = list(dict.fromkeys(singles + [G for G in Gs if len(G) > 1]))
        out = []
        for G in Gs:
            X = fill(N, G, [C[k] for k in G])
            out.append((N, C, G, X, Nname, Cname))
        return out

    def rule_world(self, pat, G, options):
        if self.rule is None: return options
        if callable(self.rule): w = self.rule(self.S, pat, G)
        else: w = self.rule.get(pat)
        if w is None: return options
        return [w] if w in options else []

    def Es(self, G):
        if self.Ekind == 'all': return E_family(G)
        if self.Ekind == 'single': return [(k,) for k in G]
        if self.Ekind == 'whole': return [tuple(G)]
        return E_family(G)

    # -------------------------------------------------------------- run
    def solve(self):
        S, V = self.S, self.V
        cl = new_closure(S, V)
        fam = []
        for j in range(3):
            fam += self.family(S.T, V[j], 'T', f'V{j+1}', self.Gkinds)
        self.fam = fam
        self.rivals = {}               # model -> name (rivals T and defenders must meet)
        for (N, C, G, X, Nn, Cn) in fam:
            self.rivals.setdefault(X, f'X[{Nn}<-{Cn}:{"+".join(S.names[k] for k in G)}]')
            R = fill(C, G, [2] * len(G))
            self.rivals.setdefault(R, f'R[{Cn}:{"+".join(S.names[k] for k in G)}]')
        done_rounds = 0
        cl, st = self._phase(cl, fam)
        if cl is None: return None, st
        while done_rounds < self.rounds:
            done_rounds += 1
            new = []
            for D in list(self.defenders):
                Dn = self.names[D]
                new += self.family(S.T, D, 'T', Dn, self.round_Gkinds)               # partial sources of D
                if self.Kfamily:
                    for j in range(3):
                        fj = self.family(D, V[j], Dn, f'V{j+1}', self.round_Gkinds)
                        # skip G inside Sil(T): same record as T's family (IB)
                        new += [f for f in fj if any(S.T[k] != 2 for k in f[2])]
            seen = {(f[3], f[1]) for f in fam}
            new = [f for f in new if (f[3], f[1]) not in seen]
            if self.verbose: print(f'  round {done_rounds}: {len(new)} new family records, |P|={len(cl.P)}'); sys.stdout.flush()
            if not new: break
            fam += new
            for (N, C, G, X, Nn, Cn) in new:
                self.rivals.setdefault(X, f'X[{Nn}<-{Cn}:{"+".join(S.names[k] for k in G)}]')
                self.rivals.setdefault(fill(C, G, [2] * len(G)), f'R[{Cn}:{"+".join(S.names[k] for k in G)}]')
            cl, st = self._phase(cl, fam)
            if cl is None: return None, st
        self.final = cl
        return cl, 'clean'

    def _phase(self, cl, fam):
        """greedy over obligations until none is open; returns (closure, status)."""
        S = self.S
        while True:
            ob = self.next_obligation(cl, fam)
            if ob is None: return cl, 'clean'
            self.nodes += 1
            opts = self.options(cl, ob)
            fails = []
            ok = False
            for q in opts:
                c2 = apply(cl, q)
                if c2.failure is None and q and q[0][0] == 'dom' and q[0][1] not in cl.P:
                    C = q[0][1]
                    rT = mk_rec(S.T, C)
                    if not any(c2.accepted(rT, w) for w in FULL):
                        c3 = None
                        for w in FULL:
                            if improvement(S, rT, w): continue
                            c3 = apply(c2, [('cmp', S.T, C, w)])
                            if c3.failure is None: break
                        if c3 is None or c3.failure is not None:
                            fails.append((q, c3 if c3 is not None else c2)); continue
                        c2 = c3
                if c2.failure is None:
                    cl = c2; ok = True
                    self.commit(ob, q, cl)
                    break
                fails.append((q, c2))
            if not ok:
                return None, ('stuck', ob, fails, cl)

    def commit(self, ob, q, cl):
        for r in q:
            if r[0] == 'dom':
                C = r[1]
                if C not in self.names:
                    self.names[C] = f'D{len(self.defenders)+1}'
                    self.defenders.append(C)
                self.dom_of[r[2]] = C
                t = self.ztags.get(r[2])
                if t is not None: self.serves.setdefault(C, set()).add(t)
            if ob[0] == 'def' and r[0] == 'cmp':
                self.def_world[mk_rec(r[1], r[2])] = r[3]
        if self.verbose and q and q[0][0] == 'dom':
            pass

    # ------------------------------------------------------- obligations
    def dominated(self, cl, Z):
        if Z in cl.P: return True
        r_ok = lambda N: all(self.acc(cl, self.rec_of(N, Z), w) for w in range(3))
        if Z in self.dom_of and r_ok(self.dom_of[Z]): return True
        for N in cl.P:
            if r_ok(N):
                self.dom_of[Z] = N
                t = self.ztags.get(Z)
                if t is not None: self.serves.setdefault(N, set()).add(t)
                return True
        return False

    def next_obligation(self, cl, fam):
        S = self.S
        sat = self.sat
        # 1. defences of the family records
        for f in fam:
            key = ('def', f[0], f[3])
            if key in sat: continue
            N, C, G, X, Nn, Cn = f
            sup = FULL if N == S.T else self.support(N)
            r = self.rec_of(N, X)
            if not any(self.acc(cl, r, w) for w in sup):
                return ('def', f)
            sat.add(key)
        # 1b. T competitive against every member of P (before new dominators are chosen)
        for N in list(cl.P):
            if N == S.T: continue
            key = ('cmpT', N)
            if key in sat: continue
            if not any(self.acc(cl, self.rec_of(S.T, N), w) for w in FULL):
                return ('cmpT', S.T, N, FULL)
            sat.add(key)
        # 2. dominators for every Z at every accepting world (and for X, R if domXR)
        for f in fam:
            N, C, G, X, Nn, Cn = f
            if self.domXR:
                ys = []
                if 'X' in self.domXR: ys.append(X)
                if 'R' in self.domXR:
                    Rr = self.rcache.setdefault((C, G), fill(C, G, [2] * len(G)))
                    if Cn in ('V1', 'V2', 'V3') or self.family_sep == 'C': self.ztags.setdefault(Rr, Cn)
                    ys.append(Rr)
                for Y in ys:
                    key = ('dom', Y)
                    if key in sat: continue
                    if not self.dominated(cl, Y):
                        return ('dom', f, Y, None)
                    sat.add(key)
            r = self.rec_of(N, X)
            for w in range(3):
                kw = ('acc', r, w)
                if kw not in sat:
                    if not self.acc(cl, r, w): continue
                    sat.add(kw)
                for E in self.Es(G):
                    zk = (C, G, E, w)
                    Z = self.zcache.get(zk)
                    if Z is None:
                        R = fill(C, G, [2] * len(G))
                        Z = fill(R, E, [wcorrect(S, k, w) for k in E])
                        self.zcache[zk] = Z
                        if Cn in ('V1', 'V2', 'V3') or self.family_sep == 'C': self.ztags.setdefault(Z, Cn)
                        self.rivals.setdefault(Z, f'Z[{Cn}:{"+".join(S.names[k] for k in G)}|E={"+".join(S.names[k] for k in E)}|w{w+1}]')
                    key = ('dom', Z)
                    if key in sat: continue
                    if not self.dominated(cl, Z):
                        return ('dom', f, Z, w)
                    sat.add(key)
        # 3. T competitive against members of P and all rivals
        for N in list(cl.P) + list(self.rivals):
            if N == S.T: continue
            key = ('cmpT', N)
            if key in sat: continue
            if not any(self.acc(cl, self.rec_of(S.T, N), w) for w in FULL):
                return ('cmpT', S.T, N, FULL)
            sat.add(key)
        # 4. registered defenders competitive on their support
        if self.Kcompete:
            for D in self.defenders:
                sup = self.support(D)
                for Y in list(cl.P) + list(self.rivals):
                    if Y == D: continue
                    key = ('cmpK', D, Y)
                    if key in sat: continue
                    if not any(self.acc(cl, self.rec_of(D, Y), w) for w in sup):
                        return ('cmpK', D, Y, sup)
                    sat.add(key)
        return None

    def options(self, cl, ob):
        S = self.S
        if ob[0] == 'def':
            N, C, G, X, Nn, Cn = ob[1]
            sup = FULL if N == S.T else self.support(N)
            r = mk_rec(N, X)
            pat = pattern(S, C, G)
            ws = [w for w in sup if not improvement(S, r, w)]
            ws = self.rule_world(pat, G, ws)
            if self.w_pref is not None: ws = sorted(ws, key=lambda w: self.w_pref(S, pat, G, w))
            return [[('cmp', N, X, w)] for w in ws]
        if ob[0] in ('cmpT', 'cmpK'):
            _, A, B, sup = ob
            r = mk_rec(A, B)
            return [[('cmp', A, B, w)] for w in sup if not improvement(S, r, w)]
        if ob[0] == 'dom':
            Z = ob[2]
            return self._dom_options(cl, Z)

    def ok_mask(self, Z):
        """pool members C with rec(C, Z) not a weak improvement at any world"""
        np = self.np
        Za = np.array(Z, dtype=np.int8)
        diff = self.PA != Za[None, :]
        ok = diff.any(axis=1)
        ar = np.arange(self.S.n)
        for w in range(3):
            RK = self.RK[w]
            d = RK[ar, Za][None, :].astype(np.int16) - RK[ar[None, :], self.PA].astype(np.int16)
            imp = np.all(np.where(diff, d <= 0, True), axis=1) & diff.any(axis=1)
            ok &= ~imp
        return ok

    def ztag(self, Z):
        return self.ztags.get(Z)

    def tag_ok(self, N, Z):
        if not self.family_sep: return True
        t = self.ztag(Z)
        if t is None: return True
        s = self.serves.get(N, set())
        return not (s - {t})

    def _dom_options(self, cl, Z):
        S = self.S
        if self.prefer_existing:
            for N in list(cl.P):
                if N != Z and N not in self.exclude and self.tag_ok(N, Z) and not weak_improvement_any(S, N, Z): yield [('dom', N, Z)]
        ok = self.ok_mask(Z)
        idx = self.np.nonzero(ok)[0]
        if self.order == 'nearZ':
            Za = self.np.array(Z, dtype=self.np.int8)
            dz = (self.PA[idx] != Za[None, :]).sum(axis=1)
            idx = idx[self.np.argsort(dz, kind='stable')]
        n = 0
        for i in idx:
            C = self.pool[i]
            if C in cl.P or C in self.exclude: continue
            if not self.tag_ok(C, Z): continue
            yield [('dom', C, Z)]; n += 1
            if n >= self.max_cands: break

    # ------------------------------------------------------------ report
    def realised_rule(self, cl=None):
        """pattern -> Counter of worlds at which T's defence record is accepted"""
        cl = cl or self.final
        S = self.S
        out = defaultdict(Counter)
        for (N, C, G, X, Nn, Cn) in self.fam:
            if N != S.T or Cn not in ('V1', 'V2', 'V3'): continue
            r = mk_rec(N, X)
            ws = tuple(w + 1 for w in range(3) if cl.accepted(r, w))
            out[pstr(pattern(S, C, G))][ws] += 1
        return out


def describe_failure(J, st, minimise_it=True, maxlines=40):
    S = J.S
    _, ob, fails, cl = st
    lines = []
    if ob[0] == 'def':
        f = ob[1]
        lines.append(f'stuck at defence of {J.rivals.get(f[3], "?")} by {f[4]}  pattern {pstr(pattern(S, f[1], f[2]))}')
    elif ob[0] == 'dom':
        lines.append(f'stuck at dominator for {J.rivals.get(ob[2], S.show(ob[2]))}')
    else:
        lines.append(f'stuck at {ob[0]}: {J.nm(ob[1])} R_w {J.rivals.get(ob[2], J.nm(ob[2]))}')
    lines.append(f'  options tried: {len(fails)}; failure kinds: {Counter(c.failure.kind for _, c in fails)}')
    return lines, fails


def minimal_failures(J, st, k=2, width=260):
    """deletion-minimal failing request sets (with derivations) for the first k
    failing options of a stuck obligation."""
    from exp_selfdom import minimise
    S, V = J.S, J.V
    _, ob, fails, cl = st
    nm = dict(J.names); nm.update({a: b for a, b in J.rivals.items() if a not in nm})
    out = []
    for q, c in fails[:k]:
        if c is None or c.failure is None: continue
        sub = [c.requests[i] for i in sorted(c.failure_support())]
        sub = [x for x in sub if x[0] != 'reg' or x[1] not in (S.T,) + tuple(V)]
        m, cm = minimise(S, V, sub)
        out.append(f'--- minimal failing set: {len(m)} requests, {cm.failure.kind}')
        for x in m: out.append('    ' + cm.req_str(x, nm)[:width])
        for l in cm.derivation(names=nm): out.append('      ' + l[:width])
    return out
