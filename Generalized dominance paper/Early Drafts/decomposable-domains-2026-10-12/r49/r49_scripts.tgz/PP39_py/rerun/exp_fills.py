"""PP36 exp_fills (CHECKED; probe only): the fills X = T[G -> V_j] are incoherent,
so KKM also demands dominators for them.  Joint greedy run of the vertex family
with dominators required for X, R and Z (std cells, single pieces and same-direction
pairs, rule all-low).  Prints the stuck point with deletion-minimal failing sets.
"""
import sys, time
from cells36 import standard
from family36 import *
from solver36 import *
from joint36 import *
from exp_rules import mk_rule

S = standard(); V = vertex_models(S)
t = time.time()
J = Joint(S, V, rule=mk_rule('low'), pool=S.coherent_models(), Gkinds=('single', 'samedir'), domXR='XR')
cl, st = J.solve()
print(f'fills probe (std, single+samedir, X, R and Z dominated): {"CLEAN" if cl is not None else "STUCK"} '
      f'({time.time()-t:.0f}s, {J.nodes} steps, |P| at stop {len(st[3].P) if cl is None else len(cl.P)})')
if cl is None:
    lines, fails = describe_failure(J, st)
    print('\n'.join(lines))
    from collections import Counter
    shapes = Counter()
    from exp_selfdom import minimise
    for q, c in fails[:80]:
        sub = [c.requests[i] for i in sorted(c.failure_support())]
        sub = [x for x in sub if x[0] != 'reg' or x[1] not in (S.T,) + tuple(V)]
        m, cm = minimise(S, V, sub)
        others = [J.nm(x[1]) for x in m if x[0] == 'dom' and x[1] != q[0][1]]
        shapes[(len(m), cm.failure.kind, tuple(others))] += 1
    print('shapes of minimal failing sets for the first 80 candidates (size, kind, other dominators involved):')
    for k, v in shapes.most_common(): print('   ', v, k)
    print('\n'.join(minimal_failures(J, st, k=3)))
    for D in J.defenders: print('  ', J.names[D], S.classify(D), S.show(D))
