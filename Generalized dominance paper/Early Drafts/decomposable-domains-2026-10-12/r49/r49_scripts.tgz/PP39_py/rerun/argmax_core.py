"""PP34 diagnostic (CHECKED on cells): unsatisfiable cores for the 'exact' largest-loss rule.

The rule's acceptances and refusals are passed as assumptions (selector literals), as are the
obligations of N_A on each edge (H_A) and T's undominatedness; the solver returns a core, which is
then shrunk to a minimal one by deletion.  Prints the minimal core in words.
Usage: python3 -B argmax_core.py <classes e.g. 00112> <masses e.g. 12122>
"""
import sys, itertools
from lib34 import Cells, Problem, A, S, B
from argmax_sat import alpha


def main(cls, mass):
    c = Cells(cls); P = Problem(c); P.base(); n = c.n
    T = [S] * n; NA = [A] * n
    nv = [3 * c.N]
    def sel():
        nv[0] += 1
        return nv[0]
    label = {}
    P.competitive(T, (0, 1, 2))
    s = sel(); label[s] = 'T undominated'
    for r in c.records_from(T):
        if r == 0: continue
        ri = int(c.inv[r])
        for w0 in range(3):
            P.add([-s] + [-P.var(w, ri) for w in range(3)] + [P.var(w0, r)])
    for e in ((0, 1), (0, 2), (1, 2)):
        s = sel(); label[s] = f'N_A competitive on edge {e[0]+1}{e[1]+1}'
        for r in c.records_from(NA):
            if r == 0: continue
            P.add([-s] + [P.var(w, r) for w in e])
    s = sel(); label[s] = 'N_A undominated'
    for r in c.records_from(NA):
        if r == 0: continue
        ri = int(c.inv[r])
        for w0 in range(3):
            P.add([-s] + [-P.var(w, ri) for w in range(3)] + [P.var(w0, r)])
    for vals in itertools.product((None, A, B), repeat=n):
        if all(v is None for v in vals): continue
        new = [S if v is None else v for v in vals]
        r = c.rec(T, new); w0, loss = alpha(cls, mass, vals)
        name = ''.join('.' if v is None else 'ASB'[v] for v in vals)
        s = sel(); label[s] = f'accept S->{name} at {w0+1} (losses {loss})'
        P.add([-s, P.var(w0, r)])
        for w in range(3):
            if w != w0 and c.kind[w, r] == 3:
                s = sel(); label[s] = f'refuse S->{name} at {w+1} (losses {loss}; rule world {w0+1})'
                P.add([-s, -P.var(w, r)])
    ass = list(label)
    ok = P.solve(assumptions=ass)
    print(f'classes {[k+1 for k in cls]} masses {mass}: {"SAT" if ok else "UNSAT"}')
    if ok: return
    core = list(P.s.get_core())
    for lit in list(core):             # deletion-based minimisation
        trial = [x for x in core if x != lit]
        if not P.solve(assumptions=trial):
            core = trial
    print(f'  minimal core ({len(core)} items):')
    for lit in core:
        print('   ', label[lit])


if __name__ == '__main__':
    main([int(ch) for ch in sys.argv[1]], [int(ch) for ch in sys.argv[2]])
