"""PP38 second_gen_mc.py -- NUMERICS (Gaussian Monte Carlo, common random numbers).

Second generation under the l^T kernel (eps = 3/10): a forced rival of a registered EDGE model.
N = B_12(t0), the Bayes model of the edge [e1,e2] at ratio t0 = lambda_1/lambda_2 (t0 = 1 and t0 = 2).
G' = ball (radius 0.2) around h = (1, 1, -1.9) in Sil(T) n M_3, where N says A (correct at 1 and 2).
T's departure (G', S -> A) is a pure improvement at worlds 1, 2, so it is accepted only at w = 3, and N
must refuse there N -> Z' with Z' = N[G' -> S, E' -> 3-correct] (PP30 Thm 3.1(b) / PP33 Prop 2.1(f)).
Question: is Z' l-dominated (Delta L_v(C) <= Delta L_v(Z') at all three worlds) by any registered
model C, i.e. any coherent l^T-Bayes model (T, the three boundary families B_ij(t), the vertices)?
Output: for each candidate family, min over the grid of max_v (Delta L_v(C) - Delta L_v(Z')).
A positive minimum means no l-endorsed dominator in that family (Section 6.4 of the note).
Run: python3 -I -B second_gen_mc.py > second_gen_mc.out
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import field38 as f

rng = np.random.default_rng(3839)
SQ = (2 * np.pi) ** -1.5
h = np.array([1.0, 1.0, -1.9]); R = 0.2
nb = 400_000
v = rng.standard_normal((nb, 3)); v /= np.linalg.norm(v, axis=1)[:, None]
gb = h + v * (R * rng.random(nb) ** (1 / 3))[:, None]
wb = (4 / 3) * np.pi * R ** 3 * SQ * np.exp(-0.5 * (gb * gb).sum(1)) * 2.0
print(f"ball: T silent on {np.mean(f.T_answer(gb) == 0):.4f}; minority world 3 on {np.mean(f.minority(gb) == 2):.4f}; mass {wb.mean():.3e}")
flb = f.field(gb)

n = 1_500_000
g = rng.standard_normal((n, 3)); fl = f.field(g)


def edge_bayes(i, j, t):
    lam = [0.0, 0.0, 0.0]; lam[i] = t / (1 + t); lam[j] = 1 / (1 + t)
    return lam


def L(adv):
    pen = f.penalty(adv, g, fl)
    return pen.mean(0), pen


for t0 in (1.0, 2.0):
    Nadv = f.bayes(g, edge_bayes(0, 1, t0), fl)
    LN, penN = L(Nadv)
    Nb = f.bayes(gb, edge_bayes(0, 1, t0), flb)
    print(f"\nN = B_12({t0}); N says A on the ball: {np.mean(Nb == -np.sign(gb[:,2])):.4f}")
    rivals = []
    for label, newadv in (("E' = G' (Z' = N[G' -> B])", np.sign(gb[:, 2]).astype(int)),
                          ("E' = 0  (Z' = N[G' -> S])", np.zeros(nb, int))):
        dZ = ((f.penalty(newadv, gb, flb) - f.penalty(Nb, gb, flb)) * wb[:, None]).mean(0)
        print(f"  rival {label}: Delta L(Z') = {np.round(dZ, 6)}")
        rivals.append((label, dZ))
    cands = [("T", f.T_answer(g))] + [(f"V{k+1}", f.V(k, g)) for k in range(3)]
    for (i, j) in ((0, 1), (0, 2), (1, 2)):
        ts = np.geomspace(0.02, 50, 30)
        if (i, j) == (0, 1):
            ts = np.concatenate([ts, t0 * (1 + np.linspace(-0.05, 0.05, 21))])
        for t in ts:
            if (i, j) == (0, 1) and abs(t - t0) < 1e-12:
                continue
            cands.append((f"B_{i+1}{j+1}", f.bayes(g, edge_bayes(i, j, t), fl)))
    dCs = [(name, (f.penalty(adv, g, fl) - penN).mean(0)) for name, adv in cands]
    for label, dZ in rivals:
        print(f"  rival {label}:")
        best = {}
        for name, dC in dCs:
            gap = np.max(dC - dZ)
            if name not in best or gap < best[name][0]:
                best[name] = (gap, dC)
        for name, (gap, dC) in best.items():
            print(f"    {name:5s}: min over grid of max_v(Delta L_v(C) - Delta L_v(Z')) = {gap:+.6f}   (Delta L(C) there = {np.round(dC, 6)})")
# standard error of an in-family difference near t0 = 1, for scale
adv1 = f.bayes(g, edge_bayes(0, 1, 1.0), fl); adv2 = f.bayes(g, edge_bayes(0, 1, 1.02), fl)
dd = f.penalty(adv2, g, fl) - f.penalty(adv1, g, fl)
print("\nscale: B_12(1.02) - B_12(1): mean", np.round(dd.mean(0), 6), " s.e.", np.round(dd.std(0) / np.sqrt(n), 7))
print("done")
