"""PP38 budget_mc.py -- NUMERICS (Gaussian Monte Carlo; no proof depends on it).

First generation of the repair class under the l^T kernel (eps = 3/10), on PP30's two balls for V_1:
  G = B+ u B-,  B+ around h+ = (0.15,-0.85,1.15) in M_2,  B- around h- = (0.15,1.15,-0.85) in M_3.
(1) world values Phi_w(d) of T's departure d = (G, S -> V_1); the accepting worlds.
(2) for each accepting w: Z_w = V_1[G -> S, E_w -> w-correct] (E_w the ball in M_w);
    Delta L_v(Z) = L_v(Z) - L_v(V_1).
(3) candidate dominators: the boundary-Bayes models B_{1x}(t) of the edge [e_1,e_x] (x = 2,3) at ratio
    t = lambda_1/lambda_x; their Delta L_v, the budget test Delta L_1(C) < Delta L_1(Z) (Theorem 3.1 of
    PP33 under a potential = PP33 Cor 3.2), compensation masses at the two other worlds, and the l-values
    of rec(C, Z) at all three worlds.
(4) the margin of Theorem 6.3: for the edge family B_12(t), min over w in {1,2} of L_w(B) - L_w(T) < 0.
(5) isolation of T in loss space (Lemma 6.5): sum_v (L_v(C) - L_v(T)) > 0 for registered C != T.
Run: python3 -I -B budget_mc.py > budget_mc.out
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import field38 as f

rng = np.random.default_rng(3838)
c, L, d = f.consts()
HP = np.array([0.15, -0.85, 1.15])
HM = np.array([0.15, 1.15, -0.85])
R = 0.05
NB = 400_000
SQ = (2 * np.pi) ** -1.5


def phi(g):
    return SQ * np.exp(-0.5 * (g * g).sum(axis=1))


def ball(h):
    v = rng.standard_normal((NB, 3)); v /= np.linalg.norm(v, axis=1)[:, None]
    rad = R * rng.random(NB) ** (1 / 3)
    g = h + v * rad[:, None]
    w = (4 / 3) * np.pi * R ** 3 * phi(g) * 2.0   # factor 2: the problem set is B u -B
    return g, w


def est(vals, w):
    x = vals * w[:, None] if vals.ndim == 2 else vals * w
    m = x.mean(axis=0)
    se = x.std(axis=0) / np.sqrt(len(w))
    return m, se


print("eps = 0.3, c = %.4f, L = %.4f, d = %.4f, ball radius %.3f" % (c, L, d, R))
balls = {}
for name, h in (("B+", HP), ("B-", HM)):
    g, w = ball(h)
    tA = f.T_answer(g)
    k = f.minority(g)
    print(f"{name}: T silent on {np.mean(tA == 0):.4f} of samples; V_1 answers + on {np.mean(np.sign(g[:,0]) > 0):.4f}; "
          f"minority world (1-based) values {sorted(set((k+1).tolist()))}; mass {w.mean():.3e}")
    balls[name] = (g, w)

# (1) departure d = (G, S -> V_1)
phi_d = np.zeros(3); se_d = np.zeros(3)
for name in balls:
    g, w = balls[name]
    fl = f.field(g)
    dl = f.penalty(f.V(0, g), g, fl) - f.penalty(np.zeros(len(g), int), g, fl)
    m, s = est(dl, w); phi_d += m; se_d += s ** 2
print("(1) Phi_w(d), d = (G, S->V_1):", np.round(phi_d, 6), " s.e.", np.round(np.sqrt(se_d), 7))
acc = [w for w in range(3) if phi_d[w] >= 0]
print("    accepting worlds (1-based):", [w + 1 for w in acc])

# (2) the rivals Z_w
Eball = {1: "B+", 2: "B-"}            # 0-based world -> ball in its class
dZ = {}
for w in acc:
    tot = np.zeros(3); se = np.zeros(3)
    for name in balls:
        g, wt = balls[name]
        fl = f.field(g)
        adv = np.zeros(len(g), int)
        if name == Eball[w]:
            adv = np.sign(g[:, w]).astype(int)      # w-correct on E
        dl = f.penalty(adv, g, fl) - f.penalty(f.V(0, g), g, fl)
        m, s = est(dl, wt); tot += m; se += s ** 2
    dZ[w] = tot
    print(f"(2) Z_{w+1}: Delta L_v(Z) = {np.round(tot, 6)}  (s.e. {np.round(np.sqrt(se), 7)})")


# (3) boundary-Bayes dominators B_{1x}(t)
def wedge_integrals(x, t, n=2_000_000):
    """Delta L_v(C) for C = Bayes on edge [e_1,e_x] at ratio t = lambda_1/lambda_x, and masses
    where C is strictly better than V_1 at each world."""
    tau0 = t / L if t >= L * (1 / L) else None      # F^{-1}(t) = t/L for t >= 1
    gx = rng.standard_normal(n); gy = rng.standard_normal(n)
    half = np.abs(gx) / tau0
    g1 = (2 * rng.random(n) - 1) * half
    wt = (2 * half) * np.exp(-0.5 * g1 ** 2) / np.sqrt(2 * np.pi)
    g = np.zeros((n, 3)); g[:, 0] = g1; g[:, x] = gx; g[:, 3 - x] = gy
    keep = g1 * gx < 0                       # W_1x
    th = np.abs(gx) / np.maximum(np.abs(g1), 1e-300)
    adv = np.sign(g1).astype(int)            # V_1
    Fv = f.Ff(th); Gv = f.Gf(th)
    advC = np.where(Fv < t, adv, np.where(Gv > t, np.sign(gx).astype(int), 0))
    advC = np.where(keep, advC, adv)
    fl = f.field(g)
    dl = f.penalty(advC, g, fl) - f.penalty(adv, g, fl)
    better = (f.rank(advC, g) < f.rank(adv, g)).astype(float)
    m, s = est(dl, wt)
    mb, _ = est(better, wt)
    return m, s, mb

print("(3) boundary-Bayes dominators C = B_1x(t) (C differs from V_1 on W_1x n {theta_1x > t/L}):")
for w in acc:
    budget = dZ[w][0]
    print(f"  rival Z_{w+1}: budget Delta L_1(Z) = {budget:.3e}")
    for x in (1, 2):
        for t in (60, 120, 240, 480, 960):
            m, s, mb = wedge_integrals(x, t)
            val = dZ[w] - m          # l-values of rec(C, Z) at the three worlds
            ok = m[0] < budget
            print(f"    edge [e1,e{x+1}] t={t:4d}: Delta L(C) = {np.round(m, 6)} (s.e. {np.round(s, 7)}); "
                  f"budget {'OK ' if ok else 'NO '}; better-mass at worlds = {np.round(mb, 6)}; "
                  f"Phi_v(rec(C,Z)) = {np.round(val, 6)}")

# (4) margin of Theorem 6.3 for the family B_12(t)
n = 2_000_000
g = rng.standard_normal((n, 3)); fl = f.field(g)
LT = f.penalty(f.T_answer(g), g, fl).mean(axis=0)
print("(4) L_w(T) =", np.round(LT, 5))
for t in (0.05, 0.2, 0.5, 1.0, 2.0, 5.0, 20.0):
    lam = (t / (1 + t), 1 / (1 + t), 0.0)
    B = f.bayes(g, lam, fl)
    LB = f.penalty(B, g, fl).mean(axis=0)
    print(f"    t={t:5.2f}: L_w(B_12) - L_w(T) = {np.round(LB - LT, 5)};  min over w in {{1,2}} = {min(LB[0]-LT[0], LB[1]-LT[1]):.5f}")
# (5) isolation of T in loss space (Lemma 6.5): sum_v (L_v(C) - L_v(T)) for registered C != T
for kk in range(3):
    LV = f.penalty(f.V(kk, g), g, fl).mean(axis=0)
    print(f"(5) V_{kk+1}: L_v(V) - L_v(T) = {np.round(LV - LT, 5)}, sum = {np.sum(LV - LT):.5f}")
for t in (0.01, 1.0, 100.0):
    lam = (t / (1 + t), 1 / (1 + t), 0.0)
    LB = f.penalty(f.bayes(g, lam, fl), g, fl).mean(axis=0)
    print(f"(5) B_12(t={t}): sum_v (L_v(B) - L_v(T)) = {np.sum(LB - LT):.5f}")
print("done")
