"""PP38 jump_gap_mc.py -- NUMERICS (Gaussian Monte Carlo).

Hypothesis (H_k) of Theorem 6.3: for every Bayes model B of the edge [e1,e2] (ratio t = lambda_1/lambda_2),
L_3(B) > L_3(T).  Also the margin of Lemma 6.2: min(L_1(B)-L_1(T), L_2(B)-L_2(T)) < 0.
eps in {0.1, 0.3, 0.5, 0.9}; t on a log grid in [1e-3, 1e3] (t -> 0, oo give V_2, V_1).
Run: python3 -I -B jump_gap_mc.py > jump_gap_mc.out
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import field38 as f

rng = np.random.default_rng(3840)
n = 1_000_000
g = rng.standard_normal((n, 3))
for eps in (0.1, 0.3, 0.5, 0.9):
    fl = f.field(g, eps)
    penT = f.penalty(f.T_answer(g, eps), g, fl)
    LT = penT.mean(0)
    worst3, worstm = np.inf, -np.inf
    for t in np.geomspace(1e-3, 1e3, 61):
        B = f.bayes(g, (t / (1 + t), 1 / (1 + t), 0.0), fl)
        d = (f.penalty(B, g, fl) - penT)
        m, se = d.mean(0), d.std(0) / np.sqrt(n)
        worst3 = min(worst3, m[2] - 4 * se[2])
        worstm = max(worstm, min(m[0] + 4 * se[0], m[1] + 4 * se[1]))
    print(f"eps={eps}: L_w(T) = {np.round(LT, 4)}; min_t [L_3(B)-L_3(T) - 4se] = {worst3:+.4f}; "
          f"max_t min_(w=1,2) [L_w(B)-L_w(T) + 4se] = {worstm:+.4f}")
print("done")
