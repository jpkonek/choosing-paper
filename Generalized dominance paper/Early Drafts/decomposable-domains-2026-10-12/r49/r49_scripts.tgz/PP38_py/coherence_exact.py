"""PP38 coherence_exact.py -- CHECKED (exact rational arithmetic, fractions.Fraction).

The abstention field l^T (REFEREE_PP32_penalties §3.2) for eps in {1/10, 3/10, 1/2, 9/10}.
 (a) T1 is the u-Bayes model (random rational problems; uniqueness of the minimiser).
 (b) Edge weights (t/(1+t), 1/(1+t), 0): the Bayes model is D_K, K the edge segment with theta-thresholds
     F^{-1}(t) < G^{-1}(t) (always a non-degenerate segment: no precise edge model is l^T-Bayes).
 (c) Lemma 4.2 (coherence lemma): at every interior grid weight lambda != u the Bayes model is
     incoherent.  The witness is the one in the proof: two problems with the same Bayes answer (strict
     margins) whose midpoint has a different answer.  Case 'B' uses the convex kink of the
     B-boundary at s_j = 1/L; case 'A' (when (lam_i - lam_j)/lam_k = 1/2) uses the concave kink of the
     A-boundary at s_j = L.
 (d) Own-class identities used in Theorem 2.1(C): on M_1 u M_2, r_1 + r_2 = 2 for A, S, B; on M_3 every
     change away from A is a weak worsening at worlds 1 and 2.
 (e) Room (Prop 4.4): a mixed departure out of T on two nearby problems of Sil(T) n M_1 has positive
     l-value at all three worlds (pointwise bookkeeping; the continuum statement is proved in the note).
Run: python3 -I -B coherence_exact.py > coherence_exact.out
"""
import random
from fractions import Fraction as Fr
from itertools import product

random.seed(38)
fails = 0


def check(cond, msg):
    global fails
    if not cond:
        fails += 1
        print("FAIL:", msg)


def sgn(x):
    return (x > 0) - (x < 0)


def make(eps):
    c = (1 - eps) / 3
    L = (c + eps) / c
    d = 1 / (1 + L)

    def F(th):
        if th <= d:
            return th / (2 * d)
        if th <= 1 / L:
            return Fr(1, 2) + L * (th - d) / (2 * d)
        return L * th

    def Finv(y):
        if y <= Fr(1, 2):
            return 2 * d * y
        if y <= 1:
            return d + (y - Fr(1, 2)) * 2 * d / L
        return y / L

    def G(s):
        return 1 / F(1 / s)

    def Ginv(y):
        return 1 / Finv(1 / y)

    def field(g):
        s = [sgn(x) for x in g]
        pos = [w for w in range(3) if s[w] > 0]
        neg = [w for w in range(3) if s[w] < 0]
        k = pos[0] if len(pos) == 1 else (neg[0] if len(neg) == 1 else None)
        if k is None:
            return [(abs(x),) * 3 for x in g]
        gk = abs(g[k])
        out = []
        for w in range(3):
            if w == k:
                out.append((gk, gk, gk))
            else:
                sj = abs(g[w]) / gk
                out.append((gk * G(sj), gk * F(sj), abs(g[w])))
        return out
    return c, L, d, F, Finv, G, Ginv, field


def rank(a, g, w):
    if a == 0:
        return 1
    return 0 if a * sgn(g[w]) > 0 else 2


def cost(fld, a, g, lam):
    tot = 0
    for w in range(3):
        al, be, _ = fld[w]
        r = rank(a, g, w)
        tot += lam[w] * [0, al, al + be][r]
    return tot


def bayes(fld, g, lam):
    cs = {a: cost(fld, a, g, lam) for a in (1, -1, 0)}
    b = min(cs.values())
    arg = [a for a in cs if cs[a] == b]
    return (arg[0] if len(arg) == 1 else None), cs


def T_answer(g, eps):
    c = (1 - eps) / 3
    lo = c * sum(g) + eps * min(g)
    hi = c * sum(g) + eps * max(g)
    return 1 if lo > 0 else (-1 if hi < 0 else (0 if lo < 0 < hi else None))


def DK(V, g):
    vals = [sum(a * b for a, b in zip(v, g)) for v in V]
    return 1 if min(vals) > 0 else (-1 if max(vals) < 0 else (0 if min(vals) < 0 < max(vals) else None))


def emb(i, j, k, si, sj, sk):
    g = [0, 0, 0]
    g[i], g[j], g[k] = si, sj, sk
    return tuple(g)


tot_c = 0
for eps in [Fr(1, 10), Fr(3, 10), Fr(1, 2), Fr(9, 10)]:
    c, L, d, F, Finv, G, Ginv, field = make(eps)
    u = (Fr(1, 3),) * 3
    # (a)
    na = 0
    for _ in range(3000):
        g = tuple(Fr(random.randint(-300, 300), 41) for _ in range(3))
        if 0 in [sgn(x) for x in g]:
            continue
        tA = T_answer(g, eps)
        b, _ = bayes(field(g), g, u)
        if tA is None or b is None:
            continue
        check(b == tA, f"(a) eps={eps} g={g}")
        na += 1
    # (b) edge [e1,e2]; theta = |g2|/|g1|
    nb = 0
    for num in range(1, 90, 3):
        t = Fr(num, 30)
        lam = (t / (1 + t), 1 / (1 + t), Fr(0))
        tau0, tau1 = Finv(t), Ginv(t)
        check(tau0 < tau1, "(b) segment non-degenerate")
        x0, x1 = tau0 / (1 + tau0), tau1 / (1 + tau1)
        K = [(x0, 1 - x0, Fr(0)), (x1, 1 - x1, Fr(0))]
        for _ in range(30):
            g = tuple(Fr(random.randint(-300, 300), 41) for _ in range(3))
            if 0 in [sgn(x) for x in g]:
                continue
            b, _ = bayes(field(g), g, lam)
            dk = DK(K, g)
            if b is None or dk is None:
                continue
            check(b == dk, f"(b) eps={eps} t={t} g={g}")
            nb += 1
    # (c) coherence lemma witnesses on the grid with denominator N
    N = 15
    ncA = ncB = 0
    for a1 in range(1, N):
        for a2 in range(1, N - a1):
            a3 = N - a1 - a2
            lam = (Fr(a1, N), Fr(a2, N), Fr(a3, N))
            if lam == u:
                continue
            i = max(range(3), key=lambda w: lam[w])
            j = min(range(3), key=lambda w: lam[w])
            k = 3 - i - j
            li, lj, lk = lam[i], lam[j], lam[k]
            y0 = (li - lj) / lk
            if y0 != Fr(1, 2):
                def b_(s):
                    return Finv((li - lj * F(s)) / lk)
                s0 = 1 / L
                dl = s0 / 50
                for _ in range(8):           # keep both side points inside the linear pieces
                    sm, sp = s0 - dl, s0 + dl
                    if F(sp) < li / lj and sm > d:
                        break
                    dl /= 2
                avg = (b_(sm) + b_(sp)) / 2
                gap = avg - b_(s0)
                check(gap > 0, f"(c-B) no convex kink lam={lam}")
                eta = gap / 3
                pts = [(sm, b_(sm) - eta), (sp, b_(sp) - eta)]
                mid = ((sm + sp) / 2, avg - eta)
                ans = []
                for sj, sk in pts + [mid]:
                    g = emb(i, j, k, Fr(1), -sj, -sk)
                    b, _ = bayes(field(g), g, lam)
                    ans.append(b)
                check(ans[0] == 1 and ans[1] == 1 and ans[2] is not None and ans[2] != 1,
                      f"(c-B) eps={eps} lam={lam} answers {ans}")
                ncB += 1
            else:
                def a_(s):
                    return Ginv((li - lj * G(s)) / lk)
                s0 = L
                dl = s0 / 50
                avg = (a_(s0 - dl) + a_(s0 + dl)) / 2
                gap = a_(s0) - avg
                check(gap > 0, f"(c-A) no concave kink lam={lam}")
                eta = gap / 3
                pts = [(s0 - dl, a_(s0 - dl) + eta), (s0 + dl, a_(s0 + dl) + eta)]
                mid = (s0, avg + eta)
                ans = []
                for sj, sk in pts + [mid]:
                    g = emb(i, j, k, Fr(1), -sj, -sk)
                    b, _ = bayes(field(g), g, lam)
                    ans.append(b)
                check(ans[0] == -1 and ans[1] == -1 and ans[2] is not None and ans[2] != -1,
                      f"(c-A) eps={eps} lam={lam} answers {ans}")
                ncA += 1
    tot_c += ncA + ncB
    print(f"eps={eps}: (a) {na} problems, T1 = unique u-Bayes; (b) {nb} edge checks, Bayes = segment D_K;"
          f" (c) {ncB} grid weights incoherent via B-kink, {ncA} via A-kink (all interior grid weights != u)")

# (d) own-class identities (ranks of A, S, B)
for k in range(3):
    for a in ('A', 'S', 'B'):
        maj = {'A': 0, 'S': 1, 'B': 2}[a]
        r = [maj] * 3
        r[k] = 2 - maj
        if k in (0, 1):
            check(r[0] + r[1] == 2, "(d) r1 + r2 = 2 on M_1, M_2")
        else:
            check(a == 'A' or (r[0] > 0 and r[1] > 0), "(d) M_3")
print("(d) own-class identities: OK" if fails == 0 else "(d) failures above")

# (e) room: mixed departure out of T on Sil(T) n M_1 (eps = 3/10)
eps = Fr(3, 10)
c, L, d, F, Finv, G, Ginv, field = make(eps)
g1 = (Fr(1), Fr(-45, 100), Fr(-45, 100))      # in Sil(T) n M_1
g2 = (Fr(1), Fr(-46, 100), Fr(-44, 100))
for g in (g1, g2):
    check(T_answer(g, eps) == 0, f"(e) T not silent at {g}")
f1, f2 = field(g1), field(g2)
# S -> B (accept g, minority answer) at g1 with mass m1, S -> A (accept -g) at g2 with mass m2
m2 = Fr(1)
m1 = m2 * f2[0][1] / f1[0][0] * Fr(99, 100)   # world-1: gain alpha_1 m1 < loss beta_1 m2
phi = []
for w in range(3):
    dB = (cost(f1, 1, g1, [int(v == w) for v in range(3)]) - cost(f1, 0, g1, [int(v == w) for v in range(3)])) * m1
    dA = (cost(f2, -1, g2, [int(v == w) for v in range(3)]) - cost(f2, 0, g2, [int(v == w) for v in range(3)])) * m2
    phi.append(dB + dA)
check(all(p > 0 for p in phi), f"(e) values {phi}")
print("(e) l-values of T -> T[g1 -> B, g2 -> A] at worlds 1,2,3:", [float(p) for p in phi])
print("ALL PASS" if fails == 0 else f"{fails} FAILURES")
