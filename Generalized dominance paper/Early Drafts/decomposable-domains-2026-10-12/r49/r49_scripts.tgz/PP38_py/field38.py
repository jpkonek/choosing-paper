"""PP38 shared code (floating point, vectorised): the abstention field l^T of REFEREE_PP32_penalties §3.2.

Problems g in R^3 modulo sign.  Advice: +1 accept g, -1 accept -g, 0 silent, 2 contradiction.
Rank at world w: correct 0, silent 1, wrong 2, contradictory 3.
Field (per problem g, world w): alpha_w = l(silent)-l(correct), beta_w = l(wrong)-l(silent),
gamma_w = l(contra)-l(wrong); l(correct) = 0.
On M_k (k = minority world): alpha_k = beta_k = gamma_k = |g_k|;
for j != k, with s_j = |g_j|/|g_k|: alpha_j = |g_k| G(s_j), beta_j = |g_k| F(s_j), gamma_j = |g_j|.
On unanimous problems alpha = beta = gamma = |g_w|.
"""
import numpy as np

EPS = 0.3


def consts(eps=EPS):
    c = (1 - eps) / 3
    L = (c + eps) / c
    d = 1 / (1 + L)
    return c, L, d


def Ff(th, eps=EPS):
    c, L, d = consts(eps)
    th = np.asarray(th, dtype=float)
    return np.where(th <= d, th / (2 * d),
                    np.where(th <= 1 / L, 0.5 + L * (th - d) / (2 * d), L * th))


def Gf(s, eps=EPS):
    s = np.asarray(s, dtype=float)
    with np.errstate(divide='ignore'):
        return 1.0 / Ff(1.0 / s, eps)


def minority(g):
    """minority world index per row (-1 for unanimous)."""
    sg = np.sign(g)
    npos = (sg > 0).sum(axis=1)
    k = np.full(len(g), -1)
    one_pos = npos == 1
    one_neg = npos == 2
    k[one_pos] = np.argmax(sg[one_pos] > 0, axis=1)
    k[one_neg] = np.argmax(sg[one_neg] < 0, axis=1)
    return k


def field(g, eps=EPS):
    """returns alpha, beta, gamma arrays of shape (n,3)."""
    n = len(g)
    ag = np.abs(g)
    al = ag.copy(); be = ag.copy(); ga = ag.copy()
    k = minority(g)
    for kk in range(3):
        m = k == kk
        if not m.any():
            continue
        gk = ag[m, kk]
        for j in range(3):
            if j == kk:
                continue
            s = ag[m, j] / gk
            al[m, j] = gk * Gf(s, eps)
            be[m, j] = gk * Ff(s, eps)
    return al, be, ga


def rank(adv, g):
    """adv shape (n,), values in {1,-1,0,2}; returns ranks (n,3)."""
    sg = np.sign(g)
    r = np.empty(g.shape, dtype=int)
    for w in range(3):
        corr = adv * sg[:, w] > 0
        r[:, w] = np.where(adv == 2, 3, np.where(adv == 0, 1, np.where(corr, 0, 2)))
    return r


def penalty(adv, g, fld):
    al, be, ga = fld
    r = rank(adv, g)
    out = np.where(r == 0, 0.0, np.where(r == 1, al, np.where(r == 2, al + be, al + be + ga)))
    return out  # (n,3)


def bayes(g, lam, fld):
    """unique-a.e. minimiser among {+1,-1,0} at weight lam."""
    costs = []
    for a in (1, -1, 0):
        costs.append(penalty(np.full(len(g), a), g, fld) @ np.asarray(lam, float))
    costs = np.stack(costs, axis=1)
    return np.array([1, -1, 0])[np.argmin(costs, axis=1)]


def T_answer(g, eps=EPS):
    c = (1 - eps) / 3
    s = g.sum(axis=1)
    lo = c * s + eps * g.min(axis=1)
    hi = c * s + eps * g.max(axis=1)
    return np.where(lo > 0, 1, np.where(hi < 0, -1, 0))


def V(j, g):
    return np.sign(g[:, j]).astype(int)
