"""PP37 levels37.py -- NUMERICS (Gaussian Monte Carlo) for the leading balanced level L^0 of PP37.

Run: python3 -I -B levels37.py   (writes levels37.out)

L^0_w(N) = integral of rho_w * r_w(N) d mu, rho_w = 2 on M_w and 1 elsewhere (PP25's first level).
Checks:
 (a) balance: sum_w rho_w r_w(N, g) = 4 on mixed g and 0 on unanimous g, for every coherent N (exact,
     pointwise on all samples, for T, V_j and every edge model in the grid);
 (b) the vector L^0(N) - L^0(T) for the vertex models and for edge models D_[x0,x1] on [e1,e2]
     (x = weight on e2), on a grid of 0 <= x0 <= x1 <= 1. Reports min over the grid of
     L^0_3(D) - L^0_3(T)  (PP37 Prop 6.5 uses only its sign) and the same for worlds 1, 2.
No proof depends on this script.
"""
import numpy as np
rng = np.random.default_rng(37)
EPS = 0.3; C = (1 - EPS) / 3
N = 2_000_000
g = rng.standard_normal((N, 3))
S = g.sum(1)
sg = np.sign(g)
cls = np.full(N, -1)
for k in range(3):
    o = [w for w in range(3) if w != k]
    cls[(sg[:, k] != sg[:, o[0]]) & (sg[:, o[0]] == sg[:, o[1]])] = k
rho = np.where(cls[:, None] == np.arange(3)[None, :], 2.0, 1.0)
out = []
def log(s):
    out.append(s); print(s)

def ans_K(points):
    """answer of D_K, K = conv(points): +1 accept g, -1 accept -g, 0 silent."""
    vals = np.stack([g @ np.array(p) for p in points], 1)
    return np.where(vals.min(1) > 0, 1, np.where(vals.max(1) < 0, -1, 0))

def rank(a, w):
    return np.where(a == 0, 1, np.where(a == sg[:, w], 0, 2))

def L0(a):
    return np.array([(rho[:, w] * rank(a, w)).mean() for w in range(3)])

def balance_ok(a):
    s = sum(rho[:, w] * rank(a, w) for w in range(3))
    return bool(np.all(np.where(cls >= 0, s == 4, s == 0)))

Mv = [C * np.ones(3) + EPS * np.eye(3)[i] for i in range(3)]
T = ans_K(Mv)
LT = L0(T)
log(f"samples {N}, eps {EPS}: L^0(T) = {np.round(LT,5)}; balance exact for T: {balance_ok(T)}")
allbal = balance_ok(T)
for j in range(3):
    V = ans_K([np.eye(3)[j]])
    allbal &= balance_ok(V)
    log(f"  V_{j+1}: L^0 - L^0(T) = {np.round(L0(V) - LT, 5)}")
grid = np.linspace(0, 1, 21)
mins = [np.inf] * 3; arg = [None] * 3
rows = []
for i, x0 in enumerate(grid):
    for x1 in grid[i:]:
        D = ans_K([(1 - x0, x0, 0.0), (1 - x1, x1, 0.0)])
        allbal &= balance_ok(D)
        d = L0(D) - LT
        rows.append((x0, x1, d))
        for w in range(3):
            if d[w] < mins[w]:
                mins[w] = d[w]; arg[w] = (x0, x1)
se = 4 * np.sqrt(4.0 / N)
log(f"(a) balance identity exact on every sample for T, V_j and all {len(rows)} edge models: {allbal}")
for w in range(3):
    log(f"(b) min over edge grid of L^0_{w+1}(D) - L^0_{w+1}(T) = {mins[w]:+.5f} at [x0,x1] = {arg[w]}  (MC error scale ~{se:.4f})")
log("    selected rows (x0, x1, L^0(D)-L^0(T)):")
for x0, x1, d in rows:
    if (x0, x1) in [(0, 0), (0.5, 0.5), (1, 1), (0, 1), (0.25, 0.75), (0.1, 0.9), (0.4, 0.6)]:
        log(f"      {x0:.2f} {x1:.2f}  {np.round(d,5)}")
pos3 = all(d[2] > 4 * se for _, _, d in rows)
log(f"(c) L^0_3(D) > L^0_3(T) by more than 4 error scales for every edge model in the grid: {pos3}")
open("levels37.out", "w").write("\n".join(out) + "\n")
