"""PP37 edgegate37.py -- CHECKED (exact rational arithmetic on sampled problems) for PP37 Section 4.

Run: python3 -I -B edgegate37.py   (writes edgegate37.out)

eps = 3/10, c = 7/30, T = D_M, M = c*1 + eps*Delta. Band J = (alpha, beta), alpha = c/(c+eps) = 7/16,
beta = 16/7, in the ratio theta = |g2|/|g1| on W_12 = M_1 u M_2.
Edge gate E (Prop 4.3): sigma_1 = sigma_2 = 1 on W_12, 1/2 on M_3. L gate: rho_w = 2 on M_w, 1 elsewhere.
For edge models D = D_[p0,p1], p_i = (1-x_i, x_i, 0), on a grid of x0 <= x1, and rational sample
problems g in Sil(T) n (W_12 u M_3) (radially irrelevant: everything is conic), computes for w = 1, 2
  supC_w = max of sigma_w/rho_w over sampled points where D is w-correct,
  infR_w = min of sigma_w/rho_w over sampled points where D is w-wrong,
and checks Theorem 4.1's condition supC_w <= infR_w against the band predicate of Cor 4.2,
'D has no 1-correct point in M_2 n Sil(T)  or  no 2-correct point in M_1 n Sil(T)' (i.e. tau0 <= alpha
or tau1 >= beta), on the samples. Also checks exactly that every sampled silent W_12 point has
alpha < theta < beta when it lies on the seam side predicted by PP32 Lemma 1.1(i).
"""
from fractions import Fraction as F
import random
random.seed(37)
EPS = F(3, 10); C = (1 - EPS) / 3
ALPHA = C / (C + EPS); BETA = (C + EPS) / C
Mv = [tuple(C + (EPS if i == j else 0) for j in range(3)) for i in range(3)]
def dot(a, b): return sum(x * y for x, y in zip(a, b))
def sgn(x): return (x > 0) - (x < 0)
def cls(g):
    s = [sgn(x) for x in g]
    for k in range(3):
        o = [w for w in range(3) if w != k]
        if s[k] != s[o[0]] and s[o[0]] == s[o[1]]:
            return k
    return -1
def ans(points, g):
    v = [dot(p, g) for p in points]
    return 1 if min(v) > 0 else (-1 if max(v) < 0 else 0)
def silT(g): return ans(Mv, g) == 0
samples = []
while len(samples) < 6000:
    g = tuple(F(random.randint(-60, 60), random.randint(1, 20)) for _ in range(3))
    if 0 in g: continue
    k = cls(g)
    if k in (0, 1, 2) and silT(g):
        samples.append((g, k))
out = []
def log(s): out.append(s); print(s)
log(f"alpha = {ALPHA}, beta = {BETA}; {len(samples)} rational problems in Sil(T) (all classes)")
# PP32 Lemma 1.1(i): theta < beta on Sil n M_1, theta > alpha on Sil n M_2
ok11 = all((abs(g[1]) / abs(g[0]) < BETA) if k == 0 else (abs(g[1]) / abs(g[0]) > ALPHA) if k == 1 else True
           for g, k in samples)
log(f"PP32 Lemma 1.1(i) on samples: {ok11}")
def rho(w, k): return F(2) if w == k else F(1)
def sigma(w, k): return F(1, 2) if k == 2 else F(1)
xs = [F(i, 20) for i in range(1, 20)]
npass = nbad = 0; mism = []
for i, x0 in enumerate(xs):
    for x1 in xs[i:]:
        pts = [(1 - x0, x0, 0), (1 - x1, x1, 0)]
        supC = {0: None, 1: None}; infR = {0: None, 1: None}
        has1cM2 = has2cM1 = False
        for g, k in samples:
            a = ans(pts, g)
            if a == 0: continue
            for w in (0, 1):
                r = sigma(w, k) / rho(w, k)
                corr = (a == sgn(g[w]))
                if corr:
                    supC[w] = r if supC[w] is None else max(supC[w], r)
                else:
                    infR[w] = r if infR[w] is None else min(infR[w], r)
            if k == 1 and a == sgn(g[0]): has1cM2 = True
            if k == 0 and a == sgn(g[1]): has2cM1 = True
        cond = all(supC[w] is None or infR[w] is None or supC[w] <= infR[w] for w in (0, 1))
        band = (not has1cM2) or (not has2cM1)
        if cond == band: npass += 1
        else: nbad += 1; mism.append((x0, x1))
log(f"edge models tested: {npass + nbad}; Theorem-4.1 condition == band predicate on {npass}, mismatches {nbad} {mism[:5]}")
log("ALL PASS" if ok11 and nbad == 0 else "FAIL")
open("edgegate37.out", "w").write("\n".join(out) + "\n")
