"""PP40 shared code: an independent re-implementation of the field l^T (REFEREE_PP32_penalties §3.2).

Written from the definition, not copied from PP38_py/field38.py, so that PP38's numbers are re-derived.
Problems g in R^3 modulo sign.  Advice codes: +1 accept g, -1 accept -g, 0 silent, 2 contradiction.
Rank at world w: correct 0, silent 1, wrong 2, contradiction 3.
Penalty above correct: silent alpha, wrong alpha+beta, contradiction alpha+beta+gamma.
On M_k (k the minority world): alpha_k = beta_k = gamma_k = |g_k|; for j != k, s_j = |g_j|/|g_k|:
  alpha_j = |g_k| G(s_j), beta_j = |g_k| F(s_j), gamma_j = |g_j|.   On U: alpha = beta = gamma = |g_w|.
"""
import numpy as np


def consts(eps):
    c = (1.0 - eps) / 3.0
    L = (c + eps) / c
    d = 1.0 / (1.0 + L)
    return c, L, d


def F(th, eps):
    c, L, d = consts(eps)
    th = np.asarray(th, float)
    return np.piecewise(th, [th <= d, (th > d) & (th <= 1 / L), th > 1 / L],
                        [lambda x: x / (2 * d), lambda x: 0.5 + L * (x - d) / (2 * d), lambda x: L * x])


def G(s, eps):
    s = np.asarray(s, float)
    return 1.0 / F(1.0 / s, eps)


def classes(g):
    """minority world per row; -1 on U."""
    pos = (g > 0).sum(1)
    k = np.full(len(g), -1)
    m1 = pos == 1
    m2 = pos == 2
    k[m1] = np.argmax(g[m1] > 0, 1)
    k[m2] = np.argmax(g[m2] < 0, 1)
    return k


def field(g, eps):
    a = np.abs(g)
    al, be, ga = a.copy(), a.copy(), a.copy()
    k = classes(g)
    for kk in range(3):
        m = k == kk
        for j in range(3):
            if j != kk and m.any():
                s = a[m, j] / a[m, kk]
                al[m, j] = a[m, kk] * G(s, eps)
                be[m, j] = a[m, kk] * F(s, eps)
    return al, be, ga


def ranks(adv, g):
    out = np.empty(g.shape, int)
    for w in range(3):
        corr = adv * np.sign(g[:, w]) > 0
        out[:, w] = np.where(adv == 2, 3, np.where(adv == 0, 1, np.where(corr, 0, 2)))
    return out


def pen(adv, g, fl):
    al, be, ga = fl
    r = ranks(adv, g)
    return np.where(r == 0, 0.0, np.where(r == 1, al, np.where(r == 2, al + be, al + be + ga)))


def bayes(g, lam, fl):
    lam = np.asarray(lam, float)
    cs = np.stack([pen(np.full(len(g), a), g, fl) @ lam for a in (1, -1, 0)], 1)
    return np.array([1, -1, 0])[np.argmin(cs, 1)]


def T(g, eps):
    """D_M with M = c 1 + eps Delta: accept g iff min over vertices of M of m.g > 0."""
    c = (1.0 - eps) / 3.0
    S = g.sum(1)
    lo = c * S + eps * g.min(1)
    hi = c * S + eps * g.max(1)
    return np.where(lo > 0, 1, np.where(hi < 0, -1, 0))


def edge(t, g, fl):
    """B_12(t): Bayes model at the edge weight (t/(1+t), 1/(1+t), 0)."""
    return bayes(g, (t / (1 + t), 1 / (1 + t), 0.0), fl)
