"""PP40 r3_window_mc.py -- NUMERICS (Gaussian Monte Carlo, paired samples), plus a sampled sign census.

Theorem 3.3 (R3 localisation).  N = B_12(1).  For t > 1:
  (a) census: B_12(t) is pointwise no worse than N at world 1 (and the mirror for t < 1 at world 2);
  (b) W_2(t) := L_2(B_12(t)) - L_2(N) and W_1(t) for t < 1 (paired differences; supported on thin wedges);
  (c) the forced rival Z' = N[G' -> S, E' -> B] on PP38's ball (centre (1,1,-1.9), radius 0.2; E' = G'):
      z = L(Z') - L(N); admissible dominators B_12(t) need W_2(t) <= z_2 (t > 1) or W_1(t) <= z_1 (t < 1);
  (d) world 3: L_3(B_12(t)) - L_3(Z') > 0 for the admissible t (so the domination must be installed there).
Run: python3 -I -B r3_window_mc.py > r3_window_mc.out
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import field40 as f

eps = 0.3
rng = np.random.default_rng(4041)
n = 2_000_000
g = rng.standard_normal((n, 3))
fl = f.field(g, eps)
N = f.edge(1.0, g, fl)
pN = f.pen(N, g, fl)
rN = f.ranks(N, g)
# (c) the forced rival on PP38's ball (sign classes: (1,1,-1.9) is in M_3)
ctr = np.array([1.0, 1.0, -1.9])
inball = (np.linalg.norm(g - ctr, axis=1) < 0.2) | (np.linalg.norm(g + ctr, axis=1) < 0.2)
Ta = f.T(g, eps)
assert np.all(Ta[inball] == 0) and np.all(f.classes(g[inball]) == 2) and np.all(N[inball] == np.sign(g[inball, 0]))
Zp = N.copy()
Zp[inball] = np.sign(g[inball, 2])          # B: the 3-correct answer on M_3 (E' = G')
z = (f.pen(Zp, g, fl) - pN).mean(0)
print(f"ball mass {inball.mean():.2e}; z = L(Z') - L(N) = {z}")
viol = 0
for t in (1.0005, 1.001, 1.002, 1.005, 1.01, 1.02, 1.05, 1 / 1.001, 1 / 1.005, 1 / 1.02):
    B = f.edge(t, g, fl)
    rB = f.ranks(B, g)
    w = 0 if t > 1 else 1                       # world where B is pointwise no worse than N
    v = 1 - w
    viol += np.sum(rB[:, w] > rN[:, w])
    W = (f.pen(B, g, fl) - pN).mean(0)
    adm = W[v] <= z[v]
    d3 = (f.pen(B, g, fl) - f.pen(Zp, g, fl)).mean(0)[2]
    print(f"t={t:.5f}: pointwise no worse at world {w + 1}: {np.sum(rB[:, w] > rN[:, w]) == 0}; "
          f"W_{v + 1}(t) = {W[v]:.2e} vs z_{v + 1} = {z[v]:.2e} -> admissible {adm}; "
          f"L_3(B) - L_3(Z') = {d3:+.2e}")
print("census (a):", "no counterexample" if viol == 0 else f"{viol} violations")
