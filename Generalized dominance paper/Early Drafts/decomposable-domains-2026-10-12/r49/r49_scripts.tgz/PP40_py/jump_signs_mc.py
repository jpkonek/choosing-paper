"""PP40 jump_signs_mc.py -- NUMERICS (Gaussian Monte Carlo, n = 10^6, fixed seed).

For the edge family B_12(t) (third world k = 3) and T = D_M:
  Delta_w(t) := L_w(B_12(t)) - L_w(T), w = 1, 2, 3  (with standard errors);
  h(t) := sum_w lambda_w(t) (L_w(T) - L_w(B_12(t))), lambda(t) = (t/(1+t), 1/(1+t), 0)   [Lemma 2.2: h > 0];
  the double-loss set I_2 = {t : Delta_1(t) < 0 and Delta_2(t) < 0}                     [Prop 2.6];
  comp3(t) := mu{B_12(t) strictly 3-better than T}  (the compensation set R_t; Prop 2.4)  [0 iff t = 1];
  sanity: mu{u-Bayes != T} (should be 0 up to ties).
Run: python3 -I -B jump_signs_mc.py > jump_signs_mc.out
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import field40 as f

rng = np.random.default_rng(4040)
n = 1_000_000
g = rng.standard_normal((n, 3))
ts = np.concatenate([np.geomspace(1e-3, 0.5, 12), np.linspace(0.55, 1.8, 26), np.geomspace(2.0, 1e3, 12)])
for eps in (0.1, 0.3, 0.5, 0.9):
    fl = f.field(g, eps)
    Ta = f.T(g, eps)
    pT = f.pen(Ta, g, fl)
    mism = np.mean(f.bayes(g, (1 / 3, 1 / 3, 1 / 3), fl) != Ta)
    print(f"eps={eps}: L(T) = {np.round(pT.mean(0), 4)}; mu(u-Bayes != T) = {mism:.2e}")
    rT = f.ranks(Ta, g)
    I2 = []
    hmin = np.inf
    for t in ts:
        B = f.edge(t, g, fl)
        dlt = f.pen(B, g, fl) - pT
        m, se = dlt.mean(0), dlt.std(0) / np.sqrt(n)
        lam = np.array([t / (1 + t), 1 / (1 + t), 0.0])
        h = -(lam @ m)
        hmin = min(hmin, h)
        comp3 = np.mean(f.ranks(B, g)[:, 2] < rT[:, 2])
        both = (m[0] + 4 * se[0] < 0) and (m[1] + 4 * se[1] < 0)
        if both:
            I2.append(t)
        if eps == 0.3 or abs(t - 1) < 1e-9:
            print(f"  t={t:9.4f}  Delta=({m[0]:+.4f},{m[1]:+.4f},{m[2]:+.4f}) se<={se.max():.4f}  h={h:+.4f}  "
                  f"comp3={comp3:.2e}  both-edge-negative={both}")
    print(f"  min_t h(t) = {hmin:+.4f};  I_2 (grid points, 4 s.e.) spans [{min(I2):.3f}, {max(I2):.3f}]"
          if I2 else f"  min_t h(t) = {hmin:+.4f};  I_2 empty on grid")
print("done")
