"""PP40 pointwise_exact.py -- CHECKED (exact rational arithmetic).

(a) Prop 2.4(i): B_12(1) is pointwise no better than T at world 3: rank_3(T(g)) <= rank_3(B_12(1)(g)) on every
    sampled rational problem, strictly on samples of Sil(T) n M_3.  (Proof by hand in the note.)
(b) Prop 2.4(ii): for t != 1 there are problems where B_12(t) is strictly 3-better than T (the compensation
    set R_t is non-empty; being a cone with interior, it is non-null).  Exact witnesses printed.
(c) Prop 2.5 sign facts at the jump: on Sil(T) n M_3, T is silent and every B_12(t) says A (correct at 1, 2;
    wrong at 3), so X = T[E -> A] is a pure improvement of T at worlds 1 and 2 and a worsening at 3.
Run: python3 -I -B pointwise_exact.py > pointwise_exact.out
"""
import random
from fractions import Fraction as Fr

random.seed(40)
eps = Fr(3, 10)
c = (1 - eps) / 3
L = (c + eps) / c
d = 1 / (1 + L)


def F(th):
    if th <= d:
        return th / (2 * d)
    if th <= 1 / L:
        return Fr(1, 2) + L * (th - d) / (2 * d)
    return L * th


def G(s):
    return 1 / F(1 / s)


def sgn(x):
    return (x > 0) - (x < 0)


def field(g):
    s = [sgn(x) for x in g]
    pos = [w for w in range(3) if s[w] > 0]
    neg = [w for w in range(3) if s[w] < 0]
    k = pos[0] if len(pos) == 1 else (neg[0] if len(neg) == 1 else None)
    if k is None:
        return [(abs(x), abs(x)) for x in g], None
    gk = abs(g[k])
    return [((gk, gk) if w == k else (gk * G(abs(g[w]) / gk), gk * F(abs(g[w]) / gk))) for w in range(3)], k


def rank(a, g, w):
    if a == 0:
        return 1
    return 0 if a * sgn(g[w]) > 0 else 2


def bayes(g, lam):
    fl, _ = field(g)
    cs = {}
    for a in (1, -1, 0):
        cs[a] = sum(lam[w] * [0, fl[w][0], fl[w][0] + fl[w][1]][rank(a, g, w)] for w in range(3))
    m = min(cs.values())
    arg = [a for a in cs if cs[a] == m]
    return arg[0] if len(arg) == 1 else None


def T(g):
    lo = c * sum(g) + eps * min(g)
    hi = c * sum(g) + eps * max(g)
    return 1 if lo > 0 else (-1 if hi < 0 else (0 if lo < 0 < hi else None))


def edge(t):
    return (t / (1 + t), 1 / (1 + t), Fr(0))


fails = 0
na = ns = 0
for _ in range(20000):
    g = tuple(Fr(random.randint(-400, 400), 37) for _ in range(3))
    if 0 in [sgn(x) for x in g]:
        continue
    a, b = T(g), bayes(g, edge(Fr(1)))
    if a is None or b is None:
        continue
    na += 1
    if rank(a, g, 2) > rank(b, g, 2):
        fails += 1
        print("FAIL (a)", g)
    _, k = field(g)
    if k == 2 and a == 0:
        ns += 1
        if not rank(a, g, 2) < rank(b, g, 2):
            fails += 1
            print("FAIL (a) strict", g)
        if not (b == sgn(g[0]) and b == sgn(g[1])):
            fails += 1
            print("FAIL (c)", g)
print(f"(a) {na} problems: rank_3(T) <= rank_3(B_12(1)) everywhere; strict on all {ns} samples of Sil(T) n M_3")
for t in (Fr(1, 2), Fr(9, 10), Fr(11, 10), Fr(2)):
    wit = None
    for _ in range(200000):
        g = tuple(Fr(random.randint(-400, 400), 37) for _ in range(3))
        if 0 in [sgn(x) for x in g]:
            continue
        a, b = T(g), bayes(g, edge(t))
        if a is None or b is None:
            continue
        if rank(b, g, 2) < rank(a, g, 2):
            wit = (g, a, b)
            break
    if wit is None:
        fails += 1
        print(f"FAIL (b) t={t}: no witness")
    else:
        g, a, b = wit
        print(f"(b) t={t}: g={tuple(float(x) for x in g)}: T says {a}, B_12(t) says {b} (rank_3 {rank(a, g, 2)} -> {rank(b, g, 2)})")
print("ALL PASS" if fails == 0 else f"{fails} FAILS")
