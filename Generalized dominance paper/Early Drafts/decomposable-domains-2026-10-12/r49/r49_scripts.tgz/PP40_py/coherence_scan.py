"""PP40 coherence_scan.py -- CHECKED (float search, exact rational verification of every witness).

Independent test of PP38 Lemma 4.2 (coherent l^T-Bayes models at interior weights: only T at u).
Method (different from PP38's, which builds the witness at the kink the proof predicts):
  for each weight lambda and each class M_i, in the chart g = (1, -s_j, -s_k) on M_i,
  compute the boundary functions b (B-region = {s_k < b(s_j)}) and a (A-region = {s_k > a(s_j)}) by bisection
  on a blind grid of 800 x 4 triples (x1, x2 = (x1+x3)/2, x3), and look for any violation of
  concavity of b or convexity of a.  Every violation found is then verified EXACTLY (fractions): two problems
  with the same strict-margin Bayes answer whose midpoint has a different unique Bayes answer.
  Such a witness persists on balls, so the Bayes model agrees a.e. with no D_K (PP38 Lemma 4.2, step 7).
Weights: all interior weights with denominator 20 (171), plus u and six weights within 1/30 or 1/300 of u.
Expected: a witness for every lambda != u; none at u (T's regions are polygons).
Run: python3 -I -B coherence_scan.py > coherence_scan.out
"""
from fractions import Fraction as Fr
import numpy as np

EPS_LIST = [Fr(3, 10), Fr(1, 10)]


def mk(eps):
    c = (1 - eps) / 3
    L = (c + eps) / c
    d = 1 / (1 + L)
    cf, Lf, df = float(c), float(L), float(d)

    def Fx(th):
        if th <= d:
            return th / (2 * d)
        if th <= 1 / L:
            return Fr(1, 2) + L * (th - d) / (2 * d)
        return L * th

    def Gx(s):
        return 1 / Fx(1 / s)

    def Ff(th):
        th = np.asarray(th, float)
        return np.where(th <= df, th / (2 * df), np.where(th <= 1 / Lf, 0.5 + Lf * (th - df) / (2 * df), Lf * th))

    def Gf(s):
        return 1.0 / Ff(1.0 / np.asarray(s, float))
    return Fx, Gx, Ff, Gf


def costs(li, lj, lk, sj, sk, Fn, Gn):
    """costs of (B, S, A) per unit |g_i| on M_i, chart (s_j, s_k)."""
    cB = lj * (Gn(sj) + Fn(sj)) + lk * (Gn(sk) + Fn(sk))
    cS = li + lj * Gn(sj) + lk * Gn(sk)
    cA = 2 * li
    return cB, cS, cA


def boundary(li, lj, lk, x, Ff, Gf, which):
    lo = np.full_like(x, 1e-9)
    hi = np.full_like(x, 60.0)

    def inside(sk):
        cB, cS, cA = costs(li, lj, lk, x, sk, Ff, Gf)
        if which == 'B':
            return (cB < cS) & (cB < cA)
        return (cA < cS) & (cA < cB)
    if which == 'B':
        ok = inside(lo)
        for _ in range(70):
            mid = (lo + hi) / 2
            m = inside(mid)
            lo = np.where(m, mid, lo)
            hi = np.where(m, hi, mid)
        return np.where(ok, lo, 0.0)
    ok = inside(hi)
    for _ in range(70):
        mid = (lo + hi) / 2
        m = inside(mid)
        hi = np.where(m, mid, hi)
        lo = np.where(m, lo, mid)
    return np.where(ok, hi, np.inf)


def exact_answer(li, lj, lk, sj, sk, Fx, Gx):
    cB, cS, cA = costs(li, lj, lk, sj, sk, Fx, Gx)
    cs = {'B': cB, 'S': cS, 'A': cA}
    m = min(cs.values())
    arg = [a for a in cs if cs[a] == m]
    return arg[0] if len(arg) == 1 else None


def find_witness(lam, eps, Fx, Gx, Ff, Gf):
    x2 = np.geomspace(0.02, 20.0, 800)
    for i in range(3):
        j, k = [w for w in range(3) if w != i]
        for (jj, kk) in ((j, k), (k, j)):
            li, lj, lk = (float(lam[i]), float(lam[jj]), float(lam[kk]))
            for r in (0.5, 0.2, 0.05, 0.01):
                x1, x3 = x2 * (1 - r), x2 * (1 + r)
                for which in ('B', 'A'):
                    b1, b2, b3 = (boundary(li, lj, lk, x, Ff, Gf, which) for x in (x1, x2, x3))
                    if which == 'B':
                        good = (b1 > 1e-6) & (b3 > 1e-6) & (b1 < 59) & (b3 < 59)
                        gap = np.where(good, (b1 + b3) / 2 - b2, -1)
                    else:
                        good = np.isfinite(b1) & np.isfinite(b3) & np.isfinite(b2) & (b2 > 1e-6)
                        gap = np.where(good, b2 - (b1 + b3) / 2, -1)
                    idx = np.argsort(-gap)[:5]
                    for t in idx:
                        if gap[t] <= 1e-9:
                            break
                        dl = gap[t] / 3
                        sgn = -1 if which == 'B' else 1
                        P = [(x1[t], b1[t] + sgn * dl), (x3[t], b3[t] + sgn * dl)]
                        Q = ((x1[t] + x3[t]) / 2, (b1[t] + b3[t]) / 2 + sgn * dl)
                        Lx = [tuple(Fr(v).limit_denominator(10 ** 9) for v in p) for p in P]
                        Mx = tuple((Lx[0][q] + Lx[1][q]) / 2 for q in range(2))
                        la = (lam[i], lam[jj], lam[kk])
                        a0 = exact_answer(*la, *Lx[0], Fx, Gx)
                        a1 = exact_answer(*la, *Lx[1], Fx, Gx)
                        am = exact_answer(*la, *Mx, Fx, Gx)
                        pos = all(v > 0 for p in Lx for v in p)   # both problems genuinely in M_i
                        if pos and a0 == which and a1 == which and am is not None and am != which:
                            return (i, which, Lx, Mx, am)
    return None


allpass = True
for eps in EPS_LIST:
    Fx, Gx, Ff, Gf = mk(eps)
    N = 20
    lams = [(Fr(a, N), Fr(b, N), Fr(N - a - b, N)) for a in range(1, N) for b in range(1, N - a)]
    u = (Fr(1, 3),) * 3
    near = []
    for eta in (Fr(1, 30), Fr(1, 300)):
        for v in ((1, -1, 0), (1, 1, -2), (2, -1, -1)):
            near.append(tuple(u[w] + eta * v[w] / 3 for w in range(3)))
    found = missing = 0
    for lam in lams + near:
        wit = find_witness(lam, eps, Fx, Gx, Ff, Gf)
        if wit is None:
            missing += 1
            allpass = False
            print(f"  eps={eps} NO WITNESS at lambda={lam}")
        else:
            found += 1
    wu = find_witness(u, eps, Fx, Gx, Ff, Gf)
    if wu is not None:
        allpass = False
        print(f"  eps={eps} UNEXPECTED witness at u: {wu}")
    print(f"eps={eps}: exact incoherence witnesses at {found}/{len(lams) + len(near)} weights != u "
          f"({len(near)} of them within 1/30 or 1/300 of u); witness at u: {wu is not None}")
    if eps == Fr(3, 10):
        w = find_witness(near[-3], eps, Fx, Gx, Ff, Gf)
        print(f"  sample (lambda = {near[-3]}): class M_{w[0] + 1}, region {w[1]}, points "
              f"{[tuple(float(v) for v in p) for p in w[2]]}, midpoint answer {w[4]}")
print("ALL PASS" if allpass else "SOME FAIL")
