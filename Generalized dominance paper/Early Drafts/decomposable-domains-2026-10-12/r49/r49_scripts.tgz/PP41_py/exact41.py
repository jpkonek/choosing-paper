"""PP41 exact41.py -- CHECKED (exact rational arithmetic on sampled problems).

(a) T is pointwise weakly 3-better than N = B_12(1) on every sampled problem (Lemma 1.2(b) of PP41;
    PP40 Prop 2.4(i) re-checked independently), strictly on every sample of Sil(T) n M_3.
(b) Edge monotonicity (Lemma 1.2(a)): for s < t, B_12(t) is pointwise weakly 1-better and weakly
    2-worse than B_12(s), on every sampled problem, strictly somewhere for each pair.
(d) Regions used in Theorem 2.3, step 4-5: for each t != 1 in the grid, the disagreement set
    D_t = {T != B_12(t)} contains sampled problems where T is strictly 1-better, strictly 2-better,
    and strictly 3-worse than B_12(t) (the cone R_t), and problems of Sil(T) n M_3 (pattern (-,-,+)).
(c) Edge thresholds: B_12(t) on W_12 is 1-correct iff F(theta) < t, 2-correct iff G(theta) > t,
    silent otherwise, checked against the exact cost comparison at the edge weight.
eps = 3/10 and eps = 1/10.  Run: python3 -I -B exact41.py > exact41.out
"""
from fractions import Fraction as Fr
import random

random.seed(4101)


def consts(eps):
    c = (1 - eps) / 3
    L = (c + eps) / c
    d = 1 / (1 + L)
    return c, L, d


def F(th, eps):
    c, L, d = consts(eps)
    if th <= d:
        return th / (2 * d)
    if th <= 1 / L:
        return Fr(1, 2) + L * (th - d) / (2 * d)
    return L * th


def G(s, eps):
    return 1 / F(1 / s, eps)


def sign(x):
    return (x > 0) - (x < 0)


def minority(g):
    sg = [sign(x) for x in g]
    if all(x == sg[0] for x in sg):
        return -1
    pos = [i for i in range(3) if sg[i] > 0]
    neg = [i for i in range(3) if sg[i] < 0]
    return pos[0] if len(pos) == 1 else neg[0]


def field(g, eps):
    ag = [abs(x) for x in g]
    al, be = list(ag), list(ag)
    k = minority(g)
    if k >= 0:
        for j in range(3):
            if j != k:
                s = ag[j] / ag[k]
                al[j] = ag[k] * G(s, eps)
                be[j] = ag[k] * F(s, eps)
    return al, be


def rank(a, g, w):
    if a == 0:
        return 1
    return 0 if a * sign(g[w]) > 0 else 2


def pen(a, g, w, fl):
    r = rank(a, g, w)
    al, be = fl
    return [0, al[w], al[w] + be[w]][r]


def T_answer(g, eps):
    c = (1 - eps) / 3
    s = sum(g)
    lo = c * s + eps * min(g)
    hi = c * s + eps * max(g)
    return 1 if lo > 0 else (-1 if hi < 0 else 0)


def edge_bayes(g, t, fl):
    costs = {a: t * pen(a, g, 0, fl) + pen(a, g, 1, fl) for a in (1, -1, 0)}
    m = min(costs.values())
    best = [a for a in costs if costs[a] == m]
    return best[0] if len(best) == 1 else None  # None: tie (null set)


def rnd():
    return Fr(random.randint(-400, 400), random.randint(1, 60))


def main():
    allok = True
    for eps in (Fr(3, 10), Fr(1, 10)):
        n = 0; strict3 = 0; silM3 = 0; bad_a = 0; bad_b = 0; bad_c = 0; ties = 0
        ts = [Fr(1, 3), Fr(1, 2), Fr(9, 10), Fr(1), Fr(11, 10), Fr(2), Fr(3)]
        cnt = {t: [0, 0, 0, 0] for t in ts}
        strict_pairs = {(s, t): [False, False] for s in ts for t in ts if s < t}
        for _ in range(6000):
            g = [rnd() for _ in range(3)]
            if 0 in g:
                continue
            n += 1
            fl = field(g, eps)
            k = minority(g)
            Ta = T_answer(g, eps)
            Bt = {}
            for t in ts:
                b = edge_bayes(g, t, fl)
                if b is None:
                    ties += 1
                    b = None
                Bt[t] = b
            # (c) thresholds on W_12
            if k in (0, 1):
                th = abs(g[1]) / abs(g[0])
                for t in ts:
                    if Bt[t] is None:
                        continue
                    if F(th, eps) < t:
                        exp = 'c1'
                    elif G(th, eps) > t:
                        exp = 'c2'
                    else:
                        exp = 'S'
                    a = Bt[t]
                    got = 'S' if a == 0 else ('c1' if rank(a, g, 0) == 0 else 'c2')
                    if got != exp:
                        bad_c += 1
            # (a) T weakly 3-better than B_12(1)
            N = Bt[Fr(1)]
            if N is not None:
                if rank(Ta, g, 2) > rank(N, g, 2):
                    bad_a += 1
                if k == 2 and Ta == 0:
                    silM3 += 1
                    if rank(Ta, g, 2) < rank(N, g, 2):
                        strict3 += 1
            # (d) regions
            for t in ts:
                b = Bt[t]
                if b is None or b == Ta:
                    continue
                rT = [rank(Ta, g, w) for w in range(3)]
                rB = [rank(b, g, w) for w in range(3)]
                if rT[0] < rB[0]: cnt[t][0] += 1
                if rT[1] < rB[1]: cnt[t][1] += 1
                if rB[2] < rT[2]: cnt[t][2] += 1
                if k == 2 and Ta == 0: cnt[t][3] += 1
            # (b) monotonicity
            for (s, t), fl2 in strict_pairs.items():
                if Bt[s] is None or Bt[t] is None:
                    continue
                r1s, r1t = rank(Bt[s], g, 0), rank(Bt[t], g, 0)
                r2s, r2t = rank(Bt[s], g, 1), rank(Bt[t], g, 1)
                if r1t > r1s or r2t < r2s:
                    bad_b += 1
                if r1t < r1s:
                    fl2[0] = True
                if r2t > r2s:
                    fl2[1] = True
        strict_ok = all(v[0] and v[1] for v in strict_pairs.values())
        reg_ok = all(min(cnt[t]) > 0 for t in ts if t != 1) and cnt[Fr(1)][2] == 0
        ok = reg_ok and bad_a == 0 and bad_b == 0 and bad_c == 0 and strict3 == silM3 and silM3 > 0 and strict_ok
        allok &= ok
        print(f"eps={eps}: problems={n}, exact ties skipped={ties}")
        print(f"  (a) T weakly 3-better than B_12(1): violations={bad_a}; strict on Sil(T) n M_3: {strict3}/{silM3}")
        print(f"  (b) edge monotonicity violations={bad_b}; every pair strict at worlds 1 and 2: {strict_ok}")
        print("  (d) counts [T 1-better, T 2-better, B 3-better (R_t), Sil(T)nM_3] per t:", {str(t): cnt[t] for t in ts})
        print(f"  (c) threshold-form violations={bad_c}")
        print(f"  {'PASS' if ok else 'FAIL'}")
    print("ALL PASS" if allok else "SOME FAIL")


main()
