"""PP41 twofield_lp.py -- NUMERICS (LP on an empirical Gaussian sample); cross-check of PP41 Thm 2.4 / Lemma 2.5.

Unknown: a weakly guiding angular field psi (increments a_w = psi(silent)-psi(correct) >= 0,
b_w = psi(wrong)-psi(silent) >= 0, per sampled problem and world).  Valuation V_w = L_w + Psi_w
(l^T loss plus psi loss; the scale kappa is absorbed into psi).  Pointwise constraints:
 (P1) every edge model B_12(t), t in (0, oo), is pointwise psi-optimal at weight (t, 1, 0)
      (imposed at the two l^T breakpoints t = G(theta), F(theta) of each problem of W_12;
      linearity in t gives every t; on M_3 and U it is automatic);
 (P2) T is pointwise psi-optimal at u.
Integral tests at each t of a log grid on [0.1, 10], in scale-free form (max s in [0,1]):
 - iso at worlds 3 and w1 (w1 = 1 or 2): Psi_w(T) - Psi_w(B_t) = s (L_w(B_t) - L_w(T)), w in {3, w1};
   max s = 0 means infeasible; the dual multipliers (y3, y_w1) are printed (Lemma 2.5 predicts
   y1/y3 = 1 - t and y2/y3 = 1 - 1/t);
 - world-3 iso alone (the condition (J_T) of PP41 Prop 2.7 uses only this): max s = 1 means feasible.
Run: python3 -I -B twofield_lp.py 4000 > twofield_lp.out
"""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'PP38_py'))
import numpy as np
import scipy.sparse as sp
from scipy.optimize import linprog
import field38 as f

EPS = 0.3
rng = np.random.default_rng(41)
n = int(sys.argv[1]) if len(sys.argv) > 1 else 4000
g = rng.standard_normal((n, 3))
fl = f.field(g, EPS)
k = f.minority(g)
rel = np.where(k >= 0)[0]          # mixed problems (U irrelevant: every model involved is correct there)
m = len(rel)
gR = g[rel]
flR = tuple(x[rel] for x in fl)
kR = k[rel]
T = f.T_answer(gR, EPS)


def B(t):
    if t == np.inf:
        return f.V(0, gR)
    if t == 0:
        return f.V(1, gR)
    return f.bayes(gR, (t / (1 + t), 1 / (1 + t), 0.0), flR)


def Lvec(adv):
    return f.penalty(adv, gR, flR).sum(0) / n


# variable layout: for problem i, world w: a index 6i+2w, b index 6i+2w+1
nv = 6 * m


def psi_row(adv, w):
    """coefficients (length nv, sparse) of sum_i psi_w(g_i, adv_i) / n."""
    r = f.rank(adv, gR)[:, w]
    rows = []
    cols = []
    vals = []
    idx = np.arange(m)
    sil = r >= 1
    cols += list(6 * idx[sil] + 2 * w); vals += [1.0 / n] * int(sil.sum())
    wr = r >= 2
    cols += list(6 * idx[wr] + 2 * w + 1); vals += [1.0 / n] * int(wr.sum())
    v = np.zeros(nv)
    np.add.at(v, np.array(cols, dtype=int), np.array(vals))
    return v


def point_cost_coeffs(i, a, weights):
    """sparse coefficient dict for sum_w weights_w psi_w(g_i, a)."""
    out = {}
    rr = f.rank(np.array([a]), gR[i:i + 1])[0]
    for w in range(3):
        if weights[w] == 0:
            continue
        if rr[w] >= 1:
            out[6 * i + 2 * w] = out.get(6 * i + 2 * w, 0) + weights[w]
        if rr[w] >= 2:
            out[6 * i + 2 * w + 1] = out.get(6 * i + 2 * w + 1, 0) + weights[w]
    return out


# ---- pointwise constraints (P1), (P2) ----
Ar, Ac, Av = [], [], []   # A_ub x <= 0 rows
Er, Ec, Ev = [], [], []   # A_eq x = 0 rows
nub = 0
neq = 0


def add_le(d1, d2):
    """sum d1 <= sum d2  ->  d1 - d2 <= 0"""
    global nub
    dd = dict(d1)
    for kk, vv in d2.items():
        dd[kk] = dd.get(kk, 0) - vv
    for kk, vv in dd.items():
        if vv != 0:
            Ar.append(nub); Ac.append(kk); Av.append(vv)
    nub += 1


def add_eq(d1, d2):
    global neq
    dd = dict(d1)
    for kk, vv in d2.items():
        dd[kk] = dd.get(kk, 0) - vv
    for kk, vv in dd.items():
        if vv != 0:
            Er.append(neq); Ec.append(kk); Ev.append(vv)
    neq += 1


ans = (1, -1, 0)
for i in range(m):
    # (P2) T u-optimal
    cT = point_cost_coeffs(i, T[i], (1, 1, 1))
    for a in ans:
        if a != T[i]:
            add_le(cT, point_cost_coeffs(i, a, (1, 1, 1)))
    # (P1) on W_12
    if kR[i] in (0, 1):
        th = abs(gR[i, 1]) / abs(gR[i, 0])
        tG, tF = float(f.Gf(th, EPS)), float(f.Ff(th, EPS))
        sg = np.sign(gR[i])
        c1 = int(sg[0]); c2 = int(sg[1])      # 1-correct and 2-correct advice
        for t, pair in ((tG, (c2, 0)), (tF, (0, c1))):
            wts = (t, 1.0, 0.0)
            ca = point_cost_coeffs(i, pair[0], wts)
            cb = point_cost_coeffs(i, pair[1], wts)
            add_eq(ca, cb)
            for a in ans:
                if a not in pair:
                    add_le(ca, point_cost_coeffs(i, a, wts))

A_pt = sp.csr_matrix((Av, (Ar, Ac)), shape=(nub, nv))
E_pt = sp.csr_matrix((Ev, (Er, Ec)), shape=(neq, nv))

LT = Lvec(T)
PsiT = [psi_row(T, w) for w in range(3)]
tgrid = np.concatenate([[0.0], np.geomspace(1e-2, 1e2, 41), [np.inf]])
cache = {}


def mdl(t):
    if t not in cache:
        Bt = B(t)
        cache[t] = (Lvec(Bt), [psi_row(Bt, w) for w in range(3)])
    return cache[t]


def solve(ta, tb, side):
    rows_ub, rhs_ub, rows_eq, rhs_eq = [], [], [], []
    # V_w(B) - V_w(T) = (L_w(B)-L_w(T)) + (Psi_w(B)-Psi_w(T))
    for t in np.geomspace(ta, tb, 5):
        LB, PB = mdl(t)
        rows_eq.append(PB[2] - PsiT[2]); rhs_eq.append(-(LB[2] - LT[2]))
    for t in tgrid:
        LB, PB = mdl(t)
        rows_ub.append(-(PB[2] - PsiT[2])); rhs_ub.append(LB[2] - LT[2])      # V3(B)-V3(T) >= 0
    tj = ta if side == 'right' else tb
    LB, PB = mdl(tj)
    weq, wge = (0, 1) if side == 'right' else (1, 0)
    rows_eq.append(PB[weq] - PsiT[weq]); rhs_eq.append(-(LB[weq] - LT[weq]))
    rows_ub.append(-(PB[wge] - PsiT[wge])); rhs_ub.append(LB[wge] - LT[wge])
    Aub = sp.vstack([A_pt, sp.csr_matrix(np.array(rows_ub))])
    bub = np.concatenate([np.zeros(A_pt.shape[0]), rhs_ub])
    Aeq = sp.vstack([E_pt, sp.csr_matrix(np.array(rows_eq))])
    beq = np.concatenate([np.zeros(E_pt.shape[0]), rhs_eq])
    res = linprog(np.ones(nv), A_ub=Aub, b_ub=bub, A_eq=Aeq, b_eq=beq, bounds=(0, None), method='highs')
    return res



def iso_test(t, w1):
    """max s >= 0 (s <= 1, psi >= 0 unbounded) with Psi_w(T)-Psi_w(B_t) = s*(L_w(B_t)-L_w(T)) for w in {3, w1}.
    s = 0 at the optimum means: no admissible psi makes B_t iso-level with T at worlds 3 and w1."""
    LB, PB = mdl(t)
    d = LB - LT
    rows = []
    for w in (2, w1):
        rows.append(np.concatenate([(PsiT[w] - PB[w]) * n, [-d[w]]]))
    Aeq = sp.vstack([sp.hstack([E_pt, sp.csr_matrix((E_pt.shape[0], 1))])] + [sp.csr_matrix(r[None, :]) for r in rows])
    Aub = sp.hstack([A_pt, sp.csr_matrix((A_pt.shape[0], 1))])
    c = np.zeros(nv + 1); c[-1] = -1
    res = linprog(c, A_ub=Aub, b_ub=np.zeros(Aub.shape[0]), A_eq=Aeq, b_eq=np.zeros(Aeq.shape[0]),
                  bounds=[(0, None)] * nv + [(0, 1)], method='highs')
    y3, yw = res.eqlin.marginals[-2:]
    return -res.fun, y3, yw, d


def three_only(t):
    LB, PB = mdl(t)
    d = LB - LT
    row = np.concatenate([(PsiT[2] - PB[2]) * n, [-d[2]]])
    Aeq = sp.vstack([sp.hstack([E_pt, sp.csr_matrix((E_pt.shape[0], 1))]), sp.csr_matrix(row[None, :])])
    Aub = sp.hstack([A_pt, sp.csr_matrix((A_pt.shape[0], 1))])
    c = np.zeros(nv + 1); c[-1] = -1
    res = linprog(c, A_ub=Aub, b_ub=np.zeros(Aub.shape[0]), A_eq=Aeq, b_eq=np.zeros(Aeq.shape[0]),
                  bounds=[(0, None)] * nv + [(0, 1)], method='highs')
    return -res.fun


print(f"eps={EPS}, n={n}, mixed problems={m}; pointwise rows: {A_pt.shape[0]} <=, {E_pt.shape[0]} =")
print(f"L(T) = {np.round(LT, 4)}")
allzero = True
for t in np.geomspace(0.1, 10, 21):
    s3 = three_only(t)
    line = f"t={t:7.4f}: world-3 iso alone: max s={s3:.3g};"
    for w1 in (0, 1):
        s, y3, yw, d = iso_test(t, w1)
        allzero &= abs(s) < 1e-9
        line += f"  iso at 3 and {w1+1}: max s={abs(s):.2g} (certificate y3={y3:.3g}, y{w1+1}={yw:.3g}, y.d={y3*d[2]+yw*d[w1]:.3g});"
    print(line)
print("RESULT:", "no t admits iso-level at world 3 and an edge world (all max s = 0)" if allzero else "some t feasible")
print("done")
