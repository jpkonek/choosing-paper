# HH3: finite Bayes realisability of the plain posterior family (interior selected points, binary cells).
# Question: are there weights q^p in the open simplex (p in S) and, per active cell c with acting gamble h_c,
# a vector w_c with sign(w_{c,i}) = sign((h_c)_i) (strict guidance) such that for all p in S, c:
#        C_p acts on c   <=>   q^p . w_c > 0 ?
# If yes, the cell witness psi_{i,c}(acting) = -w_{c,i}/mu(c), psi(silence) = 0, psi(other acting) large enough to be
# strictly guiding (e.g. psi(opposite) = +|w|_1 + 1 on the cell, worse than silence at every world where it is
# bad... see note) is a bounded strictly guiding additive ranking on the FULL domain whose q^p-Bayes model is a.e.
# exactly C_p.  Heuristic search: alternating LPs; the final answer is verified EXACTLY in rationals.
import numpy as np
from fractions import Fraction as F
from scipy.optimize import linprog

def data(A):
    act = A.active
    H = []; acts = []
    for c in act:
        s = set(A.cls[c]) - {'0'}
        assert len(s) == 1, "non-binary cell"
        a = s.pop()
        th, cc = A.reps[c][0]; f = (th[0]-cc, th[1]-cc, -cc)
        h = f if a == '+' else tuple(-x for x in f)
        H.append(tuple(1 if x > 0 else -1 for x in h))
        acts.append([1 if A.cls[c][p] != '0' else -1 for p in range(len(A.pts))])
    return np.array(H), np.array(acts)       # H: C x 3 signs; acts: C x S (+1 acting, -1 silent)

def step_w(Q, H, acts, eta=1e-3):
    C = len(H); W = np.zeros((C, 3)); marg = np.zeros(C)
    for c in range(C):
        # maximise t: acts[c,p] * Q[p].w >= t ; eta <= H[c,i] w_i <= 1
        A_ub = np.hstack([-(acts[c][:, None] * Q), np.ones((Q.shape[0], 1))])
        bounds = [((eta, 1) if H[c, i] > 0 else (-1, -eta)) for i in range(3)] + [(None, 1)]
        r = linprog([0, 0, 0, -1], A_ub=A_ub, b_ub=np.zeros(Q.shape[0]), bounds=bounds, method='highs')
        W[c] = r.x[:3]; marg[c] = r.x[3]
    return W, marg

def step_q(W, acts, delta=1e-3):
    S = acts.shape[1]; Q = np.zeros((S, 3)); marg = np.zeros(S)
    for p in range(S):
        A_ub = np.hstack([-(acts[:, p][:, None] * W), np.ones((W.shape[0], 1))])
        r = linprog([0, 0, 0, -1], A_ub=A_ub, b_ub=np.zeros(W.shape[0]), A_eq=[[1, 1, 1, 0]], b_eq=[1],
                    bounds=[(delta, 1)]*3 + [(None, 1)], method='highs')
        Q[p] = r.x[:3]; marg[p] = r.x[3]
    return Q, marg

def search(A, iters=200, verbose=True, Q0=None):
    H, acts = data(A)
    Q = np.array([[float(x) for x in p] for p in A.pts]) if Q0 is None else Q0
    best = -1
    for it in range(iters):
        W, mw = step_w(Q, H, acts)
        Q, mq = step_q(W, acts)
        m = min(mw.min(), mq.min())
        if verbose and (it % 20 == 0 or m > 0): print(f"     it {it}: min margin w-step {mw.min():.2e}, q-step {mq.min():.2e}", flush=True)
        if mq.min() > 1e-7:
            return verify(A, H, acts, W, Q)
    return None

def verify(A, H, acts, W, Q):
    Wq = [[F(round(x*10**9), 10**9) for x in w] for w in W]
    Qq = []
    for q in Q:
        qq = [F(round(x*10**9), 10**9) for x in q]; s = sum(qq); Qq.append([x/s for x in qq])
    ok = all(Wq[c][i]*H[c, i] > 0 for c in range(len(H)) for i in range(3))
    ok &= all(min(q) > 0 for q in Qq)
    ok &= all((sum(a*b for a, b in zip(Qq[p], Wq[c])) > 0) == (acts[c, p] > 0) and
              sum(a*b for a, b in zip(Qq[p], Wq[c])) != 0 for c in range(len(H)) for p in range(len(Qq)))
    return (Wq, Qq) if ok else None

# ---- hinge-loss alternation (more robust than max-min): minimise total violation, margin 1 ----
from scipy.sparse import lil_matrix, csr_matrix
def hinge_w(Q, H, acts, wmax=1e4):
    C = len(H); S = Q.shape[0]; W = np.zeros((C, 3)); viol = 0.0
    for c in range(C):
        # vars w(3), s(S) >= 0: acts*Q.w + s >= 1 ; min sum s ; sign bounds
        A_ub = np.hstack([-(acts[c][:, None] * Q), -np.eye(S)]); b_ub = -np.ones(S)
        bounds = [((1e-6, wmax) if H[c, i] > 0 else (-wmax, -1e-6)) for i in range(3)] + [(0, None)]*S
        r = linprog(np.concatenate([np.zeros(3), np.ones(S)]), A_ub=A_ub, b_ub=b_ub, bounds=bounds, method='highs')
        W[c] = r.x[:3]; viol += r.fun
    return W, viol
def hinge_q(W, acts, delta=1e-4):
    C = W.shape[0]; S = acts.shape[1]; Q = np.zeros((S, 3)); viol = 0.0
    for p in range(S):
        # vars q(3) (scale free: q >= delta, sum q = 1... margin 1 needs scale: use q unnormalised, sum q = 1, W scaled)
        A_ub = np.hstack([-(acts[:, p][:, None] * W), -np.eye(C)]); b_ub = -np.ones(C)
        r = linprog(np.concatenate([np.zeros(3), np.ones(C)]), A_ub=A_ub, b_ub=b_ub, A_eq=[[1, 1, 1] + [0]*C], b_eq=[1],
                    bounds=[(delta, 1)]*3 + [(0, None)]*C, method='highs')
        Q[p] = r.x[:3]; viol += r.fun
    return Q, viol
def search_hinge(A, iters=300, verbose=True, Q0=None, seed=0):
    H, acts = data(A)
    Q = np.array([[float(x) for x in p] for p in A.pts]) if Q0 is None else Q0
    for it in range(iters):
        W, vw = hinge_w(Q, H, acts)
        Q, vq = hinge_q(W, acts)
        if verbose and (it % 10 == 0 or vq < 1e-9): print(f"     hinge it {it}: violation w-step {vw:.3e}, q-step {vq:.3e}", flush=True)
        if vq < 1e-9:
            r = verify(A, H, acts, W, Q)
            if r: return r
    return None

# ---- joint gradient search (smooth squared hinge on both W and Q), then LP polishing and exact verification ----
def search_joint(A, steps=20000, lr=1e-2, margin=1.0, verbose=True, seed=0):
    H, acts = data(A)                       # H: C x 3, acts: C x S
    rng = np.random.default_rng(seed)
    P0 = np.array([[float(x) for x in p] for p in A.pts])
    # parametrise q = softmax(z) (interior), w = H * exp(v) (strict orthant)
    z = np.log(P0); v = np.zeros(H.shape) + rng.normal(0, 0.1, H.shape)
    m1 = [np.zeros_like(z), np.zeros_like(v)]; m2 = [np.zeros_like(z), np.zeros_like(v)]
    for t in range(1, steps+1):
        Q = np.exp(z); Q /= Q.sum(1, keepdims=True)
        Wm = H * np.exp(v)
        M = acts * (Wm @ Q.T) * 100.0        # C x S margins (scaled)
        r = np.maximum(0, margin - M)
        loss = (r**2).sum()
        G = -2 * r * acts * 100.0            # dloss/d(Wm @ Q.T)
        gW = G @ Q                           # C x 3
        gQ = G.T @ Wm                        # S x 3
        gv = gW * Wm
        gz = Q * (gQ - (gQ * Q).sum(1, keepdims=True))
        for k, (g, x) in enumerate(((gz, z), (gv, v))):
            m1[k] = 0.9*m1[k] + 0.1*g; m2[k] = 0.999*m2[k] + 0.001*g*g
            x -= lr * (m1[k]/(1-0.9**t)) / (np.sqrt(m2[k]/(1-0.999**t)) + 1e-12)
        if verbose and t % 2000 == 0: print(f"     joint step {t}: loss {loss:.4e}, violated {(M <= 0).sum()}", flush=True)
        if (M > 0).all():
            Q = np.exp(z); Q /= Q.sum(1, keepdims=True); Wm = H*np.exp(v)
            r_ = verify(A, H, acts, Wm, Q)
            if r_: return r_
    return None
