# HH3: vectorised fragments (models as int8 advice codes over the merged cells) and exact record identification.
# codes: 0 '+', 1 '0', 2 '-', 3 'x'.  Record code per cell: 0 if equal, else 1 + 4*from + to.
import numpy as np, itertools, random
from fractions import Fraction as F
from arr3 import *

CH = '+0-x'; CODE = {c: k for k, c in enumerate(CH)}

def rank_table(A):
    """rk[i, c, code] = world-i rank of advice code on cell c"""
    rk = np.zeros((3, A.N, 4), dtype=np.int8)
    for i in range(3):
        for c in range(A.N):
            for k, ch in enumerate(CH): rk[i, c, k] = rank(ch, A.sg[c], i)
    return rk

class Frag:
    def __init__(self, A, name=''):
        self.A = A; self.name = name
        self.rk = rank_table(A)
        self.X = []; self.kind = []; self.index = {}
        self.sel = []
        for m in range(len(A.pts)):
            v = np.array([CODE[A.cls[c][m]] for c in range(A.N)], dtype=np.int8)
            self.sel.append(self.add(v, f"C{m}"))
        self.incoh = {}

    def add(self, v, kind):
        k = v.tobytes()
        if k in self.index: return self.index[k]
        self.index[k] = len(self.X); self.X.append(v.copy()); self.kind.append(kind)
        return self.index[k]

    def tup(self, m): return tuple(CH[x] for x in self.X[m])

    # ------------- generators -------------
    def add_cube(self, cells=None, alphabet=None, maxn=20000):
        """all cell-measurable models that agree with the selected models off `cells` and, on each listed cell, give
        one of the advices in alphabet[c] (default: the advices the selected models give there)"""
        A = self.A
        cells = A.active if cells is None else cells
        base = self.X[self.sel[0]].copy()
        alph = [sorted(set(CODE[a] for a in A.cls[c])) if alphabet is None else alphabet[c] for c in cells]
        tot = int(np.prod([len(a) for a in alph]))
        if tot > maxn: raise ValueError(f"cube too large: {tot}")
        n0 = len(self.X)
        for combo in itertools.product(*alph):
            v = base.copy(); v[cells] = combo
            self.add(v, 'cube')
        return len(self.X) - n0

    def add_parallelograms(self, base=None, rounds=1):
        base = list(self.sel) if base is None else list(base)
        n0 = len(self.X)
        for _ in range(rounds):
            cur = list(base)
            new = []
            for a, b in itertools.combinations(cur, 2):
                for c in cur:
                    if c == a or c == b: continue
                    xa, xb, xc = self.X[a], self.X[b], self.X[c]
                    okb = xb == xc; oka = xa == xc
                    if np.all(okb | oka):
                        v = np.where(okb, xa, xb).astype(np.int8)
                        k = v.tobytes()
                        if k not in self.index:
                            new.append(self.add(v, f"P({self.kind[a]}+{self.kind[b]}-{self.kind[c]})"))
            base = cur + new
        return len(self.X) - n0

    def add_flips(self, bases, cells=None, advs=(0, 1, 2)):
        cells = self.A.active if cells is None else cells
        n0 = len(self.X)
        for m in bases:
            for c in cells:
                for a in advs:
                    if a == self.X[m][c]: continue
                    v = self.X[m].copy(); v[c] = a
                    self.add(v, f"F({self.kind[m]};c{c}:{CH[self.X[m][c]]}>{CH[a]})")
        return len(self.X) - n0

    def add_splices(self, pairs, regions):
        """C_a on region (boolean mask over cells), C_b elsewhere"""
        n0 = len(self.X)
        for a, b in pairs:
            for name, R in regions:
                v = np.where(R, self.X[a], self.X[b]).astype(np.int8)
                self.add(v, f"S({self.kind[a]}|{name}|{self.kind[b]})")
        return len(self.X) - n0

    # ------------- records -------------
    def records(self, verify=True):
        """RID[a,b] = record id of rec(X_a, X_b) (a != b), exact: rows are hashed and then verified against a
        representative row; returns (RID, reps) with reps[k] the record code vector."""
        A = self.A; M = len(self.X)
        act = np.array([c for c in range(A.N) if len(set(int(self.X[m][c]) for m in range(M))) > 1], dtype=np.int64)
        self.act = act
        Xs = np.array(self.X)[:, act].astype(np.int16)        # M x C
        C = len(act)
        rng = np.random.default_rng(12345)
        w1 = rng.integers(1, 2**61, size=C, dtype=np.int64); w2 = rng.integers(1, 2**61, size=C, dtype=np.int64)
        H1 = np.zeros((M, M), dtype=np.int64); H2 = np.zeros((M, M), dtype=np.int64)
        for a in range(M):
            Z = np.where(Xs != Xs[a], 1 + 4*Xs[a] + Xs, 0).astype(np.int64)
            with np.errstate(over='ignore'):
                H1[a] = Z @ w1; H2[a] = Z @ w2
        keys = H1.astype(np.uint64).astype(object) if False else None
        pair = np.stack([H1.ravel(), H2.ravel()], axis=1)
        uniq, inv, first = np.unique(pair, axis=0, return_inverse=True, return_index=True)[0:3:1] if False else (None, None, None)
        u, idx, inv = np.unique(pair, axis=0, return_index=True, return_inverse=True)
        inv = inv.reshape(M, M)
        # diagonal: identity record; give it id -1
        reps = []
        for k in range(len(u)):
            a, b = divmod(int(idx[k]), M)
            reps.append(np.where(Xs[a] != Xs[b], 1 + 4*Xs[a] + Xs[b], 0).astype(np.int8))
        reps = np.array(reps)
        if verify:
            for a in range(M):
                Z = np.where(Xs != Xs[a], 1 + 4*Xs[a] + Xs, 0).astype(np.int8)
                assert np.array_equal(Z, reps[inv[a]]), "hash collision"
        ident = inv[0, 0]
        assert not reps[ident].any()
        RID = inv.astype(np.int64)
        # renumber so that the identity record is excluded: map ident -> -1
        RID[RID == ident] = -1
        RID[RID > ident] -= 1
        reps = np.delete(reps, ident, axis=0)
        np.fill_diagonal(RID, -1)
        assert (RID >= 0).sum() == M*(M-1)
        return RID, reps

    def guidance(self, reps):
        """g[i,k] = +1 strict improvement (X_a strictly better at i, never worse), -1 strict worsening, 0 mixed"""
        act = self.act
        R = len(reps); g = np.zeros((3, R), dtype=np.int8)
        nz = reps > 0
        fr_ = np.where(nz, (reps.astype(np.int16) - 1) // 4, 0); to_ = np.where(nz, (reps.astype(np.int16) - 1) % 4, 0)
        for i in range(3):
            rk = self.rk[i][act]                       # C x 4
            cidx = np.arange(len(act))[None, :]
            rf = rk[cidx, fr_]; rt = rk[cidx, to_]
            better = np.any(nz & (rf < rt), axis=1); worse = np.any(nz & (rf > rt), axis=1)
            g[i] = np.where(better & ~worse, 1, np.where(worse & ~better, -1, 0))
        return g

    def rev_ids(self, RID):
        return RID.T

    # ------------- coherence certificates (exact; float pre-screen) -------------
    def _sample_points(self, per_cell=8):
        A = self.A
        P = []; owner = []
        for c in range(A.N):
            for (th, cc) in A.reps[c][:per_cell]:
                P.append(gamble(th, cc)); owner.append(c)
        return P, owner

    def certify_incoherence(self, models=None, per_cell=8, tries=3000, seed=0):
        A = self.A
        P, owner = self._sample_points(per_cell)
        Pf = np.array([[float(x) for x in p] for p in P])
        polys = [np.array([[float(x), float(y)] for x, y in poly]) for poly in A.polys]
        def classify_f(G):
            """float classification of oriented gambles G (n x 3); returns (cell or -1, orientation sign)"""
            s = np.sign(G[:, 0]); Fv = G * s[:, None]
            th = np.stack([Fv[:, 0]-Fv[:, 2], Fv[:, 1]-Fv[:, 2]], axis=1); c = -Fv[:, 2]
            cls = []
            for V in polys:
                d = th @ V.T; lo = d.min(axis=1); hi = d.max(axis=1)
                cls.append(np.where(c < lo, 0, np.where(c > hi, 2, 1)))
            cls = np.stack(cls, axis=1)
            sg = (Fv > 0)
            out = np.full(len(G), -1)
            for n in range(len(G)):
                key = (tuple(CH[x] for x in cls[n]), tuple(1 if t else -1 for t in sg[n]))
                out[n] = A.kidx.get(key, -1)
            return out, s
        rng = np.random.default_rng(seed)
        models = range(len(self.X)) if models is None else models
        sel = set(self.sel); cnt = 0
        for m in models:
            if m in sel: continue
            X = self.X[m]
            if np.any(X == 3):
                c = int(np.nonzero(X == 3)[0][0]); self.incoh[m] = ('x', c); cnt += 1; continue
            ow = np.array(owner)
            accp = np.nonzero(np.isin(X[ow], [0]))[0]; accm = np.nonzero(np.isin(X[ow], [2]))[0]
            Acc = np.concatenate([Pf[accp], -Pf[accm]]); AccE = [P[k] for k in accp] + [tuple(-x for x in P[k]) for k in accm]
            if len(Acc) < 2: continue
            i1 = rng.integers(0, len(Acc), tries); i2 = rng.integers(0, len(Acc), tries)
            t = rng.choice([1/3, 1.0, 3.0], tries)
            G = Acc[i1] + t[:, None]*Acc[i2]
            cl, s = classify_f(G)
            ok = (cl >= 0)
            adv = np.where(ok, X[np.maximum(cl, 0)], 1)
            accepted = np.where(s > 0, (adv == 0) | (adv == 3), (adv == 2) | (adv == 3))
            cand = np.nonzero(ok & ~accepted & (i1 != i2))[0]
            for n in cand[:20]:
                tt = {1/3: F(1, 3), 1.0: F(1), 3.0: F(3)}[float(t[n])]
                g1 = AccE[i1[n]]; g2 = AccE[i2[n]]
                g3 = tuple(x + tt*y for x, y in zip(g1, g2))
                if self.accepts(m, g1) is True and self.accepts(m, g2) is True and self.accepts(m, g3) is False:
                    self.incoh[m] = ('cone', g1, g2, tt, g3); cnt += 1; break
        return cnt

    def accepts(self, m, g):
        g = tuple(F(x) for x in g)
        if g[0] > 0: f, s = g, 1
        elif g[0] < 0: f, s = tuple(-x for x in g), -1
        else: return None
        c = self.A.classify(f)
        if c is None: return None
        a = CH[self.X[m][c]]
        return (a in '+x') if s == 1 else (a in '-x')

    def check_cert(self, m):
        cert = self.incoh[m]
        if cert[0] == 'x': return self.X[m][cert[1]] == 3
        _, g1, g2, t, g3 = cert
        return self.accepts(m, g1) is True and self.accepts(m, g2) is True and \
            tuple(x + t*y for x, y in zip(g1, g2)) == tuple(g3) and self.accepts(m, g3) is False
