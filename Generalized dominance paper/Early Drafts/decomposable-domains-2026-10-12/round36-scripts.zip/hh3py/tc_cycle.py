# HH3: an explicit longer strict cycle in a (TC)-only solution (reported as BRIEF28 requires), exactly re-checked:
# every edge's record, its acceptance at the world, the strict edge, and that no 3-cycle with a strict step exists.
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fast import *; from sat4 import *; from battery import build, u
fr, info = build('hexR1 + flips + pairflips(C0)', tri_grid(u, F(1,100), 1), F(3,10), flips=range(7), pflips=([0], None, None))
P = EdgeProblem(fr, mode='TC', selectors=False, verbose=False)
ok, _, it = P.solve(); assert ok
ms = P.model
for i in range(3):
    cyc = P.strict_cycles(ms, i, limit=200)
    cyc = sorted(cyc, key=len)
    long = [c for c in cyc if len(c) >= 5]      # node list with repeated endpoint: >= 4 distinct nodes
    print(f"world {i+1}: strict cycles found {len(cyc)}, of length >= 4: {len(long)}")
    if long:
        c = long[0]
        print("  shortest such cycle (models):", " -> ".join(f"{n}:{fr.kind[n]}" for n in c))
        acc = lambda a, b: ms[P.var(i, P.e(a, b)) - 1] > 0
        for a, b in zip(c, c[1:]):
            k = P.e(a, b); r = P.reps[k]; sup = int((r > 0).sum())
            print(f"    {a}->{b}: accepted {acc(a,b)}, reverse accepted {acc(b,a)}, record support {sup} cells, "
                  f"guidance sign at world {i+1}: {int(P.gsign[i, k])}")
        # TC check on every consecutive triple of the cycle
        n = len(c) - 1
        bad = 0
        for s in range(n):
            a, b, d = c[s], c[(s+1) % n], c[(s+2) % n]
            if (d, a) in P.edge_index and acc(d, a) and not acc(a, d): bad += 1
        print(f"    consecutive 3-chains closing strictly backwards: {bad} (TC forbids these; the long cycle evades TC)")
        break
