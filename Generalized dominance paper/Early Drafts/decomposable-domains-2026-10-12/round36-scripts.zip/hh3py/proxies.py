# HH3: the two finite PROXIES (not consequences of the axioms on a finite fragment), with minimal UNSAT cores.
#   csp : closed-section proxy at u: if C_q <=_i X for all six grid neighbours q of u, then C_u <=_i X;
#   cdom: every certified-incoherent model of the fragment is dominated by a selected model OF THE FRAGMENT.
# Run: python3 -I proxies.py
import sys, os, time, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fast import *; from sat4 import *; from battery import build, pair_flips, u
from collections import Counter

def describe_core(P, core):
    kinds = Counter(P.groups[s][0] for s in core)
    return dict(kinds)

def run(name, pts, eps, flips, pfl, opts, maxcore=True):
    fr, info = build(name, pts, eps, flips=flips, pflips=pfl)
    iu = [k for k, p in enumerate(fr.A.pts) if p == u][0]
    nb = [k for k, p in enumerate(fr.A.pts) if p != u and max(abs(p[i]-u[i]) for i in range(3)) <= max(abs(q[i]-u[i]) for q in fr.A.pts for i in range(3))/ (1 if len(pts) == 7 else 2)]
    print(f"== {name}: " + "; ".join(info) + f"; u index {iu}, neighbours {nb}", flush=True)
    for label, kw in opts:
        kw = dict(kw)
        if kw.pop('csp_on', False): kw['csp'] = [(iu, nb)]
        for mode in ('FC', 'TR'):
            t = time.time()
            P = EdgeProblem(fr, mode=mode, selectors=False, verbose=False, **kw)
            ok, _, it = P.solve()
            line = f"   [{label}] {mode}: {'SAT' if ok else 'UNSAT'} ({time.time()-t:.0f}s, rounds {it}, cuts {P.ncuts})"
            if not ok and maxcore:
                P2 = EdgeProblem(fr, mode=mode, selectors=True, verbose=False, **kw)
                ok2, core, _ = P2.solve()
                assert not ok2
                core = P2.minimise_core(core)
                line += f"; minimal core over requirement groups: {len(core)} groups {describe_core(P2, core)}"
                line += "\n      core: " + "; ".join(str(P2.groups[s]) for s in core[:12])
            print(line, flush=True)

if __name__ == '__main__':
    opts = [('no proxy', {}), ('csp at u', dict(csp_on=True)), ('cdom', dict(cdom=True)), ('csp+cdom', dict(csp_on=True, cdom=True))]
    run('hexR1 + flips(all) + pairflips(u)', tri_grid(u, F(1,100), 1), F(3,10), range(7), ([3], None, None), opts)
