# HH3: complete cell worlds (every cell-measurable model with the advices the selected models give), ALL ordered pairs
# as comparison edges (dense), FC / TC / TR.  Run: python3 -I cube_dense.py
import sys, os, time; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fast import *; from sat3 import Problem
from battery import FRAGS, build
names = sys.argv[1:] or ['cube_u_nbr', 'cube_usp_e1', 'cube_usp_e1_small', 'cube_usp_e1_eps1/10', 'cube_usp_e1_eps1/2', 'cube_u_vertices']
for nm in names:
    kw = dict(FRAGS[nm]); fr, info = build(nm, kw.pop('pts'), kw.pop('eps'), **kw)
    print(f"== {nm} (dense, all ordered pairs): " + "; ".join(info), flush=True)
    for mode in ('FC', 'TC', 'TR'):
        t = time.time(); P = Problem(fr, mode=mode, selectors=False)
        ok, core, it = P.solve()
        line = f"   {mode}: {'SAT' if ok else 'UNSAT'} [records {P.R}, groups {P.ngroups}, lazy rounds {it}, cuts {P.ncuts}, {time.time()-t:.0f}s]"
        if ok:
            cn = P.dense_counts(P.model)
            line += "\n      per world ties/strict/incomparable/non-transitive pairs: " + "; ".join(
                f"{c['tie']}/{c['strict']}/{c['incomparable']}/{c['nontransitive_pairs']}" for c in cn)
            if mode == 'TC':
                line += f"\n      strict cycles (length >= 4) in the TC solution: {[len(P.strict_cycles(P.model, i)) for i in range(3)]}"
        print(line, flush=True)
