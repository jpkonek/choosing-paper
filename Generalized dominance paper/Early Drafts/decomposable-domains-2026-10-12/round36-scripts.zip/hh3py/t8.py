import sys, time; sys.path.insert(0,'.')
from arr3 import *; from bayes_real import *
u=(F(1,3),)*3
for name, pts, eps in [('hexR2 eps1/2', tri_grid(u,F(1,100),2), F(1,2)), ('hexR2 step1/1000', tri_grid(u,F(1,1000),2), F(3,10)),
                       ('hexR3 step1/200', tri_grid(u,F(1,200),3), F(3,10))]:
    A = Arrangement(pts, eps); t=time.time()
    print(name, len(pts), 'cells', len(A.active), flush=True)
    r = search_joint(A, steps=200000, lr=5e-3, verbose=False); print('   realised exactly' if r else '   not found', f"{time.time()-t:.0f}s", flush=True)
