# HH3 battery: FC / TC / TR searches (and the additive MILP) on exact fragments of the plain posterior family.
# Run:  python3 -I battery.py [names...]   (from inside hh3py/)
import sys, os, time, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fast import *; from sat4 import *; from additive import *; from diag import *
u = (F(1,3),)*3
E1 = (F(2), F(-1), F(-1)); E3 = (F(-1), F(-1), F(2))
def simplex_grid(n): return [(F(i,n),F(j,n),F(n-i-j,n)) for i in range(n+1) for j in range(n+1-i)]
def along(c, d, t): return tuple(c[i] + t*d[i] for i in range(3))
V = [(F(1),F(0),F(0)), (F(0),F(1),F(0)), (F(0),F(0),F(1))]

def pair_flips(fr, bases, ncells=None, rng=None, maxpairs=None):
    A = fr.A; n0 = len(fr.X)
    cells = A.active if ncells is None else rng.sample(A.active, min(ncells, len(A.active)))
    prs = list(itertools.combinations(cells, 2))
    if maxpairs and len(prs) > maxpairs: prs = rng.sample(prs, maxpairs)
    for m in bases:
        for c1, c2 in prs:
            v = fr.X[m].copy()
            for c in (c1, c2):
                alts = [a for a in sorted(set(CODE[x] for x in A.cls[c])) + [1] if a != v[c]]
                v[c] = alts[0]
            fr.add(v, f"F2({fr.kind[m]};{c1},{c2})")
    return len(fr.X) - n0

def build(name, pts, eps, cube=False, flips=None, pflips=None, par=0, splices=None, seed=1):
    rng = random.Random(seed)
    A = Arrangement(pts, eps); fr = Frag(A, name)
    info = [f"{len(pts)} selected", f"{A.N} cells ({len(A.active)} active)"]
    if cube: info.append(f"cube {fr.add_cube()}")
    if par: info.append(f"parallelograms {fr.add_parallelograms(rounds=par)}")
    if flips is not None: info.append(f"flips {fr.add_flips([fr.sel[k] for k in flips])}")
    if pflips is not None:
        bases, ncells, maxp = pflips
        info.append(f"pair-flips {pair_flips(fr, [fr.sel[k] for k in bases], ncells, rng, maxp)}")
    if splices is not None:
        pats = sorted(set(A.sg)); regs = [(str(p), np.array([A.sg[c] == p for c in range(A.N)])) for p in pats]
        prs = [(fr.sel[a], fr.sel[b]) for a, b in itertools.permutations(splices, 2)]
        info.append(f"sign-splices {fr.add_splices(prs, regs)}")
    t = time.time(); n = fr.certify_incoherence(tries=600)
    bad = [m for m in fr.incoh if not fr.check_cert(m)]
    assert not bad
    info.append(f"models {len(fr.X)}; certified incoherent {n} (all certificates re-checked exactly)")
    return fr, info

def run(fr, info, modes=('FC', 'TC', 'TR'), additive=True, csp=None, out=print, diag=True):
    out(f"== {fr.name}: " + "; ".join(info))
    res = {}
    for mode in modes:
        t = time.time()
        P = EdgeProblem(fr, mode=mode, selectors=False, csp=csp, verbose=False)
        ok, core, it = P.solve()
        line = f"   {mode}: {'SAT' if ok else 'UNSAT'}  [edges {len(P.pairs)}, records {P.R}, groups {P.ngroups}, lazy rounds {it}, cuts {P.ncuts}, {time.time()-t:.0f}s]"
        if ok and diag:
            cn = counts(P, P.model)
            line += "\n      per world (ties/strict/incomparable/nontransitive): " + \
                "; ".join(f"{c['tie']}/{c['strict']}/{c['incomparable']}/{c['nontransitive_triples']}" for c in cn)
            ad = [additive_test(P, P.model, i, 'exact') for i in range(3)]
            ex = [additive_test(P, P.model, i, 'ext') for i in range(3)]
            line += f"\n      this solution exactly additive per world: {ad}; additively Suzumura-extendable: {ex}"
            if mode == 'TC' and diag:
                cyc = [len(P.strict_cycles(P.model, i)) for i in range(3)]
                line += f"\n      strict cycles of length >= 4 in the TC solution (one per strict edge, up to 50): {cyc}"
        res[mode] = ok
        out(line); sys.stdout.flush()
    if additive:
        t = time.time()
        r = additive_system(fr, verbose=False)
        out(f"   ADDITIVE (strict competitiveness, cell witnesses, exact check): {'FOUND' if r[0] else 'not found (status %s)' % r[1]} ({time.time()-t:.0f}s)")
    return res

FRAGS = {
 'cube_u_nbr':   dict(pts=[u, (u[0]+F(1,100), u[1]-F(1,100), u[2])], eps=F(3,10), cube=True),
 'cube_usp_e1':  dict(pts=[u, along(u, E1, -F(1,100)), along(u, E1, F(1,100))], eps=F(3,10), cube=True),
 'cube_usp_e1_small': dict(pts=[u, along(u, E1, -F(1,1000)), along(u, E1, F(1,1000))], eps=F(3,10), cube=True),
 'cube_usp_e1_eps1/10': dict(pts=[u, along(u, E1, -F(1,100)), along(u, E1, F(1,100))], eps=F(1,10), cube=True),
 'cube_usp_e1_eps1/2': dict(pts=[u, along(u, E1, -F(1,100)), along(u, E1, F(1,100))], eps=F(1,2), cube=True),
 'cube_u_vertices': dict(pts=[u] + V, eps=F(3,10), cube=True),
 'hexR1_flips':  dict(pts=tri_grid(u, F(1,100), 1), eps=F(3,10), flips=range(7), pflips=([0], None, None)),
 'hexR2_par_flips': dict(pts=tri_grid(u, F(1,100), 2), eps=F(3,10), par=2, flips=[9], pflips=([9], 40, 400), splices=[9, 3, 15]),
 'hexR2_vertices': dict(pts=tri_grid(u, F(1,100), 2) + V, eps=F(3,10), par=1, flips=[9]),
 'grid6_boundary': dict(pts=simplex_grid(6), eps=F(3,10), par=1),
}

if __name__ == '__main__':
    names = sys.argv[1:] or list(FRAGS)
    for nm in names:
        kw = dict(FRAGS[nm]); fr, info = build(nm, kw.pop('pts'), kw.pop('eps'), **kw)
        add = len(fr.X) * len(fr.sel) < 40000
        run(fr, info, additive=add)
