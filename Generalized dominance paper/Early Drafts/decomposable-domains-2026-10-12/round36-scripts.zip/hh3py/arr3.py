# HH3: exact cell arrangement for finitely many selected models of the plain posterior family.
# Copied and adapted from ff1py/arr.py (itself an adapted copy of ee2py/cells.py); nothing there is modified.
#
# Additions: every merged cell keeps ALL its open-piece representatives (one per open arc x open c-interval),
# and an exact classifier maps any rational gamble to its merged cell (or reports that it lies on a boundary).
#
# Conventions (write-up Sec. 2): a pair {f,-f} is indexed by its orientation with f_1 > 0.  f <-> (theta, c) up to
# positive scale: f = (theta1 - c, theta2 - c, -c); for m in aff(Delta) in 2-D coordinates (m1, m2),
# m.f = theta.m - c.  A credal polygon K accepts f ('+') iff c < min_K theta.m, accepts -f ('-') iff
# c > max_K theta.m, and is silent ('0') otherwise.  Open cells (open theta-arcs between consecutive critical
# directions x open c-intervals between consecutive breakpoints) are non-null open cones, every class and sign is
# constant on each, and their union is conull.  Cells with the same column (classes of all listed models, sign
# pattern) are merged; a merged cell is a finite union of non-null open cones.
from fractions import Fraction as F
import itertools, functools

def perp(v): return (-v[1], v[0])
def half(d): return 0 if (d[1] > 0 or (d[1] == 0 and d[0] > 0)) else 1
def cross(a, b): return a[0]*b[1] - a[1]*b[0]
def cmpang(a, b):
    ha, hb = half(a), half(b)
    if ha != hb: return -1 if ha < hb else 1
    c = cross(a, b)
    return -1 if c > 0 else (1 if c < 0 else 0)
DELTA2 = [(F(1), F(0)), (F(0), F(1)), (F(0), F(0))]

def arc_reps(points):
    dirs = [(F(1), F(0)), (F(0), F(1)), (F(-1), F(0)), (F(0), F(-1))]
    pts = list(set(points))
    for a, b in itertools.combinations(pts, 2):
        v = (a[0]-b[0], a[1]-b[1])
        q = perp(v); dirs += [q, (-q[0], -q[1])]
    dirs.sort(key=functools.cmp_to_key(cmpang))
    cd = []
    for d in dirs:
        if cd and cmpang(cd[-1], d) == 0: continue
        cd.append(d)
    n = len(cd)
    return [(cd[i][0]+cd[(i+1) % n][0], cd[i][1]+cd[(i+1) % n][1]) for i in range(n)]

def cells(polys):
    """dict key=(classes, signs) -> list of representatives (theta, c), problems with g_1 > 0; one rep per open piece"""
    pts = [p for P in polys for p in P] + DELTA2
    out = {}
    for th in arc_reps(pts):
        lo = [min(th[0]*x+th[1]*y for x, y in P) for P in polys]
        hi = [max(th[0]*x+th[1]*y for x, y in P) for P in polys]
        bps = sorted(set(lo + hi + [th[0], th[1], F(0)]))
        reps = [bps[0]-1] + [(bps[k]+bps[k+1])/2 for k in range(len(bps)-1)] + [bps[-1]+1]
        for c in reps:
            g = (th[0]-c, th[1]-c, -c)
            if g[0] <= 0: continue          # index each pair once, by its orientation with g_1 > 0
            sg = tuple(1 if x > 0 else -1 for x in g)
            cls = tuple('+' if c < lo[k] else ('-' if c > hi[k] else '0') for k in range(len(polys)))
            out.setdefault((cls, sg), []).append((th, c))
    return out

def rank(adv, sg, i):
    """world-i rank of an advice on a problem with sign pattern sg: good 0 < none 1 < bad 2 < contradictory 3"""
    if adv == '0': return 1
    if adv == 'x': return 3
    return 0 if ((adv == '+') == (sg[i] > 0)) else 2

def make_T(eps):
    c0 = (1-eps)/3
    return [[c0 + (eps if i == k else 0) for i in range(3)] for k in range(3)]

def post3(p, T):
    out = []
    for v in T:
        w = [F(p[i])*v[i] for i in range(3)]; t = sum(w)
        if t == 0: continue
        out.append([x/t for x in w])
    return out
def post2(p, T): return sorted(set((m[0], m[1]) for m in post3(p, T)))

def gamble(th, c): return (th[0]-c, th[1]-c, -c)

class Arrangement:
    """Selected models C_p (p in pts) of the plain posterior family for T = T1(eps); merged cells."""
    def __init__(self, pts, eps=F(3, 10)):
        self.eps = F(eps); self.T = make_T(self.eps)
        self.pts = [tuple(F(x) for x in p) for p in pts]
        assert all(sum(p) == 1 and min(p) >= 0 for p in self.pts)
        assert len(set(self.pts)) == len(self.pts)
        self.polys = [post2(p, self.T) for p in self.pts]
        cd = cells(self.polys)
        self.keys = sorted(cd.keys())
        self.kidx = {k: n for n, k in enumerate(self.keys)}
        self.reps = [cd[k] for k in self.keys]
        self.cls = [k[0] for k in self.keys]      # cls[c][m] = advice of selected model m on cell c
        self.sg = [k[1] for k in self.keys]
        self.N = len(self.keys)
        self.active = [c for c in range(self.N) if len(set(self.cls[c])) > 1]

    def classify(self, f):
        """merged cell of the problem whose orientation is f (f_1 > 0), or None if f is on a cell boundary"""
        f = tuple(F(x) for x in f)
        if f[0] <= 0 or f[1] == 0 or f[2] == 0: return None
        th = (f[0]-f[2], f[1]-f[2]); c = -f[2]
        cls = []
        for P in self.polys:
            lo = min(th[0]*x+th[1]*y for x, y in P); hi = max(th[0]*x+th[1]*y for x, y in P)
            if c == lo or c == hi: return None
            cls.append('+' if c < lo else ('-' if c > hi else '0'))
        sg = tuple(1 if x > 0 else -1 for x in f)
        return self.kidx.get((tuple(cls), sg))

def tri_grid(center, delta, R, hexagon=True):
    """points center + delta*(a, b, -a-b) for integers a, b with hexagonal radius <= R"""
    out = []
    for a in range(-R, R+1):
        for b in range(-R, R+1):
            cc = -a-b
            if hexagon and max(abs(a), abs(b), abs(cc)) > R: continue
            p = (F(center[0]) + delta*a, F(center[1]) + delta*b, F(center[2]) + delta*cc)
            if min(p) < 0: continue
            out.append(p)
    return out
