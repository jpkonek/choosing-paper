# HH3: explicit description of the (proxy-only) cdom core found by proxies.py.
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fast import *
from battery import u
from arr3 import tri_grid
A = Arrangement(tri_grid(u, F(1,100), 1), F(3,10)); fr = Frag(A, 'x')
fr.add_flips(fr.sel)          # same generation order as build(): flips first, then pair flips
import battery, random
battery.pair_flips(fr, [fr.sel[3]], None, random.Random(1), None)
for m in [1055, 905, 755, 605, 455, 305, 155]:
    print(m, fr.kind[m])
print('selected points:', [tuple(str(x) for x in p) for p in A.pts])
X = fr.X[1055]; c = int(np.nonzero(X != fr.X[fr.sel[6]])[0][0]) if np.any(X != fr.X[fr.sel[6]]) else None
for m in [1055]:
    for s in fr.sel:
        d = np.nonzero(fr.X[m] != fr.X[s])[0]
        print(f"  rec({fr.kind[s]} -> {m}): cells {list(d)[:6]}{'...' if len(d)>6 else ''} ({len(d)} cells)")
c = 74 if False else None
