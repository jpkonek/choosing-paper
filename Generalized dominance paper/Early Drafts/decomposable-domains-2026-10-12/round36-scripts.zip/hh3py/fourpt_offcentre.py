# HH3: exact 4-model certificate at the off-centre hexagon (centre (1/5,3/5,1/5), step 1/100, eps 3/10).
import sys, os, itertools; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from arr3 import *; from four_point2 import labelled, obstructed; from fourpt_cert import certificate
ctr = (F(1,5), F(3,5), F(1,5)); step = F(1,100)
pts = tri_grid(ctr, step, 2); A = Arrangement(pts, F(3,10)); rows_ = labelled(A)
bad = [q for q in itertools.combinations(range(len(pts)), 4) if obstructed(rows_, q)]
print(f"off-centre hexR2: {len(pts)} models; obstructed selected 4-sets {len(bad)}")
q = bad[0]; offs = [tuple(int((pts[k][i]-ctr[i])/step) for i in range(3)) for k in q]
print("   certificate models (offsets from the centre):", offs)
for key, g, adv in certificate(A, q):
    print(f"     split {[offs[q.index(k)] for k in key]}: g = ({', '.join(str(x) for x in g)}); advice {adv}")
