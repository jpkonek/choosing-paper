# HH3: SAT formulation on a finite fragment with a chosen set of comparison edges (pairs of fragment models).
#
# Every restriction of a full system to a set of pairs inherits (G), (IB) (record identity), and every no-reversal
# condition (a cycle in a subgraph is a cycle).  So all constraints below are NECESSARY conditions on any full system
# (with the plain posterior selection), except the optional closed-section proxy 'csp', which is a heuristic.
#
# Variables y[i][r] = "record r accepted at world i", r over the records of the chosen pairs (records equal iff same
# support and same before/after advice on every merged cell).
# Hard: (G) units; lazily added no-reversal cuts (FC: any cycle with a strict edge; TC: 3-cycles; TR: transitivity
# on triangles of chosen pairs).
# Groups (selector literals, for cores): comp(p,X), und(p,X), C(X,p), csp(...).
import numpy as np
from collections import deque
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components
from pysat.solvers import Solver

class EdgeProblem:
    def __init__(self, fr, pairs=None, mode='FC', undom='all', use_C=True, csp=None, solver='g4', verbose=True,
                 extra_pairs=(), selectors=True, cdom=False, complete=False):
        self.fr = fr; A = fr.A; self.mode = mode
        M = len(fr.X); self.M = M
        Xs = np.array(fr.X).astype(np.int16)
        act = np.array([c for c in range(A.N) if len(np.unique(Xs[:, c])) > 1], dtype=np.int64)
        fr.act = act
        Xa = Xs[:, act]
        sel = list(fr.sel); self.sel = sel
        if pairs is None:
            P = set()
            for s in sel:
                for x in range(M):
                    if x != s: P.add((s, x)); P.add((x, s))
            for e in extra_pairs:
                if e[0] != e[1]: P.add(tuple(e)); P.add((e[1], e[0]))
            pairs = sorted(P)
        self.pairs = pairs
        pa = np.array([p[0] for p in pairs]); pb = np.array([p[1] for p in pairs])
        # record code rows, hashed then verified exactly
        rng = np.random.default_rng(7)
        C = len(act)
        w1 = rng.integers(1, 2**61, size=C, dtype=np.int64); w2 = rng.integers(1, 2**61, size=C, dtype=np.int64)
        H = np.zeros((len(pairs), 2), dtype=np.int64)
        B = max(1000, 20000000 // max(1, C))
        for s0 in range(0, len(pairs), B):
            a = Xa[pa[s0:s0+B]]; b = Xa[pb[s0:s0+B]]
            Z = np.where(a != b, 1 + 4*a + b, 0).astype(np.int64)
            with np.errstate(over='ignore'):
                H[s0:s0+B, 0] = Z @ w1; H[s0:s0+B, 1] = Z @ w2
        u, idx, inv = np.unique(H, axis=0, return_index=True, return_inverse=True)
        inv = inv.ravel()
        reps = np.where(Xa[pa[idx]] != Xa[pb[idx]], 1 + 4*Xa[pa[idx]] + Xa[pb[idx]], 0).astype(np.int8)
        for s0 in range(0, len(pairs), B):
            a = Xa[pa[s0:s0+B]]; b = Xa[pb[s0:s0+B]]
            Z = np.where(a != b, 1 + 4*a + b, 0).astype(np.int8)
            assert np.array_equal(Z, reps[inv[s0:s0+B]]), "hash collision"
        assert np.all(reps.any(axis=1))
        self.reps = reps; self.eid = inv; R = len(reps); self.R = R
        self.pa, self.pb = pa, pb
        self.edge_index = {p: n for n, p in enumerate(pairs)}
        self.var = lambda i, k: int(1 + i*R + k)
        self.nv = 3*R
        self.S = Solver(name=solver)
        self.gsign = fr.guidance(reps)
        nG = 0
        for i in range(3):
            for k in np.nonzero(self.gsign[i] == 1)[0]: self.S.add_clause([self.var(i, k)]); nG += 1
            for k in np.nonzero(self.gsign[i] == -1)[0]: self.S.add_clause([-self.var(i, k)]); nG += 1
        self.groups = {}; self.gclauses = {}
        def e(a, b): return int(inv[self.edge_index[(a, b)]])
        self.e = e
        self.ngroups = 0
        def newsel(desc, clauses):
            self.ngroups += 1
            if not selectors:
                for cl in clauses: self.S.add_clause(cl)
                return None
            self.nv += 1; s = self.nv
            self.groups[s] = desc; self.gclauses[s] = clauses
            for cl in clauses: self.S.add_clause([-s] + cl)
            return s
        self.newsel = newsel
        for pi, m in enumerate(sel):
            p = A.pts[pi]; supp = [i for i in range(3) if p[i] > 0]
            for x in range(M):
                if x == m or (m, x) not in self.edge_index: continue
                k = e(m, x)
                newsel(('comp', pi, x), [[self.var(i, k) for i in supp]])
                if undom == 'all' or (undom == 'u' and len(set(p)) == 1):
                    kx = e(x, m)
                    newsel(('und', pi, x), [[-self.var(i, kx) for i in range(3)] + [self.var(j, k)] for j in range(3)])
        if use_C:
            for x in fr.incoh:
                for pi, m in enumerate(sel):
                    if (x, m) not in self.edge_index: continue
                    k1, k2 = e(x, m), e(m, x)
                    newsel(('C', x, pi), [[-self.var(i, k1) for i in range(3)] + [-self.var(i, k2) for i in range(3)]])
        if cdom:
            # PROXY (not a consequence of the axioms on a finite fragment): every certified-incoherent X is dominated
            # by some SELECTED model of the fragment (HH1 Prop 1 gives a selected dominator somewhere in Delta).
            for x in fr.incoh:
                ds = []
                for pi, m in enumerate(sel):
                    if (x, m) not in self.edge_index: continue
                    self.nv += 1; dvar = self.nv; ds.append(dvar)
                    k1, k2 = e(m, x), e(x, m)
                    for i in range(3): self.S.add_clause([-dvar, self.var(i, k1)])
                    self.S.add_clause([-dvar] + [-self.var(i, k2) for i in range(3)])
                newsel(('Cdom', x), [ds])
        if complete:
            # completeness on the chosen pairs (each pair comparable at each world): with (TC) this forces transitivity
            for (a, b) in pairs:
                if a < b:
                    for i in range(3): newsel(('compl', a, b, i), [[self.var(i, e(a, b)), self.var(i, e(b, a))]])
        if csp:
            for (pi, nbrs) in csp:
                m = sel[pi]
                for x in range(M):
                    if x == m or x in [sel[q] for q in nbrs]: continue
                    for i in range(3):
                        cl = [-self.var(i, e(sel[q], x)) for q in nbrs] + [self.var(i, e(m, x))]
                        newsel(('csp', pi, x, i), [cl])
        self.ncuts = 0
        if verbose: print(f"   [{fr.name}|{mode}] models {M}, edges {len(pairs)}, records {R}, (G)-units {nG}, groups {self.ngroups}", flush=True)

    def accepted_edges(self, ms, i):
        lits = np.arange(self.R) + 1 + i*self.R
        val = ms[lits - 1] > 0
        return val[self.eid]

    def graph(self, ms, i):
        acc = self.accepted_edges(ms, i)
        G = csr_matrix((np.ones(acc.sum(), dtype=np.int8), (self.pa[acc], self.pb[acc])), shape=(self.M, self.M))
        return acc, G

    def find_cuts(self, ms, maxcuts=5000):
        cuts = []; viol = 0
        for i in range(3):
            acc, G = self.graph(ms, i)
            accset = set(zip(self.pa[acc].tolist(), self.pb[acc].tolist()))
            if self.mode == 'FC':
                ncomp, lab = connected_components(G, directed=True, connection='strong')
                bysrc = {}
                for a, b in accset:
                    if lab[a] == lab[b] and (b, a) not in accset:
                        bysrc.setdefault(b, []).append(a); viol += 1
                if not bysrc: continue
                Gl = G.tolil().rows
                for b, As in bysrc.items():
                    comp = lab[b]; pred = {b: None}; dq = deque([b]); targets = set(As)
                    while dq and targets:
                        v = dq.popleft()
                        for w in Gl[v]:
                            if lab[w] != comp or w in pred: continue
                            pred[w] = v; dq.append(w); targets.discard(w)
                    for a in As:
                        path = []; w = a
                        while pred[w] is not None:
                            path.append((pred[w], w)); w = pred[w]
                        cl = [-self.var(i, self.e(x, y)) for x, y in path]
                        cl += [-self.var(i, self.e(a, b))]
                        if (b, a) in self.edge_index: cl += [self.var(i, self.e(b, a))]
                        cuts.append(cl)
                        if len(cuts) >= maxcuts: return cuts, viol
            else:
                Gl = G.tolil().rows
                for a in range(self.M):
                    for b in Gl[a]:
                        for c in Gl[b]:
                            if c == a or (a, c) not in self.edge_index: continue
                            if self.mode == 'TR':
                                if (a, c) not in accset:
                                    viol += 1
                                    cuts.append([-self.var(i, self.e(a, b)), -self.var(i, self.e(b, c)), self.var(i, self.e(a, c))])
                            else:  # TC: forbid c < a
                                if (c, a) in accset and (a, c) not in accset:
                                    viol += 1
                                    cuts.append([-self.var(i, self.e(a, b)), -self.var(i, self.e(b, c)),
                                                 -self.var(i, self.e(c, a)), self.var(i, self.e(a, c))])
                            if len(cuts) >= maxcuts: return cuts, viol
        return cuts, viol

    def solve(self, assumptions=None, maxit=100000):
        assumptions = list(self.groups) if assumptions is None else assumptions
        it = 0
        while True:
            it += 1
            if not self.S.solve(assumptions=assumptions):
                return False, self.S.get_core(), it
            ms = np.array(self.S.get_model())
            cuts, viol = self.find_cuts(ms)
            if not cuts:
                self.model = ms; return True, None, it
            for cl in cuts: self.S.add_clause(cl)
            self.ncuts += len(cuts)
            if it >= maxit: raise RuntimeError("too many iterations")

    def minimise_core(self, core):
        core = list(core); k = 0
        while k < len(core):
            trial = core[:k] + core[k+1:]
            ok, c2, _ = self.solve(trial)
            if ok: k += 1
            else:
                c2 = set(c2); core = [s for s in trial if s in c2]
        return core

    def strict_cycles(self, ms, i, limit=50):
        acc, G = self.graph(ms, i)
        accset = set(zip(self.pa[acc].tolist(), self.pb[acc].tolist()))
        ncomp, lab = connected_components(G, directed=True, connection='strong')
        Gl = G.tolil().rows; out = []
        for a, b in accset:
            if lab[a] != lab[b] or (b, a) in accset: continue
            pred = {b: None}; dq = deque([b])
            while dq and a not in pred:
                v = dq.popleft()
                for w in Gl[v]:
                    if w not in pred: pred[w] = v; dq.append(w)
            path = [a]; w = a
            while pred[w] is not None: w = pred[w]; path.append(w)
            out.append(list(reversed(path)) + [b])
            if len(out) >= limit: break
        return out
