# HH3: 4-point obstructions to STRICT Bayes realisability (ignoring the orthant constraints, which only make it harder).
# Four distinct points in the plane realise, by strictly separating lines, every 2|2 split except one (convex position)
# or every singleton split except one (one point inside the triangle of the others); degenerate positions realise less.
# So if the induced dichotomies of four selected models contain all three 2|2 splits and all four singletons,
# no additive ranking has these four models as a.e.-unique (strict) Bayes models at any weights.
import sys, itertools; sys.path.insert(0, '.')
from arr3 import *
def dichotomies(A, quad):
    out = set()
    for c in A.active:
        on = frozenset(q for q in quad if A.cls[c][q] != '0')
        if 0 < len(on) < 4:
            out.add(min(on, frozenset(quad) - on, key=lambda s: (len(s), sorted(s))))
    return out
def obstructed(A, quad):
    D = dichotomies(A, quad)
    singles = all(frozenset([q]) in D for q in quad)
    a, b, c, d = quad
    pairs = all(min(frozenset(x), frozenset(quad) - frozenset(x), key=lambda s: sorted(s)) in D
                for x in [(a, b), (a, c), (a, d)])
    return singles and pairs
if __name__ == '__main__':
    u = (F(1,3),)*3
    for name, pts, eps in [('hexR1', tri_grid(u, F(1,100), 1), F(3,10)), ('hexR2', tri_grid(u, F(1,100), 2), F(3,10)),
                           ('hexR1 eps=1/10', tri_grid(u, F(1,100), 1), F(1,10)), ('hexR2 step 1/1000', tri_grid(u, F(1,1000), 2), F(3,10))]:
        A = Arrangement(pts, eps)
        bad = [q for q in itertools.combinations(range(len(pts)), 4) if obstructed(A, q)]
        print(name, len(pts), 'points; obstructed 4-subsets:', len(bad), [tuple(str(x) for x in pts[i]) for i in bad[0]] if bad else '')
