# HH3: exact 4-model certificates against STRICT (a.e.-unique) Bayes realisation by any additive ranking.
# A certificate is four selected points a,b,c,d and seven problems (rational gambles, interior points of open cells)
# such that, on those problems, the sets of models giving advice are: each singleton, and each 2|2 split (up to
# complement).  The advice of each model is recomputed DIRECTLY from its credal polygon (exact), not from the cell table.
# Why it is a certificate (PROVED in HH3 Sec. 5): strict Bayes at weights q^a..q^d forces, for a.e. problem g of
# each such open cell, the line {q . c(g) = 0} to separate strictly the models giving advice from the others; four
# distinct points of the plane never admit all four singleton and all three 2|2 strict linear separations.
import sys, os, itertools; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from arr3 import *
from four_point2 import labelled, obstructed

def advice_direct(P, g):
    th = (g[0]-g[2], g[1]-g[2]); c = -g[2]
    lo = min(th[0]*x+th[1]*y for x, y in P); hi = max(th[0]*x+th[1]*y for x, y in P)
    return '+' if c < lo else ('-' if c > hi else '0')

def certificate(A, quad):
    out = {}
    for c in A.active:
        on = frozenset(q for q in quad if A.cls[c][q] != '0')
        if 0 < len(on) < 4:
            key = min(on, frozenset(quad) - on, key=lambda s: (len(s), sorted(s)))
            if key not in out: out[key] = c
    need = [frozenset([q]) for q in quad] + [min(frozenset((quad[0], b)), frozenset(quad) - frozenset((quad[0], b)),
                                                 key=lambda s: sorted(s)) for b in quad[1:]]
    rows = []
    for key in need:
        c = out[key]; th, cc = A.reps[c][0]; g = gamble(th, cc)
        assert A.classify(g) == c
        adv = [advice_direct(A.polys[q], g) for q in quad]
        assert adv == [A.cls[c][q] for q in quad]
        rows.append((sorted(key), g, adv))
    return rows

if __name__ == '__main__':
    u = (F(1,3),)*3
    cases = [('hexR3 step 1/200, eps 3/10', u, F(1,200), 3, F(3,10)), ('hexR3 step 1/2000, eps 3/10', u, F(1,2000), 3, F(3,10)),
             ('hexR3 step 1/20000, eps 3/10', u, F(1,20000), 3, F(3,10)), ('hexR3 step 1/200, eps 1/10', u, F(1,200), 3, F(1,10)),
             ('hexR3 step 1/200, eps 1/2', u, F(1,200), 3, F(1,2)), ('hexR2 step 1/100, eps 1/2', u, F(1,100), 2, F(1,2)),
             ('hexR2 step 1/100, eps 3/10', u, F(1,100), 2, F(3,10)), ('hexR2 step 1/100, eps 1/10', u, F(1,100), 2, F(1,10))]
    for name, ctr, step, R, eps in cases:
        pts = tri_grid(ctr, step, R); A = Arrangement(pts, eps); rows_ = labelled(A)
        bad = [q for q in itertools.combinations(range(len(pts)), 4) if obstructed(rows_, q)]
        iu = pts.index(u)
        withu = [q for q in bad if iu in q]
        print(f"{name}: {len(pts)} models; obstructed 4-sets {len(bad)} (containing u: {len(withu)})", flush=True)
        if bad:
            q = (withu or bad)[0]
            offs = [tuple(int((pts[k][i]-u[i])/step) for i in range(3)) for k in q]
            print(f"   certificate models (offsets from u in units of the step): {offs}")
            for key, g, adv in certificate(A, q):
                print(f"     split {[offs[q.index(k)] for k in key]} vs rest: gamble g = ({', '.join(str(x) for x in g)}); advice {adv}")
