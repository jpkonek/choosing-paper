# HH3: SAT formulation of per-world accepted-record sets on a finite fragment, with lazy no-reversal cuts.
#
# Variables y[i][r]: "record r is accepted at world i" (r ranges over the records of ordered pairs of distinct fragment
# models; (IB) is built in, because every pair with the same record uses the same variable).  X <=_i Y iff
# y[i][rec(X,Y)].  Strict: X <_i Y iff y[i][rec(X,Y)] and not y[i][rec(Y,X)].
#
# Hard constraints:
#   (G)    strictly improving records accepted, strictly worsening records rejected (reflexivity is the identity record).
#   no-reversal, added lazily as violated (cutting planes, all valid consequences of the axiom):
#     FC : no directed cycle of accepted edges among fragment models containing a strict edge
#          (clause: some edge of the path B ->* A is rejected, or A->B rejected, or B->A accepted);
#     TC : the same for cycles of length 3 only;
#     TR : transitivity on the fragment, y(AB) & y(BC) -> y(AC)  (the transitive comparison version).
# Soft-selectable requirement groups (each with a selector literal, for UNSAT cores):
#   comp(p,X)  : OR_{i in supp p} y[i][rec(C_p, X)]
#   und(p,X)   : not( AND_i y[i][rec(X,C_p)]  and  OR_j not y[j][rec(C_p,X)] )      (X does not dominate C_p)
#   C(X,p)     : not( AND_i y[i][rec(X,C_p)] and y[i][rec(C_p,X)] )   for certified-incoherent X   ((C), direct form)
#   csp(p,X,i) : closed-section proxy (optional; NOT a consequence of the axioms): if C_q <=_i X for every listed
#                neighbour q of p then C_p <=_i X.
import numpy as np
from collections import deque
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components
from pysat.solvers import Solver

class Problem:
    def __init__(self, fr, mode='FC', undom='all', use_C=True, csp=None, solver='g4', verbose=False, selectors=True):
        self.fr = fr; A = fr.A; self.mode = mode; self.verbose = verbose
        M = len(fr.X); self.M = M
        RID, reps = fr.records()
        self.RID = RID; self.reps = reps; R = len(reps); self.R = R
        self.var = lambda i, k: int(1 + i*R + k)
        self.nv = 3*R
        self.S = Solver(name=solver)
        self.gsign = fr.guidance(reps)
        nG = 0
        for i in range(3):
            for k in np.nonzero(self.gsign[i] == 1)[0]: self.S.add_clause([self.var(i, k)]); nG += 1
            for k in np.nonzero(self.gsign[i] == -1)[0]: self.S.add_clause([-self.var(i, k)]); nG += 1
        self.groups = {}           # selector -> description
        self.gclauses = {}
        self.ngroups = 0
        def newsel(desc, clauses):
            self.ngroups += 1
            if not selectors:
                for cl in clauses: self.S.add_clause(cl)
                return None
            self.nv += 1; s = self.nv
            self.groups[s] = desc; self.gclauses[s] = clauses
            for cl in clauses: self.S.add_clause([-s] + cl)
            return s
        self.newsel = newsel
        sel = fr.sel
        for pi, m in enumerate(sel):
            p = A.pts[pi]; supp = [i for i in range(3) if p[i] > 0]
            for x in range(M):
                if x == m: continue
                k = RID[m, x]
                newsel(('comp', pi, x), [[self.var(i, k) for i in supp]])
                if undom == 'all' or (undom == 'u' and all(t == p[0] for t in p)):
                    kx = RID[x, m]
                    newsel(('und', pi, x), [[-self.var(i, kx) for i in range(3)] + [self.var(j, k)] for j in range(3)])
        if use_C:
            for x in fr.incoh:
                for pi, m in enumerate(sel):
                    k1, k2 = RID[x, m], RID[m, x]
                    newsel(('C', x, pi), [[-self.var(i, k1) for i in range(3)] + [-self.var(i, k2) for i in range(3)]])
        if csp:
            for (pi, nbrs) in csp:
                m = sel[pi]
                for x in range(M):
                    if x == m: continue
                    for i in range(3):
                        cl = [-self.var(i, RID[sel[q], x]) for q in nbrs] + [self.var(i, RID[m, x])]
                        newsel(('csp', pi, x, i), [cl])
        self.ncuts = 0
        if verbose: print(f"   [{fr.name}] models {M}, records {R}, (G)-units {nG}, groups {len(self.groups)}")

    # ------------- lazy no-reversal -------------
    def adjacency(self, model_set, i):
        val = np.zeros(self.R + 1, dtype=bool)
        lits = np.array([self.var(i, k) for k in range(self.R)])
        val[:self.R] = model_set[lits - 1] > 0
        adj = val[self.RID]          # RID=-1 on the diagonal -> val[-1] = False
        return adj

    def find_cuts(self, ms, maxcuts=3000):
        cuts = []; viol = 0
        for i in range(3):
            adj = self.adjacency(ms, i)
            strict = adj & ~adj.T
            if self.mode in ('FC',):
                ncomp, lab = connected_components(csr_matrix(adj), directed=True, connection='strong')
                bad = np.argwhere(strict & (lab[:, None] == lab[None, :]))
                viol += len(bad)
                bysrc = {}
                for a, b in bad: bysrc.setdefault(b, []).append(a)
                for b, As in bysrc.items():
                    # BFS from b inside its SCC
                    comp = lab[b]; pred = {b: None}; dq = deque([b]); targets = set(As)
                    while dq and targets:
                        v = dq.popleft()
                        for w in np.nonzero(adj[v] & (lab == comp))[0]:
                            w = int(w)
                            if w not in pred:
                                pred[w] = v; dq.append(w); targets.discard(w)
                    for a in As:
                        path = []; w = a
                        while pred[w] is not None:
                            path.append((pred[w], w)); w = pred[w]
                        cl = [-self.var(i, self.RID[x, y]) for x, y in path]
                        cl += [-self.var(i, self.RID[a, b]), self.var(i, self.RID[b, a])]
                        cuts.append(cl)
                        if len(cuts) >= maxcuts: return cuts, viol
            elif self.mode in ('TC', 'TR'):
                ad = adj.astype(np.float32)
                two = (ad @ ad) > 0.5
                if self.mode == 'TC':
                    bad = np.argwhere(strict.T & two)     # strict[C,A] and A->B->C : pairs (A,C)
                else:
                    bad = np.argwhere(two & ~adj & ~np.eye(self.M, dtype=bool))
                viol += len(bad)
                for a, c in bad:
                    bs = np.nonzero(adj[a] & adj[:, c])[0]
                    b = int(bs[0])
                    if self.mode == 'TC':
                        cl = [-self.var(i, self.RID[a, b]), -self.var(i, self.RID[b, c]),
                              -self.var(i, self.RID[c, a]), self.var(i, self.RID[a, c])]
                    else:
                        cl = [-self.var(i, self.RID[a, b]), -self.var(i, self.RID[b, c]), self.var(i, self.RID[a, c])]
                    cuts.append(cl)
                    if len(cuts) >= maxcuts: return cuts, viol
        return cuts, viol

    def solve(self, assumptions=None, maxit=100000):
        assumptions = list(self.groups) if assumptions is None else assumptions
        it = 0
        while True:
            it += 1
            ok = self.S.solve(assumptions=assumptions)
            if not ok:
                return False, self.S.get_core(), it
            ms = np.array(self.S.get_model())
            ms = ms[:self.nv] if len(ms) >= self.nv else np.concatenate([ms, -np.arange(len(ms)+1, self.nv+1)])
            cuts, viol = self.find_cuts(ms)
            if not cuts:
                self.model = ms
                return True, None, it
            for cl in cuts: self.S.add_clause(cl)
            self.ncuts += len(cuts)
            if it >= maxit: raise RuntimeError("too many iterations")

    def minimise_core(self, core):
        """deletion-based minimal unsatisfiable subset over requirement groups (cuts kept: they are valid)"""
        core = list(core)
        k = 0
        while k < len(core):
            trial = core[:k] + core[k+1:]
            ok, c2, _ = self.solve(trial)
            if ok: k += 1
            else:
                c2 = set(c2); core = [s for s in trial if s in c2]
        return core

    def strict_cycles(self, ms, i, maxlen=8, limit=50):
        """report strict cycles (accepted edges, >=1 strict) in world i: shortest one through each strict edge in an SCC"""
        adj = self.adjacency(ms, i); strict = adj & ~adj.T
        ncomp, lab = connected_components(csr_matrix(adj), directed=True, connection='strong')
        out = []
        for a, b in np.argwhere(strict & (lab[:, None] == lab[None, :])):
            pred = {int(b): None}; dq = deque([int(b)])
            while dq:
                v = dq.popleft()
                if v == a: break
                for w in np.nonzero(adj[v])[0]:
                    w = int(w)
                    if w not in pred: pred[w] = v; dq.append(w)
            path = [int(a)]; w = int(a)
            while pred[w] is not None: w = pred[w]; path.append(w)
            out.append(list(reversed(path)) + [int(b)])
            if len(out) >= limit: break
        return out

    def dense_counts(self, ms):
        out = []
        for i in range(3):
            adj = self.adjacency(ms, i)
            iu = np.triu_indices(self.M, 1)
            x, y = adj[iu], adj.T[iu]
            ad = adj.astype(np.float32); two = (ad @ ad) > 0.5
            nt = int((two & ~adj & ~np.eye(self.M, dtype=bool)).sum())
            out.append(dict(tie=int((x & y).sum()), strict=int((x ^ y).sum()), incomparable=int((~x & ~y).sum()),
                            nontransitive_pairs=nt))
        return out
