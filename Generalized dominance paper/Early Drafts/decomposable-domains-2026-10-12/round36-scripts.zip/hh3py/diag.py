# HH3: diagnostics of a satisfying system on a fragment (EdgeProblem solution).
#  - counts: per world, among chosen pairs: accepted both ways (ties), strict, neither (incomparable);
#  - non-transitive triples A<=B<=C with (A,C) a chosen pair and A not<= C;
#  - exact additivity: is there a cell witness L_i with L(A) <= L(B) on accepted, L(A) > L(B) on rejected records?
#  - additive Suzumura extension: L(A) <= L(B) on accepted, L(A) < L(B) on strict (no constraint on rejected).
import numpy as np
from fractions import Fraction as F
from scipy.optimize import linprog
from scipy.sparse import lil_matrix, csr_matrix

def counts(P, ms):
    out = []
    for i in range(3):
        acc = P.accepted_edges(ms, i)
        accset = set(zip(P.pa[acc].tolist(), P.pb[acc].tolist()))
        pairs = set(map(tuple, P.pairs))
        tie = strict = none = 0
        for (a, b) in pairs:
            if a > b: continue
            x, y = (a, b) in accset, (b, a) in accset
            if x and y: tie += 1
            elif x or y: strict += 1
            else: none += 1
        # non-transitive triples (sampled through selected middle nodes)
        nt = 0
        succ = {}
        for (a, b) in accset: succ.setdefault(a, []).append(b)
        for a in list(succ)[:2000]:
            for b in succ[a]:
                for c in succ.get(b, []):
                    if c != a and (a, c) in pairs and (a, c) not in accset: nt += 1
        out.append(dict(tie=tie, strict=strict, incomparable=none, nontransitive_triples=nt))
    return out

def additive_test(P, ms, i, mode='exact', W=1000):
    """mode 'exact': accepted -> L(A)-L(B) <= 0, rejected -> L(A)-L(B) >= 1;  mode 'ext': accepted -> <= 0,
    strict -> <= -1.  Variables psi_{c}(+), psi_{c}(-) on active cells, strictly guiding.  Returns bool (exactly
    verified after rounding) or None if the LP is infeasible."""
    fr = P.fr; act = fr.act; nC = len(act)
    reps = P.reps
    lits = np.arange(P.R) + 1 + i*P.R
    val = ms[lits - 1] > 0
    # records appearing with their reverse among chosen pairs
    keyrow = {reps[k].tobytes(): k for k in range(P.R)}
    def revk(k):
        r = reps[k].astype(np.int16); nz = r > 0
        rr = np.where(nz, 1 + 4*((r - 1) % 4) + (r - 1)//4, 0).astype(np.int8)
        return keyrow.get(rr.tobytes(), -1)
    rows = []; rhs = []
    for k in range(P.R):
        r = reps[k].astype(np.int16); nz = np.nonzero(r)[0]
        fa = (r[nz] - 1)//4; ta = (r[nz] - 1) % 4
        coef = {}
        for c, f_, t_ in zip(nz, fa, ta):
            # L(A) - L(B) = sum psi(from) - psi(to)
            if f_ != 1: coef[(c, f_)] = coef.get((c, f_), 0) + 1
            if t_ != 1: coef[(c, t_)] = coef.get((c, t_), 0) - 1
        rk = revk(k)
        if val[k]:
            if mode == 'ext' and rk >= 0 and not val[rk]: rows.append((coef, -1))      # strict: <= -1
            else: rows.append((coef, 0))                                                  # <= 0
        else:
            if mode == 'exact': rows.append(({kk: -v for kk, v in coef.items()}, -1))    # -(L(A)-L(B)) <= -1
    idx = {}
    for c in range(nC):
        for a in (0, 2): idx[(c, a)] = len(idx)
    Aub = lil_matrix((len(rows), len(idx))); bub = np.zeros(len(rows))
    for n, (coef, b) in enumerate(rows):
        for kk, v in coef.items(): Aub[n, idx[kk]] = v
        bub[n] = b
    bounds = []
    for c in range(nC):
        for a in (0, 2):
            r = fr.rk[i, act[c], a]
            bounds.append((-W, -1) if r == 0 else (1, W))
    res = linprog(np.zeros(len(idx)), A_ub=csr_matrix(Aub), b_ub=bub, bounds=bounds, method='highs')
    if res.status != 0: return None
    psi = [F(round(x*10**4), 10**4) for x in res.x]
    for (coef, b) in rows:
        if sum(psi[idx[kk]]*v for kk, v in coef.items()) > b: return False
    return True
