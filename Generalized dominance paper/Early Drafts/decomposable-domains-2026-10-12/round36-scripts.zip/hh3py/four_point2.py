# HH3: 4-point obstructions to strict Bayes realisability, with the vertices e_1, e_2, e_3 added as labelled points
# (in any additive Bayes realisation the vertex e_i lies on the acting side of cell c iff acting is good at world i,
# i.e. iff the sign of the acting gamble at i is +; this encodes the orthant constraint on w_c combinatorially).
# Positions are left free, so the test is a NECESSARY condition only (pinning the vertices can only make it harder).
import sys, itertools; sys.path.insert(0, '.')
from arr3 import *
def labelled(A):
    n = len(A.pts); rows = []
    for c in A.active:
        s = set(A.cls[c]) - {'0'}; assert len(s) == 1; a = s.pop()
        th, cc = A.reps[c][0]; f = gamble(th, cc); h = f if a == '+' else tuple(-x for x in f)
        rows.append([A.cls[c][p] != '0' for p in range(n)] + [h[i] > 0 for i in range(3)])
    return rows
def obstructed(rows, quad):
    D = set()
    for r in rows:
        on = frozenset(q for q in quad if r[q])
        if 0 < len(on) < 4: D.add(min(on, frozenset(quad) - on, key=lambda s: (len(s), sorted(s))))
    if not all(frozenset([q]) in D for q in quad): return False
    a = quad[0]
    return all(min(frozenset((a, b)), frozenset(quad) - frozenset((a, b)), key=lambda s: sorted(s)) in D for b in quad[1:])
if __name__ == '__main__':
    u = (F(1,3),)*3
    for name, pts, eps in [('hexR2 eps1/2', tri_grid(u,F(1,100),2), F(1,2)), ('hexR2 at (1/5,3/5,1/5)', tri_grid((F(1,5),F(3,5),F(1,5)),F(1,100),2), F(3,10)),
                           ('hexR3 step1/200', tri_grid(u,F(1,200),3), F(3,10)), ('hexR2 eps3/10', tri_grid(u,F(1,100),2), F(3,10))]:
        A = Arrangement(pts, eps); rows = labelled(A); n = len(pts) + 3
        bad = [q for q in itertools.combinations(range(n), 4) if obstructed(rows, q)]
        print(name, len(pts), 'points + 3 vertices; obstructed 4-subsets:', len(bad), bad[:3], flush=True)
