# HH3: is there an ADDITIVE (cell-witness) system meeting the fragment's requirements?
# Per world i and active cell c: psi_{i,c}(a) for a in {'+','-'} (psi(0) = 0), strictly guiding:
#   psi(good) <= -1, psi(bad) >= +1 (good < none < bad);  psi('x') is irrelevant if no model uses 'x' (checked).
# L_i(X) = sum_c psi_{i,c}(X_c).  Such an L_i, with per-cell penalty psi/mu(c), is a bounded strictly guiding additive
# ranking on the FULL domain (FF1 Lemma 3.1), hence (G), (IB), transitive, complete.
# STRICT competitiveness (sufficient for comp, und and (C) together):  for every selected C_p and fragment model X != C_p,
#   some i in supp p has L_i(X) - L_i(C_p) >= 1.
# Solved as a MILP (HiGHS), then rounded to rationals and verified EXACTLY.
import numpy as np
from fractions import Fraction as F
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix, csr_matrix

def additive_system(fr, targets=None, W=200, time_limit=600, verbose=True):
    A = fr.A
    Xs = np.array(fr.X).astype(np.int16)
    assert not np.any(Xs == 3), "contradictory advice present"
    act = np.array([c for c in range(A.N) if len(np.unique(Xs[:, c])) > 1])
    nC = len(act)
    # variable index: (i, cell k, a in {0:'+', 1:'-'})
    def vid(i, k, a): return (i*nC + k)*2 + a
    nv_psi = 3*nC*2
    lb = np.full(nv_psi, -W, float); ub = np.full(nv_psi, W, float)
    for i in range(3):
        for k, c in enumerate(act):
            for a, code in ((0, 0), (1, 2)):
                r = fr.rk[i, c, code]
                if r == 0: ub[vid(i, k, a)] = -1
                else: lb[vid(i, k, a)] = 1
    # requirement rows, deduplicated by (record, supp)
    reqs = {}
    sel = fr.sel
    for pi, m in enumerate(sel):
        p = A.pts[pi]; supp = tuple(i for i in range(3) if p[i] > 0)
        xs = range(len(fr.X)) if targets is None else targets
        for x in xs:
            if x == m: continue
            a, b = Xs[m][act], Xs[x][act]
            dif = np.nonzero(a != b)[0]
            key = (tuple((int(k), int(a[k]), int(b[k])) for k in dif), supp)
            reqs.setdefault(key, (pi, x))
    R = list(reqs.keys())
    Mbig = 2*W*nC + 2
    nz = sum(len(s) for _, s in R)
    nvar = nv_psi + nz
    rows = lil_matrix((nz + len(R), nvar)); lo = []; hi = []
    zi = nv_psi; r_ = 0; zmap = []
    for (rec, supp) in R:
        zs = []
        for i in supp:
            # L_i(X) - L_i(C_p) - Mbig*z >= 1 - Mbig
            for (k, fa, ta) in rec:
                if ta != 1: rows[r_, vid(i, k, 0 if ta == 0 else 1)] += 1
                if fa != 1: rows[r_, vid(i, k, 0 if fa == 0 else 1)] -= 1
            rows[r_, zi] = -Mbig; lo.append(1 - Mbig); hi.append(np.inf)
            zs.append(zi); zi += 1; r_ += 1
        for z in zs: rows[r_, z] = 1
        lo.append(1); hi.append(np.inf); r_ += 1
        zmap.append(zs)
    lbv = np.concatenate([lb, np.zeros(nz)]); ubv = np.concatenate([ub, np.ones(nz)])
    integrality = np.concatenate([np.zeros(nv_psi), np.ones(nz)])
    res = milp(c=np.zeros(nvar), constraints=LinearConstraint(csr_matrix(rows), lo, hi),
               integrality=integrality, bounds=Bounds(lbv, ubv), options={'time_limit': time_limit, 'disp': False})
    if verbose: print(f"   additive MILP: {len(R)} distinct requirements, {nC} cells, status {res.status} ({res.message})", flush=True)
    if res.x is None: return None, res.status
    # exact verification after rounding
    psi = [F(round(v*1000), 1000) for v in res.x[:nv_psi]]
    ok = True
    for i in range(3):
        for k, c in enumerate(act):
            for a, code in ((0, 0), (1, 2)):
                r = fr.rk[i, c, code]
                v = psi[vid(i, k, a)]
                if (r == 0 and not v < 0) or (r == 2 and not v > 0): ok = False
    def L(i, x):
        s = F(0)
        for k in range(nC):
            code = Xs[x][act[k]]
            if code == 0: s += psi[vid(i, k, 0)]
            elif code == 2: s += psi[vid(i, k, 1)]
        return s
    bad = 0
    for (rec, supp), (pi, x) in reqs.items():
        m = sel[pi]
        if not any(L(i, x) > L(i, m) for i in supp): bad += 1
    if verbose: print(f"   additive exact check: guidance signs {ok}, violated strict-competitiveness requirements {bad}", flush=True)
    return (psi, act) if ok and bad == 0 else None, res.status
