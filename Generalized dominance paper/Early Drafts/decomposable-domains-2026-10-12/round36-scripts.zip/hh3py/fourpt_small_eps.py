# HH3: does the 4-model certificate (with T1 = C_u among the four) appear for smaller eps on denser hexagons?
import sys, os, itertools; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from arr3 import *; from four_point2 import labelled, obstructed
u = (F(1,3),)*3
for R, eps in [(4, F(1,10)), (5, F(1,10)), (6, F(1,10)), (5, F(1,20))]:
    pts = tri_grid(u, F(1,1000), R); A = Arrangement(pts, eps); rows_ = labelled(A); iu = pts.index(u)
    others = [k for k in range(len(pts)) if k != iu]
    bad = None
    for t in itertools.combinations(others, 3):
        q = tuple(sorted(t + (iu,)))
        if obstructed(rows_, q): bad = q; break
    offs = [tuple(int((pts[k][i]-u[i])*1000) for i in range(3)) for k in bad] if bad else None
    print(f"hexR{R} step 1/1000, eps {eps}: {len(pts)} models, {len(A.active)} active cells; first certificate containing u: {offs}", flush=True)
