# HH3: additive systems against ALL cell-measurable competitors of a finite arrangement (implicit complete cell world).
#
# Unknowns: per world i, active cell c, advice a in {'+','-'}: psi_{i,c}(a), psi(0) = 0, strictly guiding
# (good <= -1, bad >= +1).  For selected C_p and a cell-measurable X, L_i(X) - L_i(C_p) = sum_c delta_{i,c}(X_c),
# delta_{i,c}(a) = psi_{i,c}(a) - psi_{i,c}(C_p(c)).
# Requirement (strict competitiveness, implies comp, und, (C)):  for every X != C_p, some i in supp p has
# L_i(X) - L_i(C_p) >= 1.   The competitor set is the complete cell world (all advices in {'+','0','-'} per cell).
# CEGAR: master MILP over psi with a growing list of competitors; oracle MILP per p finds X with
# sum delta_i <= 1 - 1e-6 for all i in supp p.
# EXACT certificate at the end (when it exists): rational psi and, for each p, a rational weight q in relint
# Delta(supp p) with q . delta_c(a) > 0 for every single switch (c, a): then every X != C_p has
# sum_i q_i (L_i(X) - L_i(C_p)) > 0, so some i in supp p has L_i(X) > L_i(C_p) (strict competitiveness, margin > 0).
import numpy as np
from fractions import Fraction as F
from scipy.optimize import milp, LinearConstraint, Bounds, linprog
from scipy.sparse import lil_matrix, csr_matrix

def cegar(A, rk, W=1000, maxit=400, verbose=True, eps_tol=1e-6):
    act = [c for c in range(A.N) if len(set(A.cls[c])) > 1]
    nC = len(act); S = len(A.pts)
    alph = [[0, 1, 2]] * nC         # complete cell world on active cells: '+','0','-'
    def vid(i, k, a): return (i*nC + k)*2 + (0 if a == 0 else 1)
    nv = 3*nC*2
    lb = np.full(nv, -W, float); ub = np.full(nv, W, float)
    for i in range(3):
        for k, c in enumerate(act):
            for a in (0, 2):
                if rk[i, c, a] == 0: ub[vid(i, k, a)] = -1
                else: lb[vid(i, k, a)] = 1
    selcode = [[{'+': 0, '0': 1, '-': 2}[A.cls[c][p]] for c in act] for p in range(S)]
    supp = [[i for i in range(3) if A.pts[p][i] > 0] for p in range(S)]
    comps = []        # list of (p, tuple of (k, a) switches)
    def master():
        nz = sum(len(supp[p]) for p, _ in comps)
        rows = lil_matrix((nz + len(comps), nv + nz)); lo = []; hi = []
        r = 0; z = nv
        Mbig = 4*W*nC
        for p, sw in comps:
            zs = []
            for i in supp[p]:
                for (k, a) in sw:
                    o = selcode[p][k]
                    if a != 1: rows[r, vid(i, k, a)] += 1
                    if o != 1: rows[r, vid(i, k, o)] -= 1
                rows[r, z] = -Mbig; lo.append(1 - Mbig); hi.append(np.inf); zs.append(z); z += 1; r += 1
            for zz in zs: rows[r, zz] = 1
            lo.append(1); hi.append(np.inf); r += 1
        integ = np.concatenate([np.zeros(nv), np.ones(nz)])
        cons = [LinearConstraint(csr_matrix(rows), lo, hi)] if comps else []
        res = milp(c=np.zeros(nv + nz), constraints=cons, integrality=integ,
                   bounds=Bounds(np.concatenate([lb, np.zeros(nz)]), np.concatenate([ub, np.ones(nz)])),
                   options={'time_limit': 600})
        return None if res.x is None else res.x[:nv]
    def oracle(psi, p):
        # binaries x_{k,a} for a != selcode; sum_a x <= 1; sum x >= 1; for i in supp: sum delta x <= 1 - tol
        keys = [(k, a) for k in range(nC) for a in alph[k] if a != selcode[p][k]]
        n = len(keys)
        rows = lil_matrix((nC + 1 + len(supp[p]), n)); lo = []; hi = []
        for j, (k, a) in enumerate(keys): rows[k, j] = 1
        lo += [0]*nC; hi += [1]*nC
        rows[nC, :] = np.ones(n); lo.append(1); hi.append(np.inf)
        for t, i in enumerate(supp[p]):
            for j, (k, a) in enumerate(keys):
                o = selcode[p][k]
                d = (psi[vid(i, k, a)] if a != 1 else 0) - (psi[vid(i, k, o)] if o != 1 else 0)
                rows[nC + 1 + t, j] = d
            lo.append(-np.inf); hi.append(1 - 1e-4)
        res = milp(c=np.zeros(n), constraints=LinearConstraint(csr_matrix(rows), lo, hi), integrality=np.ones(n),
                   bounds=Bounds(np.zeros(n), np.ones(n)), options={'time_limit': 120})
        if res.x is None: return None
        return tuple(keys[j] for j in range(n) if res.x[j] > 0.5)
    it = 0
    while it < maxit:
        it += 1
        psi = master()
        if psi is None:
            if verbose: print(f"   CEGAR: master infeasible after {len(comps)} competitors (it {it})", flush=True)
            return None, comps
        new = 0
        for p in range(S):
            sw = oracle(psi, p)
            if sw is not None: comps.append((p, sw)); new += 1
        if verbose and it % 10 == 1: print(f"   CEGAR it {it}: competitors {len(comps)}, new {new}", flush=True)
        if new == 0: break
    # exact Bayes certificates
    psiq = [F(round(x*100), 100) for x in psi]
    certs = []
    allok = True
    for p in range(S):
        sw = [(k, a) for k in range(nC) for a in alph[k] if a != selcode[p][k]]
        D = []
        for (k, a) in sw:
            o = selcode[p][k]
            D.append([(psiq[vid(i, k, a)] if a != 1 else 0) - (psiq[vid(i, k, o)] if o != 1 else 0) for i in supp[p]])
        Dm = np.array([[float(x) for x in row] for row in D])
        m = len(supp[p])
        # maximise t s.t. q . d >= t, sum q = 1, q >= 1e-3
        c = np.zeros(m + 1); c[-1] = -1
        Aub = np.hstack([-Dm, np.ones((len(D), 1))]); bub = np.zeros(len(D))
        res = linprog(c, A_ub=Aub, b_ub=bub, A_eq=np.array([[1]*m + [0]]), b_eq=[1],
                      bounds=[(1e-3, 1)]*m + [(None, None)], method='highs')
        ok = False; q = None
        if res.status == 0 and res.x[-1] > 0:
            q = [F(round(x*10**6), 10**6) for x in res.x[:m]]; s = sum(q); q = [x/s for x in q]
            ok = all(x > 0 for x in q) and all(sum(qq*dd for qq, dd in zip(q, row)) > 0 for row in D)
        certs.append((ok, q)); allok &= ok
    if verbose: print(f"   CEGAR done: {it} iterations, {len(comps)} competitors; exact Bayes certificate for "
                      f"{sum(o for o, _ in certs)}/{S} selected models", flush=True)
    return (psiq, certs, allok), comps
