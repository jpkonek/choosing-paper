# HH3: FC / TC / TR and the additive MILP on a fragment built around the 4-model certificate (hexR3, step 1/200,
# eps 3/10): selected = all 37 models; competitors = for each certificate model, every modification on the seven
# certificate cells (2^7 each), all single flips of T1 = C_u, and one round of parallelograms.
import sys, os, time, itertools; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fast import *; from battery import run, u
from four_point2 import labelled, obstructed
from fourpt_cert import certificate
pts = tri_grid(u, F(1,200), 3); A = Arrangement(pts, F(3,10)); fr = Frag(A, 'hexR3 certificate fragment')
rows_ = labelled(A); iu = pts.index(u)
quad = next(q for q in itertools.combinations(range(len(pts)), 4) if iu in q and obstructed(rows_, q))
cells = []
for key, g, adv in certificate(A, quad): cells.append(A.classify(g))
info = [f"{len(pts)} selected", f"{A.N} cells", f"certificate models {quad}, cells {cells}"]
n0 = len(fr.X)
for m in quad:
    base = fr.X[fr.sel[m]]
    for combo in itertools.product([0, 1], repeat=len(cells)):
        v = base.copy()
        for c, s in zip(cells, combo):
            if s: v[c] = 1 if v[c] != 1 else (0 if '+' in A.cls[c] else 2)
        fr.add(v, f"Q({m};{combo})")
info.append(f"certificate-cell cubes {len(fr.X)-n0}")
# (shrunk after the container restart: flips of u omitted)
print(info, flush=True)
info.append(f"parallelograms {fr.add_parallelograms(rounds=1)}")
t = time.time(); n = fr.certify_incoherence(tries=400); info.append(f"models {len(fr.X)}; certified incoherent {n}")
run(fr, info, additive=True, diag=False)  # LP diagnostics skipped: too large at 1249 cells
