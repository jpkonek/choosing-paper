# HH3: finite strict Bayes realisation of a finite subfamily of the plain posterior family -- search, certificate file,
# and an independent exact check.   Run: python3 -I realise.py
#
# Certificate: interior rational weights q^p (p in S) and, for EVERY merged cell c of the arrangement of S (active and
# inert), a rational vector w_c whose sign pattern is that of the cell's acting gamble h_c (strict guidance) with
#        C_p gives the acting advice on c   <=>   q^p . w_c > 0,    and q^p . w_c != 0,     for all p in S.
# (On cells where every C_p is silent or every C_p acts, w_c is constructed explicitly.)
# Independent cross-check: random exact rational gambles g; the advice of C_p is computed directly from the polygon
# K_p (not from the arrangement), the cell of g by the exact classifier, and the Bayes advice from the certificate.
import sys, os, json, random, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from arr3 import *; from bayes_real import search, data, search_hinge

def acting_sign(A, c):
    s = set(A.cls[c]) - {'0'}
    th, cc = A.reps[c][0]; f = gamble(th, cc)
    if not s:      # all silent: take acting = '+' orientation (any choice works)
        a = '+'
    else:
        assert len(s) == 1; a = s.pop()
    h = f if a == '+' else tuple(-x for x in f)
    return a, tuple(1 if x > 0 else -1 for x in h)

def full_certificate(A, Wa, Q):
    """extend the active-cell vectors Wa to all merged cells"""
    W = {}
    act = A.active
    for k, c in enumerate(act): W[c] = Wa[k]
    eta = F(1, 10**6)
    for c in range(A.N):
        if c in W: continue
        a, sg = acting_sign(A, c)
        allact = A.cls[c][0] != '0'
        # all act: weight 1 on good worlds, -eta on bad; all silent: eta on good, -1 on bad
        W[c] = [ (F(1) if s > 0 else -eta) if allact else (eta if s > 0 else F(-1)) for s in sg ]
    return W

def check(A, W, Q, nrand=20000, seed=1):
    ok = True
    for c in range(A.N):
        a, sg = acting_sign(A, c)
        if not all(W[c][i]*sg[i] > 0 for i in range(3)): ok = False
        for p in range(len(A.pts)):
            v = sum(x*y for x, y in zip(Q[p], W[c]))
            if v == 0 or ((v > 0) != (A.cls[c][p] != '0')): ok = False
    if not all(min(q) > 0 and sum(q) == 1 for q in Q): ok = False
    # random cross-check, advice computed from the polygons directly
    rng = random.Random(seed); bad = 0; done = 0
    while done < nrand:
        g = tuple(F(rng.randint(-10**6, 10**6), 10**6) for _ in range(3))
        if g[0] <= 0: continue
        c = A.classify(g)
        if c is None: continue
        th = (g[0]-g[2], g[1]-g[2]); cc = -g[2]
        a, sg = acting_sign(A, c)
        for p, P in enumerate(A.polys):
            lo = min(th[0]*x+th[1]*y for x, y in P); hi = max(th[0]*x+th[1]*y for x, y in P)
            adv = '+' if cc < lo else ('-' if cc > hi else '0')
            bayes = a if sum(x*y for x, y in zip(Q[p], W[c])) > 0 else '0'
            if adv != bayes: bad += 1
        done += 1
    return ok, bad

if __name__ == '__main__':
    u = (F(1,3),)*3
    cases = [('hexR1_step1-100_eps3-10', tri_grid(u, F(1,100), 1), F(3,10)),
             ('hexR2_step1-100_eps3-10', tri_grid(u, F(1,100), 2), F(3,10)),
             ('hexR2_step1-100_eps1-10', tri_grid(u, F(1,100), 2), F(1,10)),
             ('hexR2_step1-100_eps1-2', tri_grid(u, F(1,100), 2), F(1,2)),
             ('hexR2_step1-1000_eps3-10', tri_grid(u, F(1,1000), 2), F(3,10)),
             ('hexR2_at_(1/5,3/5,1/5)', tri_grid((F(1,5),F(3,5),F(1,5)), F(1,100), 2), F(3,10)),
             ('hexR2_step1-20_eps3-10', tri_grid(u, F(1,20), 2), F(3,10))]
    names = sys.argv[1:]
    os.makedirs('certs', exist_ok=True)
    for name, pts, eps in cases:
        if names and name not in names: continue
        A = Arrangement(pts, eps); t = time.time()
        r = search(A, verbose=False) or search_hinge(A, verbose=False)
        if not r:
            print(f"{name}: {len(pts)} models, {A.N} cells: no realisation found ({time.time()-t:.0f}s)", flush=True); continue
        Wa, Q = r
        W = full_certificate(A, Wa, Q)
        ok, bad = check(A, W, Q)
        print(f"{name}: {len(pts)} models, {A.N} cells ({len(A.active)} active): realisation found; exact check {ok}; "
              f"random cross-check mismatches {bad}/20000 gambles x {len(pts)} models ({time.time()-t:.0f}s)", flush=True)
        json.dump(dict(eps=str(eps), pts=[[str(x) for x in p] for p in pts], q=[[str(x) for x in q] for q in Q],
                       w={str(c): [str(x) for x in W[c]] for c in W}), open(f'certs/{name}.json', 'w'))
