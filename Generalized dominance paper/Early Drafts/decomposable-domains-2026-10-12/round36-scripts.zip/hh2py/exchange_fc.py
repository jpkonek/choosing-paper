# HH2 section 2: the four-model exchange survives (FC) and even (TC) when the reverse selected comparison is accepted.
# Data: EE1 Example 4.3 (three cells f, g, h; world signs (w1,w2,w3): f (-,+,-), g (+,+,-), h (+,-,+)).
# Advice: '+' accept the indexed orientation, '-' accept its negative, '0' silence.
# In the threshold scheme WITHOUT closure, world-1 generators are worsening records and caps rec(C_a, Z) with
# a_1 >= r_1(Z).  With r_1(X) = p_1, r_1(Y) = q_1 the two caps rec(C_p,X), rec(C_q,Y) are generators, and so is the
# selected cap rec(C_z, C_s) (z_1 = 1/4 >= s_1 = 1/12 = r_1(C_s)), while rec(C_s, C_z) is neither a cap nor worsening.
# We realise the three generators as a 3-model cycle W -> W' -> W'' -> W.
from fractions import Fraction as F

cells = ['f', 'g', 'h']
sign = {'f': (-1, 1, -1), 'g': (1, 1, -1), 'h': (1, -1, 1)}
model = {
    'Cp': ('-', '-', '0'), 'Cq': ('+', '+', '+'), 'Cs': ('0', '-', '+'), 'Cz': ('0', '+', '-'),
    'X': ('+', '+', '0'), 'Y': ('-', '+', '-'),
}
index = {'Cp': (F(1, 3), 0, F(2, 3)), 'Cq': (F(5, 12), F(7, 12), 0), 'Cs': (F(1, 12), F(1, 6), F(3, 4)),
         'Cz': (F(1, 4), F(2, 3), F(1, 12))}

def rec(A, B):
    return tuple('i' if a == b else (a, b) for a, b in zip(A, B))

def rank(world, cell, a):
    # world rank of advice at a cell: good < silence < bad
    s = sign[cell][world]
    if a == '0':
        return 1
    good = (a == '+') == (s > 0)
    return 0 if good else 2

def kind(world, r):
    d = [rank(world, c, x[1]) - rank(world, c, x[0]) for c, x in zip(cells, r) if x != 'i']
    if all(v >= 0 for v in d) and any(v > 0 for v in d):
        return 'worsening'
    if all(v <= 0 for v in d) and any(v < 0 for v in d):
        return 'improving'
    return 'mixed' if d else 'identity'

W = ('-', '-', '+')
def apply(A, r):
    out = []
    for a, x in zip(A, r):
        if x == 'i':
            out.append(a)
        else:
            assert a == x[0], 'record not realisable here'
            out.append(x[1])
    return tuple(out)

r1, r2 = rec(model['Cp'], model['X']), rec(model['Cq'], model['Y'])
W1 = apply(W, r1); W2 = apply(W1, r2)
lines = []
lines.append(f"rec(Cp,X) = {r1}; rec(Cq,Y) = {r2}")
lines.append(f"W = {W}, W' = {W1}, W'' = {W2}")
lines.append(f"rec(W,W'') = {rec(W, W2)};  rec(Cs,Cz) = {rec(model['Cs'], model['Cz'])};  equal: {rec(W, W2) == rec(model['Cs'], model['Cz'])}")
lines.append(f"rec(W'',W) = rec(Cz,Cs): {rec(W2, W) == rec(model['Cz'], model['Cs'])}")
p, q, s, z = index['Cp'], index['Cq'], index['Cs'], index['Cz']
lines.append(f"caps at world 1: r1(X)=p1={p[0]} (cap), r1(Y)=q1={q[0]} (cap), z1={z[0]} >= s1={s[0]}: {z[0] >= s[0]} (cap rec(Cz,Cs))")
lines.append(f"rec(Cs,Cz) at world 1: kind={kind(0, rec(model['Cs'], model['Cz']))}; cap? s1 >= r1(Cz)=z1: {s[0] >= z[0]}")
lines.append("=> W <=_1 W' <=_1 W'' and W'' <_1 W: a strict 3-model cycle, violating (TC) and hence (FC), with no closure used.")
print("\n".join(lines))
