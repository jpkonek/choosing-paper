# HH2 section 3: inputs of the VB vertex obstruction (exact rational arithmetic).
# VB (L3 section 3) on M_U, U = D_{K'}, K' = u + s(T1 - u).  Interior selected models C_q = U cap {q.h>0} cap
# {v_m.h >= 0, m=1,2,3};  C_{e_j} = B^j = U cap {h_j > 0}.
# For each ordered (i, j, k) we exhibit a point h with STRICT inequalities (hence an open, non-null neighbourhood):
#   (A) h in U, h_j > 0 > h_i, h_k, v_i.h < 0      (the set A: B^j accepts, VB interior models reject, i,k-wrong)
#   (P) h in U, h_i > 0, h_j > 0, v_k.h < 0          (a set off A where B^j accepts and VB interior models reject)
# and check the sign facts used in Proposition 3.2.  Several (eps, s).
from fractions import Fraction as F
from itertools import permutations

def verts(eps):
    c0 = (1 - eps) / 3
    return [tuple(c0 + (eps if k == m else 0) for k in range(3)) for m in range(3)]

def dot(a, b): return sum(x * y for x, y in zip(a, b))

def inU(h, eps, s):
    u = (F(1, 3),) * 3
    V = verts(eps)
    return all(dot(tuple(u[t] + s * (V[m][t] - u[t]) for t in range(3)), h) > 0 for m in range(3))

def search_A(eps, s, i, j, k):
    V = verts(eps)
    for n in range(1, 4000):
        a = F(n, 1000)
        h = [None] * 3; h[j] = F(1); h[i] = -a; h[k] = -F(1, 1000)
        h = tuple(h)
        if dot(V[i], h) < 0 and inU(h, eps, s):
            return h
    return None

def search_P(eps, s, i, j, k):
    V = verts(eps)
    for n in range(1, 4000):
        t = F(n, 1000)
        h = [None] * 3; h[i] = F(1); h[j] = F(1); h[k] = -t
        h = tuple(h)
        if dot(V[k], h) < 0 and inU(h, eps, s):
            return h
    return None

out = []
for eps in (F(1, 20), F(3, 10), F(1, 2), F(9, 10)):
    for s in (F(1, 4), F(1, 2), F(9, 10)):
        V = verts(eps)
        okall = True
        for (i, j, k) in permutations(range(3)):
            hA = search_A(eps, s, i, j, k)
            hP = search_P(eps, s, i, j, k)
            ok = hA is not None and hP is not None
            if ok:
                # B^j accepts both; every VB interior model rejects both (some v_m.h < 0);
                # on hA accepting is i-wrong and k-wrong and j-right
                ok = (hA[j] > 0 and hP[j] > 0 and dot(V[i], hA) < 0 and dot(V[k], hP) < 0
                      and hA[i] < 0 and hA[k] < 0 and hP[i] > 0)
            okall &= ok
            if eps == F(3, 10) and s == F(1, 2):
                out.append(f"eps={eps} s={s} (i,j,k)=({i+1},{j+1},{k+1}): A-point {hA}, P-point {hP}, ok={ok}")
        out.append(f"eps={eps} s={s}: all six (i,j,k) have non-null A and P sets with the stated signs: {okall}")
print("\n".join(out))
