# HH2 section 4: the own-attribution ARROW RULE for the plain posterior family (exact rational arithmetic).
#
# Pairs are indexed by their majority orientation h: either h > 0 (unanimous) or two positive coordinates and one
# negative coordinate (the odd world o).  Advice: M (accept h only), S (silence), O (accept -h only), X (both).
# Plain posterior family: C_p = {g : p.g in D_T1}.  For mixed h with odd world o (lam = eps/c0):
#     C_p(h) = M  iff  p.h + lam p_o h_o > 0
#     C_p(h) = O  iff  p.h + lam max(p_j h_j, p_l h_l) < 0
#     C_p(h) = S  otherwise;            C_p(h) = M for h > 0.
# Arrow costs at world i:  c_i(a,b) = P_i(b) - P_i(a) + f_i(a,b) with
#     P_i(M) = -h_i - lam[i=o] h_o,  P_i(S) = 0,  P_i(O) = h_i (1 + (lam/2)[i!=o]),  P_i(X) = (3+lam)|h_i| + lam|h_o|,
#     friction f_i(a,O) = (lam/2) h_i [i != o] for a in {S, M}, zero otherwise.
#     (Unanimous h: P = -h_i, 0, h_i, 3h_i, no friction.)
# Checks:
#  (a) strict guidance signs of every arrow at every world;
#  (b) pointwise arrow-Bayes: sum_i p_i c_i(h; C_p(h), b) >= 0 for every b, on a grid of p (boundary included)
#      and random rational h of every sign pattern  (=> every C_p is competitive on supp p);
#  (c) positive cycle sums (friction) exactly on cycles through O at the positive worlds;
#  (d) an explicit strict 3-model cycle X <=_j Y <=_j Z, Z <_j X (atomic surrogate of Lemma 4.4);
#  (e) the (C)-failure: Y = T1 with O on three permuted mismatch atoms is tied with T1 at all three worlds.
import random
from fractions import Fraction as F

ADV = ['M', 'S', 'O', 'X']

def setup(eps):
    c0 = (1 - eps) / 3
    return c0, eps / c0

def odd(h):
    neg = [k for k in range(3) if h[k] < 0]
    return neg[0] if neg else None

def advice(p, h, lam):
    o = odd(h)
    if o is None:
        return 'M'
    j, l = [k for k in range(3) if k != o]
    ph = sum(p[k] * h[k] for k in range(3))
    if ph + lam * p[o] * h[o] > 0:
        return 'M'
    if ph + lam * max(p[j] * h[j], p[l] * h[l]) < 0:
        return 'O'
    return 'S'

def P(i, h, a, lam):
    o = odd(h)
    if o is None:
        return {'M': -h[i], 'S': F(0), 'O': h[i], 'X': 3 * h[i]}[a]
    if a == 'M':
        return -h[i] - (lam * h[o] if i == o else 0)
    if a == 'S':
        return F(0)
    if a == 'O':
        return h[i] * (1 + (lam / 2 if i != o else 0))
    return (3 + lam) * abs(h[i]) + lam * abs(h[o])

def fric(i, h, a, b, lam):
    o = odd(h)
    if o is None or i == o:
        return F(0)
    if b == 'O' and a in ('S', 'M'):
        return lam / 2 * h[i]
    return F(0)

def c(i, h, a, b, lam):
    if a == b:
        return F(0)
    return P(i, h, b, lam) - P(i, h, a, lam) + fric(i, h, a, b, lam)

def rank(i, h, a):
    o = odd(h)
    if o is not None and i == o:
        order = ['O', 'S', 'M', 'X']
    else:
        order = ['M', 'S', 'O', 'X']
    return order.index(a)

def rand_h(rng, pattern):
    return tuple(F(rng.randint(1, 400), rng.randint(1, 60)) * s for s in pattern)

def grid(n):
    return [(F(a, n), F(b, n), F(n - a - b, n)) for a in range(n + 1) for b in range(n + 1 - a)]

def main():
    rng = random.Random(20261018)
    out = []
    patterns = [(1, 1, 1), (1, 1, -1), (1, -1, 1), (-1, 1, 1)]
    for eps in (F(1, 20), F(3, 10), F(1, 2), F(9, 10)):
        c0, lam = setup(eps)
        # (a)
        bad_a = 0; n_a = 0
        for _ in range(600):
            h = rand_h(rng, rng.choice(patterns))
            for i in range(3):
                for a in ADV:
                    for b in ADV:
                        if a == b:
                            continue
                        n_a += 1
                        v = c(i, h, a, b, lam)
                        if (rank(i, h, b) > rank(i, h, a)) != (v > 0) or v == 0:
                            bad_a += 1
        # (b)
        bad_b = 0; n_b = 0; strict_b = 0
        G = grid(12)
        for _ in range(250):
            h = rand_h(rng, rng.choice(patterns))
            for p in G:
                a = advice(p, h, lam)
                for b in ADV:
                    if b == a:
                        continue
                    n_b += 1
                    s = sum(p[i] * c(i, h, a, b, lam) for i in range(3))
                    if s < 0:
                        bad_b += 1
                    elif s > 0:
                        strict_b += 1
        # (c) cycle sums on {M,S,O} at a mixed h
        h = (F(2), F(1), F(-3, 2)); o = odd(h)
        cyc = {}
        for i in range(3):
            cyc[i] = {
                'S>O>S': c(i, h, 'S', 'O', lam) + c(i, h, 'O', 'S', lam),
                'M>O>M': c(i, h, 'M', 'O', lam) + c(i, h, 'O', 'M', lam),
                'M>S>M': c(i, h, 'M', 'S', lam) + c(i, h, 'S', 'M', lam),
                'M>S>O>M': c(i, h, 'M', 'S', lam) + c(i, h, 'S', 'O', lam) + c(i, h, 'O', 'M', lam),
                'M>O>S>M': c(i, h, 'M', 'O', lam) + c(i, h, 'O', 'S', lam) + c(i, h, 'S', 'M', lam),
            }
        out.append(f"eps={eps}: lam={lam}")
        out.append(f"  (a) strict guidance signs: {n_a} arrows, {bad_a} failures")
        out.append(f"  (b) arrow-Bayes: {n_b} (p,h,b) tests on Delta cap (1/12)Z^3 x 250 random h, "
                   f"{bad_b} negative, {strict_b} strictly positive")
        for i in range(3):
            tag = 'odd' if i == o else 'positive'
            out.append(f"  (c) world {i+1} ({tag}) at h={h}: " + ", ".join(f"{k}={v}" for k, v in cyc[i].items()))
        # (d) strict 3-model cycle at world j=1 (positive), h* with odd world 3; atoms C1, C2 (weight w), I (weight d)
        hs = (F(1), F(1), F(-1)); w = F(1); i = 0
        sum_SO = c(i, hs, 'S', 'O', lam) + c(i, hs, 'O', 'S', lam)
        d = w * sum_SO / (2 * abs(c(i, hs, 'O', 'S', lam)))   # half the admissible size
        X = {'C1': 'S', 'C2': 'O', 'I': 'O'}
        Y = {'C1': 'O', 'C2': 'S', 'I': 'S'}
        Z = {'C1': 'S', 'C2': 'O', 'I': 'S'}
        wt = {'C1': w, 'C2': w, 'I': d}
        def kappa(A, B, i=i):
            return sum(wt[k] * c(i, hs, A[k], B[k], lam) for k in wt)
        def improving(A, B, i=i):   # B pointwise weakly better than A at i, strictly somewhere
            r = [rank(i, hs, B[k]) - rank(i, hs, A[k]) for k in wt]
            return all(x <= 0 for x in r) and any(x < 0 for x in r)
        k1, k2 = kappa(X, Y), kappa(Y, Z)
        kzx, kxz = kappa(Z, X), kappa(X, Z)
        out.append(f"  (d) world 1, h*={hs}, w={w}, d={d}: kappa(X->Y)={k1} kappa(Y->Z)={k2} "
                   f"kappa(Z->X)={kzx} kappa(X->Z)={kxz}; Z pointwise better than X at world 1: {improving(X, Z)}")
        ok_d = k1 >= 0 and k2 >= 0 and kzx >= 0 and kxz < 0 and improving(X, Z)
        out.append(f"      strict cycle X<=Y<=Z, Z<X at world 1 (violates (TC), hence (FC)): {ok_d}")
        # (e) (C)-failure at T1 = C_u with three permuted mismatch atoms
        u = (F(1, 3),) * 3
        found = None
        for _ in range(20000):
            a_, b_ = F(rng.randint(1, 300), 100), F(rng.randint(1, 300), 100)
            t = F(rng.randint(1, 600), 100)
            hh = (a_, b_, -t)
            if advice(u, hh, lam) != 'S':
                continue
            if sum(hh) + lam * (hh[0] + hh[1]) / 2 < 0:
                found = hh; break
        if found is None:
            out.append("  (e) no mismatch point found")
        else:
            perms = [found, (found[2], found[0], found[1]), (found[1], found[2], found[0])]
            ties = []
            for i in range(3):
                kYT = sum(c(i, hh, 'O', 'S', lam) for hh in perms)    # Y -> T1 : O -> S on the three atoms
                kTY = sum(c(i, hh, 'S', 'O', lam) for hh in perms)    # T1 -> Y : S -> O
                ties.append((kYT, kTY))
            allT1S = all(advice(u, hh, lam) == 'S' for hh in perms)
            out.append(f"  (e) mismatch h={found} (T1 silent on all three permutations: {allT1S}); "
                       + "; ".join(f"world {i+1}: k(Y->T1)={a}, k(T1->Y)={b}" for i, (a, b) in enumerate(ties)))
            out.append(f"      Y tied with T1 at every world: {all(a >= 0 and b >= 0 for a, b in ties)}")
    print("\n".join(out))

if __name__ == '__main__':
    main()
