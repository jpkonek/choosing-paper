# HH1 toy systems: two worlds, selected chain c_t (t in grid), extra models.
# Checks reflexivity, (FC) via SCCs (a strict edge inside an SCC = strict cycle), (TC),
# competitiveness of grid selections, (LA), direct (C), and the claims of Examples A and B.
from fractions import Fraction as F
import itertools, sys
N = 48
grid = [F(k, N) for k in range(N+1)]
def base(models):
    R = {1:set(), 2:set()}
    for a in models: R[1].add((a,a)); R[2].add((a,a))
    for s in grid:
        for t in grid:
            if s >= t: R[1].add((('c',s),('c',t)))   # c_s <=_1 c_t iff s>=t  (loss (1-t,t))
            if s <= t: R[2].add((('c',s),('c',t)))
    return R
def exampleA():
    m, mp = ('m',), ('mp',)
    models = [('c',t) for t in grid] + [m, mp]
    R = base(models)
    h, q = F(1,2), F(1,4)
    for t in grid:
        if t >= h: R[1].add((('c',t), m))
        if t <= h: R[2].add((('c',t), m))
        if t >= q: R[1].add((('c',t), mp))
        if t <= q: R[2].add((('c',t), mp))
    R[2].add((m, ('c',h)))           # m tied with c_1/2 at world 2 only
    for w in (1,2): R[w].add((mp, m)) # m' <= m, not m <= m'  (strict)
    return models, R, {'m':m,'mp':mp}
def exampleB():
    e, ep = ('e',), ('ep',)
    models = [('c',t) for t in grid] + [e, ep]
    R = base(models)
    h = F(1,2)
    for x in (e, ep):
        for t in grid:
            if t >= h: R[1].add((('c',t), x))
            if t <= h: R[2].add((('c',t), x))
        for w in (1,2): R[w].add((x, ('c',h)))
    return models, R, {'e':e,'ep':ep}
def le(R,w,a,b): return (a,b) in R[w]
def lt(R,w,a,b): return le(R,w,a,b) and not le(R,w,b,a)
def check_FC(models, R, w):
    adj = {a:[] for a in models}
    for (a,b) in R[w]: adj[a].append(b)
    # Tarjan SCC
    idx, low, onst, st, comp = {}, {}, set(), [], {}
    counter=[0]; cid=[0]
    sys.setrecursionlimit(100000)
    def sc(v):
        idx[v]=low[v]=counter[0]; counter[0]+=1; st.append(v); onst.add(v)
        for u in adj[v]:
            if u not in idx: sc(u); low[v]=min(low[v],low[u])
            elif u in onst: low[v]=min(low[v],idx[u])
        if low[v]==idx[v]:
            while True:
                u=st.pop(); onst.discard(u); comp[u]=cid[0]
                if u==v: break
            cid[0]+=1
    for v in models:
        if v not in idx: sc(v)
    bad = [(a,b) for (a,b) in R[w] if comp[a]==comp[b] and lt(R,w,a,b)]
    return bad
def check_TC(models,R,w):
    bad=0
    S=R[w]; succ={a:set() for a in models}
    for (a,b) in S: succ[a].add(b)
    for a in models:
        for b in succ[a]:
            for c in succ[b]:
                if lt(R,w,c,a): bad+=1
    return bad
def report(name, models, R):
    print('==',name)
    for w in (1,2):
        assert all((a,a) in R[w] for a in models)
        print(' world',w,'FC strict edges in SCCs:',len(check_FC(models,R,w)),' TC violations:',check_TC(models,R,w))
    # competitiveness: grid t interior -> some world; t=1 (delta_1) world 1 ideal; t=0 world 2 ideal
    comp_fail=0
    for t in grid:
        c=('c',t); W=[1,2] if 0<t<1 else ([1] if t==1 else [2])
        for x in models:
            if not any(le(R,w,c,x) for w in W): comp_fail+=1
    print(' competitiveness failures:',comp_fail)
    def dominates(a,b): return all(le(R,w,a,b) for w in (1,2)) and any(not le(R,w,b,a) for w in (1,2))
    coh=[('c',t) for t in grid]+[x for x in models if x[0] in ('e','ep')]
    und=[x for x in models if not any(dominates(y,x) for y in models)]
    print(' undominated:',[x for x in und if x[0]!='c'], ' all coherent grid models undominated:', all(c in und for c in coh))
    CL=[x for x in coh if x in und]
    tie=lambda a,b: all(le(R,w,a,b) and le(R,w,b,a) for w in (1,2))
    print(' (C) violations:',[x for x in models if x not in CL and any(tie(x,c) for c in CL)])
    return dominates, tie
mA,RA,dA=exampleA(); dom,tie=report('Example A',mA,RA)
m,mp=dA['m'],dA['mp']
print(' m strictly dominated by mp at both worlds:', all(lt(RA,w,mp,m) for w in (1,2)))
print(' coherent models strictly dominating m at both worlds:', [x for x in mA if x[0]=='c' and all(lt(RA,w,x,m) for w in (1,2))])
print(' coherent c with c<=_w mp and not m<=_w c on both worlds:', [str(x[1]) for x in mA if x[0]=='c' and all(le(RA,w,x,mp) and not le(RA,w,m,x) for w in (1,2))])
print(' m dominated by:', [str(x[1]) for x in mA if x[0]=='c' and dom(x,m)])
mB,RB,dB=exampleB(); dom,tie=report('Example B',mB,RB)
e,ep=dB['e'],dB['ep']; ch=('c',F(1,2))
print(' e~c, ep~c, e~ep:', tie(e,ch), tie(ep,ch), tie(e,ep))
print(' third-party witness: c_1/2 <=_2 c_3/4:', le(RB,2,ch,('c',F(3,4))), ' e <=_2 c_3/4:', le(RB,2,e,('c',F(3,4))))
