"""SCREEN_C: exact per-problem (TC) and transitivity tests for transition costs c(x,y) at one world.
Run: python3 -I tc_check.py  (from inside screenC_py/)."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from itertools import product
from exlp import feasible

S = ['+', '0', '-', 'x']
W = F(1, 3)  # FC v3 width parameter for target [1/3,2/3]

def pen_mixed(a, b):
    cw = a * b / ((1 + W) * (a + b))
    return ({'+': F(0), '0': cw, '-': a, 'x': 2 * a},   # world 1
            {'+': b, '0': cw, '-': F(0), 'x': 2 * b})   # world 2

def potential(rho):
    return {(x, y): rho[y] - rho[x] for x in S for y in S}

def triples(c):
    return [((x, y, z), (c[x, y], c[y, z], c[z, x], c[x, z])) for x, y, z in product(S, S, S)]

def tc_fail(c):
    T = triples(c); K = len(T)
    A = []; b = []
    for comp in range(3):
        A.append([v[comp] for _, v in T] + [(-1 if j == comp else 0) for j in range(3)]); b.append(0)
    A.append([v[3] for _, v in T] + [0, 0, 0]); b.append(-1)
    x = feasible(A, b)
    if x is None: return None
    return [(T[k][0], x[k]) for k in range(K) if x[k] != 0]

def tc_cert(c):
    T = triples(c); K = len(T)
    A = []; b = []
    for k, (_, v) in enumerate(T):
        A.append([v[0], v[1], v[2]] + [(1 if j == k else 0) for j in range(K)]); b.append(v[3])
    x = feasible(A, b)
    return None if x is None else x[:3]

def trans_fail(c):
    T = triples(c); K = len(T)
    A = [[v[0] for _, v in T] + [-1, 0], [v[1] for _, v in T] + [0, -1], [v[3] for _, v in T] + [0, 0]]
    x = feasible(A, [0, 0, -1])
    if x is None: return None
    return [(T[k][0], x[k]) for k in range(K) if x[k] != 0]

def guidance_ok(c, rank):
    for x in S:
        for y in S:
            if x == y: continue
            if rank[y] > rank[x] and c[x, y] < 0: return False
            if rank[y] < rank[x] and not c[x, y] < 0: return False
    return True

def report(name, cs):
    print('==', name)
    ranks = ({'+': 0, '0': 1, '-': 2, 'x': 3}, {'-': 0, '0': 1, '+': 2, 'x': 3})
    for i, c in enumerate(cs):
        g = guidance_ok(c, ranks[i])
        f = tc_fail(c); cert = tc_cert(c); tf = trans_fail(c)
        print(f'  world {i+1}: strict(G) {g}; per-problem (TC) ' +
              ('HOLDS, certificate (l1,l2,l3,l4)=' + str(tuple(map(str, cert))) + ',1' if f is None else 'FAILS'))
        if f is not None:
            print('     failing combination (triple A,B,C : weight):', [(''.join(t), str(w)) for t, w in f])
            assert cert is None
        print('     transitivity on this problem:', 'holds' if tf is None else
              'FAILS ' + str([(''.join(t), str(w)) for t, w in tf]))

if __name__ == '__main__':
    a, b = F(1), F(2)
    r1, r2 = pen_mixed(a, b)
    J = -a * b / (4 * (a + b))
    print('mixed problem g=(a,-b), a=%s b=%s, FC v3 penalties w=1/3; jump discount J=%s' % (a, b, J))
    report('P: potential c = rho(b)-rho(a)', [potential(r1), potential(r2)])
    def mod(r, jm, jp):  # jm on (-,+), jp on (+,-)
        c = potential(r); c['-', '+'] += jm; c['+', '-'] += jp; return c
    report('E1: symmetric jump discount J=J\'<0 (example of SCREEN_C)', [mod(r1, J, J), mod(r2, J, J)])
    report('E2: one-sided jump discount J<0, J\'=0', [mod(r1, J, 0), mod(r2, J, 0)])
    report('E3: jump surcharge J=J\'>0 (two-step chain cheaper than jump)', [mod(r1, -J, -J), mod(r2, -J, -J)])
    def fric(r, eps):
        c = potential(r); c['0', '-'] += eps; c['-', '0'] += eps; return c
    report('E4: friction on adjacent pair (-,0): s>0', [fric(r1, -J), fric(r2, -J)])
    report('E5: anti-friction on adjacent pair (-,0): s<0 (TC ok; excluded instead by uniqueness/adjacency)',
           [fric(r1, J), fric(r2, J)])
