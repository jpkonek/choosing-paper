"""Exact rational Phase-I simplex (Bland's rule). feasible(A, b): find x>=0 with A x = b, or None."""
from fractions import Fraction as F

def feasible(A, b):
    m = len(A); n = len(A[0]) if m else 0
    A = [[F(v) for v in row] for row in A]; b = [F(v) for v in b]
    for r in range(m):
        if b[r] < 0:
            A[r] = [-v for v in A[r]]; b[r] = -b[r]
    # tableau with artificials n..n+m-1
    T = [A[r] + [F(1) if j == r else F(0) for j in range(m)] + [b[r]] for r in range(m)]
    basis = [n + r for r in range(m)]
    N = n + m
    # objective: minimise sum of artificials -> reduced costs
    def obj_row():
        c = [F(0)] * N + [F(0)]
        for j in range(n, N): c[j] = F(1)
        for r in range(m):
            bj = basis[r]
            if c[bj] != 0:
                f = c[bj]
                c = [c[k] - f * T[r][k] for k in range(N + 1)]
        return c
    while True:
        c = obj_row()
        enter = next((j for j in range(N) if c[j] < 0), None)
        if enter is None: break
        best = None
        for r in range(m):
            if T[r][enter] > 0:
                ratio = T[r][N] / T[r][enter]
                if best is None or ratio < best[0] or (ratio == best[0] and basis[r] < basis[best[1]]):
                    best = (ratio, r)
        if best is None: break  # unbounded direction (cannot happen in phase I)
        r = best[1]; p = T[r][enter]
        T[r] = [v / p for v in T[r]]
        for rr in range(m):
            if rr != r and T[rr][enter] != 0:
                f = T[rr][enter]
                T[rr] = [T[rr][k] - f * T[r][k] for k in range(N + 1)]
        basis[r] = enter
    x = [F(0)] * N
    for r in range(m): x[basis[r]] = T[r][N]
    if any(x[j] != 0 for j in range(n, N)): return None
    return x[:n]
