"""SCREEN_C: exact grid check of Example C1 (two worlds, target K*=[1/3,2/3]).
Rule: c_i(h,x,y) = rho_i(h,y)-rho_i(h,x) (FC v3 penalties, w=1/3) except on mixed h=(a,-b):
      c_i(-,+) and c_i(+,-) are both lowered by J(h) = -ab/(4(a+b)) at both worlds.
Selection: C_t = D_{K_t}, K_t=[max(0,(4t-1)/3), min(1,4t/3)], stability weight w(t)=(t,1-t).
Also: the two-problem friction swap (hysteresis tie) and its (TC) failure.  Run: python3 -I example_check.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from itertools import product
from tc_check import S, pen_mixed, potential, W

def costs(a, b):
    r1, r2 = pen_mixed(a, b); J = -a * b / (4 * (a + b))
    cs = []
    for r in (r1, r2):
        c = potential(r); c['-', '+'] += J; c['+', '-'] += J; cs.append(c)
    return cs, (r1, r2), J

def Kt(t):
    return max(F(0), (4 * t - 1) / 3), min(F(1), 4 * t / 3)

def advice(t, a, b):
    lo, hi = Kt(t); tau = b / (a + b)       # m.h = 0 at m1 = tau
    if lo > tau: return '+'
    if hi < tau: return '-'
    if lo < tau < hi: return '0'
    return None                              # threshold: null set of h for fixed t

def main():
    ranks = ({'+': 0, '0': 1, '-': 2, 'x': 3}, {'-': 0, '0': 1, '+': 2, 'x': 3})
    vals = [F(1, 5), F(1, 3), F(1, 2), F(1), F(3, 2), F(2), F(3), F(7)]
    ts = [F(k, 96) for k in range(97)]
    cnt = dict(stab=0, uniq=0, thr=0, G=0, cert=0, endorse=0)
    for a, b in product(vals, vals):
        cs, rs, J = costs(a, b)
        for i in range(2):
            c, r, rk = cs[i], rs[i], ranks[i]
            for x, y in product(S, S):
                if x == y: continue
                assert (c[x, y] >= 0) if rk[y] > rk[x] else (c[x, y] < 0), ('G', a, b, i, x, y)
                cnt['G'] += 1
                assert c[x, y] <= r[y] - r[x]; cnt['endorse'] += 1          # endorsed by rho (J<=0)
            for x, y, z in product(S, S, S):                                   # certificate (2,2,1;1)
                assert c[x, z] - 2 * c[x, y] - 2 * c[y, z] - c[z, x] >= 0; cnt['cert'] += 1
            assert c['-', '+'] + c['+', '-'] == 2 * J < 0                     # anti-friction on jump only
        for t in ts:
            w = (t, 1 - t)
            stable = [x for x in S if all(w[0] * cs[0][x, y] + w[1] * cs[1][x, y] >= 0 for y in S)]
            adv = advice(t, a, b)
            if adv is None:
                cnt['thr'] += 1; assert len(stable) >= 1; continue
            assert adv in stable, ('stability', a, b, t, adv, stable); cnt['stab'] += 1
            assert stable == [adv], ('uniqueness', a, b, t, stable); cnt['uniq'] += 1
    # unanimous problems: potential with FC v3 table; + uniquely stable at every w (strict G at both worlds)
    print('checks passed:', cnt)
    print('target: K_{1/2} =', tuple(map(str, Kt(F(1, 2)))))

    # ---- two-problem friction swap: hysteresis tie and (TC) failure (world 1 only matters) ----
    g, e = F(1), F(1, 4)               # c(u->v)=g+e (worsening), c(v->u)=-g+e (improvement): s=2e>0
    def c1(x, y):
        if x == y: return F(0)
        return g + e if (x, y) == ('u', 'v') else -g + e
    cells = {'P1': F(1), 'P2': F(1), 'Q': F(1, 100)}
    A = {'P1': 'u', 'P2': 'v', 'Q': 'v'}
    B = {'P1': 'v', 'P2': 'u', 'Q': 'v'}
    C = {'P1': 'u', 'P2': 'v', 'Q': 'u'}   # C improves on A on Q only
    def L(X, Y): return sum(m * c1(X[k], Y[k]) for k, m in cells.items())   # X <=_1 Y iff L(X,Y)>=0
    print('friction swap: A<=B', L(A, B) >= 0, ' B<=A', L(B, A) >= 0, ' (tie with slack', L(A, B), L(B, A), ')')
    print('               B<=C', L(B, C) >= 0, ' C<=A', L(C, A) >= 0, ' A<=C', L(A, C) >= 0,
          ' => A<=B<=C and C strictly better than A: (TC) fails')

if __name__ == '__main__':
    main()
