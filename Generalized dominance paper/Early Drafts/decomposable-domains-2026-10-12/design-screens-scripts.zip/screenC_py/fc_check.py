"""SCREEN_C: longer cycles for Example C1 at one mixed problem: (FC) with k=3 (four models), exact LP.
Forbidden: A0<=A1<=A2<=A3 and A3 < A0 (A3<=A0, not A0<=A3).  Run: python3 -I fc_check.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from itertools import product
from exlp import feasible
from tc_check import S
from example_check import costs

def fc_fail(c, k=3):
    T = list(product(S, repeat=k + 1)); n = len(T); A = []; b = []
    edges = [(j, j + 1) for j in range(k)] + [(k, 0)]
    for e_idx, (p, q) in enumerate(edges):
        A.append([c[t[p], t[q]] for t in T] + [(-1 if j == e_idx else 0) for j in range(len(edges))]); b.append(0)
    A.append([c[t[0], t[k]] for t in T] + [0] * len(edges)); b.append(-1)
    x = feasible(A, b)
    return None if x is None else [(''.join(T[i]), str(x[i])) for i in range(n) if x[i] != 0]

for a, b in [(F(1), F(2)), (F(3), F(1, 2))]:
    cs, _, J = costs(a, b)
    for i in range(2):
        r = fc_fail(cs[i])
        print(f'a={a} b={b} world {i+1}: (FC,k=3) per problem', 'holds' if r is None else 'FAILS ' + str(r))
