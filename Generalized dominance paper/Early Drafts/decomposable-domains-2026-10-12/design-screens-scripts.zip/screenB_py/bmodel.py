"""Exchange licensing (candidate B) on exact cell models.  All arithmetic in Fractions.

Problems g in H = {g1 > 0} are indexed by the slope t = g2/g1.  A sector is an open slope interval;
cells are pieces of sectors carrying a nu-mass (nu = Gaussian measure of the cone, i.e. angle/2pi;
any rational mass is realised by an angular sub-interval, and every verdict depends only on masses).

World ranks (good < silence < bad < contradiction):
  unanimous sectors (t > 0), both worlds:  + 0, 0 1, - 2, x 3
  mixed sectors (t < 0):  world 1: + 0, 0 1, - 2, x 3;   world 2: - 0, 0 1, + 2, x 3
Rung r of a sector sits between ranks r and r+1.  A record C -> X contributes, at world i, for every
cell and every rung strictly between the two ranks, the cell's mass to the gain (X better) or loss
(X worse) of the node (sector, r).  This is "rank steps x density" with density 1 w.r.t. nu.
"""
from fractions import Fraction as Fr
from itertools import product
from lpexact import feasible

R1 = {'+': 0, '0': 1, '-': 2, 'x': 3}
R2MIX = {'-': 0, '0': 1, '+': 2, 'x': 3}
ADV1 = {0: '+', 1: '0', 2: '-', 3: 'x'}


def rank(world, mixed, adv):
    if world == 2 and mixed:
        return R2MIX[adv]
    return R1[adv]


def adv_of_rank(world, mixed, r):
    d = R2MIX if (world == 2 and mixed) else R1
    return {v: k for k, v in d.items()}[r]


class Cell:
    def __init__(self, name, sector, mass, mixed=True):
        self.name, self.sector, self.mass, self.mixed = name, sector, Fr(mass), mixed


def record(world, cells, C, X):
    """(gain, loss) dicts node -> mass for the record C -> X at world `world`."""
    g, l = {}, {}
    for c in cells:
        rc, rx = rank(world, c.mixed, C[c.name]), rank(world, c.mixed, X[c.name])
        if rx < rc:
            for r in range(rx, rc):
                g[(c.sector, r)] = g.get((c.sector, r), 0) + c.mass
        elif rx > rc:
            for r in range(rc, rx):
                l[(c.sector, r)] = l.get((c.sector, r), 0) + c.mass
    return g, l


class RungWorld:
    """B at one world: edges {(n, n2): kappa}: one unit of loss on n pays kappa units of gain on n2."""

    def __init__(self, index, edges):
        self.i = index
        self.E = {k: Fr(v) for k, v in edges.items()}

    def accept_record(self, g, l):
        """Return (True, plan) or (False, (u, v)); both exactly verified."""
        edges = [e for e in self.E if (l.get(e[0], 0) > 0 and g.get(e[1], 0) > 0)]
        gnodes = [n for n in g if g[n] > 0]
        lnodes = sorted({e[0] for e in edges}, key=str)
        # primal: f >= 0; sum_out f <= l ; -sum_in kappa f <= -g
        A, b = [], []
        for n in lnodes:
            A.append([Fr(1) if e[0] == n else Fr(0) for e in edges]); b.append(Fr(l.get(n, 0)))
        for n in gnodes:
            A.append([-self.E[e] if e[1] == n else Fr(0) for e in edges]); b.append(-Fr(g[n]))
        f = feasible(A, b) if edges or not gnodes else None
        if not gnodes:
            f = []
        if f is not None:
            plan = {e: f[k] for k, e in enumerate(edges) if f[k] != 0}
            assert verify_plan(self.E, g, l, plan)
            return True, plan
        # Farkas: u (loss nodes), v (gain nodes) >= 0, kappa v_n2 <= u_n on edges, v.g - u.l >= 1
        unodes = sorted({e[0] for e in self.E if e[1] in gnodes} | set(l), key=str)
        nu, nv = len(unodes), len(gnodes)
        A2, b2 = [], []
        for e in self.E:
            if e[1] in gnodes and e[0] in unodes:
                row = [Fr(0)] * (nu + nv)
                row[unodes.index(e[0])] = Fr(-1)
                row[nu + gnodes.index(e[1])] = self.E[e]
                A2.append(row); b2.append(Fr(0))
        row = [Fr(l.get(n, 0)) for n in unodes] + [-Fr(g[n]) for n in gnodes]
        A2.append(row); b2.append(Fr(-1))
        y = feasible(A2, b2)
        assert y is not None, "neither plan nor Farkas vector found"
        u = {n: y[k] for k, n in enumerate(unodes)}
        v = {n: y[nu + k] for k, n in enumerate(gnodes)}
        assert verify_farkas(self.E, g, l, u, v)
        return False, (u, v)

    def R(self, cells, C, X):
        """'C no worse than X' at this world."""
        g, l = record(self.i, cells, C, X)
        return self.accept_record(g, l)[0]

    def strict(self, cells, C, X):
        return self.R(cells, C, X) and not self.R(cells, X, C)


def verify_plan(E, g, l, plan):
    used, cov = {}, {}
    for (n, n2), f in plan.items():
        if (n, n2) not in E or f < 0:
            return False
        used[n] = used.get(n, 0) + f
        cov[n2] = cov.get(n2, 0) + E[(n, n2)] * f
    return all(used[n] <= l.get(n, 0) for n in used) and all(cov.get(n, 0) >= g[n] for n in g if g[n] > 0)


def verify_farkas(E, g, l, u, v):
    """u, v >= 0 with kappa v_{n2} <= u_n for every edge, and v.g > u.l: then no plan exists
    (sum over a plan: v.g <= sum kappa f v <= sum f u <= u.l)."""
    if any(x < 0 for x in list(u.values()) + list(v.values())):
        return False
    for (n, n2), k in E.items():
        if k * v.get(n2, 0) > u.get(n, 0) and v.get(n2, 0) > 0:
            return False
    return sum(v[n] * g.get(n, 0) for n in v) > sum(u[n] * l.get(n, 0) for n in u)


class AdditiveWorld:
    """Rank integral, density 1: B with the complete graph and all rates 1."""

    def __init__(self, index):
        self.i = index

    def L(self, cells, X):
        return sum(c.mass * rank(self.i, c.mixed, X[c.name]) for c in cells)

    def R(self, cells, C, X):
        return self.L(cells, C) <= self.L(cells, X)

    def strict(self, cells, C, X):
        return self.L(cells, C) < self.L(cells, X)


def worsening_free(world, cells, recs):
    """recs: list of (weight, C, X).  Pointwise combination sum w (delta_X - delta_C) of world ranks:
    every upper tail <= 0 at every cell (first-order downward), and nonzero somewhere."""
    nonzero = False
    for c in cells:
        tails = [Fr(0)] * 5
        for w, C, X in recs:
            rc, rx = rank(world, c.mixed, C[c.name]), rank(world, c.mixed, X[c.name])
            for s in range(1, 4):
                tails[s] += w * ((1 if rx >= s else 0) - (1 if rc >= s else 0))
        if any(t > 0 for t in tails):
            return False
        if any(t != 0 for t in tails):
            nonzero = True
    return nonzero


def pointwise_better(world, cells, Z, X):
    """Z at least as good as X everywhere and strictly somewhere (world ranks)."""
    rz = [rank(world, c.mixed, Z[c.name]) for c in cells]
    rx = [rank(world, c.mixed, X[c.name]) for c in cells]
    return all(a <= b for a, b in zip(rz, rx)) and any(a < b for a, b in zip(rz, rx))


# ---------------- interval models in slope coordinates ----------------

def thresholds(a, b):
    """D_[a,b] (credal set m1 in [a,b]) on g = (1, t): accept g iff t > -alpha, accept -g iff t < -beta."""
    alpha = None if a == 1 else Fr(a) / (1 - Fr(a))
    beta = None if b == 1 else Fr(b) / (1 - Fr(b))
    return alpha, beta


def interval_advice(a, b, lo, hi):
    """Advice of D_[a,b] on the open slope sector (lo, hi), lo may be None (-inf); hi <= 0 or sector unanimous."""
    if lo is not None and lo >= 0:
        return '+'
    alpha, beta = thresholds(a, b)
    # '+' region: t > -alpha (alpha None = +inf: everything mixed accepted)
    if alpha is None or (lo is not None and lo >= -alpha):
        return '+'
    if beta is not None and hi <= -beta:
        return '-'
    lo_ok = (beta is None) or (lo is not None and lo >= -beta)
    if lo_ok and hi <= -alpha:
        return '0'
    return 'straddle'
