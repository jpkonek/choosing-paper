"""Exact (Fraction) two-phase simplex, Bland's rule.  Only feasibility is needed.

feasible(A, b) -> x (list of Fraction) with x >= 0 and A x <= b, or None.
Every answer used by the checks is re-verified independently (see bmodel.py):
a feasible verdict by an explicit plan, an infeasible one by an explicit Farkas vector.
"""
from fractions import Fraction as Fr


def _pivot(T, rhs, r, c):
    p = T[r][c]
    T[r] = [v / p for v in T[r]]
    rhs[r] = rhs[r] / p
    for i in range(len(T)):
        if i != r and T[i][c] != 0:
            f = T[i][c]
            T[i] = [a - f * bb for a, bb in zip(T[i], T[r])]
            rhs[i] = rhs[i] - f * rhs[r]


def feasible(A, b):
    """Find x >= 0 with A x <= b (A: list of rows of Fractions)."""
    m = len(A)
    n = len(A[0]) if m else 0
    if m == 0:
        return [Fr(0)] * n
    # columns: x (n), slacks (m), artificials (one per row with b<0)
    neg = [i for i in range(m) if b[i] < 0]
    na = len(neg)
    N = n + m + na
    T, rhs, basis = [], [], []
    for i in range(m):
        row = [Fr(v) for v in A[i]] + [Fr(1) if j == i else Fr(0) for j in range(m)] + [Fr(0)] * na
        bi = Fr(b[i])
        if bi < 0:
            row = [-v for v in row]
            bi = -bi
            k = neg.index(i)
            row[n + m + k] = Fr(1)
            basis.append(n + m + k)
        else:
            basis.append(n + i)
        T.append(row)
        rhs.append(bi)
    cost = [Fr(0)] * (n + m) + [Fr(-1)] * na  # maximise -sum(artificials)
    while True:
        cb = [cost[j] for j in basis]
        enter = None
        for j in range(N):
            if j in basis:
                continue
            r = cost[j] - sum(cb[i] * T[i][j] for i in range(m))
            if r > 0:
                enter = j
                break
        if enter is None:
            break
        best = None
        for i in range(m):
            if T[i][enter] > 0:
                ratio = rhs[i] / T[i][enter]
                if best is None or ratio < best[0] or (ratio == best[0] and basis[i] < basis[best[1]]):
                    best = (ratio, i)
        _pivot(T, rhs, best[1], enter)
        basis[best[1]] = enter
    val = sum(rhs[i] for i in range(m) if basis[i] >= n + m)
    if val != 0:
        return None
    x = [Fr(0)] * n
    for i in range(m):
        if basis[i] < n:
            x[basis[i]] = rhs[i]
    return x
