"""SCREEN_B checks.  Run:  python3 -I checks.py > checks.out   (from this folder)."""
import random
import sys
from fractions import Fraction as Fr
from itertools import permutations, product

sys.path.insert(0, '.')
from bmodel import (Cell, RungWorld, AdditiveWorld, record, worsening_free, pointwise_better,
                    interval_advice, adv_of_rank, rank)

OK = True


def check(name, cond):
    global OK
    print(('PASS  ' if cond else 'FAIL  ') + name)
    OK = OK and bool(cond)


# ---------------------------------------------------------------- sectors of the instance
SECT = {'U': (Fr(0), None), 'Sp': (Fr(-1, 2), Fr(0)), 'A2': (Fr(-7, 12), Fr(-1, 2)),
        'A1': (Fr(-2, 3), Fr(-7, 12)), 'S0': (Fr(-3, 2), Fr(-2, 3)), 'B2': (Fr(-7, 4), Fr(-3, 2)),
        'B1': (Fr(-2), Fr(-7, 4)), 'Sm': (None, Fr(-2))}
NODES = [(s, r) for s in SECT for r in range(3)]
n1, n2, n3, n4 = ('A1', 0), ('B1', 1), ('A2', 0), ('B2', 1)
CYCLE = [n1, n2, n3, n4]
RATES = {(n1, n2): Fr(1), (n2, n3): Fr(1), (n3, n4): Fr(1), (n4, n1): Fr(2)}
E1 = dict(RATES)
for n in NODES:
    E1[(n, n)] = Fr(1)
W1 = RungWorld(1, E1)
W2 = AdditiveWorld(2)


def simple_cycles(edges):
    nodes = sorted({e[0] for e in edges} | {e[1] for e in edges}, key=str)
    out = []
    for L in range(2, len(nodes) + 1):
        for perm in permutations(nodes, L):
            if perm[0] != min(perm, key=str):
                continue
            if all((perm[k], perm[(k + 1) % L]) in edges for k in range(L)):
                out.append(perm)
    return out


print('=== 1. The explicit instance (world 1) ===')
nonloop = {e: k for e, k in E1.items() if e[0] != e[1]}
cyc = simple_cycles(nonloop)
print('non-loop edges:', nonloop)
print('simple cycles of length >= 2:', cyc)
prod = Fr(1)
for e in RATES:
    prod *= RATES[e]
check('exactly one simple cycle (length 4), no 2- or 3-cycles', len(cyc) == 1 and len(cyc[0]) == 4)
check('cycle rate product = 2 (arbitrage)', prod == 2)

# ---------------------------------------------------------------- 2. pumps
print('\n=== 2. Two-record pump along an arbitrage cycle (TC fails) ===')


def build_pump(world_index, cycle, rates, tag='p'):
    L = len(cycle)
    walk = cycle * (1 if L % 2 == 0 else 2)
    W = len(walk)
    x = [Fr(1)]
    for t in range(1, W + 1):
        x.append(rates[(walk[t - 1], walk[t % W])] * x[t - 1])
    cells, X, Y, Z = [], {}, {}, {}

    def put(name, node, mass, sx, sy, sz):
        sec, r = node
        cells.append(Cell(name, sec, mass, mixed=True))   # every node used lies in a mixed sector
        lo = adv_of_rank(world_index, True, r)
        hi = adv_of_rank(world_index, True, r + 1)
        st = {'L': lo, 'H': hi}
        X[name], Y[name], Z[name] = st[sx], st[sy], st[sz]

    put(tag + '0', walk[0], x[0], 'L', 'H', 'L')          # lost in rec1, regained in rec2
    for t in range(1, W):
        if t % 2 == 1:   # gained in rec1 (edge t has colour 1), lost in rec2
            put(tag + str(t), walk[t], x[t], 'H', 'L', 'H')
        else:            # gained in rec2, lost in rec1
            put(tag + str(t), walk[t], x[t], 'L', 'H', 'L')
    put(tag + 'E', walk[0], x[W] - x[0], 'H', 'H', 'L')   # surplus: improved in rec2 only
    return cells, X, Y, Z, x[W]


cells, X, Y, Z, top = build_pump(1, CYCLE, RATES)
for c in cells:
    print('  cell', c.name, 'sector', c.sector, 'mass', c.mass, ' X/Y/Z =', X[c.name], Y[c.name], Z[c.name])
check('X R1 Y', W1.R(cells, X, Y))
check('Y R1 Z', W1.R(cells, Y, Z))
check('Z pointwise strictly better than X at world 1', pointwise_better(1, cells, Z, X))
check('Z strictly better: Z R1 X and not X R1 Z  (TC violated)', W1.R(cells, Z, X) and not W1.R(cells, X, Z))

# ---------------------------------------------------------------- 3. N2 necessity
print('\n=== 3. Product-1 cycle without exact reverses: 3-record TC failure; with reverses: none ===')


def build_tc3(world_index, cycle, rates, tag='q'):
    """edge e = (cycle[0] -> cycle[1]) gets colour 3, the path cycle[1] -> ... -> cycle[0] colours 1,2,1,..."""
    L = len(cycle)
    x = {cycle[0]: Fr(1)}
    for t in range(1, L):
        x[cycle[t]] = rates[(cycle[t - 1], cycle[t])] * x[cycle[t - 1]]
    colour = {}
    colour[(cycle[0], cycle[1])] = 3
    for t in range(1, L):
        colour[(cycle[t], cycle[(t + 1) % L])] = 1 if t % 2 == 1 else 2
    cells, X, Y, Z = [], {}, {}, {}
    for t, node in enumerate(cycle):
        cin = colour[(cycle[t - 1], node)]
        cout = colour[(node, cycle[(t + 1) % L])]
        lo = adv_of_rank(world_index, True, node[1]); hi = adv_of_rank(world_index, True, node[1] + 1)
        # states along X -> Y -> Z -> X : lost (L->H) in record cout, gained (H->L) in record cin
        seq = {}
        # determine state before record 1 by walking: state after loss = H, after gain = L
        for start in ('L', 'H'):
            s = start; ok = True; st = [s]
            for rec in (1, 2, 3):
                if rec == cout:
                    if s != 'L': ok = False
                    s = 'H'
                elif rec == cin:
                    if s != 'H': ok = False
                    s = 'L'
                st.append(s)
            if ok and st[3] == start:
                seq = st
                break
        name = tag + str(t)
        cells.append(Cell(name, node[0], x[node]))
        m = {'L': lo, 'H': hi}
        X[name], Y[name], Z[name] = m[seq[0]], m[seq[1]], m[seq[2]]
    return cells, X, Y, Z


cons = {(n1, n2): Fr(1), (n2, n3): Fr(1), (n3, n4): Fr(1), (n4, n1): Fr(1)}
Wc = RungWorld(1, dict(cons))
cells3, X3, Y3, Z3 = build_tc3(1, CYCLE, cons)
check('conservative 4-cycle: X R Y, Y R Z, Z R X', Wc.R(cells3, X3, Y3) and Wc.R(cells3, Y3, Z3) and Wc.R(cells3, Z3, X3))
check('conservative 4-cycle without reverses: not X R Z (TC violated, product 1)', not Wc.R(cells3, X3, Z3))
consr = dict(cons)
for (a, b), k in cons.items():
    consr[(b, a)] = 1 / k
Wcr = RungWorld(1, consr)
check('same records with exact reverse edges: X R Z holds', Wcr.R(cells3, X3, Y3) and Wcr.R(cells3, Y3, Z3)
      and Wcr.R(cells3, Z3, X3) and Wcr.R(cells3, X3, Z3))

# ---------------------------------------------------------------- 4. ties under arbitrage
print('\n=== 4. Arbitrage gives nontrivial ties at world 1 ===')
cellsT = [Cell('t1', 'A1', 2), Cell('t2', 'B1', 2), Cell('t3', 'A2', 2), Cell('t4', 'B2', 2)]
CT = {'t1': '+', 't2': '-', 't3': '+', 't4': '-'}
XT = {k: '0' for k in CT}
check('C R1 X and X R1 C for distinct C, X (tie)', W1.R(cellsT, CT, XT) and W1.R(cellsT, XT, CT))

# ---------------------------------------------------------------- 5. random tests of Theorem 3
print('\n=== 5. Theorem 3 on random rung-type worlds (exact verdicts) ===')
rng = random.Random(20261019)
SEC5 = ['P', 'Q', 'R']
NOD5 = [(s, r) for s in SEC5 for r in range(2)]


def random_N1N2_world():
    phi = {n: Fr(rng.randint(1, 6)) for n in NOD5}
    E = {}
    for a in NOD5:
        for b in NOD5:
            if rng.random() < 0.35:
                k = phi[a] / phi[b]
                if rng.random() < 0.5:
                    k *= Fr(rng.randint(1, 4), 5)
                E[(a, b)] = k
    for (a, b), k in list(E.items()):
        if k == phi[a] / phi[b]:
            E[(b, a)] = phi[b] / phi[a]
    for n in NOD5:
        E.setdefault((n, n), Fr(1))
    return E


def perturb(M, cells, k):
    M2 = dict(M)
    for c in rng.sample(cells, k):
        M2[c.name] = rng.choice(['+', '0', '-'])
    return M2


chains = back = viol = cyc_found = strictcyc = 0
for trial in range(80):
    E = random_N1N2_world()
    W = RungWorld(1, E)
    cellsR = [Cell(s + str(j), s, rng.randint(1, 2)) for s in SEC5 for j in range(2)]
    for _ in range(40):
        Xr = {c.name: rng.choice(['+', '0', '-']) for c in cellsR}
        Yr = perturb(Xr, cellsR, rng.randint(1, 3))
        if not W.R(cellsR, Xr, Yr):
            continue
        for _ in range(4):
            Zr = perturb(Yr, cellsR, rng.randint(1, 3))
            if not W.R(cellsR, Yr, Zr):
                continue
            chains += 1                                  # X R Y and Y R Z
            if W.R(cellsR, Zr, Xr):
                back += 1
                if not W.R(cellsR, Xr, Zr):
                    viol += 1                            # Z strictly better than X: TC violation
                if Xr != Yr and Yr != Zr and Zr != Xr:
                    cyc_found += 1
                    if not (W.R(cellsR, Yr, Xr) and W.R(cellsR, Zr, Yr) and W.R(cellsR, Xr, Zr)):
                        strictcyc += 1
print('  chains X R Y R Z:', chains, ' of which Z R X:', back, ' TC violations:', viol,
      ' 3-cycles of distinct models:', cyc_found, ' with a strict edge:', strictcyc)
check('N1+N2 worlds: no TC violation; every accepted 3-cycle consists of ties', back > 0 and viol == 0 and strictcyc == 0)

# random worlds with a positive cycle: the pump always works
pumps = 0
for trial in range(25):
    L = rng.choice([1, 2, 3, 4, 5])
    nodes = rng.sample(NOD5, L)
    rates = {}
    for k in range(L):
        rates[(nodes[k], nodes[(k + 1) % L])] = Fr(rng.randint(1, 5), rng.randint(1, 5))
    p = Fr(1)
    for v in rates.values():
        p *= v
    if p <= 1:
        first = (nodes[0], nodes[1 % L])
        rates[first] *= (2 / p)
    E = dict(rates)
    for n in NOD5:
        if rng.random() < 0.5:
            E.setdefault((n, n), Fr(1))
    W = RungWorld(1, E)
    cP, XP, YP, ZP, _ = build_pump(1, nodes, rates, tag='r')
    if W.R(cP, XP, YP) and W.R(cP, YP, ZP) and pointwise_better(1, cP, ZP, XP) and not W.R(cP, XP, ZP):
        pumps += 1
print('  random positive cycles (lengths 1..5) pumped:', pumps, 'of 25')
check('every random positive cycle yields a TC-violating pump', pumps == 25)

# random N1 worlds violating N2: tight cycle of length >= 3 whose first edge lacks its exact reverse
n2fail = 0
for trial in range(20):
    L = rng.choice([3, 4, 5])
    nodes = rng.sample(NOD5, L)
    phi = {n: Fr(rng.randint(1, 6)) for n in NOD5}
    rates = {(nodes[k], nodes[(k + 1) % L]): phi[nodes[k]] / phi[nodes[(k + 1) % L]] for k in range(L)}
    E = dict(rates)
    for (a, b) in list(rates)[1:]:
        E[(b, a)] = phi[b] / phi[a]                          # exact reverses except for the first edge
    a0, b0 = nodes[0], nodes[1]
    if rng.random() < 0.5:
        E[(b0, a0)] = phi[b0] / phi[a0] * Fr(rng.randint(1, 4), 5)   # a strictly weaker reverse
    W = RungWorld(1, E)
    c3, X3r, Y3r, Z3r = build_tc3(1, nodes, rates, tag='z')
    if W.R(c3, X3r, Y3r) and W.R(c3, Y3r, Z3r) and W.R(c3, Z3r, X3r) and not W.R(c3, X3r, Z3r):
        n2fail += 1
print('  random tight cycles with one deficient reverse: TC violated in', n2fail, 'of 20')
check('every random N2-violation yields a 3-record TC violation', n2fail == 20)

# ---------------------------------------------------------------- 6. experimental target in miniature
print('\n=== 6. Certificate out of K* (selected) and K\' (nested, coherent), exchange-supplied defence ===')
KS, KP = (Fr(1, 3), Fr(2, 3)), (Fr(2, 5), Fr(3, 5))
for s in ['A1', 'A2', 'B1', 'B2']:
    lo, hi = SECT[s]
    print('  sector', s, (lo, hi), " K* advice:", interval_advice(*KS, lo, hi), " K' advice:", interval_advice(*KP, lo, hi))
check("K* silent on A1,A2,B1,B2; K' + on A1,A2 and - on B1,B2",
      all(interval_advice(*KS, *SECT[s]) == '0' for s in ['A1', 'A2', 'B1', 'B2'])
      and all(interval_advice(*KP, *SECT[s]) == '+' for s in ['A1', 'A2'])
      and all(interval_advice(*KP, *SECT[s]) == '-' for s in ['B1', 'B2']))
# cells (units of a small scale s)
# a1 (mass 10) is split into a1x (8) and a1y (2) so that R'_1 acts on a sub-piece
cellsC = [Cell('a1x', 'A1', 8), Cell('a1y', 'A1', 2), Cell('a2', 'A2', 6), Cell('b1', 'B1', 8), Cell('b2', 'B2', 5)]
Kstar = {'a1x': '0', 'a1y': '0', 'a2': '0', 'b1': '0', 'b2': '0'}
Kpr = {'a1x': '+', 'a1y': '+', 'a2': '+', 'b1': '-', 'b2': '-'}
X1 = dict(Kstar, a2='+', b1='-')                 # R*_1: B1 pays A2
X2 = dict(Kstar, a1x='+', a1y='+', b2='-')       # R*_2: B2 pays A1 at rate 2
Y1 = dict(Kpr, a1x='0', b1='0')                  # R'_1: A1 pays B1
Y2 = dict(Kpr, a2='0', b2='0')                   # R'_2: A2 pays B2
for nm, C, Xm in [('R*_1', Kstar, X1), ('R*_2', Kstar, X2), ("R'_1", Kpr, Y1), ("R'_2", Kpr, Y2)]:
    g, l = record(1, cellsC, C, Xm)
    acc, cert = W1.accept_record(g, l)
    print('  ', nm, 'gains', g, 'losses', l, '-> accepted' if acc else '-> rejected', cert)
    check(nm + ' accepted at world 1', acc)
check('combination of the four records is worsening-free and nonzero (certificate)',
      worsening_free(1, cellsC, [(1, Kstar, X1), (1, Kstar, X2), (1, Kpr, Y1), (1, Kpr, Y2)]))
check('R*_1: world 1 strict (K* <1 X1), world 2 does NOT defend (X1 <2 K*)',
      W1.strict(cellsC, Kstar, X1) and W2.strict(cellsC, X1, Kstar))
check('R*_2: world 2 defends K* against X2 strictly', W2.strict(cellsC, Kstar, X2))
Xm = dict(Kstar, a1x='+', a1y='+', a2='+', b1='-', b2='-')   # merged rival
check('merged rival: tied with K* at world 1 (convexity lemma), K* strictly better at world 2',
      W1.R(cellsC, Kstar, Xm) and W1.R(cellsC, Xm, Kstar) and W2.strict(cellsC, Kstar, Xm))
# region-wise (product) test at world 1 would reject R*_1: on the A-region alone X1 only gains
cA = [c for c in cellsC if c.sector in ('A1', 'A2')]
check('a region-by-region world 1 rejects K* vs X1 on region A (compensation across regions is essential)',
      not W1.R(cA, Kstar, X1))
# the same records, re-sited out of incoherent bases, compose into a pump
cP, XP, YP, ZP, _ = build_pump(1, CYCLE, RATES, tag='s')
check('the same exchanges re-sited form a pump: X R1 Y R1 Z with Z strictly better than X',
      W1.R(cP, XP, YP) and W1.R(cP, YP, ZP) and pointwise_better(1, cP, ZP, XP))

# ---------------------------------------------------------------- 7. transition types: ladder triangle
print('\n=== 7. Transition types (not rung-decomposed): ladder triangle ===')


class TransWorld:
    """types (sector, old rank, new rank); size = steps x mass; edges loss-type -> gain-type."""

    def __init__(self, edges):
        self.E = {k: Fr(v) for k, v in edges.items()}

    def R(self, cells, C, X):
        g, l = {}, {}
        for c in cells:
            a, b = rank(1, True, C[c.name]), rank(1, True, X[c.name])
            if a == b:
                continue
            d = g if b < a else l
            d[(c.sector, a, b)] = d.get((c.sector, a, b), 0) + abs(a - b) * c.mass
        return RungWorld(1, self.E).accept_record(g, l)[0]


aL, bL, cL = ('S', 0, 1), ('S', 1, 2), ('S', 0, 2)
aG, bG, cG = ('S', 1, 0), ('S', 2, 1), ('S', 2, 0)
cellsL = [Cell('A', 'S', 1), Cell('B', 'S', 1), Cell('C', 'S', 1)]
XL = {'A': '+', 'B': '0', 'C': '-'}
YL = {'A': '0', 'B': '-', 'C': '+'}
ZL = {'A': '-', 'B': '+', 'C': '0'}
for kap in [Fr(1), Fr(3, 2)]:
    for r in [None, Fr(1, 2), Fr(2, 3)]:
        E = {(aL, cG): kap, (bL, cG): kap}
        if r is not None:
            E[(cL, aG)] = r; E[(cL, bG)] = r
        T = TransWorld(E)
        res = T.R(cellsL, XL, YL) and T.R(cellsL, YL, ZL) and T.R(cellsL, ZL, XL) and not T.R(cellsL, XL, ZL)
        check('kappa=%s, reverse rate %s (pair-graph products <= 1): ladder 3-cycle violates TC' % (kap, r), res)

# ---------------------------------------------------------------- 8. interval family
print('\n=== 8. Interval models: crossing <=> strictly nested; the chosen family is comonotone ===')
grid = [Fr(k, 10) for k in range(11)]
cuts = sorted({-(a / (1 - a)) for a in grid if a < 1}, reverse=True)
secs = []
prev = Fr(0)
for c in cuts:
    if c < prev:
        secs.append((c, prev)); prev = c
secs.append((None, prev))
cellsI = [Cell('i%d' % k, 'I%d' % k, 1) for k in range(len(secs))]


def model(a, b):
    return {'i%d' % k: interval_advice(a, b, lo, hi) for k, (lo, hi) in enumerate(secs)}


bad = 0
pairs = [(a, b) for a in grid for b in grid if a <= b]
for (a, b) in pairs:
    for (c, d) in pairs:
        M, N = model(a, b), model(c, d)
        assert 'straddle' not in M.values()
        rk = lambda Mo: [rank(1, True, Mo[c_.name]) for c_ in cellsI]
        cross = any(x < y for x, y in zip(rk(M), rk(N))) and any(x > y for x, y in zip(rk(M), rk(N)))
        nested = (a < c and d < b) or (c < a and b < d)
        bad += (cross != nested)
check('on the 66x66 grid of intervals: cross at world 1 <=> strictly nested', bad == 0)
fam = lambda s: (s - Fr(2, 3) * s * (1 - s), s + Fr(2, 3) * s * (1 - s))
S = [Fr(k, 40) for k in range(41)]
check('family [s - 2s(1-s)/3, s + 2s(1-s)/3]: K at s=1/2 is [1/3,2/3], vertices precise',
      fam(Fr(1, 2)) == (Fr(1, 3), Fr(2, 3)) and fam(Fr(0)) == (0, 0) and fam(Fr(1)) == (1, 1))
check('family endpoints strictly increasing on the grid (comonotone: no crossing pair)',
      all(fam(S[k])[0] < fam(S[k + 1])[0] and fam(S[k])[1] < fam(S[k + 1])[1] for k in range(40)))

# ---------------------------------------------------------------- 9. S1: no potential on E1
print('\n=== 9. S1: no positive potential for world 1 of the instance ===')
# potential phi: kappa(n,n') phi(n') <= phi(n) on all edges. Around the cycle: phi(n1) >= phi(n2) >= phi(n3) >= phi(n4) >= 2 phi(n1)
from lpexact import feasible
nodes = CYCLE
A, b = [], []
for (a_, c_), k in RATES.items():
    row = [Fr(0)] * 4
    row[nodes.index(c_)] += k
    row[nodes.index(a_)] -= 1
    A.append(row); b.append(Fr(0))
for j in range(4):
    row = [Fr(0)] * 4; row[j] = Fr(-1); A.append(row); b.append(Fr(-1))   # phi >= 1
check('LP {phi >= 1, kappa phi(n2) <= phi(n1) on cycle edges} infeasible', feasible(A, b) is None)

# ---------------------------------------------------------------- 10. S5 swaps
print('\n=== 10. S5: swap rivals ===')
# boundary of the selected model at the sector boundary -7/12 between A1 and A2
cellsS = [Cell('G', 'A1', 1), Cell('Lc', 'A2', 2)]
M = {'G': '0', 'Lc': '+'}
Xs = {'G': '+', 'Lc': '0'}
check('swap across the A1|A2 boundary: neither world defends M (world 1 has no A2->A1 exchange)',
      not W1.R(cellsS, M, Xs) and not W2.R(cellsS, M, Xs))
cellsS2 = [Cell('G', 'A2', 1), Cell('Lc', 'A2', 1)]
ok_in = all((W1.R([Cell('G', 'A2', p), Cell('Lc', 'A2', q)], M, Xs) or W2.R([Cell('G', 'A2', p), Cell('Lc', 'A2', q)], M, Xs))
            for p in range(1, 6) for q in range(1, 6))
check('swap inside one sector (self-loop rate 1 at world 1, additive world 2): always defended by sign', ok_in)
Elossy = dict(E1); Elossy[(n3, n3)] = Fr(1, 2)
check('lossy self-loop (rate 1/2): an equal-mass swap inside A2 is rejected at world 1',
      not RungWorld(1, Elossy).R(cellsS2, M, Xs))

# ---------------------------------------------------------------- 11. the four-state window
print('\n=== 11. Transition types on the four-state ladder: arbitrage only through contradiction ===')
def window(kap, sectors=('S',)):
    E = {}
    for s1 in sectors:
        for r in range(3):
            for s2 in sectors:
                E[((s1, r, r + 1), (s2, 3, 0))] = Fr(kap)
    return TransWorld(E)


ADV4 = ['+', '0', '-', 'x']
Tw = window(2, ('S', 'T'))
cellsW = [Cell('w%d' % k, 'S' if k < 3 else 'T', rng.randint(1, 3)) for k in range(6)]


def perturb4(M, k):
    M2 = dict(M)
    for c in rng.sample(cellsW, k):
        cur = M2[c.name]
        M2[c.name] = '+' if (cur == 'x' and rng.random() < 0.6) else rng.choice(ADV4)
    return M2


chains4 = cyc4 = viol4 = ties4 = 0
for _ in range(6000):
    Xw = {c.name: rng.choice(ADV4) for c in cellsW}
    Yw = perturb4(Xw, rng.randint(1, 4))
    if Xw != Yw and Tw.R(cellsW, Xw, Yw) and Tw.R(cellsW, Yw, Xw):
        ties4 += 1
    if not Tw.R(cellsW, Xw, Yw):
        continue
    for _ in range(3):
        Zw = perturb4(Yw, rng.randint(1, 4))
        if Tw.R(cellsW, Yw, Zw):
            chains4 += 1
            if Tw.R(cellsW, Zw, Xw) and len({str(Xw), str(Yw), str(Zw)}) == 3:
                cyc4 += 1
            if Tw.R(cellsW, Zw, Xw) and not Tw.R(cellsW, Xw, Zw):
                viol4 += 1
print('  kappa=2: chains', chains4, ' nontrivial 3-cycles', cyc4, ' TC violations', viol4, ' nontrivial ties', ties4)
check('kappa=2 window: no TC violation, no 3-cycle of distinct models, no nontrivial tie (random exact)',
      chains4 > 0 and cyc4 == 0 and viol4 == 0 and ties4 == 0)
# strict 4-cycle and a 4-record certificate (kappa = 2)
Tw1 = window(2)
cells4 = [Cell('P%d' % j, 'S', 1) for j in range(4)] + [Cell('E', 'S', 1)]
seq = ['x', '+', '0', '-']          # ranks 3,0,1,2: at P_j the model X_k has state seq[(k - j) % 4]
Xs = [{('P%d' % j): seq[(k - j) % 4] for j in range(4)} for k in range(4)]
for k in range(4):
    Xs[k]['E'] = 'x'
cyc_ok = all(Tw1.R(cells4, Xs[k], Xs[(k + 1) % 4]) and not Tw1.R(cells4, Xs[(k + 1) % 4], Xs[k]) for k in range(4))
check('kappa=2 window: strict 4-cycle X0 R X1 R X2 R X3 R X0 (every reverse rejected)', cyc_ok)
X4 = dict(Xs[0]); X4['E'] = '+'
recs = [(1, Xs[0], Xs[1]), (1, Xs[1], Xs[2]), (1, Xs[2], Xs[3]), (1, Xs[3], X4)]
check('kappa=2 window: the four records (last one also clears x on E) are accepted and form a certificate',
      all(Tw1.R(cells4, C, X) for _, C, X in recs) and worsening_free(1, cells4, recs))
# threshold: at kappa = 3 a 3-cycle through 0 -> 1 -> 3 -> 0 violates TC
Tw3 = window(3)
c3 = [Cell('Q%d' % j, 'S', 1) for j in range(3)]
s3 = ['+', '0', 'x']
Xq = [{('Q%d' % j): s3[(k - j) % 3] for j in range(3)} for k in range(3)]
check('kappa=3: X R Y R Z R X with not X R Z (window closes exactly at kappa = 3)',
      Tw3.R(c3, Xq[0], Xq[1]) and Tw3.R(c3, Xq[1], Xq[2]) and Tw3.R(c3, Xq[2], Xq[0]) and not Tw3.R(c3, Xq[0], Xq[2]))
check('kappa=2.9: the same three records are not all accepted',
      not (window(Fr(29, 10)).R(c3, Xq[0], Xq[1]) and window(Fr(29, 10)).R(c3, Xq[1], Xq[2])
           and window(Fr(29, 10)).R(c3, Xq[2], Xq[0])))

print('\nALL CHECKS PASSED' if OK else '\nSOME CHECK FAILED')
