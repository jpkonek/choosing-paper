# SCREEN_A: exact checks of the measure-version median lemma (SCREEN_A Lemma 2.2, 1-D core)
# Run: python3 -I quantile_check.py      (all arithmetic exact: Fractions)
#
# One-dimensional form.  P, Q = laws of the projected normalised profiles f(a^) at two worlds.
# Blocking mass beta (= 1 - theta).  The judge space is atomless, so a blocking set may take
# any part of an atom of P.  "Separated" means: there are A, B with pi(A) > beta, nu(B) > beta
# and every A-value > every B-value (or the reverse).  Extreme A for a lower bound x is {>= x}.
#
# Claim (PROVED in note): not separated  <=>  exists c with P(<c),P(>c),Q(<c),Q(>c) all <= beta,
# and then P{c} >= 1-2beta, Q{c} >= 1-2beta; c unique if beta < 1/3.
from fractions import Fraction as Fr
import random

ok = True
random.seed(20261019)

def mass(D, pred):
    return sum((w for x, w in D.items() if pred(x)), Fr(0))

def separated(P, Q, beta):
    for x in P:
        for y in Q:
            if x > y and mass(P, lambda s: s >= x) > beta and mass(Q, lambda s: s <= y) > beta:
                return True
            if y > x and mass(Q, lambda s: s >= y) > beta and mass(P, lambda s: s <= x) > beta:
                return True
    return False

def deep_points(P, Q, beta):
    cands = set(P) | set(Q)
    out = []
    for c in cands:
        if all(m <= beta for m in (mass(P, lambda s: s < c), mass(P, lambda s: s > c),
                                   mass(Q, lambda s: s < c), mass(Q, lambda s: s > c))):
            out.append(c)
    return out

def rand_dist(G, natoms, den):
    xs = random.sample(range(G), natoms)
    cuts = sorted(random.sample(range(1, den), natoms - 1))
    ws = [b - a for a, b in zip([0] + cuts, cuts + [den])]
    return {Fr(x): Fr(w, den) for x, w in zip(xs, ws)}

print("Part 1: random weighted 1-D instances (atomless judge space, atomic profile law)")
for beta in [Fr(1, 5), Fr(1, 4), Fr(3, 10), Fr(1, 3) - Fr(1, 100), Fr(2, 5)]:
    tot = 0; nsep = 0
    for trial in range(4000):
        G = random.choice([3, 4, 5, 6])
        P = rand_dist(G, random.randint(1, min(G, 4)), 20)
        Q = rand_dist(G, random.randint(1, min(G, 4)), 20)
        # bias some trials towards a big common atom
        if trial % 3 == 0:
            c = Fr(random.randrange(G))
            big = Fr(random.randint(10, 20), 20)
            P = {x: w * (1 - big) for x, w in P.items()}; P[c] = P.get(c, 0) + big
            Q = {x: w * (1 - big) for x, w in Q.items()}; Q[c] = Q.get(c, 0) + big
        s = separated(P, Q, beta)
        dp = deep_points(P, Q, beta)
        if s == bool(dp):
            ok = False; print("  criterion mismatch", beta, P, Q)
        if not s:
            for c in dp:
                if P.get(c, 0) < 1 - 2 * beta or Q.get(c, 0) < 1 - 2 * beta:
                    ok = False; print("  atom too small", beta, P, Q, c)
            if beta < Fr(1, 3) and len(dp) != 1:
                ok = False; print("  non-unique deep point", beta, P, Q, dp)
        tot += 1; nsep += s
    print(f"  beta={beta}: {tot} instances, {tot-nsep} unseparated, all with common atom >= 1-2beta")

print("Part 2: atomless profile laws are always separated (explicit t)")
# P uniform on [a,b], Q uniform on [c,d] (nondegenerate).  Take t = midpoint of the overlap of
# medians: with t = (median P + median Q)/2 one of the two orientations separates when beta < 1/2.
def unif_cdf_lt(a, b, t):  # P(< t) for U[a,b]
    if t <= a: return Fr(0)
    if t >= b: return Fr(1)
    return (t - a) / (b - a)
for (a, b, c, d) in [(0, 1, 0, 1), (0, 1, Fr(1, 2), 2), (1, 2, 1, 3), (0, 1, Fr(9, 10), Fr(11, 10))]:
    a, b, c, d = map(Fr, (a, b, c, d))
    mP = (a + b) / 2; mQ = (c + d) / 2
    t = mP if mP == mQ else (mP + mQ) / 2
    # orientation 1: P above t, Q below t ; orientation 2: P below, Q above
    o1 = (1 - unif_cdf_lt(a, b, t), unif_cdf_lt(c, d, t))
    o2 = (unif_cdf_lt(a, b, t), 1 - unif_cdf_lt(c, d, t))
    best = max(min(o1), min(o2))
    print(f"  P=U[{a},{b}] Q=U[{c},{d}] t={t}: blocking masses available = {best}")
    if not best >= Fr(1, 2):
        ok = False; print("  FAIL")
# arc example: profiles a^(s) = (1, 1 + (1-s^2)/(2(1+s^2)), 1 + s/(1+s^2)), s ~ U[-1,1] at both worlds.
# f = third coordinate is strictly increasing in s on [-1,1]; t = f(a^(0)) = 1.
f = lambda s: 1 + s / (1 + s * s)
grid = [Fr(k, 50) for k in range(-50, 51)]
mono = all(f(grid[i]) < f(grid[i + 1]) for i in range(len(grid) - 1))
print(f"  arc example: f strictly increasing on grid: {mono}; P(f>1)=Q(f<1)=1/2 > beta for every theta>1/2")
ok &= mono

print("ALL CHECKS PASSED" if ok else "SOME CHECK FAILED")
