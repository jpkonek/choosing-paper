# SCREEN_A Q3: exact rival defeating (QS_theta) at D_K, K = {m in Delta_2 : m_1 in [al, be]},
# for continuum judge families whose boundary switch-ratio law has no deep common atom.
# Run: python3 -I dkstar_rival.py        (exact Fractions; the problem space is the circle of
# directions g in R^2 modulo +-, with the Gaussian measure = uniform in angle, so sector masses
# are free parameters and are taken rational.)
from fractions import Fraction as Fr

ok = True

def in_D(g, al, be):
    return al * g[0] + (1 - al) * g[1] >= 0 and be * g[0] + (1 - be) * g[1] >= 0

def advice_C(g, al, be):          # coherent model D_K on problem {g,-g}, representative g
    if in_D(g, al, be): return '+'
    if in_D((-g[0], -g[1]), al, be): return '-'
    return '0'

def rank(adv, g, i):              # world i (0 or 1): good 0 < silence 1 < bad 2 < contradiction 3
    if adv == '0': return 1
    if adv == 'x': return 3
    s = g[i] if adv == '+' else -g[i]
    return 0 if s > 0 else 2

def rot(g, e):                    # tiny exact "rotation" (shear towards the normal); e>0 = anticlockwise
    return (g[0] - e * g[1], g[1] + e * g[0])

def setup(al, be):
    R1 = (1 - al, -al)            # boundary ray of D_K on which al*g1+(1-al)*g2 = 0
    R2 = (-(1 - be), be)          # boundary ray on which be*g1+(1-be)*g2 = 0
    e = Fr(1, 1000)
    # outside points next to each ray, and inside points
    o1, i1 = rot(R1, -e), rot(R1, e)
    o2, i2 = rot(R2, e), rot(R2, -e)
    return R1, R2, (o1, i1), (o2, i2)

def increments(al, be):
    """Rank increments (world1, world2) of switching C's advice to '+' just outside each ray."""
    R1, R2, (o1, i1), (o2, i2) = setup(al, be)
    res = {}
    for name, (o, i) in (('R1', (o1, i1)), ('R2', (o2, i2))):
        a_out, a_in = advice_C(o, al, be), advice_C(i, al, be)
        assert a_in == '+' and a_out == '0', (name, a_in, a_out)
        res[name] = tuple(rank('+', o, w) - rank('0', o, w) for w in (0, 1))
    return res

# judge families: kappa_iv = 1 on a neighbourhood of R1, = rho_i(v) on a neighbourhood of R2.
# rho laws are pushforwards of U[0,1]; atomless.
families = {
    'same U[1,2]':           (lambda v: 1 + v,          lambda u: 1 + u),
    'different laws':        (lambda v: 1 + v * v,      lambda u: Fr(3, 2) + u / 2),
    'world2 nearly constant':(lambda v: 1 + v,          lambda u: Fr(7, 4) + u / 1000),
}

def median_of(rho):   # rho increasing on [0,1] -> median = rho(1/2)
    return rho(Fr(1, 2))

def mass_le(rho, t, N=2000):     # exact for monotone rho via bisection on rationals (monotone => interval)
    lo, hi = Fr(0), Fr(1)
    if rho(Fr(0)) > t: return Fr(0)
    if rho(Fr(1)) <= t: return Fr(1)
    for _ in range(60):
        mid = (lo + hi) / 2
        if rho(mid) <= t: lo = mid
        else: hi = mid
    return lo   # lower bound accurate to 2^-60

def mass_ge(rho, t):             # lower bound on U[0,1]{u : rho(u) >= t}, rho increasing
    if rho(Fr(0)) >= t: return Fr(1)
    if rho(Fr(1)) < t: return Fr(0)
    lo, hi = Fr(0), Fr(1)        # invariant rho(lo) < t <= rho(hi)
    for _ in range(60):
        mid = (lo + hi) / 2
        if rho(mid) >= t: hi = mid
        else: lo = mid
    return 1 - hi

for (al, be) in [(Fr(1, 3), Fr(2, 3)), (Fr(3, 10), Fr(7, 10)), (Fr(2, 5), Fr(3, 5)), (Fr(1, 4), Fr(1, 2)), (Fr(1, 3), Fr(1, 2))]:
    inc = increments(al, be)
    # expected: R1 outside, 0 -> '+': world1 -1, world2 +1 ; R2 outside: world1 +1, world2 -1
    if inc != {'R1': (-1, 1), 'R2': (1, -1)}:
        ok = False; print("unexpected increments", al, be, inc)
    print(f"K = [{al},{be}]: rank increments of 0->+ outside R1 = {inc['R1']}, outside R2 = {inc['R2']}")
    for fname, (r1, r2) in families.items():
        m = Fr(1, 10**6)                       # base sector mass (any small value)
        t = (median_of(r1) + median_of(r2)) / 2
        m1, m2 = t * m, m                      # masses of the two thin sectors
        D1 = lambda v: m1 * 1 * inc['R1'][0] + m2 * r1(v) * inc['R2'][0]   # world-1 judge v: L(X)-L(C)
        D2 = lambda u: m1 * 1 * inc['R1'][1] + m2 * r2(u) * inc['R2'][1]
        # world 1: D1 <= 0 iff r1(v) <= t ; world 2: D2 <= 0 iff r2(u) >= t
        A = mass_le(r1, t)                     # pi_1{rho_1 <= t}
        B = mass_ge(r2, t)                     # nu{rho_2 >= t}  (lower bound)
        # exact sign checks on a grid
        grid = [Fr(k, 200) for k in range(201)]
        g1 = all((D1(v) <= 0) == (r1(v) <= t) for v in grid)
        g2 = all((D2(u) <= 0) == (r2(u) >= t) for u in grid)
        okfam = g1 and g2 and A > Fr(1, 3) and B > Fr(1, 3)
        # orientation swap if needed (median of world 1 above world 2): use reverse rival
        print(f"   {fname:24s} t={float(t):.4f}: pi1{{Delta<=0}}>={float(A):.4f}, pi2{{Delta<=0}}>={float(B):.4f}"
              f"  -> X defeats (QS_theta) for every theta > {float(1-min(A,B)):.4f}; both > 1/3 (so all theta in (2/3,1)): {okfam}")
        ok &= okfam

print("ALL CHECKS PASSED" if ok else "SOME CHECK FAILED")
