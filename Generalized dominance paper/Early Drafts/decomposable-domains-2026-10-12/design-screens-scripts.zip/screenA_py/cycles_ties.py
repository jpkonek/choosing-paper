# SCREEN_A Q1: continuum Nakamura number, explicit strict k-cycles, and the mass-slack counterexample
# to a verbatim strict-sign lifting lemma.  Run: python3 -I cycles_ties.py   (exact Fractions)
from fractions import Fraction as Fr
from math import ceil

ok = True

def psi_half(s): return s / 2                 # a lifting-type margin: 0 < psi(s) <= s/2
def psi_quad(s): return s * s / (1 + s)       # psi(s)/s -> 0

def supports(xs_from, xs_to, psi):
    """judge supports 'A no worse than B' iff L(B)-L(A) >= psi(d).  Models differ only on cells;
    A has silence (rank 1) on its own cell, good elsewhere; so L = cell mass of own cell."""
    LA, LB = xs_from, xs_to
    d = xs_from + xs_to
    return LB - LA >= psi(d)

print("Part 1: strict k-cycles for a continuum of judges, k = nu(theta) = ceil(1/(1-theta))")
for theta in [Fr(7, 10), Fr(3, 4), Fr(4, 5), Fr(9, 10), Fr(2, 3) + Fr(1, 1000)]:
    nu = ceil(1 / (1 - theta))
    for psi in (psi_half, psi_quad):
        k = nu
        # judge classes G_0..G_{k-1}, each of pi-mass 1/k <= 1-theta (judge space atomless: any split works)
        cls = Fr(1, k)
        assert cls <= 1 - theta
        R = Fr(3); scale = Fr(1, 10 * 3 ** k)   # all cell masses small (psi_quad ~ s^2 there)
        # judge in class j: mass of cell F_m = scale * R^((m - j - 1) mod k)
        def x(j, m): return scale * R ** ((m - j - 1) % k)
        good = True
        for m in range(k):                        # edge  A_m  R  A_{m+1}
            n = (m + 1) % k
            sup = sum((cls for j in range(k) if supports(x(j, m), x(j, n), psi)), Fr(0))
            rev = sum((cls for j in range(k) if supports(x(j, n), x(j, m), psi)), Fr(0))
            if not (sup >= theta and rev < theta):
                good = False
        print(f"  theta={theta}, psi={psi.__name__}: nu={k}; strict {k}-cycle realised: {good}")
        ok &= good
    # necessity: a cycle of length k needs k sets of mass >= theta with null intersection => k(1-theta) >= 1
    for k in range(2, nu):
        if k * (1 - theta) >= 1:
            ok = False; print("  counting error", theta, k)
print("  (no cycle of length < nu: k sets of mass >= theta have intersection mass >= 1 - k(1-theta) > 0)")

print("Part 2: no ties / TC are mass counts")
for theta in [Fr(7, 10), Fr(3, 4), Fr(9, 10)]:
    print(f"  theta={theta}: two supporting sets overlap in mass >= {2*theta-1} > 0; three in >= {3*theta-2} > 0")
    ok &= (2 * theta - 1 > 0) and (3 * theta - 2 > 0)

print("Part 3: strict signs at exactly theta do not lift to any positive margin (one comparison)")
# One world, two cells: P (C better there: improvement for X? no) -- record C -> X:
# X worsens on cell W (mass w_v) and improves on cell I (mass i_v); rank steps 1.
# Judge v in [0,1] (uniform): W_v = 1, I_v = 1 - (v - (1-theta)) ... Delta_v = W_v - I_v = v - (1-theta).
theta = Fr(3, 4)
def W(v): return Fr(1)
def I(v): return 1 - (v - (1 - theta))
def Delta(v): return W(v) - I(v)
def d(v): return W(v) + I(v)
# pi{Delta > 0} = pi{v > 1-theta} = theta exactly  (strict-sign super-majority holds, with no slack)
grid = [Fr(k, 1000) for k in range(1001)]
strict_mass = Fr(sum(1 for v in grid[1:] if Delta(v) > 0), 1000)   # Riemann count of (0,1]
print(f"  pi{{Delta>0}} = theta = {theta} (grid count {strict_mass})")
for name, psi in (("s/2", psi_half), ("s^2/(1+s)", psi_quad), ("s/10^6", lambda s: s / 10**6)):
    # v -> Delta(v) - psi(d(v)) is strictly increasing (Delta up, d down, psi nondecreasing); its zero v* is
    # strictly above 1-theta because psi(d) > 0.  Supporter mass = 1 - v* < theta.  Bisection, exact rationals.
    lo, hi = 1 - theta, Fr(1)
    assert Delta(lo) - psi(d(lo)) < 0 and Delta(hi) - psi(d(hi)) >= 0
    for _ in range(80):
        mid = (lo + hi) / 2
        if Delta(mid) - psi(d(mid)) >= 0: hi = mid
        else: lo = mid
    sup = 1 - hi                     # supporter mass is <= 1 - lo; report upper bound
    upper = 1 - lo
    print(f"  margin psi={name}: supporter mass <= {float(upper):.10f} < theta: {upper < theta}")
    ok &= upper < theta
print("ALL CHECKS PASSED" if ok else "SOME CHECK FAILED")
