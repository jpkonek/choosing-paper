# Referee copy of PP11_py/t2_threshold.py, unchanged except that output goes to REFEREE_PP11_py/.
"""PP11 t2: exact check of Theorem J (forced allocation jump) on the pump geometry.

Family: X_k = C_a with A on G_1(k) u G_2(k), G_1(k) = shrunk(cone_1, t_k) (class M_1) DEcreasing in k,
G_2(k) = shrunk(cone_2, s_k) (class M_2) INcreasing in k; k = 0..n, G_2(0) = G_1(n) = empty.
d_k = rec(X_k, C_a) (A -> S on G(k)).  Pool = {C_a, C_q} + family, closed under splicing.

Checks, all on the most-permissive SAT instance (axioms only):
  (a) every d_k (0<k<n) has the edge face (0,1) among the faces met by A(d_k)       [geometry, exact]
  (b) assume d_k in R_1 and d_k in R_2  -> UNSAT; deletion-minimal core printed      [Theorem J, part 1]
  (c) assume d_j in R_1 and d_k in R_2 with j < k (non-threshold pattern) -> UNSAT for k >= j+2; core printed
                                                                                     [Theorem J, part 2]
  (d) every threshold position is realisable: for each m, assume d_k in R_2 (k<m) and d_k in R_1 (k>=m) -> SAT
  (e) the instance itself is SAT, re-verified by the independent checker."""
import sys, os, time
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, '..', 'PP11_py'))
from modules import *
import pp11sat as S

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def family(geo, n=5):
    ts = [F(n - k, n) for k in range(n + 1)]          # 1, (n-1)/n, ..., 0
    ss = [F(k, n) for k in range(n + 1)]              # 0, 1/n, ..., 1
    c1, c2 = geo['cones'][0], geo['cones'][1]
    ms = []
    for k in range(n + 1):
        ov = []
        if ts[k] > 0:
            r = c1 if ts[k] == 1 else shrunk(c1, ts[k]); ov.append((r, adv(r, 'A')))
        if ss[k] > 0:
            r = c2 if ss[k] == 1 else shrunk(c2, ss[k]); ov.append((r, adv(r, 'A')))
        ms.append(Model(geo['a'], geo['eps'], ov, name='X%d' % k))
    return ms

def label(lab, P):
    t = lab[0]
    if t == 'UND': return 'UND: C_a undominated vs %s' % P.names[lab[2]] if P.names[lab[1]] == 'C_a' else 'UND(%s vs %s)' % (P.names[lab[1]], P.names[lab[2]])
    if t == 'OBL': return 'OBL: %s faces %s' % (S.describe_rec(P, lab[1]), [tuple(i+1 for i in I) for I in [lab[2]]])
    if t == 'TC': return 'TC world %d on (%s, %s, %s)' % (lab[1]+1, P.names[lab[2]], P.names[lab[3]], P.names[lab[4]])
    if t == 'DC': return 'DC(%s,%s)' % (P.names[lab[1]], P.names[lab[2]])
    return str(lab)

def run(key, n=5):
    geo = pump_geometry(key)
    fam = family(geo, n)
    ms = dedup([geo['Ca'], geo['Cq']] + fam)
    P, closed = build_pool(ms, geo['eps'], close=True, cap=300, log=lambda *a: None)
    inc = incoherence_map(P)
    I = S.Inst(P, incoh=inc, log=lambda *a: None)
    ia = P.names.index('C_a')
    idx = [P.names.index('X%d' % k) for k in range(n + 1)]
    d = [P.recmat[x, ia] for x in idx]
    pr('\n=== %s: pool %d models (closed %s), %d records, %d clause groups' % (key, P.N, closed, P.R, len(I.groups)))
    # (a) faces
    ok_a = all((0, 1) in P.faces[d[k]] for k in range(1, n))
    pr('(a) every interior d_k has the edge face Delta_12:', ok_a, '; faces d_0', P.faces[d[0]], 'd_n', P.faces[d[n]])
    pr('    (G) at the ends: d_0 world1/2/3 guidance', P.G[d[0]].astype(int), 'strict-forbidden', P.G[P.rev[d[0]]].astype(int),
       '; d_n', P.G[d[n]].astype(int), P.G[P.rev[d[n]]].astype(int))
    v = I.var
    ok, model = I.solve()
    pr('(e) instance SAT:', ok, '; independent check', S.check(P, model, incoh=inc) if ok else None)
    # (b)
    res_b = []
    for k in range(1, n):
        c = I.core([v(d[k], 0), v(d[k], 1)])
        res_b.append(c is not None)
        if k == 1 and c is not None:
            pr('(b) assume d_1 in R_1 and R_2: UNSAT; deletion-minimal core (axiom instances; (G) units are built in):')
            for lab in c: pr('      ', label(lab, P))
    pr('(b) UNSAT for every interior k:', all(res_b), res_b)
    # (c)
    res_c = {}
    shown = False
    gref = []
    for j in range(0, n + 1):
        for k in range(j + 1, n + 1):
            if I.fix.get(v(d[j], 0)) is False or I.fix.get(v(d[k], 1)) is False:
                gref.append((j, k)); continue
            c = I.core([v(d[j], 0), v(d[k], 1)], minimize=(not shown and k >= j + 2))
            res_c[(j, k)] = (c is not None)
            if c is not None and not shown and k >= j + 2:
                shown = True
                pr('(c) assume d_%d in R_1 and d_%d in R_2: UNSAT; deletion-minimal core:' % (j, k))
                for lab in c: pr('      ', label(lab, P))
    pr('(c) pairs refuted by (G) alone (d_0 not in R_1, d_n not in R_2):', gref)
    pr('(c) other pairs (j<k) with "d_j in R_1, d_k in R_2" UNSAT:', sorted(k_ for k_, u in res_c.items() if u))
    pr('    pairs SAT (adjacent pairs are allowed only if the threshold sits between them):', sorted(k_ for k_, u in res_c.items() if not u))
    # (d)
    res_d = []
    for m in range(1, n + 1):
        ass = [v(d[k], 1) if k < m else v(d[k], 0) for k in range(n + 1)]
        Sv = I.solver(); r = Sv.solve(assumptions=ass); Sv.delete(); res_d.append(r)
    pr('(d) threshold at every position m=1..n realisable (SAT):', res_d)
    return ok_a and ok and all(res_b) and all(res_d)

if __name__ == '__main__':
    keys = sys.argv[1:] or ['e1_3', 'e1_1', 'u_3', 'u_1']
    res = {k: run(k) for k in keys}
    pr('\nSUMMARY', res)
    open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'rerun_t2_%s.out' % '_'.join(keys)), 'w').write('\n'.join(out) + '\n')
