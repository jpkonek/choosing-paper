"""Referee check for PP11 Theorem J: the ABSTRACT implication skeleton, with no geometry and no pool.

Family X_0..X_n (X_k = C_a + A on G_1(k) u G_2(k), G_1 decreasing, G_2 increasing, G_2(0)=G_1(n)=empty).
Variables (one per record and world, so (IB) is built in):
  L[w][k]  : d_k = rec(X_k, C_a) in R_w      ("X_k <=_w C_a")
  F[w][k]  : e_k = rec(C_a, X_k) in R_w      ("C_a <=_w X_k")
  H[k][l]  : rec(X_k, X_l) in R_3 (k != l)   -- world-3 comparisons between members are NOT guidance
             (A->S on M_1 worsens world 3, S->A on M_2 improves it), so they are free.
Fixed by (G) (both halves), derived by hand from the class/rank table:
  world 3: d_k weak worsening -> L[3][k]=1 ; e_k strict improvement -> F[3][k]=0 (every k, G(k) non-null)
  d_0: world 1 strictly improved -> L[1][0]=0, F[1][0]=1 ; world 2 worsened -> L[2][0]=1, F[2][0]=0
  d_n: symmetric.
  members, k<l: X_l strictly better than X_k at world 1, strictly worse at world 2.
Clauses (each an axiom instance):
  EDGE  L[1][k] or L[2][k]                         (defence clause of the precise edge model C_r, via (IB))
  FWD   F[1][k] or F[2][k] or F[3][k]              (competitiveness of C_a at its full support)
  UND   (L1 & L2 & L3) -> (F1 & F2 & F3)            (C_a undominated by X_k)
  TC    all triangles on all triples of {C_a, X_0..X_n} at all three worlds.
Toggles let us remove TC / UND / EDGE to see which parts of Theorem J each one carries.
Also: the Phi^kappa demonstration that every closed record rule of the form {kappa*on - off >= 0} fails J(1)."""
import itertools, sys
from fractions import Fraction as Fr
from pysat.solvers import Solver

def build(n, use_tc=True, use_und=True, use_edge=True, use_fwd=True):
    M = ['C'] + ['X%d' % k for k in range(n + 1)]
    var = {}
    def v(key):
        if key not in var: var[key] = len(var) + 1
        return var[key]
    fixed = {}
    # acc(x, y, w): literal or constant for "x <=_w y"
    def acc(x, y, w):
        if x == y: return True
        if x == 'C':
            k = int(y[1:]); key = ('F', w, k)
        elif y == 'C':
            k = int(x[1:]); key = ('L', w, k)
        else:
            k, l = int(x[1:]), int(y[1:])
            if w == 1: return l < k      # X_k <=_1 X_l iff X_l is worse at world 1 iff l < k
            if w == 2: return l > k
            key = ('H', k, l)
        return fixed.get(key, v(key))
    for k in range(n + 1):
        fixed[('L', 3, k)] = True; fixed[('F', 3, k)] = False
    fixed[('L', 1, 0)] = False; fixed[('F', 1, 0)] = True; fixed[('L', 2, 0)] = True; fixed[('F', 2, 0)] = False
    fixed[('L', 2, n)] = False; fixed[('F', 2, n)] = True; fixed[('L', 1, n)] = True; fixed[('F', 1, n)] = False
    cls = []
    def clause(lits):
        out = []
        for l in lits:
            if l is True: return            # satisfied
            if l is False: continue
            out.append(l)
        cls.append(out)
    def neg(l): return (not l) if isinstance(l, bool) else -l
    for k in range(n + 1):
        L = {w: acc('X%d' % k, 'C', w) for w in (1, 2, 3)}
        Fw = {w: acc('C', 'X%d' % k, w) for w in (1, 2, 3)}
        if use_edge: clause([L[1], L[2]])
        if use_fwd: clause([Fw[1], Fw[2], Fw[3]])
        if use_und:
            for j in (1, 2, 3): clause([neg(L[1]), neg(L[2]), neg(L[3]), Fw[j]])
    if use_tc:
        for w in (1, 2, 3):
            for x, y, z in itertools.permutations(M, 3):
                # x<=y, y<=z, z<=x  =>  x<=z
                clause([neg(acc(x, y, w)), neg(acc(y, z, w)), neg(acc(z, x, w)), acc(x, z, w)])
    return var, fixed, cls

def project(n, var, fixed, cls, limit=100000):
    keys = [('L', w, k) for w in (1, 2) for k in range(n + 1)] + [('F', w, k) for w in (1, 2) for k in range(n + 1)]
    S = Solver(name='cd19', bootstrap_with=cls)
    sols = set()
    proj = [var[kk] for kk in keys if kk in var]
    while S.solve() and len(sols) < limit:
        m = set(l for l in S.get_model() if l > 0)
        pat = tuple(fixed[kk] if kk in fixed else (var[kk] in m) for kk in keys)
        sols.add(pat)
        S.add_clause([-p if p in m else p for p in proj])
    S.delete()
    out = []
    for pat in sols:
        d = dict(zip(keys, pat))
        out.append(d)
    return out

def describe(n, d):
    L1 = ''.join('1' if d[('L', 1, k)] else '.' for k in range(n + 1))
    L2 = ''.join('2' if d[('L', 2, k)] else '.' for k in range(n + 1))
    F1 = ''.join('1' if d[('F', 1, k)] else '.' for k in range(n + 1))
    F2 = ''.join('2' if d[('F', 2, k)] else '.' for k in range(n + 1))
    return 'L1 %s  L2 %s  F1 %s  F2 %s' % (L1, L2, F1, F2)

def analyse(n, **kw):
    var, fixed, cls = build(n, **kw)
    sols = project(n, var, fixed, cls)
    exact_one = all(d[('L', 1, k)] != d[('L', 2, k)] for d in sols for k in range(n + 1))
    # "far inversion": L1 at j, L2 at k >= j+2  (excluded by Theorem J (2) in finite form)
    far_inv = [d for d in sols if any(d[('L', 1, j)] and d[('L', 2, k)] for j in range(n + 1) for k in range(j + 2, n + 1))]
    # strict pattern of (2): where L2-only, F = {1}; where L1-only, F = {2}   (checked for members not adjacent to an inversion)
    return sols, exact_one, far_inv

if __name__ == '__main__':
    out = []
    def pr(*a):
        s = ' '.join(str(x) for x in a); print(s); out.append(s)
    n = 5
    for tag, kw in [('ALL axioms', {}), ('no TC', dict(use_tc=False)), ('no UND', dict(use_und=False)),
                    ('no EDGE', dict(use_edge=False)), ('no FWD', dict(use_fwd=False))]:
        sols, ex1, far = analyse(n, **kw)
        pr('== %s (n=%d): %d projected solutions on (L1,L2,F1,F2); exactly-one-of-{1,2} on every d_k: %s; '
           'solutions with an inversion L1@j, L2@k, k>=j+2: %d' % (tag, n, len(sols), ex1, len(far)))
        if tag == 'ALL axioms':
            for d in sorted(sols, key=lambda d: describe(n, d)): pr('   ', describe(n, d))
    # Theorem J (2) strict pattern, finite form: if d_k is L2-only and d_{k+1} in L2, then F(C_a,X_k) = {1};
    # if d_k is L1-only and d_{k-1} in L1, then F(C_a,X_k) = {2}.
    sols, _, _ = analyse(n)
    bad = 0; tested = 0
    for d in sols:
        for k in range(n + 1):
            if d[('L', 2, k)] and not d[('L', 1, k)] and k < n and d[('L', 2, k + 1)]:
                tested += 1; bad += not (d[('F', 1, k)] and not d[('F', 2, k)])
            if d[('L', 1, k)] and not d[('L', 2, k)] and k > 0 and d[('L', 1, k - 1)]:
                tested += 1; bad += not (d[('F', 2, k)] and not d[('F', 1, k)])
    pr('Theorem J (2) strict F-pattern away from the cut: %d instances tested, %d violations' % (tested, bad))

    # --- closed Phi^kappa rules on the family (x = mu(G_1), y = mu(G_2), lambda in [0,1], x = 1-lambda, y = lambda) ---
    pr('\n== closed rules R_w = Guid_w u {kappa*on_w - off_w >= 0} on d(lambda):')
    pr('   world 1: on = y (A->S on M_2, majority for 1), off = x (A->S on M_1, minority for 1)')
    pr('   world 2: on = x, off = y ; world 3: on = x+y, off = 0 (guidance)')
    for kappa in (Fr(1, 2), Fr(1), Fr(2), Fr(4)):
        both = []; neither = []
        for i in range(0, 1001):
            lam = Fr(i, 1000); x, y = 1 - lam, lam
            a1 = (kappa*y - x >= 0) or x == 0
            a2 = (kappa*x - y >= 0) or y == 0
            if a1 and a2: both.append(lam)
            if not a1 and not a2: neither.append(lam)
        rng = lambda s: '[%s, %s]' % (min(s), max(s)) if s else 'none'
        pr('   kappa=%s: accepted at BOTH 1,2 (C_a dominated) for lambda in %s; at NEITHER (edge defence lost) for lambda in %s'
           % (kappa, rng(both), rng(neither)))
    open(__file__.replace('.py', '.out'), 'w').write('\n'.join(out) + '\n')
