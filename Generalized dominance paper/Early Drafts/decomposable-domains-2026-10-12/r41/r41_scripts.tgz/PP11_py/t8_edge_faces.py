"""PP11 t8: which records of the cube pool (with (IB) transfers) carry a GENUINE edge obligation, i.e. their
anchor set meets an edge away from its two vertices, and that obligation is not already met by guidance.
Grouped by edge and by the record's (old -> new) pattern on the three cones and T, plus 'outside' if the
record also changes cells outside the cones and T (C_a-vs-C_q differences)."""
import sys, os
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from modules import *
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)
LABS = {'+': None, '-': None}
for key in (sys.argv[1:] or ['e1_3', 'e1_1', 'u_3', 'u_1']):
    geo = pump_geometry(key)
    ms = dedup([geo['Ca'], geo['Cq']] + cube_models(geo))
    P, closed = build_pool(ms, geo['eps'], close=True, cap=400, log=lambda *a: None)
    regions = [list(r) for r in geo['cones']] + [list(geo['T'])]
    def region_of(c):
        g = interior(P.cells[c])
        for k, r in enumerate(regions):
            if in_cone(g, r) or in_cone(neg(g), r): return k
        return 4
    reg = np.array([region_of(c) for c in range(P.C)])
    groups = {}
    for r in range(P.R):
        for I in P.faces[r]:
            if len(I) != 2: continue
            if any(len(J) == 1 and J[0] in I for J in P.faces[r]): continue
            if any(P.G[r, i] for i in I): continue           # met by guidance at a world of the edge
            D = P.rD[r]
            pat = []
            for k in range(4):
                sel = D[reg[D] == k]
                if len(sel) == 0: pat.append('-'); continue
                o = set(label(P.g[c], ADVC_[P.rold[r][list(D).index(c)]]) for c in sel) if False else None
                olds = set(); news = set()
                for c in sel:
                    idx = int(np.nonzero(D == c)[0][0])
                    olds.add(label(P.g[c], jd.ADVC[P.rold[r][idx]])); news.add(label(P.g[c], jd.ADVC[P.rnew[r][idx]]))
                pat.append('%s>%s' % (''.join(sorted(olds)), ''.join(sorted(news))))
            outside = (reg[D] == 4).any()
            k_ = (tuple(i+1 for i in I), ' '.join(pat) + (' +outside' if outside else ''))
            groups[k_] = groups.get(k_, 0) + 1
    pr('\n=== %s: %d models, %d records; genuine edge obligations not met by guidance (edge, pattern on S1 S2 S3 T): count' % (key, P.N, P.R))
    for k_ in sorted(groups): pr('   ', k_, groups[k_])
open(os.path.join(HERE, 't8_edge_faces.out'), 'w').write('\n'.join(out) + '\n')
