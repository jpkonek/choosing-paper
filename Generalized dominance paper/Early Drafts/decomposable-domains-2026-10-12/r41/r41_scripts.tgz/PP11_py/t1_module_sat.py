"""PP11 t1: the coupled module of brief §4, most-permissive SAT (axioms only), four settings.

Pool: C_a, C_q (PP8 pump geometry) + the splice cube (sigma in {S,A,B}^3 on the three cones x tau in {S,B} on T:
Y_plus = AAA, Y_minus = BBB, all independent splices, the return Z), closed under splicing of its own records
(the (IB) transfers, e.g. into C_q-contexts); then, WITHOUT further splicing (frozen):
  * the nested two-class family X_k (A on G_1(k) u G_2(k), the Theorem J family, n = 4);
  * PP8 F-B's selected model C_p (p = a + t v, PP8's exact t, v) as a fixed selected model;
  * six germ models C_{a + t v} (t = 1e-7, v = the six unit directions) with closed-section clauses against
    every fixed model.
Reports: SAT, independent re-check, and the backbone (free literals forced in every model of the instance)."""
import sys, os, time
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from modules import *
import pp11sat as S
import t2_threshold as T2

FB = {'e1_3': ((1, -1, 0), F(1, 10**6)), 'e1_1': ((1, -1, 0), F(1, 10**8)),
      'u_3': ((0, 1, -1), F(-1, 10**6)), 'u_1': ((1, -1, 0), F(1, 10**8))}
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def run(key, backbone=True):
    t0 = time.time()
    geo = pump_geometry(key); a = geo['a']; eps = geo['eps']
    base = dedup([geo['Ca'], geo['Cq']] + cube_models(geo))
    fam = T2.family(geo, 4)[1:-1]                       # interior members (ends are cube members up to closure)
    v, t = FB[key]
    Cp = Model(path_point(a, v, t), eps, name='C_p(F-B)')
    dirs = [(1, -1, 0), (-1, 1, 0), (0, 1, -1), (0, -1, 1), (1, 0, -1), (-1, 0, 1)]
    germs = [Model(path_point(a, d, F(1, 10**7)), eps, name='P%s' % (d,)) for d in dirs]
    P = jd.Pool(base + fam + [Cp] + germs, eps, log=lambda *x: None)
    frozen = [P.names.index(m.name) for m in fam + [Cp] + germs]
    close_excluding(P, frozen, cap=600, log=lambda *x: None)
    P.build_records()
    gidx = [P.names.index(g.name) for g in germs]; ia = P.names.index('C_a')
    fixed = [k for k in range(P.N) if k not in gidx]
    inc = incoherence_map(P)
    nface = {}
    for r in range(P.R):
        for I in P.faces[r]:
            if len(I) == 2 and not any(len(J) == 1 and J[0] in I for J in P.faces[r]): nface[I] = nface.get(I, 0) + 1
    pr('\n=== %s: %d models (%d selected, %d germs), %d records; genuine edge obligations (edge met away from its vertices): %s; certified-incoherent rivals %d/%d' % (
        key, P.N, sum(s is not None for s in P.selp), len(gidx), P.R, {tuple(i+1 for i in k): c for k, c in nface.items()}, sum(inc.values()), len(inc)))
    I = S.Inst(P, germs=gidx, germ_base=ia, fixed_for_germ=fixed, incoh=inc, stream=True, log=pr)
    ok, model = I.solve()
    pr('SAT: %s (%.0fs)' % (ok, time.time()-t0))
    if not ok: return False
    pr('independent check:', S.check(P, model, germs=gidx, germ_base=ia, fixed_for_germ=fixed, incoh=inc))
    if backbone:
        t1 = time.time(); bb = I.backbone(model)
        pr('backbone: %d forced free literals out of %d free variables (%.0fs)' % (len(bb), 3*P.R - len(I.fix), time.time()-t1))
        for r, i, val in bb[:20]: pr('   forced:', S.describe_rec(P, r), 'world', i+1, val)
    return True

if __name__ == '__main__':
    keys = sys.argv[1:] or ['e1_3', 'e1_1', 'u_3', 'u_1']
    res = {k: run(k) for k in keys}
    pr('\nSUMMARY', res)
    open(os.path.join(HERE, 't1_module_sat_%s.out' % '_'.join(keys)), 'w').write('\n'.join(out) + '\n')
