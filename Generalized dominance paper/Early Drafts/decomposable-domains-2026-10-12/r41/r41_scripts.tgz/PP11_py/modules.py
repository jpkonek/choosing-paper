"""PP11 module builders.  Exact geometry from PP7/PP8 (pp7core via PP8_py/configs.py).

Module pieces (brief §4):
  * C_a and the reverse anchor C_q of PP8's pump (PP5 t7 geometry: three cones S_1,S_2,S_3, one per class,
    where C_a is silent and C_q says A; and a cone T in the lead class where both are silent);
  * the splice cube: C_a with advice sigma_w in {S,A,B} on S_w (w = 1,2,3) and tau in {S,B} on T.
    sigma = AAA is PP8's doubly anchored rival Y_plus (= Ypump); sigma = BBB is the mirror Y_minus; tau = B is
    PP8's return Z (a strict world-lead improvement of C_a);
  * nested sub-cones (fractional refinement): S_w(t) for t in a grid, with A (or B) on a nested prefix;
  * (IB) transfers: closure of the pool under splicing of its own records into its own models;
  * selected models along paths p = a + t v, either as fixed selected models (e.g. PP8 F-B's C_p) or as
    germ models for the closed-section clauses."""
import sys, os, itertools
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'PP8_py'))
from configs import *
import jd
import numpy as np

LAB = {'S': '0'}

def pump_geometry(key='e1_3', world=0):
    a = PP5_A if key == 'e1_3' else SETTINGS[key][0]
    eps = SETTINGS[key][1]
    ms, q = cfg_pp5_pump(a, eps, world=world)
    if ms is None: return None
    Ca, Cq, Y, Z = ms
    cones = [r for r, _ in Y.ov]            # one per class, in class order of construction
    T = Z.ov[0][0]
    return dict(a=a, eps=eps, q=q, Ca=Ca, Cq=Cq, Y=Y, Z=Z, cones=cones, T=T, lead=world)

def adv(rays, lab):
    return '0' if lab == 'S' else adv_from_label(interior(list(rays)), lab)

def cube_models(geo, sigmas=None, taus=('S', 'B'), base='a'):
    B = geo['Ca'] if base == 'a' else geo['Cq']
    out = []
    if sigmas is None: sigmas = [''.join(s) for s in itertools.product('SAB', repeat=3)]
    for s in sigmas:
        for t in taus:
            ov = [(geo['cones'][w], adv(geo['cones'][w], s[w])) for w in range(3)]
            ov.append((geo['T'], adv(geo['T'], t)))
            # drop overrides equal to the base advice so that the selected base keeps selected=True
            ov2 = [(r, a_) for (r, a_) in ov if a_ != B.advice(interior(list(r)))]
            name = ('X%s' % base) + '[%s|%s]' % (s, t)
            if not ov2: name = 'C_%s' % base
            out.append(Model(B.p, B.eps, ov2, name=name))
    return out

def nested_models(geo, ts=(F(1), F(1, 2)), labs=('S', 'A', 'B'), taus=('S',)):
    """C_a with, on each class w, advice lab on the nested sub-cone S_w(t) (t in ts) and silence on the rest
    of S_w.  Option 'S' = silent on all of S_w.  Nested prefixes give a fractional refinement in which the
    guidance order between rivals is the product order of PP7 Thm 4.2."""
    opts = [('S', None)] + [(l, t) for l in labs if l != 'S' for t in ts]
    out = []
    for combo in itertools.product(opts, repeat=3):
        for tau in taus:
            ov = []
            nm = []
            for w, (l, t) in enumerate(combo):
                if l == 'S': nm.append('S'); continue
                rays = geo['cones'][w] if t == 1 else shrunk(geo['cones'][w], t)
                ov.append((rays, adv(rays, l))); nm.append('%s%s' % (l, '' if t == 1 else str(t)))
            if tau != 'S': ov.append((geo['T'], adv(geo['T'], tau)))
            name = 'N[%s|%s]' % (','.join(nm), tau)
            if not ov: name = 'C_a'
            out.append(Model(geo['a'], geo['eps'], ov, name=name))
    return out

def dedup(models):
    seen = set(); out = []
    for M in models:
        key = (M.p, tuple(sorted((tuple(r), a_) for r, a_ in M.ov)))
        if key in seen: continue
        seen.add(key); out.append(M)
    return out

def build_pool(models, eps, close=True, cap=400, extra_planes=(), log=print):
    P = jd.Pool(models, eps, log=log, extra_planes=extra_planes)
    closed = P.close(cap=cap) if close else None
    P.build_records()
    return P, closed

def incoherence_map(P):
    out = {}
    for k in range(P.N):
        if P.selp[k] is not None: continue
        out[k] = P.incoherence(k) is not None
    return out

def close_excluding(P, frozen, cap=400, rounds=6, log=print):
    """Pool.close, except that models in `frozen` (indices; e.g. germ models C_{p(t)}) are never used as
    source, target or context of a splice, so every added model is t-independent."""
    frozen = set(frozen)
    for rnd in range(rounds):
        N = len(P.A); Am = np.array(P.A)
        live = [u for u in range(N) if u not in frozen]
        seen = set(); added = 0
        for u in live:
            for v in live:
                if u == v: continue
                Dm = Am[u] != Am[v]
                D = np.nonzero(Dm)[0]
                key = (D.tobytes(), Am[u][D].tobytes(), Am[v][D].tobytes())
                if key in seen: continue
                seen.add(key)
                for z in live:
                    if z == u: continue
                    if (Am[z][D] != Am[u][D]).any(): continue
                    a_ = Am[z].copy(); a_[D] = Am[v][D]
                    k, new = P.add_vec(a_, '%s^[%s>%s]' % (P.names[z], P.names[u], P.names[v]))
                    if new:
                        added += 1
                        if len(P.A) >= cap:
                            log('closure: CAP %d reached (not closed)' % cap); return False
        log('closure round %d: +%d -> %d' % (rnd+1, added, len(P.A)))
        if added == 0: return True
    return False

def path_point(a, v, t):
    return tuple(a[k] + t*v[k] for k in range(3))
