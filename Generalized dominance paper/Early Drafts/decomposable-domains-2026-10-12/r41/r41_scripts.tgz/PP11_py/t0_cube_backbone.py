"""PP11 t0: the splice cube alone (C_a, C_q, sigma in {S,A,B}^3 on the three pump cones x tau in {S,B} on T,
closed under splicing of its own records = all (IB) transfers inside the pool).  Most-permissive SAT
(axioms only, no germs): SAT, independent re-check, backbone (free literals forced in every solution),
and the faces of the two mirror rivals' records."""
import sys, os, time
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from modules import *
import pp11sat as S
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)
def run(key):
    t0 = time.time()
    geo = pump_geometry(key)
    ms = dedup([geo['Ca'], geo['Cq']] + cube_models(geo))
    P, closed = build_pool(ms, geo['eps'], close=True, cap=400, log=lambda *a: None)
    inc = incoherence_map(P)
    ia = P.names.index('C_a'); ip = P.names.index('Xa[AAA|S]'); im = P.names.index('Xa[BBB|S]')
    pr('\n=== %s: %d models (closed %s), %d records; certified-incoherent %d/%d' % (key, P.N, closed, P.R, sum(inc.values()), len(inc)))
    pr('   Y_plus  = Xa[AAA|S]: faces rec(C_a,Y+) %s, rec(Y+,C_a) %s' % (P.faces[P.recmat[ia, ip]], P.faces[P.recmat[ip, ia]]))
    pr('   Y_minus = Xa[BBB|S]: faces rec(C_a,Y-) %s, rec(Y-,C_a) %s' % (P.faces[P.recmat[ia, im]], P.faces[P.recmat[im, ia]]))
    I = S.Inst(P, incoh=inc, stream=True, log=pr)
    ok, model = I.solve()
    pr('   SAT %s; independent check %s' % (ok, S.check(P, model, incoh=inc) if ok else None))
    bb = I.backbone(model)
    pr('   backbone: %d forced free literals out of %d free variables (%.0fs)' % (len(bb), 3*P.R - len(I.fix), time.time()-t0))
    return ok and not bb
if __name__ == '__main__':
    keys = sys.argv[1:] or ['e1_3', 'e1_1', 'u_3', 'u_1']
    res = {k: run(k) for k in keys}
    pr('\nSUMMARY (SAT and empty backbone):', res)
    open(os.path.join(HERE, 't0_cube_backbone.out'), 'w').write('\n'.join(out) + '\n')
