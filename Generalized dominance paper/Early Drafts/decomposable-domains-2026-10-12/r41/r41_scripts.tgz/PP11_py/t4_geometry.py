"""PP11 t4: the hypothesis of Theorem J holds at EVERY interior index and on every edge (exact instances).

Construction (edge Delta_ij, third world k), as in the proof of Lemma J0:
  z*(x) = x_j/(x_i+x_j) is the point where the line through e_k and x meets [e_i,e_j] (e_j-coordinate).
  Take x, x' in int K_p with z*(x) < z*(x'), and r on the open edge with z*(x) < r_j < z*(x').
  G_i: a small cone of problems around the line through x and the edge point with e_j-coordinate in
       (z*(x), r_j)  -- a line of M_i, through int K_p, with r on its majority side;
  G_j: a small cone around the line through x' and the edge point with e_j-coordinate in (r_j, z*(x'))
       -- a line of M_j, through int K_p, with r on its majority side.
Exact checks for each instance:
  (1) C_p is silent on both cones (a common negative and a common positive vertex of K_p for all rays);
  (2) the cones lie in M_i and M_j (class of every ray);
  (3) the exact anchor polygon of the old side "A on G_i u G_j" (pp7core.anchor_set) meets the open edge
      Delta_ij (some polygon vertex with zero k-coordinate and both other coordinates > 0) -- i.e. the
      A-pattern is realised by a precise edge model C_r;
  (4) C_r says A on every ray of both cones, for the constructed r (direct exact evaluation)."""
import sys, os, random, itertools
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from modules import *

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def homog_line(P, Q):
    """problem g (normal) of the line through barycentric points P, Q: g.P = g.Q = 0."""
    return prim(cross(P, Q))

def cone_around(g0, N=200):
    """small exact simplicial cone of problems around g0: rays g0 + (|g0|/N) * (unit-ish perturbations)."""
    basis = [(1, 0, 0), (0, 1, 0), (0, 0, 1)]
    e = min(basis, key=lambda b: abs(dot(b, g0)))
    u = cross(g0, e); w = cross(g0, u)
    n0 = max(abs(t) for t in g0); nu = max(abs(t) for t in u); nw = max(abs(t) for t in w)
    us = tuple(F(t*n0, N*nu) for t in u); ws = tuple(F(t*n0, N*nw) for t in w)
    rays = []
    for (a, b) in ((1, 0), (-1, 1), (-1, -1)):
        rays.append(prim(tuple(g0[t] + a*us[t] + b*ws[t] for t in range(3))))
    if det3(*rays) < 0: rays = [rays[0], rays[2], rays[1]]
    return tuple(rays)

def silent_on(p, eps, rays):
    V = verts(p, eps)
    neg_ = [v for v in V if all(dot(r, v) < 0 for r in rays)]
    pos_ = [v for v in V if all(dot(r, v) > 0 for r in rays)]
    return bool(neg_) and bool(pos_)

def instance(p, eps, i, j, k, N=200):
    V = verts(p, eps)
    cen = tuple(sum(v[t] for v in V)/3 for t in range(3))
    # two interior points of K_p: shrink the vertices of K_p towards the centroid
    pts = [tuple(cen[t] + F(3, 4)*(v[t]-cen[t]) for t in range(3)) for v in V]
    zst = lambda x: x[j]/(x[i]+x[j])
    x, xp = min(pts, key=zst), max(pts, key=zst)
    if not zst(x) < zst(xp): return None, 'degenerate'
    z1 = zst(x) + (zst(xp)-zst(x))/4; rj = (zst(x)+zst(xp))/2; z2 = zst(x) + 3*(zst(xp)-zst(x))/4
    def edge_pt(z):
        e = [F(0)]*3; e[i] = 1-z; e[j] = z; return tuple(e)
    gi = homog_line(x, edge_pt(z1)); gj = homog_line(xp, edge_pt(z2))
    r = edge_pt(rj)
    ok = {}
    Gi, Gj = cone_around(gi, N), cone_around(gj, N)
    ok['N'] = N
    ok['silent'] = silent_on(p, eps, Gi) and silent_on(p, eps, Gj)
    ok['classes'] = all(cls(g) == i for g in Gi) and all(cls(g) == j for g in Gj)
    # old side "A" on both cones, exact advice of C_r on every ray and the interior ray
    advA = lambda rays: adv_from_label(interior(list(rays)), 'A')
    ok['C_r says A'] = all(sel_advice(r, g, eps) == advA(Gi) for g in list(Gi) + [interior(list(Gi))]) and \
                       all(sel_advice(r, g, eps) == advA(Gj) for g in list(Gj) + [interior(list(Gj))])
    polys = anchor_set([(list(Gi), advA(Gi), '0'), (list(Gj), advA(Gj), '0')], eps)
    pts2 = [(v[0], v[1], 1-v[0]-v[1]) for kk in polys for v in polys[kk]]
    ok['anchor meets open edge'] = any(q[k] == 0 and q[i] > 0 and q[j] > 0 for q in pts2)
    ok['anchor meets interior'] = any(all(t > 0 for t in q) for q in pts2)
    return all(v for kk, v in ok.items() if kk != 'N'), ok

if __name__ == '__main__':
    random.seed(11)
    tot = 0; good = 0
    P = [(F(9, 10), F(6, 100), F(4, 100)), (F(35, 100), F(33, 100), F(32, 100)), (F(1, 3), F(1, 3), F(1, 3)),
         (F(98, 100), F(1, 100), F(1, 100)), (F(1, 100), F(1, 100), F(98, 100))]
    for _ in range(15):
        a_ = [random.randint(1, 1000) for _ in range(3)]; s_ = sum(a_)
        P.append(tuple(F(t, s_) for t in a_))
    for eps in (F(3, 10), F(1, 10), F(1, 100)):
        for p in P:
            for (i, j, k) in ((0, 1, 2), (0, 2, 1), (1, 2, 0)):
                for N in (200, 2000, 20000, 200000, 2000000, 20000000):
                    res, info = instance(p, eps, i, j, k, N)
                    if res: break
                tot += 1; good += bool(res)
                if not res: pr('FAIL', tuple(map(str, p)), str(eps), (i+1, j+1), info)
    pr('Theorem J hypothesis, exact instances: %d / %d (20 interior indices x 3 values of eps x 3 edges)' % (good, tot))
    open(os.path.join(HERE, 't4_geometry.out'), 'w').write('\n'.join(out) + '\n')
