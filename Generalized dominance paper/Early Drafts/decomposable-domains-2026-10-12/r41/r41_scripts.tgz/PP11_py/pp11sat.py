"""PP11 harness: the MOST PERMISSIVE encoding of the adopted axioms on a finite pool.

No rule, no priority, no initial order.  One boolean per (directed record, world): "the record is accepted
at that world", so (IB) is built in (one variable per record, shared by all its contexts).  Constraints, each
an axiom instance and nothing else:

  (G)    pointwise weak worsening at i  -> accepted at i (unit);  strict improvement at i -> refused at i (unit).
         (Identity is reflexivity.)
  (TC)   for every world i and ordered triple of distinct pool models X,Y,Z:
            X<=Y, Y<=Z, Z<=X  imply  X<=Z           (i.e. not Z <_i X).
  (S-def) face obligations: for every record d and every face I met by A(d) (exact anchor polygons, PP7/PP8
         geometry):  OR_{i in I} acc(d,i).  (This is exactly competitiveness on supp q, transported by (IB),
         for every q in A(d); it is applied to every record of the pool, in particular rival-to-rival ones.)
  (U)    every selected pool model is undominated by every pool model.
  (C)    no all-world tie between a selected pool model and a CERTIFIED-incoherent pool model.
  (CL)   closed sections, only through GERM clauses: for a germ model P (= C_{p(t)}, t small, standing for a
         subsequence t_n -> 0 along which all finitely many verdicts involving it are constant) and a FIXED
         pool model X (not built from P):  acc(rec(P,X),i) -> acc(rec(C_a,X),i).

The instance is a RELAXATION of the axioms restricted to the pool: UNSAT => the axioms are inconsistent
(given exact data); SAT => no contradiction at this level of the module.  KKM dominators are NOT encoded
(their witness need not lie in the pool), so no unsound clause is added.

Also: backbone computation (literals forced in every model of the instance = compulsory comparisons beyond
guidance) and deletion-minimal cores with labelled axiom instances, so that each forced literal comes with an
explicit implication chain.  An independent checker re-verifies any assignment with plain loops."""
import sys, os, itertools, time
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'PP8_py'))
import numpy as np
from pysat.solvers import Solver

W3 = (0, 1, 2)

class Inst:
    def __init__(self, pool, germs=(), germ_base=None, fixed_for_germ=None, log=print, incoh=None, extra_units=(), stream=False):
        """pool: a jd.Pool after build_records().  germs: list of model indices that are germ models;
        germ_base: index of C_a; fixed_for_germ: list of model indices X that are fixed (not t-dependent)."""
        self.P = pool; self.log = log
        N, R = pool.N, pool.R
        self.N, self.R = N, R
        self.var = lambda r, i: 1 + 3*int(r) + i
        # fixed values from (G)
        self.fix = {}
        for r in range(R):
            for i in W3:
                if pool.G[r, i]: self.fix[self.var(r, i)] = True
                elif pool.G[pool.rev[r], i]: self.fix[self.var(r, i)] = False
        for (lit) in extra_units:
            self.fix[abs(lit)] = lit > 0
        self.groups = []          # (label, [clauses])
        self.sel = [s for s in range(N) if pool.selp[s] is not None]
        self.germs = list(germs); self.germ_base = germ_base
        self.fixed_for_germ = list(fixed_for_germ) if fixed_for_germ is not None else []
        self.incoh = incoh if incoh is not None else {}
        self.stream = stream; self.nstream = 0
        if stream:
            self.S = Solver(name='cd19')
            for vv, val in self.fix.items(): self.S.add_clause([vv if val else -vv])
        t0 = time.time()
        self._build()
        self.log('instance: %d records, %d vars (%d fixed by (G)), %d clauses, %.1fs' % (
            R, 3*R, len(self.fix), self.nstream if stream else sum(len(c) for _, c in self.groups), time.time()-t0))

    # ---------------------------------------------------------------- clause simplification by (G)
    def simp(self, cl):
        out = []
        for l in cl:
            v = abs(l)
            if v in self.fix:
                val = self.fix[v] if l > 0 else (not self.fix[v])
                if val: return None          # satisfied
                continue                     # literal false: drop
            out.append(l)
        return out

    def add(self, label, cls_):
        if self.stream:
            for cl in cls_:
                s_ = self.simp(cl)
                if s_ is None: continue
                self.S.add_clause(s_); self.nstream += 1
            return
        kept = []
        for cl in cls_:
            s = self.simp(cl)
            if s is None: continue
            kept.append((cl, s))
        if kept: self.groups.append((label, kept))

    def _build(self):
        P = self.P; N = self.N; v = self.var; rm = P.recmat
        # obligations
        for r in range(self.R):
            for I in P.faces[r]:
                self.add(('OBL', r, I), [[v(r, i) for i in I]])
        # TC, vectorised enumeration of triples whose clause is not satisfied by (G)
        fixarr = np.zeros((self.R, 3), dtype=np.int8)       # 1 fixed true, -1 fixed false, 0 free
        for (var_, val) in self.fix.items():
            r, i = divmod(var_-1, 3); fixarr[r, i] = 1 if val else -1
        self.fixarr = fixarr
        ntc = 0
        for i in W3:
            F_ = fixarr[np.maximum(rm, 0), i].copy(); np.fill_diagonal(F_, 1)
            notfalse = F_ != -1          # X<=Y possibly true
            nottrue = F_ != 1            # X<=Z possibly false
            for x in range(N):
                ys = np.nonzero(notfalse[x])[0]; ys = ys[ys != x]
                zs = np.nonzero(notfalse[:, x] & nottrue[x, :])[0]; zs = zs[zs != x]
                if len(ys) == 0 or len(zs) == 0: continue
                M = notfalse[np.ix_(ys, zs)]
                a, c = np.nonzero(M)
                cls_ = []
                for y, z in zip(ys[a], zs[c]):
                    if y == z: continue
                    cls_.append([-v(rm[x, y], i), -v(rm[y, z], i), -v(rm[z, x], i), v(rm[x, z], i)])
                if cls_:
                    # group per (world, x): coarse groups; refined in cores()
                    for cl, (y, z) in zip(cls_, [(y, z) for y, z in zip(ys[a], zs[c]) if y != z]):
                        self.add(('TC', i, x, int(y), int(z)), [cl])
                    ntc += len(cls_)
        self.ntc = ntc
        # undominated selected models, and direct (C)
        for s in self.sel:
            for x in range(N):
                if x == s: continue
                xs = [v(rm[x, s], i) for i in W3]; sx = [v(rm[s, x], i) for i in W3]
                self.add(('UND', s, x), [[-xs[0], -xs[1], -xs[2], sx[j]] for j in W3])
                if self.incoh.get(x):
                    self.add(('DC', s, x), [[-xs[0], -xs[1], -xs[2], -sx[0], -sx[1], -sx[2]]])
        # germ clauses (closed sections with the rival fixed)
        for g in self.germs:
            for x in self.fixed_for_germ:
                if x == g or x == self.germ_base: continue
                for i in W3:
                    self.add(('CL', g, x, i), [[-v(rm[g, x], i), v(rm[self.germ_base, x], i)]])

    # ---------------------------------------------------------------- solving
    def solver(self, groups=None, selectors=False):
        if self.stream:
            assert not selectors and groups is None
            return _Shared(self.S)
        S = Solver(name='cd19')
        for vv, val in self.fix.items(): S.add_clause([vv if val else -vv])     # (G) units
        top = 3*self.R
        self.selvar = {}
        gl = self.groups if groups is None else groups
        for k, (lab, cls_) in enumerate(gl):
            if selectors:
                top += 1; self.selvar[top] = k
                for cl, s in cls_: S.add_clause(s + [-top])
            else:
                for cl, s in cls_: S.add_clause(s)
        return S

    def solve(self):
        S = self.solver()
        ok = S.solve()
        model = None
        if ok:
            m = S.get_model(); val = {abs(l): l > 0 for l in m}
            model = np.zeros((self.R, 3), dtype=bool)
            for r in range(self.R):
                for i in W3:
                    vv = self.var(r, i)
                    model[r, i] = self.fix[vv] if vv in self.fix else val.get(vv, False)
        S.delete()
        return ok, model

    def backbone(self, model, only=None, timeout_each=None):
        """free literals forced in every solution.  Returns list of (r, i, value)."""
        S = self.solver()
        forced = []
        cand = [(r, i) for r in range(self.R) for i in W3 if self.var(r, i) not in self.fix]
        if only is not None: cand = [c for c in cand if c in only]
        cur = model.copy()
        for (r, i) in cand:
            vv = self.var(r, i); val = bool(cur[r, i])
            ok = S.solve(assumptions=[-vv if val else vv])
            if ok:
                m = S.get_model(); mv = {abs(l): l > 0 for l in m}
                # update current model to prune future tests (any literal flipped is not backbone)
                for (r2, i2) in cand:
                    v2 = self.var(r2, i2)
                    if v2 in mv: cur[r2, i2] = mv[v2]
            else:
                forced.append((r, i, val))
        S.delete()
        return forced

    def core(self, assumption_lits=(), minimize=True):
        """deletion-minimal set of clause groups that is UNSAT together with the assumption literals."""
        S = self.solver(selectors=True)
        allsel = list(self.selvar.keys())
        ok = S.solve(assumptions=allsel + list(assumption_lits))
        if ok:
            S.delete(); return None
        core = [l for l in S.get_core() if l in self.selvar]
        if minimize:
            k = 0
            core = list(core)
            while k < len(core):
                trial = core[:k] + core[k+1:]
                if not S.solve(assumptions=trial + list(assumption_lits)):
                    c2 = [l for l in S.get_core() if l in self.selvar]
                    core = [l for l in trial if l in set(c2)] if c2 else trial
                else:
                    k += 1
        S.delete()
        return [self.groups[self.selvar[l]][0] for l in core]


class _Shared:
    """wrapper so that streamed instances can be solved repeatedly without deleting the solver"""
    def __init__(self, S): self.S = S
    def solve(self, assumptions=()): return self.S.solve(assumptions=list(assumptions))
    def get_model(self): return self.S.get_model()
    def get_core(self): return self.S.get_core()
    def delete(self): pass

# -------------------------------------------------------------------- independent checker (plain loops)
def check(pool, acc, germs=(), germ_base=None, fixed_for_germ=(), incoh=None):
    """re-verify an assignment acc[R,3] directly from the pool data with plain Python loops."""
    N = pool.N; rm = pool.recmat; bad = {'G': 0, 'TC': 0, 'OBL': 0, 'UND': 0, 'DC': 0, 'CL': 0}
    def le(x, y, i):
        return True if x == y else bool(acc[rm[x, y], i])
    for r in range(pool.R):
        for i in W3:
            if pool.G[r, i] and not acc[r, i]: bad['G'] += 1
            if pool.G[pool.rev[r], i] and acc[r, i]: bad['G'] += 1
        for I in pool.faces[r]:
            if not any(acc[r, i] for i in I): bad['OBL'] += 1
    for i in W3:
        for x in range(N):
            for y in range(N):
                if not le(x, y, i): continue
                for z in range(N):
                    if le(y, z, i) and le(z, x, i) and not le(x, z, i): bad['TC'] += 1
    sel = [s for s in range(N) if pool.selp[s] is not None]
    for s in sel:
        for x in range(N):
            if x == s: continue
            xs = all(le(x, s, i) for i in W3); sx = all(le(s, x, i) for i in W3)
            if xs and not sx: bad['UND'] += 1
            if xs and sx and incoh and incoh.get(x): bad['DC'] += 1
    for g in germs:
        for x in fixed_for_germ:
            if x in (g, germ_base): continue
            for i in W3:
                if le(g, x, i) and not le(germ_base, x, i): bad['CL'] += 1
    return bad


def describe_rec(pool, r, maxctx=2):
    u, v = np.nonzero(pool.recmat == r)
    ctx = ['rec(%s,%s)' % (pool.names[a], pool.names[b]) for a, b in list(zip(u, v))[:maxctx]]
    more = len(u) - maxctx
    return ctx[0] + (' [+%d contexts]' % more if more > 0 else '') if ctx else 'r%d' % r
