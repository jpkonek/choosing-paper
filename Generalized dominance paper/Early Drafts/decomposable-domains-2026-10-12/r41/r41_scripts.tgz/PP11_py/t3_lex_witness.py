"""PP11 t3: an explicit, record-based, COMPLETE assignment on the module, and where it fails.

Witness L* (a diagnostic, NOT proposed as a construction; it is a fixed lexicographic additive system, which
audit's §2 / stop condition 2 classifies as no new mechanism):
   world 1: lex( J_1, E_1, cell-lex ),   J_1 = errors on M_1 (minority-first),
   world 2: lex( Jmaj_2, E_2, cell-lex ), Jmaj_2 = errors of world 2 on M_1 u M_3 (majority-first),
   world 3: lex( J_3, E_3, cell-lex ),
 where E_w is world w's total error and cell-lex is the sign of the world-w rank change on the first changed
 cell (fixed cell order), so that distinct models are never tied.  X <=_w Y iff V_w(X) <=_lex V_w(Y).
Each world is a total preorder of records, so reflexivity, (G), (IB) and (TC) hold automatically.
We test, on the module pools, every remaining clause of the SAT instance: face obligations, undominated
selected models, direct (C), and the germ clauses for closed sections."""
import sys, os
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from modules import *
import pp11sat as S

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def cls_of_cells(P):
    return np.array([{'U': 3, 0: 0, 1: 1, 2: 2}[cls(g)] for g in P.g])

def lex_acc(P):
    cl = cls_of_cells(P)
    acc = np.zeros((P.R, 3), dtype=bool); unc = 0
    first_sets = {0: (0,), 1: (0, 2), 2: (2,)}
    for r in range(P.R):
        D = P.rD[r]
        for w in range(3):
            dl = P.rk[D, P.rnew[r], w].astype(int) - P.rk[D, P.rold[r], w].astype(int)
            vals = []
            for sel in (np.isin(cl[D], first_sets[w]), np.ones(len(D), dtype=bool)):
                if not sel.any() or not dl[sel].any(): vals.append(0); continue
                v = float((dl[sel]*P.mf[D][sel]).sum()); e = float((np.abs(dl[sel])*P.mrad[D][sel]).sum()) + 1e-15*abs(v)
                if abs(v) <= e: unc += 1; vals.append(0)
                else: vals.append(1 if v > 0 else -1)
            nz = np.nonzero(dl)[0]
            vals.append(0 if len(nz) == 0 else (1 if dl[nz[0]] > 0 else -1))
            s = next((x for x in vals if x != 0), 0)
            acc[r, w] = s >= 0
    return acc, unc

def run(key):
    geo = pump_geometry(key)
    a = geo['a']; eps = geo['eps']
    t = F(1, 10**6)
    dirs = [(1, -1, 0), (-1, 1, 0), (0, 1, -1), (0, -1, 1), (1, 0, -1), (-1, 0, 1)]
    germs = [Model(path_point(a, v, t), eps, name='P%s' % (v,)) for v in dirs]
    ms = dedup([geo['Ca'], geo['Cq']] + cube_models(geo))
    P = jd.Pool(ms + germs, eps, log=lambda *x: None)
    gidx = [P.names.index(g.name) for g in germs]
    close_excluding(P, gidx, cap=600, log=lambda *x: None)
    P.build_records()
    inc = incoherence_map(P)
    acc, unc = lex_acc(P)
    ia = P.names.index('C_a')
    fixed = [k for k in range(P.N) if k not in gidx]
    bad = S.check(P, acc, germs=gidx, germ_base=ia, fixed_for_germ=fixed, incoh=inc)
    pr('%s: pool %d models, %d records; uncertified float level signs %d; violations of L*: %s' % (key, P.N, P.R, unc, bad))
    # list the closed-section (germ) failures
    rm = P.recmat; shown = 0
    for g in gidx:
        for x in fixed:
            if x in (g, ia): continue
            for w in range(3):
                if acc[rm[g, x], w] and not acc[rm[ia, x], w]:
                    if shown < 6:
                        pr('   CL fails: %s <=_%d %s but not C_a <=_%d %s ; rec(C_a,X) guidance-forbidden at %d: %s' % (
                            P.names[g], w+1, P.names[x], w+1, P.names[x], w+1, bool(P.G[P.rev[rm[ia, x]], w])))
                    shown += 1
    pr('   total CL failures: %d' % bad['CL'])
    return bad

if __name__ == '__main__':
    keys = sys.argv[1:] or ['e1_3', 'e1_1', 'u_3', 'u_1']
    for k in keys: run(k)
    open(os.path.join(HERE, 't3_lex_witness.out'), 'w').write('\n'.join(out) + '\n')
