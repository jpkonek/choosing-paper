"""PP11 t5: Corollary J4 (pinned defences) on exact pools.

Pool: C_a, C_q, the Theorem-J family X_0..X_n (n = 4), closed under splicing; plus six germ models
P_v = C_{a + t v} (t = 1e-7), frozen, with closed-section clauses against every fixed model.
For each threshold position m (assumption: d_k in R_2 for k < m, d_k in R_1 for k >= m) we compute which
literals acc(rec(P_v, X_k), w) are FORCED (backbone restricted to germ-vs-family records).  Corollary J4
predicts: for k < m-1, P_v <=_1 X_k forced true and P_v <=_2 X_k, P_v <=_3 X_k forced false;
for k > m the same with worlds 1 and 2 exchanged (world 2 forced).  (k = m-1, m: see the comment in run().)"""
import sys, os, time
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from modules import *
import pp11sat as S
import t2_threshold as T2

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def run(key, n=4):
    geo = pump_geometry(key); a = geo['a']; eps = geo['eps']
    fam = T2.family(geo, n)
    dirs = [(1, -1, 0), (-1, 1, 0), (0, 1, -1), (0, -1, 1), (1, 0, -1), (-1, 0, 1)]
    germs = [Model(path_point(a, d, F(1, 10**7)), eps, name='P%s' % (d,)) for d in dirs]
    P = jd.Pool(dedup([geo['Ca'], geo['Cq']] + fam) + germs, eps, log=lambda *x: None)
    gidx = [P.names.index(g.name) for g in germs]
    close_excluding(P, gidx, cap=400, log=lambda *x: None)
    P.build_records()
    ia = P.names.index('C_a'); fixed = [k for k in range(P.N) if k not in gidx]
    inc = incoherence_map(P)
    I = S.Inst(P, germs=gidx, germ_base=ia, fixed_for_germ=fixed, incoh=inc, log=lambda *x: None)
    v = I.var
    X = [P.names.index('X%d' % k) for k in range(n + 1)]
    d = [P.recmat[x, ia] for x in X]
    pr('\n=== %s: %d models, %d records' % (key, P.N, P.R))
    Sv = I.solver()
    allok = True
    for m in range(1, n + 1):
        ass = [v(d[k], 1) if k < m else v(d[k], 0) for k in range(n + 1)]
        if not Sv.solve(assumptions=ass): pr('  m=%d: UNSAT (unexpected)' % m); allok = False; continue
        forced = {}
        for g in gidx:
            for k in range(1, n):                      # interior family members
                for w in range(3):
                    lit = v(P.recmat[g, X[k]], w)
                    t_ = Sv.solve(assumptions=ass + [lit]); f_ = Sv.solve(assumptions=ass + [-lit])
                    forced[(g, k, w)] = 'T' if not f_ else ('F' if not t_ else '-')
        pat = {}
        for k in range(1, n):
            pat[k] = sorted(set(''.join(forced[(g, k, w)] for w in range(3)) for g in gidx))
        # discrete family: the cut lemma needs a family member on the same side, so k = m-1 and k = m (the two
        # members adjacent to the threshold) are not forced in a finite pool; in the continuum every k != lambda_0 is.
        ok = all(pat[k] == (['TFF'] if k <= m - 2 else ['FTF']) for k in range(1, n) if k not in (m - 1, m))
        allok &= ok
        pr('  threshold m=%d: forced pattern (worlds 1,2,3) of P_v <= X_k over the six germs, k=1..%d: %s  -> as predicted: %s' % (
            m, n-1, {k: pat[k] for k in range(1, n)}, ok))
    return allok

if __name__ == '__main__':
    keys = sys.argv[1:] or ['e1_3', 'e1_1', 'u_3', 'u_1']
    res = {k: run(k) for k in keys}
    pr('\nSUMMARY', res)
    open(os.path.join(HERE, 't5_pinning.out'), 'w').write('\n'.join(out) + '\n')
