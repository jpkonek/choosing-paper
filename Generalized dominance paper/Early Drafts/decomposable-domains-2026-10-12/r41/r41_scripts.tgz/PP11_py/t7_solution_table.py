"""PP11 t7: one verified model of the full-module instance (t1), restricted to the brief's named comparisons.

Prints, for the solution found and re-verified by the independent checker, the worlds accepting each
direction of: C_a vs Y_plus (doubly anchored, PP8 F-A), C_a vs Y_minus, Y_plus vs Y_minus, C_a vs the return Z,
Y_plus vs Z, C_q vs the transferred W = C_q with S on the cones, the PP8 F-B triangle (C_a, C_p, Y_plus),
C_a vs C_q, the Theorem-J family d_k, and one germ against Y_plus.  It also reports, for comparison, the
same comparisons under a SECOND solution obtained by asking the solver to flip the Y_plus defence world,
to show that these verdicts are choices, not consequences."""
import sys, os
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from modules import *
import pp11sat as S
import t2_threshold as T2
from t1_module_sat import FB

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

key = sys.argv[1] if len(sys.argv) > 1 else 'e1_3'
geo = pump_geometry(key); a = geo['a']; eps = geo['eps']
base = dedup([geo['Ca'], geo['Cq']] + cube_models(geo))
fam = T2.family(geo, 4)
v, t = FB[key]
Cp = Model(path_point(a, v, t), eps, name='C_p(F-B)')
dirs = [(1, -1, 0), (-1, 1, 0), (0, 1, -1), (0, -1, 1), (1, 0, -1), (-1, 0, 1)]
germs = [Model(path_point(a, d, F(1, 10**7)), eps, name='P%s' % (d,)) for d in dirs]
P = jd.Pool(base + fam[1:-1] + [Cp] + germs, eps, log=lambda *x: None)
frozen = [P.names.index(m.name) for m in fam[1:-1] + [Cp] + germs]
close_excluding(P, frozen, cap=600, log=lambda *x: None)
P.build_records()
gidx = [P.names.index(g.name) for g in germs]; ia = P.names.index('C_a')
fixed = [k for k in range(P.N) if k not in gidx]
inc = incoherence_map(P)
I = S.Inst(P, germs=gidx, germ_base=ia, fixed_for_germ=fixed, incoh=inc, stream=True, log=lambda *x: None)
N = P.names.index
pairs = [('C_a', 'Xa[AAA|S]', 'C_a vs Y_plus'), ('C_a', 'Xa[BBB|S]', 'C_a vs Y_minus'), ('Xa[AAA|S]', 'Xa[BBB|S]', 'Y_plus vs Y_minus'),
         ('C_a', 'Xa[SSS|B]', 'C_a vs Z (return, strict world-1 improvement)'), ('Xa[AAA|S]', 'Xa[SSS|B]', 'Y_plus vs Z'),
         ('C_a', 'C_q', 'C_a vs C_q (selected-selected)'), ('C_a', 'C_p(F-B)', 'C_a vs C_p (F-B)'), ('C_p(F-B)', 'Xa[AAA|S]', 'C_p vs Y_plus (F-B)'),
         ('P(1, -1, 0)', 'Xa[AAA|S]', 'germ P(1,-1,0) vs Y_plus')]
wq = [k for k in range(P.N) if P.recmat[P.names.index('C_q'), k] >= 0 and P.recmat[P.names.index('C_q'), k] == P.rev[P.recmat[ia, N('Xa[AAA|S]')]]]
if wq: pairs.append(('C_q', P.names[wq[0]], 'C_q vs W (= C_q with S on the cones; (IB) transfer of rev(C_a,Y_plus))'))
def show(model, tag):
    pr('\n%s:' % tag)
    for x, y, lab in pairs:
        r = P.recmat[N(x), N(y)]; rb = P.rev[r]
        pr('   %-62s  %s<=: %-9s  >=: %-9s   faces fwd %s / rev %s' % (lab, '', [w+1 for w in range(3) if model[r, w]], [w+1 for w in range(3) if model[rb, w]],
                                                                   [tuple(i+1 for i in I_) for I_ in P.faces[r]], [tuple(i+1 for i in I_) for I_ in P.faces[rb]]))
    Xk = ['Xa[ASS|S]', 'X1', 'X2', 'X3', 'Xa[SAS|S]']
    pr('   Theorem-J family d_k = rec(X_k, C_a), k = 0..4: worlds accepting %s' % [[w+1 for w in range(3) if model[P.recmat[N(x), ia], w]] for x in Xk])
ok, model = I.solve()
pr('%s: full module SAT %s; independent check %s' % (key, ok, S.check(P, model, germs=gidx, germ_base=ia, fixed_for_germ=fixed, incoh=inc)))
show(model, 'solution 1')
# second solution: force the defence of C_a against Y_plus to a different world set
r = P.recmat[ia, N('Xa[AAA|S]')]
cur = [w for w in range(3) if model[r, w]]
alt = None
for w in range(3):
    if w in cur: continue
    Sv = I.solver()
    if Sv.solve(assumptions=[I.var(r, w)] + [-I.var(r, u) for u in cur]):
        m = Sv.get_model(); mv = {abs(l): l > 0 for l in m}
        alt = np.zeros((P.R, 3), dtype=bool)
        for rr in range(P.R):
            for ww in range(3):
                vv = I.var(rr, ww); alt[rr, ww] = I.fix[vv] if vv in I.fix else mv.get(vv, False)
        break
if alt is not None:
    pr('\nsecond solution (defence of C_a against Y_plus moved to world %d): independent check %s' % (w+1, S.check(P, alt, germs=gidx, germ_base=ia, fixed_for_germ=fixed, incoh=inc)))
    show(alt, 'solution 2')
open(os.path.join(HERE, 't7_solution_table_%s.out' % key), 'w').write('\n'.join(out) + '\n')
