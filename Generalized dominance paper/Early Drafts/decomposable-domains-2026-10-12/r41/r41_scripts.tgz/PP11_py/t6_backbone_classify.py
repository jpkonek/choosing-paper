"""PP11 t6: what the axioms force on the full module (e1_3): classification of the backbone of t1's instance.

Guidance pinning (Lemma P2): if a fixed W strictly improves C_a pointwise at two worlds u,v, then
{p : C_p <=_u W}, {p : C_p <=_v W} are closed and miss a, so for p near a competitiveness pins C_p <=_w W
(w the third world).  (TC) then refuses Z <=_w C_p for every Z with W <_w Z by guidance.
The simplest closedness consequence is listed first: if C_a <=_w X is refused by strict (G), then
C_p <=_w X is refused for p near a.  Each forced literal is tested against these explanations."""
import sys, os, time
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from modules import *
import pp11sat as S
import t2_threshold as T2
from t1_module_sat import FB

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

key = sys.argv[1] if len(sys.argv) > 1 else 'e1_3'
geo = pump_geometry(key); a = geo['a']; eps = geo['eps']
base = dedup([geo['Ca'], geo['Cq']] + cube_models(geo))
fam = T2.family(geo, 4)[1:-1]
v, t = FB[key]
Cp = Model(path_point(a, v, t), eps, name='C_p(F-B)')
dirs = [(1, -1, 0), (-1, 1, 0), (0, 1, -1), (0, -1, 1), (1, 0, -1), (-1, 0, 1)]
germs = [Model(path_point(a, d, F(1, 10**7)), eps, name='P%s' % (d,)) for d in dirs]
P = jd.Pool(base + fam + [Cp] + germs, eps, log=lambda *x: None)
frozen = [P.names.index(m.name) for m in fam + [Cp] + germs]
close_excluding(P, frozen, cap=600, log=lambda *x: None)
P.build_records()
gidx = [P.names.index(g.name) for g in germs]; ia = P.names.index('C_a')
fixed = [k for k in range(P.N) if k not in gidx]
inc = incoherence_map(P)
I = S.Inst(P, germs=gidx, germ_base=ia, fixed_for_germ=fixed, incoh=inc, stream=True, log=lambda *x: None)
ok, model = I.solve()
bb = I.backbone(model)
rm = P.recmat
def strict_impr(x, y, w):   # y strict pointwise improvement of x at w  <=> rec(x,y) is strictly forbidden at w
    return bool(P.G[P.rev[rm[x, y]], w]) and x != y
pinned = {}   # (germ, W, w) pinned true by Lemma P2
for g in gidx:
    for W in fixed:
        if W == ia: continue
        imp = [w for w in range(3) if strict_impr(ia, W, w)]
        if len(imp) == 2:
            w = [x for x in range(3) if x not in imp][0]; pinned[(g, W, w)] = True
cnt = {'closedness refusal (germ <= X refused, C_a <=_w X refused by strict (G))': 0,
       'pin-true (germ <= W)': 0, 'TC-refusal (Z <= germ) via pinned W <_w Z': 0, 'other': 0}
other = []
for (r, w, val) in bb:
    us, vs = np.nonzero(rm == r)
    ctx = list(zip(us.tolist(), vs.tolist()))
    exp = None
    for (x, y) in ctx:
        if (not val) and x in gidx and y in fixed and strict_impr(ia, y, w):
            exp = 'closedness refusal (germ <= X refused, C_a <=_w X refused by strict (G))'; break
        if val and x in gidx and pinned.get((x, y, w)): exp = 'pin-true (germ <= W)'; break
        if (not val) and y in gidx:
            for W in fixed:
                if pinned.get((y, W, w)) and strict_impr(x, W, w): exp = 'TC-refusal (Z <= germ) via pinned W <_w Z'; break
            if exp: break
    if exp is None: exp = 'other'; other.append((r, w, val))
    cnt[exp] += 1
pr('%s: backbone %d literals; classification %s' % (key, len(bb), cnt))
# obligations carried by the records of forced literals
ob = {'forced-false on a record with a face obligation': 0, 'of which the face has another world available': 0,
      'TC-refusals (Z <= germ) whose record has any face obligation': 0}
for (r, w, val) in bb:
    if val: continue
    fs = [I_ for I_ in P.faces[r] if w in I_]
    if fs:
        ob['forced-false on a record with a face obligation'] += 1
        if all(len(I_) > 1 for I_ in fs): ob['of which the face has another world available'] += 1
    us, vs = np.nonzero(rm == r)
    if any(y in gidx for y in vs.tolist()) and P.faces[r]: ob['TC-refusals (Z <= germ) whose record has any face obligation'] += 1
pr('   obligations on forced refusals: %s' % ob)
for r, w, val in other[:20]: pr('   unexplained:', S.describe_rec(P, r), 'world', w+1, val)
open(os.path.join(HERE, 't6_backbone_classify_%s.out' % key), 'w').write('\n'.join(out) + '\n')
