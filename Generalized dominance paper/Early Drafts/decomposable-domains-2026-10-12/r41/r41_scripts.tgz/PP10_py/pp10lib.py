"""PP10 library: the union rule R_U and an unrestricted SAT screen on PP8's exact pools.

R_U at world i (record-based):
    d in R_U,i  iff  d is a pointwise weak world-i worsening (guidance, incl. identity)
                 or  [A(d) != {}  and  max(dE_i(d), dV_i(d)) >= 0],
    with E_i = int r_i dmu (= nu(U_i), PP7's L_i), J_i = int_{M_i} r_i dmu, V_i = E_i + J_i.
Every sign used is certified against PP8's rigorous per-cell error radii (arb); uncertified signs are counted.
Imports PP8's library (jd.py, pp7core.py) read-only."""
import sys, os, itertools, time
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'PP8_py'))
from jd import *
from configs import *

def add_J(P):
    """dJ[r,i] = int_{D cap M_i} (r_i(new)-r_i(old)) dmu, with error radius."""
    cl = np.array([(-1 if cls(g) == 'U' else cls(g)) for g in P.g])
    P.cl = cl
    R = P.R
    P.dJ = np.zeros((R, 3)); P.dJe = np.zeros((R, 3))
    for r in range(R):
        D = P.rD[r]
        dl = P.rk[D, P.rnew[r], :].astype(int) - P.rk[D, P.rold[r], :].astype(int)
        m = P.mf[D]; e = P.mrad[D]
        for i in range(3):
            sel = cl[D] == i
            P.dJ[r, i] = (dl[sel, i]*m[sel]).sum()
            P.dJe[r, i] = (np.abs(dl[sel, i])*e[sel]).sum() + (len(D)+2)*EPSM*(np.abs(dl[sel, i])*m[sel]).sum()
    P.dV = P.b + P.dJ; P.dVe = P.be + P.dJe

def union_rule(P):
    """acc[r,i] for R_U; also returns counts of uncertified signs that mattered."""
    R = P.R
    acc = np.zeros((R, 3), dtype=bool); unc = 0
    for r in range(R):
        for i in range(3):
            if P.G[r, i]: acc[r, i] = True; continue
            if not P.Anon[r]: continue
            m = max(P.b[r, i], P.dV[r, i])
            if m >= 0: acc[r, i] = True
            if abs(P.b[r, i]) <= P.be[r, i] or abs(P.dV[r, i]) <= P.dVe[r, i]:
                if max(P.b[r, i] + P.be[r, i], P.dV[r, i] + P.dVe[r, i]) >= 0 and min(P.b[r, i] - P.be[r, i], P.dV[r, i] - P.dVe[r, i]) < 0 \
                   and not (P.b[r, i] - P.be[r, i] >= 0 or P.dV[r, i] - P.dVe[r, i] >= 0):
                    unc += 1
    return acc, unc

def faces_all(P):
    """Anon and faces already computed by build_records (the anchor faces of each record)."""
    return P.faces

def violating_triples(P, acc, i, limit=None):
    M = P.relation(acc, i)
    out = []
    for x in range(P.N):
        zs = M[:, x] & ~M[x, :]
        if not zs.any(): continue
        ys = M[x].copy(); ys[x] = False
        yi = np.nonzero(ys)[0]; zi = np.nonzero(zs)[0]
        V = M[np.ix_(yi, zi)]
        a, c = np.nonzero(V)
        for k in range(len(a)):
            out.append((x, int(yi[a[k]]), int(zi[c[k]])))
            if limit and len(out) >= limit: return out
    return out

def typ(P, r, i):
    if P.G[r, i]: return 'G'
    e, v = P.b[r, i], P.dV[r, i]
    if e >= 0 and v >= 0: return 'N'
    if e < 0 <= v: return 'V'
    if v < 0 <= e: return 'E'
    return '-'

EDGES = [(0, 1), (0, 2), (1, 2)]
def boundary_anchored(P, r):
    return any(len(I) < 3 for I in P.faces[r])

def rule_VE(P, fallback='all'):
    """R_VE: guidance; anchored with dV_i >= 0; edge fallback: A(d) meets edge I containing i, dE_i >= 0 and
    max_{j in I} dV_j <= 0.  fallback='argmax' keeps only the edge worlds with maximal dE (closed version: all maximisers)."""
    R = P.R
    acc = np.zeros((R, 3), dtype=bool); src = np.zeros((R, 3), dtype='<U1'); src[:] = '-'
    for r in range(R):
        for i in range(3):
            if P.G[r, i]: acc[r, i] = True; src[r, i] = 'G'; continue
            if not P.Anon[r]: continue
            if P.dV[r, i] >= 0: acc[r, i] = True; src[r, i] = 'V'; continue
        if not P.Anon[r]: continue
        for I in EDGES:
            if I not in P.faces[r]: continue
            if max(P.dV[r, j] for j in I) > 0: continue
            cand = [i for i in I if P.b[r, i] >= 0]
            if fallback == 'argmax' and cand:
                mx = max(P.b[r, i] for i in cand); cand = [i for i in cand if P.b[r, i] == mx]
            for i in cand:
                if not acc[r, i]: acc[r, i] = True; src[r, i] = 'E'
    return acc, src
