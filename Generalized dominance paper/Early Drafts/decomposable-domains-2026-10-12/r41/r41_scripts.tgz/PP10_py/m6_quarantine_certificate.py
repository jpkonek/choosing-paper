"""PP10 m6: certificates for Theorem D (section quarantine) at PP8's e1_3 pump base a = (9/10,1/20,1/20), eps = 3/10.

Path p(t) = (1-t) a + t e_3, t >= 0 (min coordinate stays at index 2, so PP9 Lemma H applies: C_{p(t)} is a pointwise
weak world-3 improvement of C_a).
 (1) dL_1/dt and dL_2/dt are enclosed in intervals > 0 for ALL t in [0, T1] (interval forward-mode derivative of PP6's
     closed-form L, mpmath iv, 40 digits, t treated as an interval).  Hence beta_w(t) = L_w(C_a) - L_w(C_{p(t)}) < 0 for
     w = 1, 2 and all t in (0, T1]: C_a is additively strictly better than C_{p(t)} at worlds 1 AND 2.
 (2) C_{p(t)} is silent on PP8's cones R_1, R_2 (exact: strict lower-prevision inequalities at the cone rays, linear in
     p on the chamber {p_2 = min}, checked at t = 0 and t = T2, hence on [0, T2] by convexity).
 (3) mu(R_1) > mu(R_2) (arb-certified), so by the intermediate value theorem a nested sub-cone S_1(s*) of R_1 has
     mu(S_1(s*)) = mu(R_2) exactly; Y* = C_a with majority advice on S_1(s*) and R_2 is a strict pointwise world-3
     improvement of C_a with b_1(rec(C_a,Y*)) = b_2(rec(C_a,Y*)) = 0.
 (4) Sample check (exact pool, certified cell masses) that J_3(C_{p(t)}) < J_3(C_a) at t = 1e-6 (used only for the remark
     on J_3-first lexicographic rankings)."""
import sys, os
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from pp10lib import *
OUT_HERE = HERE = os.path.dirname(os.path.abspath(__file__))   # jd.py exports its own HERE; outputs go to PP10_py
from mpmath import iv, mpf
iv.dps = 40
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

class D:
    """dual interval numbers (value, derivative)."""
    def __init__(s, v, d=0): s.v = iv.mpf(v) if not isinstance(v, type(iv.mpf(0))) else v; s.d = iv.mpf(d) if not isinstance(d, type(iv.mpf(0))) else d
    def __add__(s, o): o = o if isinstance(o, D) else D(o); return D(s.v + o.v, s.d + o.d)
    __radd__ = __add__
    def __sub__(s, o): o = o if isinstance(o, D) else D(o); return D(s.v - o.v, s.d - o.d)
    def __rsub__(s, o): return D(o) - s
    def __mul__(s, o): o = o if isinstance(o, D) else D(o); return D(s.v*o.v, s.d*o.v + s.v*o.d)
    __rmul__ = __mul__
def dsqrt(x): r = iv.sqrt(x.v); return D(r, x.d/(2*r))
def datan2(n, d):
    den = n.v*n.v + d.v*d.v
    return D(iv.atan2(n.v, d.v), (n.d*d.v - n.v*d.d)/den)
def ddot(x, y): return x[0]*y[0] + x[1]*y[1] + x[2]*y[2]
def dcross(x, y): return (x[1]*y[2]-x[2]*y[1], x[2]*y[0]-x[0]*y[2], x[0]*y[1]-x[1]*y[0])
def th(x, y):
    c = dcross(x, y); return datan2(dsqrt(ddot(c, c)), ddot(x, y))

def L_dual(a, eps, t):
    """L_i(C_{p(t)}) with derivative in t, p(t) = (1-t)a + t e3, min at index 2 (requires t >= 0)."""
    T = D(t, 1)
    one = D(1)
    p = [D(a[0])*(one - T), D(a[1])*(one - T), D(a[2])*(one - T) + T]
    m = D(a[1])*(one - T)
    e = D(iv.mpf(eps.numerator)/eps.denominator)
    V = [[p[i] - e*m + (D(3)*e*m if i == j else D(0)) for i in range(3)] for j in range(3)]
    E = [[D(1), D(0), D(0)], [D(0), D(1), D(0)], [D(0), D(0), D(1)]]
    out_ = []
    for i in range(3):
        j, k = [x for x in range(3) if x != i]
        s = th(E[i], V[j]) + th(E[i], V[k]) + th(V[j], V[k])*D(iv.mpf(0.5)) - th(V[i], V[j])*D(iv.mpf(0.5)) - th(V[i], V[k])*D(iv.mpf(0.5))
        out_.append(D(s.v/iv.pi, s.d/iv.pi))
    return out_

if __name__ == '__main__':
    a = PP5_A; eps = F(3, 10)
    for T1 in ('1e-3', '1e-2'):
        tI = iv.mpf(['0', T1])
        Ld = L_dual([iv.mpf(x.numerator)/x.denominator for x in a], eps, tI)
        pr('(1) t in [0, %s]: enclosure of dL_i/dt (i=1,2,3):' % T1, [str(x.d) for x in Ld])
        pr('    dL_1/dt > 0 and dL_2/dt > 0 on the whole interval: %s' % (Ld[0].d.a > 0 and Ld[1].d.a > 0))
    # consistency with the float formula
    for t in (1e-6, 1e-4):
        p = tuple(float((1-t)*a[k]) + (t if k == 2 else 0) for k in range(3))
        La, Lp = L_float(a, eps), L_float(p, eps)
        pr('    float check t=%g: beta = %s' % (t, [La[i]-Lp[i] for i in range(3)]))
    # (2) silence on R_1, R_2 at t = 0 and t = T2
    ms, q = cfg_pp5_pump(a, eps); Ca, Cq, Y, Z = ms
    cones = [r for r, _ in Y.ov]
    T2 = F(1, 10**5)
    def silent_strict(p, cone):
        k = min(range(3), key=lambda j: p[j])   # chamber index (ties: index 1 for a, also valid)
        ok = True
        for r in cone:
            for sgn in (+1, -1):
                c = lin_lowprev(r, k, sgn, eps)
                if not (sum(c[j]*p[j] for j in range(3)) < 0): ok = False
        return ok
    for t in (F(0), T2):
        p = tuple((1-t)*a[k] + (t if k == 2 else 0) for k in range(3))
        pr('(2) t = %s: C_p strictly silent at every ray of R_1, R_2 (both lower previsions < 0, chamber k=2): %s' % (
            t, [silent_strict(p, cones[w]) for w in (0, 1)]))
    # (3) masses
    mR = [mass_arb(list(c)) for c in cones]
    pr('(3) mu(R_1) =', mR[0], ' mu(R_2) =', mR[1], ' mu(R_1) > mu(R_2) certified:', bool((mR[0] - mR[1]) > 0))
    g1 = interior(list(cones[0])); g2 = interior(list(cones[1]))
    pr('    world-3 ranks on R_1, R_2: C_a (silent) %s -> majority %s' % ([rank(Ca.advice(g), g, 2) for g in (g1, g2)],
       [rank(adv_from_label(g, 'A'), g, 2) for g in (g1, g2)]))
    # (4) J_3 sample
    for kk in (6, 8, 10, 12):
        t = F(1, 10**kk)
        Cp = Model(tuple((1-t)*a[k] + (t if k == 2 else 0) for k in range(3)), eps, name='C_p(e3,1e-%d)' % kk)
        P = Pool([Ca, Cp], eps, log=pr); P.build_records(); add_J(P)
        r = P.recmat[0, 1]
        pr('(4) t=1e-%d rec(C_a, C_p): dE =' % kk, P.b[r], '+-', P.be[r], '; dJ =', P.dJ[r], '+-', P.dJe[r], '; rec(C_p,C_a) world-3 guidance:', P.G[P.rev[r], 2])
        pr('    J_3(C_p) < J_3(C_a) certified:', bool(P.dJ[r, 2] + P.dJe[r, 2] < 0), '; beta_1, beta_2 < 0 certified:', bool((-P.b[r, :2] + P.be[r, :2] < 0).all()))
    open(os.path.join(HERE, 'm6_quarantine_certificate.out'), 'w').write('\n'.join(out) + '\n')
