"""PP10 m8: diagnose the pool-mode UNSAT that m4 (closure cap 100) gave with the FIRST, unfiltered quarantine proxy: which quarantine units matter, their R_VE status,
the masses involved, and what the free-mode solution accepts outside R_VE."""
import sys, os, time
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from pp10lib import *
OUT_HERE = HERE = os.path.dirname(os.path.abspath(__file__))   # jd.py exports its own HERE; outputs go to PP10_py
from m4_sat_screen import build, quarantine_list, solve
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)
def recname(P, r):
    u, v = P.contexts(r)[0]; return 'rec(%s,%s)' % (P.names[u], P.names[v])

if __name__ == '__main__':
    cap = int(sys.argv[1]) if len(sys.argv) > 1 else 100
    P = build(closure_cap=cap)
    acc, src = rule_VE(P, fallback='all')
    Q = quarantine_list(P, filtered=False)
    ia = P.names.index('C_a')
    for (r, i) in Q:
        u, v = P.contexts(r)[0]
        ra = P.recmat[ia, v]
        pr('quarantine %s at world 3: R_VE accepts? %s (src %s); dE_3=%.4g dV_3=%.4g (e-6); size of rival vs C_a: dE(C_a->Y)=%s' % (
            recname(P, r), acc[r, i], src[r, i], P.b[r, i]*1e6, P.dV[r, i]*1e6, np.round(P.b[ra]*1e6, 4)))
        pr('     other worlds for this record under R_VE: %s; dV=%s dE=%s' % ([w+1 for w in range(3) if acc[r, w]], np.round(P.dV[r]*1e6, 4), np.round(P.b[r]*1e6, 4)))
    # single-unit tests
    for k, (r, i) in enumerate(Q):
        ok, A, _, _ = solve(P, 'pool', allowed=acc, quarantine=[(r, i)], notie=False)
        pr('pool mode with only quarantine unit %d (%s): %s' % (k, recname(P, r), 'SAT' if ok else 'UNSAT'))
    ok, A, _, _ = solve(P, 'free', allowed=acc, quarantine=Q, notie=True)
    extra = [(r, w) for r in range(P.R) for w in range(3) if A[r, w] and not acc[r, w]]
    kinds = {}
    for r, w in extra:
        k = (w+1, typ(P, r, w), 'anch' if P.Anon[r] else 'unanch')
        kinds[k] = kinds.get(k, 0) + 1
    pr('free solution: %d acceptances outside R_VE, by (world, (dE,dV) type, anchored): %s' % (len(extra), kinds))
    open(os.path.join(HERE, 'm8_core.out'), 'w').write('\n'.join(out) + '\n')
