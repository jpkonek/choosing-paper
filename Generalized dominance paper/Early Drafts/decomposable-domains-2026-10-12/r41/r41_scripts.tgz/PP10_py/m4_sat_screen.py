"""PP10 m4: exact SAT screen of the coupled module (discovery only; finite pools cannot establish a rule).
Variables x[r,i]: record r accepted at world i, jointly for every record of the pool (defences, reverses,
returns, selected-to-selected, rival-to-rival), with NO priced initial order.  Constraints:
  reflexive; guidance compulsory, strict-guidance reverse forbidden;  (TC) on every ordered triple at every world;
  every face obligation of every record (exact anchors);  no dominated selected model;  no all-world tie of a
  selected model with a non-selected model (stronger than direct (C); OPTIONAL test, reported separately);
  section proxy (Q): world 3 refuses rec(C_p, Y) at the path point p = (1-t)a + t e_3 (t = 1e-6) when Y is a strict
  pointwise world-3 improvement of C_a (closedness of {p : C_p <=_3 Y} at a plus strict (G): PP10 Theorem D).  The
  theorem forces refusal only for t below a rival-dependent t_0, so the unit is imposed only when every score sign
  (dE_w, dV_w, w = 1,2,3) of rec(C_p,Y) equals that of the limit record rec(C_a,Y).  (A first version without this
  validity filter produced a spurious pool-mode UNSAT through a rival smaller than the selected shift; see m8_core.out.)
Modes: 'free' (any non-forbidden record may be accepted) and 'pool' (only records of R_VE may be accepted)."""
import sys, os, time
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from pp10lib import *
OUT_HERE = HERE = os.path.dirname(os.path.abspath(__file__))   # jd.py exports its own HERE; outputs go to PP10_py
from m3_rule_VE import rivals
from pysat.solvers import Cadical153
from pysat.formula import IDPool
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def solve(P, mode, allowed=None, quarantine=(), notie=True, extra_units=(), want_core=False):
    vp = IDPool()
    R, N = P.R, P.N
    X = lambda r, i: vp.id(('x', r, i))
    cl = []
    fixed = {}
    for r in range(R):
        for i in range(3):
            if P.G[r, i]: fixed[(r, i)] = True
            elif P.G[P.rev[r], i]: fixed[(r, i)] = False
            elif mode == 'pool' and not allowed[r, i]: fixed[(r, i)] = False
    for (r, i) in quarantine: fixed[(r, i)] = False
    for (r, i), v in fixed.items(): cl.append([X(r, i) if v else -X(r, i)])
    def lit(r, i, pos=True):
        return X(r, i) if pos else -X(r, i)
    # obligations
    for r in range(R):
        for I in P.faces[r]: cl.append([X(r, i) for i in I])
    # TC: x<=y, y<=z, z<=x  ->  x<=z   (clause: -xy v -yz v -zx v xz)
    nt = 0
    for i in range(3):
        for x in range(N):
            for y in range(N):
                if y == x: continue
                rxy = P.recmat[x, y]
                if fixed.get((rxy, i)) is False: continue
                for z in range(N):
                    if z == x or z == y: continue
                    ryz = P.recmat[y, z]; rzx = P.recmat[z, x]; rxz = P.recmat[x, z]
                    if fixed.get((ryz, i)) is False or fixed.get((rzx, i)) is False: continue
                    if fixed.get((rxz, i)) is True: continue
                    c = [-X(rxy, i), -X(ryz, i), -X(rzx, i)]
                    if fixed.get((rxz, i)) is not False: c.append(X(rxz, i))
                    cl.append(c); nt += 1
    sel = [k for k in range(N) if P.selp[k] is not None]
    # undominated: not( all_i x[X->s] and exists j not x[s->X] )
    for s in sel:
        for x in range(N):
            if x == s: continue
            a_ = P.recmat[x, s]; b_ = P.recmat[s, x]
            for j in range(3):
                cl.append([-X(a_, i) for i in range(3)] + [X(b_, j)])
            if notie and P.selp[x] is None:
                cl.append([-X(a_, i) for i in range(3)] + [-X(b_, i) for i in range(3)])
    for u in extra_units: cl.append(list(u))
    S = Cadical153(bootstrap_with=cl)
    ok = S.solve()
    model = S.get_model() if ok else None
    S.delete()
    acc = None
    if ok:
        ms = set(v for v in model if v > 0)
        acc = np.zeros((R, 3), dtype=bool)
        for r in range(R):
            for i in range(3): acc[r, i] = X(r, i) in ms
    return ok, acc, len(cl), nt

def build(closure_cap=None):
    a = PP5_A; eps = F(3, 10)
    ms, q = cfg_pp5_pump(a, eps)
    Ca, Cq, Y, Z = ms
    cones = [r for r, _ in Y.ov]
    t = F(1, 10**6)
    Cp1 = Model(tuple(a[k] + t*v for k, v in enumerate((1, -1, 0))), eps, name='Cp_FB')
    Cp3 = Model(tuple((1-t)*a[k] + (t if k == 2 else 0) for k in range(3)), eps, name='Cp_e3')
    extra = rivals(Ca, cones, [(1, 1, F(1, 5)), (1, F(9, 10), F(1, 5)), (F(9, 10), 1, F(1, 5)), (1, 1, 0)], 'A') \
          + rivals(Ca, cones, [(1, 1, 1), (1, F(1, 2), F(1, 2))], 'B')
    P = Pool([Ca, Cp1, Cp3, Cq, Y, Z] + extra, eps, log=pr)
    if closure_cap: P.close(cap=closure_cap)
    P.build_records(); add_J(P)
    return P

def quarantine_list(P, filtered=True):
    """(rec(C_p, Yk), world 3) for path point Cp_e3 and rivals Yk that are strict pointwise world-3 improvements of C_a."""
    ia = P.names.index('C_a'); ip = P.names.index('Cp_e3')
    q = []
    for k in range(P.N):
        if k in (ia, ip) or P.selp[k] is not None: continue
        r = P.recmat[ia, k]
        if P.G[P.rev[r], 2] and not P.G[r, 2]:       # rec(Y, C_a) is a worsening at 3, i.e. Y improves 3
            rp = P.recmat[ip, k]
            # proxy validity: the path point is 'close enough' only if every score sign of rec(C_p,Y) equals that of
            # the limit record rec(C_a,Y) (closedness forces refusal only for t below a rival-dependent t_0)
            same = all(np.sign(P.b[rp, w]) == np.sign(P.b[r, w]) and np.sign(P.dV[rp, w]) == np.sign(P.dV[r, w]) for w in range(3))
            if same or not filtered: q.append((rp, 2))
    return q

if __name__ == '__main__':
    cap = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    P = build(closure_cap=cap or None)
    accVE, src = rule_VE(P, fallback='all')
    Q = quarantine_list(P)
    pr('pool: %d models, %d records; quarantine units: %s' % (P.N, P.R, [(P.names[P.contexts(r)[0][1]], i+1) for r, i in Q]))
    for mode in ('free', 'pool'):
        for quar in (False, True):
            for notie in (False, True):
                t0 = time.time()
                ok, acc, ncl, nt = solve(P, mode, allowed=accVE, quarantine=Q if quar else (), notie=notie)
                pr('mode=%-4s quarantine=%-5s no-incoherent-ties=%-5s: %s  (%d clauses, %d TC clauses, %.1fs)' % (
                    mode, quar, notie, 'SAT' if ok else 'UNSAT', ncl, nt, time.time()-t0))
                if ok:
                    chk = P.tc_check(acc); ob = P.obligations(acc); dom, ties = P.selected_checks(acc)
                    pr('      re-check: TC %s, obligations unmet %d, dominated %d, ties %d' % (chk, len(ob), len(dom), len(ties)))
    open(os.path.join(HERE, 'm4_sat_screen%s.out' % ('_cap%d' % cap if cap else '')), 'w').write('\n'.join(out) + '\n')
