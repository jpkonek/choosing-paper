"""PP10 m1: directions v at a (PP8's e1_3 pump base a = (9/10,1/20,1/20), eps = 3/10) along which C_{a+tv} is
additively worse than C_a at BOTH worlds 1 and 2 (beta_1, beta_2 < 0), and the world-3 minority-class loss J_3
moves.  Float scan (NUMERICS) using PP6's closed-form L (pp7core.L_float); J_3 by cell integration."""
import sys, os, math
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'PP8_py'))
from pp7core import *
from configs import *
a = PP5_A; eps = F(3, 10)
La = L_float(a, eps)
out = []
def pr(*x):
    s = ' '.join(str(t) for t in x); print(s, flush=True); out.append(s)
pr('L(C_a) =', La)
for t in (1e-4, 1e-5):
    for ang in range(0, 360, 15):
        v = (math.cos(math.radians(ang)), math.sin(math.radians(ang)))
        d = (v[0], -v[0]/2 + v[1]*math.sqrt(3)/2, -v[0]/2 - v[1]*math.sqrt(3)/2)
        p = tuple(float(a[k]) + t*d[k] for k in range(3))
        Lp = L_float(p, eps)
        beta = [La[i] - Lp[i] for i in range(3)]
        tag = 'BOTH_1_2_WORSE' if beta[0] < 0 and beta[1] < 0 else ''
        pr('t=%g ang=%3d d=(%+.3f,%+.3f,%+.3f) beta=(%+.3e,%+.3e,%+.3e) %s' % (t, ang, d[0], d[1], d[2], beta[0], beta[1], beta[2], tag))
open(os.path.join(HERE, 'm1_selected_directions.out'), 'w').write('\n'.join(out) + '\n')
