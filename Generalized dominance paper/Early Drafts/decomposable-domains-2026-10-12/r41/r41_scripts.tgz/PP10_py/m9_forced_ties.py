"""PP10 m9: data for Proposition 4.3 (forced V-ties): around a and around q (PP8's e1_3 pump indices), the vector
v(p) = V(C_x) - V(C_p) (x = a or q) has, for EACH world i, a certified positive i-th coordinate at some p at distance
1e-6, with C_p still silent on R (around a) / still majority on R (around q).  Also checks sum_i v_i(p) = 0 (V-sum is
constant on regular models).  CHECKED: exact cells, certified masses; exact ray tests for silence/majority."""
import sys, os, math
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from pp10lib import *
OUT_HERE = HERE = os.path.dirname(os.path.abspath(__file__))
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def ray_test(p, cone, eps, want):
    k = min(range(3), key=lambda j: p[j])
    for r in cone:
        Pp = sum(c*x for c, x in zip(lin_lowprev(r, k, +1, eps), p)); Pm = sum(c*x for c, x in zip(lin_lowprev(r, k, -1, eps), p))
        if want == 'S' and not (Pp < 0 and Pm < 0): return False
        if want == 'A':
            g = interior(list(cone)); sgn = +1 if adv_from_label(g, 'A') == '+' else -1
            if not ((Pp > 0) if sgn > 0 else (Pm > 0)): return False
    return True

if __name__ == '__main__':
    a = PP5_A; eps = F(3, 10)
    ms, q = cfg_pp5_pump(a, eps); Ca, Cq, Y, Z = ms
    cones = [r for r, _ in Y.ov]
    dirs = [(1, -1, 0), (-1, 1, 0), (0, 1, -1), (0, -1, 1), (1, 0, -1), (-1, 0, 1), (2, -1, -1), (-2, 1, 1), (-1, -1, 2), (1, 1, -2)]
    for base, B, want in (('a', Ca, 'S'), ('q', Cq, 'A')):
        x = B.p; t = F(1, 10**6)
        found = [None]*3
        for v in dirs:
            p = tuple(x[k] + t*v[k] for k in range(3))
            if not all(ray_test(p, c, eps, want) for c in cones): pr('  %s + 1e-6 %s: advice on R changes, skipped' % (base, v)); continue
            Cp = Model(p, eps, name='p')
            P = Pool([B, Cp], eps, log=lambda *s: None); P.build_records(); add_J(P)
            r = P.recmat[0, 1]
            vv = -(P.dV[r]); ve = P.dVe[r]
            cert = [abs(vv[i]) > ve[i] for i in range(3)]
            pr('  %s + 1e-6 %-11s v = (%+.4e, %+.4e, %+.4e)  sum = %+.2e  signs certified %s' % (base, v, vv[0], vv[1], vv[2], vv.sum(), cert))
            for i in range(3):
                if vv[i] > ve[i] and found[i] is None: found[i] = v
        pr('%s: for each world i a direction with certified v_i > 0: %s' % (base, found))
        for i, v in enumerate(found):
            if v is None: continue
            row = []
            for kk in (6, 8, 10, 12):
                tt = F(1, 10**kk); p = tuple(x[k] + tt*v[k] for k in range(3))
                okr = all(ray_test(p, c, eps, want) for c in cones)
                P = Pool([B, Model(p, eps, name='p')], eps, log=lambda *s: None); P.build_records(); add_J(P)
                r = P.recmat[0, 1]; vv = -P.dV[r, i]; ve = P.dVe[r, i]
                row.append('t=1e-%d: v_%d/t = %+.6f (certified > 0: %s; advice on R unchanged: %s)' % (kk, i+1, vv/float(tt), vv > ve, okr))
            pr('   world %d along %s: ' % (i+1, v) + '; '.join(row))
    open(os.path.join(HERE, 'm9_forced_ties.out'), 'w').write('\n'.join(out) + '\n')
