"""PP10 m7: certified failure instances of the closed covering rule R_VE (argmax fallback) on PP8's e1_3 module:
 (a) a (TC) violation at the fallback world (F-B shape, CHECKED: every decisive sign exceeds its rigorous error bound);
 (b) the dominance created by the plain union rule R_U and by R_VE with fallback at every edge world (CHECKED)."""
import sys, os
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from pp10lib import *
OUT_HERE = HERE = os.path.dirname(os.path.abspath(__file__))   # jd.py exports its own HERE; outputs go to PP10_py
from m3_rule_VE import rivals
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def cert(P, r, i, what):
    if what == 'E': v, e = P.b[r, i], P.be[r, i]
    else: v, e = P.dV[r, i], P.dVe[r, i]
    return v, e, abs(v) > e

if __name__ == '__main__':
    a = PP5_A; eps = F(3, 10)
    ms, q = cfg_pp5_pump(a, eps); Ca, Cq, Y, Z = ms
    cones = [r for r, _ in Y.ov]
    t = F(1, 10**6)
    Cp = Model(tuple(a[k] + t*v for k, v in enumerate((1, -1, 0))), eps, name='C_p')
    Yx = rivals(Ca, cones, [(1, 1, F(1, 5))], 'A')[0]; Yx.name = 'Y_x'
    P = Pool([Ca, Cp, Cq, Yx], eps, log=pr); P.build_records(); add_J(P)
    acc, src = rule_VE(P, fallback='argmax')
    ia, ip, iy = P.names.index('C_a'), P.names.index('C_p'), P.names.index('Y_x')
    i = 1
    links = [('C_a<=C_p', P.recmat[ia, ip]), ('C_p<=Y_x', P.recmat[ip, iy]), ('Y_x<=C_a', P.recmat[iy, ia]), ('C_p<=C_a (reverse)', P.recmat[ip, ia])]
    pr('(a) world 2 triangle C_a <=_2 C_p <=_2 Y_x <=_2 C_a with C_p <=_2 C_a refused; Y_x = C_a + majority on R_1, R_2 and 1/5 of R_3')
    for nm_, r in links:
        vE, eE, cE = cert(P, r, i, 'E'); vV, eV, cV = cert(P, r, i, 'V')
        pr('   %-20s accepted at 2: %-5s (source %s); dE_2 = %+.6e (+-%.1e, certified sign %s); dV_2 = %+.6e (+-%.1e, %s); faces %s' % (
            nm_, acc[r, i], src[r, i], vE, eE, cE, vV, eV, cV, P.faces[r]))
    d = P.recmat[iy, ia]
    pr('   fallback record rec(Y_x,C_a): dV_1, dV_2 =', P.dV[d, :2], '(both < 0: the edge E12 cannot be met by V); dE_1, dE_2 =', P.b[d, :2], '-> argmax world', int(np.argmax(P.b[d, :2]))+1)
    viol = acc[links[0][1], i] and acc[links[1][1], i] and acc[links[2][1], i] and not acc[links[3][1], i]
    pr('   (TC) violation at world 2 certified: %s' % viol)
    # (b) dominance under R_U / R_VE(all)
    accU, _ = union_rule(P); accA, _ = rule_VE(P, fallback='all')
    for lab, A in (('R_U', accU), ('R_VE(all)', accA), ('R_VE(argmax)', acc)):
        dom, ties = P.selected_checks(A)
        pr('(b) %-12s dominated selected models: %s' % (lab, [(P.names[s], P.names[x]) for x, s in dom]))
        r = P.recmat[ia, iy]; e = P.rev[r]
        pr('      C_a<=Y_x at worlds %s ; Y_x<=C_a at worlds %s' % ([w+1 for w in range(3) if A[r, w]], [w+1 for w in range(3) if A[e, w]]))
    open(os.path.join(HERE, 'm7_RVE_certificates.out'), 'w').write('\n'.join(out) + '\n')
