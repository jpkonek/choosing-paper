"""PP10 m0: exact anchor-face table for every old-advice pattern on the module regions of PP8's pump
(e1_3 and the other settings).  Regions: R_1,R_2,R_3 (C_a silent, C_q majority, one cone per class, PP8's
exact cones) and T (lead class, C_a and C_q silent).  For each pattern o in {A,S,B,-}^4 (advice of the
OLD side on that region; '-' = region not in D) we compute A(d) exactly (pp7core.anchor_set, closed weak
constraints at the cone rays) and list the faces it meets.  Uses PP8's unmodified library read-only."""
import sys, os, itertools
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'PP8_py'))
from pp7core import *
from configs import *

FN = {(0,): 'v1', (1,): 'v2', (2,): 'v3', (0, 1): 'E12', (0, 2): 'E13', (1, 2): 'E23', (0, 1, 2): 'int'}
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def region_cells(cone, p, eps):
    # the cone is inside one cell of C_a's arrangement; use the cone itself as the changed cell
    return [list(cone)]

def run(key, world=0):
    a = PP5_A if key == 'e1_3' else SETTINGS[key][0]; eps = SETTINGS[key][1]
    ms, q = cfg_pp5_pump(a, eps, world=world)
    if ms is None: pr(key, 'no pump'); return
    Ca, Cq, Y, Z = ms
    cones = [r for r, _ in Y.ov] + [Z.ov[0][0]]
    names = ['R1', 'R2', 'R3', 'T(M%d)' % (world+1)]
    pr('\n=== %s lead %d  a=%s q=%s' % (key, world+1, tuple(map(str, a)), tuple(map(str, q))))
    for k, c in enumerate(cones):
        g = interior(list(c)); pr('  %s: class M%d, C_a %s, C_q %s' % (names[k], cls(g)+1, label(g, Ca.advice(g)), label(g, Cq.advice(g))))
    table = {}
    for pat in itertools.product('ASB-', repeat=4):
        if all(x == '-' for x in pat): continue
        changed = []
        for k, x in enumerate(pat):
            if x == '-': continue
            c = list(cones[k]); g = interior(c)
            changed.append((c, adv_from_label(g, x), None))
        polys = anchor_set(changed, eps)
        f = faces_met(polys)
        nonempty = any(len(polys[k]) >= 1 for k in polys)
        table[''.join(pat)] = (nonempty, [FN[t] for t in f])
    for pat, (ne, f) in sorted(table.items()):
        pr('  old %s : %s %s' % (pat, 'anchored' if ne else 'EMPTY   ', ' '.join(f)))
    return table

if __name__ == '__main__':
    for key in (sys.argv[1:] or ['e1_3']):
        for w in range(3): run(key, w)
    open(os.path.join(HERE, 'm0_anchor_table_%s.out' % '_'.join(sys.argv[1:] or ['e1_3'])), 'w').write('\n'.join(out) + '\n')
