"""PP10 m5: minimal repair of R_VE(argmax) on the module pool, by exact MaxSAT (RC2): keep as many R_VE
acceptances as possible subject to guidance, (TC), all face obligations, undominatedness, no incoherent all-world
ties, the section quarantine; acceptances may only be REMOVED (pool mode) or also ADDED (free mode, unit cost).
Discovery only (finite pool)."""
import sys, os, time
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from pp10lib import *
OUT_HERE = HERE = os.path.dirname(os.path.abspath(__file__))   # jd.py exports its own HERE; outputs go to PP10_py
from m4_sat_screen import build, quarantine_list, pr as _pr, out as _out
from pysat.formula import WCNF, IDPool
from pysat.examples.rc2 import RC2
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def recname(P, r):
    u, v = P.contexts(r)[0]; return 'rec(%s,%s)' % (P.names[u], P.names[v])

def maxsat(P, base, mode, Q):
    vp = IDPool(); R, N = P.R, P.N
    X = lambda r, i: vp.id(('x', r, i))
    w = WCNF(); fixed = {}
    for r in range(R):
        for i in range(3):
            if P.G[r, i]: fixed[(r, i)] = True
            elif P.G[P.rev[r], i]: fixed[(r, i)] = False
            elif mode == 'pool' and not base[r, i]: fixed[(r, i)] = False
    for (r, i) in Q: fixed[(r, i)] = False
    for (r, i), v in fixed.items(): w.append([X(r, i) if v else -X(r, i)])
    for r in range(R):
        for I in P.faces[r]: w.append([X(r, i) for i in I])
    for i in range(3):
        for x in range(N):
            for y in range(N):
                if y == x: continue
                rxy = P.recmat[x, y]
                if fixed.get((rxy, i)) is False: continue
                for z in range(N):
                    if z == x or z == y: continue
                    ryz = P.recmat[y, z]; rzx = P.recmat[z, x]; rxz = P.recmat[x, z]
                    if fixed.get((ryz, i)) is False or fixed.get((rzx, i)) is False or fixed.get((rxz, i)) is True: continue
                    c = [-X(rxy, i), -X(ryz, i), -X(rzx, i)]
                    if fixed.get((rxz, i)) is not False: c.append(X(rxz, i))
                    w.append(c)
    sel = [k for k in range(N) if P.selp[k] is not None]
    for s in sel:
        for x in range(N):
            if x == s: continue
            a_ = P.recmat[x, s]; b_ = P.recmat[s, x]
            for j in range(3): w.append([-X(a_, i) for i in range(3)] + [X(b_, j)])
            if P.selp[x] is None: w.append([-X(a_, i) for i in range(3)] + [-X(b_, i) for i in range(3)])
    for r in range(R):
        for i in range(3):
            if (r, i) in fixed: continue
            w.append([X(r, i)] if base[r, i] else [-X(r, i)], weight=1)
    rc = RC2(w); m = rc.compute(); cost = rc.cost; rc.delete()
    if m is None: return None, None
    ms = set(v for v in m if v > 0)
    acc = np.zeros((R, 3), dtype=bool)
    for r in range(R):
        for i in range(3): acc[r, i] = X(r, i) in ms
    return acc, cost

if __name__ == '__main__':
    cap = int(sys.argv[1]) if len(sys.argv) > 1 else 40
    P = build(closure_cap=cap)
    base, src = rule_VE(P, fallback='argmax')
    pr('R_VE(argmax) on pool of %d models: TC %s, obligations %d, dominated/ties %s' % (P.N, P.tc_check(base), len(P.obligations(base)),
       [len(x) for x in P.selected_checks(base)]))
    Q = quarantine_list(P)
    pr('quarantined at world 3 by base acceptance:', sum(base[r, i] for r, i in Q), 'of', len(Q))
    for mode in ('pool', 'free'):
        t0 = time.time()
        acc, cost = maxsat(P, base, mode, Q)
        if acc is None: pr('mode %s: UNSAT' % mode); continue
        pr('mode %s: min changes %d (%.1fs); re-check TC %s obligations %d dom/ties %s' % (mode, cost, time.time()-t0, P.tc_check(acc),
           len(P.obligations(acc)), [len(x) for x in P.selected_checks(acc)]))
        rem = [(r, i) for r in range(P.R) for i in range(3) if base[r, i] and not acc[r, i]]
        add = [(r, i) for r in range(P.R) for i in range(3) if acc[r, i] and not base[r, i]]
        kinds = {}
        for r, i in rem:
            k = ('removed', i+1, src[r, i], 'sel-old' if P.selp[P.contexts(r)[0][0]] is not None else 'riv-old', 'rev-anch' if P.Anon[P.rev[r]] else 'rev-unanch')
            kinds[k] = kinds.get(k, 0) + 1
        for r, i in add:
            k = ('added', i+1, typ(P, r, i), 'anch' if P.Anon[r] else 'unanch')
            kinds[k] = kinds.get(k, 0) + 1
        for k, v in sorted(kinds.items()): pr('   %s: %d' % (k, v))
        for r, i in (rem + add)[:25]:
            pr('      %s world %d %s: dE=%.4g dV=%.4g (e-6) faces %s; rev faces %s' % ('-' if (r, i) in rem else '+', i+1, recname(P, r),
               P.b[r, i]*1e6, P.dV[r, i]*1e6, P.faces[r], P.faces[P.rev[r]]))
    open(os.path.join(HERE, 'm5_min_repair_cap%d.out' % cap), 'w').write('\n'.join(out) + '\n')
