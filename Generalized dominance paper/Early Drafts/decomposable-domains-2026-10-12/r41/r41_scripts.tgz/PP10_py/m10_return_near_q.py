"""PP10 m10: the return record of the balanced rival seen from selected models near q.
X = C_q with silence on R_1, R_2 (so rec(C_q, X) = rec(Y12, C_a), Y12 = C_a + majority on R_1 u R_2).
For p = q + 1e-6 dir: faces met by A(rec(C_p, X)) (exact), and dE, dV at worlds 1,2,3 (certified).  Question: does the
edge obligation E12 persist off q (it would force a non-additive, non-V return at the remaining edge world)?"""
import sys, os
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from pp10lib import *
OUT_HERE = HERE = os.path.dirname(os.path.abspath(__file__))
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)
if __name__ == '__main__':
    a = PP5_A; eps = F(3, 10)
    ms, q = cfg_pp5_pump(a, eps); Ca, Cq, Y, Z = ms
    cones = [r for r, _ in Y.ov]
    X = Cq.with_ov([(cones[0], '0'), (cones[1], '0')], name='X')
    t = F(1, 10**6)
    dirs = [(0, 0, 0), (1, -1, 0), (-1, 1, 0), (0, 1, -1), (0, -1, 1), (1, 0, -1), (-1, 0, 1), (2, -1, -1), (-2, 1, 1), (-1, -1, 2), (1, 1, -2)]
    for v in dirs:
        p = tuple(q[k] + t*v[k] for k in range(3))
        Cp = Model(p, eps, name='C_p')
        P = Pool([Cp, X], eps, log=lambda *s: None); P.build_records(); add_J(P)
        r = P.recmat[0, 1]
        pr('p = q + 1e-6 %-11s faces of A(rec(C_p,X)): %-40s dE = %s  dV = %s (e-6)' % (v, P.faces[r], np.round(P.b[r]*1e6, 4), np.round(P.dV[r]*1e6, 4)))
    open(os.path.join(HERE, 'm10_return_near_q.out'), 'w').write('\n'.join(out) + '\n')
