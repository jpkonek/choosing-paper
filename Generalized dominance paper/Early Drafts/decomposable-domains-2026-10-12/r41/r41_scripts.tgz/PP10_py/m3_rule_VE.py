"""PP10 m3: R_VE (V-first, E as edge fallback) on PP8's exact pools plus fractional splice rivals.
CHECKED where stated (exact records/anchors, certified masses); survival in pools is NUMERICS."""
import sys, os
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from pp10lib import *
OUT_HERE = HERE = os.path.dirname(os.path.abspath(__file__))   # jd.py exports its own HERE; outputs go to PP10_py
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def report(P, acc, src, label):
    pr('--- %s' % label)
    pr('(TC) violations per world:', P.tc_check(acc))
    ob = P.obligations(acc); pr('unmet face obligations:', len(ob))
    dom, ties = P.selected_checks(acc)
    pr('dominated selected: %d; all-world ties with selected: %d' % (len(dom), len(ties)))
    for x, s in dom[:6]:
        d = P.recmat[s, x]; e = P.rev[d]
        pr('   %s dominated by %s: fwd src %s rev src %s; b=%s dV=%s' % (P.names[s], P.names[x], list(src[d]), list(src[e]),
           np.round(P.b[d]*1e6, 4), np.round(P.dV[d]*1e6, 4)))
    for x, s, c in ties[:6]: pr('   tie %s ~ %s; incoherence %s' % (P.names[x], P.names[s], c[0] if c else None))
    for i in range(3):
        vt = violating_triples(P, acc, i, limit=50000)
        pats = {}
        for (x, y, z) in vt:
            k = (src[P.recmat[x, y], i], src[P.recmat[y, z], i], src[P.recmat[z, x], i])
            pats[k] = pats.get(k, 0) + 1
        pr('world %d: %d violating ordered triples; source words: %s' % (i+1, len(vt), pats))
        for (x, y, z) in vt[:3]:
            pr('   %s <= %s <= %s <= %s (refused %s<=%s); links (dE,dV)e6: %s %s %s' % (P.names[x], P.names[y], P.names[z], P.names[x], P.names[x], P.names[z],
               np.round([P.b[P.recmat[x, y], i]*1e6, P.dV[P.recmat[x, y], i]*1e6], 4), np.round([P.b[P.recmat[y, z], i]*1e6, P.dV[P.recmat[y, z], i]*1e6], 4),
               np.round([P.b[P.recmat[z, x], i]*1e6, P.dV[P.recmat[z, x], i]*1e6], 4)))

def scaled(cone, frac):
    lo, hi = F(0), F(1); target = frac*mass_float(cone)
    for _ in range(30):
        mid = (lo+hi)/2
        if mass_float(shrunk(cone, mid)) <= target: lo = mid
        else: hi = mid
    return shrunk(cone, lo)

def rivals(Ca, Ycones, fr_list, lab='A'):
    out_ = []
    for fr in fr_list:
        ov = []
        for w, f in enumerate(fr):
            if f == 0: continue
            c = Ycones[w] if f == 1 else scaled(Ycones[w], F(f).limit_denominator(100))
            ov.append((c, adv_from_label(interior(list(c)), lab)))
        out_.append(Ca.with_ov(ov, name='Y%s%s' % (lab, ''.join(str(int(100*f)) for f in fr))))
    return out_

if __name__ == '__main__':
    a = PP5_A; eps = F(3, 10)
    ms, q = cfg_pp5_pump(a, eps)
    Ca, Cq, Y, Z = ms
    cones = [r for r, _ in Y.ov]
    for v, t in (((1, -1, 0), F(1, 10**6)), ((-1, -1, 2), F(1, 10**6))):
        p = tuple(a[k] + t*v[k] for k in range(3))
        Cp = Model(p, eps, name='C_p%s' % (v,))
        base = [Ca, Cp, Cq, Y, Z]
        extra = rivals(Ca, cones, [(1, 1, F(1, 5)), (1, F(9, 10), F(1, 5)), (F(9, 10), 1, F(1, 5)), (1, 1, 0)], 'A') \
              + rivals(Ca, cones, [(1, 1, 1), (1, F(1, 2), F(1, 2))], 'B')
        P = Pool(base + extra, eps, log=pr)
        P.build_records(); add_J(P)
        for fb in ('all', 'argmax'):
            acc, src = rule_VE(P, fallback=fb)
            report(P, acc, src, 'R_VE fallback=%s, pool {C_a, C_p=a+1e-6%s, C_q, Y, Z} + %d splice rivals' % (fb, v, len(extra)))
    open(os.path.join(HERE, 'm3_rule_VE.out'), 'w').write('\n'.join(out) + '\n')
