"""PP10 m2: the union rule R_U on PP8's exact pump / edge / path pools.  Reports (TC) violations by link type,
face obligations, dominated selected models and all-world ties (CHECKED: exact records, exact anchors,
certified signs)."""
import sys, os
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from pp10lib import *
OUT_HERE = HERE = os.path.dirname(os.path.abspath(__file__))   # jd.py exports its own HERE; outputs go to PP10_py
out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def run(label, models, eps, closure=False, cap=200):
    pr('\n=== ' + label)
    P = Pool(models, eps, log=pr)
    if closure: P.close(cap=cap)
    P.build_records(); add_J(P)
    acc, unc = union_rule(P)
    pr('uncertified decisive signs: %d' % unc)
    pr('(TC) violations per world:', P.tc_check(acc))
    ob = P.obligations(acc); pr('unmet face obligations:', len(ob))
    dom, ties = P.selected_checks(acc)
    pr('dominated selected models: %d; all-world ties with selected: %d' % (len(dom), len(ties)))
    for x, s in dom[:8]:
        d = P.recmat[s, x]
        pr('   %s dominated by %s: rec(sel,X) b=%s dV=%s types %s; rev anchored %s faces %s' % (
            P.names[s], P.names[x], np.round(P.b[d], 9), np.round(P.dV[d], 9), [typ(P, d, i) for i in range(3)],
            bool(P.Anon[P.rev[d]]), P.faces[P.rev[d]]))
    for i in range(3):
        vt = violating_triples(P, acc, i, limit=20000)
        pats = {}
        for (x, y, z) in vt:
            key = (typ(P, P.recmat[x, y], i), typ(P, P.recmat[y, z], i), typ(P, P.recmat[z, x], i),
                   bool(P.Anon[P.recmat[z, x]] or P.G[P.recmat[z, x], i]) and False)
            pats[key[:3]] = pats.get(key[:3], 0) + 1
        pr('world %d: %d violating ordered triples; link-type words (x<=y, y<=z, z<=x; z<x strict): %s' % (i+1, len(vt), pats))
        for (x, y, z) in vt[:4]:
            pr('   e.g. %s <= %s <= %s <= %s, %s<=%s refused; (dE,dV): %s %s %s' % (
                P.names[x], P.names[y], P.names[z], P.names[x], P.names[x], P.names[z],
                tuple(np.round([P.b[P.recmat[x, y], i], P.dV[P.recmat[x, y], i]], 9)),
                tuple(np.round([P.b[P.recmat[y, z], i], P.dV[P.recmat[y, z], i]], 9)),
                tuple(np.round([P.b[P.recmat[z, x], i], P.dV[P.recmat[z, x], i]], 9))))
    return P, acc

if __name__ == '__main__':
    a = PP5_A; eps = F(3, 10)
    ms, q = cfg_pp5_pump(a, eps)
    Ca, Cq, Y, Z = ms
    run('pump pool {C_a, C_q, Y, Z} (e1_3, lead 1)', ms, eps)
    run('pump pool closed under splicing', ms, eps, closure=True)
    for v, t in (((1, -1, 0), F(1, 10**6)), ((0, 1, -1), F(1, 10**6)), ((-1, -1, 2), F(1, 10**6))):
        p = tuple(a[k] + t*v[k] for k in range(3))
        Cp = Model(p, eps, name='C_p%s' % (v,))
        run('edge/path pool {C_a, C_p, C_q, Y, Z}, p = a + 1e-6 %s' % (v,), [Ca, Cp, Cq, Y, Z], eps)
    open(os.path.join(HERE, 'm2_union_rule.out'), 'w').write('\n'.join(out) + '\n')
