"""s2: Theorem A (the full filtered batch kills every defence of T against Y_jk).
For each ordered pair (i, w), w != i, with l the third index:
  (a) an exact generic point of M_l (outside the guards) with T = B, C_i = S, I_w = A.
      All vertex functionals are nonzero there, so the advice pattern holds on an
      open cone: a non-null set N_{i,w}.  On N: C_i != T, X != C_i, X != T for
      X = X^(w) := I_w off W, T on W.  So (C_i, X^(w)) satisfies (E_T) and (E_C).
  (b) the kill triangle on the cell model {G_1, G_2, G_3, N}:
      A <=_w B   copy of sigma_{jk} = rec(T, Y_jk)   ({j,k} = complement of i)
      B <=_w Z   copy of rec(C_i, X^(w))  (installed at every world)
      Z  <_w A   strict guidance.
"""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pp16lib import *
import random
rng = random.Random(16)
T = M_vertices(); C = [tilt(i, A_TILT) for i in range(3)]; I = [ideal(w) for w in range(3)]

def generic(g, models):
    cls, h = orient(g)
    return all(dot(v, h) != 0 for m in models for v in m) and all(x != 0 for x in g)

def find_witness(i, w, l):
    for _ in range(200000):
        # point of class l: h_l < 0, others > 0
        h = [F(rng.randint(1, 4000), 1000) for _ in range(3)]
        h[l] = -h[l]
        h = tuple(h)
        if not generic(h, [T] + C): continue
        if orient(h)[0] != l: continue
        if advice(T, h) == 'B' and advice(C[i], h) == 'S' and advice(I[w], h) == 'A':
            return h
    return None

def ranks(w, cls_list, adv_list):
    return [rank(w, c, a) for c, a in zip(cls_list, adv_list)]

allok = True
for i in range(3):
    for w in range(3):
        if w == i: continue
        l = 3 - i - w
        j, k = sorted(set(range(3)) - {i})
        h = find_witness(i, w, l)
        print(f"(i,w)=({i+1},{w+1}) l={l+1}: witness h on M_{l+1} =", h,
              " T,C_i,I_w =", advice(T, h), advice(C[i], h), advice(I[w], h))
        allok &= h is not None
        # cell model: cells G_1,G_2,G_3 (classes 0,1,2) and N (class l)
        cls = [0, 1, 2, l]
        Cadv = ['A' if k_ != i else 'B' for k_ in range(3)] + ['S']        # C_i
        Xadv = ['B', 'B', 'B', 'A']                                          # X^(w): T on W, I_w on N
        Tadv = ['B', 'B', 'B', 'B']
        # exposure on the cell model
        ET = any(Cadv[c] != Xadv[c] and Xadv[c] != Tadv[c] for c in range(4))
        EC = any(c == 3 and Cadv[c] != Tadv[c] and Xadv[c] != Cadv[c] for c in range(4))
        # A: min on G_j, G_k; C_i on N; G_i: B (anything)
        Aadv = ['B', 'B', 'B', Cadv[3]]
        Badv = list(Aadv); Badv[j] = 'A'; Badv[k] = 'A'
        # sigma copy check: rec(A,B) = (G_j u G_k, B -> A) = rec(T, Y_jk)
        recAB = {c: (Aadv[c], Badv[c]) for c in range(4) if Aadv[c] != Badv[c]}
        sigma = {j: ('B', 'A'), k: ('B', 'A')}
        # repair copy: B agrees with C_i on D = {C_i != X}
        D = [c for c in range(4) if Cadv[c] != Xadv[c]]
        copy_ok = all(Badv[c] == Cadv[c] for c in D)
        Zadv = [Xadv[c] if c in D else Badv[c] for c in range(4)]
        rA, rB, rZ = ranks(w, cls, Aadv), ranks(w, cls, Badv), ranks(w, cls, Zadv)
        rC, rX = ranks(w, cls, Cadv), ranks(w, cls, Xadv)
        mixed_sigma = any(rB[c] > rA[c] for c in range(4)) and any(rB[c] < rA[c] for c in range(4))
        mixed_rep = any(rX[c] > rC[c] for c in range(4)) and any(rX[c] < rC[c] for c in range(4))
        strict_impr = all(rZ[c] <= rA[c] for c in range(4)) and any(rZ[c] < rA[c] for c in range(4))
        print(f"   exposure (E_T,E_C) = ({ET},{EC});  rec(A,B)==sigma_{{{j+1}{k+1}}}: {recAB == sigma};"
              f"  B=C_i on D: {copy_ok};  sigma mixed at w: {mixed_sigma};  repair mixed at w: {mixed_rep};"
              f"  Z strict w-improvement of A: {strict_impr}")
        allok &= ET and EC and recAB == sigma and copy_ok and strict_impr and mixed_rep
print("ALL OK" if allok else "FAILURE")
