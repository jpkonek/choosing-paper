"""s4: kill-free allocation against ALL two-guard rivals (generalised Lemma K).

Two-guard rivals: Y = T with majority on G_j u G_k and any change on a set N off
the guards, Y a strict i-improvement of T (so T must defend Y at j or k).
Fixed-world strategy: T defends every such Y at w_i in {j,k}.
An installed label-i repair R = rec(C_i, X) (x = X, c = C_i on D' = {C_i != X} \ W)
kills that strategy iff some such Y closes a 3-cycle {R, rec(T,Y), guidance} at w:
  K1 : a 3-cycle  R, rec(T,Y), guidance  exists for some such Y   [cycle R, e, G]
  K2 : a 3-cycle  rec(T,Y), R, guidance  exists for some such Y   [cycle e, R, G]
  (per-problem conditions: pp16lib.cycle_atom_ok; Y is chosen problem-wise.)
(Section 4 of PP16 derives both; s3 is the special case N = empty, i.e. K1 with
an empty bad set.)  A rival X in X_G \ {T} is BAD for w if for each label i:
  not two-sided exposed, or K1g, or K2.
Exact and complete over the 97 open cells (s3)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pp16lib import *
from itertools import product

T = M_vertices(); C = [tilt(i, A_TILT) for i in range(3)]
normals = [E(0), E(1), E(2)] + T + [v for K in C for v in K]
cells = arrangement_cells(normals)
types = sorted(set((orient(g)[0], advice(T, orient(g)[1]), tuple(advice(C[i], orient(g)[1]) for i in range(3)))
                   for g in cells.values()), key=str)
ADV = ['A', 'S', 'B', 'X']

def allowed(ty, wch, modes):
    cls, t, cs = ty
    out = []
    for x in ADV:
        ok = True
        for i in range(3):
            ci = cs[i]; m = modes[i]; w = wch[i]
            if m == 'ET':   ok &= (x == ci or x == t)
            elif m == 'EC': ok &= (ci == t or x == ci)
            else:
                # exists y (Y's advice here): Y weakly i-better than T, and the cycle condition
                ok &= any(rank(i, cls, y) <= rank(i, cls, t) and cycle_atom_ok(m, w, cls, t, ci, x, y) for y in ADV)
        if ok: out.append(x)
    return out

summary = {}
for wch in product([1, 2], [0, 2], [0, 1]):
    sols = []
    for modes in product(['ET', 'EC', 'K1', 'K2'], repeat=3):
        al = {ty: allowed(ty, wch, modes) for ty in types}
        if any(len(v) == 0 for v in al.values()): continue
        diff = [ty for ty in types if any(x != ty[1] for x in al[ty])]
        if diff: sols.append((modes, al, diff))
    summary[wch] = sols
    print(f"w = ({wch[0]+1},{wch[1]+1},{wch[2]+1}):", "BAD X EXISTS" if sols else "no bad X (fixed-world strategy kill-free)",
          " #mode patterns:", len(sols))
    for modes, al, diff in sols[:2]:
        print("   modes", modes)
        for ty in diff:
            print("     class", ty[0] if ty[0] == 'U' else ty[0] + 1, "T", ty[1], "C", ty[2], "-> X may be", [x for x in al[ty] if x != ty[1]])
