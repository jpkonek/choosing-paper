"""s8: (a) isolation: rescaled models near T agree with T on the guards (so lie in X_G
and are strictly dominated by an installed repair in audit's construction);
(b) vertex / tilt couplings: for 3-tilts C_b (b large) and the ideal I_3,
    X_{I_3} := I_3 off W, T on W  has rec(I_3, X_{I_3}) = rho_12 = (G_1 u G_2, A -> B),
    and (C_b, X_{I_3}) is two-sided exposed (so the full filtered batch over
    variable defenders installs its repair at every world);
    X_{b0} := C_{b0} off W, T on W  has rec(C_{b0}, X_{b0}) = rho_12 and (C_b, X_{b0})
    is two-sided exposed for b < b0 close to b0;
(c) the T-trap: rho_12 accepted at worlds 1 and 2 makes Y_12 := T[G_1 u G_2 -> A]
    weakly better than T at every world and strictly at world 3."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pp16lib import *

T = M_vertices(); AP = F(1, 50); G = [cone(guard_dir(k), AP) for k in range(3)]
def gpat(K): return [advice_on_cone(K, G[k]) for k in range(3)]
print("(a) isolation (guard cones of aperture 1/50; None = not constant on the cone)")
for p in [(F(1,3)+F(1,3000), F(1,3)-F(1,3000), F(1,3)), (F(1,3)+F(1,1000), F(1,3), F(1,3)-F(1,1000)), (F(1,3), F(1,3)+F(1,600), F(1,3)-F(1,600)), (F(11,30), F(3,10), F(1,3)), (F(1,2), F(1,4), F(1,4))]:
    print("   C_p, p =", tuple(str(x) for x in p), " guard pattern:", gpat(rescale(p, T)))

def exposure(Cm, Xm, atoms):
    ET = any(Cm[q] != Xm[q] and Xm[q] != atoms[q]['T'] for q in range(len(atoms)))
    EC = any(atoms[q]['guard'] is None and Cm[q] != atoms[q]['T'] and Xm[q] != Cm[q] for q in range(len(atoms)))
    return ET, EC

def atoms_for(models):
    normals = [E(0), E(1), E(2)] + T + [v for K in models for v in K]
    cells = list(arrangement_cells(normals).values())
    out = []
    for g in cells:
        out.append({'cls': orient(g)[0], 'T': advice(T, orient(g)[1]), 'guard': None, 'g': g})
    for k in range(3):
        out.append({'cls': k, 'T': 'B', 'guard': k, 'g': guard_dir(k)})
    return out
def adv_of(K, a):
    return advice_on_cone(K, G[a['guard']]) if a['guard'] is not None else advice(K, orient(a['g'])[1])

print("(b) vertex and tilt couplings")
I3 = ideal(2)
ok = True
for b in (F(10), F(100), F(1000), F(10**4)):
    Cb = tilt(2, b)
    atoms = atoms_for([Cb, I3])
    Cm = [adv_of(Cb, a) for a in atoms]; Im = [adv_of(I3, a) for a in atoms]
    Xm = [(a['T'] if a['guard'] is not None else Im[q]) for q, a in enumerate(atoms)]
    rec = {(a['guard'] if a['guard'] is not None else 'off'): (Im[q], Xm[q]) for q, a in enumerate(atoms) if Im[q] != Xm[q]}
    ET, EC = exposure(Cm, Xm, atoms)
    print(f"   b={b}: C_b guard pattern {gpat(Cb)};  rec(I_3, X_I3) = {rec}  (rho_12 iff keys are guards 0,1 with A->B);"
          f"  (C_b, X_I3) exposure (E_T,E_C) = ({ET},{EC})")
    ok &= ET and EC and set(rec) == {0, 1} and all(v == ('A', 'B') for v in rec.values())
b0 = F(10)
Cb0 = tilt(2, b0)
for b in (F(9), F(99, 10), F(999, 100)):
    Cb = tilt(2, b)
    atoms = atoms_for([Cb, Cb0])
    Cm = [adv_of(Cb, a) for a in atoms]; C0 = [adv_of(Cb0, a) for a in atoms]
    Xm = [(a['T'] if a['guard'] is not None else C0[q]) for q, a in enumerate(atoms)]
    rec0 = {(a['guard'] if a['guard'] is not None else 'off'): (C0[q], Xm[q]) for q, a in enumerate(atoms) if C0[q] != Xm[q]}
    ET, EC = exposure(Cm, Xm, atoms)
    print(f"   b0={b0}, b={b}: rec(C_b0, X_b0) = {rec0};  (C_b, X_b0) exposure (E_T,E_C) = ({ET},{EC})")
    ok &= ET and EC and set(rec0) == {0, 1}
print("(c) T-trap ranks on the guards G_1, G_2 (classes 1, 2): T = B, Y_12 = A")
for w in range(3):
    rT = [rank(w, k, 'B') for k in (0, 1)]; rY = [rank(w, k, 'A') for k in (0, 1)]
    print(f"   world {w+1}: ranks T {rT}, Y_12 {rY};  Y_12 weakly better: {all(y <= t for y, t in zip(rY, rT))}")
print("ALL OK" if ok else "FAILURE")
