"""s3: can audit's three-defender repairs be allocated kill-free?

T must defend Y_jk at a world w_i in {j,k} (i = third index), by sigma_jk.
By Lemma K a label-i repair rec(C_i, X) kills sigma_jk @ w_i iff X is weakly
w_i-better than C_i off the guards.  A rival X in X_G \ {T} is BAD for the
choice w = (w_1, w_2, w_3) if, for every label i, (C_i, X) is not two-sided
exposed or the repair is a kill.  Then X has no admissible repair.

Exact and complete: the off-guard problem space is partitioned into the open
cells of the arrangement of the 15 planes {g_j = 0} u {v.g = 0 : v a vertex
of M, K_1, K_2, K_3}; every cell is non-null and the advice of T, C_i, I_w is
constant on it.  All conditions are pointwise on cells (X may be chosen
cell-wise; splitting a cell never helps a universal condition), so a bad X
exists iff the finite search below finds one.
"""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pp16lib import *
from itertools import product

T = M_vertices(); C = [tilt(i, A_TILT) for i in range(3)]
normals = [E(0), E(1), E(2)] + T + [v for K in C for v in K]
cells = arrangement_cells(normals)
atoms = []
for sv, g in cells.items():
    cls, h = orient(g)
    atoms.append((cls, advice(T, h), tuple(advice(C[i], h) for i in range(3)), g))
assert all(a[1] is not None and None not in a[2] for a in atoms)
print("cells (mod sign):", len(atoms))
types = sorted(set(a[:3] for a in atoms), key=str)
print("distinct (class, T, C1, C2, C3) types:", len(types))
ADV = ['A', 'S', 'B', 'X']

def allowed(atype, wch, modes):
    cls, t, cs = atype
    out = []
    for x in ADV:
        ok = True
        for i in range(3):
            ci = cs[i]; m = modes[i]
            if m == 'ET':   ok &= (x == ci or x == t)
            elif m == 'EC': ok &= (ci == t or x == ci)
            else:           ok &= (x == ci or rank(wch[i], cls, x) < rank(wch[i], cls, ci))
        if ok: out.append(x)
    return out

results = {}
for wch in product([1, 2], [0, 2], [0, 1]):     # w_1 in {2,3}, w_2 in {1,3}, w_3 in {1,2} (0-based)
    sols = []
    for modes in product(['ET', 'EC', 'K'], repeat=3):
        al = {ty: allowed(ty, wch, modes) for ty in types}
        if any(len(v) == 0 for v in al.values()): continue
        diff = [ty for ty in types if any(x != ty[1] for x in al[ty])]
        if diff:
            sols.append((modes, al, diff))
    results[wch] = sols
    tag = "BAD X EXISTS" if sols else "kill-free allocation exists (no bad X)"
    print(f"w = ({wch[0]+1},{wch[1]+1},{wch[2]+1}):", tag, "  mode patterns:", [s[0] for s in sols])
    if sols:
        modes, al, diff = sols[0]
        print("   example modes", modes, "; cells where X may differ from T:")
        for ty in diff[:12]:
            print("     class", ty[0] if ty[0] == 'U' else ty[0] + 1, "T", ty[1], "C", ty[2], "-> X in", al[ty])
# sanity: all-unexposed modes must be infeasible (audit Lemma 4)
bad_unexp = 0
for modes in product(['ET', 'EC'], repeat=3):
    al = {ty: allowed(ty, (1, 0, 0), modes) for ty in types}
    if all(len(v) for v in al.values()) and any(any(x != ty[1] for x in al[ty]) for ty in types):
        bad_unexp += 1
print("sanity (Lemma 4: some defender two-sided exposed for every X != T): violations =", bad_unexp)
