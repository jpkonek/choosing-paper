"""s10: plateau-edge couplings.
(a) Projection exclusion: for m = (1/2,1/2,0) (projection of T's index c* onto Delta_12)
    T is weakly A-ward of E_m on M_1 u M_2, so X := T[N -> A] (N a non-null part of
    M_3 where T != A) is a strict world-3 improvement of E_m, while T can defend X only
    at world 3.  Hence the closure of T's plateau cannot contain an index carrying E_m.
    For edge points r != m some cell of M_1 or M_2 has E_r strictly A-ward of T, and the
    argument does not apply (listed).
(b) Lambda (majority advice on every mixed class) is a strict world-3 improvement of
    every edge model on Delta_12 tested.  Exact, cell-wise."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pp16lib import *
T = M_vertices()
AW = {'B': 0, 'S': 1, 'A': 2}
def cells_for(K):
    normals = [E(0), E(1), E(2)] + T + K
    return [orient(g) for g in arrangement_cells(normals).values()]
ok = True
for lam in (F(1, 2), F(2, 5), F(3, 5), F(1, 10), F(9, 10)):
    r = (lam, 1 - lam, F(0)); K = rescale(r, T)
    cs = cells_for(K)
    TgeE = all(AW[advice(T, h)] >= AW[advice(K, h)] for cls, h in cs if cls in (0, 1))
    Eahead = [(cls + 1, advice(T, h), advice(K, h)) for cls, h in cs if cls in (0, 1) and AW[advice(K, h)] > AW[advice(T, h)]]
    # X = T[N -> A], N = M_3 cells where T != A
    X = lambda cls, h: 'A' if (cls == 2 and advice(T, h) != 'A') else advice(T, h)
    weak3 = all(rank(2, cls, X(cls, h)) <= rank(2, cls, advice(K, h)) for cls, h in cs)
    strict3 = any(rank(2, cls, X(cls, h)) < rank(2, cls, advice(K, h)) for cls, h in cs)
    lam_impr = all(rank(2, cls, ('A')) <= rank(2, cls, advice(K, h)) for cls, h in cs if cls in (0, 1)) and \
               any(rank(2, cls, 'A') < rank(2, cls, advice(K, h)) for cls, h in cs if cls in (0, 1)) and \
               all(advice(K, h) == 'A' for cls, h in cs if cls == 2)
    print(f"r = ({lam},{1-lam},0): T >=_A E_r on M_1uM_2: {TgeE};  X=T[N->A] strict 3-improvement of E_r: {weak3 and strict3};"
          f"  #cells with E_r strictly A-ward of T: {len(Eahead)};  Lambda strict 3-improvement of E_r: {lam_impr}")
    if lam == F(1, 2): ok &= TgeE and weak3 and strict3
    ok &= lam_impr
print("ALL OK" if ok else "FAILURE")
