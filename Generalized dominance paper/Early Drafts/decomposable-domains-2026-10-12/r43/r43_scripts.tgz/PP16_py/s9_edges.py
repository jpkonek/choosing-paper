"""s9: edge two-world systems and T's guard defences.
(a) Naive template (gate2d keys on the edge classes, all other steps keyed lowest,
    verdict Phi = 2 on - off): an explicit record out of a Delta_13 edge model near e_3,
    accepted at world 1 by the naive rule, which closes a 3-cycle with sigma_12 = rec(T,Y_12)
    and guidance at world 1.  By symmetry all six (pair, world) defences of T die.
(b) Per-problem certificate for the repair Psi_w = min(Phi_w, Phi_w - Phi_i): for edge
    models on every edge, every record out of the edge model that can close a kill cycle
    (any two-guard rival Y, either order) at a support world w is, problem by problem,
    a weak worsening at the other support world i.  (Then Phi_i > Phi_w, so Psi_w < 0.)"""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pp16lib import *

T = M_vertices(); AP = F(1, 50); G = [cone(guard_dir(k), AP) for k in range(3)]
ADV = ['A', 'S', 'B', 'X']
def atoms_for(K):
    normals = [E(0), E(1), E(2)] + T + K
    cells = list(arrangement_cells(normals).values())
    out = [{'cls': orient(g)[0], 'T': advice(T, orient(g)[1]), 'E': advice(K, orient(g)[1]), 'guard': None} for g in cells]
    for k in range(3):
        e = advice_on_cone(K, G[k])
        if e is None: return None
        out.append({'cls': k, 'T': 'B', 'E': e, 'guard': k})
    return out

# ---------- (a) naive template kill ----------
r = (F(1, 20), F(0), F(19, 20)); K = rescale(r, T); at = atoms_for(K)
print("(a) edge model r =", tuple(str(x) for x in r), " guard pattern:", [a['E'] for a in at if a['guard'] is not None])
# record x: B on G_1, G_2; on one class-1 cell where E != B: B; else E
N = next(q for q, a in enumerate(at) if a['guard'] is None and a['cls'] == 0 and a['E'] != 'B')
x = [a['E'] for a in at]
for q, a in enumerate(at):
    if a['guard'] in (0, 1): x[q] = 'B'
x[N] = 'B'
mass = [F(1) if a['guard'] is not None else (F(1, 2) if q == N else F(0)) for q, a in enumerate(at)]
def steps(w):
    on = sum(mass[q] * max(0, rank(w, a['cls'], x[q]) - rank(w, a['cls'], a['E'])) for q, a in enumerate(at))
    off = sum(mass[q] * max(0, rank(w, a['cls'], a['E']) - rank(w, a['cls'], x[q])) for q, a in enumerate(at))
    on_cls = {a['cls'] for q, a in enumerate(at) if mass[q] and rank(w, a['cls'], x[q]) > rank(w, a['cls'], a['E'])}
    return on, off, on_cls
on1, off1, cls1 = steps(0); on3, off3, cls3 = steps(2)
print(f"   world 1: on={on1} off={off1}, added steps only in classes {sorted(c+1 for c in cls1)} (class 2 = off-edge class, lowest keys: gate passes);"
      f" Phi_1 = {2*on1-off1}")
print(f"   world 3: on={on3} off={off3}  (pure world-3 worsening: {off3 == 0});  Phi_3 = {2*on3-off3};"
      f"  Psi_1 = min(Phi_1, Phi_1-Phi_3) = {min(2*on1-off1, 2*on1-off1-(2*on3-off3))}")
# kill cycle with Y_12 (y = T off guards, A on G_1, G_2) at world 1
kill = all(cycle_atom_ok(o, 0, a['cls'], a['T'], a['E'], x[q], ('A' if a['guard'] in (0, 1) else a['T']))
           for q, a in enumerate(at) for o in ['K1'][:1])
print("   3-cycle {rec(E,x), sigma_12, guidance} at world 1 exists (K1, problem-wise):", kill)
okA = kill and 2*on1-off1 >= 0 and off3 == 0 and min(2*on1-off1, 2*on1-off1-(2*on3-off3)) < 0

# ---------- (b) per-problem certificate ----------
print("(b) edge models on all three edges")
okB = True; tested = 0; vacuous = 0; feasible = 0
for (sa, sb) in ((0, 1), (0, 2), (1, 2)):
    for num in range(1, 20):
        lam = F(num, 20)
        rr = [F(0)] * 3; rr[sa] = lam; rr[sb] = 1 - lam
        K = rescale(tuple(rr), T); at = atoms_for(K)
        if at is None: continue
        tested += 1
        for w, i in ((sa, sb), (sb, sa)):
            for other in [m for m in range(3) if m != w]:
                pair = {w, other}; t = 3 - w - other
                for order in ('K1', 'K2'):
                    def ys(a):
                        if a['guard'] is not None:
                            return ['A'] if a['guard'] in pair else [a['T']]
                        return [y for y in ADV if rank(t, a['cls'], y) <= rank(t, a['cls'], a['T'])]
                    allowed = [[xx for xx in ADV if any(cycle_atom_ok(order, w, a['cls'], a['T'], a['E'], xx, y) for y in ys(a))]
                               for a in at]
                    if any(len(al) == 0 for al in allowed):
                        vacuous += 1          # no record out of E closes such a cycle at all
                        continue
                    feasible += 1
                    for q, a in enumerate(at):
                        for xx in allowed[q]:
                            if rank(i, a['cls'], xx) < rank(i, a['cls'], a['E']):
                                okB = False
                                print("   COUNTEREXAMPLE edge", (sa+1, sb+1), "lam", lam, "w", w+1, "pair", sorted(m+1 for m in pair), order, a, xx)
print(f"   edge models tested: {tested}; (w, pair, order) cases with some kill-capable record: {feasible}, with none: {vacuous};"
      f" every kill-capable record at a support world w is a weak worsening at the other support world: {okB}")
print("ALL OK" if okA and okB else "FAILURE")
