"""PP16 shared library: exact rational geometry for the guard / selection analysis.

Conventions (0-based worlds in code, 1-based in the note):
  * Problems: g in Q^3 modulo sign.  orient(g) -> (cls, h): h is the majority
    orientation (two positive coordinates) and cls the index of its negative
    coordinate; unanimous problems have cls 'U' and h > 0.
  * Advice relative to h: 'A' accept h (majority answer; correct on U),
    'S' silence, 'B' accept -h (minority answer; wrong on U), 'X' contradiction.
  * Ranks: world w on class w: B0 S1 A2 X3; world w on class c != w: A0 S1 B2 X3;
    on U: A0 S1 B2 X3.
  * A coherent model D_K (K a polytope, given by vertices) says 'A' iff
    min_K m.h > 0, 'B' iff max_K m.h < 0, else 'S'.  Advice is only evaluated
    at points where no vertex functional vanishes (generic points).
"""
from fractions import Fraction as F
import math

def dot(a, b): return sum(x * y for x, y in zip(a, b))
def had(a, b): return tuple(x * y for x, y in zip(a, b))
def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def sgn(x): return (x > 0) - (x < 0)
def E(i): return tuple(F(1) if j == i else F(0) for j in range(3))

EPS = F(3, 10)
CC = (1 - EPS) / 3                     # c = 7/30
L = F(4)                               # guard payoff
A_TILT = F(10)                         # concentration of audit's defenders

def M_vertices(eps=EPS):
    c = (1 - eps) / 3
    return [tuple(c + (eps if j == i else 0) for j in range(3)) for i in range(3)]

def rescale(p, verts):
    """Posterior image {p*m/(p.m)} of a polytope (vertices map to vertices)."""
    return [tuple(x / dot(p, v) for x in had(p, v)) for v in verts]

def tilt(i, b, eps=EPS):
    s = tuple(F(b) if j == i else F(1) for j in range(3))
    return rescale(s, M_vertices(eps))

def orient(g):
    pos = [x > 0 for x in g]
    if all(pos): return 'U', tuple(g)
    if not any(pos): return 'U', tuple(-x for x in g)
    h = tuple(g) if sum(pos) == 2 else tuple(-x for x in g)
    return [i for i in range(3) if h[i] < 0][0], h

def advice(verts, h):
    vals = [dot(v, h) for v in verts]
    if any(v == 0 for v in vals): return None
    if min(vals) > 0: return 'A'
    if max(vals) < 0: return 'B'
    return 'S'

RANK_MAJ = {'A': 0, 'S': 1, 'B': 2, 'X': 3}
RANK_MIN = {'B': 0, 'S': 1, 'A': 2, 'X': 3}
def rank(w, cls, a):
    if cls == 'U': return RANK_MAJ[a]
    return RANK_MIN[a] if w == cls else RANK_MAJ[a]

def ideal(w): return [E(w)]

def guard_dir(k):
    """g^k = L e_k - (1 - e_k): world k minority; T accepts it (minority answer)."""
    return tuple(L if j == k else F(-1) for j in range(3))

def cone(center, ap):
    """Small polyhedral cone: 4 generators around center (aperture ap)."""
    c = center
    # two directions orthogonal-ish to c
    u = cross(c, (F(1), F(0), F(0))) if c[1] != 0 or c[2] != 0 else cross(c, (F(0), F(1), F(0)))
    v = cross(c, u)
    nu = max(abs(x) for x in u); nv = max(abs(x) for x in v); nc = max(abs(x) for x in c)
    u = tuple(x * nc / nu for x in u); v = tuple(x * nc / nv for x in v)
    return [tuple(c[j] + s * ap * d[j] for j in range(3)) for d in (u, v) for s in (1, -1)]

def advice_on_cone(verts, gens):
    """Advice constant on the cone spanned by gens (all in one class), or None.
    Exact: m.g is linear in g, so strict signs at the generators extend."""
    cls0 = None; out = set()
    for g in gens:
        cls, h = orient(g)
        if cls0 is None: cls0 = cls
        if cls != cls0: return None
        a = advice(verts, h)
        if a is None: return None
        out.add(a)
    if len(out) != 1: return None
    # 'S' needs care: S at generators means some vertex positive and some negative
    # at each generator; this is not convex in general, so only certify A/B on cones,
    # and certify S via the two separate witnesses below.
    a = out.pop()
    if a in ('A', 'B'): return a
    # S on the cone: certify by showing a fixed vertex is >0 and a fixed vertex <0 on all gens
    for v1 in verts:
        for v2 in verts:
            if all(dot(v1, orient(g)[1]) > 0 for g in gens) and all(dot(v2, orient(g)[1]) < 0 for g in gens):
                return 'S'
    return None

# ---------------- arrangement of planes through 0 ---------------------------
def ratapprox(x, den=10**9):
    return F(x).limit_denominator(den)

def arrangement_cells(normals):
    """All open cells (mod sign) of the arrangement of planes n.g = 0 in R^3.
    Returns dict canonical_sign_vector -> exact interior point.  Complete: every
    cell of a great-circle arrangement with >= 2 distinct circles has a vertex,
    and all sectors around every vertex are visited."""
    N = [tuple(F(x) for x in n) for n in normals]
    cells = {}
    verts = []
    for a in range(len(N)):
        for b in range(a + 1, len(N)):
            v = cross(N[a], N[b])
            if any(x != 0 for x in v):
                verts.append(v)
    for v in verts:
        through = [n for n in N if dot(n, v) == 0]
        # tangent basis
        for k in range(3):
            u1 = cross(v, E(k))
            if any(x != 0 for x in u1): break
        u2 = cross(v, u1)
        f1 = math.sqrt(float(dot(u1, u1))); f2 = math.sqrt(float(dot(u2, u2)))
        angs = []
        for n in through:
            t = cross(v, n)
            angs.append(math.atan2(float(dot(t, u2)) / f2, float(dot(t, u1)) / f1) % math.pi)
        angs = sorted(set(round(x, 12) for x in angs))
        mids = []
        for idx in range(len(angs)):
            a0 = angs[idx]; a1 = angs[(idx + 1) % len(angs)] + (math.pi if idx + 1 == len(angs) else 0)
            mids.append((a0 + a1) / 2)
        for th in mids:
            for sgn_ in (1, -1):
                cth = ratapprox(sgn_ * math.cos(th)); sth = ratapprox(sgn_ * math.sin(th))
                d = tuple(cth * u1[j] / ratapprox(f1) + sth * u2[j] / ratapprox(f2) for j in range(3))
                if any(dot(n, d) == 0 for n in through):
                    continue
                others = [abs(dot(n, v)) for n in N if dot(n, v) != 0]
                scale = max(sum(abs(x) for x in n) for n in N) * sum(abs(x) for x in d)
                t = (min(others) / (4 * scale)) if others else F(1)
                g = tuple(v[j] + t * d[j] for j in range(3))
                sv = tuple(sgn(dot(n, g)) for n in N)
                assert all(s != 0 for s in sv)
                # expected sign vector
                exp = tuple(sgn(dot(n, v)) if dot(n, v) != 0 else sgn(dot(n, d)) for n in N)
                assert sv == exp
                if sv[0] < 0 or (sv[0] == 0):
                    sv = tuple(-s for s in sv); g = tuple(-x for x in g)
                cells.setdefault(sv, g)
    return cells

# ---------------- kill cycles (PP16 section 4) --------------------------------
def cycle_atom_ok(order, w, cls, t, c, x, y):
    """Per-problem condition for a 3-cycle at world w made of
       R = rec(c-model, x-model), e = rec(T, Y) and one guidance link.
    order 'K1': A0 -R-> B0 -e-> Z0 -guidance-> A0
    order 'K2': A0 -e-> B0 -R-> Z0 -guidance-> A0
    (the guidance link Z0 <=_w A0 needs rank_w(Z0) <= rank_w(A0) pointwise)."""
    inR, inE = (x != c), (y != t)
    rk = lambda a: rank(w, cls, a)
    if order == 'K1':
        if inR and inE: return x == t and rk(y) <= rk(c)
        if inR:         return rk(x) <= rk(c)
        if inE:         return rk(y) <= rk(t)
        return True
    else:
        if inR and inE: return y == c and rk(x) <= rk(t)
        if inR:         return rk(x) <= rk(c)
        if inE:         return rk(y) <= rk(t)
        return True

def pair_killed(atoms, records, i, need_strict=True):
    """atoms: list of dicts with keys cls, T, guard (None or k).  records: list of
    (c_list, x_list) advice lists over atoms (records installed at every world).
    Pair {j,k} = complement of i.  Returns a witness description if some two-guard
    rival Y (majority on G_j u G_k, T on G_i, Y weakly i-better than T elsewhere)
    has its T-defence killed at BOTH j and k (by 3-cycles with guidance), else None.
    Strictness: the closing guidance link must be strict somewhere unless the
    record is known to be strict (need_strict=False)."""
    j, k = [m for m in range(3) if m != i]
    ADV = ['A', 'S', 'B', 'X']
    for rj in range(len(records)):
        for rk in range(len(records)):
            for oj in ('K1', 'K2'):
                for ok_ in ('K1', 'K2'):
                    choices = []
                    feas = True
                    for q, a in enumerate(atoms):
                        cls, t = a['cls'], a['T']
                        if a['guard'] is not None:
                            ys = ['A'] if a['guard'] in (j, k) else [t]
                        else:
                            ys = [y for y in ADV if rank(i, cls, y) <= rank(i, cls, t)]
                        cj, xj = records[rj][0][q], records[rj][1][q]
                        ck, xk = records[rk][0][q], records[rk][1][q]
                        good = [y for y in ys if cycle_atom_ok(oj, j, cls, t, cj, xj, y)
                                and cycle_atom_ok(ok_, k, cls, t, ck, xk, y)]
                        if not good: feas = False; break
                        choices.append(good)
                    if feas:
                        return (rj, rk, oj, ok_, choices)
    return None
