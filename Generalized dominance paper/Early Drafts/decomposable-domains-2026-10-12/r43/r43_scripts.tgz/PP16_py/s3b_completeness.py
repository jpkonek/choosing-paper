"""s3b: completeness check of the arrangement enumeration used in s3 (random sampling)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pp16lib import *
import random
rng = random.Random(7)
T = M_vertices(); C = [tilt(i, A_TILT) for i in range(3)]
normals = [E(0), E(1), E(2)] + T + [v for K in C for v in K]
cells = arrangement_cells(normals)
seen = set(); miss = 0; n = 0
for _ in range(60000):
    g = tuple(F(rng.randint(-10**6, 10**6), 10**6) for _ in range(3))
    sv = tuple(sgn(dot(nv, g)) for nv in normals)
    if 0 in sv: continue
    if sv[0] < 0: sv = tuple(-s for s in sv)
    n += 1; seen.add(sv)
    if sv not in cells: miss += 1
# also sample near the guard and near coordinate axes (thin cells)
for _ in range(60000):
    base = random.choice([E(0), E(1), E(2), (F(1), F(1), F(-1)), (F(1), F(-1), F(1)), (F(-1), F(1), F(1))])
    g = tuple(base[j] + F(rng.randint(-10**5, 10**5), 10**6) for j in range(3))
    sv = tuple(sgn(dot(nv, g)) for nv in normals)
    if 0 in sv: continue
    if sv[0] < 0: sv = tuple(-s for s in sv)
    n += 1; seen.add(sv)
    if sv not in cells: miss += 1
print("enumerated cells:", len(cells), " sampled points:", n, " distinct sampled cells:", len(seen), " sampled cells not enumerated:", miss)
