"""s1: exact instance of audit's guarded construction (eps=3/10, L=4, a=10).
Checks: T accepts the guard directions (minority answer, B relative to h);
the three concentrated defenders C_i = Phi_{s_i}(T) have the i-defender guard
pattern on whole guard cones (min on G_i, maj on G_k); so do the ideals I_i;
Prop. 1's hypotheses (m_i > 1/2 on K_i; 1/(a+2) < c)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pp16lib import *

AP = F(1, 50)
G = [cone(guard_dir(k), AP) for k in range(3)]
T = M_vertices()
C = [tilt(i, A_TILT) for i in range(3)]
I = [ideal(w) for w in range(3)]
print("eps =", EPS, " c =", CC, " L =", L, " a =", A_TILT, " guard aperture =", AP)
for k in range(3):
    print(f"guard G_{k+1}: class", {orient(g)[0] for g in G[k]}, " T:", advice_on_cone(T, G[k]))
ok = True
for i in range(3):
    pat = [advice_on_cone(C[i], G[k]) for k in range(3)]
    want = ['B' if k == i else 'A' for k in range(3)]
    print(f"C_{i+1} on (G1,G2,G3):", pat, " i-defender pattern:", pat == want)
    ok &= pat == want
    pat = [advice_on_cone(I[i], G[k]) for k in range(3)]
    print(f"I_{i+1} on (G1,G2,G3):", pat, " i-defender pattern:", pat == want)
    ok &= pat == want
    mi = min(v[i] for v in C[i])
    print(f"  min_{{K_{i+1}}} m_{i+1} =", mi, "> 1/2:", mi > F(1, 2))
    ok &= mi > F(1, 2)
print("1/(a+2) < c:", F(1) / (A_TILT + 2) < CC)
# V_i as the maximal guard-pattern region: m.g^i > 0 on G_i cone, m.g^k < 0 on G_k cones
def in_V(i, m):
    for k in range(3):
        for g in G[k]:
            val = dot(m, g)       # g is the guard gamble (accepted = minority answer)
            if k == i and not val > 0: return False
            if k != i and not val < 0: return False
    return True
for i in range(3):
    print(f"K_{i+1} subset V_{i+1}:", all(in_V(i, v) for v in C[i]), "  e_" + str(i+1) + " in V:", in_V(i, E(i)))
print("ALL OK" if ok else "FAILURE")
