"""s7: screen of the nearby route -- dominate the forced rival X* of Theorem B by a
selected model D* that is NOT a 1-defender, instead of by audit's 1-defender repair.

For each candidate D*: (i) X* is a strict pointwise improvement of D* at no world
(so D* <=_w X* is (G)-admissible at all three worlds); (ii) with rec(D*, X*) installed
at every world, for each pair {j,k}: is some two-guard rival Y (majority on G_j u G_k,
strict i-improvement of T) killed at BOTH j and k (3-cycles with guidance)?
Also, as a control, the same screen for audit's C_1 (must report the {2,3} kill).
Exact cell models (arrangement cells + the S-cone + guard cones)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pp16lib import *

T = M_vertices(); C1, C2, C3 = (tilt(i, A_TILT) for i in range(3))
AP = F(1, 50); G = [cone(guard_dir(k), AP) for k in range(3)]
h0 = (F(-1), F(1), F(1)); Scone = cone(h0, F(1, 20))

def build(D):
    normals = [E(0), E(1), E(2)] + T + C1 + C2 + C3 + D
    cells = list(arrangement_cells(normals).values())
    raw = [('cell', g, None) for g in cells] + [('S', h0, None)] + [('G', guard_dir(k), k) for k in range(3)]
    def adv(model, kind, g, k):
        if kind == 'S': return advice_on_cone(model, Scone)
        if kind == 'G': return advice_on_cone(model, G[k])
        return advice(model, orient(g)[1])
    atoms = []
    for kind, g, k in raw:
        a = {'cls': orient(g)[0], 'T': adv(T, kind, g, k), 'D': adv(D, kind, g, k), 'guard': k, 'kind': kind}
        a['X'] = 'A' if kind == 'S' else a['T']
        assert a['T'] is not None and a['D'] is not None, (kind, g)
        atoms.append(a)
    return atoms

def screen(name, D):
    atoms = build(D)
    n = len(atoms)
    refused = [w for w in range(3) if all(rank(w, a['cls'], a['X']) <= rank(w, a['cls'], a['D']) for a in atoms)
               and any(rank(w, a['cls'], a['X']) < rank(w, a['cls'], a['D']) for a in atoms)]
    gp = [a['D'] for a in atoms if a['kind'] == 'G']
    rec = ([a['D'] for a in atoms], [a['X'] for a in atoms])
    kills = {}
    for i in range(3):
        wit = pair_killed(atoms, [rec], i)
        kills['{%d,%d}' % tuple(m + 1 for m in range(3) if m != i)] = (wit is not None)
    print(f"{name:28s} guard pattern {gp}; worlds where X* strictly improves D*: {[w+1 for w in refused]};"
          f" pair fully killed: {kills}")
    return refused, kills

screen("control: audit C_1", C1)
for b in (F(1, 2), F(1, 4), F(1, 10), F(1, 100)):
    screen(f"away-tilt nu(b,1,1), b={b}", tilt(0, b))
for r in ((F(0), F(1, 2), F(1, 2)), (F(0), F(1, 3), F(2, 3)), (F(0), F(2, 3), F(1, 3)), (F(0), F(2, 5), F(3, 5)), (F(0), F(3, 5), F(2, 5))):
    try:
        screen(f"edge model C_{tuple(str(x) for x in r)}", rescale(r, T))
    except AssertionError:
        print(f"edge model C_{tuple(str(x) for x in r)}: advice not constant on a guard cone (skipped)")
