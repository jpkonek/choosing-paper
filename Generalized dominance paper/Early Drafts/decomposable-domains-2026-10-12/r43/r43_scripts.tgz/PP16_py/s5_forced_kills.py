"""s5: forced kills in audit's three-defender mechanism (per-rival world choice).

Search for a two-guard rival Y (majority on G_j u G_k, change y on a set N off the
guards, Y a strict i-improvement of T) and two guard-preserving rivals X1, X2 whose
ONLY two-sided-exposed defender (among C_1, C_2, C_3) is C_i, such that
  rec(C_i, X1) kills rec(T, Y) at world j   (3-cycle with guidance, K1 or K2 form)
  rec(C_i, X2) kills rec(T, Y) at world k.
Audit's guarantee (every X in X_G \\ {T} strictly dominated by a repair) forces
rec(C_i, X1), rec(C_i, X2) to be installed, at every world.  Then T can defend Y
at no world: i by strict guidance, j and k by (TC).

Cycle conditions (derived in PP16 section 4), per problem, with c = C_i, x = X_r:
 K1 (cycle R, rec(T,Y), guidance) at w:
   x!=c, y!=T : x = T and y <=_w c
   x!=c, y =T : x <_w c
   x =c, y!=T : y <=_w T
 K2 (cycle rec(T,Y), R, guidance) at w:
   x!=c, y!=T : y = c and x <=_w T
   x!=c, y =T : x <_w c
   x =c, y!=T : y <=_w T
Exposure: E_T: some part with x != c and x != T;  E_C: some part with c != T and x != c.
Unexposed for label m: ET-fail (x in {C_m, T} everywhere) or EC-fail (C_m = T or x = C_m).
Exact and complete over the 97 open cells (atomless: a cell may be split into parts,
so universal conditions are per (cell, triple) and existential ones need one allowed
triple somewhere)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pp16lib import *
from itertools import product

T = M_vertices(); C = [tilt(i, A_TILT) for i in range(3)]
normals = [E(0), E(1), E(2)] + T + [v for K in C for v in K]
cells = arrangement_cells(normals)
types = sorted(set((orient(g)[0], advice(T, orient(g)[1]), tuple(advice(C[i], orient(g)[1]) for i in range(3)))
                   for g in cells.values()), key=str)
ADV = ['A', 'S', 'B', 'X']
R = rank

def kill_ok(kind, w, cls, t, c, x, y):
    return cycle_atom_ok(kind, w, cls, t, c, x, y)

def unexp_ok(mode, t, cm, x):
    return (x == cm or x == t) if mode == 'ET' else (cm == t or x == cm)

found = []
for i in range(3):
    j, k = [m for m in range(3) if m != i]
    others = [m for m in range(3) if m != i]
    for kinds in product(['K1', 'K2'], repeat=2):
        for m1 in product(['ET', 'EC'], repeat=2):
            for m2 in product(['ET', 'EC'], repeat=2):
                allowed = {}
                feas = True
                for ty in types:
                    cls, t, cs = ty
                    c = cs[i]
                    trip = []
                    for x1, x2, y in product(ADV, ADV, ADV):
                        if R(i, cls, y) > R(i, cls, t): continue            # Y weakly i-better than T
                        if not all(unexp_ok(m1[a], t, cs[others[a]], x1) for a in range(2)): continue
                        if not all(unexp_ok(m2[a], t, cs[others[a]], x2) for a in range(2)): continue
                        if not kill_ok(kinds[0], j, cls, t, c, x1, y): continue
                        if not kill_ok(kinds[1], k, cls, t, c, x2, y): continue
                        trip.append((x1, x2, y))
                    if not trip: feas = False; break
                    allowed[ty] = trip
                if not feas: continue
                def exists(pred):
                    return any(pred(ty, tr) for ty in types for tr in allowed[ty])
                ok = (exists(lambda ty, tr: tr[0] != ty[2][i] and tr[0] != ty[1]) and
                      exists(lambda ty, tr: ty[2][i] != ty[1] and tr[0] != ty[2][i]) and
                      exists(lambda ty, tr: tr[1] != ty[2][i] and tr[1] != ty[1]) and
                      exists(lambda ty, tr: ty[2][i] != ty[1] and tr[1] != ty[2][i]))
                if ok:
                    found.append((i, kinds, m1, m2, allowed))
print("configurations (label i, kill kinds at (j,k), unexposure modes of X1, X2) admitting forced kills:", len(found))
for i, kinds, m1, m2, allowed in found[:6]:
    j, k = [m for m in range(3) if m != i]
    print(f"  i={i+1}: kills {kinds[0]}@{j+1}, {kinds[1]}@{k+1}; X1 unexposed modes {m1}, X2 {m2}")
print("labels with forced kills:", sorted(set(f[0] + 1 for f in found)))
# store one explicit witness: choose, per cell, one triple; then add parts realising existentials
if found:
    i, kinds, m1, m2, allowed = found[0]
    j, k = [m for m in range(3) if m != i]
    print(f"\nexplicit witness for i={i+1}, kinds {kinds}:")
    for ty in types:
        cls, t, cs = ty
        # prefer triple with x1=x2=t-ish variety: list all
        print("   class", cls if cls == 'U' else cls + 1, "T", t, "C", cs, "allowed (x1,x2,y):", allowed[ty][:6], "..." if len(allowed[ty]) > 6 else "")
