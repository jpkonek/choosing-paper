"""s6: Theorem B (a forced repair makes T non-competitive, in every subcollection).

X* := T with the majority answer A on a small cone S around h0 = (-1,1,1) (class M_1).
 * T says S at h0; every m in V_2^max u V_3^max says A on the whole cone S, so
   (E_T) fails for EVERY 2- and 3-defender: only 1-defenders can repair X*.
 * For a 1-defender C (pointwise no worse than T at world 1, as audit's C_1),
   Y_C := C on M_2 u M_3 (guards included), T on M_1 u U.
   Y_C is a strict world-1 improvement of T, so T refuses Y_C at world 1.
 * For w = 2, 3 the 3-cycle  A0 -[rec(C,X*)]-> B0 -[rec(T,Y_C)]-> Z0 -[guidance]-> A0
   exists, with the guidance link strict: (TC) forbids T <=_w Y_C.
Exact cell model: open cells of the arrangement for (T, C, C_2, C_3), plus the cone S
and the three guard cones as separate atoms (advice certified on cone generators)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pp16lib import *

T = M_vertices(); C2 = tilt(1, A_TILT); C3 = tilt(2, A_TILT)
AP = F(1, 50)
G = [cone(guard_dir(k), AP) for k in range(3)]
h0 = (F(-1), F(1), F(1))
Scone = cone(h0, F(1, 20))
# maximal V_2, V_3 for L = 4 (guard pattern on the guard directions): m_i >= 3/5, others <= 1/5
V2 = [(F(0), F(1), F(0)), (F(1, 5), F(4, 5), F(0)), (F(0), F(4, 5), F(1, 5)), (F(1, 5), F(3, 5), F(1, 5))]
V3 = [(F(0), F(0), F(1)), (F(1, 5), F(0), F(4, 5)), (F(0), F(1, 5), F(4, 5)), (F(1, 5), F(1, 5), F(3, 5))]
print("T on S-cone:", advice_on_cone(T, Scone), "  class:", {orient(g)[0] for g in Scone})
print("every vertex of V_2^max, V_3^max says A on all S-cone generators:",
      all(dot(m, orient(g)[1]) > 0 for m in V2 + V3 for g in Scone))
# the guard cones are disjoint from the S-cone direction (different cells): check G_1 advice of T is B, S is S
def run(Cname, C):
    normals = [E(0), E(1), E(2)] + T + C + C2 + C3
    cells = list(arrangement_cells(normals).values())
    atoms = [('cell', g) for g in cells] + [('S', h0)] + [('G%d' % (k + 1), guard_dir(k)) for k in range(3)]
    def adv(model, atom):
        kind, g = atom
        if kind == 'S': return advice_on_cone(model, Scone)
        if kind.startswith('G'): return advice_on_cone(model, G[int(kind[1]) - 1])
        return advice(model, orient(g)[1])
    cls = [orient(a[1])[0] for a in atoms]
    Tm = [adv(T, a) for a in atoms]; Cm = [adv(C, a) for a in atoms]
    assert None not in Tm and None not in Cm
    n = len(atoms)
    Xs = [('A' if atoms[q][0] == 'S' else Tm[q]) for q in range(n)]
    guard_ok = all(Xs[q] == Tm[q] for q in range(n) if atoms[q][0].startswith('G'))
    pattern = [Cm[q] for q in range(n) if atoms[q][0].startswith('G')]
    # pointwise 1-no-worse than T
    c_le1 = all(rank(0, cls[q], Cm[q]) <= rank(0, cls[q], Tm[q]) for q in range(n))
    ET = any(Cm[q] != Xs[q] and Xs[q] != Tm[q] for q in range(n))
    EC = any(not atoms[q][0].startswith('G') and Cm[q] != Tm[q] and Xs[q] != Cm[q] for q in range(n))
    Y = [(Cm[q] if cls[q] in (1, 2) else Tm[q]) for q in range(n)]
    y_impr1 = all(rank(0, cls[q], Y[q]) <= rank(0, cls[q], Tm[q]) for q in range(n)) and \
              any(rank(0, cls[q], Y[q]) < rank(0, cls[q], Tm[q]) for q in range(n))
    DR = [q for q in range(n) if Cm[q] != Xs[q]]
    De = [q for q in range(n) if Y[q] != Tm[q]]
    A0 = [(Cm[q] if q in DR else Tm[q]) for q in range(n)]
    B0 = [(Xs[q] if q in DR else Tm[q]) for q in range(n)]
    rep_copy = all((A0[q] != B0[q]) == (q in DR) for q in range(n)) and all(A0[q] == Cm[q] and B0[q] == Xs[q] for q in DR)
    e_copy = all(B0[q] == Tm[q] for q in De)
    Z0 = [(Y[q] if q in De else B0[q]) for q in range(n)]
    res = {}
    for w in (1, 2):
        weak = all(rank(w, cls[q], Z0[q]) <= rank(w, cls[q], A0[q]) for q in range(n))
        strict = any(rank(w, cls[q], Z0[q]) < rank(w, cls[q], A0[q]) for q in range(n))
        res[w + 1] = weak and strict
    print(f"[{Cname}] atoms {n}; guard pattern {pattern}; C <=_1 T pointwise: {c_le1}; X* in X_G: {guard_ok};"
          f" (E_T,E_C) for C: ({ET},{EC}); Y_C strict 1-improvement of T: {y_impr1};"
          f" repair copy ok: {rep_copy}; rec(B0,Z0)=rec(T,Y_C): {e_copy};"
          f" Z0 strict guidance-improvement of A0 at worlds 2,3: {res}")
    return pattern == ['B', 'A', 'A'] and c_le1 and guard_ok and ET and EC and y_impr1 and rep_copy and e_copy and all(res.values())

ok = True
ok &= run("C_1 (a=10)", tilt(0, A_TILT))
for b in (F(9), F(40), F(1000)):
    ok &= run(f"tilt b={b}", tilt(0, b))
ok &= run("I_1", ideal(0))
print("ALL OK" if ok else "FAILURE")
