import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
"""A concentrated KKM repair rec(C_1, Y) for a pure-guard rival Y satisfying N_1 conflicts with a type-(i)
ETR+ defence of T at world 2 (explicit triangle, rank bookkeeping on 8 cells; patterns from s2_geometry.out:
on G_3 lines T = B and C_1 = A; O1 = (1/10,-1,1): T S, C_1 A; O4 = (1,1,-5/2): T S, C_1 A)."""
from cell15 import *
names = ['G1a', 'G1b', 'G2a', 'G2b', 'G3a', 'G3b', 'O1', 'O4']
cls = [0, 0, 1, 1, 2, 2, 1, 2]
T  = 'BBBBBBSS'
C1 = 'BBAAAAAA'
Y  = 'SBABABSS'      # pure-guard rival: S on G1a, A on G2a and G3a, T elsewhere
def r(w, s): return [rk(w, cls[c], "ASB".index(s[c])) for c in range(len(s))]
def rec(x, y): return [(names[c], x[c], y[c]) for c in range(len(x)) if x[c] != y[c]]
P0 = C1                                   # context = C_1 itself
P1 = Y                                    # rec(C_1, Y)
# rho: old side T, restores C_1's advice on G2b, G3b (B -> A) and on O4 (S -> A)
P2 = 'SBAAAAS' + 'A'
P2 = ''.join(['S','B','A','A','A','A','S','A'])
print("kappa = rec(C1,Y):", rec(P0, P1))
print("rho   = rec(P1,P2):", rec(P1, P2))
D = [c for c in range(8) if P1[c] != P2[c]]
assert all(P1[c] == T[c] for c in D), "rho's old side must be T"
print("  rho old side = T on its D:", all(P1[c] == T[c] for c in D), "; breaks G_2:", any(names[c].startswith('G2') for c in D))
full = {l: all((c in D and P2[c] == 'A') for c in range(8) if names[c].startswith('G%d' % l)) for l in (1, 3)}
print("  rho converts all of G_1 / G_3 to majority:", full, "-> type (i) holds:", not any(full.values()))
for w in (0, 1, 2):
    rk0, rk1, rk2 = r(w, P0), r(w, P1), r(w, P2)
    g01 = all(b >= a for a, b in zip(rk0, rk1)); 
    print(f"  world {w+1}: kappa guidance-accepted? {g01};  P2 vs P0: {['=' if a==b else ('better' if b<a else 'worse') for a,b in zip(rk0, rk2)]}")
rk0, rk2 = r(1, P0), r(1, P2)
print("  composite P0 -> P2 is a strict world-2 improvement:", all(b <= a for a, b in zip(rk0, rk2)) and any(b < a for a, b in zip(rk0, rk2)))
print("  exposure of kappa (new side != T on part of D):", any(P1[c] != T[c] for c in range(8) if P0[c] != P1[c]))
print("  N_1 (Y not majority a.e. on G_2 and on G_3):", any(Y[c] != 'A' for c in (2, 3)), any(Y[c] != 'A' for c in (4, 5)))
print("  rec(C1,Y) strictly improving at some world (refused by strict (G))?",
      [all(b <= a for a, b in zip(r(w, P0), r(w, P1))) and any(b < a for a, b in zip(r(w, P0), r(w, P1))) for w in (0, 1, 2)])
