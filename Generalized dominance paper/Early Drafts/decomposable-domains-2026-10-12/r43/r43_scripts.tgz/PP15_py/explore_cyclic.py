import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib15 import *
from pysat.solvers import Cadical153
import pickle
tab = pickle.load(open('cells_a20.pkl', 'rb'))
nc = len(tab)
def allowed(c, j, w):
    g = tab[c]['g']; cj = tab[c]['C'][j]
    return [a for a in ADV if a == cj or rank(a, g, w) < rank(cj, g, w)]
for cyc in ([(0,1),(1,2),(2,0)], [(0,2),(2,1),(1,0)], [(0,1),(1,0)], [(0,1),(2,1)]):
    # X allowed values per cell = intersection
    dom = []
    for c in range(nc):
        s = set(ADV)
        for (j, w) in cyc: s &= set(allowed(c, j, w))
        dom.append(s)
    empty = [c for c in range(nc) if not dom[c]]
    nonT = [c for c in range(nc) if dom[c] - {tab[c]['T']}]
    print('improving pairs', [(j+1, w+1) for j, w in cyc], ': cells with empty domain', len(empty),
          '; cells where X may differ from T:', len(nonT))
    if not empty:
        for c in range(nc):
            if dom[c] != {tab[c]['T']}:
                r = tab[c]
                print('    g', tuple(float(x) for x in r['g']), 'T', r['T'], 'C', r['C'], 'dom', sorted(dom[c]))
