import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
"""Exhaustive cell-abstraction checks (all 3^8 = 6561 models on 8 cells, every relation computed in full).
Cell patterns are the exact ones of s2_geometry.out (eps = 3/10, a = 20, L = 5, b = 44/25).
 E1  task 1: adding T <=_w Y (sigma, all copies) to guidance + TR + filtered repairs;
 E2  Theorem P: guidance + TR + F*-filtered repairs + ETR- at every world;
 E3  necessity of F*;
 E4  Theorem O: X_F = T + majority on O2, its only exposed defender C_3, and Y_C = C_3 silenced on O2;
 E5  KKM candidates for the section-13 rival (Prop K1, K2), on a second cell set containing a cell where
     the intermediate tilt Q_b differs from T off the guards."""
from cell15 import *
import time
t0 = time.time()
W = (0, 1, 2)
names = ['G1a', 'G1b', 'G2a', 'G2b', 'G3', 'O1', 'O2', 'O3']
cs = Cells(names, [0, 0, 1, 1, 2, 1, 2, 0], [0, 0, 1, 1, 2, None, None, None],
           {'T':  'BBBBBSSS',
            'C1': 'BBAAAAAB',
            'C2': 'AABBABAA',
            'C3': 'AAAABABA'})
defs = [('C1', 0), ('C2', 1), ('C3', 2)]
print(f"cells {names}; {cs.NM} models")
G = [cs.guidance(w) for w in W]
TRr = [cs.TR(w) for w in W]
def base_rel(recs):
    m = cs.mask(recs)
    return [G[w] | TRr[w] | m for w in W], m

def report(rel, label, extra_strict=None):
    print(f"  [{label}]")
    for w in W:
        nv, ex = tc_violations(rel[w]); nf, _ = forced_violations(cs, rel[w], w)
        print(f"    world {w+1}: (TC) violations {nv} (forced {nf}); strict-(G) violations {strictG(cs, w, rel[w])}")
    print(f"    T strictly dominated (all worlds) by {dominated(rel, cs.iT)} models;",
          "defenders:", [dominated(rel, cs.j(nm)) for nm, _ in defs])

# ---------------- E1 ----------------
print("\nE1. Task 1: sigma = (G1 u G2, minority -> majority) added at world 1 or 2")
Y13 = cs.model('AAAABSSS')
sig = cs.rec_code(cs.T, Y13); sigmask = cs.code == sig
for filt in (('EC',), ('F3',)):
    recs, cover = cs.repairs(defs, filt)
    rel, m = base_rel(recs)
    print(f" repairs filtered by {filt}: {len(recs)} records; X_G rivals without a defender: {sum(1 for v in cover.values() if not v)}")
    report(rel, 'base')
    for w in (0, 1):
        r = rel[w] | sigmask
        nv, ex = tc_violations(r); nf, exf = forced_violations(cs, r, w)
        print(f"    + sigma at world {w+1}: (TC) violations {nv}, forced {nf}")
        if nf:
            x, z = exf[0]; y = find_middle(r, x, z)
            kind1 = 'sigma' if sigmask[x, y] else ('repair' if m[x, y] else 'other')
            kind2 = 'sigma' if sigmask[y, z] else ('repair' if m[y, z] else 'other')
            print(f"      chain {cs.show(cs.M[x])} -[{kind1}]-> {cs.show(cs.M[y])} -[{kind2}]-> {cs.show(cs.M[z])}"
                  f"  (last is a strict world-{w+1} improvement of the first)")
            # which repairs are involved in forced chains: check every forced chain uses a label-3 repair whose
            # off-guard part is a pointwise strict world-w improvement
            bad_other = 0
            for (x, z) in exf:
                ys = np.nonzero(r[x] & r[:, z])[0]
                okc = False
                for y in ys:
                    for (p, q) in ((x, y), (y, z)):
                        if m[p, q]:
                            C = cs.M[p]; X = cs.M[q]; offD = ~cs.isg & (C != X)
                            if all(cs.rtab[w][X[c], c] < cs.rtab[w][C[c], c] for c in np.nonzero(offD)[0]): okc = True
                if not okc: bad_other += 1
            print(f"      forced chains NOT explained by a (3,{w+1})-improving repair: {bad_other}")

# ---------------- E2/E3 ----------------
ETR = [cs.ETRminus(w) for w in W]
for filt, lab in ((('F*',), 'E2. Theorem P (F*)'), (('EC',), 'E3. same without F* (necessity)')):
    print(f"\n{lab}: guidance + TR + repairs{filt} + ETR- at every world")
    recs, cover = cs.repairs(defs, filt)
    m = cs.mask(recs)
    rel = [G[w] | TRr[w] | m | ETR[w] for w in W]
    print(f"  repairs {len(recs)}; X_G rivals without a filtered defender: {sum(1 for v in cover.values() if not v)} of {len(cover)}")
    report(rel, 'with ETR-')
    eye = np.eye(cs.NM, dtype=bool)
    newties = sum(int((ETR[w] & rel[w].T & ~eye).sum()) for w in W)
    print(f"  ETR- comparisons whose reverse is accepted: {newties}")
    # defence of T against guard-changing rivals
    gch = [jx for jx in range(cs.NM) if not np.array_equal(cs.M[jx][cs.isg], cs.T[cs.isg])]
    nodef = [jx for jx in gch if not any(rel[w][cs.iT, jx] for w in W)]
    inY = []
    for jx in gch:
        Yv = cs.M[jx]
        for w in W:
            gw = np.array([g == w for g in cs.guard])
            if np.any(Yv[gw] != cs.T[gw]) and all(cs.rtab[w][Yv[c], c] >= cs.rtab[w][cs.T[c], c] for c in range(cs.n) if not cs.isg[c]):
                inY.append(jx); break
    print(f"  guard-changing rivals: {len(gch)}; in class Y (Thm P): {len(inY)}; T undefended against {len(nodef)}"
          f" (of which in class Y: {len(set(nodef) & set(inY))})")
    if filt == ('F*',):
        relP, recsP, mP = rel, recs, m

# ---------------- E4 ----------------
print("\nE4. Theorem O: X_F = T + majority on O2")
XF = cs.model('BBBBBSAS')
ok = [nm for nm, lab in defs if cs.repair_ok(cs.pat[nm], XF, lab, ('F*',))]
print(f"  filtered exposed defenders of X_F: {ok}  (C1, C2 give the majority answer on O2)")
YC = cs.pat['C3'].copy(); YC[names.index('O2')] = cs.T[names.index('O2')]
print(f"  Y_C3 = {cs.show(YC)}  (C3 with T's silence on O2); guard-changing: {not np.array_equal(YC[cs.isg], cs.T[cs.isg])}")
c = cs.rec_code(cs.T, YC); add = cs.code == c
for w in W:
    r = relP[w] | add
    nf, exf = forced_violations(cs, r, w)
    print(f"  T <=_{w+1} Y_C3 added: strict-(G) violations {strictG(cs, w, r)}, forced (TC) violations {nf}", end='')
    if nf:
        x, z = exf[0]; y = find_middle(r, x, z)
        print(f";  e.g. {cs.show(cs.M[x])} -> {cs.show(cs.M[y])} -> {cs.show(cs.M[z])}")
    else: print()
print(f"  [elapsed {time.time()-t0:.0f}s]")
