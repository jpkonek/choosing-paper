import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
"""Exact geometric inputs (eps = 3/10, a = 20, guard parameter L = 5):
 (1) guards G_k = cones around gamma_k = L e_k - (1 - e_k): T gives the minority answer strictly; every
     i-defender has the guard pattern; the guard patterns force  V_1 u V_2 in {m_3 < 1/(L+1)} and
     V_3 in {m_3 > 1 - 2/(L+1)}, with 1/(L+1) < c < c + eps < 1 - 2/(L+1)   (V-separation, Thm O);
 (2) the test regions of Lemma 4* (L-A, L-B, L-C) and of Theorem O (the set F), at exact points;
 (3) the representative lines of the 8 cells used by s4_cells.py, with the advice of T, C_1, C_2, C_3
     and of the intermediate e_3-tilt Q_b = Phi_{(1,1,b)}(T)."""
from lib15 import *

eps = F(3, 10); a = 20; L = 5
S = Setting(eps, a); c = S.c
print(f"eps={eps}, c={c}, c+eps={c+eps}, a={a}, L={L}, 1/(L+1)={F(1,L+1)}, 1-2/(L+1)={1-F(2,L+1)}")
assert F(1, L+1) < c < c + eps < 1 - F(2, L+1)

def mm(g):  # minority/majority encoding of advice relative to line g:  A majority, B minority, S
    pass

def cls(g):
    s = [x > 0 for x in g]
    for i in W3:
        if sum(1 for j in W3 if s[j] == s[i]) == 1: return i
    return None

def enc(adv, g):
    """P/N advice -> A (majority) / B (minority)."""
    if adv in ('S', 'C', 'Z'): return adv
    k = cls(g); assert k is not None
    minority_P = g[k] > 0      # accepting g is correct for the minority world iff g_k > 0
    return 'B' if (adv == 'P') == minority_P else 'A'

gam = [tuple(F(L) if t == k else F(-1) for t in W3) for k in W3]
print("\n(1) guards")
for k in W3:
    g = gam[k]
    print(f"  gamma_{k+1}={tuple(int(x) for x in g)}: T={enc(S.T(g),g)} (lower prevision {min(dot(g,v) for v in S.M)}),",
          " C_1,C_2,C_3 =", [enc(S.Cj(j, g), g) for j in W3])
# aperture check: random lines in the cone of aperture 1/50 around each gamma_k
import random
rng = random.Random(3); bad = 0; n = 0
for k in W3:
    for _ in range(400):
        d = tuple(F(rng.randint(-1000, 1000), 50000) for _ in W3)
        g = tuple(gam[k][t] + d[t]*L for t in W3)
        n += 1
        pat = [enc(S.Cj(j, g), g) for j in W3]
        want = ['B' if j == k else 'A' for j in W3]
        if enc(S.T(g), g) != 'B' or pat != want: bad += 1
print(f"  {n} random lines within relative aperture 1/50 of the generators: {bad} failures of (T minority, defender pattern)")
print("  guard-forced bounds: an i-defender gives the majority answer on gamma_k (k != i) iff (L+1) m_k < 1, i.e. m_k < 1/(L+1);")
print("  so V_1,V_2 lie in {m_3 < 1/6} and V_3 in {m_1,m_2 < 1/6} c {m_3 > 2/3}.")

print("\n(2) test regions (exact points)")
def show(name, g, models=('T', 0, 1, 2)):
    out = []
    for m in models:
        adv = S.T(g) if m == 'T' else S.Cj(m, g)
        out.append(f"{'T' if m=='T' else 'C'+str(m+1)}={adv}")
    print(f"  {name:38s} g={tuple(str(x) for x in g)}  " + "  ".join(out) + "   correct:" + "".join(correct(g, w) for w in W3))
d = F(1, 10)
for (j, k, w) in [(0, 1, 2), (0, 2, 1), (1, 0, 2), (1, 2, 0), (2, 0, 1), (2, 1, 0)]:
    for s in (1, -1):
        g = [F(0)]*3; g[j] = F(1); g[k] = F(-1); g[w] = s*d
        show(f"R({j+1},{k+1},{'+' if s>0 else '-'}) [L-C, Lemma 4]", tuple(g))
eta = F(1, 400)
for (j, w, k) in [(0, 1, 2), (1, 2, 0), (2, 0, 1), (0, 2, 1), (2, 1, 0), (1, 0, 2)]:
    g = [F(0)]*3; g[j] = F(1); g[w] = eta; g[k] = F(-3)
    show(f"Q({j+1},{w+1},{k+1}) [L-B: C{j+1} w-correct P, C{w+1} k-correct N]", tuple(g))
for (j, k, w) in [(0, 1, 2), (1, 2, 0), (2, 0, 1)]:
    # E1: g_j=1, g_k=-t (t< c/(c+eps)), g_w=-eta  : T=P, C_k=N (w-correct), C_w=S
    for t in (F(2, 5),):
        for et in (F(1, 40), F(1, 60), F(1, 100)):
            g = [F(0)]*3; g[j] = F(1); g[k] = -t; g[w] = -et
            show(f"E1({j+1},{k+1},{w+1}) t={t} eta={et} [L-A exp.]", tuple(g))
    for et in (F(1, 2000),):
        g = [F(0)]*3; g[j] = F(1); g[k] = F(-1); g[w] = et
        show(f"E2({j+1},{k+1},{w+1}) [L-A, C{j+1} w-correct, C{w+1}=S]", tuple(g))
        g = [F(0)]*3; g[k] = F(1); g[j] = F(-1); g[w] = et
        show(f"E3({j+1},{k+1},{w+1}) [L-A, C{k+1} w-correct, C{w+1}=S]", tuple(g))
print("  Theorem O set F: g0=(1,1,-1) (theta=1/2 in (c,c+eps)); all 1-,2-defenders accept, all 3-defenders reject:")
g0 = (F(1), F(1), F(-1))
show("F: g0", g0)
print("   m.g0 = 1 - 2 m_3 : positive on {m_3 < 1/2} > V_1 u V_2, negative on {m_3 > 1/2} > V_3;  T: lower",
      min(dot(g0, v) for v in S.M), "upper", max(dot(g0, v) for v in S.M))

print("\n(3) representative lines of the 8-cell abstraction (advice in majority A / minority B / silence S)")
b = F(44, 25)   # intermediate e_3 tilt
Qb = rescale(S.M, (F(1), F(1), b))
cellsdef = {
 'G1a': (F(5), F(-1), F(-1)),
 'G1b': (F(5), F(-1), F(-49, 50)),
 'G2a': (F(-1), F(5), F(-1)),
 'G2b': (F(-1), F(5), F(-49, 50)),
 'G3':  (F(-1), F(-1), F(5)),
 'O1':  (F(1, 10), F(-1), F(1)),
 'O2':  (F(1), F(1), F(-1)),
 'O3':  (F(-1), F(1, 10), F(1)),
 'O4':  (F(1), F(1), F(-5, 2)),
}
for nm, g in cellsdef.items():
    row = [enc(S.T(g), g)] + [enc(S.Cj(j, g), g) for j in W3] + [enc(advice(Qb, g), g)]
    print(f"  {nm:4s} class {cls(g)+1}  g={tuple(str(x) for x in g)}  T,C1,C2,C3,Q_b = {row}")
print(f"  Q_b = Phi_(1,1,{b})(T); Q_b >=_3 T pointwise (scaling the 3rd payoff by b>1).")
