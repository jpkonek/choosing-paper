"""PP15 cell abstraction (exhaustive combinatorics; cells are atoms).

Advice codes 0 = A (majority answer), 1 = S (silence), 2 = B (minority answer).  Contradiction is omitted
(3 values per cell) to keep 3^n models; every rule below treats contradiction like any worst-rank advice,
so its omission only removes models, never adds acceptances.
Rank at world w on a class-k cell: w == k (minority world): B 0, S 1, A 2; w != k: A 0, S 1, B 2.
Records are (D, old, new); a relation accepts a pair (Y, Z) ("Y no worse than Z") according to rules that
inspect the record only, so (IB) holds by construction."""
import itertools
import numpy as np

A, S, B = 0, 1, 2
NAME = "ASB"

def rk(w, k, adv):
    if w == k: return [2, 1, 0][adv]
    return [0, 1, 2][adv]

class Cells:
    def __init__(self, names, classes, guard, patterns):
        """names: cell names; classes: minority world (0..2) per cell; guard: guard index (0..2) or None per cell;
        patterns: dict model-name -> list of advice letters ('A','S','B') per cell (must contain 'T')."""
        self.names = names; self.n = len(names)
        self.cls = np.array(classes); self.guard = [g for g in guard]
        self.isg = np.array([g is not None for g in guard])
        self.pat = {k: np.array(["ASB".index(x) for x in v], np.int8) for k, v in patterns.items()}
        self.T = self.pat['T']
        M = np.array(list(itertools.product(range(3), repeat=self.n)), np.int8)
        self.M = M; self.NM = len(M)
        self.idx = {tuple(m): j for j, m in enumerate(M.tolist())}
        self.rtab = np.array([[[rk(w, self.cls[c], a) for c in range(self.n)] for a in range(3)] for w in range(3)], np.int8)
        self.R = [self.rtab[w][M, np.arange(self.n)] for w in range(3)]          # (NM, n)
        self.rT = [self.rtab[w][self.T, np.arange(self.n)] for w in range(3)]
        self.base = 10 ** np.arange(self.n, dtype=np.int64)
        code = np.zeros((self.NM, self.NM), np.int64)
        for c in range(self.n):
            a = M[:, c].astype(np.int64)
            code += np.where(a[:, None] != a[None, :], 1 + 3 * a[:, None] + a[None, :], 0) * self.base[c]
        self.code = code
        self.isT = np.all(M == self.T, axis=1)
        self.iT = self.idx[tuple(self.T.tolist())]

    def j(self, name): return self.idx[tuple(self.pat[name].tolist())]
    def model(self, letters): return np.array(["ASB".index(x) for x in letters], np.int8)
    def show(self, m): return "".join(NAME[x] for x in m)

    def rec_code(self, Y, Z):
        Y = np.asarray(Y, np.int64); Z = np.asarray(Z, np.int64)
        return int((np.where(Y != Z, 1 + 3 * Y + Z, 0) * self.base).sum())

    # ---------- rules ----------
    def guidance(self, w):
        Rw = self.R[w]
        return np.all(Rw[:, None, :] <= Rw[None, :, :], axis=2)
    def strictly_better(self, w):
        """sb[Y, Z]: Z is a strict pointwise improvement of Y at w (strict (G) refuses Y <=_w Z)."""
        Rw = self.R[w]
        return np.all(Rw[None, :, :] <= Rw[:, None, :], axis=2) & np.any(Rw[None, :, :] < Rw[:, None, :], axis=2)
    def _oldT(self):
        M = self.M; D = M[:, None, :] != M[None, :, :]
        return D, np.all(~D | (M == self.T)[:, None, :], axis=2)
    def TR(self, w):
        D, oldT = self._oldT()
        offg = ~np.any(D[:, :, self.isg], axis=2)
        worse = np.any(D & (self.R[w][None, :, :] > self.rT[w]), axis=2)
        return offg & oldT & worse
    def ETRminus(self, w):
        """old side = T on D; new side differs from T on some cell of G_w; new side weakly w-worse than T on
        the off-guard cells of D."""
        D, oldT = self._oldT()
        gw = np.array([g == w for g in self.guard])
        breaks = np.any(D[:, :, gw], axis=2)
        offworse = np.all(~(D & ~self.isg) | (self.R[w][None, :, :] >= self.rT[w]), axis=2)
        return oldT & breaks & offworse

    # ---------- repairs ----------
    def XG(self):
        return [jx for jx in range(self.NM) if np.array_equal(self.M[jx][self.isg], self.T[self.isg]) and jx != self.iT]
    def repair_ok(self, C, X, label, filt):
        T = self.T; g = self.isg
        ET = np.any((C != X) & (X != T))
        if not ET: return False
        if 'EC' in filt or 'F*' in filt or 'F3' in filt:
            if not np.any(~g & (C != T) & (X != C)): return False
        offD = ~g & (C != X)
        for w in range(3):
            if w == label: continue
            if 'F*' in filt or ('F3' in filt and label == 2):
                cells = np.nonzero(offD)[0]
                if all(self.rtab[w][X[c], c] < self.rtab[w][C[c], c] for c in cells):
                    return False
        return True
    def repairs(self, defs, filt, choose=None):
        """defs: list of (pattern-name, label).  Returns set of record codes and coverage dict."""
        recs = set(); cover = {}
        for jx in self.XG():
            X = self.M[jx]
            ok = [(nm, lab) for nm, lab in defs if self.repair_ok(self.pat[nm], X, lab, filt)]
            cover[jx] = ok
            for nm, lab in (ok if choose is None else ok[:1]):
                recs.add(self.rec_code(self.pat[nm], X))
        return recs, cover
    def mask(self, recs):
        if not recs: return np.zeros((self.NM, self.NM), bool)
        return np.isin(self.code, np.array(sorted(recs), np.int64))

# ---------- checks ----------
def two_step(r):
    f = r.astype(np.float32)
    return (f @ f) > 0
def tc_violations(r):
    bad = two_step(r) & r.T & ~r
    return int(bad.sum()), np.argwhere(bad)
def find_middle(r, x, z):
    ys = np.nonzero(r[x] & r[:, z])[0]
    return int(ys[0]) if len(ys) else None
def forced_violations(cs, r, w):
    """chains Y<=Z<=U with U a strict pointwise improvement of Y at w: violations that no further acceptance
    can remove (Y<=_w U is refused by strict (G))."""
    bad = two_step(r) & cs.strictly_better(w)
    return int(bad.sum()), np.argwhere(bad)
def strictG(cs, w, r):
    return int((cs.strictly_better(w) & r).sum())
def dominated(rel, j):
    """models Y with Y <_w j at every world (strict at every world)."""
    s = np.ones(rel[0].shape[0], bool)
    for r in rel: s &= r[:, j] & ~r[j, :]
    return int(s.sum())

def ETRplus_parts(cs, w):
    """ETR+_w = (i) u (ii):  old side = T on D, D meets G_w (breaks it), and
       (i)  for every l != w, the record does not convert all of G_l to the majority answer
            (some G_l cell outside D, or with new side != A), or
       (ii) the new side is weakly w-worse than T on the off-guard cells of D  (= ETR-_w)."""
    M = cs.M; D = M[:, None, :] != M[None, :, :]
    oldT = np.all(~D | (M == cs.T)[:, None, :], axis=2)
    gw = np.array([g == w for g in cs.guard])
    breaks = np.any(D[:, :, gw], axis=2)
    typei = np.ones_like(breaks)
    for l in range(3):
        if l == w: continue
        gl = np.array([g == l for g in cs.guard])
        full = np.all(D[:, :, gl] & (M[None, :, :][:, :, gl] == 0), axis=2)   # every G_l cell in D with new side A
        typei &= ~full
    offworse = np.all(~(D & ~cs.isg) | (cs.R[w][None, :, :] >= cs.rT[w]), axis=2)
    return oldT & breaks & typei, oldT & breaks & offworse
