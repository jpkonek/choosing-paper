import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
"""Part 3 (KKM dominators for guard-changing rivals), exhaustive on 8 cells (patterns from s2_geometry.out;
Q_b = Phi_(1,1,44/25)(T)).  Usage: python3 -I -B s5_kkm.py C   (cells G1a G1b G2a G2b G3 O1 O3 O4; default)
                                   python3 -I -B s5_kkm.py B   (cells G1a G1b G2a G2b G3 O1 O2 O4).
Base relation R: guidance + TR + F*-filtered repairs (C1,C2,C3) + ETR- at every world (Theorem P).
 E5  the section-13 rival Y13 = T + majority on G1 u G2: can rec(Q, Y13) be added at all worlds, for
     Q in {C1, C2, C3, Q_b}?  (Prop K1 for C3, Prop K2 for C1, C2.)
 E6  concentrated-defender rule: rec(C_i, Y) for pure-guard rivals Y satisfying N_i.
 E7  the intermediate tilt Q_b for the pure-guard rivals left without a concentrated dominator."""
from cell15 import *
import time
t0 = time.time(); W = (0, 1, 2)
CELLSET = sys.argv[1] if len(sys.argv) > 1 else 'C'
if CELLSET == 'B':
    names = ['G1a', 'G1b', 'G2a', 'G2b', 'G3', 'O1', 'O2', 'O4']
    cs = Cells(names, [0, 0, 1, 1, 2, 1, 2, 2], [0, 0, 1, 1, 2, None, None, None],
               {'T': 'BBBBBSSS', 'C1': 'BBAAAAAA', 'C2': 'AABBABAA', 'C3': 'AAAABABB', 'Qb': 'SBSBBSSB'})
else:   # set C: O3 (class 1, (-1,1/10,1)) is the cell where C2 beats T at world 3 and C3 beats T at world 2
    names = ['G1a', 'G1b', 'G2a', 'G2b', 'G3', 'O1', 'O3', 'O4']
    cs = Cells(names, [0, 0, 1, 1, 2, 1, 0, 2], [0, 0, 1, 1, 2, None, None, None],
               {'T': 'BBBBBSSS', 'C1': 'BBAAAABA', 'C2': 'AABBABAA', 'C3': 'AAAABAAB', 'Qb': 'SBSBBSSB'})
print("cell set", CELLSET)
defs = [('C1', 0), ('C2', 1), ('C3', 2)]
G = [cs.guidance(w) for w in W]; TRr = [cs.TR(w) for w in W]; ETR = [cs.ETRminus(w) for w in W]
SB = [cs.strictly_better(w) for w in W]
recs, cover = cs.repairs(defs, ('F*',)); m = cs.mask(recs)
R = [G[w] | TRr[w] | m | ETR[w] for w in W]
print(f"cells {names}; {cs.NM} models; F*-repairs {len(recs)}")
def check(rel, label):
    out = []
    for w in W:
        nv, _ = tc_violations(rel[w]); nf, _ = forced_violations(cs, rel[w], w)
        out.append((nv, nf, int((SB[w] & rel[w]).sum())))
    print(f"  {label}: per world (TC viol, forced, strict-(G) viol) = {out}")
    return out
check(R, 'base R')
print("  dominated (strictly at all worlds): T", dominated(R, cs.iT), " C1,C2,C3,Qb",
      [dominated(R, cs.j(nm)) for nm in ('C1', 'C2', 'C3', 'Qb')])

print("\nE5. section-13 rival Y13 = AAAABSSS")
Y13 = cs.model('AAAABSSS')
for nm in ('C1', 'C2', 'C3', 'Qb'):
    add = cs.code == cs.rec_code(cs.pat[nm], Y13)
    res = []
    for w in W:
        r = R[w] | add
        nv, _ = tc_violations(r); nf, exf = forced_violations(cs, r, w)
        res.append((w + 1, nv, nf, int((SB[w] & r).sum())))
    print(f"  {nm} <= Y13 at all worlds: (world, TC viol, forced, strict-(G)) {res}")

print("\nE6/E7. KKM records for pure-guard rivals")
pure = [jx for jx in range(cs.NM) if np.array_equal(cs.M[jx][~cs.isg], cs.T[~cs.isg]) and not np.array_equal(cs.M[jx][cs.isg], cs.T[cs.isg])]
gk = {k: np.array([g == k for g in cs.guard]) for k in W}
def admissible(Q, Y):   # not refused by strict (G) at any world
    jq = cs.idx[tuple(Q.tolist())]; jy = cs.idx[tuple(Y.tolist())]
    return not any(SB[w][jq, jy] for w in W)
kk = set(); nocon = []
for jx in pure:
    Y = cs.M[jx]; got = False
    for nm, i in defs:
        Ni = all(np.any(Y[gk[k]] != A) for k in W if k != i)
        expo = np.any((Y != cs.pat[nm]) & (Y != cs.T))     # new side differs from T on part of D (protects T)
        if Ni and expo and admissible(cs.pat[nm], Y) and not np.array_equal(cs.pat[nm], Y):
            kk.add(cs.rec_code(cs.pat[nm], Y)); got = True
    if not got: nocon.append(jx)
print(f"  pure-guard rivals {len(pure)}; with a concentrated dominator candidate (N_i): {len(pure)-len(nocon)}; without: {len(nocon)}")
mk = cs.mask(kk)
R6 = [R[w] | mk for w in W]
o6 = check(R6, 'R + all N_i-admissible rec(C_i, Y)')
print("  dominated: T", dominated(R6, cs.iT), " C1,C2,C3", [dominated(R6, cs.j(nm)) for nm, _ in defs])
# E7: Q_b for the rest
qb = set(); stillno = []
for jx in nocon:
    Y = cs.M[jx]
    if admissible(cs.pat['Qb'], Y) and np.any((Y != cs.pat['Qb']) & (Y != cs.T)): qb.add(cs.rec_code(cs.pat['Qb'], Y))
    else: stillno.append(jx)
print(f"  rivals without concentrated candidate that Q_b can take ((G)-admissibly): {len(nocon)-len(stillno)}; left: {len(stillno)}",
      [cs.show(cs.M[j]) for j in stillno[:8]])
mq = cs.mask(qb)
R7 = [R[w] | mq for w in W]
check(R7, 'R + rec(Q_b, Y) for those rivals')
R67 = [R6[w] | mq for w in W]
check(R67, 'R + both families')
print("  dominated: T", dominated(R67, cs.iT), " C1,C2,C3,Qb", [dominated(R67, cs.j(nm)) for nm in ('C1','C2','C3','Qb')])
print(f"  [elapsed {time.time()-t0:.0f}s]")
