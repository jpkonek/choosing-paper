import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.argv = [sys.argv[0], 'B']   # run on cell set B (the set without a cell where C3 beats T at world 2)
exec(open('s5_kkm.py').read().split('print("\\nE5.')[0])
pure = [jx for jx in range(cs.NM) if np.array_equal(cs.M[jx][~cs.isg], cs.T[~cs.isg]) and not np.array_equal(cs.M[jx][cs.isg], cs.T[cs.isg])]
gk = {k: np.array([g == k for g in cs.guard]) for k in W}
def admissible(Q, Y):
    jq = cs.idx[tuple(Q.tolist())]; jy = cs.idx[tuple(Y.tolist())]
    return not any(SB[w][jq, jy] for w in W)
kk = {}
for jx in pure:
    Y = cs.M[jx]
    for nm, i in defs:
        Ni = all(np.any(Y[gk[k]] != A) for k in W if k != i)
        expo = np.any((Y != cs.pat[nm]) & (Y != cs.T))
        if Ni and expo and admissible(cs.pat[nm], Y) and not np.array_equal(cs.pat[nm], Y):
            kk[cs.rec_code(cs.pat[nm], Y)] = (nm, cs.show(Y))
mk = cs.mask(set(kk))
R6 = [R[w] | mk for w in W]
for w in W:
    nf, exf = forced_violations(cs, R6[w], w); nv, ex = tc_violations(R6[w])
    print(f"world {w+1}: TC viol {nv}, forced {nf}")
    for (x, z) in exf[:4]:
        y = find_middle(R6[w], x, z)
        def kind(p, q):
            if mk[p, q]: return 'KKM' + str(kk[int(cs.code[p, q])])
            if m[p, q]: return 'repair'
            if ETR[w][p, q]: return 'ETR'
            if TRr[w][p, q]: return 'TR'
            if G[w][p, q]: return 'guid'
            return '?'
        print(f"   {cs.show(cs.M[x])} -[{kind(x,y)}]-> {cs.show(cs.M[y])} -[{kind(y,z)}]-> {cs.show(cs.M[z])}  (last strictly better at w than first)")
print("dominated T:", dominated(R6, cs.iT))
