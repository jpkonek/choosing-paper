"""PP15 shared library: exact (Fraction) geometry for T1 = D_M (contamination), the section-11 defenders
C_j = D_{K_j}, K_j = Phi_{s_j}(M) (coordinate j multiplied by a), and the arrangement of problems.

Conventions (as in AUDIT_guard_extension.md):
  * worlds 0,1,2 in code = worlds 1,2,3 in the note;
  * a problem is g in R^3 modulo sign; advice is relative to a fixed representative g:
      'P' = accept g, 'N' = accept -g, 'S' = silent, 'C' = contradiction;
  * D_K for a polytope K: P if g.v > 0 at every vertex, N if < 0 at every vertex, S if mixed;
    'Z' (non-generic: a vertex on the line) is avoided;
  * ranks at world w: correct answer 0, S 1, wrong answer 2, contradiction 3; the correct answer at w is
    P if g_w > 0 and N if g_w < 0 (g_w = 0 avoided).
Everything is exact rational arithmetic; open conditions only, so every cell statement is a.e.-correct."""
from fractions import Fraction as F
import itertools, random

W3 = (0, 1, 2)
ADV = ('P', 'N', 'S', 'C')

def dot(a, b): return sum(x*y for x, y in zip(a, b))
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def neg(g): return tuple(-x for x in g)

def Mverts(eps):
    c = (1 - eps)/3
    return [tuple(c + (eps if t == l else 0) for t in W3) for l in W3]

def rescale(V, s):
    out = []
    for v in V:
        sv = tuple(s[t]*v[t] for t in W3); z = sum(sv)
        out.append(tuple(x/z for x in sv))
    return out

def defender_verts(j, a, eps):
    s = [F(1)]*3; s[j] = F(a)
    return rescale(Mverts(eps), s)

def advice(V, g):
    s = [dot(g, v) for v in V]
    if any(x == 0 for x in s): return 'Z'
    if all(x > 0 for x in s): return 'P'
    if all(x < 0 for x in s): return 'N'
    return 'S'

def correct(g, w):
    if g[w] == 0: return 'Z'
    return 'P' if g[w] > 0 else 'N'

def rank(adv, g, w):
    if adv == 'C': return 3
    if adv == 'S': return 1
    return 0 if adv == correct(g, w) else 2

def flip(adv):
    return {'P': 'N', 'N': 'P'}.get(adv, adv)

def canon(g):
    """canonical representative of the line {g,-g}: first nonzero coordinate positive."""
    for x in g:
        if x != 0:
            return tuple(g) if x > 0 else neg(g)
    return tuple(g)

class Setting:
    def __init__(self, eps=F(3, 10), a=20):
        self.eps = F(eps); self.c = (1 - self.eps)/3; self.a = F(a)
        self.M = Mverts(self.eps)
        self.K = [defender_verts(j, a, self.eps) for j in W3]
        # normals of the arrangement: vertices of M and of K_j, and the coordinate vectors
        self.normals = []
        for v in self.M + self.K[0] + self.K[1] + self.K[2] + [(F(1), F(0), F(0)), (F(0), F(1), F(0)), (F(0), F(0), F(1))]:
            if v not in self.normals: self.normals.append(v)
    def T(self, g): return advice(self.M, g)
    def Cj(self, j, g): return advice(self.K[j], g)
    def signvec(self, g):
        return tuple((dot(g, n) > 0) - (dot(g, n) < 0) for n in self.normals)

def cells(S, ndir=48, nrand=20000, seed=1):
    """Representatives of all 2-cells of the great-circle arrangement (modulo antipodes), exactly:
    perturb every vertex of the arrangement in ndir tangent directions with an exactly verified small step,
    then add random points as a cross-check.  Returns dict signvec(canon) -> representative g."""
    reps = {}
    def add(g):
        g = canon(g)
        sv = S.signvec(g)
        if 0 in sv: return False
        if sv not in reps: reps[sv] = g; return True
        return False
    N = S.normals
    verts = []
    for n1, n2 in itertools.combinations(N, 2):
        p = cross(n1, n2)
        if p == (0, 0, 0): continue
        verts.append(p)
    for p in verts:
        for pp in (p, neg(p)):
            # tangent basis at pp
            through = [n for n in N if dot(n, pp) == 0]
            u = through[0]; t1 = cross(pp, u); t2 = cross(pp, t1)
            for k in range(ndir):
                # rational point on a circle via Pythagorean-like param
                tt = F(2*k + 1, 2*ndir)*4 - 2   # in (-2,2)
                x = (1 - tt*tt)/(1 + tt*tt); y = 2*tt/(1 + tt*tt)
                for sgn in (1, -1):
                    d = tuple(sgn*(x*t1[i] + y*t2[i]) for i in W3)
                    eta = F(1, 10**6)
                    while True:
                        g = tuple(pp[i] + eta*d[i] for i in W3)
                        ok = True
                        for n in N:
                            if dot(n, pp) != 0:
                                if (dot(n, g) > 0) != (dot(n, pp) > 0): ok = False; break
                            else:
                                if dot(n, d) == 0: ok = False; break
                                if (dot(n, g) > 0) != (dot(n, d) > 0): ok = False; break
                        if ok: break
                        eta /= 10
                        if eta < F(1, 10**40): g = None; break
                    if g is not None: add(g)
    rng = random.Random(seed)
    newr = 0
    for _ in range(nrand):
        g = tuple(F(rng.randint(-10**6, 10**6), 10**6) for _ in W3)
        if add(g): newr += 1
    return reps, newr

def cell_table(S, reps):
    """list of dicts with representative g, T advice, C_j advice, correct answers."""
    tab = []
    for sv, g in reps.items():
        row = {'g': g, 'T': S.T(g), 'C': [S.Cj(j, g) for j in W3], 'cor': [correct(g, w) for w in W3]}
        assert row['T'] != 'Z' and 'Z' not in row['C'] and 'Z' not in row['cor']
        tab.append(row)
    return tab
