import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
"""Lemma 4* screen: is there a rival X (constant on cells of the arrangement; WLOG, see note) with X != T
such that for EVERY section-11 defender C_j the pair (C_j, X) is either not doubly exposed ((E_T),(E_C))
or its off-guard part is a pointwise strict world-w improvement for some w != j  (filter F*)?
Also the weaker filter sets.  Exact SAT (pysat, CaDiCaL)."""
from lib15 import *
from pysat.solvers import Cadical153
import pickle

def build(tab, filt):
    """filt: set of (j,w) pairs that are filtered (label j repairs that are pointwise w-improvements excluded)."""
    nc = len(tab); var = {}
    def v(*k):
        if k not in var: var[k] = len(var) + 1
        return var[k]
    cl = []
    for c in range(nc):
        cl.append([v('x', c, a) for a in ADV])
        for a1, a2 in itertools.combinations(ADV, 2): cl.append([-v('x', c, a1), -v('x', c, a2)])
    cl.append([v('x', c, a) for c in range(nc) for a in ADV if a != tab[c]['T']])
    for j in W3:
        # e_j <-> (E_T); f_j <-> (E_C)   (only the direction lit -> e needed)
        for c in range(nc):
            for a in ADV:
                if a != tab[c]['C'][j] and a != tab[c]['T']: cl.append([-v('x', c, a), v('e', j)])
                if tab[c]['C'][j] != tab[c]['T'] and a != tab[c]['C'][j]: cl.append([-v('x', c, a), v('f', j)])
        ms = []
        for w in W3:
            if w == j or (j, w) not in filt: continue
            m = v('m', j, w); ms.append(m)
            for c in range(nc):
                g = tab[c]['g']; cj = tab[c]['C'][j]
                for a in ADV:
                    if a != cj and not rank(a, g, w) < rank(cj, g, w): cl.append([-m, -v('x', c, a)])
        cl.append([-v('e', j), -v('f', j)] + ms)
    return cl, var

def solve(tab, filt):
    cl, var = build(tab, filt)
    with Cadical153(bootstrap_with=cl) as s:
        if not s.solve(): return None
        mod = set(l for l in s.get_model() if l > 0)
        X = []
        for c in range(len(tab)):
            for a in ADV:
                if var[('x', c, a)] in mod: X.append(a)
        return X

if __name__ == '__main__':
    out = {}
    for a in (20, 6):
        S = Setting(F(3, 10), a)
        reps, _ = cells(S, nrand=2000)
        tab = cell_table(S, reps)
        full = {(j, w) for j in W3 for w in W3 if j != w}
        tests = [('no filter (Lemma 4 itself)', set()),
                 ('label-3 filters (3,1),(3,2)  [task 1]', {(2, 0), (2, 1)}),
                 ('F*: all six (j,w)', full)]
        for name, filt in tests:
            X = solve(tab, filt)
            print(f"a={a} {name}: {'COUNTEREXAMPLE FOUND' if X else 'UNSAT (every X != T has a filtered defender among C_1,C_2,C_3)'}")
            if X:
                for c, row in enumerate(tab):
                    if X[c] != row['T']:
                        print('   cell', row['g'], 'T', row['T'], 'C', row['C'], 'X', X[c])
            out[(a, name)] = X
        pickle.dump(tab, open(f'cells_a{a}.pkl', 'wb'))
