import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib15 import *
for a in (20, 6):
    S = Setting(F(3, 10), a)
    reps, newr = cells(S)
    tab = cell_table(S, reps)
    print(f"eps=3/10 a={a}: {len(S.normals)} great circles, {len(reps)} cells (random points adding new cells: {newr})")
    # checks of section-11 / Lemma 4 facts
    for j in W3:
        mins = min(v[j] for v in S.K[j])
        print(f"  K_{j+1}: min coordinate {j+1} = {float(mins):.4f} (>1/2: {mins > F(1,2)})")
