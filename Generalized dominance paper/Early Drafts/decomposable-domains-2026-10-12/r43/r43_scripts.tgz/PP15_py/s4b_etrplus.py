import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
"""Theorem P with the full rule ETR+ = (i) u (ii), on the 8-cell set of s4_cells.py (6561 models):
  P(i)   guidance + TR + (E_T,E_C)-repairs [NO F*] + ETR+(i)   : type (i) needs no extra filter;
  P(i+ii) guidance + TR + F*-repairs + ETR+(i) + ETR+(ii)        : Theorem P.
Also counts the guard-changing rivals against which T is defended, and the residual class Z."""
from cell15 import *
import time
t0 = time.time(); W = (0, 1, 2)
names = ['G1a', 'G1b', 'G2a', 'G2b', 'G3', 'O1', 'O2', 'O3']
cs = Cells(names, [0, 0, 1, 1, 2, 1, 2, 0], [0, 0, 1, 1, 2, None, None, None],
           {'T': 'BBBBBSSS', 'C1': 'BBAAAAAB', 'C2': 'AABBABAA', 'C3': 'AAAABABA'})
defs = [('C1', 0), ('C2', 1), ('C3', 2)]
G = [cs.guidance(w) for w in W]; TRr = [cs.TR(w) for w in W]
parts = [ETRplus_parts(cs, w) for w in W]
for filt, use, lab in ((('EC',), (True, False), 'P(i): EC-repairs + ETR+(i) only'),
                       (('F*',), (True, True), 'P(i+ii): F*-repairs + ETR+(i) + ETR+(ii)')):
    recs, cover = cs.repairs(defs, filt); m = cs.mask(recs)
    rel = []
    for w in W:
        r = G[w] | TRr[w] | m
        if use[0]: r = r | parts[w][0]
        if use[1]: r = r | parts[w][1]
        rel.append(r)
    print(f"[{lab}] repairs {len(recs)}")
    for w in W:
        nv, _ = tc_violations(rel[w]); nf, _ = forced_violations(cs, rel[w], w)
        print(f"   world {w+1}: (TC) violations {nv} (forced {nf}); strict-(G) violations {strictG(cs, w, rel[w])}")
    print("   strictly dominated: T", dominated(rel, cs.iT), " C1,C2,C3", [dominated(rel, cs.j(nm)) for nm, _ in defs])
    gch = [jx for jx in range(cs.NM) if not np.array_equal(cs.M[jx][cs.isg], cs.T[cs.isg])]
    nodef = [jx for jx in gch if not any(rel[w][cs.iT, jx] for w in W)]
    # residual class Z: majority a.e. on >= 2 guards and, for every broken guard w, strictly w-better than T off guards somewhere
    gk = {k: np.array([g == k for g in cs.guard]) for k in W}
    def inZ(Y):
        if sum(1 for k in W if np.all(Y[gk[k]] == A)) < 2: return False
        for w in W:
            if np.any(Y[gk[w]] != cs.T[gk[w]]):
                if not any(cs.rtab[w][Y[c], c] < cs.rtab[w][cs.T[c], c] for c in range(cs.n) if not cs.isg[c]): return False
        return True
    Z = [jx for jx in gch if inZ(cs.M[jx])]
    print(f"   guard-changing rivals {len(gch)}; T undefended against {len(nodef)}; residual class Z has {len(Z)};"
          f" undefended outside Z: {len(set(nodef) - set(Z))}")
print(f"[elapsed {time.time()-t0:.0f}s]")
