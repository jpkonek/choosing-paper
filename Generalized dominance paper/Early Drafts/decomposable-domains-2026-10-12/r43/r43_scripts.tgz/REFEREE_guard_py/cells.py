"""Finite cell abstraction of the guard extension (AUDIT_guard_extension.md).

Each cell is one positive-mass block of problems of a single sign class; all
models are constant on cells (cells behave as atoms).  This is exact
combinatorics: every relation, axiom and chain below is computed exhaustively
over ALL 4^n models on the cells (n = 6 -> 4096 models), including incoherent,
silent and contradictory ones.

Advice codes: 0 = P (the minority answer: accept the gamble whose only positive
coordinate is the minority world), 1 = N (majority answer), 2 = S (silence),
3 = X (contradiction).
Rank at world w on a class-k cell:  w == k: P0 S1 N2 X3 ;  w != k: N0 S1 P2 X3.

Run: python3 -I -B cells.py   (inside this folder)
"""
import itertools, sys
import numpy as np

P, N, S, X = 0, 1, 2, 3
NAME = "PNSX"


def rank(w, k, adv):
    if w == k:
        return [0, 2, 1, 3][adv]
    return [2, 0, 1, 3][adv]


class Setting:
    def __init__(self, classes, guard_cells, T, defenders):
        self.classes = list(classes)          # class (minority world 0..2) of each cell
        self.n = len(classes)
        self.guard = np.zeros(self.n, bool)
        self.guard[list(guard_cells)] = True
        self.T = np.array(T, np.int8)
        self.defs = {k: np.array(v, np.int8) for k, v in defenders.items()}  # name -> (label i, pattern)
        self.models = np.array(list(itertools.product(range(4), repeat=self.n)), np.int8)
        self.NM = len(self.models)
        self.idx = {tuple(m): j for j, m in enumerate(self.models.tolist())}
        self.ranks = np.stack([np.array([[rank(w, self.classes[c], a) for c in range(self.n)]
                                         for a in range(4)], np.int8) for w in range(3)])
        # ranks[w][a][c]
        self.R = [self.ranks[w][self.models, np.arange(self.n)] for w in range(3)]  # (NM, n)
        M = self.models
        self.D = M[:, None, :] != M[None, :, :]
        mult = (17 ** np.arange(self.n)).astype(np.int64)
        code = np.zeros((self.NM, self.NM), np.int64)         # record code of rec(Y,Z)
        for c in range(self.n):
            a = M[:, c].astype(np.int64)
            b = M[:, c].astype(np.int64)
            cell = np.where(a[:, None] != b[None, :], 1 + 4 * a[:, None] + b[None, :], 0)
            code += cell * mult[c]
        self.code = code
        self.mult = mult

    def rec_code(self, Y, Z):
        Y = np.asarray(Y); Z = np.asarray(Z)
        d = Y != Z
        return int((np.where(d, 1 + 4 * Y.astype(np.int64) + Z, 0) * self.mult).sum())

    def guidance(self, w):
        Rw = self.R[w]
        return np.all(Rw[:, None, :] <= Rw[None, :, :], axis=2)

    def target_reference(self, w):
        """old side = T throughout D, D outside guards, new side somewhere strictly worse than T at w."""
        M = self.models
        Yeq = (M == self.T)
        rT = self.ranks[w][self.T, np.arange(self.n)]
        Dg = self.D[:, :, self.guard].any(axis=2)
        oldT = np.all(~self.D | Yeq[:, None, :], axis=2)
        worse = np.any(self.D & (self.R[w][None, :, :] > rT), axis=2)
        return (~Dg) & oldT & worse

    def X_G(self):
        return [j for j in range(self.NM) if np.array_equal(self.models[j][self.guard], self.T[self.guard])]

    def exposed(self, C, Xm, filt):
        ET = np.any((C != Xm) & (Xm != self.T))
        if not filt:
            return ET
        EC = np.any((~self.guard) & (C != self.T) & (Xm != C))
        return ET and EC

    def new_records(self, names, filt, choose=None):
        """All records rec(C,X), C in names, X in X_G, exposed (and E_C if filt).
        choose: None = install all; 'first' = one defender per rival (first exposed in names order)."""
        recs = set()
        cover = {}
        for j in self.X_G():
            Xm = self.models[j]
            if np.array_equal(Xm, self.T):
                continue
            ok = [nm for nm in names if self.exposed(self.defs[nm], Xm, filt)]
            cover[j] = ok
            use = ok if choose is None else ok[:1]
            for nm in use:
                recs.add(self.rec_code(self.defs[nm], Xm))
        return recs, cover

    def relation(self, base, recs):
        rel = []
        newmask = np.isin(self.code, np.array(sorted(recs), np.int64)) if recs else np.zeros((self.NM,) * 2, bool)
        for w in range(3):
            r = self.guidance(w)
            if base == 'TR':
                r = r | self.target_reference(w)
            r = r | newmask
            rel.append(r)
        return rel, newmask


def tc_violations(r):
    """count (A,C) with A<=C missing, C<=A, and some B with A<=B<=C."""
    f = r.astype(np.float32)
    two = (f @ f) > 0
    bad = two & r.T & ~r
    return int(bad.sum()), np.argwhere(bad)[:3]


def strict_G_violations(s, w, r):
    Rw = s.R[w]
    weakly_better = np.all(Rw[None, :, :] <= Rw[:, None, :], axis=2)   # Z (col) weakly better than Y (row)
    strictly = weakly_better & np.any(Rw[None, :, :] < Rw[:, None, :], axis=2)
    return int((strictly & r).sum())


def analyse(s, base, names, filt, choose=None, label=""):
    print(f"=== {label}: base={base}, defenders={names}, filter E_C={filt}, choose={choose}")
    recs, cover = s.new_records(names, filt, choose)
    rel, newmask = s.relation(base, recs)
    print(f" installed records: {len(recs)}; X_G rivals (excluding T): {len(cover)};"
          f" rivals with no qualifying defender: {sum(1 for v in cover.values() if not v)}")
    allok = True
    eye = np.eye(s.NM, dtype=bool)
    for w in range(3):
        r = rel[w]
        nv, ex = tc_violations(r)
        g_weak = int((s.guidance(w) & ~r).sum())
        g_str = strict_G_violations(s, w, r)
        ties = int((r & r.T & ~eye).sum())
        newrev = int((newmask.T & r).sum())
        print(f" world {w+1}: (TC) violations {nv}; weak-(G) misses {g_weak}; strict-(G) violations {g_str};"
              f" distinct ties {ties}; reverses of new comparisons accepted {newrev}; reflexive {bool(np.all(np.diag(r)))}")
        allok &= (nv == 0 and g_weak == 0 and g_str == 0 and ties == 0 and newrev == 0)
    # domination
    allw = rel[0] & rel[1] & rel[2]
    strict_any = (rel[0] & ~rel[0].T) | (rel[1] & ~rel[1].T) | (rel[2] & ~rel[2].T)
    dom = allw & strict_any        # dom[Y, X]: Y dominates X
    iT = s.idx[tuple(s.T.tolist())]
    tdom = int(dom[:, iT].sum())
    print(f" T dominated by {tdom} models")
    allok &= tdom == 0
    for nm in names:
        ic = s.idx[tuple(s.defs[nm].tolist())]
        print(f" defender {nm} dominated by {int(dom[:, ic].sum())} models")
    # every rival strictly dominated at every world by a defender
    sd = [s.idx[tuple(s.defs[nm].tolist())] for nm in names]
    strictly_all = (rel[0] & ~rel[0].T) & (rel[1] & ~rel[1].T) & (rel[2] & ~rel[2].T)
    miss = [j for j in cover if not any(strictly_all[c, j] for c in sd)]
    print(f" X_G rivals not strictly dominated at every world by a listed defender: {len(miss)}")
    if base == 'TR':
        nodef = [j for j in cover if not (rel[0][iT, j] or rel[1][iT, j] or rel[2][iT, j])]
        print(f" X_G rivals against which T has no defence: {len(nodef)}")
    return rel, recs, allok


def strictly_better(s, w):
    """sb[A, C] = C is a strict pointwise improvement of A at world w (so strict (G) refuses A <=_w C)."""
    Rw = s.R[w]
    wb = np.all(Rw[None, :, :] <= Rw[:, None, :], axis=2)
    return wb & np.any(Rw[None, :, :] < Rw[:, None, :], axis=2)


def can_ever_defend(s, rel, Y, Z):
    """For each world w: add the record rec(Y,Z) (all copies) at w.  Report
    (i) strict-(G) violations, (ii) FORCED (TC) violations: chains A<=B<=C with C a
    strict pointwise improvement of A at w.  A forced violation cannot be removed by
    adding further comparisons (A<=C is refused by strict (G)), so if (i) or (ii) is
    positive, NO extension satisfying (G) and (TC) accepts Y <=_w Z."""
    out = []
    c = s.rec_code(Y, Z)
    add = s.code == c
    for w in range(3):
        r = rel[w] | add
        sg = strict_G_violations(s, w, r)
        f = r.astype(np.float32)
        two = (f @ f) > 0
        forced = int((two & strictly_better(s, w)).sum())
        out.append((w + 1, sg, forced))
    return out


def show(m):
    return "".join(NAME[a] for a in m)
