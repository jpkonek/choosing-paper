"""Monotone form of Theorem 2's (TC) proof, checked exhaustively on the cell abstraction:
no accepted 2- or 3-cycle at any world contains a new (repair) comparison, for the FULL
collection of qualifying records.  This property passes to every subcollection, and old
triples satisfy (TC), so (TC) holds for every subcollection.  Also re-checks Lemma 3
(no nontrivial accepted cycle of length <= 3 in the target-reference base).
Run: python3 -I -B cycles_any_subcollection.py"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from cells import *
classes = [0, 1, 2, 0, 1, 2]
T = [P, P, P, S, S, P]
defs = {'C1': [P, N, N, P, N, S], 'C2': [N, P, N, N, P, S], 'C3': [N, N, P, N, N, P],
        # extra defenders NOT pointwise no worse than T at their own world (generic V_i members)
        'D1': [P, N, N, S, N, P], 'D2': [N, P, N, N, S, P], 'D3': [N, N, P, P, N, S]}
s = Setting(classes, [0, 1, 2], T, defs)
eye = np.eye(s.NM, dtype=bool)
allok = True
for base in ['guidance', 'TR']:
    for names in (['C1', 'C2', 'C3'], ['C1', 'C2', 'C3', 'D1', 'D2', 'D3']):
        recs, cover = s.new_records(names, False, None)
        rel, newmask = s.relation(base, recs)
        for w in range(3):
            r = rel[w]
            f = r.astype(np.float32)
            two = (f @ f) > 0
            c3 = int((newmask & two.T & ~eye & ~eye.T).sum())
            c2 = int((newmask & r.T & ~eye).sum())
            print(f"{base} defenders={names} world {w+1}: 3-cycles through a new link {c3}, 2-cycles {c2}")
            allok &= (c3 == 0 and c2 == 0)
    rel0, _ = s.relation(base, set())
    for w in range(3):
        r = rel0[w] & ~eye
        f = r.astype(np.float32)
        cyc3 = int(((f @ f > 0) & r.T).sum()); cyc2 = int((r & r.T).sum())
        print(f"{base} base alone world {w+1}: nontrivial 3-cycles {cyc3}, 2-cycles {cyc2}")
        if base == 'TR': allok &= (cyc3 == 0 and cyc2 == 0)
print("OK" if allok else "FAIL")
