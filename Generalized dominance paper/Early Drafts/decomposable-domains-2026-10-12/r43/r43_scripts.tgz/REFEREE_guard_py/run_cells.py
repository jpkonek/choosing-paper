"""Exhaustive finite-cell checks of Theorem 2, Lemma 3, section 11, Lemma 4 (cell form),
the section-12 trap, and the new forced trap against the co-designed defenders.

Cells (minority world in brackets, worlds numbered 1..3 in output, 0..2 internally):
  0 G1 [1], 1 G2 [2], 2 G3 [3], 3 O1 [1], 4 O2 [2], 5 O3 [3]
Patterns (P minority answer, N majority answer, S silence):
  T  = P P P | S S P
  C1 = P N N | P N S     C2 = N P N | N P S     C3 = N N P | N N P
These reproduce the geometric facts checked exactly in geom.py for the
co-designed posterior defenders (eps = 3/10, a = 20): guard pattern, C_i pointwise
no worse than T at world i, property (A), and the regions O1 (F: T silent, C3
majority), O3 (E_T: T accepts, C1, C2 silent, C3 accepts).
Run: python3 -I -B run_cells.py
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from cells import *

classes = [0, 1, 2, 0, 1, 2]
T = [P, P, P, S, S, P]
defs = {'C1': [P, N, N, P, N, S], 'C2': [N, P, N, N, P, S], 'C3': [N, N, P, N, N, P],
        'I3': [N, N, P, N, N, P]}
# I3 (ideal at world 3) coincides with C3 on these cells; for the section-12 trap
# we use a separate setting with an extra cell where I3 and T differ.
s = Setting(classes, [0, 1, 2], T, {k: v for k, v in defs.items() if k != 'I3'})

ok_all = True
# pointwise facts
for i, nm in enumerate(['C1', 'C2', 'C3']):
    C = s.defs[nm]
    rC = s.ranks[i][C, np.arange(s.n)]; rT = s.ranks[i][s.T, np.arange(s.n)]
    print(f"{nm} pointwise no worse than T at world {i+1}: {bool(np.all(rC <= rT))}")
agree = [c for c in range(s.n) if s.defs['C1'][c] == s.defs['C2'][c] == s.defs['C3'][c]]
print("cells where C1=C2=C3:", agree, "(property (A) needs T to agree there)")

for base in ['guidance', 'TR']:
    for filt in [False, True]:
        rel, recs, ok = analyse(s, base, ['C1', 'C2', 'C3'], filt, None,
                                label="all qualifying records")
        ok_all &= ok
rel_g, _, ok = analyse(s, 'TR', ['C1', 'C2', 'C3'], True, 'first', label="one defender per rival")
ok_all &= ok

print()
print("Axioms of the starting relations alone (no new records):")
for base in ['guidance', 'TR']:
    rel0, _ = s.relation(base, set())
    for w in range(3):
        nv, _ = tc_violations(rel0[w])
        eye = np.eye(s.NM, dtype=bool)
        ties = int((rel0[w] & rel0[w].T & ~eye).sum())
        print(f" {base} world {w+1}: TC violations {nv}, distinct ties {ties}")

print()
print("=== Forced trap against the co-designed defender C3 (strongest version: TR base, E_C filter)")
for choose in [None, 'first']:
    recs, cover = s.new_records(['C1', 'C2', 'C3'], True, choose)
    rel, _ = s.relation('TR', recs)
    Xs = s.T.copy(); Xs[5] = S          # T + silence on E_T (cell O3)
    jx = s.idx[tuple(Xs.tolist())]
    print(f" rival X* = {show(Xs)}: qualifying defenders (E_T and E_C): {cover[jx]}")
    print(f"  X* strict pointwise improvement of T at worlds:",
          [w + 1 for w in range(3) if strictly_better(s, w)[s.idx[tuple(s.T.tolist())], jx]])
    print(f"  C3 strict pointwise improvement of T at worlds:",
          [w + 1 for w in range(3) if strictly_better(s, w)[s.idx[tuple(s.T.tolist())], s.idx[tuple(s.defs['C3'].tolist())]]])
    print(f"  choose={choose}: rec(C3,X*) installed: {s.rec_code(s.defs['C3'], Xs) in recs}")
    iT = s.idx[tuple(s.T.tolist())]; i3 = s.idx[tuple(s.defs['C3'].tolist())]
    print(f"  T <=_w C3 currently at worlds: {[w+1 for w in range(3) if rel[w][iT, i3]]}")
    res = can_ever_defend(s, rel, s.T, s.defs['C3'])
    for w, sg, forced in res:
        print(f"  adding T <=_{w} C3: strict-(G) violations {sg}, forced (TC) violations {forced}")
    blocked = all(sg > 0 or forced > 0 for w, sg, forced in res)
    print(f"  => T can be defended against C3 at NO world in ANY (G)+(TC) extension: {blocked}")

print()
print("=== Same trap for every defender when ALL filtered records are installed")
recs, cover = s.new_records(['C1', 'C2', 'C3'], True, None)
rel, _ = s.relation('TR', recs)
for nm in ['C1', 'C2', 'C3']:
    res = can_ever_defend(s, rel, s.T, s.defs[nm])
    print(f" {nm}: per world (w, strictG, forcedTC) = {res}; blocked everywhere:",
          all(a > 0 or b > 0 for _, a, b in res))

print()
print("=== Section 12 trap (unfiltered, defender I3), on a setting with an extra class-3 cell E")
# cells: G1 G2 G3 O1 O2 O3 ; I3 differs from C3 on O1? I3 gives on class-1 cells the majority
# answer (correct at 3), on class-2 majority, on class-3 minority: identical pattern to C3 here.
# Use cell O3 as E (T and I3 both minority-3), Y = T + majority on G1,G2.
s2 = Setting(classes, [0, 1, 2], T, {'I3': [N, N, P, N, N, P]})
for filt in [False, True]:
    recs, cover = s2.new_records(['I3'], filt, None)
    rel, _ = s2.relation('guidance', recs)
    Xm = np.array([P, P, P, N, N, S], np.int8)   # I3 except: T on G1,G2 and silent on E=O3
    print(f" filter={filt}: rec(I3, {show(Xm)}) installed: {s2.rec_code(s2.defs['I3'], Xm) in recs}")
    Y = np.array([N, N, P, S, S, P], np.int8)
    res = can_ever_defend(s2, rel, s2.T, Y)
    print(f"  defence T <= Y={show(Y)}: per world (w, strictG, forcedTC) = {res}; blocked everywhere:",
          all(a > 0 or b > 0 for _, a, b in res))

print()
print("ALL STRUCTURAL CHECKS PASSED" if ok_all else "SOME STRUCTURAL CHECK FAILED")
