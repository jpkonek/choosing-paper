"""Witness chains for the filtered section-12 configuration (cell abstraction).
Run: python3 -I -B witness_s12.py"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from cells import *
classes = [0, 1, 2, 0, 1, 2]
T = [P, P, P, S, S, P]
s2 = Setting(classes, [0, 1, 2], T, {'I3': [N, N, P, N, N, P]})
recs, cover = s2.new_records(['I3'], True, None)
for base in ['guidance', 'TR']:
    rel, newmask = s2.relation(base, recs)
    Y = np.array([N, N, P, S, S, P], np.int8)
    add = s2.code == s2.rec_code(s2.T, Y)
    for w in [0, 1]:
        r = rel[w] | add
        sb = strictly_better(s2, w)
        f = r.astype(np.float32)
        # find A,B,C with A<=B (B<=C) and C strictly better than A, one link being a copy of rec(T,Y)
        found = 0
        As, Bs = np.nonzero(add)
        for A, B in zip(As, Bs):
            Cs = np.nonzero(r[B] & sb[A])[0]
            for C in Cs[:1]:
                kind = 'new' if newmask[B, C] else ('guid' if s2.guidance(w)[B, C] else 'TR')
                print(f"{base} world {w+1}: A={show(s2.models[A])} <= B={show(s2.models[B])} [copy of rec(T,Y)]"
                      f" <= C={show(s2.models[C])} [{kind}], C strictly better than A")
                found += 1
            if found >= 3: break
        Bs2, Cs2 = np.nonzero(add)
        for B, C in zip(Bs2, Cs2):
            As2 = np.nonzero(r[:, B] & sb[:, C])[0]
            for A in As2[:1]:
                kind = 'new' if newmask[A, B] else ('guid' if s2.guidance(w)[A, B] else 'TR')
                print(f"{base} world {w+1}: A={show(s2.models[A])} <= B={show(s2.models[B])} [{kind}]"
                      f" <= C={show(s2.models[C])} [copy of rec(T,Y)], C strictly better than A")
                found += 1
            if found >= 6: break
