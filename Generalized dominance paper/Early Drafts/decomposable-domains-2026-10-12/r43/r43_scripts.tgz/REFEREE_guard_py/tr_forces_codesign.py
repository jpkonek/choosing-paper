"""Lemma R1 (referee): under the target-reference base, an i-defender (guard pattern of V_i,
regular elsewhere) is undominated iff, at SOME world j, it is pointwise no worse than T
OFF THE GUARDS.  (A first guess, "iff no worse than T at its own world i everywhere",
is printed too and is FALSE: 43/81.)
Exhaustive on the cell abstraction (all 3 x 27 regular defender patterns off the guards).
Run: python3 -I -B tr_forces_codesign.py"""
import os, sys, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from cells import *
classes = [0, 1, 2, 0, 1, 2]
T = [P, P, P, S, S, P]
s = Setting(classes, [0, 1, 2], T, {})
rel, _ = s.relation('TR', set())
allw = rel[0] & rel[1] & rel[2]
strict_any = (rel[0] & ~rel[0].T) | (rel[1] & ~rel[1].T) | (rel[2] & ~rel[2].T)
dom = allw & strict_any
guardpat = {0: [P, N, N], 1: [N, P, N], 2: [N, N, P]}
agree = agree2 = total = 0
for i in range(3):
    for outside in itertools.product([P, N, S], repeat=3):
        C = np.array(guardpat[i] + list(outside), np.int8)
        jc = s.idx[tuple(C.tolist())]
        undominated = not dom[:, jc].any()
        rC = s.ranks[i][C, np.arange(s.n)]; rT = s.ranks[i][s.T, np.arange(s.n)]
        le = bool(np.all(rC <= rT))
        off = ~s.guard
        lej = any(bool(np.all(s.ranks[j][C, np.arange(s.n)][off] <= s.ranks[j][s.T, np.arange(s.n)][off]))
                  for j in range(3))
        total += 1; agree += (undominated == le); agree2 += (undominated == lej)
print(f"undominated under TR  <=>  pointwise no worse than T at own world (everywhere): {agree}/{total}")
print(f"undominated under TR  <=>  pointwise no worse than T off the guards at SOME world: {agree2}/{total}")
