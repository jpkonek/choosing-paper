"""Exact (fractions) geometric checks for AUDIT_guard_extension.md, eps = 3/10.

T = D_M, M = c1 + eps*Delta (contamination, c = (1-eps)/3).  Posterior defenders
C_i = D_{K_i}, K_i = {s_i*m/(s_i.m)}, s_i = a at i, 1 elsewhere; C_i accepts g iff
T accepts s_i*g.  Guards: polyhedral cones around gamma_k = L e_k - (1 - e_k).
Run: python3 -I -B geom.py
"""
from fractions import Fraction as F
import random

eps = F(3, 10); c = (1 - eps) / 3
VM = [[c + (eps if l == j else 0) for j in range(3)] for l in range(3)]   # vertices of M


def lu(V, g):
    vals = [sum(v[j] * g[j] for j in range(3)) for v in V]
    return min(vals), max(vals)


def adv(V, g):
    lo, up = lu(V, g)
    if lo > 0: return 'P+'      # accepts g
    if up < 0: return 'P-'      # accepts -g
    if lo < 0 < up: return 'S'
    return 'tie'


def post(s):
    out = []
    for v in VM:
        w = [s[j] * v[j] for j in range(3)]; z = sum(w)
        out.append([x / z for x in w])
    return out


def sv(i, a):
    return [a if j == i else F(1) for j in range(3)]


def answer(g, A):
    """translate accept g / accept -g into minority (P) / majority (N) answer."""
    pos = [j for j in range(3) if g[j] > 0]; neg = [j for j in range(3) if g[j] < 0]
    if len(pos) == 3 or len(neg) == 3: return {'P+': 'U+', 'P-': 'U-', 'S': 'S', 'tie': 'tie'}[A]
    minority_positive = (len(pos) == 1)
    if A == 'S' or A == 'tie': return A
    acc_pos = (A == 'P+')
    return 'P' if acc_pos == minority_positive else 'N'


def rank(w, g, A):
    """rank at world w (0..2) of advice A on problem g."""
    if A == 'S': return 1
    sign = g[w] if A == 'P+' else -g[w]
    return 0 if sign > 0 else 2


ok = True
def check(name, cond):
    global ok
    ok &= bool(cond)
    print(("PASS " if cond else "FAIL ") + name)


a = F(20); L = F(5); rho = F(1, 50)
K = [post(sv(i, a)) for i in range(3)]
# guards: cone generators gamma_k + rho*(+-e_l)
def gens(k):
    gam = [L if j == k else F(-1) for j in range(3)]
    out = []
    for l in range(3):
        for sgn in (1, -1):
            g = gam[:]; g[l] += sgn * rho; out.append(g)
    return out
G = [gens(k) for k in range(3)]
check("T accepts the minority gamble on every guard generator (strict)",
      all(lu(VM, g)[0] > 0 for k in range(3) for g in G[k]))
for i in range(3):
    check(f"K_{i+1}: minority on G_{i+1}, majority on the other guards (all vertices, all generators)",
          all(lu(K[i], g)[0] > 0 for g in G[i]) and
          all(lu(K[i], g)[1] < 0 for k in range(3) if k != i for g in G[k]))
    check(f"K_{i+1}: every vertex has coordinate {i+1} > 1/2", all(v[i] > F(1, 2) for v in K[i]))
eta = 1 / (a + 2)
check("eta = 1/(a+2) < c, so M is inside conv{v_i} = {m_j >= eta}", eta < c)
u = [F(1, 3)] * 3
pu = [sv(0, a)[j] * u[j] / sum(sv(0, a)[l] * u[l] for l in range(3)) for j in range(3)]
check("posterior of u under s_1 is (a,1,1)/(a+2) (so v_1 with eta = 1/(a+2) lies in K_1)",
      pu == [x / (a + 2) for x in sv(0, a)])

random.seed(7)
nA = nmono = 0
badA = badmono = 0
for _ in range(4000):
    g = [F(random.randint(-60, 60), random.randint(1, 40)) for _ in range(3)]
    if any(x == 0 for x in g): continue
    advT = adv(VM, g); advs = [adv(K[i], g) for i in range(3)]
    if 'tie' in advs or advT == 'tie': continue
    if advs[0] == advs[1] == advs[2]:
        nA += 1
        if advT != advs[0]: badA += 1
    for i in range(3):
        nmono += 1
        if rank(i, g, advs[i]) > rank(i, g, advT): badmono += 1
check(f"property (A) on {nA} random problems where C_1=C_2=C_3 (T agrees)", badA == 0 and nA > 0)
check(f"C_i pointwise no worse than T at world i on {nmono} random (problem, i)", badmono == 0)

# Lemma 4 patches
for i in range(3):
    for j in range(3):
        if i == j: continue
        g = [F(0)] * 3; g[i] = F(1); g[j] = F(-1)
        check(f"Lemma 4 patch e{i+1}-e{j+1}: T silent, C_{i+1} accepts g, C_{j+1} accepts -g",
              adv(VM, g) == 'S' and adv(K[i], g) == 'P+' and adv(K[j], g) == 'P-')
check("a > 1 + eps/c", a > 1 + eps / c)

# Forced trap region E_T in class 3: T accepts minority-3, C_1 and C_2 silent, C_3 accepts
for theta in [F(1), F(3, 4), F(3, 2)]:
    g = [-theta / a, -theta / a, F(1)]
    check(f"E_T point (-{theta}/a,-{theta}/a,1): T={answer(g, adv(VM, g))}, C1={answer(g, adv(K[0], g))},"
          f" C2={answer(g, adv(K[1], g))}, C3={answer(g, adv(K[2], g))}",
          answer(g, adv(VM, g)) == 'P' and adv(K[0], g) == 'S' and adv(K[1], g) == 'S'
          and answer(g, adv(K[2], g)) == 'P')
    # not in guard G_3: guard G_3 direction is (-1,-1,5) ~ (-1/5,-1/5,1)
    check(f"  E_T point is not in the guard cone around (-1,-1,{L})", theta / a != 1 / L)
# F regions: class 1 and class 2, T silent, C_3 majority
for g in ([F(1), F(-1, 2), F(-3, 5)], [F(-1, 2), F(1), F(-3, 5)]):
    check(f"F point {[str(x) for x in g]}: T={answer(g, adv(VM, g))}, C3={answer(g, adv(K[2], g))}",
          adv(VM, g) == 'S' and answer(g, adv(K[2], g)) == 'N')

# Non-additivity sets for section 11 exist outside the guards (world 1):
gA = [F(1), F(-1, 10), F(-1, 10)]    # class 1, T accepts minority answer -> good at world 1
gB = [F(-1, 10), F(1), F(-1, 10)]    # class 2, T accepts minority-2 -> bad at world 1
check("section 11: T good at world 1 on A-type problems", rank(0, gA, adv(VM, gA)) == 0)
check("section 11: T bad at world 1 on B-type problems", rank(0, gB, adv(VM, gB)) == 2)

# Section 7: PP13 sources and the t-range
r = c / (c + eps)
srcs = {'p1': [F(1918, 5273), F(2009, 5273), F(1346, 5273)],
        'p2': [F(212, 517), F(229, 517), F(76, 517)],
        'p3': [F(5278, 11073), F(5761, 11073), F(34, 11073)]}
print("Section 7: patches g_j = 1, g_k = -t, g_i = -delta (r = c/(c+eps) = %s)" % r)
delta = F(1, 100000)
for nm, p in srcs.items():
    Vp = post(p)
    for i in range(3):
        j, k = [x for x in range(3) if x != i]
        if p[j] > p[k]: j, k = k, j
        lo_t = r * p[j] / p[k]
        hi_audit = r
        hi_true = min(r, p[j] / (r * p[k]))
        def mk(t):
            g = [F(0)] * 3; g[j] = F(1); g[k] = -t; g[i] = -delta; return g
        t_near = hi_audit - F(1, 1000)
        g1 = mk(t_near)
        tmid = (lo_t + hi_true) / 2
        g2 = mk(tmid)
        aT1, aS1 = adv(VM, g1), adv(Vp, g1)
        aT2, aS2 = adv(VM, g2), adv(Vp, g2)
        print(f"  {nm} i={i+1} (minority world {j+1}): audit range ({float(lo_t):.4f},{float(hi_audit):.4f}),"
              f" correct upper end {float(hi_true):.4f}; at t=r-1/1000: T {aT1}, source {aS1};"
              f" at midpoint of corrected range: T {aT2}, source {aS2}")
        ok &= (aT2 == 'P+' and aS2 == 'S')
        if hi_true < hi_audit:
            print(f"    -> audit's claim 'source silent for every t in (r p_j/p_k, r)' FAILS here"
                  f" (source gives {aS1} at t = r - 1/1000); the source still differs from T, so (P_A) survives")
# PP13 certificate generator g_3 has third coordinate:
g3 = [F(1), F(-2442664, 6063705), F(-6307, 6063705)]
print(f"  PP13 cone B_3 generator g_3 = (1, {float(g3[1]):.5f}, {float(g3[2]):.6f}); the (p3, i=3) patch has"
      f" t in ({float(r*srcs['p3'][0]/srcs['p3'][1]):.4f},{float(r):.4f}) which contains {float(-g3[1]):.4f}:"
      f" delta must be taken below the B_3 range of |g_3| (about 1e-3), as the audit says")

print("ALL GEOMETRIC CHECKS PASSED" if ok else "SOME GEOMETRIC CHECK FAILED")
