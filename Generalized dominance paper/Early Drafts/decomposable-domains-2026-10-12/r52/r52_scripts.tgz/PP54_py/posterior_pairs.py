"""PP54 referee script 2 (CHECKED, exact rationals).  The posterior pair-ordering theorem.

C_a(g) = D_{M_a}(g).  Since q in M_a is proportional to a*p, D_{M_a} accepts h iff min_{p in M} sum p_i a_i h_i > 0,
so for a polytope M the advice is read off the vertices v_k(a) ~ a*m_k (computed directly here).
Ranks at world i of advice x in {+1 (accept g), 0 (silent), -1 (accept -g)}: correct 0, silent 1, wrong 2.
W = worlds where C_b is worse than C_a, R = worlds where it is better, r_i = b_i/a_i.
(A) interior pairs, M = T1 (eps = 3/10) and random interior polytopes, n = 3 and n = 4:
    check  min_W r < max_R r  on every disagreement (exact).  Count disagreement kinds.
(B) boundary pairs (some a_i or b_i = 0), with r_i in [0, inf]; worlds with a_i = b_i = 0 are dropped:
    check the same inequality and record whether W or R becomes empty after dropping.
(C) injectivity: max_{q in M_a} q_i/q_j = (a_i/a_j) max_{p in M} p_i/p_j (exact, vertices).
(D) the certificate is a coboundary: D^{ab} = log a - log b, so D^{ab} + D^{bc} + D^{ca} = 0 identically
    (recorded, no computation needed).
Run: python3 -I -B posterior_pairs.py > posterior_pairs.out
"""
from fractions import Fraction as Fr
import random

random.seed(5402)
INF = float("inf")
FAIL = []


def chk(c, m):
    if not c:
        FAIL.append(m)


def T1_verts(n, eps):
    c = (1 - eps) / n
    return [[c + (eps if j == i else 0) for j in range(n)] for i in range(n)]


def random_polytope(n, k):
    V = []
    for _ in range(k):
        w = [Fr(random.randint(5, 60)) for _ in range(n)]
        s = sum(w)
        V.append([x / s for x in w])
    return V


def advice(V, a, g):
    vals = [sum(a[i] * v[i] * g[i] for i in range(len(g))) for v in V]   # sign of (a*v).g
    if min(vals) > 0:
        return 1
    if max(vals) < 0:
        return -1
    return 0


def rank(x, gi):
    if x == 0:
        return 1
    return 0 if x * gi > 0 else 2


def ratio(ai, bi):
    if ai == 0 and bi == 0:
        return None
    if ai == 0:
        return INF
    return Fr(bi) / Fr(ai)


def lt(x, y):   # x < y on [0, inf]
    if x == INF:
        return False
    if y == INF:
        return True
    return x < y


def rand_like(n, zeros=()):
    a = [Fr(random.randint(1, 40)) for _ in range(n)]
    for z in zeros:
        a[z] = Fr(0)
    s = sum(a)
    return [x / s for x in a]


stats = {}


def test_pair(V, a, b, n, ngam, tag):
    for _ in range(ngam):
        g = [Fr(random.randint(-60, 60)) for _ in range(n)]
        if any(x == 0 for x in g):
            continue
        xa, xb = advice(V, a, g), advice(V, b, g)
        if xa == xb:
            continue
        kind = (xa, xb)
        stats.setdefault(tag, {}).setdefault(kind, 0)
        stats[tag][kind] += 1
        W = [i for i in range(n) if rank(xb, g[i]) > rank(xa, g[i])]
        R = [i for i in range(n) if rank(xb, g[i]) < rank(xa, g[i])]
        r = [ratio(a[i], b[i]) for i in range(n)]
        Wd = [i for i in W if r[i] is not None]
        Rd = [i for i in R if r[i] is not None]
        if not Wd or not Rd:
            stats[tag].setdefault("empty side after dropping", 0)
            stats[tag]["empty side after dropping"] += 1
            # with a common zero world, check the inequality on the common support instead
            chk(tag.startswith("B"), f"empty side for interior pair {tag}")
            continue
        mnW = min((r[i] for i in Wd), key=lambda x: (x == INF, x if x != INF else 0))
        mxR = max((r[i] for i in Rd), key=lambda x: (x == INF, x if x != INF else 0))
        chk(lt(mnW, mxR), f"{tag}: a={a} b={b} g={g} W={W} R={R}")


# (A) interior pairs
for eps in (Fr(3, 10), Fr(1, 10)):
    V = T1_verts(3, eps)
    for _ in range(600):
        test_pair(V, rand_like(3), rand_like(3), 3, 60, f"A:T1 eps={eps}")
for _ in range(150):
    V = random_polytope(3, random.randint(3, 7))
    for __ in range(4):
        test_pair(V, rand_like(3), rand_like(3), 3, 60, "A:random polytope n=3")
for _ in range(150):
    V = random_polytope(4, random.randint(4, 9))
    for __ in range(4):
        test_pair(V, rand_like(4), rand_like(4), 4, 60, "A:random polytope n=4")

# (B) boundary pairs
V = T1_verts(3, Fr(3, 10))
for _ in range(800):
    za = random.choice([(), (0,), (1,), (2,), (0, 1)])
    zb = random.choice([(), (0,), (1,), (2,)])
    a, b = rand_like(3, za), rand_like(3, zb)
    tag = "B:one interior" if (not za or not zb) else ("B:common zero" if set(za) & set(zb) else "B:different faces")
    test_pair(V, a, b, 3, 60, tag)

# (C) injectivity identity
for _ in range(300):
    Vp = random_polytope(3, random.randint(3, 6))
    a = rand_like(3)
    Va = []
    for v in Vp:
        s = sum(a[i] * v[i] for i in range(3))
        Va.append([a[i] * v[i] / s for i in range(3)])
    for i in range(3):
        for j in range(3):
            if i != j:
                lhs = max(q[i] / q[j] for q in Va)
                rhs = a[i] / a[j] * max(p[i] / p[j] for p in Vp)
                chk(lhs == rhs, "injectivity identity")

for tag in sorted(stats):
    tot = sum(v for k, v in stats[tag].items() if k != "empty side after dropping")
    print(f"{tag}: {tot} disagreements; by kind (C_a, C_b): "
          + ", ".join(f"{k}:{v}" for k, v in sorted(stats[tag].items(), key=str)))
print(f"failures: {len(FAIL)}")
for f in FAIL[:10]:
    print("FAIL", f)
print("ALL PASS" if not FAIL else "SOME FAIL")
