"""PP54 referee script 4 (NUMERICS: patterns sampled; order test exact).
For interior posterior pairs (a, b) on T1 (eps = 3/10), collect the move patterns (W, R) on sampled
disagreements and list the strict orders of D that satisfy max_W D > min_R D on all of them.
Question: is the admissible order forced to be the order of log(a/b)?  (How much freedom the
certificate leaves before global consistency is imposed.)
Run: python3 -I -B posterior_orders.py > posterior_orders.out
"""
from fractions import Fraction as Fr
from itertools import permutations
import random
random.seed(5404)
eps = Fr(3, 10); c = (1 - eps) / 3
V = [[c + (eps if j == i else 0) for j in range(3)] for i in range(3)]
def adv(a, g):
    vals = [sum(a[i] * v[i] * g[i] for i in range(3)) for v in V]
    return 1 if min(vals) > 0 else (-1 if max(vals) < 0 else 0)
def rk(x, gi):
    return 1 if x == 0 else (0 if x * gi > 0 else 2)
def norm(a):
    s = sum(a); return [x / s for x in a]
hist = {}
for trial in range(300):
    a = norm([Fr(random.randint(1, 40)) for _ in range(3)])
    # nearby b: small multiplicative perturbation, or far
    if trial % 2 == 0:
        b = norm([a[i] * (1 + Fr(random.randint(-20, 20), 100)) for i in range(3)])
    else:
        b = norm([Fr(random.randint(1, 40)) for _ in range(3)])
    if a == b:
        continue
    pats = set()
    for _ in range(4000):
        g = [Fr(random.randint(-80, 80)) for _ in range(3)]
        if 0 in g:
            continue
        xa, xb = adv(a, g), adv(b, g)
        if xa == xb:
            continue
        W = frozenset(i for i in range(3) if rk(xb, g[i]) > rk(xa, g[i]))
        R = frozenset(i for i in range(3) if rk(xb, g[i]) < rk(xa, g[i]))
        pats.add((W, R))
    ok = [p for p in permutations(range(3)) if all(max(p[w] for w in W) > min(p[x] for x in R) for W, R in pats)]
    r = [b[i] / a[i] for i in range(3)]
    # order of D = log(a/b) = -log r: rank of D_i
    D_order = tuple(sorted(range(3), key=lambda i: -r[i]))     # ascending D
    D_perm = [0] * 3
    for pos, i in enumerate(D_order):
        D_perm[i] = pos
    ties = len(set(r)) < 3
    key = ("ties in r" if ties else "distinct r", len(ok), tuple(D_perm) in ok if not ties else None, len(pats))
    hist[key[:3]] = hist.get(key[:3], 0) + 1
for k, v in sorted(hist.items(), key=str):
    print(f"{k[0]}: #admissible strict orders = {k[1]}, order of log(a/b) admissible = {k[2]}: {v} pairs")
