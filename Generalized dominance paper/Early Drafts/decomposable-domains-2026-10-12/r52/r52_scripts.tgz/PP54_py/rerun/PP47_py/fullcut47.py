"""PP47 script 2 (CHECKED, exact rationals). The pointwise algebra behind Thm 2.6 (no three-band nested pair).

Setting at one A-family point of band b: N's own increment delta = l^N(sigma) - l^N(S) has sign pattern
  delta_b > 0, delta_j < 0, delta_k < 0.
CG2(N,F) gives F's increment >= rho_w * delta_w, so F's Bayes (sigma strictly preferred at lambda_F) forces
  mu . delta < 0,  mu_w := lambda_F,w * rho_w,
while N's Bayes (S strictly preferred at lambda_N) needs lambda_N . delta > 0.
 (i)  For lambda, mu >= 0 (nonzero): a vector delta in the open A-sector of band b with
        lambda.delta > 0 > mu.delta  exists  iff  r_b > min(r_j, r_k),  r_w := lambda_w / mu_w (in [0, inf]).
      Checked both ways: an explicit delta is built when the condition holds; when it fails the
      inequality lambda.delta <= r_b mu.delta (+ terms <= 0) is verified on random sector vectors.
 (ii) Hence no (lambda_N, mu) works for all three bands (the argmin band fails); exhaustive on random pairs.
 (iii) Two bands are always fine: explicit lambda, mu, delta for bands {1,2}.
 (iv) Second-kind bands (N says sigma, F says S) need r_b < max(r_j, r_k); a pair is pointwise feasible iff
      its bands are not all of one kind (random sign assignments, exact).
 (v)  Zero-sum lemma: for lambda > 0 and v_b in lambda^perp with the A-pattern of band b (b = 1,2,3),
      there are alpha_b > 0 with sum alpha_b v_b = 0.
Run: python3 -I -B fullcut47.py > fullcut47.out
"""
from fractions import Fraction as Fr
import random
import itertools

random.seed(4747)
OK = True
INF = None


def check(c, m):
    global OK
    if not c:
        OK = False
        print("FAIL:", m)


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def rpos(n=50):
    return Fr(random.randint(1, n), random.randint(1, n))


def rsimplex(boundary_prob=0.2):
    v = [Fr(random.randint(0, 20)) if random.random() < boundary_prob else Fr(random.randint(1, 20)) for _ in range(3)]
    if sum(v) == 0:
        v[random.randrange(3)] = Fr(1)
    s = sum(v)
    return [x / s for x in v]


def ratio(l, m, w):
    if m[w] == 0:
        return INF if l[w] > 0 else Fr(0) if False else INF
    return l[w] / m[w]


def gt(a, b):  # a > b with INF = +inf
    if a is INF:
        return b is not INF
    if b is INF:
        return False
    return a > b


def lt(a, b):
    return gt(b, a)


def sector_vec(b, kind=1):
    """random vector with + at b and - elsewhere (kind=1); kind=-1 flips (second-kind uses same sector)."""
    d = [-rpos() for _ in range(3)]
    d[b] = rpos()
    return d


def build_first(l, m, b):
    """try to build delta in sector b with l.delta > 0 > m.delta; return it or None."""
    j, k = [w for w in range(3) if w != b]
    # take y,z weights concentrated on the cheaper-to-beat world
    for (wy, wz) in [(1, Fr(1, 10**6)), (Fr(1, 10**6), 1), (1, 1)]:
        # delta = (x at b, -wy at j, -wz at k); need m_b x < m_j wy + m_k wz and l_b x > l_j wy + l_k wz
        lo = (l[j] * wy + l[k] * wz)
        hi = (m[j] * wy + m[k] * wz)
        # x with l_b x > lo and m_b x < hi
        if l[b] == 0:
            continue
        xmin = lo / l[b]
        if m[b] == 0:
            x = xmin + 1
        else:
            xmax = hi / m[b]
            if not xmin < xmax:
                continue
            x = (xmin + xmax) / 2
        d = [Fr(0)] * 3
        d[b] = x; d[j] = -Fr(wy); d[k] = -Fr(wz)
        if dot(l, d) > 0 > dot(m, d):
            return d
    return None


n1 = n2 = 0
for _ in range(4000):
    l = rsimplex(); m = rsimplex()
    r = [ratio(l, m, w) for w in range(3)]
    feas = []
    for b in range(3):
        j, k = [w for w in range(3) if w != b]
        cond = gt(r[b], r[j]) or gt(r[b], r[k])
        d = build_first(l, m, b)
        if cond:
            check(d is not None or (l[b] == 0), "condition holds but no delta built")
            # l_b = 0 makes r_b = 0 or INF(if m_b=0): if l_b = 0, r_b = 0 unless m_b = 0
        else:
            check(d is None, "condition fails but delta found")
            for _ in range(20):
                dd = sector_vec(b)
                check(not (dot(l, dd) > 0 > dot(m, dd)), "counterexample to (i)")
            n1 += 1
        feas.append(d is not None)
    check(not all(feas), "all three bands feasible for one (lambda, mu)")
    n2 += 1
print("(i)  per-band criterion: %d failing bands verified on random sector vectors" % n1)
print("(ii) %d random (lambda_N, mu) pairs: never all three bands feasible" % n2)

# (iii) two bands feasible: explicit
l = [Fr(2, 5), Fr(2, 5), Fr(1, 5)]
m = [Fr(1, 10), Fr(1, 10), Fr(4, 5)]  # r = (4, 4, 1/4): band 3 is the argmin, bands 1, 2 fine
for b in (0, 1):
    d = build_first(l, m, b)
    check(d is not None, "two-band explicit")
check(build_first(l, m, 2) is None, "third band must fail")
print("(iii) explicit two-band example: lambda_N = %s, mu = %s; bands 1,2 feasible, band 3 not" % (l, m))

# (iv) mixed kinds
n4 = 0
for _ in range(3000):
    l = rsimplex(0.0); m = rsimplex(0.0)
    r = [l[w] / m[w] for w in range(3)]
    kinds = [random.choice([1, -1]) for _ in range(3)]
    ok = True
    for b in range(3):
        j, k = [w for w in range(3) if w != b]
        if kinds[b] == 1:
            ok = ok and (r[b] > min(r[j], r[k]))
        else:
            ok = ok and (r[b] < max(r[j], r[k]))
        # second kind: need l.delta < 0 < m.delta, i.e. first kind with roles swapped
        d = build_first(l, m, b) if kinds[b] == 1 else build_first(m, l, b)
        check((d is not None) == ((r[b] > min(r[j], r[k])) if kinds[b] == 1 else (r[b] < max(r[j], r[k]))),
              "kind criterion")
    if len(set(kinds)) == 1:
        check(not ok, "same-kind triple feasible")
    n4 += 1
# mixed kinds always admit some (l, m): exhibit
for kinds in itertools.product([1, -1], repeat=3):
    if len(set(kinds)) == 1:
        continue
    found = False
    for _ in range(400):
        l = rsimplex(0.0); m = rsimplex(0.0)
        if all((build_first(l, m, b) if kinds[b] == 1 else build_first(m, l, b)) is not None for b in range(3)):
            found = True
            break
    check(found, "no (l,m) for mixed kinds %s" % (kinds,))
print("(iv) kind criterion on %d instances; every mixed-kind assignment has a feasible (lambda, mu)" % n4)

# (v) zero-sum lemma
n5 = 0
for _ in range(2000):
    lam = rsimplex(0.0)
    vs = []
    for b in range(3):
        j, k = [w for w in range(3) if w != b]
        y, z = rpos(), rpos()
        v = [Fr(0)] * 3
        v[j] = -y; v[k] = -z
        v[b] = (lam[j] * y + lam[k] * z) / lam[b]
        check(dot(lam, v) == 0, "v not in lambda-perp")
        vs.append(v)
    # solve a v0 + b v1 = -v2 using two coordinates (system is consistent since all in lam-perp)
    a11, a12, b1 = vs[0][0], vs[1][0], -vs[2][0]
    a21, a22, b2 = vs[0][1], vs[1][1], -vs[2][1]
    det = a11 * a22 - a12 * a21
    check(det != 0, "degenerate")
    al = (b1 * a22 - a12 * b2) / det
    be = (a11 * b2 - a21 * b1) / det
    tot = [al * vs[0][t] + be * vs[1][t] + vs[2][t] for t in range(3)]
    check(al > 0 and be > 0 and all(x == 0 for x in tot), "zero-sum lemma")
    n5 += 1
print("(v)  zero-sum lemma: %d random instances, positive coefficients, exact zero" % n5)
print("ALL PASS" if OK else "SOME CHECKS FAILED")
