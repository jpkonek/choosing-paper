"""PP47 script 1 (CHECKED, exact rationals; candidates found by float search, every claim verified in Fractions).

Multicap family K_s = M ∩ {m_b <= c+eps-s_b}, C_s = D_{K_s}.  Problems g in Q^3 modulo sign.
 (a) union lemma and two-valuedness at random rational problems (sanity re-check; the referee proved it);
 (b) band sign patterns: inside H_b(t) the cap answer sigma_b has, at the three worlds, the patterns
       A-family of M_b : (b wrong, j correct, k correct)
       B-family of M_j : (b wrong, j correct, k wrong)
       B-family of M_k : (b wrong, j wrong,  k correct)
     exact witnesses of all three, and no other pattern among the sampled points;
 (c) strips: for 0 < r < s, the strip H_b(s) \\ H_b(r) contains an exact A-family witness of M_b
     (strict inequalities, so an open, hence non-null, set) -- used by Thm 2.6 for nested pairs;
 (d) the A-family part of every band meets H_b(t) for every sampled t (used by Thm 2.6).
Run: python3 -I -B geom47.py > geom47.out
"""
from fractions import Fraction as Fr
import random
import itertools

random.seed(47)
OK = True


def check(cond, msg):
    global OK
    if not cond:
        OK = False
        print("FAIL:", msg)


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def verts(c, eps, s):
    """vertices of K_s (s a 3-vector of cut sizes, s_i + s_j < eps)."""
    M = [[c + (eps if i == j else 0) for j in range(3)] for i in range(3)]
    out = []
    for b in range(3):
        if s[b] == 0:
            out.append(M[b])
        else:
            for o in range(3):
                if o != b:
                    out.append([M[b][t] + (s[b] / eps) * (M[o][t] - M[b][t]) for t in range(3)])
    return out


def D(vs, g):
    vals = [dot(m, g) for m in vs]
    if min(vals) > 0:
        return 1
    if max(vals) < 0:
        return -1
    if min(vals) < 0 < max(vals):
        return 0
    return None  # boundary (null) case


def cls(g):
    pos = sum(1 for x in g if x > 0)
    if pos == 1:
        return [i for i in range(3) if g[i] > 0][0]
    if pos == 2:
        return [i for i in range(3) if g[i] < 0][0]
    return -1


def pattern(sig, g):
    """'W'/'C' (wrong/correct) of answer sig at each world."""
    return tuple('C' if sig * g[w] > 0 else 'W' for w in range(3))


def family(sig, g):
    k = cls(g)
    if k < 0:
        return 'U'
    maj = 1 if sum(1 for x in g if x > 0) == 2 else -1
    return ('A' if sig == maj else 'B') + str(k)


def rand_g(n=60):
    return [Fr(random.randint(-n, n), random.randint(1, n)) for _ in range(3)]


EPS = [Fr(3, 10), Fr(1, 10)]

# (a) union lemma / two-valuedness
na = 0
for eps in EPS:
    c = (1 - eps) / 3
    dl = eps / 3 - Fr(1, 1000)
    for _ in range(60):
        s = [Fr(random.randint(0, 100), 100) * dl for _ in range(3)]
        V = {}
        for sub in itertools.product([0, 1], repeat=3):
            V[sub] = verts(c, eps, [s[b] if sub[b] else 0 for b in range(3)])
        for _ in range(60):
            g = rand_g()
            if any(x == 0 for x in g):
                continue
            vals = {sub: D(V[sub], g) for sub in V}
            if None in vals.values():
                continue
            t = vals[(0, 0, 0)]
            nonS = set(v for v in vals.values() if v != 0)
            check(len(nonS) <= 1, "two members give opposite answers")
            single = [vals[tuple(1 if i == b else 0 for i in range(3))] != t for b in range(3)]
            check(sum(single) <= 1, "single-cut regions overlap")
            for sub in V:
                diff = vals[sub] != t
                check(diff == any(single[b] and sub[b] for b in range(3)), "union lemma")
            na += 1
print("(a) union lemma + two-valuedness: %d problem-instances x 8 models" % na)

# (b),(d) band patterns
expected = {}
for b in range(3):
    j, k = [w for w in range(3) if w != b]
    pA = ['W'] * 3; pA[j] = 'C'; pA[k] = 'C'
    pBj = ['W'] * 3; pBj[j] = 'C'
    pBk = ['W'] * 3; pBk[k] = 'C'
    expected[b] = {('A' + str(b)): tuple(pA), ('B' + str(j)): tuple(pBj), ('B' + str(k)): tuple(pBk)}


def search_band(c, eps, b, t, rlow=None, tries=40000):
    """float search near planes through the cut corner; return exact witnesses by family."""
    Vt = verts(c, eps, [t if i == b else 0 for i in range(3)])
    Vr = verts(c, eps, [rlow if i == b else 0 for i in range(3)]) if rlow is not None else None
    VT = verts(c, eps, [0, 0, 0])
    found = {}
    pats = set()
    for _ in range(tries):
        # plane through a point of the cut corner region, random orientation
        g = rand_g(200)
        a = D(VT, g); bb = D(Vt, g)
        if a is None or bb is None or a != 0 or bb == 0:
            continue
        if Vr is not None:
            rr = D(Vr, g)
            if rr is None or rr != 0:
                continue
        fam = family(bb, g)
        pats.add((fam, pattern(bb, g)))
        found.setdefault(fam, g)
    return found, pats


def near_corner_g(c, eps, b, t):
    """problems whose plane passes near the cut corner: g orthogonal-ish to a point of the corner."""
    M = [[c + (eps if i == j else 0) for j in range(3)] for i in range(3)]
    # point inside the corner O_b at depth between 0 and t
    lam = Fr(random.randint(1, 999), 1000) * t / eps
    o1, o2 = [w for w in range(3) if w != b]
    mu = Fr(random.randint(0, 1000), 1000)
    p = [M[b][q] + lam * (mu * (M[o1][q] - M[b][q]) + (1 - mu) * (M[o2][q] - M[b][q])) for q in range(3)]
    # random g with g.p = small
    x = [Fr(random.randint(-300, 300), 100) for _ in range(2)]
    # solve g = (g0,g1,g2) with g.p = eta
    eta = Fr(random.randint(-5, 5), 1000)
    idx = random.randrange(3)
    rest = [q for q in range(3) if q != idx]
    g = [None] * 3
    g[rest[0]], g[rest[1]] = x
    g[idx] = (eta - x[0] * p[rest[0]] - x[1] * p[rest[1]]) / p[idx]
    return g


def search_band2(c, eps, b, t, rlow=None, tries=25000):
    Vt = verts(c, eps, [t if i == b else 0 for i in range(3)])
    Vr = verts(c, eps, [rlow if i == b else 0 for i in range(3)]) if rlow is not None else None
    VT = verts(c, eps, [0, 0, 0])
    found, pats = {}, set()
    for _ in range(tries):
        g = near_corner_g(c, eps, b, t)
        if any(x == 0 for x in g):
            continue
        a = D(VT, g); bb = D(Vt, g)
        if a is None or bb is None or a != 0 or bb == 0:
            continue
        if Vr is not None:
            rr = D(Vr, g)
            if rr is None or rr != 0:
                continue
        fam = family(bb, g)
        pats.add((fam, pattern(bb, g)))
        found.setdefault(fam, (g, bb))
    return found, pats


nb = 0
for eps in EPS:
    c = (1 - eps) / 3
    for b in range(3):
        for t in [eps / 4, eps / 40]:
            found, pats = search_band2(c, eps, b, t)
            for fam, pat in pats:
                check(fam in expected[b] and expected[b][fam] == pat, "unexpected pattern %s %s" % (fam, pat))
            for fam in expected[b]:
                check(fam in found, "missing family %s at eps=%s b=%d t=%s" % (fam, eps, b, t))
            nb += 1
print("(b,d) band patterns: %d (eps, band, cut) cases; all three families found with the stated patterns" % nb)

# (c) strips contain A-family witnesses
nc = 0
for eps in EPS:
    c = (1 - eps) / 3
    for b in range(3):
        for (r, s) in [(eps / 40, eps / 20), (eps / 8, eps / 4), (eps / 4 - eps / 400, eps / 4), (eps / 200, eps / 4)]:
            found, pats = search_band2(c, eps, b, s, rlow=r, tries=30000)
            fam = 'A' + str(b)
            check(fam in found, "no A-family witness in strip eps=%s b=%d r=%s s=%s" % (eps, b, r, s))
            if fam in found:
                g, sig = found[fam]
                VT = verts(c, eps, [0, 0, 0])
                Vs = verts(c, eps, [s if i == b else 0 for i in range(3)])
                Vr = verts(c, eps, [r if i == b else 0 for i in range(3)])
                check(D(VT, g) == 0 and D(Vr, g) == 0 and D(Vs, g) == sig, "strip witness re-check")
                check(pattern(sig, g) == expected[b][fam], "strip witness pattern")
            nc += 1
print("(c) strip A-family witnesses (exact, strict): %d cases" % nc)
print("ALL PASS" if OK else "SOME CHECKS FAILED")
