"""PP47 script 3 (CHECKED: LP proposes, Fractions verify). (TC) under zero-accepting gates (R0), two-valued triples.

Three gated members A (silent on both bands), B (answers sigma on band 1), C (answers sigma on band 2), as
T, C^i, C^j at a world k where both bands are two-signed.  Atoms carry fields delta^N = l^N(sigma)-l^N(S).
Pair intervals (multiplicative constants R_NM = c_N/c_M):
   R_AB in [1,2],  R_AC in [1,2],  R_BC in [L_BC, 3]   with L_BC = 2 (tight), 3/2 (slack), 5/2 (closed test fails).
 Ex1 (tight, all three bounding extremes attained on atoms): an exact NONTRIVIAL triangle with all three link
     values = 0 exists; under (R0) it is accepted; every reverse is refused (strict pair CG2 / no realiser /
     not guidance).  So (TC) fails under (R0) although the closed test holds.
 Ex2 (slack): LP shows no nontrivial triangle with links >= 0 (max total mass 0), any gate order.
 Ex3 (closed test fails): LP finds a triangle with all links > 0 (the strict-gate failure of Thm R1).
Run: python3 -I -B tc_r0_47.py > tc_r0_47.out
"""
from fractions import Fraction as Fr
import itertools
import random
import numpy as np
from scipy.optimize import linprog

random.seed(51)
OK = True


def check(c, m):
    global OK
    if not c:
        OK = False
        print("FAIL:", m)


S, SG = 0, 1
MEMB = ['A', 'B', 'C']


def build(s2):
    atoms = []  # dict: band, sign, delta{N}, value{N}
    r1 = {'P1a': Fr(2), 'P1b': Fr(3), 'Q1a': Fr(1), 'Q1b': Fr(1, 2)}
    r2 = {'P2a': Fr(2), 'P2b': Fr(3), 'Q2a': Fr(1), 'Q2b': Fr(1, 2)}
    for name, r in r1.items():
        sg = 1 if name[0] == 'P' else -1
        dA = sg * Fr(random.randint(1, 9), random.randint(1, 9))
        k1 = Fr(3, 2) if sg > 0 else Fr(3)
        atoms.append(dict(name=name, band=1, sg=sg,
                          d={'A': dA, 'B': r * dA, 'C': k1 * r * dA},
                          v={'A': S, 'B': SG, 'C': S}))
    for name, r in r2.items():
        sg = 1 if name[0] == 'P' else -1
        dA = sg * Fr(random.randint(1, 9), random.randint(1, 9))
        atoms.append(dict(name=name, band=2, sg=sg,
                          d={'A': dA, 'B': s2 * dA, 'C': r * dA},
                          v={'A': S, 'B': S, 'C': SG}))
    return atoms


def pair_interval(atoms, N, M):
    """interval for R = c_N/c_M from c_N f^N <= c_M f^M on D_NM (f = increment of the move N -> M)."""
    lo, hi = Fr(0), None
    for a in atoms:
        if a['v'][N] == a['v'][M]:
            continue
        s = 1 if a['v'][M] == SG else -1  # move S->sigma gives +delta
        fN, fM = s * a['d'][N], s * a['d'][M]
        q = fM / fN
        if fN > 0:
            hi = q if hi is None else min(hi, q)
        else:
            lo = max(lo, q)
    return lo, hi


def ell(a, N, x):
    return a['d'][N] if x == SG else Fr(0)


def types(a, gates):
    out = []
    n = [a['v'][g] for g in gates]
    for p, q, r in itertools.product([S, SG], repeat=3):
        if p == q == r:
            continue
        if p != q and p != n[0]:
            continue
        if q != r and q != n[1]:
            continue
        if r != p and r != n[2]:
            continue
        vec = (ell(a, gates[0], q) - ell(a, gates[0], p),
               ell(a, gates[1], r) - ell(a, gates[1], q),
               ell(a, gates[2], p) - ell(a, gates[2], r))
        out.append(((p, q, r), vec))
    return out


def lp(atoms, gates, mode):
    var = []
    for i, a in enumerate(atoms):
        for t, vec in types(a, gates):
            var.append((i, t, vec))
    nv = len(var)
    if mode == 'R0':  # max total mass s.t. links >= 0
        c = -np.ones(nv)
        A_ub = [[-float(v[2][l]) for v in var] for l in range(3)]
        b_ub = [0.0] * 3
    else:  # R: max t s.t. links >= t
        c = np.zeros(nv + 1); c[-1] = -1
        A_ub = [[-float(v[2][l]) for v in var] + [1.0] for l in range(3)]
        b_ub = [0.0] * 3
    for i in range(len(atoms)):
        row = [1.0 if v[0] == i else 0.0 for v in var]
        if mode != 'R0':
            row += [0.0]
        A_ub.append(row); b_ub.append(1.0)
    bounds = [(0, None)] * nv + ([(None, 1.0)] if mode != 'R0' else [])
    res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method='highs')
    return -res.fun, var, res.x


def verify_triangle(atoms, gates, pieces, accept_zero=True):
    """pieces: list of (atom index, (p,q,r), mass). Build links, check acceptance and reverses exactly."""
    links = [Fr(0)] * 3
    for i, (p, q, r), m in pieces:
        a = atoms[i]
        links[0] += m * (ell(a, gates[0], q) - ell(a, gates[0], p))
        links[1] += m * (ell(a, gates[1], r) - ell(a, gates[1], q))
        links[2] += m * (ell(a, gates[2], p) - ell(a, gates[2], r))
    acc = all((x >= 0) if accept_zero else (x > 0) for x in links)
    # reverses: link1 reverse is Q -> P on supp(link1), etc.
    refused = []
    for l, (old_i, new_i) in enumerate([(1, 0), (2, 1), (0, 2)]):
        supp = [(i, t, m) for i, t, m in pieces if t[old_i] != t[new_i]]
        if not supp:
            continue
        rs = []
        for N in MEMB:
            if all(atoms[i]['v'][N] == t[old_i] for i, t, m in supp):
                val = sum(m * (ell(atoms[i], N, t[new_i]) - ell(atoms[i], N, t[old_i])) for i, t, m in supp)
                rs.append((N, val))
        # guidance: reverse is a weak worsening iff at every supp point rank(new) >= rank(old)
        def rank(a, x):  # sg>0: sigma wrong (rank 2) ; sg<0: sigma right (rank 0); S rank 1
            return 1 if x == S else (2 if a['sg'] > 0 else 0)
        guid = all(rank(atoms[i], t[new_i]) >= rank(atoms[i], t[old_i]) for i, t, m in supp)
        acc_rev = guid or any((v >= 0) if accept_zero else (v > 0) for N, v in rs)
        refused.append((l, rs, guid, acc_rev))
    return links, acc, refused


for label, s2, expect in [('Ex1 tight', Fr(1, 2), 'zero'), ('Ex2 slack', Fr(2, 3), 'none'), ('Ex3 fails', Fr(2, 5), 'pos')]:
    atoms = build(s2)
    iv = {(N, M): pair_interval(atoms, N, M) for N, M in [('A', 'B'), ('A', 'C'), ('B', 'C')]}
    print(label, "pair intervals R_NM in [lo, hi]:", {k: (str(v[0]), str(v[1])) for k, v in iv.items()})
    for k, (lo, hi) in iv.items():
        check(hi is not None and lo < hi, "pair interval degenerate: strict pair CG2 must be possible")
    best0 = max(lp(atoms, g, 'R0')[0] for g in itertools.permutations(MEMB))
    bestR = max(lp(atoms, g, 'R')[0] for g in itertools.permutations(MEMB))
    print("   max mass of a triangle with links >= 0 (R0): %.6f ; max min-link (R): %.6f" % (best0, bestR))
    if expect == 'none':
        check(best0 < 1e-9 and bestR < 1e-9, "slack case should admit no triangle")
    if expect == 'pos':
        check(bestR > 1e-9, "failing closed test should give a positive triangle")
        # exact rebuild of the positive triangle
        for g in itertools.permutations(MEMB):
            val, var, x = lp(atoms, g, 'R')
            if val > 1e-9:
                pieces = [(var[n][0], var[n][1], Fr(x[n]).limit_denominator(10**6)) for n in range(len(var)) if x[n] > 1e-12]
                links, acc, refused = verify_triangle(atoms, g, pieces, accept_zero=False)
                check(acc, "rebuilt positive triangle not accepted")
                check(any(not r[3] for r in refused), "no refused reverse")
                print("   exact positive triangle, gates", g, "links", [str(v) for v in links],
                      "refused reverses:", [r[0] + 1 for r in refused if not r[3]])
                break
    if expect == 'zero':
        check(bestR < 1e-9, "tight case: no strictly positive triangle")
        check(best0 > 1e-9, "tight case: LP should find a zero triangle")
        for g in itertools.permutations(MEMB):
            val, var, x = lp(atoms, g, 'R0')
            if val > 1e-9:
                sup = [(var[n][0], var[n][1], var[n][2]) for n in range(len(var)) if x[n] > 1e-9]
                # exact: solve for masses on the support with all links = 0 (null vector of 3 x k matrix)
                k = len(sup)
                Mx = [[sup[j][2][l] for j in range(k)] for l in range(3)]
                # find positive null vector: use LP masses as guide, project exactly via fraction Gaussian elim
                from itertools import combinations
                found = None
                for cols in combinations(range(k), min(k, 3)):
                    sub = [[Mx[l][j] for j in cols] for l in range(3)]
                    # solve sub * m = 0 with m_last = 1
                    import copy
                    n = len(cols)
                    A = [row[:n - 1] for row in sub]; b = [-row[n - 1] for row in sub]
                    # least: use first n-1 independent rows
                    for rows in combinations(range(3), n - 1):
                        AA = [A[r] for r in rows]; bb = [b[r] for r in rows]
                        if n - 1 == 2:
                            det = AA[0][0] * AA[1][1] - AA[0][1] * AA[1][0]
                            if det == 0:
                                continue
                            m0 = (bb[0] * AA[1][1] - AA[0][1] * bb[1]) / det
                            m1 = (AA[0][0] * bb[1] - bb[0] * AA[1][0]) / det
                            ms = [m0, m1, Fr(1)]
                        else:
                            if AA[0][0] == 0:
                                continue
                            ms = [bb[0] / AA[0][0], Fr(1)]
                        if all(mm > 0 for mm in ms) and all(sum(sub[l][j] * ms[j] for j in range(n)) == 0 for l in range(3)):
                            sc = max(ms)
                            found = [(sup[cols[j]][0], sup[cols[j]][1], ms[j] / sc) for j in range(n)]
                            break
                    if found:
                        break
                check(found is not None, "no exact zero triangle")
                if found:
                    links, acc, refused = verify_triangle(atoms, g, found, accept_zero=True)
                    check(all(v == 0 for v in links), "links not exactly zero")
                    check(acc, "zero triangle not accepted under R0")
                    check(any(not r[3] for r in refused), "all reverses accepted")
                    print("   exact zero triangle, gates", g, "pieces",
                          [(atoms[i]['name'], t, str(m)) for i, t, m in found])
                    for l, rs, guid, accr in refused:
                        print("     reverse of link %d: realiser values %s, guidance %s -> %s" %
                              (l + 1, [(N, str(v)) for N, v in rs], guid, 'accepted' if accr else 'REFUSED'))
                break
print("ALL PASS" if OK else "SOME CHECKS FAILED")
