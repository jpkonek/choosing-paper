"""PP45 script 1 (CHECKED, exact rationals).  The type test.

(a) Lemma 1.1: on every strip H_i(t) \ H_i(s), 0 <= s < t <= delta, the advice sigma is i-wrong and the
    sign pattern is one of A_i = {i}, B_j = {i,k}, B_k = {i,j} (worlds where sigma is WRONG); all three occur.
    Also: the union-lemma advice agrees with D_{K_s} computed directly from K_s's vertices.
(b) Cor 3.2: for pairs of box members, the pair's pattern set is order-feasible  <=>  at most one coordinate
    goes up and at most one goes down.  (Order feasibility = Lemma 2.2.)
(c) Cor 3.3: refinements K of M (corner cuts, tilted, random) are order-feasible with T  <=>  K cuts
    at most one vertex.
(d) Tilted single-vertex cuts: feasibility statistics for pairs at one vertex, across vertices, and with T.
Run: python3 -I -B types_exact.py > types_exact.out
"""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from pp45_lib import *

random.seed(45)
OK = True


def check(c, msg):
    global OK
    if not c:
        OK = False
        print("FAIL:", msg)


def rg(n=30):
    while True:
        g = [Fr(random.randint(-n, n), random.randint(1, n)) for _ in range(3)]
        if all(x != 0 for x in g) and sum(g) != 0:
            return g


def corner_any(eps, top=Fr(3, 5)):
    """corner point at a random vertex: depth log-uniform in (top/2^12, top), ratio log-uniform in (1/2^8, 2^8)"""
    i = random.randrange(3)
    big = top / 2 ** random.randint(0, 12) * rfrac(Fr(1, 2), 1)
    small = big / 2 ** random.randint(0, 8) * rfrac(Fr(1, 2), 1)
    lj, lk = (big, small) if random.random() < 0.5 else (small, big)
    return corner_point(i, lj, lk, eps)


def move_pattern(a, b, g):
    """(W,R) for the move a -> b at g, a,b in {sigma(g), 0}; W = worlds where b is worse."""
    pw = pattern(g)
    allw = frozenset(range(3))
    if a == b:
        return None
    if b != 0:      # S -> sigma: worse where sigma wrong
        return (pw, allw - pw)
    return (allw - pw, pw)  # sigma -> S: worse where sigma correct


# ---------------- (a)
na = 0
for eps in (Fr(1, 10), Fr(3, 10), Fr(1, 2)):
    delta = eps / 4
    M = verts_M(eps)
    for rep in range(12):
        s, t = sorted([rfrac(0, delta), rfrac(0, delta)])
        if rep == 0:
            s = Fr(0)
        for i in range(3):
            j, k = [w for w in range(3) if w != i]
            seen = set()
            for trial in range(300):
                # target depth tau in (s,t): choose max(lj,lk) = tau/eps, other one smaller (random ratio)
                tau = rfrac(s, t)
                big = tau / eps
                small = big * rfrac(0, 1)
                lj, lk = (big, small) if random.random() < 0.5 else (small, big)
                g = corner_point(i, lj, lk, eps)
                if random.random() < 0.5:
                    g = [-x for x in g]
                bt = band_tau(g, eps)
                check(bt is not None and bt[0] == i and bt[1] == tau, "corner point band/tau")
                check(D(M, g) == 0, "T not silent on band")
                p = pattern(g)
                check(i in p and p in ({i}, {i, k}, {i, j}), f"bad pattern {p}")
                seen.add(p)
                na += 1
            check(seen == {frozenset({i}), frozenset({i, k}), frozenset({i, j})},
                  f"strip ({s},{t}] band {i}: families {seen}")
    # union lemma vs direct D_{K_s}
    for rep in range(40):
        sv = [rfrac(0, delta) if random.random() < 0.7 else Fr(0) for _ in range(3)]
        Kv = K_box_verts(sv, eps)
        for trial in range(150):
            if trial % 2:
                g = rg()
            else:
                i = random.randrange(3)
                g = corner_point(i, rfrac(0, 2 * delta / eps), rfrac(0, 2 * delta / eps), eps)
            if any(dot(m, g) == 0 for m in Kv + M):
                continue  # null boundary cases
            check(multicap_advice(sv, g, eps) == D(Kv, g), "union lemma advice")
            na += 1
print(f"(a) {na} exact checks of strip families / union-lemma advice")

# ---------------- (b) box pairs
def sample_pair_patterns(sv, tv, eps, delta, n=60):
    pats = set()
    M = verts_M(eps)
    for i in range(3):
        lo, hi = sorted([sv[i], tv[i]])
        if lo == hi:
            continue
        for trial in range(n):
            tau = rfrac(lo, hi)
            big = tau / eps
            small = big / 2 ** random.randint(0, 8) * rfrac(Fr(1, 2), 1)
            lj, lk = (big, small) if random.random() < 0.5 else (small, big)
            g = corner_point(i, lj, lk, eps)
            a, b = multicap_advice(sv, g, eps), multicap_advice(tv, g, eps)
            mp = move_pattern(a, b, g)
            check(mp is not None, "expected disagreement")
            if mp:
                pats.add(mp)
    return pats


nb = 0
for eps in (Fr(1, 10), Fr(3, 10)):
    delta = eps / 4
    grid = [Fr(0), delta / 3, 2 * delta / 3]
    pts = [(a, b, c) for a in grid for b in grid for c in grid]
    for sv in pts:
        for tv in pts:
            if sv >= tv:
                continue
            up = sum(1 for i in range(3) if tv[i] > sv[i])
            dn = sum(1 for i in range(3) if tv[i] < sv[i])
            pats = sample_pair_patterns(sv, tv, eps, delta, n=60)
            feas, perm = order_feasible(pats)
            check(feas == (up <= 1 and dn <= 1), f"box pair {sv} {tv}: feasible={feas}, up={up}, dn={dn}")
            nb += 1
    # the four-model checkpoint, explicitly
    a, b = delta / 2, delta / 3
    four = {"T": (0, 0, 0), "A": (a, 0, 0), "B": (0, b, 0), "AB": (a, b, 0)}
    for n1 in four:
        for n2 in four:
            if n1 < n2:
                pats = sample_pair_patterns(four[n1], four[n2], eps, delta, n=80)
                feas, perm = order_feasible(pats)
                print(f"(b) eps={eps} checkpoint pair ({n1},{n2}): {len(pats)} patterns, order-feasible={feas}"
                      + (f", ranks(w1,w2,w3)={perm}" if feas else ""))
print(f"(b) {nb} box pairs on a 27-point grid per eps: feasible <=> (<=1 up and <=1 down)")

# ---------------- (c) random refinements
def cut_verts(cuts, eps):
    """cuts: dict vertex -> (x, y) fractions along the two edges (j<k order). Returns K's vertices."""
    M = verts_M(eps)
    vs = []
    for i in range(3):
        j, k = [w for w in range(3) if w != i]
        if i in cuts:
            x, y = cuts[i]
            vs.append([M[i][t] + x * (M[j][t] - M[i][t]) for t in range(3)])
            vs.append([M[i][t] + y * (M[k][t] - M[i][t]) for t in range(3)])
        else:
            vs.append(M[i])
    return vs


def patterns_vs_T(Kv, eps, n=250):
    M = verts_M(eps)
    pats = set()
    for trial in range(n):
        if trial % 3 == 0:
            g = rg()
        else:
            g = corner_any(eps)
        if any(dot(m, g) == 0 for m in Kv + M):
            continue
        a, b = D(M, g), D(Kv, g)
        if a != b:
            check(a == 0, "refinement silent where T answers?")
            pats.add(move_pattern(0, b, g))
    return pats


nc = 0
for eps in (Fr(1, 10), Fr(3, 10)):
    for rep in range(150):
        ncut = random.choice([1, 2, 3])
        vs = random.sample(range(3), ncut)
        cuts = {v: (rfrac(0, Fr(2, 5)), rfrac(0, Fr(2, 5))) for v in vs}
        Kv = cut_verts(cuts, eps)
        pats = patterns_vs_T(Kv, eps)
        feas, _ = order_feasible(pats)
        check(feas == (ncut == 1), f"refinement cutting {ncut} vertices: feasible={feas}")
        nc += 1
print(f"(c) {nc} random refinements (1, 2 or 3 tilted corner cuts): order-feasible with T <=> one vertex cut")

# ---------------- (d) tilted cuts at one vertex
def pair_pats_K(K1, K2, eps, n=300):
    pats = set()
    for trial in range(n):
        if trial % 3 == 0:
            g = rg()
        else:
            g = corner_any(eps)
        if any(dot(m, g) == 0 for m in K1 + K2):
            continue
        a, b = D(K1, g), D(K2, g)
        if a != b:
            pats.add(move_pattern(a, b, g))
    return pats


eps = Fr(3, 10)
stats = {"nested": [0, 0], "crossing, tilt ratio<=2": [0, 0], "crossing, tilt ratio>4": [0, 0], "other vertex": [0, 0]}
for rep in range(240):
    x1, y1 = rfrac(Fr(1, 50), Fr(3, 10)), rfrac(Fr(1, 50), Fr(3, 10))
    if rep % 4 == 0:
        x2, y2 = x1 * rfrac(1, 2), y1 * rfrac(1, 2)
        key = "nested"
    elif rep % 4 == 1:
        r = rfrac(Fr(1, 2), 2)
        x2, y2 = x1 * rfrac(1, Fr(3, 2)), y1 / rfrac(1, Fr(3, 2))
        key = "crossing, tilt ratio<=2" if max(x1 / y1, y1 / x1, x2 / y2, y2 / x2) <= 2 else None
    elif rep % 4 == 2:
        x2, y2 = x1 * 5, y1 / 5
        key = "crossing, tilt ratio>4"
    else:
        key = "other vertex"
    K1 = cut_verts({0: (x1, y1)}, eps)
    if key == "other vertex":
        K2 = cut_verts({1: (x1, y1)}, eps)
    else:
        if key is None or x2 >= 1 or y2 >= 1:
            continue
        K2 = cut_verts({0: (x2, y2)}, eps)
    feas, _ = order_feasible(pair_pats_K(K1, K2, eps))
    stats[key][0] += 1
    stats[key][1] += int(feas)
for kk, (n, f) in stats.items():
    print(f"(d) tilted single-vertex cuts, {kk}: {f}/{n} pairs order-feasible")
check(stats["nested"][0] == stats["nested"][1], "nested tilted cuts should be feasible")
check(stats["other vertex"][0] == stats["other vertex"][1], "cross-vertex tilted cuts should be feasible")
print("ALL PASS" if OK else "SOME CHECK FAILED")
