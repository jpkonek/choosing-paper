"""PP45 script 6 (NUMERICS).  The forbidden configuration of Thm 3.1 for one concrete pair of fields.

T carries l^T.  AB = C_(a,b,0) carries the natural two-cut extension of PP42's humble field: on H_1(a) world 1 is
multiplied by bdis and worlds 2,3 by (1+eta) where sigma is wrong, (1-eta) where right; symmetrically on H_2(b)
with world 2 discounted; l^T elsewhere.  (Thm 3.1 says EVERY choice fails; this only exhibits the records.)
At world 1:  D := (all of H_1(a)) u (a fraction theta of the 1-correct part of H_2(b)), bounded by |g| < 2.5, with
theta chosen so that  int_D f^T > 0 > int_D f^AB.  F := a small ball in Sil(T) off the bands.
  r1 = (D, T -> AB)                    accepted at world 1 through T's gate;
  r2 = (D, AB -> T) u (F, T -> 1-correct)  accepted at world 1 through AB's gate;
  r3 = (F, 1-correct -> T)             accepted at world 1 by guidance;
so T <=_1 X <=_1 Y <=_1 T with X = T[D -> AB], Y = T[F -> 1-correct], and (TC) would need T <=_1 Y, a strict
1-improvement: refused by strict (G).
Run: python3 -I -B forbidden_triangle_mc.py > forbidden_triangle_mc.out
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "PP42_py"))
import numpy as np
from field40 import field, pen, T

rng = np.random.default_rng(3)
EPS = 0.3
c = (1 - EPS) / 3
a_cut, b_cut = EPS / 8, EPS / 8
bdis, eta = 0.1, 0.02
N = 3_000_000
g = rng.standard_normal((N, 3))
g = g[np.linalg.norm(g, axis=1) < 2.5]
fl = field(g, EPS)
tg = T(g, EPS)
Mv = np.array([[c + (EPS if i == j else 0) for j in range(3)] for i in range(3)])


def cap_answer(v, s):
    others = [Mv[i] for i in range(3) if i != v]
    ps = [Mv[v] + (s / EPS) * (o - Mv[v]) for o in others]
    V = np.array(others + ps)
    vals = g @ V.T
    return np.where(vals.min(1) > 0, 1, np.where(vals.max(1) < 0, -1, 0))


H1 = (cap_answer(0, a_cut) != tg)
H2 = (cap_answer(1, b_cut) != tg)
sig = np.sign(g.sum(1)).astype(int)
pS = pen(np.zeros(len(g), int), g, fl)
pA = pen(sig, g, fl)
inc = pA - pS                       # l^T increment of S -> sigma, per world
wrong1 = sig * g[:, 0] < 0
# AB's world-1 multiplier: bdis on H_1; on H_2 humble (1+eta) where sigma 1-wrong, (1-eta) where 1-right
mult1 = np.where(H1, bdis, np.where(H2, np.where(wrong1, 1 + eta, 1 - eta), 1.0))
fT = inc[:, 0]
fAB = mult1 * inc[:, 0]
Pp = fT[H1].sum() / len(g)                        # T's world-1 value of S->sigma on H_1 (positive)
Rcorr = H2 & ~wrong1
Qm = -fT[Rcorr].sum() / len(g)                    # 1-gain on the 1-correct part of H_2 (positive)
# choose theta with  Pp - theta*Qm > 0 > bdis*Pp - (1-eta)*theta*Qm
lo, hi = bdis * Pp / ((1 - eta) * Qm), Pp / Qm
theta = min(0.5 * (lo + hi), 1.0)
assert lo < theta < hi, (lo, hi)
sel = Rcorr & (rng.random(len(g)) < theta)
Dset = H1 | sel
IT = fT[Dset].sum() / len(g)
IAB = fAB[Dset].sum() / len(g)
print(f"mu(H_1(a))={H1.mean():.4f}, mu(H_2(b))={H2.mean():.4f}; theta range ({lo:.3f},{hi:.3f}), theta={theta:.3f}")
print(f"r1: Phi^T_1(D: T->AB) = {IT:+.3e}  (> 0: T's gate accepts T <=_1 X)")
# F: ball in Sil(T) off the bands, where T is silent; changing to the 1-correct answer
F = (tg == 0) & ~H1 & ~H2 & (np.linalg.norm(g - np.array([0.2, -0.9, 0.6]), axis=1) < 0.12)
corr1 = np.sign(g[:, 0]).astype(int)
gainF = (pen(corr1, g, fl)[:, 0] - pS[:, 0])[F].sum() / len(g)   # negative: 1-improvement
r2 = -IAB + gainF
print(f"r2: Phi^AB_1 = -Phi^AB_1(D: T->AB) + Phi_1(F: S->1-correct) = {-IAB:+.3e} + ({gainF:+.3e}) = {r2:+.3e}"
      f"  (> 0: AB's gate accepts X <=_1 Y)")
print("r3: Y -> T on F is a pure 1-worsening: guidance accepts Y <=_1 T")
print(f"(TC) needs T <=_1 Y = T[F -> 1-correct], a strict 1-improvement (Phi = {gainF:+.3e} < 0 for every field)"
      f": refused by strict (G).  Forbidden configuration present: {IT > 0 and r2 > 0}")
print("NUMERICS DONE")
