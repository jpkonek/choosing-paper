"""PP45 script 4 (NUMERICS; no proof depends on it).  Repair-class rivals against the section-5 tripod design.

Gaussian sample; on the bands H_i(delta) every member uses the section-5 field; off the bands all use l^T
(the rivals below live on the bands, so l^T is never consulted).  For each rival X we scan every registered
member D (T and 3 x 40 caps) and test D <=_w X at w = 1,2,3 through ALL routes: guidance, and the gate of
every member that realises D on the record's support (zero accepted).  'dominated' = accepted at all worlds.
Rivals: fills of T by cap answers (deep, and hugging the arc), the two-corner rival X = T[G1 -> C, G2 -> C'],
retreats and improved retreats of a cap.
Run: python3 -I -B tripod_repairs_mc.py > tripod_repairs_mc.out
"""
import numpy as np

rng = np.random.default_rng(45)
EPS, N = 0.3, 1_500_000
c = (1 - EPS) / 3
DELTA = EPS / 4
CC = 0.25
g = rng.standard_normal((N, 3))
g = g[np.linalg.norm(g, axis=1) < 2.5]           # bounded records
S = g.sum(1)
sg = np.sign(S)
Mv = np.array([[c + (EPS if i == j else 0) for j in range(3)] for i in range(3)])
vals = (g @ Mv.T) * sg[:, None]                   # sigma-oriented vertex values
Tsil = (vals.min(1) < 0) & (vals.max(1) > 0)
bad = vals < 0
one = Tsil & (bad.sum(1) == 1)
band = np.where(one, np.argmax(bad, 1), -1)
tau = np.full(len(g), np.inf)
for i in range(3):
    m = band == i
    lam = []
    for j in range(3):
        if j != i:
            lam.append(-vals[m, i] / (vals[m, j] - vals[m, i]))
    tau[m] = EPS * np.maximum(*lam)
onH = (band >= 0) & (tau < DELTA)
idx = np.where(onH)[0]
g, band, tau, sg = g[idx], band[idx], tau[idx], sg[idx]
wrong = (sg[:, None] * g) < 0                     # sigma wrong at w
phi = tau / (2 * DELTA)
q = 1 - phi
zeta = phi / 2
nrm = np.linalg.norm(g, axis=1)
n = np.zeros((len(g), 3))
for i in range(3):
    m = band == i
    n[m, i] = 1
    for j in range(3):
        if j == i:
            continue
        k = 3 - i - j
        mA = m & (wrong.sum(1) == 1)
        n[mA, j] = -q[mA] / 2
        mBj = m & wrong[:, k] & ~wrong[:, j] & (wrong.sum(1) == 2)   # correct only at j
        n[mBj, j] = -(q[mBj] + zeta[mBj])
        mBk = m & wrong[:, j] & ~wrong[:, k] & (wrong.sum(1) == 2)   # correct only at k
        n[mBk, j] = zeta[mBk]
fam = np.where(wrong.sum(1) == 1, "A", "B")
print(f"band sample points: {len(g)} (of which per band: {[int((band == i).sum()) for i in range(3)]})")

grid = np.linspace(DELTA / 40, DELTA, 40)
members = [(-1, 0.0)] + [(v, t) for v in range(3) for t in grid]


def member_data(mb):
    v, t = mb
    mu = np.ones(3)
    if v >= 0:
        mu[v] = 1 - t / (2 * DELTA)
    val = n @ mu
    mh = np.abs(val)
    sig = (band == v) & (tau < t)
    H = np.where(wrong == sig[:, None], 1 + CC * mh[:, None], 1 - CC * mh[:, None])
    mag = np.abs(n) * mu * H * nrm[:, None]
    return sig, mag


DATA = [member_data(mb) for mb in members]


def accepted(Didx, Xsig):
    """Is D <=_w X accepted, w=1..3?  Xsig: boolean array (X says sigma) on the band sample."""
    Dsig, Dmag = DATA[Didx]
    supp = Dsig != Xsig
    if not supp.any():
        return np.array([True] * 3), "equal"
    up = Xsig & ~Dsig                                # S -> sigma
    out = np.zeros(3, bool)
    # guidance: weak w-worsening pointwise on the support
    for w in range(3):
        worse = np.where(up, wrong[:, w], ~wrong[:, w])
        if worse[supp].all():
            out[w] = True
    # gates of realisers
    for Ridx, (Rsig, Rmag) in enumerate(DATA):
        if (Rsig[supp] != Dsig[supp]).any():
            continue
        sgn = np.where(up[:, None] == wrong, 1.0, -1.0)    # +m if the move is a w-worsening
        val = (sgn * Rmag)[supp].sum(0) / len(g)
        out |= val >= 0
    return out, ""


def scan(name, Xsig):
    doms = []
    for Didx, mb in enumerate(members):
        acc, _ = accepted(Didx, Xsig)
        if acc.all() and (DATA[Didx][0] != Xsig).any():
            doms.append(mb)
    lab = ", ".join(("T" if v < 0 else f"C{v+1}({t/DELTA:.3f}d)") for v, t in doms[:6])
    print(f"{name}: mu(supp)~{Xsig.mean():.2e}; dominated by {len(doms)} members" + (f": {lab}" if doms else ""))
    return doms


# subsets: thin random sub-selection keeps the pieces small
coin = rng.random(len(g))
T_sig = np.zeros(len(g), bool)
res = {}
# 1. fills of T by cap-1 answers, deep in band 1, each family
for f, sel in (("A_1", fam == "A"), ("B-fam", fam == "B")):
    G = (band == 0) & (tau > 0.6 * DELTA) & (tau < 0.9 * DELTA) & sel & (coin < 0.3)
    res[f"fill deep {f}"] = scan(f"fill T[G->C1], G deep in band 1, {f}", G)
# 2. fills hugging the arc
for f, sel in (("A_1", fam == "A"), ("B-fam", fam == "B")):
    G = (band == 0) & (tau < 0.08 * DELTA) & sel & (coin < 0.5)
    res[f"fill shallow {f}"] = scan(f"fill T[G->C1], G hugging arc of band 1, {f}", G)
# 3. two-corner rivals
for (lo, hi, lab) in ((0.6, 0.9, "deep"), (0.0, 0.08, "shallow")):
    for frac1, frac2 in ((0.3, 0.3), (0.3, 0.05)):
        G1 = (band == 0) & (fam == "A") & (tau > lo * DELTA) & (tau < hi * DELTA) & (coin < frac1)
        G2 = (band == 1) & (fam == "A") & (tau > lo * DELTA) & (tau < hi * DELTA) & (coin < frac2)
        res[f"two-corner {lab} {frac1}/{frac2}"] = scan(
            f"two-corner X=T[G1->C1,G2->C2], A-families, {lab}, sizes {frac1}/{frac2}", G1 | G2)
# 4. retreats and improved retreats of C1(delta)
C1 = DATA[members.index((0, grid[-1]))][0]
for (lo, hi, lab) in ((0.6, 0.9, "deep"), (0.0, 0.08, "shallow")):
    E = (band == 0) & (tau > lo * DELTA) & (tau < hi * DELTA) & (coin < 0.2)
    res[f"retreat {lab}"] = scan(f"retreat C1(d)[E->S], E {lab}", C1 & ~E)
print("NUMERICS DONE")
