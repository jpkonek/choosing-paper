"""PP45 script 2 (CHECKED, exact rationals).  Thm 3.1 for arbitrary fields.

For the pair (T, AB) with AB = C_(a,b,0): sample exact points of the six families (three on H_1(a), three on
H_2(b)).  At every point draw RANDOM positive sigma-vs-silence magnitudes m^T_w, m^AB_w (any fields) and random
interior supporting weights lam^T, lam^AB, rejecting draws until T strictly prefers silence and AB weakly prefers
sigma (own Bayes, pointwise).  Then compute, world by world, the CG2 interval for log c^T_w - log c^AB_w:
   [ max over sigma-correct points of log(m^AB/m^T),  min over sigma-wrong points of log(m^AB/m^T) ].
Thm 3.1 says at least one world has an EMPTY interval, for every such draw.  Ratios are compared exactly.
Control: the same experiment for (T, A) and (A, B) finds draws with all three intervals non-empty.
Run: python3 -I -B pair_obstruction_exact.py > pair_obstruction_exact.out
"""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from pp45_lib import *

random.seed(4545)
OK = True


def check(c, msg):
    global OK
    if not c:
        OK = False
        print("FAIL:", msg)


def rpos():
    return Fr(random.randint(1, 60), random.randint(1, 60)) * Fr(2) ** random.randint(-6, 6)


def family_points(eps, i, t, n):
    """n points per family (three families) on H_i(t)."""
    out, cnt = [], {}
    while min([cnt.get(f, 0) for f in (frozenset({i}), frozenset({i, (i + 1) % 3}), frozenset({i, (i + 2) % 3}))]) < n:
        big = t / eps * rfrac(0, 1)
        small = big / 2 ** random.randint(0, 8) * rfrac(Fr(1, 2), 1)
        lj, lk = (big, small) if random.random() < 0.5 else (small, big)
        g = corner_point(i, lj, lk, eps)
        f = frozenset(pattern(g))
        if cnt.get(f, 0) < n:
            cnt[f] = cnt.get(f, 0) + 1
            out.append(g)
    return out


def draw(pts_info, lamP, lamQ, tries=4000):
    """pts_info: list of (wrong-set, P_is_sigma). Returns per-point magnitude vectors (mP, mQ) with
    P weakly preferring its advice (lam-weighted) and Q strictly preferring its own."""
    res = []
    for (Wset, Psig) in pts_info:
        for _ in range(tries):
            mP = [rpos() for _ in range(3)]
            mQ = [rpos() for _ in range(3)]
            vP = sum((1 if w in Wset else -1) * lamP[w] * mP[w] for w in range(3))   # cost(sigma)-cost(S)
            vQ = sum((1 if w in Wset else -1) * lamQ[w] * mQ[w] for w in range(3))
            okP = (vP <= 0) if Psig else (vP >= 0)
            okQ = (vQ > 0) if Psig else (vQ < 0)
            if okP and okQ:
                res.append((mP, mQ))
                break
        else:
            return None
    return res


def intervals(pts_info, mags):
    """for each world: is the CG2 interval for (log c^Q - log c^P) nonempty?
    CG2: sigma-sayer's scaled magnitude >= S-sayer's at sigma-wrong worlds, <= at sigma-correct ones."""
    out = []
    for w in range(3):
        lo, hi = None, None   # bounds on r := c^Q/c^P ... expressed via ratio rho = mP/mQ when P is sigma
        for (Wset, Psig), (mP, mQ) in zip(pts_info, mags):
            rho = mP[w] / mQ[w]
            # if P sigma: c^P mP >= c^Q mQ on wrong  <=>  r <= rho ; on correct r >= rho
            # if Q sigma: c^Q mQ >= c^P mP on wrong  <=>  r >= rho ; on correct r <= rho
            wrong = w in Wset
            upper = (wrong and Psig) or ((not wrong) and (not Psig))
            if upper:
                hi = rho if hi is None else min(hi, rho)
            else:
                lo = rho if lo is None else max(lo, rho)
        out.append(lo is None or hi is None or lo <= hi)
    return out


for eps in (Fr(1, 10), Fr(3, 10)):
    delta = eps / 4
    a, b = delta / 2, delta / 3
    A_pts = [(pattern(g), True) for g in family_points(eps, 0, a, 3)]   # AB (=P) says sigma on H_1(a)
    B_pts = [(pattern(g), True) for g in family_points(eps, 1, b, 3)]   # and on H_2(b)
    fams = set(p for p, _ in A_pts + B_pts)
    check(len(fams) == 5, f"expected 5 distinct patterns, got {fams}")
    # (T, AB): P = AB, Q = T
    nempty = 0
    ndraw = 0
    while ndraw < 200:
        lamP = [rpos() for _ in range(3)]
        lamQ = [rpos() for _ in range(3)]
        mags = draw(A_pts + B_pts, lamP, lamQ)
        if mags is None:
            continue
        ndraw += 1
        iv = intervals(A_pts + B_pts, mags)
        check(not all(iv), "found compatible fields for (T, AB)!")
        nempty += 1
    print(f"(T,AB) eps={eps}: {ndraw} random own-Bayes field draws; every draw has an empty CG2 interval: "
          f"{nempty == ndraw}")
    # controls (constructive): (T, A) and (A, B) DO admit own-Bayes fields with all CG2 intervals non-empty.
    # Fix the constants ratio r = c^Q/c^P from the order criterion, put mP := r * mQ (CG2 with equality),
    # and draw mQ until both pointwise Bayes conditions hold.
    def construct(info, r, lam):
        mags = []
        for (Wset, Psig) in info:
            sgn = [(1 if w in Wset else -1) for w in range(3)]
            for _ in range(20000):
                mQ = [rpos() for _ in range(3)]
                vQ = sum(sgn[w] * lam[w] * mQ[w] for w in range(3))
                mP = [r[w] * mQ[w] for w in range(3)]
                vP = sum(sgn[w] * lam[w] * mP[w] for w in range(3))
                if ((vQ > 0 and vP <= 0) if Psig else (vQ < 0 and vP >= 0)):
                    mags.append((mP, mQ))
                    break
            else:
                return None
        return mags
    lam = [Fr(1), Fr(1), Fr(1)]
    for name, info, r in (("(T,A)", A_pts, [Fr(1, 8), Fr(1), Fr(1)]),
                          ("(A,B)", A_pts + [(p, False) for p, _ in B_pts], [Fr(1, 8), Fr(8), Fr(1)])):
        mags = construct(info, r, lam)
        ok = mags is not None and all(intervals(info, mags))
        print(f"control {name} eps={eps}: constructed own-Bayes fields with all three CG2 intervals non-empty: {ok}")
        check(ok, f"control {name}")
print("ALL PASS" if OK else "SOME CHECK FAILED")
