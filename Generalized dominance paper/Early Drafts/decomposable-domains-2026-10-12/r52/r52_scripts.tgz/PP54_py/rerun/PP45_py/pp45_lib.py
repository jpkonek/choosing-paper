"""PP45 shared exact geometry (Fractions).

Problems g in Q^3 (modulo sign).  M = c*1 + eps*Delta, vertices m_i = c*1 + eps*e_i, c = (1-eps)/3.
sigma(g) := sign(sum g) (the answer of every model whose credal set contains u).
Band i:  T silent and only vertex m_i lies on the wrong side of g's plane (a corner cut at m_i).
tau(g) := eps*max(lam_j, lam_k): the cut depth at which the single cap at i starts answering.
pattern(g) := frozenset of worlds where sigma is WRONG (sigma*g_w < 0).
"""
from fractions import Fraction as Fr
import random
from itertools import permutations


def consts(eps):
    c = (1 - eps) / 3
    return c


def verts_M(eps):
    c = consts(eps)
    return [[c + (eps if i == j else 0) for j in range(3)] for i in range(3)]


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def D(verts, g):
    vals = [dot(m, g) for m in verts]
    if min(vals) > 0:
        return 1
    if max(vals) < 0:
        return -1
    return 0


def sigma(g):
    s = sum(g)
    return 1 if s > 0 else (-1 if s < 0 else 0)


def band_tau(g, eps):
    """(i, tau) if T silent and exactly one vertex of M is on the wrong side; else None."""
    M = verts_M(eps)
    sg = sigma(g)
    if sg == 0 or D(M, g) != 0:
        return None
    vals = [sg * dot(m, g) for m in M]
    bad = [i for i in range(3) if vals[i] < 0]
    if len(bad) != 1 or any(v == 0 for v in vals):
        return None
    i = bad[0]
    lams = []
    for j in range(3):
        if j != i:
            lams.append(-vals[i] / (vals[j] - vals[i]))
    return i, eps * max(lams)


def pattern(g):
    sg = sigma(g)
    return frozenset(w for w in range(3) if sg * g[w] < 0)


def corner_point(i, lj, lk, eps):
    """Exact g (sum 1) whose plane cuts edges m_i->m_j, m_i->m_k at fractions lj, lk (j<k order)."""
    k0 = consts(eps) / eps
    X, Y = 1 / Fr(lj), 1 / Fr(lk)
    h = (1 + 3 * k0) / (X + Y - 3)
    j, k = [w for w in range(3) if w != i]
    g = [None] * 3
    g[i] = -k0 - h
    g[j] = -k0 + h * (X - 1)
    g[k] = -k0 + h * (Y - 1)
    return g


def rfrac(lo, hi, den=997):
    return Fr(lo) + (Fr(hi) - Fr(lo)) * Fr(random.randint(1, den - 1), den)


def multicap_advice(s, g, eps):
    """C_s(g) via the union lemma (exact): T's answer off the bands; sigma on band i iff tau < s_i."""
    M = verts_M(eps)
    t = D(M, g)
    if t != 0:
        return t
    bt = band_tau(g, eps)
    if bt is None:
        return 0
    i, tau = bt
    return sigma(g) if tau < s[i] else 0


def K_box_verts(s, eps):
    """Vertices of K_s = M cap {m_i <= c+eps-s_i} (all s_i < eps/3): a hexagon (degenerate if s_i = 0)."""
    M = verts_M(eps)
    vs = []
    for i in range(3):
        for j in range(3):
            if j != i:
                f = s[i] / eps
                vs.append([M[i][t] + f * (M[j][t] - M[i][t]) for t in range(3)])
    return vs


def order_feasible(pats):
    """pats: set of (W, R) frozenset pairs. Is there D in R^3 with max_W D > min_R D for all?
    The feasible set is open, so it suffices to test the 6 strict orders."""
    for perm in permutations(range(3)):
        r = {w: perm[w] for w in range(3)}
        if all(max(r[w] for w in W) > min(r[x] for x in R) for (W, R) in pats):
            return True, perm
    return False, None


def pair_patterns(advN, advM):
    """Pattern of the move N(g) -> M(g) for sigma/silence advice values: (W, R) where W = worlds at
    which M's advice is worse.  Returns None if they agree. Uses the global sigma sign pattern."""
    return advN, advM
