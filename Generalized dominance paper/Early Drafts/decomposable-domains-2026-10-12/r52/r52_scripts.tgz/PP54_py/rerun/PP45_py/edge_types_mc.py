"""PP45 script 5 (NUMERICS).  Does the type test (Lemma 2.1) obstruct T together with an edge model?

B_12(t) = l^T-Bayes model at the edge weight (t/(1+t), 1/(1+t), 0) (PP40 field40.edge).  On a Gaussian sample we
collect the move patterns (W, R) of T -> B_12(t) on {T != B}: W = worlds where B's advice has the higher rank.
Feasibility of the pair test with
   (i) an interior supporting weight for B (finite D), and
   (ii) a boundary weight lambda_3 = 0 for B (D_3 = +infinity),
is decided by Lemma 2.2 (order enumeration; for (ii) world 3 is placed strictly on top and patterns with
3 in W are automatically satisfied, patterns with R = {3} are infeasible).
Patterns occurring on fewer than 20 sample points are listed separately (possible sampling noise).
Run: python3 -I -B edge_types_mc.py > edge_types_mc.out
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "PP42_py"))
import numpy as np
from itertools import permutations
from field40 import field, ranks, T, edge

rng = np.random.default_rng(12)
EPS = 0.3
g = rng.standard_normal((1_000_000, 3))
fl = field(g, EPS)
tg = T(g, EPS)


def feasible(pats, inf3):
    for perm in permutations(range(3)):
        if inf3 and perm[2] != 2:
            continue
        r = list(perm)
        if inf3:
            r[2] = 10 ** 9
        okall = True
        for W, R in pats:
            if max(r[w] for w in W) <= min(r[x] for x in R):
                okall = False
                break
        if okall:
            return True
    return False


for t in (0.5, 0.9, 1.0, 1.1, 2.0):
    b = edge(t, g, fl)
    d = b != tg
    rT, rB = ranks(tg[d], g[d]), ranks(b[d], g[d])
    W = rB > rT
    keys = [(tuple(np.where(Wr)[0]), tuple(np.where(~Wr)[0])) for Wr in W]
    from collections import Counter
    cnt = Counter(keys)
    pats = [(set(k[0]), set(k[1])) for k, v in cnt.items() if v >= 20]
    rare = {k: v for k, v in cnt.items() if v < 20}
    def lab(k):
        return "W={" + ",".join(str(w + 1) for w in k[0]) + "}"
    print(f"t={t}: mu(T!=B)={d.mean():.3f}; patterns: " +
          ", ".join(f"{lab(k)}:{v}" for k, v in sorted(cnt.items(), key=lambda kv: -kv[1])))
    print(f"   pair test feasible with interior weight: {feasible(pats, False)};"
          f" with boundary weight lambda_3=0: {feasible(pats, True)}" + (f"; rare patterns ignored: {rare}" if rare else ""))
print("NUMERICS DONE")
