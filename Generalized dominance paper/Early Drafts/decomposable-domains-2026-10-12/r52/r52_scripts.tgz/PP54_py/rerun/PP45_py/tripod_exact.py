"""PP45 script 3 (CHECKED, exact rationals).

(A) The tripod design of section 5 on exact band points: for T and caps C_{v,t} (v = 1,2,3; t on a grid),
    (A1) strict own-Bayes at lambda = u over all four advice values, with the pointwise margin
         |cost(sigma) - cost(S)| >= (3/8) * mhat (Prop 5.2);
    (A2) strict CG2 with the GLOBAL constants c^s_w = 1/mu^s_w: ratio of scaled magnitudes
         >= 1 + c(mhat^P + mhat^Q) at sigma-wrong worlds, <= 1/(1 + c(...)) at sigma-correct worlds;
    (A3) the pair lower bounds mhat^P + mhat^Q >= phi(t)-phi(t'), phi(t), (3/4) phi(t)  (Lemma 5.3);
    (A4) (BR): member-to-member magnitude ratios lie in [3/10, 10/3];
    (A5) continuity in t at fixed g: magnitudes at t = tau(g) +- 1/10^6 differ by O(1/10^6).
(B) Pointwise Bayes estimate for PP42 Thm 4.3(a) under l^T (Prop 5.6): on every band point of H_v,
    sum_{w!=v} |d_w| <= 3 d_v - 3 u.d,   sum_{w!=v} |d'_w| <= 3 alpha_v + 3 u.d',   u.d > 0, u.d' > 0.
Run: python3 -I -B tripod_exact.py > tripod_exact.out
"""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from pp45_lib import *

random.seed(51)
OK = True
CC = Fr(1, 4)


def check(c, msg):
    global OK
    if not c:
        OK = False
        print("FAIL:", msg)


def band_sample(eps, delta, i):
    big = delta / eps * rfrac(0, 1) / 2 ** random.randint(0, 6)
    small = big / 2 ** random.randint(0, 8) * rfrac(Fr(1, 2), 1)
    lj, lk = (big, small) if random.random() < 0.5 else (small, big)
    return corner_point(i, lj, lk, eps)


def nvec(g, eps, delta):
    i, tau = band_tau(g, eps)
    phi = tau / (2 * delta)
    q = 1 - phi
    zeta = phi / 2
    W = pattern(g)
    j, k = [w for w in range(3) if w != i]
    n = [None] * 3
    n[i] = Fr(1)
    if W == {i}:
        n[j] = n[k] = -q / 2
    elif W == {i, k}:      # B_j: sigma correct only at j
        n[j], n[k] = -(q + zeta), zeta
    elif W == {i, j}:      # B_k
        n[k], n[j] = -(q + zeta), zeta
    else:
        raise ValueError
    return i, tau, n


def mu(member, delta):
    v, t = member
    m = [Fr(1)] * 3
    if v is not None:
        m[v] = 1 - t / (2 * delta)
    return m


def advice_sigma(member, i, tau):
    v, t = member
    return v == i and t > tau


def mags(member, g, eps, delta, info=None):
    i, tau, n = info if info else nvec(g, eps, delta)
    m = mu(member, delta)
    val = sum(n[w] * m[w] for w in range(3))
    mh = abs(val)
    sig = advice_sigma(member, i, tau)
    H = []
    for w in range(3):
        wrong = n[w] > 0
        if sig:
            H.append(1 + CC * mh if wrong else 1 - CC * mh)
        else:
            H.append(1 - CC * mh if wrong else 1 + CC * mh)
    return [abs(n[w]) * m[w] * H[w] for w in range(3)], H, mh, sig, val


def full_costs(mg, W):
    """costs at lambda = u (times 3) of sigma, S, -sigma, contra for the section-5 field."""
    Lam = sum(mg)
    B = 2 * Lam
    cost = {"sigma": 0, "S": 0, "-sigma": 0, "contra": 0}
    for w in range(3):
        if w in W:     # sigma wrong: l(-sigma)=0, l(S)=m, l(sigma)=2m, l(contra)=2m+Lam
            cost["-sigma"] += 0; cost["S"] += mg[w]; cost["sigma"] += 2 * mg[w]; cost["contra"] += 2 * mg[w] + Lam
        else:          # sigma correct: l(sigma)=0, l(S)=m, l(-sigma)=m+B, l(contra)=m+B+Lam
            cost["S"] += mg[w]; cost["-sigma"] += mg[w] + B; cost["contra"] += mg[w] + B + Lam
    return cost


nA = 0
for eps in (Fr(1, 10), Fr(3, 10)):
    delta = eps / 4
    grid = [delta * Fr(k, 8) for k in range(1, 9)]
    members = [(None, Fr(0))] + [(v, t) for v in range(3) for t in grid]
    for trial in range(240):
        i = trial % 3
        g = band_sample(eps, delta, i)
        info = nvec(g, eps, delta)
        _, tau, n = info
        W = pattern(g)
        data = {}
        for mb in members:
            mg, H, mh, sig, val = mags(mb, g, eps, delta, info)
            data[mb] = (mg, H, mh, sig)
            if mh == 0:
                continue
            cost = full_costs(mg, W)
            best = min(cost, key=cost.get)
            want = "sigma" if sig else "S"
            check(best == want and sorted(cost.values())[0] < sorted(cost.values())[1], f"Bayes {mb} at {g}")
            check(abs(cost["sigma"] - cost["S"]) >= Fr(3, 8) * mh, "margin estimate")
            nA += 1
        for P in members:
            for Q in members:
                mP, HP, mhP, sP = data[P]
                mQ, HQ, mhQ, sQ = data[Q]
                if not (sP and not sQ):
                    continue
                s_ = mhP + mhQ
                for w in range(3):
                    r = HP[w] / HQ[w]       # = scaled-magnitude ratio, constants 1/mu
                    if n[w] > 0:
                        check(r >= 1 + CC * s_ and r > 1, "CG2 wrong world")
                    else:
                        check(r <= 1 / (1 + CC * s_) and r < 1, "CG2 correct world")
                    rr_ = mP[w] / mQ[w]
                    check(Fr(3, 10) <= rr_ <= Fr(10, 3), "BR")
                # pair lower bounds (Lemma 5.3)
                vP, tP = P
                vQ, tQ = Q
                ph = lambda t: t / (2 * delta)
                if vQ is None:
                    check(s_ == ph(tP), "pair bound with T")
                elif vQ == vP:
                    check(s_ == ph(tP) - ph(tQ), "pair bound same vertex")
                else:
                    check(s_ >= Fr(3, 4) * ph(tP), "pair bound cross vertex")
                nA += 1
        # continuity at the switch
        for v in range(3):
            if v != i:
                continue
            h = Fr(1, 10 ** 6)
            if tau + h <= delta and tau - h > 0:
                m1 = mags((v, tau + h), g, eps, delta, info)[0]
                m0 = mags((v, tau - h), g, eps, delta, info)[0]
                check(max(abs(a - b) for a, b in zip(m1, m0)) <= 10 * h / delta, "continuity at the switch")
print(f"(A) tripod design: {nA} exact Bayes / CG2 / BR / pair-bound checks")

# ---------------- (B) PP42 pointwise estimate under l^T (exact)
def Fexact(th, eps):
    c = (1 - eps) / 3
    L = (c + eps) / c
    d = 1 / (1 + L)
    if th <= d:
        return th / (2 * d)
    if th <= 1 / L:
        return Fr(1, 2) + L * (th - d) / (2 * d)
    return L * th


def Gexact(s, eps):
    return 1 / Fexact(1 / s, eps)


def lT(g, eps):
    a = [abs(x) for x in g]
    pos = sum(1 for x in g if x > 0)
    k = [w for w in range(3) if (g[w] > 0) == (pos == 1)][0]
    al, be = list(a), list(a)
    for j in range(3):
        if j != k:
            s = a[j] / a[k]
            al[j] = a[k] * Gexact(s, eps)
            be[j] = a[k] * Fexact(s, eps)
    return al, be


nB = 0
worst = {}
for eps in (Fr(1, 10), Fr(3, 10), Fr(1, 2)):
    delta = eps / 4
    for trial in range(3000):
        v = trial % 3
        g = band_sample(eps, delta, v)
        al, be = lT(g, eps)
        W = pattern(g)
        d = [be[w] if w in W else -al[w] for w in range(3)]
        dp = [-al[w] if w in W else be[w] for w in range(3)]
        ud, udp = sum(d) / 3, sum(dp) / 3
        check(ud > 0 and udp > 0, "T silent strictly")
        s1 = sum(abs(d[w]) for w in range(3) if w != v)
        s2 = sum(abs(dp[w]) for w in range(3) if w != v)
        check(s1 <= 3 * d[v] - 3 * ud, "sigma-vs-S pointwise bound")
        check(s2 <= 3 * al[v] + 3 * udp, "-sigma pointwise bound")
        r1, r2 = s1 / d[v], s2 / al[v]
        worst[eps] = max(worst.get(eps, (0, 0))[0], float(r1)), max(worst.get(eps, (0, 0))[1], float(r2))
        nB += 1
for eps, (r1, r2) in worst.items():
    print(f"(B) eps={eps}: max sum|d_w|/d_v = {r1:.3f} (<= 3 proved);  max sum|d'_w|/alpha_v = {r2:.3f} "
          f"(unbounded by 3 alone; the proof uses 3 alpha_v + 3 u.d')")
print(f"(B) {nB} exact band points")
print("ALL PASS" if OK else "SOME CHECK FAILED")
