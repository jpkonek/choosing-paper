#!/bin/bash
# Re-run the authors' scripts in copies; outputs written next to the copies.
cd "$(dirname "$0")"
for d in PP45_py PP47_py PP46_py; do
  for s in $d/*.py; do
    b=$(basename $s .py)
    case $b in pp45_lib|geom|star) continue;; esac
    start=$(date +%s)
    ( cd $d && NRIV=150 timeout 3000 python3 -I -B $b.py > $b.out 2> $b.err )
    echo "$d/$b exit=$? secs=$(( $(date +%s) - start ))" >> runall.log
  done
done
echo DONE >> runall.log
