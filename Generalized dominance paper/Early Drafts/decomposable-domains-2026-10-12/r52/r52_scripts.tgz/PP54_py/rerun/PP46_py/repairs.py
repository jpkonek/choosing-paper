"""PP46 script 4 (NUMERICS on an empirical measure; no proof depends on it).

Repair coverage of the closed-form star design (star.py, b = 1) against sampled rivals.
The sample (Gaussian, kept on Sil(T)) is treated as the measure: rivals are defined on it, so each
domination verdict is exact for the empirical measure and only a proxy for the continuum.
Members: T and caps (v, s), v = 1, 2, 3, s on a 20-point log grid in [delta/60, delta].
A member D dominates X if at every world w the record rec(D, X) is accepted: by guidance, or by the
gate of some member R that equals D on the support of the record (R's own field, value > 0).
Variant b < 1: PP42-style discount of each cap's own world-v penalties on its own region; it breaks
cross-vertex CG2 (star_check.out (6)) and is run only to show what such a discount would buy.
Rival classes:
  R1 single-band sigma-fills T[G -> sigma] (generation-2 fills by caps' answers),
  R2 two-corner rivals T[G_i -> sigma, G_j -> sigma] (bands i != j),
  R3 retreats C^v_s[G -> S] with G inside H_v(s),
  R4 vertex fills T[G -> V_w].
G is a random thinned subset of one depth-layer atom (band v, class r, layer) per band used.
Run: NRIV=150 python3 -I -B repairs.py > repairs.out   (NRIV = rivals per class per configuration)
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from star import *

rng = np.random.default_rng(4647)


def run(eps, TH, KAP, ETA, B=1.0, nsamp=400_000, nriv=int(os.environ.get('NRIV', 300)), label=""):
    delta = 0.95 * eps / 3
    g = rng.standard_normal((nsamp, 3))
    geo0 = Geo(g, eps)
    keep = geo0.sil & (geo0.iso >= 0)
    geo = Geo(g[keep], eps)
    n = len(geo.g)
    base = base_field(geo, TH, KAP, delta)
    sizes = delta * np.geomspace(1 / 60, 1, 20)
    mem = [(-1, 0.0)] + [(v, s) for v in range(3) for s in sizes]
    ADV = np.array([advice(geo, *N) for N in mem], dtype=np.int8)
    PEN = np.zeros((len(mem), 3, n, 3), dtype=np.float32)   # advice index: 0 sigma, 1 silent, 2 -sigma
    for a, N in enumerate(mem):
        f = member_field(geo, base, N[0], N[1], TH, ETA, b=(B if N[0] >= 0 else 1.0))
        for ai, adv in enumerate((geo.sig, np.zeros(n, int), -geo.sig)):
            PEN[a, ai] = penalties(geo, f, adv) * f[3]
    sgn = np.sign(geo.g)

    def aidx(adv, idx=None):
        sg = geo.sig if idx is None else geo.sig[idx]
        return np.where(adv == sg, 0, np.where(adv == 0, 1, 2))

    def rank(adv, idx):
        return np.where(adv[:, None] == 0, 1, np.where(adv[:, None] * sgn[idx] > 0, 0, 2))

    def dominated(X):
        xi = aidx(X)
        for d in range(len(mem)):
            D = ADV[d]
            supp = np.where(X != D)[0]
            if len(supp) == 0:
                return "equal", d
            di = aidx(D[supp], supp)
            agree = (ADV[:, supp] == D[supp]).all(1)
            Rs = np.where(agree)[0]
            phi = (PEN[Rs[:, None], xi[supp][None, :], supp[None, :], :] -
                   PEN[Rs[:, None], di[None, :], supp[None, :], :]).sum(1)   # (len(Rs), 3)
            gate_ok = (phi > 0).any(0)
            guid = (rank(X[supp], supp) >= rank(D[supp], supp)).all(0)
            if (gate_ok | guid).all():
                return "dom", d
        return "undominated", None

    layers = [0, delta / 4, delta / 2, delta, 2 * delta, eps]

    def atom(v, r, l):
        return np.where((geo.iso == v) & (geo.cls == r) & (geo.tau >= layers[l]) & (geo.tau < layers[l + 1]))[0]

    def thin(idx, f):
        k = max(1, int(round(f * len(idx))))
        return rng.choice(idx, k, replace=False) if len(idx) else idx

    res = {}
    T0 = ADV[0].astype(int)
    for cls_name in ("R1", "R2", "R3", "R4"):
        tally = {"dom": 0, "undominated": 0, "equal": 0}
        bydom = {"T": 0, "same-vertex cap": 0, "other-vertex cap": 0}
        examples = []
        for _ in range(nriv):
            X = T0.copy()
            if cls_name == "R1":
                v, r, l = rng.integers(3), rng.integers(3), rng.integers(5)
                G = thin(atom(v, r, l), 10 ** rng.uniform(-2, 0))
                X[G] = geo.sig[G]
                desc = (v + 1, r + 1, l)
                bands = {v}
            elif cls_name == "R2":
                v1, v2 = rng.choice(3, 2, replace=False)
                G1 = thin(atom(v1, rng.integers(3), rng.integers(4)), 10 ** rng.uniform(-2, 0))
                G2 = thin(atom(v2, rng.integers(3), rng.integers(4)), 10 ** rng.uniform(-2, 0))
                X[G1] = geo.sig[G1]
                X[G2] = geo.sig[G2]
                desc = (v1 + 1, v2 + 1, len(G1), len(G2))
                bands = {v1, v2}
            elif cls_name == "R3":
                c = 1 + rng.integers(len(sizes))
                v, s = mem[c]
                X = ADV[c].astype(int).copy()
                inside = np.where((geo.iso == v) & (geo.tau < s) & (geo.cls == rng.integers(3)))[0]
                if len(inside) == 0:
                    continue
                G = thin(inside, 10 ** rng.uniform(-1.5, -0.1))
                X[G] = 0
                desc = ("retreat of", v + 1, round(s / delta, 3))
                bands = {v}
            else:
                w = rng.integers(3)
                v, r, l = rng.integers(3), rng.integers(3), rng.integers(5)
                G = thin(atom(v, r, l), 10 ** rng.uniform(-2, 0))
                X[G] = np.sign(geo.g[G, w]).astype(int)
                desc = ("V", w + 1, "on", v + 1, r + 1, l)
                bands = {v}
            out, d = dominated(X)
            tally[out] += 1
            if out == "dom":
                if d == 0:
                    bydom["T"] += 1
                elif mem[d][0] in bands:
                    bydom["same-vertex cap"] += 1
                else:
                    bydom["other-vertex cap"] += 1
            elif out == "undominated" and len(examples) < 4:
                examples.append(desc)
        res[cls_name] = (tally, bydom, examples)
        print(f"  {label} {cls_name}: {tally}  dominators used: {bydom}  undominated examples: {examples}")
    return res


for eps, KAP, B in ((0.3, 0.1, 1.0), (0.3, 0.5, 1.0), (0.3, 0.9, 1.0), (0.1, 0.1, 1.0), (0.3, 0.1, 0.4)):
    print(f"eps={eps}, TH=0.5, kap={KAP}, eta=0.2, own-region world-v discount b={B}"
          + ("  [b < 1 violates cross-vertex CG2: diagnostic only, see star_check (6)]" if B < 1 else ""))
    run(eps, 0.5, KAP, 0.2, B=B, label=f"kap={KAP},b={B}")
print("NUMERICS DONE")
