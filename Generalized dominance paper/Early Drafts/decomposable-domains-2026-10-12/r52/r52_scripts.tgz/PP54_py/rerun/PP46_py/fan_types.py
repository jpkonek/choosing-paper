"""PP46 script 5 (NUMERICS for which answer types occur; the order test itself is exact enumeration).

Independent check of PP45 Lemma 2.1 / Thm 3.1 / Cor 3.2 and of PP45's 'fan' (tilted single-vertex cuts).
A tilted cut at vertex v cuts the two edges at m_v at depths t1 (towards m_j) and t2 (towards m_k):
K = conv(m_j, m_k, p_j, p_k), p_o = m_v + (t_o/eps)(m_o - m_v).  D_K = T except on its band, where it answers sigma.
For a pair (N, M): at each sampled disagreement point record (answerer, set C of worlds where sigma is correct).
Pair test (PP45 Lemma 2.1 = PP46 Lemma A0 / Thm B), with psi := -D (PP45's D):
   M answers: max_{c in C} psi_c > min_{w not in C} psi_w;   N answers: min_{c in C} psi_c < max_{w not in C} psi_w.
Feasible iff some weak order psi in {0,1,2}^3 satisfies every occurring type (types seen at >= MINCOUNT points).
(A) box members incl. (T, combined cut): reproduces Thm B / PP45 Cor 3.2.
(B) the fan near T: random tilted single-vertex cuts, sizes in [delta/50, delta], pairs with T, at one vertex
    (nested and crossing) and at different vertices.
(C) two-vertex tilted refinements (PP45 Cor 3.3) against T.
Run: python3 -I -B fan_types.py > fan_types.out
"""
import itertools
import numpy as np

rng = np.random.default_rng(4648)
MINCOUNT = 10
PSI = [np.array(p) for p in itertools.product(range(3), repeat=3)]


def sample(eps, n=1_500_000, nb=1_500_000):
    c = (1 - eps) / 3
    Mv = np.array([[c + (eps if i == j else 0) for j in range(3)] for i in range(3)])
    g = rng.standard_normal((n, 3))
    h = rng.standard_normal((nb, 3))
    v = rng.integers(0, 3, nb)
    m = Mv[v]
    h = h - ((h * m).sum(1) / (m * m).sum(1))[:, None] * m
    h = h + (rng.uniform(-0.02, 0.02, nb) * eps)[:, None] * m
    return np.vstack([g, h]), Mv


def model(g, Mv, eps, cuts):
    """cuts: list of (v, t1, t2) single-vertex tilted cuts (t = 0 means no cut on that edge side)."""
    vals = g @ Mv.T
    T = np.where(vals.min(1) > 0, 1, np.where(vals.max(1) < 0, -1, 0))
    V = [Mv[q] for q in range(3)]
    verts = []
    cut = {v: (t1, t2) for v, t1, t2 in cuts}
    for v in range(3):
        if v not in cut:
            verts.append(Mv[v])
            continue
        j, k = [o for o in range(3) if o != v]
        t1, t2 = cut[v]
        verts.append(Mv[v] + (t1 / eps) * (Mv[j] - Mv[v]))
        verts.append(Mv[v] + (t2 / eps) * (Mv[k] - Mv[v]))
    vv = g @ np.array(verts).T
    return np.where(vv.min(1) > 0, 1, np.where(vv.max(1) < 0, -1, 0)), T


def types(g, aN, aM):
    D = aN != aM
    sig = np.where(aN[D] != 0, aN[D], aM[D])
    corr = (sig[:, None] * np.sign(g[D])) > 0
    ans = np.where(aM[D] != 0, 1, 0)        # 1: M answers, 0: N answers
    assert ((aN[D] == 0) | (aM[D] == 0)).all(), "three-valued point"
    keys = ans * 8 + corr @ np.array([1, 2, 4])
    cnt = np.bincount(keys, minlength=16)
    return {(k // 8, tuple(w for w in range(3) if (k % 8) >> w & 1)): int(cnt[k]) for k in range(16) if cnt[k] >= MINCOUNT}


def feasible(tp):
    for psi in PSI:
        ok = True
        for (ans, C) in tp:
            W = [w for w in range(3) if w not in C]
            if not C or not W:
                continue
            if ans == 1 and not (max(psi[c] for c in C) > min(psi[w] for w in W)):
                ok = False; break
            if ans == 0 and not (min(psi[c] for c in C) < max(psi[w] for w in W)):
                ok = False; break
        if ok:
            return True, psi
    return False, None


for eps in (0.1, 0.3):
    delta = 0.95 * eps / 3
    g, Mv = sample(eps)
    print(f"eps={eps}, {len(g)} problems")
    # (A)
    a, b = delta / 2, delta / 3
    box = {"T": [], "A=C(a,0,0)": [(0, a, a)], "B=C(0,b,0)": [(1, b, b)], "AB=C(a,b,0)": [(0, a, a), (1, b, b)],
           "ABC": [(0, a, a), (1, b, b), (2, a, a)]}
    adv = {k: model(g, Mv, eps, cuts)[0] for k, cuts in box.items()}
    for N, M in itertools.combinations(box, 2):
        tp = types(g, adv[N], adv[M])
        f, psi = feasible(tp)
        print(f"  (A) {N:>12} vs {M:<12} types={sorted(tp)}  pair test: {'feasible' if f else 'EMPTY'}")
    # (B) fan
    T0 = model(g, Mv, eps, [])[1]
    stats = {"with T": [0, 0], "same vertex": [0, 0], "different vertices": [0, 0]}
    members = []
    for _ in range(40):
        v = int(rng.integers(3))
        t1, t2 = delta * 10 ** rng.uniform(np.log10(1 / 50), 0, 2)
        members.append((v, t1, t2))
    fadv = [model(g, Mv, eps, [m])[0] for m in members]
    fails = []
    for i, m in enumerate(members):
        f, _ = feasible(types(g, T0, fadv[i]))
        stats["with T"][0] += 1; stats["with T"][1] += f
        if not f:
            fails.append(("T", m))
    for i, j in itertools.combinations(range(len(members)), 2):
        key = "same vertex" if members[i][0] == members[j][0] else "different vertices"
        f, _ = feasible(types(g, fadv[i], fadv[j]))
        stats[key][0] += 1; stats[key][1] += f
        if not f:
            fails.append((members[i], members[j]))
    print(f"  (B) fan of 40 tilted single-vertex cuts, tilt ratio t1/t2 in [1/50, 50]: " +
          "; ".join(f"{k}: {v[1]}/{v[0]} feasible" for k, v in stats.items()))
    for fl in fails[:5]:
        print("      failing pair:", fl)
    # (C) two-vertex tilted refinements vs T
    nC, okC = 0, 0
    for _ in range(30):
        vs = rng.choice(3, 2, replace=False)
        cuts = [(int(v), *(delta * 10 ** rng.uniform(np.log10(1 / 20), 0, 2))) for v in vs]
        f, _ = feasible(types(g, T0, model(g, Mv, eps, cuts)[0]))
        nC += 1; okC += f
    print(f"  (C) refinements missing two vertices (random tilts) vs T: {okC}/{nC} feasible (PP45 Cor 3.3 predicts 0)")
print("NUMERICS DONE")
