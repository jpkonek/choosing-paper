"""PP46 library: the closed-form star design (base field E, weights pi, humility).

Problems g (N x 3 floats).  Advice codes: +1, -1, 0 silent, 2 contradiction.
Base field on Sil(T) (all values times |g|), at a problem with isolated vertex v, depth tau,
class r, theta = TH * tau / eps, rho = kap * theta / theta(delta):
  piece r = v   (sigma wrong at v only):     beta_v = 1, alpha_j = alpha_k = (1 - theta)/2
  piece r = j   (sigma correct at j only):   beta_v = 1, beta_k = rho, alpha_j = 1 + rho - theta
  so that  sum_w e_w = theta  (e_w := l_w(sigma) - l_w(S)) exactly.
  Free entries: beta = 2(1 + rho) at sigma-correct worlds, alpha = e_w/2 at sigma-wrong worlds, gamma = 1.
On Ans(T) (answer a = T's answer): alpha = 1 at a-correct worlds, beta = rhoA at a-wrong worlds,
  beta = 2 at a-correct worlds, alpha = rhoA/2 at a-wrong worlds, gamma = 1.
Members: T (v = -1, s = 0) and caps (v, s).  Weight pi^T = (1,1,1), pi^(v,s) = (1,1,1) - theta(s) e_v.
Own field l^N_w = pi^N_w * (base_w with humility), so N is u-Bayes for l^N iff it is pi^N-Bayes for
the humble base; CG2 constants c^N_w = 1/pi^N_w.
Humility of cap (v,s) on its own answer region {band v, tau < s}: beta at sigma-wrong worlds times
(1 + eta*h), alpha at sigma-correct worlds times (1 - eta*h), h = theta(s) - theta(tau).
"""
import numpy as np


class Geo:
    def __init__(self, g, eps):
        self.g, self.eps = g, eps
        c = (1 - eps) / 3
        self.Mv = np.array([[c + (eps if i == j else 0) for j in range(3)] for i in range(3)])
        vals = g @ self.Mv.T
        self.Tadv = np.where(vals.min(1) > 0, 1, np.where(vals.max(1) < 0, -1, 0))
        self.sil = self.Tadv == 0
        sv = np.sign(vals)
        iso = np.full(len(g), -1)
        for v in range(3):
            o = [q for q in range(3) if q != v]
            iso[self.sil & (sv[:, o[0]] == sv[:, o[1]]) & (sv[:, v] == -sv[:, o[0]])] = v
        self.iso = iso
        av = np.abs(vals)
        tau = np.full(len(g), np.inf)
        for v in range(3):
            o = [q for q in range(3) if q != v]
            m = iso == v
            r = av[m, v] / np.minimum(av[m, o[0]], av[m, o[1]])
            tau[m] = eps * r / (1 + r)
        self.tau = tau
        pos = (g > 0).sum(1)
        self.cls = np.where(pos == 1, np.argmax(g > 0, 1), np.where(pos == 2, np.argmax(g < 0, 1), -1))
        self.sig = np.sign(g.sum(1)).astype(int)
        self.nrm = np.linalg.norm(g, axis=1)
        # sigma-correct mask per world (on Sil(T)); on Ans(T) use T's answer
        ans = np.where(self.sil, self.sig, self.Tadv)
        self.corr = (ans[:, None] * np.sign(g)) > 0


def advice(geo, v, s):
    """union-lemma advice of the star member (v, s); v = -1 is T."""
    a = geo.Tadv.copy()
    if v >= 0:
        m = (geo.iso == v) & (geo.tau < s)
        a[m] = geo.sig[m]
    return a


def base_field(geo, TH, kap, delta, rhoA=0.2):
    g, eps = geo.g, geo.eps
    N = len(g)
    al = np.zeros((N, 3)); be = np.zeros((N, 3)); ga = np.ones((N, 3))
    th = np.where(geo.sil, TH * np.minimum(geo.tau, eps) / eps, 0.0)
    thd = TH * delta / eps
    rho = kap * th / thd
    e = np.zeros((N, 3))
    sil = geo.sil
    for v in range(3):
        for r in range(3):
            m = sil & (geo.iso == v) & (geo.cls == r)
            if not m.any():
                continue
            if r == v:
                e[m, v] = 1.0
                for j in range(3):
                    if j != v:
                        e[m, j] = -(1 - th[m]) / 2
            else:
                k = 3 - v - r
                e[m, v] = 1.0
                e[m, k] = rho[m]
                e[m, r] = -(1 + rho[m] - th[m])
    corr = geo.corr
    # Sil(T): alpha at correct worlds = -e, beta at wrong worlds = e
    big = 2 * (1 + rho)[:, None] * np.ones((1, 3))
    al[sil] = np.where(corr[sil], -e[sil], e[sil] / 2)
    be[sil] = np.where(corr[sil], big[sil], e[sil])
    ans = ~sil
    al[ans] = np.where(corr[ans], 1.0, rhoA / 2)
    be[ans] = np.where(corr[ans], 2.0, rhoA)
    scale = geo.nrm[:, None]
    return al * scale, be * scale, ga * scale, th


def theta_of(s, TH, eps):
    return TH * s / eps


def member_field(geo, base, v, s, TH, eta, b=1.0):
    """humble base (before the per-world weight pi); returns alpha, beta, gamma, pi."""
    al, be, ga, th = base
    al, be = al.copy(), be.copy()
    pi = np.ones(3)
    if v >= 0:
        ths = theta_of(s, TH, geo.eps)
        pi[v] -= ths
        m = (geo.iso == v) & (geo.tau < s)
        h = (ths - th[m])[:, None]
        cm = geo.corr[m]
        al[m] = np.where(cm, al[m] * (1 - eta * h), al[m])
        be[m] = np.where(~cm, be[m] * (1 + eta * h), be[m])
        if b != 1.0:   # PP42-style discount of the cap's own world-v penalties on its own region
            al[m, v] *= b
            be[m, v] *= b
            ga[m, v] *= b
    return al, be, ga, pi


def penalties(geo, fld, adv):
    al, be, ga = fld[:3]
    r = np.where(adv[:, None] == 2, 3, np.where(adv[:, None] == 0, 1,
                 np.where(adv[:, None] * np.sign(geo.g) > 0, 0, 2)))
    return np.where(r == 0, 0.0, np.where(r == 1, al, np.where(r == 2, al + be, al + be + ga)))
