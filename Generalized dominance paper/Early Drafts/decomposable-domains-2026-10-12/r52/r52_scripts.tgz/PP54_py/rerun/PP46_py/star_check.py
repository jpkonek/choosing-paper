"""PP46 script 3 (NUMERICS: pointwise formulas evaluated at sampled problems; the proofs are in the note).

Star design of star.py, for eps in {0.1, 0.3, 0.5}, delta = 0.95 eps/3, TH = 1/2, kap = 1/2, eta = 1/5
(eta < 1/(2 + 2 kap) is the pointwise Bayes condition for the answer against silence).
Members: T and caps (v, s), v = 1, 2, 3, s in {delta/4, delta/2, delta}.
(1) own-Bayes: each member's advice is the strict u-optimum of its own field at every sampled problem
    (four advices compared); min margin / |g| reported.
(2) pointwise strict CG2 with the global constants c^N_w = 1/pi^N_w: c^N f^N < c^M f^M at every sampled
    point of D_NM, every pair, every world.
(3) essential intervals [L_NM, U_NM] (from samples) and the global differences x_N - x_M: closed test holds,
    open test (L < U) fails: the intervals are single points (in the limit).
(4) triple cycle sums for all triples (closed version): sum L <= 0 <= sum U.
(5) the combined cut C_(s,t,0) cannot be added: reported via pair_criterion (no fields exist).
Run: python3 -I -B star_check.py > star_check.out
"""
import os, sys, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from star import *

rng = np.random.default_rng(4646)
TH, KAP, ETA = 0.5, 0.5, 0.2
OK = True


def check(cond, msg):
    global OK
    if not cond:
        OK = False
        print("FAIL:", msg)


def sample(eps, n=1_500_000, nband=600_000):
    g = rng.standard_normal((n, 3))
    # extra points concentrated near the arcs m_v . g = 0 (small depth)
    h = rng.standard_normal((nband, 3))
    c = (1 - eps) / 3
    Mv = np.array([[c + (eps if i == j else 0) for j in range(3)] for i in range(3)])
    v = rng.integers(0, 3, nband)
    m = Mv[v]
    h = h - ((h * m).sum(1) / (m * m).sum(1))[:, None] * m
    h = h + (rng.uniform(-0.03, 0.03, nband) * eps)[:, None] * m
    return np.vstack([g, h])


for eps in (0.1, 0.3, 0.5):
    delta = 0.95 * eps / 3
    geo = Geo(sample(eps), eps)
    base = base_field(geo, TH, KAP, delta)
    mem = [(-1, 0.0)] + [(v, f * delta) for v in range(3) for f in (0.25, 0.5, 1.0)]
    flds = {N: member_field(geo, base, N[0], N[1], TH, ETA) for N in mem}
    advs = {N: advice(geo, *N) for N in mem}
    # (1) Bayes
    worst = np.inf
    for N in mem:
        al, be, ga, pi = flds[N]
        costs = np.stack([penalties(geo, flds[N], np.full(len(geo.g), a)) @ pi for a in (1, -1, 0, 2)], 1)
        idx = np.select([advs[N] == 1, advs[N] == -1, advs[N] == 0], [0, 1, 2], 3)
        mine = costs[np.arange(len(idx)), idx]
        costs[np.arange(len(idx)), idx] = np.inf
        marg = (costs.min(1) - mine) / geo.nrm
        ok = (marg > 0).all()
        check(ok, f"Bayes eps={eps} N={N}")
        worst = min(worst, marg.min())
    nb = int(((geo.iso >= 0) & (geo.tau < delta)).sum())
    print(f"eps={eps}: {len(geo.g)} problems ({nb} in the bands H_v(delta)); every member strictly own-Bayes; "
          f"min margin/|g| = {worst:.2e}")
    # (2)-(3)
    x = {N: -np.log(flds[N][3]) for N in mem}
    nstrict = 0
    degenerate = 0
    intervals = {}
    for N, M in itertools.combinations(mem, 2):
        D = advs[N] != advs[M]
        if not D.any():
            continue
        # actual own fields l^N = pi^N * (humble base); f^N, f^M as in PP42 section 3.1
        fN = (penalties(geo, flds[N], advs[M])[D] - penalties(geo, flds[N], advs[N])[D]) * flds[N][3]
        fM = (penalties(geo, flds[M], advs[M])[D] - penalties(geo, flds[M], advs[N])[D]) * flds[M][3]
        cN, cM = np.exp(x[N]), np.exp(x[M])
        gap = (cM * fM - cN * fN) / geo.nrm[D][:, None]
        check((gap > 0).all(), f"pointwise strict CG2 eps={eps} {N} {M}")
        nstrict += gap.size
        LU = []
        for w in range(3):
            r = fM[:, w] / fN[:, w]
            neg, pos = fN[:, w] < 0, fN[:, w] > 0
            L = np.log(r[neg].max()) if neg.any() else -np.inf
            U = np.log(r[pos].min()) if pos.any() else np.inf
            dx = x[N][w] - x[M][w]
            check(L <= dx + 1e-12 and dx <= U + 1e-12, "closed interval contains global difference")
            if np.isfinite(L) and np.isfinite(U) and U - L < 0.02:
                degenerate += 1
            LU.append((L, U))
        intervals[(N, M)] = LU
        intervals[(M, N)] = [(-U, -L) for (L, U) in LU]
    print(f"   pointwise strict CG2 at all {nstrict} (pair, point, world) instances with constants 1/pi; "
          f"{degenerate} two-sided pair-world intervals have width < 0.02 (essentially single points)")
    # (4) triples, closed test
    nt, bad = 0, 0
    for A, B, C in itertools.combinations(mem, 3):
        for w in range(3):
            I = [intervals.get(P, [(-np.inf, np.inf)] * 3)[w] for P in ((A, B), (B, C), (C, A))]
            sL, sU = sum(i[0] for i in I), sum(i[1] for i in I)
            nt += 1
            if not (sL <= 1e-9 and sU >= -1e-9):
                bad += 1
    check(bad == 0, "triple test")
    print(f"   closed triple test: {nt - bad}/{nt} (triple, world) instances pass")
    T_, A_, B_ = (-1, 0.0), (0, delta), (1, delta / 2)
    for P in ((T_, A_), (T_, B_), (A_, B_)):
        print(f"   intervals {P}: " + ", ".join(f"w{w+1}:[{L:+.3f},{U:+.3f}] x-diff {x[P[0]][w]-x[P[1]][w]:+.3f}"
                                         for w, (L, U) in enumerate(intervals[P])))

# (6) PP42-style own-region discount b = 1/2 at the cut world: the triple certificate
print("(6) variant: each cap discounts its own world-v penalties on its own region by b = 1/2 (PP42 Thm 4.3)")
eps = 0.3
delta = 0.95 * eps / 3
geo = Geo(sample(eps, 1_000_000, 400_000), eps)
base = base_field(geo, TH, KAP, delta)
A, A2, B = (0, delta / 2), (0, delta), (1, delta / 2)
mem = [(-1, 0.0), A, A2, B]
flds = {N: member_field(geo, base, N[0], N[1], TH, ETA, b=(0.5 if N[0] >= 0 else 1.0)) for N in mem}
advs = {N: advice(geo, *N) for N in mem}


def interval(N, M, w):
    D = advs[N] != advs[M]
    fN = (penalties(geo, flds[N], advs[M])[D] - penalties(geo, flds[N], advs[N])[D])[:, w] * flds[N][3][w]
    fM = (penalties(geo, flds[M], advs[M])[D] - penalties(geo, flds[M], advs[N])[D])[:, w] * flds[M][3][w]
    r = fM / fN
    L = np.log(r[fN < 0].max()) if (fN < 0).any() else -np.inf
    U = np.log(r[fN > 0].min()) if (fN > 0).any() else np.inf
    return L, U


for tri in ((A, A2, B), ((-1, 0.0), A, B), ((-1, 0.0), A, A2)):
    for w in range(3):
        I = [interval(*P, w) for P in ((tri[0], tri[1]), (tri[1], tri[2]), (tri[2], tri[0]))]
        sL, sU = sum(i[0] for i in I), sum(i[1] for i in I)
        okt = sL <= 1e-9 and sU >= -1e-9
        print(f"   triple {tri} world {w+1}: intervals " + ", ".join(f"[{a:+.3f},{b:+.3f}]" for a, b in I)
              + f"  sum L = {sL:+.3f}, sum U = {sU:+.3f}  -> {'pass' if okt else 'FAIL (certificate: multipliers (1,1,1) on the cycle)'}")
print("ALL PASS (sections 1-4)" if OK else "SOME CHECK FAILED")
