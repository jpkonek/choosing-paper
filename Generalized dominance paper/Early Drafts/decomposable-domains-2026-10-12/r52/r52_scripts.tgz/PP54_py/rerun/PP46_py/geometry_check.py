"""PP46 script 1 (CHECKED exact rationals for (A),(B); solid angles are float evaluations of exact cones).

(A) depth formula and union lemma bookkeeping:  for random rational g and s in [0,delta]^3,
    the union-lemma advice member(s, g) equals D_{K_s}(g) computed from K_s's vertices, and
    g in H_v(t) iff tau_v(g) < t.
(B) band cones: the three rays of H_v(t) satisfy the stated boundary equations; the class pieces
    H_v(t) ∩ M_r are computed by exact clipping; each piece's correctness pattern is listed.
(C) Gaussian measures of the pieces (exact cones, solid-angle formula) vs Monte Carlo, and
    positivity of every annulus piece (H_v(t) minus H_v(s)) ∩ M_r for s < t.
Run: python3 -I -B geometry_check.py > geometry_check.out
"""
import os, sys, random, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import numpy as np
from geom import *

random.seed(46)
OK = True


def check(cond, msg):
    global OK
    if not cond:
        OK = False
        print("FAIL:", msg)


def rr(n=30):
    return Fr(random.randint(-n, n), random.randint(1, n))


# ---------------- (A)
nA = 0
for eps in (Fr(1, 10), Fr(3, 10), Fr(1, 2)):
    delta = eps / 3 - eps / 100
    for trial in range(300):
        s = [random.choice([Fr(0), delta * Fr(random.randint(1, 50), 50)]) for _ in range(3)]
        V = Ks_verts(eps, s)
        for _ in range(40):
            if random.random() < 0.5:
                g = [rr(), rr(), rr()]
            else:  # near a plane through a vertex of M
                v = random.randrange(3)
                m = mverts(eps)[v]
                h = [rr(), rr(), rr()]
                lam = dot(m, h) / dot(m, m)
                g = [h[q] - lam * m[q] + Fr(random.randint(-4, 4), 300) * m[q] for q in range(3)]
            if any(x == 0 for x in g) or sum(g) == 0:
                continue
            if any(dot(m, g) == 0 for m in V + mverts(eps)):
                continue
            check(member(eps, s, g) == DK(V, g), f"union/depth eps={eps} s={s} g={g}")
            if T(eps, g) == 0:
                v, t = tau(eps, g)
                for tt in (delta / 3, delta):
                    inH = DK(Ks_verts(eps, [tt if q == v else 0 for q in range(3)]), g) != 0
                    check(inH == (t < tt), "tau criterion")
            nA += 1
print(f"(A) {nA} exact problems: union-lemma advice == D_K(s); H_v(t) = {{tau_v < t}}")

# ---------------- (B), (C)


def clip(poly, f, keep_pos):
    out = []
    n = len(poly)
    for i in range(n):
        P, Q = poly[i], poly[(i + 1) % n]
        fp, fq = f(P), f(Q)
        inP = fp >= 0 if keep_pos else fp <= 0
        inQ = fq >= 0 if keep_pos else fq <= 0
        if inP:
            out.append(P)
        if (fp > 0 and fq < 0) or (fp < 0 and fq > 0):
            lam = fp / (fp - fq)
            out.append([P[q] + lam * (Q[q] - P[q]) for q in range(3)])
    return out


def solid_angle(poly):
    U = [np.array([float(x) for x in p]) for p in poly]
    U = [x / np.linalg.norm(x) for x in U]
    tot = 0.0
    for i in range(1, len(U) - 1):
        a, b, c = U[0], U[i], U[i + 1]
        num = abs(np.dot(a, np.cross(b, c)))
        den = 1 + np.dot(a, b) + np.dot(b, c) + np.dot(a, c)
        tot += 2 * math.atan2(num, den)
    return tot


def pieces(eps, v, t):
    a, b, c = band_rays(eps, v, t)
    out = {}
    for signs in [(x, y, z) for x in (1, -1) for y in (1, -1) for z in (1, -1)]:
        poly = [a, b, c]
        for q in range(3):
            poly = clip(poly, lambda P, q=q: P[q], signs[q] > 0)
            if len(poly) < 3:
                break
        if len(poly) >= 3:
            om = solid_angle(poly)
            if om > 1e-15:
                g = [sum(p[q] for p in poly) / len(poly) for q in range(3)]
                r = cls(g)
                out[r] = (poly, om / (2 * math.pi))   # mu of the double cone
    return out


def pattern(v, r):
    """worlds where sigma (= +1 on the chosen half) is correct, on piece H_v ∩ M_r."""
    return [r] if r != v else [q for q in range(3) if q != v]


rng = np.random.default_rng(46)
G = rng.standard_normal((2_000_000, 3))
print("(B) boundary lines of H_v(t):  L0: c*S + eps*g_v = 0;  L_o(t): c*S + (eps-t)*g_v + t*g_o = 0  (S = g1+g2+g3)")
for eps in (Fr(1, 10), Fr(3, 10)):
    c = consts(eps)
    delta = eps / 3 - eps / 100
    for v in range(3):
        a, b, cc = band_rays(eps, v, delta)
        j, k = [o for o in range(3) if o != v]
        L0 = lambda g: c * sum(g) + eps * g[v]
        Lo = lambda g, o, t: c * sum(g) + (eps - t) * g[v] + t * g[o]
        check(L0(a) == 0 and Lo(a, j, delta) == 0 and L0(b) == 0 and Lo(b, k, delta) == 0
              and Lo(cc, j, delta) == 0 and Lo(cc, k, delta) == 0, "ray equations")
        check(sum(a) > 0 and sum(b) > 0 and sum(cc) > 0, "rays in the sigma=+1 half")
    # pieces and MC
    epsf = float(eps)
    Mv = np.array([[float(x) for x in m] for m in mverts(eps)])
    vals = G @ Mv.T
    Tg = np.where(vals.min(1) > 0, 1, np.where(vals.max(1) < 0, -1, 0))
    sil = Tg == 0
    sv = np.sign(vals)
    iso = np.full(len(G), -1)
    for v in range(3):
        o = [q for q in range(3) if q != v]
        iso[sil & (sv[:, o[0]] == sv[:, o[1]]) & (sv[:, v] == -sv[:, o[0]])] = v
    av = np.abs(vals)
    tauv = np.full(len(G), np.inf)
    for v in range(3):
        o = [q for q in range(3) if q != v]
        m = iso == v
        r = av[m, v] / np.minimum(av[m, o[0]], av[m, o[1]])
        tauv[m] = epsf * r / (1 + r)
    pos = (G > 0).sum(1)
    clsG = np.where(pos == 1, np.argmax(G > 0, 1), np.where(pos == 2, np.argmax(G < 0, 1), -1))
    for t in (delta, delta / 4):
        for v in range(3):
            P = pieces(eps, v, t)
            line = []
            for r in sorted(P):
                mu = P[r][1]
                mc = ((iso == v) & (tauv < float(t)) & (clsG == r)).mean()
                se = math.sqrt(mc / len(G))
                check(abs(mu - mc) < 5 * se + 1e-6, f"MC mismatch eps={eps} v={v} r={r}")
                line.append(f"M{r+1}[correct at {','.join(str(q+1) for q in pattern(v, r))}] mu={mu:.3e} (MC {mc:.3e})")
            check(sorted(P) == [0, 1, 2], "all three classes meet the band")
            print(f"  eps={eps} t={str(t):>7} v={v+1}: " + "; ".join(line))
    # (C) annuli
    for v in range(3):
        for (s0, t0) in ((Fr(0), delta / 8), (delta / 8, delta / 4), (delta / 2, delta), (delta * Fr(99, 100), delta)):
            Pt, Ps = pieces(eps, v, t0), (pieces(eps, v, s0) if s0 > 0 else {0: (0, 0), 1: (0, 0), 2: (0, 0)})
            for r in range(3):
                check(Pt[r][1] - Ps[r][1] > 0, f"annulus piece null eps={eps} v={v} r={r} s={s0} t={t0}")
    print(f"  eps={eps}: every annulus piece (H_v(t) minus H_v(s)) ∩ M_r has positive measure, 4 (s,t) pairs x 3 bands x 3 classes")
print("ALL PASS" if OK else "SOME CHECK FAILED")
