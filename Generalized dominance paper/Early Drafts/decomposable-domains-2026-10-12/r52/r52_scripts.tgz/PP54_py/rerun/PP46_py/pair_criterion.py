"""PP46 script 2 (CHECKED: (a), (c) exact integer arithmetic; (b) LP cross-check, floats).

Pair test for two box members N, M (both own-Bayes, CG2 at all three worlds).
On a band piece of D_NM with gain worlds C and loss worlds W (sigma correct on C, wrong on W),
with answerer weight p and silent weight q (p = lambda^ans / c^ans, q = lambda^sil / c^sil,
per world), the piece admits field values iff  exists c in C, w in W with p_c q_w > p_w q_c   (*).
Band v pieces: (v,v): C = {j,k}; (v,j): C = {j}; (v,k): C = {k}  (geometry_check.out).

(a) Exhaustive over p, q in {0,1,2,3}^3 minus 0 and all pairs of disjoint band sets (V_M, V_N)
    (bands where M, resp. N, answers and the other is silent): the pair is feasible iff
    |V_M| <= 1 and |V_N| <= 1.
(b) LP cross-check of (*) and of its Farkas certificate on random real p, q.
(c) Compatibility graph on the 8-model box and on a 27-model grid; maximal cliques through T.
Run: python3 -I -B pair_criterion.py > pair_criterion.out
"""
import itertools, random
import numpy as np
from scipy.optimize import linprog

OK = True


def check(cond, msg):
    global OK
    if not cond:
        OK = False
        print("FAIL:", msg)


def band_pieces(v):
    j, k = [o for o in range(3) if o != v]
    return [([j, k], [v]), ([j], [v, k]), ([k], [v, j])]


def piece_ok(C, W, p, q):
    return any(p[c] * q[w] > p[w] * q[c] for c in C for w in W)


def pair_ok(VM, VN, pM, pN):
    for v in VM:   # M answers, N silent
        for C, W in band_pieces(v):
            if not piece_ok(C, W, pM, pN):
                return False
    for v in VN:
        for C, W in band_pieces(v):
            if not piece_ok(C, W, pN, pM):
                return False
    return True


# (a)
vecs = [p for p in itertools.product(range(4), repeat=3) if any(p)]
subsets = [frozenset(x) for r in range(4) for x in itertools.combinations(range(3), r)]
n = 0
for VM in subsets:
    for VN in subsets:
        if VM & VN or not (VM or VN):
            continue
        feas = any(pair_ok(VM, VN, pM, pN) for pM in vecs for pN in vecs)
        check(feas == (len(VM) <= 1 and len(VN) <= 1), f"criterion VM={set(VM)} VN={set(VN)}")
        n += 1
print(f"(a) {n} band configurations x {len(vecs)**2} weight pairs: feasible iff each side answers beyond the other on <= 1 band")
# the 4-model checkpoint's bad pair: T silent, AB answers on bands 1,2
bad = [(pM, pN) for pM in vecs for pN in vecs if pair_ok({0, 1}, set(), pM, pN)]
print(f"    (T, C_(s1,s2,0)): feasible weight pairs found = {len(bad)}  (must be 0)")
check(not bad, "T vs combined cut")

# (b) LP cross-check
random.seed(1)
rng = np.random.default_rng(1)
nb = 0
for trial in range(3000):
    p = rng.random(3) * (rng.random(3) > 0.1)
    q = rng.random(3) * (rng.random(3) > 0.1)
    if not p.any() or not q.any():
        continue
    v = rng.integers(3)
    C, W = band_pieces(v)[rng.integers(3)]
    # variables x_w > 0: d_w = -x_w on C, +x_w on W.  p.d <= -1, q.d >= 1, x >= 1e-9 (scale-free)
    sgnv = np.array([-1.0 if w in C else 1.0 for w in range(3)])
    A = np.vstack([p * sgnv, -(q * sgnv)])
    res = linprog(np.zeros(3), A_ub=A, b_ub=[-1, -1], bounds=[(0, None)] * 3, method="highs")
    lp_feas = res.status == 0
    comb = piece_ok(C, W, p, q)
    check(lp_feas == comb, f"LP vs criterion p={p} q={q} C={C}")
    if not comb:
        # Farkas certificate: for any c in C with p_c > 0:  q_c*(p.d) - p_c*(q.d) = sum_{w in W} (q_c p_w - p_c q_w) x_w
        #                     + sum_{c' in C} (p_c q_c' - q_c p_c') x_c' >= 0, contradicting p.d < 0 < q.d.
        cs = [c for c in C if p[c] > 0]
        if cs:
            c = cs[0]
            coef_ok = all(q[c] * p[w] - p[c] * q[w] >= -1e-15 for w in W)
            check(coef_ok, "certificate coefficients")
        nb += 1
print(f"(b) LP agrees with (*) on all random pieces; {nb} infeasible pieces carry the explicit certificate")

# (c) compatibility graph


def diffsets(s, t):
    up = {v for v in range(3) if t[v] > s[v]}
    dn = {v for v in range(3) if t[v] < s[v]}
    return up, dn


def compatible(s, t):
    up, dn = diffsets(s, t)
    return len(up) <= 1 and len(dn) <= 1


def max_cliques(nodes):
    adj = {a: {b for b in nodes if b != a and compatible(a, b)} for a in nodes}
    out = []

    def bk(R, P, X):
        if not P and not X:
            out.append(R)
            return
        for v in list(P):
            bk(R | {v}, P & adj[v], X & adj[v])
            P = P - {v}
            X = X | {v}
    bk(set(), set(nodes), set())
    return out


box = list(itertools.product((0, 1), repeat=3))
inc = [(a, b) for a, b in itertools.combinations(box, 2) if not compatible(a, b)]
print(f"(c) 8-model box: {len(inc)} of 28 pairs incompatible:", inc)
print("    maximal compatible subfamilies:", sorted(sorted(c) for c in max_cliques(box)))
grid = list(itertools.product((0, 1, 2), repeat=3))
mc = [c for c in max_cliques(grid) if (0, 0, 0) in c]
print(f"    27-model grid {{0, d/2, d}}^3: maximal compatible subfamilies containing T: {len(mc)}; largest size {max(map(len, mc))}")
for c in sorted(mc, key=len, reverse=True)[:3]:
    print("     ", sorted(c))
star = [s for s in grid if sum(1 for x in s if x) <= 1]
check(all(compatible(a, b) for a, b in itertools.combinations(star, 2)), "star compatible")
check(all(set(c) <= set(star) for c in mc), "every T-clique lies in the star")
print("    every compatible subfamily containing T lies in the star {s : at most one s_v > 0}:", all(set(c) <= set(star) for c in mc))
print("ALL PASS" if OK else "SOME CHECK FAILED")
