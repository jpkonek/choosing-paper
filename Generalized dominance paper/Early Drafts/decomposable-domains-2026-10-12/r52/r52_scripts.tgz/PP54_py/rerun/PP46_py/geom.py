"""PP46 library: exact geometry of the multicap family (works with Fractions or floats).

M = c*1 + eps*Delta, vertices m_v = c*1 + eps*e_v, c = (1-eps)/3.
Single cut at v of size t:  K_v(t) = M ∩ {m_v <= c+eps-t};  its two new vertices
    p_{v,o}(t) = m_v + (t/eps)(m_o - m_v),   o != v.
Band:  H_v(t) = {g : sign(m_v.g) = -sign(p_{v,j}(t).g) = -sign(p_{v,k}(t).g) != 0}.
Depth: for g in Sil(T) let v = the vertex its plane isolates, r = |m_v.g| / min_{o!=v} |m_o.g|;
       tau_v(g) = eps*r/(1+r).  Then g in H_v(t)  iff  tau_v(g) < t.
Answer on the bands: sigma(g) = sign(u.g) = sign(g1+g2+g3).
"""
from fractions import Fraction as Fr


def consts(eps):
    return (1 - eps) / 3


def mverts(eps):
    c = consts(eps)
    return [[c + (eps if i == j else 0) for j in range(3)] for i in range(3)]


def pvert(eps, v, o, t):
    M = mverts(eps)
    return [M[v][q] + (t / eps) * (M[o][q] - M[v][q]) for q in range(3)]


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def cross(a, b):
    return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]


def sgn(x):
    return (x > 0) - (x < 0)


def DK(verts, g):
    vals = [dot(m, g) for m in verts]
    if min(vals) > 0:
        return 1
    if max(vals) < 0:
        return -1
    return 0


def Ks_verts(eps, s):
    """vertices of K_s (s = (s1,s2,s3), each 0 <= s_i <= delta < eps/3)."""
    M = mverts(eps)
    V = []
    for v in range(3):
        if s[v] == 0:
            V.append(M[v])
        else:
            for o in range(3):
                if o != v:
                    V.append(pvert(eps, v, o, s[v]))
    return V


def T(eps, g):
    return DK(mverts(eps), g)


def iso_vertex(eps, g):
    """for g in Sil(T): the vertex m_v whose sign differs from the other two (None if not unique)."""
    vals = [sgn(dot(m, g)) for m in mverts(eps)]
    for v in range(3):
        o = [vals[q] for q in range(3) if q != v]
        if vals[v] != 0 and o[0] == o[1] == -vals[v]:
            return v
    return None


def tau(eps, g):
    v = iso_vertex(eps, g)
    M = mverts(eps)
    a = abs(dot(M[v], g))
    b = min(abs(dot(M[o], g)) for o in range(3) if o != v)
    r = a / b
    return v, eps * r / (1 + r)


def sigma(g):
    return sgn(sum(g))


def cls(g):
    pos = sum(1 for x in g if x > 0)
    if pos == 1:
        return [i for i in range(3) if g[i] > 0][0]
    if pos == 2:
        return [i for i in range(3) if g[i] < 0][0]
    return -1


def member(eps, s, g):
    """advice of C_s by the union lemma: T's answer, else sigma on the band of the isolated vertex if tau < s_v."""
    tg = T(eps, g)
    if tg != 0:
        return tg
    v = iso_vertex(eps, g)
    if v is None:
        return 0
    _, t = tau(eps, g)
    return sigma(g) if t < s[v] else 0


def band_rays(eps, v, t):
    """three generating rays of the sigma=+1 half of the band cone H_v(t) (a, b on the plane m_v^perp)."""
    M = mverts(eps)
    j, k = [o for o in range(3) if o != v]
    pj, pk = pvert(eps, v, j, t), pvert(eps, v, k, t)
    a = cross(M[v], M[j])          # on m_v^perp and p_{v,j}^perp, for every t
    if dot(pk, a) < 0:
        a = [-x for x in a]
    b = cross(M[v], M[k])
    if dot(pj, b) < 0:
        b = [-x for x in b]
    cc = cross(pj, pk)
    if dot(M[v], cc) > 0:
        cc = [-x for x in cc]
    return a, b, cc
