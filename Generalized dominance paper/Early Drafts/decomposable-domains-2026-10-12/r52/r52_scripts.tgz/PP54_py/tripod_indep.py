"""PP54 referee script 1 (CHECKED, exact rationals). Independent re-implementation of PP45 Thm 5.1.

Independence from the authors' code:
  * band points are generated as planes through two random edge points (cross product), not by
    PP45's corner_point formula;
  * every member's advice is computed from the actual vertices of its credal set K_{i,t}
    (no union lemma, no threshold rule);
  * the depth tau(g) is recomputed from the edge crossings of g's plane.
Checks, for T and caps C_{i,t} on a grid of t at all three vertices:
  (1) the threshold rule: C_{i,t} answers sigma on band i iff tau < t, silent on other bands;
  (2) strict own u-Bayes over all four advice values (Lemma 5.2), with the margin (3/8)|n.mu|;
  (3) strict CG2 pointwise with the GLOBAL constants 1/mu, for every ordered pair, every world;
  (4) the single field U (magnitudes |n_w|) is a witness: c^s(l^s(b)-l^s(a)) <= U(b)-U(a) for the
      member's own advice a and b in {sigma, S}; and every member is the U-Bayes model at weight mu^s;
  (5) continuity at the switch t = tau(g).
Run: python3 -I -B tripod_indep.py > tripod_indep.out
"""
from fractions import Fraction as Fr
import random

random.seed(5401)
CC = Fr(1, 4)
FAIL = []


def chk(c, m):
    if not c:
        FAIL.append(m)


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def cross(a, b):
    return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]


def Mverts(eps):
    c = (1 - eps) / 3
    return [[c + (eps if j == i else 0) for j in range(3)] for i in range(3)]


def cap_verts(eps, i, t):
    M = Mverts(eps)
    if t == 0:
        return M
    out = []
    for j in range(3):
        if j != i:
            out.append(M[j])
            out.append([M[i][x] + (t / eps) * (M[j][x] - M[i][x]) for x in range(3)])
    return out


def DK(V, g):
    v = [dot(p, g) for p in V]
    if min(v) > 0:
        return 1
    if max(v) < 0:
        return -1
    return 0


def sample_band_point(eps, i, depth_max):
    """plane through 0 and two points on edges m_i->m_j, m_i->m_k at fractions lj, lk."""
    M = Mverts(eps)
    j, k = [w for w in range(3) if w != i]
    lj = Fr(random.randint(1, 999), 1000) * depth_max / eps
    lk = lj * Fr(random.randint(1, 1000), 1000) ** random.randint(1, 3)
    if random.random() < 0.5:
        lj, lk = lk, lj
    pj = [M[i][x] + lj * (M[j][x] - M[i][x]) for x in range(3)]
    pk = [M[i][x] + lk * (M[k][x] - M[i][x]) for x in range(3)]
    g = cross(pj, pk)
    if sum(g) < 0:
        g = [-x for x in g]
    return g


def depth(eps, g):
    """(i, tau) if T silent and g's plane cuts off exactly one vertex; recomputed from edge crossings."""
    M = Mverts(eps)
    vals = [dot(m, g) for m in M]
    if min(vals) > 0 or max(vals) < 0:
        return None
    s = 1 if sum(g) > 0 else -1
    bad = [w for w in range(3) if s * vals[w] < 0]
    if len(bad) != 1:
        return None
    i = bad[0]
    lam = [vals[i] / (vals[i] - vals[j]) for j in range(3) if j != i]
    return i, eps * max(lam)


def nhat(i, tau, W, delta):
    phi = tau / (2 * delta)
    q, z = 1 - phi, phi / 2
    j, k = [w for w in range(3) if w != i]
    n = [None] * 3
    n[i] = Fr(1)
    if W == {i}:
        n[j] = n[k] = -q / 2
    elif W == {i, k}:   # sigma right only at j
        n[j], n[k] = -(q + z), z
    elif W == {i, j}:   # right only at k
        n[k], n[j] = -(q + z), z
    else:
        raise ValueError(W)
    return n


def field(n, mu_s, says_sigma, W):
    """returns dict advice -> per-world penalty (|g| factor dropped: fields are 1-homogeneous)."""
    mh = abs(dot(n, mu_s))
    H = []
    for w in range(3):
        wrong = w in W
        if says_sigma:
            H.append(1 + CC * mh if wrong else 1 - CC * mh)
        else:
            H.append(1 - CC * mh if wrong else 1 + CC * mh)
    m = [abs(n[w]) * mu_s[w] * H[w] for w in range(3)]
    Lam = sum(m)
    L = {a: [None] * 3 for a in ("sig", "S", "-sig", "C")}
    for w in range(3):
        if w in W:
            L["-sig"][w], L["S"][w], L["sig"][w], L["C"][w] = 0, m[w], 2 * m[w], 2 * m[w] + Lam
        else:
            L["sig"][w], L["S"][w], L["-sig"][w], L["C"][w] = 0, m[w], m[w] + 2 * Lam, m[w] + 3 * Lam
    return L, mh


n_checks = 0
for eps in (Fr(1, 10), Fr(3, 10), Fr(1, 2)):
    for delta in (eps / 4, eps * Fr(33, 100)):     # second value close to the bound eps/3
        grid = [delta * Fr(k, 6) for k in range(1, 7)]
        members = [("T", None, Fr(0))] + [("C", v, t) for v in range(3) for t in grid]
        mu = {}
        for mb in members:
            m = [Fr(1)] * 3
            if mb[1] is not None:
                m[mb[1]] = 1 - mb[2] / (2 * delta)
            mu[mb] = m
        for trial in range(150):
            i = trial % 3
            g = sample_band_point(eps, i, delta)
            d = depth(eps, g)
            if d is None or d[1] >= delta:
                continue
            bi, tau = d
            chk(bi == i, "band index")
            W = {w for w in range(3) if g[w] < 0}      # sigma = + here
            n = nhat(bi, tau, W, delta)
            adv, fld = {}, {}
            for mb in members:
                V = Mverts(eps) if mb[0] == "T" else cap_verts(eps, mb[1], mb[2])
                a = DK(V, g)
                chk(a in (0, 1), "never -sigma on a band")
                says = (a == 1)
                rule = (mb[0] == "C" and mb[1] == bi and tau < mb[2])
                if tau != mb[2]:
                    chk(says == rule, f"threshold rule {mb}")
                adv[mb] = says
                L, mh = field(n, mu[mb], says, W)
                fld[mb] = (L, mh)
                if mh == 0:
                    continue
                cost = {x: sum(L[x]) for x in L}              # u-weighted cost times 3
                own = "sig" if says else "S"
                others = [cost[x] for x in cost if x != own]
                chk(cost[own] < min(others), f"own Bayes {mb}")
                chk(abs(cost["sig"] - cost["S"]) >= Fr(3, 8) * mh, "margin")
                # U-Bayes at weight mu^s with U_w(sig)-U_w(S) = n_w
                chk((dot(n, mu[mb]) < 0) == says, "U-Bayes at mu^s")
                # witness inequality on the member's own moves between sigma and S
                for w in range(3):
                    a0, b0 = own, ("S" if says else "sig")
                    lhs = (L[b0][w] - L[a0][w]) / mu[mb][w]
                    rhs = (n[w] if b0 == "sig" else -n[w])
                    chk(lhs <= rhs, "witness")
                n_checks += 1
            for N in members:
                for Mm in members:
                    if N == Mm or adv[N] == adv[Mm] or fld[N][1] == 0 or fld[Mm][1] == 0:
                        continue
                    aN = "sig" if adv[N] else "S"
                    aM = "sig" if adv[Mm] else "S"
                    for w in range(3):
                        fN = fld[N][0][aM][w] - fld[N][0][aN][w]
                        fM = fld[Mm][0][aM][w] - fld[Mm][0][aN][w]
                        chk(fN / mu[N][w] < fM / mu[Mm][w], f"strict CG2 {N} {Mm} w{w}")
                    n_checks += 1
            # continuity at the switch
            h = Fr(1, 10 ** 7)
            if h < tau < delta - h:
                L1, _ = field(n, [1 - (tau + h) / (2 * delta) if w == bi else Fr(1) for w in range(3)], True, W)
                L0, _ = field(n, [1 - (tau - h) / (2 * delta) if w == bi else Fr(1) for w in range(3)], False, W)
                diff = max(abs(L1[x][w] - L0[x][w]) for x in L1 for w in range(3))
                chk(diff < 1000 * h, "switch continuity")
                n_checks += 1
print(f"tripod (independent): {n_checks} exact checks; failures: {len(FAIL)}")
for f in FAIL[:10]:
    print("FAIL", f)
print("ALL PASS" if not FAIL else "SOME FAIL")
