# PP49 exact checks (Fractions only).
# (A) three-valued posterior triples exist (so PP47 Thm 4.1's two-valued test does not cover the whole simplex);
#     pairwise-overlapping posteriors never give opposite answers.
# (B) pair-ordering theorem at boundary indices, extended reals, common-zero coordinates removed.
from fractions import Fraction as F
import random, itertools
random.seed(49)
eps = F(3,10); c = (1-eps)/3
M = [[c+eps if j==i else c for j in range(3)] for i in range(3)]   # vertices of T1

def T1(h):
    vals = [sum(m[j]*h[j] for j in range(3)) for m in M]
    if min(vals) > 0: return +1
    if max(vals) < 0: return -1
    return 0
def margin(h):  # distance of the decision from a switch (all three vertex values nonzero => locally constant)
    return min(abs(sum(m[j]*h[j] for j in range(3))) for m in M)
def C(a, g): return T1([a[j]*g[j] for j in range(3)])
def rank(adv, g, w):
    if adv == 0: return 1
    return 0 if adv*g[w] > 0 else 2
fails = 0
# (A1) explicit three-valued triple
u = [F(1,3)]*3; b = [F(8,10),F(1,10),F(1,10)]; cc = [F(1,10),F(8,10),F(1,10)]
g = [F(1), F(-1), F(1,10)]
adv = (C(u,g), C(b,g), C(cc,g))
ok = sorted(adv) == [-1,0,1] and all(margin([a[j]*g[j] for j in range(3)])>0 for a in (u,b,cc))
print("(A1) advice of (T1, C_b, C_c) at g=(1,-1,1/10):", adv, "strict margins:", ok); fails += (not ok)
# (A2) nearby indices: posteriors overlap (contain a common point) => never opposite answers.
def common_point(a, bb):
    # M_a and M_b both contain normalise(a*m) ... test: is there p in M with a*p ∝ b*q, q in M?  sufficient check: u-image
    pa = [a[j]*u[j] for j in range(3)]; s = sum(pa); pa = [x/s for x in pa]
    # pa in M_b iff pa ∝ b*q with q in M iff q ∝ pa/b in M
    q = [pa[j]/bb[j] for j in range(3)]; s = sum(q); q = [x/s for x in q]
    return all(x >= c for x in q)   # M = {q : q_i >= c}
cnt = 0; opp = 0
for _ in range(3000):
    a = [F(random.randint(900,1100)) for _ in range(3)]; s = sum(a); a = [x/s for x in a]
    bb = [F(random.randint(900,1100)) for _ in range(3)]; s = sum(bb); bb = [x/s for x in bb]
    if not common_point(a, bb): continue
    cnt += 1
    gg = [F(random.randint(-1000,1000), 1000) for _ in range(3)]
    if C(a,gg)*C(bb,gg) == -1: opp += 1
print("(A2) overlapping nearby pairs tested:", cnt, " opposite answers found:", opp); fails += (opp>0 or cnt<1000)
# (B) boundary pair ordering
def rand_index(kind):
    if kind == 'int':
        a = [F(random.randint(1,50)) for _ in range(3)]
    elif kind == 'edge':
        a = [F(random.randint(1,50)) for _ in range(3)]; a[random.randrange(3)] = F(0)
    else:
        a = [F(0)]*3; a[random.randrange(3)] = F(1)
    s = sum(a); return [x/s for x in a]
INF = None
def ratio(bi, ai):
    if ai == 0: return 'inf' if bi > 0 else None
    return bi/ai
def lt(x, y):  # extended-real x < y, 'inf' is +infinity
    if x == 'inf': return False
    if y == 'inf': return True
    return x < y
ndis = 0; nbad = 0; kinds = ['int','edge','vert']
for _ in range(40000):
    a = rand_index(random.choice(kinds)); bb = rand_index(random.choice(kinds))
    gg = [F(random.randint(-1000,1000), 1000) for _ in range(3)]
    if any(x == 0 for x in gg): continue
    ca, cb = C(a,gg), C(bb,gg)
    if ca == cb: continue
    ndis += 1
    Z = {i for i in range(3) if a[i] == 0 and bb[i] == 0}
    W = [i for i in range(3) if i not in Z and rank(cb,gg,i) > rank(ca,gg,i)]
    R = [i for i in range(3) if i not in Z and rank(cb,gg,i) < rank(ca,gg,i)]
    if not W or not R: nbad += 1; continue
    rW = [ratio(bb[i],a[i]) for i in W]; rR = [ratio(bb[i],a[i]) for i in R]
    mn = rW[0]
    for x in rW[1:]:
        if lt(x, mn): mn = x
    mx = rR[0]
    for x in rR[1:]:
        if lt(mx, x): mx = x
    if not lt(mn, mx): nbad += 1
print("(B) boundary/interior pairs: disagreements", ndis, " violations", nbad); fails += (nbad>0 or ndis<5000)
print("ALL PASS" if fails == 0 else "FAILURES: %d" % fails)
