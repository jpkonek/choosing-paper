import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from witness_search import search
eps = Fr(3,10)
cfg = {'A':[1,1,1],'B':[Fr(11,10),1,Fr(99,100)],'C':[Fr(12,10),Fr(11,10),1],'D':[1,Fr(11,10),Fr(101,100)]}
print('no cycle demand, margin 1e-3:', search(eps, cfg, 0, den=4, margin=1e-3, defect=-100, glob_other=False, tlim=120)[1], flush=True)
print('no cycle demand, margin 0:', search(eps, cfg, 0, den=4, margin=0.0, defect=-100, glob_other=False, tlim=120)[1], flush=True)
