"""PP50 refinement test (proposal by MILP; output verified exactly by verify_exact.py):
an n x n grid of posterior models in the quadrilateral spanned at T, side-profile ansatz,
lambda = u, all pairs strict CG2, all triples (TC), and NO global prices around the corner 4-cycle."""
import sys, os, json; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import explore_ansatz as E
from pp50_lib import enumerate_types, posterior
n = int(sys.argv[1]) if len(sys.argv) > 1 else 3
tlim = float(sys.argv[2]) if len(sys.argv) > 2 else 600
eps = Fr(3,10)
d1 = [Fr(1,10), 0, Fr(-1,100)]; d2 = [0, Fr(1,10), Fr(1,100)]
cfg = {}
for i in range(n):
    for j in range(n):
        s, t = Fr(i, n-1), Fr(j, n-1)
        cfg['P%d%d' % (i, j)] = [1 + s*d1[q] + t*d2[q] for q in range(3)]
names = sorted(cfg); E.set_models(names)
models = {k: posterior(v) for k, v in cfg.items()}
types = enumerate_types(eps, models)
print('models', len(names), 'types', len(types), 'three-valued', sum(1 for t in types if t[0]=='THREE'), flush=True)
m = n-1
cyc = [('P00','P%d0'%m), ('P%d0'%m,'P%d%d'%(m,m)), ('P%d%d'%(m,m),'P0%d'%m), ('P0%d'%m,'P00')]
ANS = (sys.argv[3] == 'ansatz') if len(sys.argv) > 3 else True
out, msg = E.solve(types, cyc, 0, ansatz=ANS, obj=None, K=14, humble_other=ANS, glob_other=ANS, tlim=tlim)
print(msg, flush=True)
if out:
    sol, tl = out
    rows = []
    for ti,(H,S,Wr) in enumerate(tl):
        y = {N: [int(round(sol[('Phi',N,v)] + sol.get(('J',ti,'h' if N in H else 's',v),0))) if ANS else int(round(sol[('y',ti,N,v)])) for v in range(3)] for N in names}
        rows.append({'H':sorted(H),'S':sorted(S),'Wr':sorted(Wr),'y':y})
    J = {'eps':'3/10','models':{k:[str(x) for x in v] for k,v in cfg.items()},
         'lambda':{k:['1/3']*3 for k in names},'base':'3','target_world':1,'types':rows}
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'grid%d_fields.json' % n)
    json.dump(J, open(p,'w'))
    print('saved', p)
