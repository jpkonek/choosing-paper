"""PP50: kink certificates on the tripod through the checkpoint corners: u plus points t*(a_N - 1) + 1,
t in {1/3, 2/3, 1}, on the three rays u->B, u->C, u->D of checkpoint_fields.json (10 models, 120 triples)."""
import sys, os, json; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from itertools import combinations
from kink_scan_grid import kink
from pp50_lib import posterior
J = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'checkpoint_fields.json')))
cfg = {'U': [Fr(1)] * 3}
for N in 'BCD':
    a = [Fr(x) for x in J['models'][N]]
    for k in (1, 2, 3):
        cfg['%s%d' % (N, k)] = [1 + Fr(k, 3) * (x - 1) for x in a]
models = {k: posterior(v) for k, v in cfg.items()}
found = 0; tot = 0
for tr in combinations(sorted(models), 3):
    tot += 1
    k = kink({N: models[N] for N in tr})
    if k:
        found += 1; print('kink certificate:', tr, k, flush=True)
print('triples:', tot, ' with kink certificate:', found)
