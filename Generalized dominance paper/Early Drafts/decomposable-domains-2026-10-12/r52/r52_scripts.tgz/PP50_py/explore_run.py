import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from explore_ansatz import solve
from pp50_lib import enumerate_types, posterior
eps = Fr(3,10)
cfg = {'A':[1,1,1],'B':[Fr(11,10),1,Fr(99,100)],'C':[Fr(12,10),Fr(11,10),1],'D':[1,Fr(11,10),Fr(101,100)]}
models = {k: posterior(v) for k,v in cfg.items()}
types = enumerate_types(eps, models)
cyc = [('A','B'),('B','C'),('C','D'),('D','A')]
for ans in (False, True):
    for w in range(3):
        out, msg = solve(types, cyc, w, ansatz=ans, obj=None)
        print('ansatz',ans,'world',w+1, msg if out is None else 'FEASIBLE '+msg, flush=True)
