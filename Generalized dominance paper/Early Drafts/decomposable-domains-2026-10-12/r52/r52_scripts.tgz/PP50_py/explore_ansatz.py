"""Exploration (proposal only): MILP with lambda = u, integer logs (base 3), optional
side-profile ansatz y^N_v(tau) = Phi^N_v + J_v(tau, side(N)), optional global prices at worlds != w."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from fractions import Fraction as Fr
from itertools import combinations
from scipy.optimize import milp, LinearConstraint, Bounds
from pp50_lib import enumerate_types, posterior
MODELS = ['A','B','C','D']; PAIRS = list(combinations(MODELS,2)); TRIPLES = list(combinations(MODELS,3))
def set_models(names):
    global MODELS, PAIRS, TRIPLES
    MODELS[:] = list(names); PAIRS[:] = list(combinations(MODELS,2)); TRIPLES[:] = list(combinations(MODELS,3))


def solve(types, cycle, wcyc, ansatz=False, glob_other=True, K=12, obj='l1', BIG=60, humble_other=False, tlim=300, per_edge=False):
    tl = [t for t in types if t[0] != 'THREE']
    idx = {}; integ = set(); rows = []
    def var(n, integer=False):
        if n not in idx: idx[n] = len(idx)
        if integer: integ.add(idx[n])
        return idx[n]
    def add(c, lo, hi): rows.append((c, lo, hi))
    def yv(ti, N, v):
        if not ansatz:
            return {var(('y',ti,N,v),True):1}
        side = 'h' if N in tl[ti][0] else 's'
        return {var(('Phi',N,v),True):1, var(('J',ti,side,v),True):1}
    def comb(*ds):
        out = {}
        for s, d in ds:
            for k, c in d.items(): out[k] = out.get(k,0) + s*c
        return out
    for ti,(H,S,Wr) in enumerate(tl):
        Rt = [v for v in range(3) if v not in Wr]; Wl = sorted(Wr)
        for N in MODELS:
            good = Rt if N in H else Wl; bad = Wl if N in H else Rt
            bs = []
            for r in good:
                b = var(('b',ti,N,r),True); bs.append(b)
                for v in bad:
                    c = comb((1,yv(ti,N,r)),(-1,yv(ti,N,v))); c[b] = c.get(b,0) - BIG
                    add(c, 1 - BIG, np.inf)
            add({b:1 for b in bs},1,1)
        if humble_other and ansatz:
            for v in range(3):
                if v == wcyc: continue
                sg = 1 if v in Wr else -1   # e_v = sg*(J_h - J_s) >= 1
                add({var(('J',ti,'h',v),True): sg, var(('J',ti,'s',v),True): -sg}, 1, np.inf)
        for (X,Y) in PAIRS:
            if (X in H) == (Y in H): continue
            for v in range(3):
                Xerr = (X in H) == (v in Wr)
                rho = comb((1,yv(ti,Y,v)),(-1,yv(ti,X,v)))
                if Xerr: c = dict(rho); c[var(('Lo',X,Y,v))] = -1; add(c,-np.inf,0)
                else:    c = dict(rho); c[var(('Hi',X,Y,v))] = -1; add(c,0,np.inf)
    for (X,Y) in PAIRS:
        for v in range(3):
            if ('Lo',X,Y,v) in idx and ('Hi',X,Y,v) in idx:
                add({idx[('Hi',X,Y,v)]:1, idx[('Lo',X,Y,v)]:-1}, 1, np.inf)
    groups = [(tr,v) for tr in TRIPLES for v in range(3)]
    if glob_other:
        groups += [(tuple(MODELS),v) for v in range(3) if v != wcyc]
    for tr,v in groups:
        for (X,Y) in combinations(tr,2):
            kx = {var(('x',tr,X,v)):1, var(('x',tr,Y,v)):-1}
            if ('Lo',X,Y,v) in idx:
                c = dict(kx); c[idx[('Lo',X,Y,v)]] = -1; add(c, 0.5, np.inf)
            if ('Hi',X,Y,v) in idx:
                c = dict(kx); c[idx[('Hi',X,Y,v)]] = -1; add(c, -np.inf, -0.5)
    for ei,(X,Y) in enumerate(cycle):
        cands = [ti for ti,(H,S,Wr) in enumerate(tl) if (X in H)!=(Y in H) and ((Y in H)==(wcyc in Wr))]
        if not cands: return None, 'edge %s%s has no Y-err type' % (X,Y)
        bs = []
        for ti in cands:
            b = var(('pin',ei,ti),True); bs.append(b)
            c = comb((1,yv(ti,Y,wcyc)),(-1,yv(ti,X,wcyc))); c[var(('U',ei))] = -1; c[b] = BIG
            add(c,-np.inf,BIG)
        add({b:1 for b in bs},1,1)
    if per_edge:
        for ei in range(len(cycle)): add({idx[('U',ei)]:1}, -np.inf, -1)
    else:
        add({idx[('U',ei)]:1 for ei in range(len(cycle))}, -np.inf, -1)
    base = [k for k in idx if k[0] in ('y','Phi','J')]
    if obj == 'l1':
        for k in base:
            a = var(('abs',k)); add({a:1, idx[k]:-1},0,np.inf); add({a:1, idx[k]:1},0,np.inf)
    n = len(idx)
    A = np.zeros((len(rows),n)); lo = np.array([r[1] for r in rows],float); hi = np.array([r[2] for r in rows],float)
    for i,(c,_,_) in enumerate(rows):
        for j,v in c.items(): A[i,j] += v
    integrality = np.zeros(n); lb = -K*np.ones(n); ub = K*np.ones(n)
    for j in integ: integrality[j] = 1
    for k,j in idx.items():
        if k[0] in ('b','pin'): lb[j]=0; ub[j]=1
        if k[0] in ('Lo','Hi','x','U'): lb[j] = -4*K; ub[j] = 4*K
        if k[0] == 'abs': lb[j]=0; ub[j]=K
    cvec = np.zeros(n)
    if obj == 'l1':
        for k,j in idx.items():
            if k[0]=='abs': cvec[j]=1
    res = milp(cvec, constraints=LinearConstraint(A,lo,hi), integrality=integrality, bounds=Bounds(lb,ub), options={'time_limit':tlim})
    if res.x is None: return None, res.message
    return ({k: res.x[j] for k,j in idx.items()}, tl), res.message

if __name__ == '__main__':
    eps = Fr(3,10)
    cfg = {'A':[1,1,1],'B':[Fr(11,10),1,Fr(99,100)],'C':[Fr(12,10),Fr(11,10),1],'D':[1,Fr(11,10),Fr(101,100)]}
    models = {k: posterior(v) for k,v in cfg.items()}
    types = enumerate_types(eps, models)
    cyc = [('A','B'),('B','C'),('C','D'),('D','A')]
    for ans in (False, True):
        for w in range(3):
            out, msg = solve(types, cyc, w, ansatz=ans)
            print('ansatz',ans,'world',w+1, msg if out is None else 'FEASIBLE '+msg)
