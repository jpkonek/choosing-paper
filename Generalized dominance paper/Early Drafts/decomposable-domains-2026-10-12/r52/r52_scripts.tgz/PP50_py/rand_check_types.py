import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import random
from fractions import Fraction as Fr
from pp50_lib import *
eps = Fr(3,10)
configs = {
 'square': {'A':[1,1,1],'B':[Fr(11,10),1,1],'C':[Fr(11,10),Fr(11,10),1],'D':[1,Fr(11,10),1]},
 'generic': {'A':[1,1,1],'B':[Fr(11,10),1,Fr(99,100)],'C':[Fr(12,10),Fr(11,10),1],'D':[1,Fr(11,10),Fr(101,100)]},
}
random.seed(1)
for name, cfg in configs.items():
    models = {k: posterior(v) for k, v in cfg.items()}
    ty = enumerate_types(eps, models)
    seen = set()
    for _ in range(200000):
        g = [Fr(random.randint(-10**6,10**6), 10**6) for _ in range(3)]
        t = type_of(eps, models, g)
        if t is not None: seen.add(t)
    print(name, 'enumerated', len(ty), 'sampled', len(seen), 'sampled-but-not-enumerated', len(seen - set(ty)))
