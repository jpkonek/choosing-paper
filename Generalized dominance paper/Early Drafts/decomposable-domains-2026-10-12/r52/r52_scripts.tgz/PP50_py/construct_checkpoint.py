"""PP50 construction (proposal by MILP; the output table is verified exactly by verify_exact.py).
Side-profile ansatz: m^N_v(tau) = 3^(Phi^N_v + J_v(tau, side of N)), lambda = u for all four models,
humble (e_v >= 1) at the two worlds other than the target world, L1-small integer exponents."""
import sys, os, json; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from explore_ansatz import solve
from pp50_lib import enumerate_types, posterior
eps = Fr(3,10)
cfg = {'A':[1,1,1],'B':[Fr(11,10),1,Fr(99,100)],'C':[Fr(12,10),Fr(11,10),1],'D':[1,Fr(11,10),Fr(101,100)]}
w = 0
models = {k: posterior(v) for k,v in cfg.items()}
types = enumerate_types(eps, models)
cyc = [('A','B'),('B','C'),('C','D'),('D','A')]
out, msg = solve(types, cyc, w, ansatz=True, obj='l1', K=10, humble_other=True, tlim=float(sys.argv[1]) if len(sys.argv)>1 else 240)
print(msg)
sol, tl = out
rows = []
for ti,(H,S,Wr) in enumerate(tl):
    y = {}
    for N in 'ABCD':
        side = 'h' if N in H else 's'
        y[N] = [int(round(sol[('Phi',N,v)] + sol.get(('J',ti,side,v),0))) for v in range(3)]
    rows.append({'H':sorted(H),'S':sorted(S),'Wr':sorted(Wr),'y':y,
                 'Jh':[int(round(sol.get(('J',ti,'h',v),0))) for v in range(3)],
                 'Js':[int(round(sol.get(('J',ti,'s',v),0))) for v in range(3)],
                 'pins':[ '%s%s'%cyc[ei] for ei in range(4) if sol.get(('pin',ei,ti),0)>0.5]})
J = {'eps':'3/10','models':{k:[str(x) for x in v] for k,v in cfg.items()},
     'lambda':{k:['1/3']*3 for k in 'ABCD'},'base':'3','target_world':w+1,
     'Phi':{N:[int(round(sol[('Phi',N,v)])) for v in range(3)] for N in 'ABCD'},
     'types':rows}
json.dump(J, open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'checkpoint_fields.json'),'w'), indent=1)
print('saved', len(rows), 'types; L1 =', sum(abs(x) for r in rows for N in 'ABCD' for x in r['y'][N]))
