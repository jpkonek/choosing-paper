"""PP50 (CHECKED, exact): the PP51 kink triple is stable under (i) moving the base point, (ii) perturbing the
shape, and (iii) shrinking towards the base point, uniformly on a box.

Parameters: base a0 = (1+x1, 1+x2, 1); shape perturbations p = (p1,p2,0), q = (q1,q2,0); scale t in (0,1].
  A = a0,  B(t) = a0 * (1 + t (beta + p - 1)),  D(t) = a0 * (1 + t (delta + q - 1)),
  beta = 3*(406,421,373)/1200, delta = 3*(406,373,421)/1200   (unnormalised likelihoods; C_a is scale-free).
For each of the 220 determinants of triples among the 12 normals {m_j*A, m_j*B, m_j*D} U {e_1,e_2,e_3}:
  P(t) is a polynomial; Q(x) = (1+x)^3 P(1/(1+x)).  We check that every coefficient of Q, as a polynomial in
  (x1,x2,p1,p2,q1,q2), has constant nonzero sign (or is identically 0) on the box |.| <= r, by the bound
  |c(v) - c(0)| <= sum_{nonconstant monomials} |coef| r^deg < |c(0)|, and that Q has no sign change at the
  centre.  Then no determinant vanishes for t in (0,1] anywhere in the box (Descartes; Q(0) = P(1)), so the
  oriented matroid, the cells and the type set are those of the PP51 instance (kink_check.out).
"""
import sys
from fractions import Fraction as Fr
import sympy as sp
from itertools import combinations
r = Fr(sys.argv[1]) if len(sys.argv) > 1 else Fr(1, 100000)
T1 = Fr(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[2] != '-v' else Fr(1, 5)
x1, x2, p1, p2, q1, q2, t, X = sp.symbols('x1 x2 p1 p2 q1 q2 t X')
V = [x1, x2, p1, p2, q1, q2]
eps = sp.Rational(3, 10); c = (1 - eps) / 3
M = [[c + (eps if i == j else 0) for j in range(3)] for i in range(3)]
beta = [sp.Rational(3 * 406, 1200), sp.Rational(3 * 421, 1200), sp.Rational(3 * 373, 1200)]
delta = [sp.Rational(3 * 406, 1200), sp.Rational(3 * 373, 1200), sp.Rational(3 * 421, 1200)]
a0 = [1 + x1, 1 + x2, sp.Integer(1)]
pv = [p1, p2, 0]; qv = [q1, q2, 0]
A = a0
tt = sp.Rational(T1.numerator, T1.denominator) * t   # t in (0,1] <-> scale tt in (0, T1]
B = [a0[i] * (1 + tt * (beta[i] + pv[i] - 1)) for i in range(3)]
D = [a0[i] * (1 + tt * (delta[i] + qv[i] - 1)) for i in range(3)]
vecs = []
for N in (A, B, D):
    for j in range(3):
        vecs.append([M[j][i] * N[i] for i in range(3)])
for i in range(3):
    vecs.append([sp.Integer(1 if k == i else 0) for k in range(3)])
bad = 0; zero = 0; n = 0
for u, v, w in combinations(vecs, 3):
    n += 1
    P = sp.expand(sp.Matrix([u, v, w]).det())
    if P == 0:
        zero += 1; continue
    Q = sp.expand(sp.together((1 + X) ** 3 * P.subs(t, 1 / (1 + X))))
    Q = sp.Poly(sp.cancel(Q), X)
    signs = []
    ok = True
    for ck in Q.all_coeffs():
        ck = sp.Poly(sp.expand(ck), *V)
        c0 = Fr(str(ck.coeff_monomial(1)))
        rest = Fr(0)
        for mono, coef in ck.terms():
            if sum(mono) == 0:
                continue
            rest += abs(Fr(str(coef))) * r ** sum(mono)
        if c0 == 0:
            if rest != 0:
                ok = False
            continue
        if rest >= abs(c0):
            ok = False
        signs.append(c0 > 0)
    changes = sum(1 for i in range(len(signs) - 1) if signs[i] != signs[i + 1])
    if not ok or changes > 0 or not signs:
        bad += 1
        if '-v' in sys.argv:
            print('  uncertified: ok=%s changes=%d P(t) at centre = %s' % (ok, changes, sp.factor(P.subs({x1:0,x2:0,p1:0,p2:0,q1:0,q2:0}))))
print('scale range (0, %s]; box radius r =' % T1, r, '; determinants:', n, ' identically zero:', zero, ' not certified:', bad)
print('ALL PASS' if bad == 0 else 'NOT CERTIFIED AT THIS r')
