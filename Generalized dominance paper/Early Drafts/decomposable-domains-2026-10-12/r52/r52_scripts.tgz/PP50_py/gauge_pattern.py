"""PP50: gauge transformation (CHECKED by re-running verify_exact on the transformed table).
Rescaling model N's world-w field by t_N and its weight lambda^N_w by 1/t_N leaves every Bayes comparison
unchanged and shifts every world-w interval for kappa_XY = c_X/c_Y by the factor t_Y/t_X.  Applied to the
checkpoint table (exponents first multiplied by 4) it produces the audit's pattern: each consecutive
difference x_Y - x_X of the 4-cycle is forced to be >= 1 (log_3 units)."""
import sys, os, json; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
here = os.path.dirname(os.path.abspath(__file__))
J = json.load(open(os.path.join(here, 'checkpoint_fields.json')))
w = J['target_world'] - 1
# upper bounds (log3) of k_XY = x_X - x_Y on the cycle edges, from the table
def hi(X, Y, rows):
    vals = []
    for r in rows:
        H = set(r['H'])
        if (X in H) == (Y in H): continue
        Yerr = (Y in H) == (w in r['Wr'])
        if Yerr: vals.append(r['y'][Y][w] - r['y'][X][w])
    return min(vals)
cyc = [('A','B'),('B','C'),('C','D'),('D','A')]
for r in J['types']:
    for N in 'ABCD': r['y'][N] = [4*e for e in r['y'][N]]
H0 = [hi(X, Y, J['types']) for X, Y in cyc]
print('cycle upper bounds after x4:', H0, 'sum', sum(H0))
D = -sum(H0)   # defect, = 4 here
assert D >= 4
phi = {'A': 0}
# want hi'_XY = hi_XY + phi_Y - phi_X = -1 on the first three edges (the fourth then has <= -1)
phi['B'] = -1 - H0[0] + phi['A']; phi['C'] = -1 - H0[1] + phi['B']; phi['D'] = -1 - H0[2] + phi['C']
for r in J['types']:
    for N in 'ABCD': r['y'][N][w] += phi[N]
lam = {}
for N in 'ABCD':
    l = [Fr(1), Fr(1), Fr(1)]; l[w] = Fr(3) ** (-phi[N]); s = sum(l)
    lam[N] = [str(x / s) for x in l]
J['lambda'] = lam
H1 = [hi(X, Y, J['types']) for X, Y in cyc]
print('phi =', phi, ' cycle upper bounds after gauge:', H1, '=> x_B-x_A, x_C-x_B, x_D-x_C, x_A-x_D >=', [-h for h in H1])
json.dump(J, open(os.path.join(here, 'checkpoint_fields_gauged.json'), 'w'), indent=1)
