"""PP50: independent check of PP51's kink certificate (Thm 5.1 instance), exact.

Triple A = u, B = (406,421,373)/1200, D = (406,373,421)/1200, eps = 3/10.
Types are found from PP50's own arrangement enumeration (not PP51's code).  We check:
 (K0) two-valued (no cell with both h and -h);
 (K1) a cell where A answers alone with Wr = {1} ("above") and one with Wr = {2,3} ("below");
 (K2) the admissible strict orders of D^{AB} = log(nu^A/nu^B) and D^{AD} = log(nu^A/nu^D) implied by
      PP45 Lemma 2.1 (strict own-Bayes for the first model, weak for the second, and the reverse roles)
      on the realised pair patterns: only 3>1>2 for AB and only 2>1>3 for AD
      (hence z^B_2 >= z^A_2 >= z^D_2 with z^N = (nu^N_2/nu^N_1, nu^N_3/nu^N_1));
 (K3) every pair is two-signed at every world.
Then PP51 Thm 5.1's short convexity argument (re-proved in PP50 §7) gives the contradiction.
Additionally (NUMERICS) a direct search over effective weights nu in the exact triple reduction
(PP50 Lemma 7.1) finds no feasible nu.
"""
import sys, os, random, math; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from itertools import permutations
from pp50_lib import enumerate_types
import numpy as np
from scipy.optimize import linprog

eps = Fr(3, 10)
TS = Fr(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1] != 'numerics' else Fr(1)
_b = [Fr(3 * 406, 1200), Fr(3 * 421, 1200), Fr(3 * 373, 1200)]
_d = [Fr(3 * 406, 1200), Fr(3 * 373, 1200), Fr(3 * 421, 1200)]
models = {'A': [Fr(1)] * 3, 'B': [1 + TS * (x - 1) for x in _b], 'D': [1 + TS * (x - 1) for x in _d]}
print('scale t =', TS, ' (t = 1 is PP51\'s instance)')
types = enumerate_types(eps, models)
OK = True
def check(c, m):
    global OK
    if not c:
        OK = False; print('FAIL', m)
three = [t for t in types if t[0] == 'THREE']
check(not three, 'three-valued cells')
tl = [t for t in types if t[0] != 'THREE']
print('(K0) cells with disagreement:', len(tl), ' two-valued:', not three)
for H, S, Wr in sorted(tl, key=lambda t: (sorted(t[0]), sorted(t[2]))):
    print('   H=%-4s S=%-4s Wr=%s' % (''.join(sorted(H)), ''.join(sorted(S)), [v + 1 for v in sorted(Wr)]))
above = (frozenset('A'), frozenset('BD'), frozenset([0]))
below = (frozenset('A'), frozenset('BD'), frozenset([1, 2]))
check(above in types and below in types, 'K1 cells missing')
print('(K1) "above" cell (A alone answers, wrong only at 1):', above in types, '; "below" cell (A alone, right only at 1):', below in types)
# pair patterns: for pair (X,Y): set of (Wworse) = worlds where Y's advice is worse than X's
def pair_patterns(X, Y):
    pats = set()
    for H, S, Wr in tl:
        if (X in H) == (Y in H):
            continue
        if Y in H:   # Y answers h: worse where h wrong
            W = frozenset(Wr)
        else:        # Y silent: worse where h right
            W = frozenset(v for v in range(3) if v not in Wr)
        pats.add(W)
    return pats
def admissible_orders(X, Y):
    """strict orders of D (D_w = log nu^X_w/nu^Y_w) compatible with (star): max_{W} D > min_{R} D, all patterns"""
    pats = pair_patterns(X, Y)
    out = []
    for perm in permutations(range(3)):   # perm[0] largest
        rank = {perm[i]: 3 - i for i in range(3)}
        if all(max(rank[w] for w in W) > min(rank[r] for r in range(3) if r not in W) for W in pats):
            out.append('>'.join(str(p + 1) for p in perm))
    return pats, out
for X, Y in (('A', 'B'), ('A', 'D')):
    pats, orders = admissible_orders(X, Y)
    print('(K2) pair %s%s: worse-sets %s; admissible strict orders of log(nu^%s/nu^%s): %s' %
          (X, Y, sorted(sorted(v + 1 for v in W) for W in pats), X, Y, orders))
_, oAB = admissible_orders('A', 'B'); _, oAD = admissible_orders('A', 'D')
check(oAB == ['3>1>2'] and oAD == ['2>1>3'], 'K2 orders differ from PP51')
# ties: (star) with ties allowed only if strict inequality still holds; check that no order with a tie passes
def tie_ok(X, Y):
    pats = pair_patterns(X, Y)
    bad = []
    for D in [(a, b, c) for a in range(3) for b in range(3) for c in range(3)]:
        if len(set(D)) == 3:
            continue
        if all(max(D[w] for w in W) > min(D[r] for r in range(3) if r not in W) for W in pats):
            bad.append(D)
    return bad
check(not tie_ok('A', 'B') and not tie_ok('A', 'D'), 'tied D vectors admissible')
print('(K2) no tied D vector is admissible for AB or AD')
for X, Y in (('A', 'B'), ('A', 'D'), ('B', 'D')):
    pats = pair_patterns(X, Y)
    for v in range(3):
        check(any(v in W for W in pats) and any(v not in W for W in pats), 'K3 %s%s world %d one-signed' % (X, Y, v + 1))
print('(K3) all three pairs two-signed at all worlds')

# NUMERICS: exact reduction (Lemma 7.1): feasible iff exist nu^A,nu^B,nu^D > 0 s.t. every cell has
# w in O_s with nu^H.w <= -t, nu^Q.w >= t (strict margin t > 0, |w|_inf <= 1).
def cell_margin(nu, H, S, Wr):
    s = [1 if v in Wr else -1 for v in range(3)]
    # variables w (3), t ; maximise t
    A_ub = []; b_ub = []
    for N in H:   # nu.w + t <= 0
        A_ub.append(list(nu[N]) + [1]); b_ub.append(0)
    for N in S:   # -nu.w + t <= 0
        A_ub.append([-x for x in nu[N]] + [1]); b_ub.append(0)
    for v in range(3):   # s_v w_v >= t  ->  -s_v w_v + t <= 0
        row = [0, 0, 0, 1]; row[v] = -s[v]; A_ub.append(row); b_ub.append(0)
    bounds = [(-1, 1)] * 3 + [(None, 1)]
    r = linprog([0, 0, 0, -1], A_ub=A_ub, b_ub=b_ub, bounds=bounds, method='highs')
    return -r.fun if r.status == 0 else -1
def score(x):
    nu = {'A': np.exp([0, x[0], x[1]]), 'B': np.exp([0, x[2], x[3]]), 'D': np.exp([0, x[4], x[5]])}
    return min(cell_margin(nu, H, S, Wr) for H, S, Wr in tl)
if 'numerics' not in sys.argv:
    print('ALL PASS' if OK else 'FAILURES'); sys.exit(0)
random.seed(7)
best = -9
from scipy.optimize import minimize
for trial in range(40):
    x0 = [random.gauss(0, 2) for _ in range(6)]
    s0 = score(x0)
    if trial < 25 or s0 > best - 0.2:
        r = minimize(lambda x: -score(x), x0, method='Nelder-Mead', options={'maxiter': 400, 'xatol': 1e-6, 'fatol': 1e-9})
        s0 = max(s0, -r.fun)
    best = max(best, s0)
print('NUMERICS: best min-cell margin over 40 starts (feasible iff > 0): %.3e' % best)
print('ALL PASS' if OK else 'FAILURES')
