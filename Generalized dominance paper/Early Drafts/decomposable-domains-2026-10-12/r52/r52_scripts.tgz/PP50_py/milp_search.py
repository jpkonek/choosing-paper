"""PP50 search (proposal only; every claim is re-verified exactly in verify_exact.py).

Finite reduction: magnitudes m^N_v(tau) > 0 constant on each realised type tau (times |g|).
Log variables y = log m, l = log lambda.  Bayes is imposed in the sufficient 'dominant world' form
(one world on the good side beats every world on the bad side by a factor e^1 >= 2.7 > 2), which is
linear in (y, l).  CG2 thresholds, triple constants and the 4-cycle certificate are linear.
The system is homogeneous apart from the margin 1, so feasibility with margin 1 is scale-free.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import json
import numpy as np
from fractions import Fraction as Fr
from itertools import combinations
from scipy.optimize import milp, LinearConstraint, Bounds
from pp50_lib import enumerate_types, posterior

MODELS = ['A', 'B', 'C', 'D']
PAIRS = list(combinations(MODELS, 2))
TRIPLES = list(combinations(MODELS, 3))


def build_and_solve(types, cycle, wcyc, BIG=200.0, margin=1.0, verbose=True):
    tl = [t for t in types if t[0] != 'THREE']
    assert len(tl) == len(types), 'three-valued type present'
    idx = {}
    def var(name):
        if name not in idx:
            idx[name] = len(idx)
        return idx[name]
    integ = {}
    rows = []  # (dict coef, lo, hi)
    def add(coef, lo, hi):
        rows.append((coef, lo, hi))
    for N in MODELS:
        for v in range(3):
            var(('l', N, v))
    for ti, (H, S, Wr) in enumerate(tl):
        Rt = [v for v in range(3) if v not in Wr]
        Wl = sorted(Wr)
        for N in MODELS:
            for v in range(3):
                var(('y', ti, N, v))
        # Bayes (dominant world)
        for N in MODELS:
            good = Rt if N in H else Wl     # worlds where N's own answer is the better one
            bad = Wl if N in H else Rt
            bs = []
            for r in good:
                b = var(('b', ti, N, r)); integ[b] = 1; bs.append(b)
                for v in bad:
                    coef = {var(('y', ti, N, r)): 1, var(('l', N, r)): 1,
                            var(('y', ti, N, v)): -1, var(('l', N, v)): -1, b: -BIG}
                    add(coef, margin - BIG, np.inf)
            add({b: 1 for b in bs}, 1, 1)
        # CG2
        for (X, Y) in PAIRS:
            if (X in H) == (Y in H):
                continue
            for v in range(3):
                hwrong = v in Wr
                Xerr = (X in H) == hwrong
                rho = {var(('y', ti, Y, v)): 1, var(('y', ti, X, v)): -1}
                if Xerr:   # rho <= Lo
                    c = dict(rho); c[var(('Lo', X, Y, v))] = -1; add(c, -np.inf, 0)
                else:      # rho >= Hi
                    c = dict(rho); c[var(('Hi', X, Y, v))] = -1; add(c, 0, np.inf)
    # nondegenerate intervals
    for (X, Y) in PAIRS:
        for v in range(3):
            if ('Lo', X, Y, v) in idx and ('Hi', X, Y, v) in idx:
                add({idx[('Hi', X, Y, v)]: 1, idx[('Lo', X, Y, v)]: -1}, margin, np.inf)
    # triples
    for tr in TRIPLES:
        for v in range(3):
            for (X, Y) in combinations(tr, 2):
                kx = {var(('x', tr, X, v)): 1, var(('x', tr, Y, v)): -1}
                if ('Lo', X, Y, v) in idx:
                    c = dict(kx); c[idx[('Lo', X, Y, v)]] = -1; add(c, margin, np.inf)
                if ('Hi', X, Y, v) in idx:
                    c = dict(kx); c[idx[('Hi', X, Y, v)]] = -1; add(c, -np.inf, -margin)
    # 4-cycle certificate at world wcyc: for each oriented edge X->Y, a designated type where Y errs
    # at wcyc with y^Y - y^X <= U_e ; sum U_e <= -margin
    for ei, (X, Y) in enumerate(cycle):
        cands = []
        for ti, (H, S, Wr) in enumerate(tl):
            if (X in H) == (Y in H):
                continue
            hwrong = wcyc in Wr
            Yerr = (Y in H) == hwrong
            if Yerr:
                cands.append(ti)
        if not cands:
            if verbose:
                print('edge', X, Y, 'has no Y-err type at world', wcyc + 1)
            return None
        bs = []
        for ti in cands:
            b = var(('pin', ei, ti)); integ[b] = 1; bs.append(b)
            c = {var(('y', ti, Y, wcyc)): 1, var(('y', ti, X, wcyc)): -1, var(('U', ei)): -1, b: BIG}
            add(c, -np.inf, BIG)
        add({b: 1 for b in bs}, 1, 1)
    add({idx[('U', ei)]: 1 for ei in range(len(cycle))}, -np.inf, -margin)
    n = len(idx)
    A = np.zeros((len(rows), n)); lo = np.zeros(len(rows)); hi = np.zeros(len(rows))
    for i, (coef, l, h) in enumerate(rows):
        for j, c in coef.items():
            A[i, j] += c
        lo[i] = l; hi[i] = h
    integrality = np.zeros(n)
    lb = -50 * np.ones(n); ub = 50 * np.ones(n)
    for j in integ:
        integrality[j] = 1; lb[j] = 0; ub[j] = 1
    # objective: keep things small (L1-ish proxy: minimise sum of U to make certificate strong is pointless)
    cvec = np.zeros(n)
    res = milp(cvec, constraints=LinearConstraint(A, lo, hi), integrality=integrality,
               bounds=Bounds(lb, ub), options={'time_limit': 120})
    if verbose:
        print('status', res.status, res.message, 'vars', n, 'rows', len(rows))
    if res.x is None:
        return None
    sol = {k: res.x[j] for k, j in idx.items()}
    return tl, sol


if __name__ == '__main__':
    eps = Fr(3, 10)
    configs = {
        'square': {'A': [1, 1, 1], 'B': [Fr(11, 10), 1, 1], 'C': [Fr(11, 10), Fr(11, 10), 1], 'D': [1, Fr(11, 10), 1]},
        'generic': {'A': [1, 1, 1], 'B': [Fr(11, 10), 1, Fr(99, 100)], 'C': [Fr(12, 10), Fr(11, 10), 1],
                    'D': [1, Fr(11, 10), Fr(101, 100)]},
    }
    cyc = [('A', 'B'), ('B', 'C'), ('C', 'D'), ('D', 'A')]
    rcyc = [(Y, X) for (X, Y) in reversed(cyc)]
    for name, cfg in configs.items():
        models = {k: posterior(v) for k, v in cfg.items()}
        types = enumerate_types(eps, models)
        for w in range(3):
            for cname, cc in (('ABCD', cyc), ('ADCB', rcyc)):
                print('==', name, 'world', w + 1, 'cycle', cname)
                out = build_and_solve(types, cc, w)
