"""PP50: independent re-verification of PP53's four-model certificate.
Converts r9/PP53_py/four_model_solution*.json (P = acceptors, R = worlds where h is correct; magnitudes
exp(phi) taken as the exact binary value of the float, as PP53 does) into PP50's table format and runs
verify_exact.py, which re-enumerates the realised types from the plane arrangement (independently of the
pair-ordering admissibility list PP53 uses) and re-derives intervals, triples and global prices."""
import sys, os, json, math; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import verify_exact as V
here = os.path.dirname(os.path.abspath(__file__))
for name in ('four_model_solution.json', 'four_model_solution_fixlam.json'):
    S = json.load(open(os.path.join(here, '..', 'PP53_py', name)))
    rows = []
    for P, R in S['types']:
        Wr = [v for v in range(3) if v not in R]
        Sset = [N for N in 'ABCD' if N not in P]
        m = {N: [str(Fr(math.exp(S['phi'][json.dumps([N, P, R, v])]))) for v in range(3)] for N in 'ABCD'}
        rows.append({'H': P, 'S': Sset, 'Wr': Wr, 'm': m})
    lam = {}
    for N in 'ABCD':
        l = [Fr(math.exp(S['ll'][json.dumps([N, v])])) for v in range(3)]
        lam[N] = [str(x / sum(l)) for x in l]
    # PP53's models are given as normalised indices; PP50's loader normalises again (harmless)
    J = {'eps': '3/10', 'models': S['idx'], 'lambda': lam, 'base': None, 'target_world': 1, 'types': rows}
    p = os.path.join(here, '_pp53.json'); json.dump(J, open(p, 'w'))
    print('=====', name)
    V.FAILS.clear(); V.main(p)
    os.remove(p)
