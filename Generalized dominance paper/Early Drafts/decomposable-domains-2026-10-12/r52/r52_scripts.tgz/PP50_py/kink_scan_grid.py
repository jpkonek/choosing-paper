"""PP50: PP51 Thm 5.1 kink certificates on every triple of a model set (exact types from pp50_lib).
Certificate for an ordered choice (odd model X, lone world i, coordinate j != i, mode 'answer'/'silent'):
 (K1) cells where X alone answers (or alone is silent) with Wr = {i} and with Wr = {j,k};
 (K2) every admissible strict order of log(nu^X/nu^B) puts i above j and every admissible order of
      log(nu^X/nu^D) puts j above i (or the reverse for both), no tied vector admissible;
 (K3) all pairs two-signed at all worlds.
Usage: kink_scan_grid.py grid N   |   kink_scan_grid.py checkpoint"""
import sys, os, json; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from itertools import combinations, permutations, product
from pp50_lib import enumerate_types, posterior
eps = Fr(3, 10)

def pair_patterns(tl, X, Y):
    pats = set()
    for H, S, Wr in tl:
        if (X in H) == (Y in H): continue
        pats.add(frozenset(Wr) if Y in H else frozenset(v for v in range(3) if v not in Wr))
    return pats

def adm(pats):
    out = []
    for D in product(range(3), repeat=3):
        if all(max(D[w] for w in W) > min(D[r] for r in range(3) if r not in W) for W in pats):
            out.append(D)
    return out

def kink(models3):
    types = enumerate_types(eps, models3)
    if any(t[0] == 'THREE' for t in types): return 'three-valued'
    tl = list(types)
    names = sorted(models3)
    for X in names:
        Bn, Dn = [N for N in names if N != X]
        for i in range(3):
            jk = [v for v in range(3) if v != i]
            for mode in ('answer', 'silent'):
                def cell(Wr):
                    if mode == 'answer':
                        return (frozenset([X]), frozenset([Bn, Dn]), frozenset(Wr)) in types
                    return (frozenset([Bn, Dn]), frozenset([X]), frozenset(Wr)) in types
                if not (cell([i]) and cell(jk)): continue
                aB, aD = adm(pair_patterns(tl, X, Bn)), adm(pair_patterns(tl, X, Dn))
                if any(len(set(D)) < 3 for D in aB + aD): continue
                for j in jk:
                    for P, Q in ((Bn, Dn), (Dn, Bn)):
                        a1 = aB if P == Bn else aD; a2 = aD if P == Bn else aB
                        if all(D[i] > D[j] for D in a1) and all(D[j] > D[i] for D in a2):
                            ok3 = all(any(v in W for W in pair_patterns(tl, U, Vv)) and any(v not in W for W in pair_patterns(tl, U, Vv))
                                      for U, Vv in combinations(names, 2) for v in range(3))
                            if ok3:
                                return (X, i + 1, j + 1, mode)
    return None

if __name__ == '__main__':
    if sys.argv[1] == 'checkpoint':
        J = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'checkpoint_fields.json')))
        cfg = {k: [Fr(x) for x in v] for k, v in J['models'].items()}
    else:
        n = int(sys.argv[2]); d1 = [Fr(1, 10), 0, Fr(-1, 100)]; d2 = [0, Fr(1, 10), Fr(1, 100)]
        cfg = {'P%d%d' % (i, j): [1 + Fr(i, n - 1) * d1[q] + Fr(j, n - 1) * d2[q] for q in range(3)] for i in range(n) for j in range(n)}
    models = {k: posterior(v) for k, v in cfg.items()}
    found = 0; tot = 0
    for tr in combinations(sorted(models), 3):
        tot += 1
        k = kink({N: models[N] for N in tr})
        if k:
            found += 1; print('kink certificate:', tr, k, flush=True)
    print('triples:', tot, ' with kink certificate:', found)
