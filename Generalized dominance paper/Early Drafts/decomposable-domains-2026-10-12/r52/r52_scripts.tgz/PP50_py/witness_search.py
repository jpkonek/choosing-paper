"""PP50 witness-pair fields (proposal by MILP; verified exactly by verify_exact.py).

Witness-pair field of model N (weight lambda_N = a_N, the model's own likelihood vector):
    l^N_v(g, h) - l^N_v(g, S) = -h_v * p_v(g, N),      p(g, N) in M,
with p(g,N) arbitrary in M when N answers h, and p(g,N) in W_N(g) = {p in M : (a_N * p).h < 0}
when N is silent.  Then lambda_N . (l(h) - l(S)) = -(a_N * p).h, so N is pointwise strictly own-Bayes
between h and S AUTOMATICALLY, at every problem, for every index a_N (boundary included).
CG2 ratios at world v are p_v(g,Y)/p_v(g,X).

Here p(tau, N) is constant on each realised type and is chosen from a finite grid of M:
  - answering models: any grid point;
  - silent models: grid points supported on J_N(tau) = {j : (m_j * a_N).g < 0 on the cell}
    (the sign is constant on the cell), so W_N holds on the whole cell.
"""
import sys, os, json, math; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from fractions import Fraction as Fr
from itertools import combinations
from scipy.optimize import milp, LinearConstraint, Bounds
from pp50_lib import enumerate_types, posterior, mverts, dot

MODELS = ['A', 'B', 'C', 'D']; PAIRS = list(combinations(MODELS, 2)); TRIPLES = list(combinations(MODELS, 3))


def grid(den):
    pts = []
    for i in range(den + 1):
        for j in range(den + 1 - i):
            pts.append((Fr(i, den), Fr(j, den), Fr(den - i - j, den)))
    return pts


def search(eps, cfg, w, den=4, margin=0.004, defect=0.004, tlim=300, cycle=None, glob_other=True):
    models = {k: posterior(v) for k, v in cfg.items()}
    types = enumerate_types(eps, models)
    tl = [(t, g) for t, g in types.items() if t[0] != 'THREE']
    Mv = mverts(eps)
    G = grid(den)
    P = [[sum(b[j] * Mv[j][v] for j in range(3)) for v in range(3)] for b in G]   # points of M
    LP = [[math.log(float(p[v])) for v in range(3)] for p in P]
    cycle = cycle or [('A', 'B'), ('B', 'C'), ('C', 'D'), ('D', 'A')]
    idx = {}; integ = set(); rows = []
    def var(n, integer=False):
        if n not in idx: idx[n] = len(idx)
        if integer: integ.add(idx[n])
        return idx[n]
    def add(c, lo, hi): rows.append((c, lo, hi))
    allowed = {}
    for ti, ((H, S, Wr), g) in enumerate(tl):
        for N in MODELS:
            if N in H:
                ks = list(range(len(G)))
            else:
                a = models[N]
                J = [j for j in range(3) if dot([Mv[j][q] * a[q] for q in range(3)], g) < 0]
                ks = [k for k, b in enumerate(G) if all(b[j] == 0 for j in range(3) if j not in J)]
            allowed[(ti, N)] = ks
            add({var(('z', ti, N, k), True): 1 for k in ks}, 1, 1)
    def logp(ti, N, v):
        return {idx[('z', ti, N, k)]: LP[k][v] for k in allowed[(ti, N)]}
    def comb(a, b):  # a - b
        out = dict(a)
        for k, c in b.items(): out[k] = out.get(k, 0) - c
        return out
    for ti, ((H, S, Wr), g) in enumerate(tl):
        for (X, Y) in PAIRS:
            if (X in H) == (Y in H): continue
            for v in range(3):
                Xerr = (X in H) == (v in Wr)
                rho = comb(logp(ti, Y, v), logp(ti, X, v))
                if Xerr: c = dict(rho); c[var(('Lo', X, Y, v))] = -1; add(c, -np.inf, 0)
                else:    c = dict(rho); c[var(('Hi', X, Y, v))] = -1; add(c, 0, np.inf)
    for (X, Y) in PAIRS:
        for v in range(3):
            if ('Lo', X, Y, v) in idx and ('Hi', X, Y, v) in idx:
                add({idx[('Hi', X, Y, v)]: 1, idx[('Lo', X, Y, v)]: -1}, margin, np.inf)
    groups = [(tr, v) for tr in TRIPLES for v in range(3)]
    if glob_other:
        groups += [(tuple(MODELS), v) for v in range(3) if v != w]
    for tr, v in groups:
        for (X, Y) in combinations(tr, 2):
            kx = {var(('x', tr, X, v)): 1, var(('x', tr, Y, v)): -1}
            if ('Lo', X, Y, v) in idx:
                c = dict(kx); c[idx[('Lo', X, Y, v)]] = -1; add(c, margin / 2, np.inf)
            if ('Hi', X, Y, v) in idx:
                c = dict(kx); c[idx[('Hi', X, Y, v)]] = -1; add(c, -np.inf, -margin / 2)
    BIG = 10.0
    for ei, (X, Y) in enumerate(cycle):
        cands = [ti for ti, ((H, S, Wr), g) in enumerate(tl) if (X in H) != (Y in H) and ((Y in H) == (w in Wr))]
        if not cands: return None, 'edge %s%s has no Y-err type at world %d' % (X, Y, w + 1)
        bs = []
        for ti in cands:
            b = var(('pin', ei, ti), True); bs.append(b)
            c = comb(logp(ti, Y, w), logp(ti, X, w)); c[var(('U', ei))] = -1; c[b] = BIG
            add(c, -np.inf, BIG)
        add({b: 1 for b in bs}, 1, 1)
    add({idx[('U', ei)]: 1 for ei in range(len(cycle))}, -np.inf, -defect)
    n = len(idx)
    A = np.zeros((len(rows), n)); lo = np.array([r[1] for r in rows], float); hi = np.array([r[2] for r in rows], float)
    for i, (c, _, _) in enumerate(rows):
        for j, v in c.items(): A[i, j] += v
    integrality = np.zeros(n); lb = -5 * np.ones(n); ub = 5 * np.ones(n)
    for j in integ: integrality[j] = 1; lb[j] = 0; ub[j] = 1
    res = milp(np.zeros(n), constraints=LinearConstraint(A, lo, hi), integrality=integrality,
               bounds=Bounds(lb, ub), options={'time_limit': tlim})
    if res.x is None:
        return None, res.message
    sol = {k: res.x[j] for k, j in idx.items()}
    choice = {(ti, N): G[max(allowed[(ti, N)], key=lambda k: sol[('z', ti, N, k)])] for ti in range(len(tl)) for N in MODELS}
    return (tl, choice, models, P, G), res.message


if __name__ == '__main__':
    eps = Fr(3, 10)
    cfg = {'A': [1, 1, 1], 'B': [Fr(11, 10), 1, Fr(99, 100)], 'C': [Fr(12, 10), Fr(11, 10), 1],
           'D': [1, Fr(11, 10), Fr(101, 100)]}
    for w in range(3):
        out, msg = search(eps, cfg, w, den=int(sys.argv[1]) if len(sys.argv) > 1 else 4)
        print('world', w + 1, 'FEASIBLE' if out else 'NO', msg, flush=True)
