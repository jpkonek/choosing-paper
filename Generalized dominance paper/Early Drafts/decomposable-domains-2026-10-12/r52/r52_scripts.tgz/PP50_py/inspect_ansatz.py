import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from itertools import permutations
from explore_ansatz import solve
from pp50_lib import enumerate_types, posterior
eps = Fr(3,10)
cfg = {'A':[1,1,1],'B':[Fr(11,10),1,Fr(99,100)],'C':[Fr(12,10),Fr(11,10),1],'D':[1,Fr(11,10),Fr(101,100)]}
models = {k: posterior(v) for k,v in cfg.items()}
types = enumerate_types(eps, models)
cyc = [('A','B'),('B','C'),('C','D'),('D','A')]
w = int(sys.argv[1]) if len(sys.argv)>1 else 0
(sol, tl), msg = solve(types, cyc, w, ansatz=True, obj=None, K=8)
M = 'ABCD'
print('Phi (log3):', {N: [round(sol[('Phi',N,v)]) for v in range(3)] for N in M})
for ti,(H,S,Wr) in enumerate(tl):
    Jh = [round(sol.get(('J',ti,'h',v),0)) for v in range(3)]; Js = [round(sol.get(('J',ti,'s',v),0)) for v in range(3)]
    e = [ (Jh[v]-Js[v]) if v in Wr else (Js[v]-Jh[v]) for v in range(3)]
    pins = [ei for ei in range(4) if sol.get(('pin',ei,ti),0) > 0.5]
    print('%-4s|%-4s Wr=%-6s Jh=%-12s Js=%-12s e(err-right)=%-12s %s' % (''.join(sorted(H)),''.join(sorted(S)),[v+1 for v in sorted(Wr)],Jh,Js,e, ('PIN '+str([cyc[p] for p in pins])) if pins else ''))
