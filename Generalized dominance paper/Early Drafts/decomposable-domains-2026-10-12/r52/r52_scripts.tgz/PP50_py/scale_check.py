"""PP50 (CHECKED): the same field table works for the quadruple shrunk towards T.
a_N(t) = 1 + t (a_N - 1) (unnormalised), t in {1, 1/2, 1/4, 1/10, 1/100, 1/1000}: the realised type
set is identical, so verify_exact passes with the unchanged table."""
import sys, os, json; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import verify_exact as V
from pp50_lib import enumerate_types, posterior
here = os.path.dirname(os.path.abspath(__file__))
J = json.load(open(os.path.join(here, 'checkpoint_fields.json')))
base = {k: [Fr(x) for x in v] for k, v in J['models'].items()}
for t in [Fr(1), Fr(1,2), Fr(1,4), Fr(1,10), Fr(1,100), Fr(1,1000)]:
    J2 = dict(J); J2['models'] = {k: [str(1 + t*(x-1)) for x in v] for k, v in base.items()}
    p = os.path.join(here, '_scaled.json'); json.dump(J2, open(p, 'w'))
    V.FAILS.clear()
    import io, contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        V.main(p)
    out = buf.getvalue().splitlines()
    print('t =', t, '|', [l for l in out if l.startswith('(V1)') or l.startswith('(V5) world 1') or 'PASS' in l or 'FAIL' in l][:4])
os.remove(os.path.join(here, '_scaled.json'))
