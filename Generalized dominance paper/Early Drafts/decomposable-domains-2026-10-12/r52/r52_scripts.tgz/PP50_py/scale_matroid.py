"""PP50 (CHECKED, exact): for a_N(t) = 1 + t (a_N - 1) the oriented matroid of the 15 plane normals
{m_j * a_N(t)} U {e_1, e_2, e_3} is constant for t in (0, 1]: every 3x3 determinant is a polynomial in t of
degree <= 3 that is identically zero or has no root in (0, 1].  Hence the cell structure and the realised
type set are the same for every t in (0, 1], and the single field table of checkpoint_fields.json works for
every quadruple of the shrinking family (combine with verify_exact at t = 1)."""
import sys, os, json; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from itertools import combinations
from pp50_lib import mverts
here = os.path.dirname(os.path.abspath(__file__))
J = json.load(open(os.path.join(here, 'checkpoint_fields.json')))
eps = Fr(3, 10); M = mverts(eps)
# polynomials as coefficient lists [c0, c1, ...] in t
def padd(p, q):
    n = max(len(p), len(q)); return [(p[i] if i < len(p) else 0) + (q[i] if i < len(q) else 0) for i in range(n)]
def pmul(p, q):
    r = [Fr(0)] * (len(p) + len(q) - 1)
    for i, a in enumerate(p):
        for j, b in enumerate(q): r[i + j] += a * b
    return r
def pneg(p): return [-x for x in p]
vecs = []
for N, a in J['models'].items():
    a = [Fr(x) for x in a]
    for j in range(3):
        vecs.append([[M[j][q], M[j][q] * (a[q] - 1)] for q in range(3)])   # m_j*(1 + t(a-1)), unnormalised a
for q in range(3):
    vecs.append([[Fr(1 if i == q else 0)] for i in range(3)])
def det(u, v, w):
    t1 = pmul(u[0], padd(pmul(v[1], w[2]), pneg(pmul(v[2], w[1]))))
    t2 = pmul(u[1], padd(pmul(v[0], w[2]), pneg(pmul(v[2], w[0]))))
    t3 = pmul(u[2], padd(pmul(v[0], w[1]), pneg(pmul(v[1], w[0]))))
    return padd(padd(t1, pneg(t2)), t3)
def roots_in_01(p):
    # strip zeros; count sign changes via Sturm-free test: exact real-root isolation by bisection on a fine
    # rational grid plus Descartes' bound on (0,1] after substitution t = 1/(1+x)
    while p and p[-1] == 0: p = p[:-1]
    if not p: return 'zero'
    d = len(p) - 1
    # q(x) = (1+x)^d p(1/(1+x)) ; roots t in (0,1) <-> x in (0,inf); Descartes bound on q
    q = [Fr(0)]
    for k, c in enumerate(p):
        term = [Fr(c)]
        for _ in range(d - k): term = pmul(term, [Fr(1), Fr(1)])
        q = padd(q, term)
    q = [x for x in q]
    s = [x for x in q if x != 0]
    changes = sum(1 for i in range(len(s) - 1) if (s[i] > 0) != (s[i + 1] > 0))
    at1 = sum(p)
    return (changes, at1)
bad = 0; zero = 0; n = 0
for u, v, w in combinations(vecs, 3):
    p = det(u, v, w); n += 1
    r = roots_in_01(p)
    if r == 'zero': zero += 1; continue
    changes, at1 = r
    if changes > 0 or at1 == 0:
        bad += 1
print('determinants:', n, ' identically zero:', zero, ' possibly changing sign on (0,1]:', bad)
print('ALL PASS' if bad == 0 else 'NEEDS FINER CHECK')
