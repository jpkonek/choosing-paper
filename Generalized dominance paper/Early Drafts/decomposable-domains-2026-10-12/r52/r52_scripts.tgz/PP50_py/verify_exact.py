"""PP50 exact verifier (CHECKED).  Reads a field table (JSON) and verifies, in Fractions only:

 (V1) the type list is the full list of realised disagreement types (re-enumerated exactly here)
      and the four models are two-valued (no problem gets three different answers);
 (V2) pointwise strict own-Bayes at the stated weight, at every type, over ALL FOUR advice values,
      for the completed field (h vs S magnitudes from the table; -h and contradiction completed
      as in PP45 with a large constant K);
 (V3) the derived CG2 sandwich intervals I_XY(v) = [max over X-err of m^Y/m^X, min over Y-err of m^Y/m^X]
      for all 6 pairs and 3 worlds, and that each is nondegenerate (lo < hi), so strict CG2 holds
      with any constants strictly inside;
 (V4) PP47 Thm 4.1 for every triple at every world, in the strict (slack) form:
      prod lo < 1 < prod hi around the triangle, both orientations  (hence (a) holds and no tight triple);
 (V5) global prices: at each world, whether one set of constants fits all six intervals
      (exact: difference constraints on 4 nodes are infeasible iff some 2-, 3- or 4-cycle has
      product of upper ratio-bounds < 1; all cycles are enumerated), with the certificate cycle.

Fields: at a problem g of type tau, model N, world v:  l^N_v(g, h) - l^N_v(g, S) = +/- m^N_v(tau) |g|_1,
sign + iff h is wrong at v.  Off disagreement sets every model uses an own-Bayes field (V2 covers it
by a separate check at agreement types).
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from itertools import combinations, permutations
from pp50_lib import enumerate_types, posterior, cell_points, advice

MODELS = ['A', 'B', 'C', 'D']
FAILS = []


def check(cond, msg):
    if not cond:
        FAILS.append(msg)
        print('FAIL', msg)


def load(path):
    with open(path) as f:
        J = json.load(f)
    eps = Fr(J['eps'])
    models = {k: posterior([Fr(x) for x in v]) for k, v in J['models'].items()}
    lam = {k: [Fr(x) for x in v] for k, v in J['lambda'].items()}
    base = Fr(J['base']) if J.get('base') else None
    MODELS[:] = sorted(J['models'])
    table = {}
    for row in J['types']:
        key = (frozenset(row['H']), frozenset(row['S']), frozenset(row['Wr']))
        if 'm' in row:
            table[key] = {N: [Fr(x) for x in row['m'][N]] for N in MODELS}
        else:
            table[key] = {N: [base ** int(e) for e in row['y'][N]] for N in MODELS}
    return J, eps, models, lam, table


def full_field(m, Wr, K):
    """completed field values (per world) for h, S, -h, X at one type for magnitudes m (|g|=1)."""
    Lam = sum(m)
    out = []
    for v in range(3):
        if v in Wr:   # h wrong at v: ranks -h 0 < S 1 < h 2 < X 3
            out.append({'mh': 0, 'S': m[v], 'h': 2 * m[v], 'X': 2 * m[v] + K * Lam})
        else:         # h right at v: h 0 < S 1 < -h 2 < X 3
            out.append({'h': 0, 'S': m[v], 'mh': m[v] + K * Lam, 'X': m[v] + (K + 1) * Lam})
    return out


def main(path):
    J, eps, models, lam, table = load(path)
    print('models (likelihood, normalised):', {k: [str(x) for x in v] for k, v in models.items()})
    # (V1)
    types = enumerate_types(eps, models)
    three = [t for t in types if t[0] == 'THREE']
    check(not three, 'three-valued types present: %s' % three)
    real = set(t for t in types if t[0] != 'THREE')
    check(real == set(table), 'type table != realised types: missing %s extra %s' %
          (real - set(table), set(table) - real))
    print('(V1) realised disagreement types:', len(real), ' two-valued:', not three)
    # (V2)
    Kc = 2 / min(min(l) for l in lam.values()) + 1
    nb = 0
    for (H, S, Wr), m in table.items():
        for N in MODELS:
            F = full_field(m[N], Wr, Kc)
            own = 'h' if N in H else 'S'
            cost = {a: sum(lam[N][v] * F[v][a] for v in range(3)) for a in ('h', 'S', 'mh', 'X')}
            for a in cost:
                if a != own:
                    check(cost[own] < cost[a], 'Bayes fails %s at %s,%s,%s vs %s' % (N, sorted(H), sorted(S), sorted(Wr), a))
                    nb += 1
            # rank monotonicity of the completed field
            for v in range(3):
                order = ['mh', 'S', 'h', 'X'] if v in Wr else ['h', 'S', 'mh', 'X']
                check(all(F[v][order[i]] < F[v][order[i + 1]] for i in range(3)), 'not strictly guiding')
    # agreement types: each model must be own-Bayes where all four agree.  Pointwise this is always
    # possible (the advice is coherent): we verify the explicit choice used in the note.
    for g in cell_points(eps, models):
        adv = {k: advice(eps, a, g) for k, a in models.items()}
        if len(set(adv.values())) != 1:
            continue
        x = adv['A']
        h = [-c for c in g] if x == -1 else g
        Wr = [v for v in range(3) if h[v] < 0]
        own = 'S' if x == 0 else 'h'
        if x == 0:
            check(0 < len(Wr) < 3, 'silence on a one-signed problem')
        # magnitudes: 1/lambda_v on the worlds where the own answer is better, 10^-6/lambda_v elsewhere
        good = Wr if own == 'S' else [v for v in range(3) if v not in Wr]
        for N in MODELS:
            mm = [(Fr(1) if v in good else Fr(1, 10 ** 6)) / lam[N][v] for v in range(3)]
            F = full_field(mm, Wr, Kc)
            cost = {a: sum(lam[N][v] * F[v][a] for v in range(3)) for a in ('h', 'S', 'mh', 'X')}
            check(all(cost[own] < cost[a] for a in cost if a != own), 'agreement Bayes')
    print('(V2) strict own-Bayes comparisons checked:', nb)
    # (V3)
    I = {}
    for (X, Y) in permutations(MODELS, 2):
        for v in range(3):
            lo, hi = None, None
            for (H, S, Wr), m in table.items():
                if (X in H) == (Y in H):
                    continue
                rho = m[Y][v] / m[X][v]
                Xerr = (X in H) == (v in Wr)
                if Xerr:
                    lo = rho if lo is None else max(lo, rho)
                else:
                    hi = rho if hi is None else min(hi, rho)
            I[(X, Y, v)] = (lo, hi)
            if lo is not None and hi is not None:
                check(lo < hi, 'degenerate/empty interval %s%s world %d' % (X, Y, v + 1))
    print('(V3) derived intervals for kappa_XY = c_X/c_Y (log base %s):' % J['base'])
    import math
    b = float(Fr(J['base'])) if J.get('base') else 2.718281828459045
    def L(x):
        return '-inf' if x is None else ('%+.0f' % (math.log(float(x)) / math.log(b)))
    for (X, Y) in combinations(MODELS, 2):
        print('   %s%s ' % (X, Y) + '  '.join('w%d [%s,%s]' % (v + 1, L(I[(X, Y, v)][0]),
              ('+inf' if I[(X, Y, v)][1] is None else L(I[(X, Y, v)][1]))) for v in range(3)))
    # (V4)
    def up(X, Y, v):   # upper bound on kappa_XY
        return I[(X, Y, v)][1]
    def low(X, Y, v):
        return I[(X, Y, v)][0]
    for tr in combinations(MODELS, 3):
        for v in range(3):
            for (P, Q, R) in (tr, (tr[0], tr[2], tr[1])):
                his = [up(P, Q, v), up(Q, R, v), up(R, P, v)]
                los = [low(P, Q, v), low(Q, R, v), low(R, P, v)]
                okhi = any(h is None for h in his) or (his[0] * his[1] * his[2] > 1)
                oklo = any(l is None for l in los) or (los[0] * los[1] * los[2] < 1)
                check(okhi and oklo, 'triple %s world %d fails strict test' % ((P, Q, R), v + 1))
    print('(V4) strict triple test (PP47 Thm 4.1, slack form): all 4 triples x 3 worlds x 2 orientations')
    # (V5) exact Floyd-Warshall on upper ratio bounds: global constants at v exist iff no cycle has
    # product of upper bounds < 1 (or = 1 through a closed endpoint, treated as infeasible here: conservative)
    n = len(MODELS)
    for v in range(3):
        D = {(X, Y): up(X, Y, v) for X in MODELS for Y in MODELS if X != Y}
        nxt = {k: k[1] for k, val in D.items() if val is not None}
        for X in MODELS:
            D[(X, X)] = Fr(1); nxt[(X, X)] = X
        for K in MODELS:
            for X in MODELS:
                for Y in MODELS:
                    a, b = D.get((X, K)), D.get((K, Y))
                    if a is None or b is None or X == Y and False:
                        continue
                    c = a * b
                    if D.get((X, Y)) is None or c < D[(X, Y)]:
                        D[(X, Y)] = c; nxt[(X, Y)] = nxt[(X, K)]
        neg = [X for X in MODELS if D[(X, X)] < 1]
        if neg:
            # recover one certificate cycle through neg[0] by brute force over simple cycles (n small) or path
            X0 = neg[0]
            cyc = [X0]; cur = nxt[(X0, X0)]
            while cur != X0 and len(cyc) <= n:
                cyc.append(cur); cur = nxt[(cur, X0)]
            print('(V5) world %d: NO global constants; certificate cycle %s, product of upper bounds %.4f'
                  % (v + 1, ''.join(cyc), float(D[(X0, X0)])))
        else:
            print('(V5) world %d: global constants exist' % (v + 1))
        if v == J['target_world'] - 1:
            check(bool(neg), 'target world has global prices')
    print('ALL PASS' if not FAILS else '%d FAILURES' % len(FAILS))


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), 'checkpoint_fields.json'))
