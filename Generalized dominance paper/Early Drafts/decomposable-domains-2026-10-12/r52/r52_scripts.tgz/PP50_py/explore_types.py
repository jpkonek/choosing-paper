import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from pp50_lib import *
eps = Fr(3,10)
configs = {
 'square': {'A':[1,1,1],'B':[Fr(11,10),1,1],'C':[Fr(11,10),Fr(11,10),1],'D':[1,Fr(11,10),1]},
 'generic': {'A':[1,1,1],'B':[Fr(11,10),1,Fr(99,100)],'C':[Fr(12,10),Fr(11,10),1],'D':[1,Fr(11,10),Fr(101,100)]},
 'Tinside': {'A':[1,1,1],'B':[Fr(11,10),Fr(97,100),Fr(95,100)],'C':[Fr(96,100),Fr(11,10),Fr(98,100)],'D':[Fr(97,100),Fr(95,100),Fr(11,10)]},
}
for name, cfg in configs.items():
    models = {k: posterior(v) for k, v in cfg.items()}
    ty = enumerate_types(eps, models)
    print('==', name, len(ty), 'types')
    for t in sorted(ty, key=lambda t: (str(t[0]) if t[0]!='THREE' else 'Z')):
        if t[0] == 'THREE':
            print('  THREE-VALUED', t); continue
        H,S,Wr = t
        print('  H=%-10s S=%-10s Wr=%s' % (''.join(sorted(H)), ''.join(sorted(S)), sorted(v+1 for v in Wr)))
