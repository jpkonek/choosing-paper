"""PP51 survey: for many four-index arrangements around u (u included), exact cell types, then
MILP feasibility of (G) global constants, (T) per-triple constants, (C) per-triple constants with an
infeasible Hamiltonian 4-cycle at some world.  NUMERICS (HiGHS); exact re-verification of
selected solutions is in verify51.py."""
import sys, os, time, random, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from post51 import *
from prog51 import *

def idx(d, t): return tuple(Fr(1, 3) + t * x for x in d)

def nonsep(models, A):
    """answer set A not linearly separable from the rest within the affine index plane (exact LP-free test
    for 4 points: conv(A) meets conv(S))."""
    import numpy as np
    from scipy.optimize import linprog
    S = [k for k in range(4) if k not in A]
    P = [np.array([float(c) for c in models[k]]) for k in range(4)]
    # find lambda>=0 (A), mu>=0 (S), sum=1 each, sum lam P_a = sum mu P_s
    n = len(A) + len(S)
    Aeq = []; beq = []
    for q in range(3):
        Aeq.append([P[a][q] for a in A] + [-P[s][q] for s in S]); beq.append(0)
    Aeq.append([1]*len(A) + [0]*len(S)); beq.append(1)
    Aeq.append([0]*len(A) + [1]*len(S)); beq.append(1)
    r = linprog(np.zeros(n), A_eq=Aeq, b_eq=beq, bounds=[(0,None)]*n, method='highs')
    return r.status == 0

CYCLES = [(0,1,2,3),(0,1,3,2),(0,2,1,3)]

def analyse(name, eps, models, verbose=False):
    if not all(u_in_Ma(eps, a) for a in models):
        return None, None
    cs = cells(eps, models)
    types = sorted({cell_type(eps, models, g) for g in cs}); types=[ty for ty in types if 0<len(ty[0])<4]
    ns = [ty for ty in types if nonsep(models, ty[0])]
    out = {'types': len(types), 'nonsep': ns}
    P,_,_ = build(types, mode='global'); out['G'] = P.solve(time_limit=60).status == 0
    P,_,_ = build(types, mode='triple'); out['T'] = P.solve(time_limit=60).status == 0
    cyc = []
    for c in CYCLES:
        for w0 in range(3):
            edges = [(c[i], c[(i + 1) % 4]) for i in range(4)]
            for ori in (edges, [(q, p) for p, q in edges]):
                if all(any((p in A) != (q in A) and ((w0 in cor) if p in A else (w0 in wr)) for A, cor, wr in types)
                       for p, q in ori):
                    cyc.append((c, w0)); break
    out['C'] = cyc
    return types, out

if __name__ == '__main__':
    random.seed(51)
    eps_list = [Fr(1,10), Fr(3,10), Fr(1,2)]
    arrs = []
    t = Fr(1,100)
    arrs.append(('sq_u_vertex', [idx((0,0,0),t), idx((1,-1,0),t), idx((2,0,-2),t), idx((1,1,-2),t)]))
    arrs.append(('tri_u_centre', [idx((0,0,0),t), idx((2,-1,-1),t), idx((-1,2,-1),t), idx((-1,-1,2),t)]))
    # thin kites with long diagonal along e2-e3 crossing a short diagonal through u (XOR candidates)
    for L, s in [(4,1),(8,1),(6,1)]:
        tk = Fr(1, 400)
        arrs.append(('kite%d_%d' % (L, s), [idx((0,0,0),tk), idx((2*s,-s+L,-s-L),tk), idx((4*s,-2*s,-2*s),tk), idx((2*s,-s-L,-s+L),tk)]))
    for k in range(12):
        ds = []
        while len(ds) < 3:
            a, b = random.randint(-6,6), random.randint(-6,6)
            d = (a, b, -a-b)
            if d != (0,0,0) and d not in ds:
                ds.append(d)
        arrs.append(('rand%d' % k, [idx((0,0,0),t)] + [idx(d,t) for d in ds]))
    for eps in eps_list:
        for name, models in arrs:
            T0 = time.time()
            types, out = analyse(name, eps, models)
            if out is None:
                print('eps=%s %-13s skipped (u not in every M_a)' % (eps, name), flush=True); continue
            print('eps=%s %-13s types=%2d nonsep=%-22s G=%d T=%d cycle/world pairs with witness cells: %d %s  [%.0fs]' % (
                eps, name, out['types'], [ty[0] for ty in out['nonsep']], out['G'], out['T'], len(out['C']),
                out['C'][:2], time.time()-T0), flush=True)
