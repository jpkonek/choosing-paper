"""PP51 Sec. 1: exact geometry of four posterior models near u.  CHECKED (exact rationals),
except the masses (Monte Carlo, NUMERICS).
For each arrangement: every cell of the plane arrangement (exact interior ray), its answer set,
and for each pair (a, b) the disagreement types (W, R) = (worlds where C_b is worse, better),
with D = log(a/b) ordering, and an exact check of the pair-ordering theorem max_W D > min_R D.
Run: python3 -I -B geometry51.py > geometry51.out"""
import sys, os, itertools, random, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from post51 import *
from arrangements51 import *

OK = True
def check(c, msg):
    global OK
    if not c:
        OK = False; print('FAIL', msg)

W = lambda ws: '{' + ','.join(str(w + 1) for w in ws) + '}'

def mc_masses(eps, models, n=200000, seed=1):
    rnd = random.Random(seed)
    fm = [tuple(float(x) for x in a) for a in models]
    mv = [tuple(float(x) for x in m) for m in mverts(float(eps))]
    cnt = {}
    for _ in range(n):
        g = [rnd.gauss(0, 1) for _ in range(3)]
        if sum(g) < 0: g = [-x for x in g]
        A = tuple(k for k, a in enumerate(fm) if all(sum(a[i]*m[i]*g[i] for i in range(3)) > 0 for m in mv))
        cor = tuple(w for w in range(3) if g[w] > 0)
        cnt[(A, cor)] = cnt.get((A, cor), 0) + 1
    return {k: v / n for k, v in cnt.items()}

for name, models in ARR.items():
    eps = EPS
    print('=' * 78)
    print('Arrangement', name, ' eps =', eps, ' indices (x 300 - 100):')
    for k, a in enumerate(models):
        print('  %s = u + (1/100)%s' % (NAMES[k], tuple(int((x - Fr(1, 3)) * 100) for x in a)))
    check(all(u_in_Ma(eps, a) for a in models), 'u in every M_a')
    cs = cells(eps, models)
    # exact re-check of each cell point: advice in {0,1} (two-valuedness), no zero signs
    ns = normals(eps, models)
    for g in cs:
        check(0 not in signvec(ns, g), 'interior point')
        check(all(advice(eps, a, g) in (0, 1) for a in models), 'no opposite answers')
    types = {}
    for g in cs:
        types.setdefault(cell_type(eps, models, g), []).append(g)
    mass = mc_masses(eps, models)
    print('cells (mod sign):', len(cs), ' cell types:', len(types),
          ' types with disagreement:', sum(1 for t in types if 0 < len(t[0]) < 4))
    print('\nMulti-model cell types (answer set | correct worlds | #cells | MC mass):')
    for t in sorted(types, key=lambda t: (len(t[0]), t)):
        if 0 < len(t[0]) < 4:
            print('  answer %-5s silent %-5s correct %-6s  cells %2d  mass %.2e' % (
                ''.join(NAMES[k] for k in t[0]), ''.join(NAMES[k] for k in range(4) if k not in t[0]),
                W(t[1]), len(types[t]), mass.get((t[0], t[1]), 0.0)))
    print('\nPairs: D = log(a/b) ordering, disagreement types (W = b worse, R = b better):')
    for a, b in itertools.combinations(range(4), 2):
        A_, B_ = models[a], models[b]
        order = sorted(range(3), key=lambda i: -(A_[i] / B_[i]))
        ties = [(i, j) for i, j in itertools.combinations(range(3), 2) if A_[i] * B_[j] == A_[j] * B_[i]]
        tys = {}
        for t in types:
            wr = pair_WR(t, a, b)
            if wr is None: continue
            who = NAMES[a] if a in t[0] else NAMES[b]
            tys.setdefault((wr, who), 0)
            tys[(wr, who)] += len(types[t])
            Wd, Rd = wr
            # exact pair-ordering theorem: min_{i in W} b_i/a_i < max_{j in R} b_j/a_j
            check(min(B_[i] / A_[i] for i in Wd) < max(B_[j] / A_[j] for j in Rd), 'pair ordering %s%s' % (NAMES[a], NAMES[b]))
        desc = ' > '.join('D%d' % (i + 1) for i in order) + (' (ties %s)' % ties if ties else '')
        print('  pair %s%s: %s' % (NAMES[a], NAMES[b], desc))
        for (wr, who), n in sorted(tys.items()):
            print('      %s answers:  W=%-6s R=%-6s  (%d cells)' % (who, W(wr[0]), W(wr[1]), n))
        Ws = sorted({wr for (wr, who) in tys})
        # implied region for delta = x^b - x^a: intersection over types of max_W > min_R
        perms = [p for p in itertools.permutations(range(3))
                 if all(max(-p.index(i) for i in Wd) > min(-p.index(j) for j in Rd) for Wd, Rd in Ws)]
        print('      strict orderings of delta = x^b - x^a allowed by the type test:',
              ['>'.join(str(i + 1) for i in p) for p in perms])
print('\nALL PASS' if OK else '\nSOME FAIL')
