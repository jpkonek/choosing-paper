"""PP51 Sec. 7.2: does the likelihood witness survive a sixth member?  PP53's four models plus the
inside member E = (64,61,55)/180, plus one candidate F.  Exact (rational P per cell, or an exact Farkas vector).
Run: python3 -I -B sixth51.py > sixth51.out"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from linwit51 import likelihood_witness
from post51 import u_in_Ma
eps = Fr(3, 10)
S = lambda v, den: tuple(Fr(x, den) for x in v)
m4 = [S(v, 30) for v in [(10, 10, 10), (11, 10, 9), (11, 11, 8), (10, 11, 9)]]
m5 = m4 + [S((64, 61, 55), 180)]
NM = 'ABCDEF'
for name, mods in [('A-D', m4), ('A-D + E', m5)] + [('A-D + E + F=%s/%d' % (F, d), m5 + [S(F, d)]) for F, d in
        [((10, 9, 11), 30), ((11, 9, 10), 30), ((12, 10, 8), 30), ((12, 11, 7), 30), ((11, 12, 7), 30),
         ((9, 10, 11), 30), ((10, 12, 8), 30), ((9, 11, 10), 30), ((61, 59, 60), 180)]]:
    assert all(u_in_Ma(eps, a) for a in mods)
    r = likelihood_witness(eps, mods)
    bad = [('answer %s correct %s' % (''.join(NM[k] for k in A), [w + 1 for w in cor]), v[0]) for (A, cor), v in r.items() if v[0] != 'witness']
    print('%-34s cells %3d  likelihood witness: %s' % (name, len(r), 'exists (exact)' if not bad else 'FAILS ' + str(bad)), flush=True)
