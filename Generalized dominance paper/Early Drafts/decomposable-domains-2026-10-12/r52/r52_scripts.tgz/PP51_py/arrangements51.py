"""The two main four-index arrangements of PP51 (exact rationals)."""
from fractions import Fraction as Fr

def idx(d, t):
    return tuple(Fr(1, 3) + t * x for x in d)

EPS = Fr(3, 10)
T = Fr(1, 100)
NAMES = 'ABCD'
ARR = {
    # rectangle with u as a corner; perimeter A-B-C-D-A, diagonals AC, BD
    'R': [idx((0, 0, 0), T), idx((1, -1, 0), T), idx((2, 0, -2), T), idx((1, 1, -2), T)],
    # u at the centre of an equilateral triangle B, C, D
    'Y': [idx((0, 0, 0), T), idx((2, -1, -1), T), idx((-1, 2, -1), T), idx((-1, -1, 2), T)],
}
