"""PP51 Sec. 5.3: kink certificates on candidate kink-free gated sets (exact per triple).
(a) points on one straight line through u; (b) a tripod of three rays from u.
Run: python3 -I -B tripod51.py > tripod51.out"""
import sys, os, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from kink51 import certificate, idx

eps = Fr(3, 10)
t = Fr(1, 400)
sets = {
    'line (1,-1,0)': [idx(tuple(r * x for x in (1, -1, 0)), t) for r in (-3, -1, 0, 1, 2, 5)],
    'line (1,2,-3)': [idx(tuple(r * x for x in (1, 2, -3)), t) for r in (-3, -1, 0, 1, 2, 5)],
    'tripod e_i-directions': [idx((0, 0, 0), t)] + [idx(tuple(r * x for x in d), t) for d in ((2, -1, -1), (-1, 2, -1), (-1, -1, 2)) for r in (1, 4)],
    'tripod -e_i-directions': [idx((0, 0, 0), t)] + [idx(tuple(-r * x for x in d), t) for d in ((2, -1, -1), (-1, 2, -1), (-1, -1, 2)) for r in (1, 4)],
}
for name, pts in sets.items():
    bad = []
    for S in itertools.combinations(range(len(pts)), 3):
        for A in range(3):
            order = [S[A]] + [S[q] for q in range(3) if q != A]
            if certificate(eps, [pts[k] for k in order], 0) is not None:
                bad.append(tuple(order))
    print('%-24s %d points, %d triples: kink-certified (odd, other, other): %s' % (
        name, len(pts), len(list(itertools.combinations(range(len(pts)), 3))), bad if bad else 'none'), flush=True)
