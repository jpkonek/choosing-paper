"""PP51 Sec. 4: explicit four-model gate design with every triple feasible and NO global
constants (no additive endorser) at the stated worlds.  Construction = Theorem P:
  step 1  a global witness (X, Y) with Bayes margin m and strict CG2 margin 1, tight (margin
          exactly 1) on one witness sub-cone per cycle edge and world  [MILP proposes; exact check];
  step 2  per-triple shifts phi (0, s, 2s along each triple's consecutive cycle edges), x^tau = X + phi^tau;
  step 3  fields y = Y + psi with the explicit psi of Theorem P.
The final design is re-verified by verify51.py in exact arithmetic (CHECKED).
Run: python3 -I -B construct51.py > construct51.out"""
import sys, os, itertools, json, math, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import numpy as np
from post51 import *
from prog51 import Prog, TRIPLES
from arrangements51 import *
from verify51 import verify

MARGIN = 40


def subcone_points(g, k, models, eps):
    """k distinct exact points in the same cell as g (small perturbations, checked exactly)."""
    ns = normals(eps, models)
    sv = signvec(ns, g)
    pts = [g]
    dirs = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, -1, 0), (0, 1, -1)]
    i = 0
    while len(pts) < k:
        d = dirs[i % len(dirs)]; i += 1
        eta = Fr(1, 10 ** 6) * i
        while True:
            gg = tuple(g[q] + eta * d[q] for q in range(3))
            if signvec(ns, gg) == sv and gg not in pts:
                pts.append(gg); break
            eta /= 3
    return pts


def global_witness(types, witnesses):
    """types: list of (A,cor,wr).  witnesses: list of (type index, P, Q, w0).  Returns X, Ygen, Ywit."""
    P = Prog()
    B = 400; BIG = 6 * B
    X = {(N, w): (P.var(0, 0) if N == 0 else P.var(-B, B)) for N in range(4) for w in range(3)}
    reps = [(ti, None) for ti in range(len(types))] + [(wt[0], wi) for wi, wt in enumerate(witnesses)]
    Y = {}
    for ri, (ti, wi) in enumerate(reps):
        A, cor, wr = types[ti]
        for N in range(4):
            for w in range(3):
                Y[ri, N, w] = P.var(-B, B)
            dom, oth = (cor, wr) if N in A else (wr, cor)
            if len(dom) == 1:
                for r in oth:
                    P.con({Y[ri, N, dom[0]]: 1, Y[ri, N, r]: -1}, MARGIN, np.inf)
            else:
                b = P.var(0, 1, integer=True)
                for r in oth:
                    P.con({Y[ri, N, dom[0]]: 1, Y[ri, N, r]: -1, b: -BIG}, MARGIN - BIG, np.inf)
                    P.con({Y[ri, N, dom[1]]: 1, Y[ri, N, r]: -1, b: BIG}, MARGIN, np.inf)
        for N in A:
            for M_ in range(4):
                if M_ in A:
                    continue
                for c in cor:
                    P.con({Y[ri, N, c]: 1, Y[ri, M_, c]: -1, X[M_, c]: -1, X[N, c]: 1}, -np.inf, -1)
                for r in wr:
                    P.con({Y[ri, N, r]: 1, Y[ri, M_, r]: -1, X[M_, r]: -1, X[N, r]: 1}, 1, np.inf)
        if wi is not None:
            _, p, q, w0 = witnesses[wi]
            # tight: y_p - y_q = X_q - X_p - 1 at w0
            P.con({Y[ri, p, w0]: 1, Y[ri, q, w0]: -1, X[q, w0]: -1, X[p, w0]: 1}, -1, -1)
    res = P.solve(time_limit=300)
    assert res.status == 0, res.message
    # fix binaries and re-solve as LP, then rationalise and scale to integers
    sol = res.x
    for i in range(P.nv):
        if P.integ[i]:
            v = round(sol[i]); P.lb[i] = v; P.ub[i] = v
    P.integ = [0] * P.nv
    res2 = P.solve(time_limit=300)
    assert res2.status == 0
    vals = [Fr(v).limit_denominator(64) for v in res2.x]
    L = 1
    for v in vals:
        L = L * v.denominator // math.gcd(L, v.denominator)
    iv = [int(v * L) for v in vals]
    Xi = {k: iv[j] for k, j in X.items()}
    Yi = {k: iv[j] for k, j in Y.items()}
    return Xi, Yi, reps, L


def run(name, specs):
    """specs: list of (w0, oriented 4-cycle) -- one per world to be made globally infeasible."""
    eps, models = EPS, ARR[name]
    cs = cells(eps, models)
    alltypes = {}
    for g in cs:
        alltypes.setdefault(cell_type(eps, models, g), g)
    types = [t for t in sorted(alltypes) if 0 < len(t[0]) < 4]
    witnesses = []
    for w0, cycle in specs:
        edges = [(cycle[i], cycle[(i + 1) % 4]) for i in range(4)]
        for p, q in edges:
            cand = [ti for ti, (A, cor, wr) in enumerate(types)
                    if (p in A) != (q in A) and ((w0 in cor) if p in A else (w0 in wr))]
            assert cand, 'no witness cell for edge %s%s at world %d' % (NAMES[p], NAMES[q], w0 + 1)
            witnesses.append((cand[0], p, q, w0))
    X, Y, reps, L = global_witness(types, witnesses)
    print('[%s] step 1: integer global witness found, scale L = %d (CG2 margin L, Bayes margin %d L)' % (name, L, MARGIN))
    # exact check of the global witness itself (as a design with all triples using X)
    s = 3 * L
    phi = {tau: {N: [0, 0, 0] for N in tau} for tau in TRIPLES}
    for w0, cycle in specs:
        for j in range(4):   # triple missing cycle[j]: 0, s, 2s along its consecutive cycle edges
            nodes = [cycle[(j + 1 + i) % 4] for i in range(3)]
            tau = tuple(sorted(nodes))
            for i, N in enumerate(nodes):
                phi[tau][N][w0] = i * s
    xt = {tau: {N: [X[N, w] + phi[tau][N][w] for w in range(3)] for N in tau} for tau in TRIPLES}
    a = s
    design_reps = []
    for ri, (ti, wi) in enumerate(reps):
        A, cor, wr = types[ti]
        y = {}
        for N in range(4):
            y[N] = []
            for w in range(3):
                sgn_ = -1 if (w in cor) == (N in A) else 1   # answerer: -a on Cor, +a on Wr; silent: +a on Cor, -a on Wr
                y[N].append(Y[ri, N, w] + sgn_ * a)
        if wi is not None:
            _, p, q, w0 = witnesses[wi]
            S_ = [k for k in range(4) if k not in A]
            def b_cor(N, M):   # psi_N - psi_M <= b at a correct world
                return min(xt[tau][M][w0] - xt[tau][N][w0] for tau in TRIPLES if N in tau and M in tau) - 1 \
                    - (Y[ri, N, w0] - Y[ri, M, w0])
            def b_wr(N, M):    # psi_N - psi_M >= b at a wrong world
                return max(xt[tau][M][w0] - xt[tau][N][w0] for tau in TRIPLES if N in tau and M in tau) + 1 \
                    - (Y[ri, N, w0] - Y[ri, M, w0])
            psi = {}
            if p in A:      # w0 correct; tight arc p -> q
                psi[q] = 0
                for M in S_:
                    if M != q:
                        psi[M] = max(0, b_cor(p, q) - b_cor(p, M))
                for N in A:
                    psi[N] = min(psi[M] + b_cor(N, M) for M in S_)
            else:           # q answers, p silent, w0 wrong; tight arc q -> p
                psi[q] = 0
                for N in A:
                    if N != q:
                        psi[N] = max(0, b_wr(N, p) - b_wr(q, p))
                for M in S_:
                    psi[M] = min(psi[N] - b_wr(N, M) for N in A)
            for N in range(4):
                y[N][w0] = Y[ri, N, w0] + psi[N]
        design_reps.append((ti, wi, y))
    # attach exact points: generic rep at the cell's point, witness reps on distinct sub-cone points
    used = {}
    reps_out = []
    for ti, wi, y in design_reps:
        g0 = alltypes[types[ti]]
        k = used.get(ti, 0); used[ti] = k + 1
        g = subcone_points(g0, k + 1, models, eps)[k]
        reps_out.append({'g': g, 'y': y, 'type': types[ti], 'wit': None if wi is None else witnesses[wi]})
    # agreement cells: plain own-Bayes fields
    for t, g in alltypes.items():
        if len(t[0]) in (0, 4):
            y = {N: [MARGIN * L if ((w in t[1]) == (len(t[0]) == 4)) else 0 for w in range(3)] for N in range(4)}
            reps_out.append({'g': g, 'y': y, 'type': t, 'wit': None})
    design = {'eps': eps, 'models': models, 'reps': reps_out, 'xt': xt}
    ok, iv, certs = verify(design)
    print('[%s] exact verification (V1-V4, V6):' % name, 'PASS' if ok else 'FAIL')
    print('   global witness constants X (log2, world 1..3):', {NAMES[N]: [X[N, w] for w in range(3)] for N in range(4)})
    print('   triple constants x^tau = X + phi^tau (log2):')
    for tau in TRIPLES:
        print('     %s: %s' % (''.join(NAMES[k] for k in tau), {NAMES[N]: xt[tau][N] for N in tau}))
    for w in range(3):
        row = []
        for N, M in itertools.combinations(range(4), 2):
            lo, hi = iv[(N, M, w)]
            row.append('%s%s [%s, %s]' % (NAMES[N], NAMES[M], '-inf' if lo == 0 else _lg(lo), '+inf' if hi is None else _lg(hi)))
        print('   world %d realised intervals for log2(c_N/c_M): %s' % (w + 1, '; '.join(row)))
    mm = None
    for r in reps_out:
        A, cor, wr = r['type']
        for N in range(4):
            yy = r['y'][N]
            dom, oth = (cor, wr) if N in A else (wr, cor)
            if not dom or not oth:
                continue
            mg = max(yy[d] for d in dom) - max(yy[o] for o in oth)
            mm = mg if mm is None else min(mm, mg)
    print('   min tropical Bayes margin after perturbation (log2): %d (exactness needs >= 2)' % mm)
    for w in range(3):
        c = certs[w]
        if c is None:
            print('   world %d: global constants not excluded by a lower-bound cycle' % (w + 1))
        else:
            cyc, prod = c
            terms = ['log2 lo(%s/%s) = %s' % (NAMES[cyc[i]], NAMES[cyc[(i + 1) % len(cyc)]],
                     _lg(iv[(cyc[i], cyc[(i + 1) % len(cyc)], w)][0])) for i in range(len(cyc))]
            print('   world %d: NO global constants. Certificate: cycle %s, %s; sum = %s > 0' % (
                w + 1, '->'.join(NAMES[k] for k in cyc + (cyc[0],)), '; '.join(terms), _lg(prod)))
    # weights are irrelevant: rescale to random interior lambda and re-verify
    rnd = random.Random(7)
    lam = {}
    for N in range(4):
        v = [Fr(rnd.randint(1, 9)) for _ in range(3)]
        lam[N] = [x / sum(v) for x in v]
    d2 = dict(design)
    d2['lam'] = lam
    # field rescaling l^N_w -> l^N_w / (3 lam_w) cannot be represented by integer y in general;
    # verify instead with the ratio check on rational multiples:
    ok2 = verify_lambda(design, lam)
    print('[%s] same design re-verified at random interior supporting weights (fields and constants rescaled):' % name,
          'PASS' if ok2 else 'FAIL')
    return design, iv, certs, ok and ok2


def _lg(q):
    n, d = q.numerator, q.denominator
    if n & (n - 1) == 0 and d & (d - 1) == 0:
        return str(n.bit_length() - d.bit_length())
    return '%.3f' % math.log2(q)


def verify_lambda(design, lam):
    """Rescale world w of model N by 1/(3 lam_N,w) (fields) and constants by 3 lam_N,w; check lam-Bayes
    and that every CG2 ratio inequality is unchanged (exact)."""
    import verify51
    eps, models = design['eps'], design['models']
    ok = True
    for r in design['reps']:
        g = r['g']; h = g if sum(g) > 0 else tuple(-v for v in g)
        for N in range(4):
            adv = advice(eps, models[N], h)
            L = verify51.complete(r['y'][N], h, adv == 1, [Fr(1, 3)] * 3)
            Ls = {w: {a: L[w][a] / (3 * lam[N][w]) for a in L[w]} for w in range(3)}
            act = 'h' if adv == 1 else 'S'
            val = {a: sum(lam[N][w] * Ls[w][a] for w in range(3)) for a in verify51.ACTS}
            if not all(val[act] < val[b] for b in verify51.ACTS if b != act):
                ok = False
    # CG2: c'_N f'^N = (c_N 3 lam_N)(f^N / (3 lam_N)) = c_N f^N : identical inequalities.
    return ok


if __name__ == '__main__':
    out = {}
    for name in ('R', 'Y'):
        eps, models = EPS, ARR[name]
        types = sorted({cell_type(eps, models, g) for g in cells(eps, models)})
        specs = []
        for w0 in range(3):
            for base in [(0, 1, 2, 3), (0, 1, 3, 2), (0, 2, 1, 3)]:
                for cyc in (base, (base[0], base[3], base[2], base[1])):
                    if all(any((p in A) != (q in A) and ((w0 in cor) if p in A else (w0 in wr)) for A, cor, wr in types)
                           for p, q in [(cyc[i], cyc[(i + 1) % 4]) for i in range(4)]):
                        break
                else:
                    continue
                break
            specs.append((w0, cyc))
        print('[%s] target cycles: %s' % (name, ', '.join('world %d: %s' % (w + 1, '->'.join(NAMES[k] for k in c + (c[0],))) for w, c in specs)))
        design, iv, certs, ok = run(name, specs)
        out[name] = design
        with open('design51_%s.json' % name, 'w') as f:
            json.dump({'eps': str(design['eps']), 'models': [[str(v) for v in a] for a in design['models']],
                       'xt': {''.join(NAMES[k] for k in tau): {NAMES[N]: v for N, v in d.items()} for tau, d in design['xt'].items()},
                       'reps': [{'g': [str(v) for v in r['g']], 'answer': ''.join(NAMES[k] for k in r['type'][0]),
                                 'correct': [w + 1 for w in r['type'][1]],
                                 'witness': None if r['wit'] is None else '%s->%s at world %d' % (NAMES[r['wit'][1]], NAMES[r['wit'][2]], r['wit'][3] + 1),
                                 'y': {NAMES[N]: v for N, v in r['y'].items()}} for r in design['reps']]}, f, indent=1)
        print('[%s] design written to design51_%s.json' % (name, name))
        print('[%s] %s' % (name, 'ALL PASS' if ok else 'SOME FAIL'))
