"""PP51 feasibility programme (tropical / integer form), built with scipy.optimize.milp (HiGHS).

Unknowns (all integers; field values are E = 2^y, constants c = 2^x):
  y[k,t,N,w]  log2 of |l^N_w(h) - l^N_w(S)| on representative k of cell type t;
  x[tau,N,w]  log2 of the CG2 constant of model N at world w used for triple tau
              (mode 'global': one x[N,w] shared by all triples).
Supporting weights are uniform w.l.o.g. (see PP51 Sec. 2: interior weights are forced and
are absorbed into the constants).
Constraints (exact for integers, see verify51.py):
  Bayes (sufficient form with margin m >= 2): an answerer has a correct world c with
      y_c >= y_r + m for all wrong r; a silent model has a wrong world r with y_r >= y_c + m.
      Then sum_cor 2^y > sum_wr 2^y (resp. <) exactly, since at most two terms compete.
  CG2, strict with margin 1, for every pair (N answers, M silent) disagreeing on t and every
      triple tau containing both:  y_N,c - y_M,c <= x_tau,M,c - x_tau,N,c - 1  (c correct),
                                   y_N,r - y_M,r >= x_tau,M,r - x_tau,N,r + 1  (r wrong).
  Cycle (mode 'triple' with cycle): for oriented Hamiltonian cycle P0->P1->P2->P3->P0 at world w0,
      sum_e beta_e >= 1 where beta_e <= y_P,w0 - y_Q,w0 at a selected witness cell type where
      Q is worse than P at w0 (this is a realised lower bound on x_Q - x_P at w0).
"""
import itertools
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds

TRIPLES = [(0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3)]


class Prog:
    def __init__(self):
        self.nv = 0
        self.lb, self.ub, self.integ = [], [], []
        self.rows, self.rlo, self.rhi = [], [], []

    def var(self, lo, hi, integer=False):
        self.lb.append(lo); self.ub.append(hi); self.integ.append(1 if integer else 0)
        self.nv += 1
        return self.nv - 1

    def con(self, coefs, lo, hi):
        self.rows.append(coefs); self.rlo.append(lo); self.rhi.append(hi)

    def solve(self, c=None, time_limit=120):
        A = np.zeros((len(self.rows), self.nv))
        for i, r in enumerate(self.rows):
            for j, v in r.items():
                A[i, j] += v
        cc = np.zeros(self.nv) if c is None else c
        res = milp(cc, constraints=LinearConstraint(A, self.rlo, self.rhi),
                   integrality=np.array(self.integ), bounds=Bounds(self.lb, self.ub),
                   options={'time_limit': time_limit, 'disp': False})
        return res


def build(types, mode='triple', cycle=None, w0=0, reps=1, B=60, m=2, extra=None):
    """types: list of (A, cor, wr) with 0<|A|<4.  cycle: tuple of 4 model indices (oriented)."""
    P = Prog()
    BIG = 6 * B
    x = {}
    if mode == 'global':
        for N in range(4):
            for w in range(3):
                x[N, w] = P.var(-B, B) if not (N == 0) else P.var(0, 0)
        X = lambda tau, N, w: x[N, w]
    else:
        for tau in TRIPLES:
            for N in tau:
                for w in range(3):
                    x[tau, N, w] = P.var(-B, B) if N != tau[0] else P.var(0, 0)
        X = lambda tau, N, w: x[tau, N, w]
    y = {}
    for k in range(reps):
        for ti, (A, cor, wr) in enumerate(types):
            for N in range(4):
                for w in range(3):
                    y[k, ti, N, w] = P.var(-B, B)
                # Bayes
                dom, oth = (cor, wr) if N in A else (wr, cor)
                if len(dom) == 1:
                    for r in oth:
                        P.con({y[k, ti, N, dom[0]]: 1, y[k, ti, N, r]: -1}, m, np.inf)
                else:
                    b = P.var(0, 1, integer=True)
                    # b=1 -> dom[0] dominant, b=0 -> dom[1]
                    for r in oth:
                        P.con({y[k, ti, N, dom[0]]: 1, y[k, ti, N, r]: -1, b: -BIG}, m - BIG, np.inf)
                        P.con({y[k, ti, N, dom[1]]: 1, y[k, ti, N, r]: -1, b: BIG}, m, np.inf)
            # CG2 strict
            for N in A:
                for M_ in range(4):
                    if M_ in A:
                        continue
                    for tau in TRIPLES:
                        if N in tau and M_ in tau:
                            for c in cor:
                                P.con({y[k, ti, N, c]: 1, y[k, ti, M_, c]: -1, X(tau, M_, c): -1, X(tau, N, c): 1}, -np.inf, -1)
                            for r in wr:
                                P.con({y[k, ti, N, r]: 1, y[k, ti, M_, r]: -1, X(tau, M_, r): -1, X(tau, N, r): 1}, 1, np.inf)
    beta = {}
    if cycle is not None:
        edges = [(cycle[i], cycle[(i + 1) % 4]) for i in range(4)]
        tot = {}
        for ei, (p, q) in enumerate(edges):
            k = ei % reps
            cands = []
            for ti, (A, cor, wr) in enumerate(types):
                if (p in A) == (q in A):
                    continue
                qworse = (w0 in cor) if p in A else (w0 in wr)
                if qworse:
                    cands.append(ti)
            if not cands:
                return None, None, None
            be = P.var(-B, B, integer=False)
            zs = []
            for ti in cands:
                z = P.var(0, 1, integer=True)
                zs.append(z)
                P.con({be: 1, y[k, ti, p, w0]: -1, y[k, ti, q, w0]: 1, z: BIG}, -np.inf, BIG)
            P.con({z: 1 for z in zs}, 1, 1)
            tot[be] = 1
            beta[ei] = (be, cands, zs)
        P.con(tot, 1, np.inf)
    return P, x, y


def build_sub(types, S, groups, B=60, m=2):
    """General form: models S (subset of 0..3); groups = list of model-subsets, each with its own
    constants (a pair (N,M) must satisfy CG2 with the constants of every group containing both).
    Types are restricted to S.  Pairs not covered by any group are left unconstrained (but every
    pair of S must lie in some group for a meaningful test)."""
    P = Prog()
    BIG = 6 * B
    x = {}
    for gi, G in enumerate(groups):
        for N in G:
            for w in range(3):
                x[gi, N, w] = P.var(0, 0) if N == G[0] else P.var(-B, B)
    seen = set()
    rtypes = []
    for A, cor, wr in types:
        A2 = tuple(k for k in A if k in S)
        if 0 < len(A2) < len(S) and (A2, cor) not in seen:
            seen.add((A2, cor)); rtypes.append((A2, cor, wr))
    y = {}
    for ti, (A, cor, wr) in enumerate(rtypes):
        for N in S:
            for w in range(3):
                y[ti, N, w] = P.var(-B, B)
            dom, oth = (cor, wr) if N in A else (wr, cor)
            if len(dom) == 1:
                for r in oth:
                    P.con({y[ti, N, dom[0]]: 1, y[ti, N, r]: -1}, m, np.inf)
            else:
                b = P.var(0, 1, integer=True)
                for r in oth:
                    P.con({y[ti, N, dom[0]]: 1, y[ti, N, r]: -1, b: -BIG}, m - BIG, np.inf)
                    P.con({y[ti, N, dom[1]]: 1, y[ti, N, r]: -1, b: BIG}, m, np.inf)
        for N in A:
            for M_ in S:
                if M_ in A:
                    continue
                for gi, G in enumerate(groups):
                    if N in G and M_ in G:
                        for c in cor:
                            P.con({y[ti, N, c]: 1, y[ti, M_, c]: -1, x[gi, M_, c]: -1, x[gi, N, c]: 1}, -np.inf, -1)
                        for r in wr:
                            P.con({y[ti, N, r]: 1, y[ti, M_, r]: -1, x[gi, M_, r]: -1, x[gi, N, r]: 1}, 1, np.inf)
    return P, rtypes
