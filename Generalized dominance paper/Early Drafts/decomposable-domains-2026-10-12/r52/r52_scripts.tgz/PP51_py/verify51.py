"""PP51 exact verifier (Fractions only; no floating point, no LP).

Input: a design = dict with
  eps, models (index vectors), reps: list of {'g': exact interior ray, 'y': {N: [y_1,y_2,y_3]}}
  (y = log2 of |l^N_w(h) - l^N_w(S)| on that sub-cone; integers), 'lam': supporting weights
  (default uniform), and 'xt': {triple: {N: [x_1,x_2,x_3]}} (log2 of the triple's CG2 constants).
The fields are completed on the whole cell (all four advices) by an explicit formula (complete()).
Checks, all exact:
 (V1) strict guidance at every world, and each model the strict unique lam-Bayes act, at every rep;
 (V2) realised pair intervals from the fields (ratio form of CG2; sign agreement);
 (V3) strict pointwise CG2 for every triple's own constants;
 (V4) closed triple test with slack at every world (hence not tight: PP47 Thm 4.1 applies);
 (V5) global constants at each world: Bellman-Ford; a positive cycle of lower bounds is printed
      as the Farkas certificate (multipliers 1 on four interval rows);
 (V6) every model has two-signed moves at each world (so no zero endorser constants).
"""
import itertools
from fractions import Fraction as Fr
from post51 import advice, mverts, dot, had

TRIPLES = [(0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3)]
ACTS = ('h', 'S', '-h', 'X')


def pw2(k):
    return Fr(2) ** k


def complete(y, h, answering, lam, mag=None):
    """Full field l_w(a) for a in ACTS at a point with common answer h.  y: log2 |e_w| (or mag: the
    magnitudes |e_w| themselves, exact rationals).
    l(S) = 0; l(h) = -sign(h_w) |e_w|; l(-h) = +K at worlds where h correct, -1/K where wrong;
    l(X) = max + 1.  With K = 16 max(|e|, 1/|e|)/min lam this gives strict guidance, -h never optimal
    (lam interior), X never optimal."""
    if mag is None:
        mag = [pw2(v) for v in y]
    lmin = min(lam)
    K = 16 * max(max(m, 1 / m) for m in mag) / lmin
    L = {}
    for w in range(3):
        cor = h[w] > 0
        lh = -mag[w] if cor else mag[w]
        lmh = K if cor else -1 / K
        L[w] = {'h': lh, 'S': Fr(0), '-h': lmh, 'X': max(lh, lmh, Fr(0)) + 1}
    return L


def rank(h, w, a):
    cor = h[w] > 0
    return {'h': 0 if cor else 2, 'S': 1, '-h': 2 if cor else 0, 'X': 3}[a]


def verify(design, worlds=(0, 1, 2), log=print):
    eps, models, reps = design['eps'], design['models'], design['reps']
    nm = len(design['models'])
    lam = design.get('lam', {N: [Fr(1, 3)] * 3 for N in range(nm)})
    xt = design.get('xt')
    ok = True

    def fail(msg):
        nonlocal ok
        ok = False
        log('FAIL ' + msg)
    fields = []
    for r in reps:
        g = r['g']
        h = g if sum(g) > 0 else tuple(-v for v in g)
        adv = [advice(eps, a, h) for a in models]
        if any(v not in (0, 1) for v in adv):
            fail('not two-valued')
        F = {}
        for N in range(len(models)):
            act = 'h' if adv[N] == 1 else 'S'
            L = complete(r.get('y', {}).get(N), h, adv[N] == 1, lam[N], mag=r['E'][N] if 'E' in r else None)
            for w in range(3):  # (V1) guidance
                for a, b in itertools.permutations(ACTS, 2):
                    if rank(h, w, a) < rank(h, w, b) and not L[w][a] < L[w][b]:
                        fail('guidance')
            val = {a: sum(lam[N][w] * L[w][a] for w in range(3)) for a in ACTS}
            if not all(val[act] < val[b] for b in ACTS if b != act):
                fail('Bayes rep %s model %d' % (str(g), N))
            F[N] = (act, L)
        fields.append((h, F))
    # (V2) realised intervals for r = c_N / c_M at each world:  lo <= r <= hi
    iv = {}
    twosign = {(N, w): set() for N in range(nm) for w in range(3)}
    for N, M in itertools.permutations(range(nm), 2):
        for w in range(3):
            lo, hi = Fr(0), None
            for h, F in fields:
                aN, LN = F[N]
                aM, LM = F[M]
                if aN == aM:
                    continue
                fN = LN[w][aM] - LN[w][aN]
                fM = LM[w][aM] - LM[w][aN]
                if (fN > 0) != (fM > 0):
                    fail('sign disagreement')
                twosign[(N, w)].add(fN > 0)
                q = fM / fN
                if fN > 0:
                    hi = q if hi is None else min(hi, q)
                else:
                    lo = max(lo, q)
            iv[(N, M, w)] = (lo, hi)
            if hi is not None and lo > hi:
                fail('empty pair interval %d%d w%d' % (N, M, w))
    # (V3) strict CG2 with each triple's constants (skipped when no triple constants are supplied)
    ct = design.get('ct')      # optional: exact rational constants {tau: {N: [c_1,c_2,c_3]}}
    trip = design.get('triples', TRIPLES)
    for tau in (trip if (xt is not None or ct is not None) else []):
        for N, M in itertools.permutations(tau, 2):
            for w in range(3):
                if ct is not None:
                    cN, cM = ct[tau][N][w], ct[tau][M][w]
                else:
                    cN, cM = pw2(xt[tau][N][w]), pw2(xt[tau][M][w])
                for h, F in fields:
                    aN, LN = F[N]
                    aM, LM = F[M]
                    if aN == aM:
                        continue
                    fN = LN[w][aM] - LN[w][aN]
                    fM = LM[w][aM] - LM[w][aN]
                    if not cN * fN < cM * fM:
                        fail('CG2 triple %s pair %d%d w%d' % (tau, N, M, w))
    # (V4) triple test with slack, via the realised intervals, both orientations
    for tau in itertools.combinations(range(nm), 3):
        for w in range(3):
            for cyc in (tau, (tau[0], tau[2], tau[1])):
                los = [iv[(cyc[i], cyc[(i + 1) % 3], w)][0] for i in range(3)]
                his = [iv[(cyc[i], cyc[(i + 1) % 3], w)][1] for i in range(3)]
                if not (los[0] * los[1] * los[2] < 1):
                    fail('triple lower %s w%d' % (cyc, w))
                if not any(v is None for v in his) and not (his[0] * his[1] * his[2] > 1):
                    fail('triple upper %s w%d' % (cyc, w))
    # (V5) global constants at each world: need log c_N - log c_M in [log lo, log hi]; detect a
    # cycle N0->N1->...->N0 with prod lo > 1 (equivalently a negative cycle).
    certs = {}
    for w in worlds:
        best = None
        for k in range(3, nm + 1):
          for cyc in itertools.permutations(range(nm), k):
                if cyc[0] != min(cyc):
                    continue
                p = Fr(1)
                for i in range(len(cyc)):
                    p *= iv[(cyc[i], cyc[(i + 1) % len(cyc)], w)][0]
                if p > 1 and (best is None or p > best[1]):
                    best = (cyc, p)
        # also cycles avoiding model 0 are triples, already excluded by (V4)
        certs[w] = best
    # (V6)
    for (N, w), s in twosign.items():
        if s != {True, False}:
            fail('model %d one-signed at world %d' % (N, w))
    return ok, iv, certs
