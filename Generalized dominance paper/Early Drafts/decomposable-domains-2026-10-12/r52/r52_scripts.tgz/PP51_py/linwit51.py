"""PP51 Sec. 3: the likelihood witness.  By Lemma G, global constants c^N = 1/N (omega = index) work
for a four-model arrangement iff every realised cell (answer set A, sign pattern sigma) admits P > 0 with
(sigma o P).N > 0 for N answering and < 0 for N silent.  For each cell an LP proposes P (floats); P is
rationalised and the strict inequalities are re-checked in exact arithmetic (CHECKED when it succeeds).
A failure is certified by an exact Farkas vector (Gordan): gamma >= 0 on the sign rows and alpha >= 0 on the
model rows with sum_k alpha_k s_k N_k = - sum_w gamma_w sigma_w e_w, rationalised and re-checked."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import linprog
from post51 import *


def cell_P(models, A, cor):
    sig = [1 if w in cor else -1 for w in range(3)]
    k = len(models)
    Aub, bub = [], []
    for w in range(3):
        r = [0, 0, 0, 1.0]; r[w] = -1.0; Aub.append(r); bub.append(0)
    for N in range(k):
        s = 1 if N in A else -1
        nn = np.array([float(x) for x in models[N]]); nn /= np.linalg.norm(nn)
        Aub.append([-s * sig[w] * nn[w] for w in range(3)] + [1.0]); bub.append(0)
    r = linprog([0, 0, 0, -1], A_ub=Aub, b_ub=bub, A_eq=[[1, 1, 1, 0]], b_eq=[1], bounds=[(0, 1)] * 3 + [(None, 1)], method='highs')
    t = -r.fun
    if t > 1e-9:
        for den in (10 ** 4, 10 ** 6, 10 ** 9):
            P = [Fr(x).limit_denominator(den) for x in r.x[:3]]
            if all(p > 0 for p in P) and all(
                    (1 if N in A else -1) * sum(sig[w] * P[w] * models[N][w] for w in range(3)) > 0 for N in range(k)):
                return ('witness', P)
        return ('float-only', None)
    # Farkas: find gamma, alpha >= 0, sum = 1, with sum_N alpha_N s_N sig o N + gamma = 0 (componentwise in sigma-coords)
    # i.e. for each w: sig_w * (sum_N alpha_N s_N N_w) + gamma_w = 0
    nv = 3 + k
    Aeq = []
    for w in range(3):
        Aeq.append([1.0 if q == w else 0.0 for q in range(3)] + [sig[w] * (1 if N in A else -1) * float(models[N][w]) for N in range(k)])
    Aeq.append([1.0] * nv)
    r2 = linprog(np.zeros(nv), A_eq=Aeq, b_eq=[0, 0, 0, 1], bounds=[(0, None)] * nv, method='highs')
    if r2.status != 0:
        return ('undecided', None)
    # exact: solve for gamma from alpha exactly
    for den in (10 ** 4, 10 ** 6, 10 ** 9):
        al = [Fr(x).limit_denominator(den) for x in r2.x[3:]]
        gam = [-sig[w] * sum(al[N] * (1 if N in A else -1) * models[N][w] for N in range(k)) for w in range(3)]
        if all(a >= 0 for a in al) and any(a > 0 for a in al) and all(g >= 0 for g in gam):
            return ('farkas', al)
    return ('undecided', None)


def likelihood_witness(eps, models):
    types = sorted({cell_type(eps, models, g) for g in cells(eps, models)})
    res = {}
    for A, cor, wr in types:
        if 0 < len(A) < len(models):
            res[(A, cor)] = cell_P(models, A, cor)
    return res


if __name__ == '__main__':
    from arrangements51 import ARR, EPS, NAMES
    from kink51 import idx
    tk = Fr(1, 400)
    cases = dict(ARR)
    for L in (4, 6, 8):
        cases['kite%d' % L] = [idx((0, 0, 0), tk), idx((2, -1 + L, -1 - L), tk), idx((4, -2, -2), tk), idx((2, -1 - L, -1 + L), tk)]
    for eps in (Fr(1, 10), EPS, Fr(1, 2)):
        for name, models in cases.items():
            res = likelihood_witness(eps, models)
            bad = [(A, cor, v[0]) for (A, cor), v in res.items() if v[0] != 'witness']
            ok = not bad
            print('eps=%-5s %-6s likelihood witness (c^N = 1/N): %s%s' % (
                eps, name, 'EXISTS (exact, all %d cells)' % len(res) if ok else 'FAILS',
                '' if ok else ' at ' + '; '.join('answer %s correct %s [%s]' % (''.join(NAMES[k] for k in A), [w + 1 for w in cor], s) for A, cor, s in bad)))
