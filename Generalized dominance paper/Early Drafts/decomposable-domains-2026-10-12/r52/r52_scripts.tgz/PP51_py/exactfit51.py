"""PP51 Sec. 7 (continuum question): exact-Bayes field LP for FIXED rational constants, any number of
members.  Constants: likelihood prices times a discrete vortex,
    c^tau_{N,w} = q^(k_tau(N) [w = w0]) / N_w,
where k_tau(N) in {0,1,2} is N's position in tau after the largest angular gap of tau's indices seen from
the centre o of the 4-cycle.  For each cell the LP minimises the field ratio K (all magnitudes in [1, K]),
subject to strict own-Bayes at uniform weight (margin beta), strict CG2 against every triple's constants
(factor 1 -/+ eta, eta = 1e-5), and, on one extra witness sub-cone per cycle edge, tightness to within (1 - eta).
The LP proposes; magnitudes are rationalised and the whole design is re-verified by verify51 (exact):
guidance, strict own-Bayes, strict CG2 for every triple, closed triple test with slack for every triple,
and the global-constant certificate.  The width budget (PP53 Lemma 3.4) is read off the exact intervals.
Run: python3 -I -B exactfit51.py > exactfit51.out"""
import sys, os, itertools, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import linprog
from post51 import *
from verify51 import verify

ETA = 1e-5
_CELLS = {}
BETA = 1e-6


def plane(a):
    # orthonormal-ish 2-D coordinates of an index (only angles are used)
    x = float(a[0] - a[1]) / math.sqrt(2)
    y = float(a[0] + a[1] - 2 * a[2]) / math.sqrt(6)
    return x, y


def vortex_ranks(models, cycle):
    n = len(models)
    ox = sum(plane(models[k])[0] for k in cycle) / 4
    oy = sum(plane(models[k])[1] for k in cycle) / 4
    ang = [math.atan2(plane(a)[1] - oy, plane(a)[0] - ox) % (2 * math.pi) for a in models]
    # orientation: the cycle order must be increasing angle
    ks = {}
    for tau in itertools.combinations(range(n), 3):
        order = sorted(tau, key=lambda k: ang[k])
        gaps = [((ang[order[(i + 1) % 3]] - ang[order[i]]) % (2 * math.pi), i) for i in range(3)]
        g, i = max(gaps)
        start = (i + 1) % 3
        seq = [order[(start + r) % 3] for r in range(3)]
        ks[tau] = {seq[r]: r for r in range(3)}
    return ks, ang


def solve_cell(models, A, cor, wr, ct, triples_of, wit=None):
    """min K; variables E[N][w] (n*3) and K.  wit = (P, Q, w0, target) with E^P/E^Q >= target."""
    n = len(models)
    nv = 3 * n + 1
    iK = 3 * n
    v = lambda N, w: 3 * N + w
    Aub, bub = [], []
    def le(coefs, b):
        row = np.zeros(nv)
        for j, c in coefs.items():
            row[j] += c
        Aub.append(row); bub.append(b)
    for N in range(n):
        for w in range(3):
            le({v(N, w): -1}, -1)
            le({v(N, w): 1, iK: -1}, 0)
        good, bad = (cor, wr) if N in A else (wr, cor)
        # sum_good E - sum_bad E >= BETA * sum E
        co = {}
        for w in good:
            co[v(N, w)] = co.get(v(N, w), 0) - (1 - BETA)
        for w in bad:
            co[v(N, w)] = co.get(v(N, w), 0) + (1 + BETA)
        le(co, 0)
    for N in A:
        for M in range(n):
            if M in A:
                continue
            for tau in triples_of[(min(N, M), max(N, M))]:
                for w in range(3):
                    cN, cM = float(ct[tau][N][w]), float(ct[tau][M][w])
                    if w in cor:   # cN E^N <= (1-eta) cM E^M
                        le({v(N, w): cN, v(M, w): -(1 - ETA) * cM}, 0)
                    else:          # cN E^N >= (1+eta) cM E^M
                        le({v(N, w): -cN, v(M, w): (1 + ETA) * cM}, 0)
    if wit is not None:
        P, Q, w0, target = wit
        le({v(P, w0): -1, v(Q, w0): target}, 0)
    c = np.zeros(nv); c[iK] = 1
    r = linprog(c, A_ub=np.array(Aub), b_ub=np.array(bub), bounds=[(1, None)] * nv, method='highs')
    if r.status != 0:
        return None, None
    return r.x[iK], {N: [r.x[v(N, w)] for w in range(3)] for N in range(n)}


def design(name, eps, models, cycle, w0, q, verbose=True, exact=True):
    n = len(models)
    assert all(u_in_Ma(eps, a) for a in models)
    ks, ang = vortex_ranks(models, cycle)
    triples = list(itertools.combinations(range(n), 3))
    ct = {tau: {N: [Fr(q) ** (ks[tau][N] if w == w0 else 0) / models[N][w] for w in range(3)] for N in tau} for tau in triples}
    triples_of = {}
    for tau in triples:
        for N, M in itertools.combinations(tau, 2):
            triples_of.setdefault((N, M), []).append(tau)
    key = (eps, tuple(models))
    if key not in _CELLS:
        _CELLS[key] = [(g, cell_type(eps, models, g)) for g in cells(eps, models)]
    cell_list = _CELLS[key]
    reps, Kmax = [], 1.0
    for g, (A, cor, wr) in cell_list:
        if 0 < len(A) < n:
            K, E = solve_cell(models, A, cor, wr, ct, triples_of)
            if K is None:
                return {'name': name, 'status': 'cell LP infeasible', 'cell': (A, cor)}
            Kmax = max(Kmax, K)
        else:
            E = {N: [100.0 if ((w in cor) == (len(A) == n)) else 1.0 for w in range(3)] for N in range(n)}
        reps.append((g, E))
    # witnesses: for each oriented cycle edge (increasing angle) P -> Q, a cell where Q is worse than P at w0;
    # target = (1 - eta) min_tau c^tau_Q / c^tau_P  (the realised lower bound on c_Q/c_P)
    edges = [(cycle[i], cycle[(i + 1) % 4]) for i in range(4)]
    wits = []
    for P, Q in edges:
        target = (1 - 2 * ETA) * min(float(ct[tau][Q][w0] / ct[tau][P][w0]) for tau in triples_of[(min(P, Q), max(P, Q))])
        best = None
        for g, (A, cor, wr) in cell_list:
            if (P in A) == (Q in A):
                continue
            if not ((w0 in cor) if P in A else (w0 in wr)):
                continue
            K, E = solve_cell(models, A, cor, wr, ct, triples_of, wit=(P, Q, w0, target))
            if K is not None and (best is None or K < best[0]):
                best = (K, g, E)
        if best is None:
            return {'name': name, 'status': 'no witness for edge %d%d' % (P, Q)}
        Kmax = max(Kmax, best[0])
        # a distinct exact point in the same cell
        from construct51 import subcone_points
        g2 = subcone_points(best[1], 2, models, eps)[1]
        reps.append((g2, best[2]))
    if not exact:
        return {'name': name, 'status': 'ok', 'logK': math.log(Kmax)}
    # rationalise and verify exactly
    out = []
    for g, E in reps:
        out.append({'g': g, 'E': {N: [Fr(x).limit_denominator(10 ** 7) for x in E[N]] for N in range(n)}})
    d = {'eps': eps, 'models': models, 'reps': out, 'ct': ct, 'triples': triples}
    ok, iv, certs = verify(d, log=(lambda m: None))
    res = {'name': name, 'status': 'ok', 'exact': ok, 'logK': math.log(Kmax), 'iv': iv, 'certs': certs, 'n': n}
    c = certs[w0]
    res['deficit'] = math.log(c[1]) if c else None
    # width budget: for each extra member F, sum of widths of I(X_i,F) at w0 over cycle members
    wb = {}
    for F in range(n):
        if F in cycle:
            continue
        tot = 0.0
        for X in cycle:
            lo, hi = iv[(X, F, w0)]
            tot += (math.inf if (lo == 0 or hi is None) else math.log(hi) - math.log(lo))
        wb[F] = tot
    res['widths'] = wb
    return res


def idx30(v, den=30):
    return tuple(Fr(x, den) for x in v)


if __name__ == '__main__':
    eps = Fr(3, 10)
    base = [(10, 10, 10), (11, 10, 9), (11, 11, 8), (10, 11, 9)]      # PP53's four models (x 1/30)
    print('PP53 configuration, cycle A->B->C->D->A at world 1; constants = likelihood x vortex step q.')
    print('For each member set: the largest step q (bisection on log q) for which every cell LP is feasible,')
    print('then an exactly verified design at that step and at half of it.  logK = log of the largest')
    print('within-cell field ratio needed; widths = sum over the cycle members X of width I(X,F) at world 1.')
    for label, scale in (('size 1/30', 1), ('size 1/300', 10)):
        S = lambda v, den=30: tuple(Fr(1, 3) + (Fr(x, den) - Fr(1, 3)) / scale for x in v)
        mods4 = [S(v) for v in base]
        mods5 = mods4 + [S((64, 61, 55), 180)]      # strictly inside the parallelogram, on no line through two members
        mods6 = mods5 + [S((61, 59, 60), 180)]      # outside, next to u (keeps the likelihood witness)
        for nm, mods in (('4 members', mods4), ('+ inside E', mods5), ('+ inside E + outside F', mods6)):
            lo, hi = 0.0, 0.08
            if design(nm, eps, mods, (0, 1, 2, 3), 0, Fr(math.exp(hi)).limit_denominator(10 ** 6), exact=False)['status'] == 'ok':
                lo = hi
            else:
                for _ in range(10):
                    mid = (lo + hi) / 2
                    r = design(nm, eps, mods, (0, 1, 2, 3), 0, Fr(math.exp(mid)).limit_denominator(10 ** 6), exact=False)
                    if r['status'] == 'ok':
                        lo = mid
                    else:
                        hi = mid
            print('  %-10s %-24s max feasible log q in [%.5f, %.5f]' % (label, nm, lo, hi), flush=True)
            for f in (1.0, 0.5):
                if lo == 0:
                    break
                q = Fr(math.exp(lo * f)).limit_denominator(10 ** 6)
                r = design(nm, eps, mods, (0, 1, 2, 3), 0, q)
                if r['status'] != 'ok':
                    print('      log q=%.5f: %s' % (lo * f, r['status'])); continue
                print('      log q=%.5f exact=%s deficit(w1)=%s logK=%.3f widths: %s' % (
                    lo * f, r['exact'], 'none' if r['deficit'] is None else '%.5f' % r['deficit'], r['logK'],
                    {('ABCDEF'[F]): ('%.4f' % w) for F, w in r['widths'].items()}), flush=True)
