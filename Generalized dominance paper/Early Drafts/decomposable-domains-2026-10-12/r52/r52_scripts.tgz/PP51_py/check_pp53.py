"""PP51 Sec. 7: independent exact check of PP53 Thm 3.3 (four posterior models with no global prices).
Takes from PP53 only the DATA in four_model_solution.json (indices, field magnitudes per point type and
world, supporting weights; floats read as their exact binary values, as PP53 does).  Everything else is
PP51's own code: exact cell enumeration (post51.cells), my field completion, guidance and strict own-Bayes,
realised CG2 intervals from the full fields, closed triple test with slack, global-constant certificate
(verify51), plus the kink certificate (kink51) and the likelihood witness (linwit51) on the same models.
Run: python3 -I -B check_pp53.py [path-to-json] > check_pp53.out"""
import sys, os, json, math, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from post51 import *
from verify51 import verify
from kink51 import certificate
from linwit51 import likelihood_witness

path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'PP53_py', 'four_model_solution.json')
sol = json.load(open(path))
NM = ['A', 'B', 'C', 'D']
eps = Fr(3, 10)
models = [tuple(Fr(q) for q in sol['idx'][N]) for N in NM]
mag = {}
for key, val in sol['phi'].items():
    N, P, R, w = json.loads(key)
    mag[(N, tuple(P), tuple(R), w)] = Fr(math.exp(val))
lam = {}
for key, val in sol['ll'].items():
    N, w = json.loads(key)
    lam[(N, w)] = Fr(math.exp(val))
lamn = {k: [lam[(NM[k], w)] / sum(lam[(NM[k], q)] for q in range(3)) for w in range(3)] for k in range(4)}
OK = True
print('models:', [[str(v) for v in a] for a in models])
print('two-valued (u in every M_a):', all(u_in_Ma(eps, a) for a in models))
cs = cells(eps, models)
mytypes = {}
for g in cs:
    mytypes.setdefault(cell_type(eps, models, g), []).append(g)
mine = {(tuple(NM[k] for k in A), cor) for (A, cor, wr) in mytypes if 0 < len(A) < 4}
theirs = {(tuple(P), tuple(R)) for P, R in sol['types']}
print('disagreement cell types: mine %d, PP53 %d, identical: %s' % (len(mine), len(theirs), mine == theirs))
OK &= mine == theirs
reps = []
for (A, cor, wr), gs in mytypes.items():
    P = tuple(NM[k] for k in A)
    for g in gs:            # every cell (not just one per type) carries the type's field
        if 0 < len(A) < 4:
            E = {k: [mag[(NM[k], P, cor, w)] for w in range(3)] for k in range(4)}
        else:               # agreement cells: any own-Bayes field at the model's weight
            E = {k: [(Fr(100) if ((w in cor) == (len(A) == 4)) else Fr(1)) / lamn[k][w] for w in range(3)] for k in range(4)}
        reps.append({'g': g, 'E': E})
ok, iv, certs = verify({'eps': eps, 'models': models, 'reps': reps, 'lam': lamn, 'xt': None}, log=print)
OK &= ok
print('guidance, strict own-Bayes at PP53 weights, nonempty intervals, closed triple test with slack, two-signedness:', 'PASS' if ok else 'FAIL')
for w in range(3):
    row = []
    for N, M in itertools.combinations(range(4), 2):
        lo, hi = iv[(N, M, w)]
        row.append('%s%s [%s, %s]' % (NM[N], NM[M], '-inf' if lo == 0 else '%.4f' % math.log(lo), '+inf' if hi is None else '%.4f' % math.log(hi)))
    c = certs[w]
    print('world %d  log(c_N/c_M): %s' % (w + 1, '; '.join(row)))
    print('   ', 'NO global constants: cycle %s, product of lower bounds = exp(%.4f) > 1' % (
        '->'.join(NM[k] for k in c[0] + (c[0][0],)), math.log(c[1])) if c else 'global constants not excluded')
print('kink certificates on its triples:', sum(1 for S in itertools.combinations(range(4), 3) for A in range(3)
                                              if certificate(eps, [models[k] for k in S], A) is not None))
lw = likelihood_witness(eps, models)
print('likelihood witness c^N = 1/N:', 'exists (exact)' if all(v[0] == 'witness' for v in lw.values()) else 'fails')
print('ALL PASS' if OK else 'SOME FAIL')
