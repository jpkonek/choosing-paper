"""PP51 Sec. 5.3: likelihood witness versus kink certificates on the survey arrangements (exact both ways
where decided).  Run: python3 -I -B compare51.py > compare51.out"""
import sys, os, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from post51 import *
from kink51 import certificate, idx
from linwit51 import likelihood_witness
from arrangements51 import ARR

def arrangements():
    t = Fr(1, 100); tk = Fr(1, 400)
    arrs = dict(ARR)
    for L in (4, 6, 8):
        arrs['kite%d' % L] = [idx((0, 0, 0), tk), idx((2, -1 + L, -1 - L), tk), idx((4, -2, -2), tk), idx((2, -1 - L, -1 + L), tk)]
    random.seed(51)
    for k in range(12):
        ds = []
        while len(ds) < 3:
            a, b = random.randint(-6, 6), random.randint(-6, 6)
            d = (a, b, -a - b)
            if d != (0, 0, 0) and d not in ds:
                ds.append(d)
        arrs['rand%d' % k] = [idx((0, 0, 0), t)] + [idx(d, t) for d in ds]
    return arrs

if __name__ == '__main__':
    for eps in (Fr(1, 10), Fr(3, 10), Fr(1, 2)):
        for name, models in arrangements().items():
            if not all(u_in_Ma(eps, a) for a in models):
                continue
            lw = likelihood_witness(eps, models)
            status = {v[0] for v in lw.values()}
            lws = 'exists' if status == {'witness'} else ('FAILS (Farkas)' if 'farkas' in status else 'undecided ' + str(status))
            kinks = []
            for S in itertools.combinations(range(4), 3):
                for A in range(3):
                    if certificate(eps, [models[k] for k in S], A) is not None:
                        kinks.append(''.join('ABCD'[S[q]] for q in [A] + [q for q in range(3) if q != A]))
            print('eps=%-5s %-7s likelihood witness: %-15s kink-obstructed triples (odd model first): %s' % (
                eps, name, lws, kinks if kinks else 'none'), flush=True)
