"""PP51 Sec. 5 scan: where does the kink certificate occur?  CHECKED (exact) per instance.
Triples A = u, B = u + t(m + v), D = u + t(m - v), v = L(0,1,-1) (B, D far apart along e2 - e3),
m = midpoint offset.  Also the scale t.  Run: python3 -I -B kinkscan51.py > kinkscan51.out"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from post51 import u_in_Ma
from kink51 import certificate, idx

for eps in (Fr(1, 10), Fr(3, 10), Fr(1, 2)):
    for m in ((2, -1, -1), (-2, 1, 1), (1, 0, -1), (0, 0, 0)):
        row = []
        for L in (1, 2, 3, 4, 5, 6, 8, 12, 16, 24, 32):
            t = Fr(1, 100 * L)
            mod = [idx((0, 0, 0), t), idx(tuple(m[q] + L * (0, 1, -1)[q] for q in range(3)), t),
                   idx(tuple(m[q] - L * (0, 1, -1)[q] for q in range(3)), t)]
            if not all(u_in_Ma(eps, a) for a in mod):
                row.append('-'); continue
            row.append('K' if certificate(eps, mod, 0) is not None else '.')
        print('eps=%-5s m=%-12s L=1,2,3,4,5,6,8,12,16,24,32: %s' % (eps, m, ' '.join(row)), flush=True)
# scale independence for one obstructed shape
for t in (Fr(1, 400), Fr(1, 4000), Fr(1, 40000)):
    mod = [idx((0, 0, 0), t), idx((2, 7, -9), t), idx((2, -9, 7), t)]
    print('scale t=%s, kite8 triple, eps=3/10: %s' % (t, 'K' if certificate(Fr(3, 10), mod, 0) else '.'), flush=True)
