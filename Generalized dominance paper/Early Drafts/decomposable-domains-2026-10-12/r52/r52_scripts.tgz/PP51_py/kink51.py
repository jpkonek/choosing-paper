"""PP51 Sec. 5: the kink obstruction (Theorem K) -- exact certificate that a triple of posterior
models admits NO own-Bayes fields passing the closed triple test with positive constants.
Certificate data (all exact, from the cell enumeration of post51):
  (K1) a lone world i (j, k the others) and two non-null cells in which model A is the odd one out
       (alone answering or alone silent), with h having a lone sign at world i, of opposite kinds:
       'above' = (A answers, h_i < 0) or (A silent, h_i > 0);  'below' = the other two cases;
  (K2) the pair type sets of (A,B) and (A,D) force, for every admissible constant vector,
       z^B_j >= z^A_j >= z^D_j (or the reverse), where z^N_j = omega^N_j / omega^N_i;
       admissibility = the exact pair type test  max_W delta > min_R delta  (delta = log omega^a - log omega^b),
       checked on all 13 weak orders of (delta_1, delta_2, delta_3);
  (K3) every pair is two-signed at every world, so admissible constants are positive.
Run: python3 -I -B kink51.py > kink51.out"""
import sys, os, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from post51 import *

WEAK = []
for vals in itertools.product(range(3), repeat=3):
    s = sorted(set(vals))
    if s == list(range(len(s))):
        WEAK.append(vals)          # 13 weak orders as rank vectors


def admissible(types_wr):
    return [d for d in WEAK if all(max(d[w] for w in W) > min(d[r] for r in R) for W, R in types_wr)]


def pair_types(tys, a, b):
    out = set()
    for t in tys:
        wr = pair_WR(t, a, b)
        if wr is not None:
            out.add(wr)
    return sorted(out)


def certificate(eps, models, A=0):
    """models: 3 indices; returns a certificate dict or None."""
    cs = cells(eps, models)
    tys = sorted({cell_type(eps, models, g) for g in cs})
    B, D = [k for k in range(3) if k != A]
    # (K3) two-signedness
    for a, b in itertools.combinations(range(3), 2):
        pts = pair_types(tys, a, b)
        for w in range(3):
            if not (any(w in W for W, R in pts) and any(w in R for W, R in pts)):
                return None
    adm_AB = admissible(pair_types(tys, A, B))
    adm_AD = admissible(pair_types(tys, A, D))
    for i in range(3):
        j, k = [w for w in range(3) if w != i]
        above, below = [], []
        for t in tys:
            Aset, cor, wr = t
            lone = (cor == (i,)) or (wr == (i,))
            if not lone:
                continue
            hi_neg = i in wr
            if Aset == (A,):
                (above if hi_neg else below).append(t)
            elif set(Aset) == {B, D}:
                (below if hi_neg else above).append(t)
        if not above or not below:
            continue
        for jj in (j, k):
            # z^B_jj >= z^A_jj  <=>  delta^{AB}_jj <= delta^{AB}_i   (rank vectors: larger = bigger)
            sB = {(d[jj] > d[i]) - (d[jj] < d[i]) for d in adm_AB}
            sD = {(d[jj] > d[i]) - (d[jj] < d[i]) for d in adm_AD}
            if (sB <= {-1, 0} and sD <= {1, 0}) or (sB <= {1, 0} and sD <= {-1, 0}):
                return {'i': i, 'j': jj, 'above': above[0], 'below': below[0],
                        'adm_AB': adm_AB, 'adm_AD': adm_AD}
    return None


def idx(d, t):
    return tuple(Fr(1, 3) + t * x for x in d)


def show(name, eps, models, A=0):
    c = certificate(eps, models, A)
    nm = 'ABD'
    if c is None:
        print('%-34s eps=%-5s no kink certificate' % (name, eps))
        return False
    f = lambda t: 'answer %s correct %s' % (''.join(nm[k] for k in t[0]) or '-', '{' + ','.join(str(w + 1) for w in t[1]) + '}')
    print('%-34s eps=%-5s KINK OBSTRUCTION: lone world %d, coordinate z_%d; above-cell [%s]; below-cell [%s]' % (
        name, eps, c['i'] + 1, c['j'] + 1, f(c['above']), f(c['below'])))
    o = lambda d: '>'.join(''.join(str(w + 1) for w in range(3) if d[w] == r) for r in sorted(set(d), reverse=True))
    print('      admissible weak orders of delta^AB = log(w^A/w^B): %s ; of delta^AD: %s' % (
        [o(d) for d in c['adm_AB']], [o(d) for d in c['adm_AD']]))
    return True


if __name__ == '__main__':
    tk = Fr(1, 400)
    for eps in (Fr(1, 10), Fr(3, 10), Fr(1, 2)):
        show('kite8 triple (u; u+(2,7,-9)t; u+(2,-9,7)t)', eps, [idx((0, 0, 0), tk), idx((2, 7, -9), tk), idx((2, -9, 7), tk)])
        show('kite4 triple (u; u+(2,3,-5)t; u+(2,-5,3)t)', eps, [idx((0, 0, 0), tk), idx((2, 3, -5), tk), idx((2, -5, 3), tk)])
        show('collinear along e2-e3', eps, [idx((0, 0, 0), tk), idx((0, 1, -1), tk), idx((0, -1, 1), tk)])
        show('collinear along (2,-1,-1)', eps, [idx((0, 0, 0), tk), idx((2, -1, -1), tk), idx((-2, 1, 1), tk)])
        show('collinear along (1,2,-3)', eps, [idx((0, 0, 0), tk), idx((1, 2, -3), tk), idx((-1, -2, 3), tk)])
    # the two checkpoint arrangements: no triple carries the certificate (any odd model)
    from arrangements51 import ARR, EPS
    for name, models in ARR.items():
        hits = 0
        for S in itertools.combinations(range(4), 3):
            for A in range(3):
                if certificate(EPS, [models[k] for k in S], A) is not None:
                    hits += 1
        print('checkpoint arrangement %s: triples x odd-model choices with a kink certificate: %d' % (name, hits))
