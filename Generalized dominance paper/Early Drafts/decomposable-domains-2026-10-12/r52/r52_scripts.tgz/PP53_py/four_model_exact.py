"""PP53 exact certificate (CHECKED, Fractions only): four posterior models with own-Bayes fields, strict CG2,
the exact zero-accepting triangle test on every triple, and NO global prices at world 1.

Reads four_model_solution.json (floats proposed by four_model_search.py), rounds to rationals, and verifies:
 (0) the four credal sets M_a pairwise intersect (so the family is two-valued, PP49 Lemma 1.2(a)), exactly;
 (1) every one of the 28 types admitted by the pair-ordering theorem has an exact witness point with strict margins
     (so every type region is a non-null open cone) and no other type occurs (superset = actual);
 (2) piecewise-constant fields  l^N_w = magnitude x |g|  on each type cone, completed on all four advice values,
     are strictly guiding and make each model the STRICT pointwise own-Bayes optimum (all four advice values);
 (3) every pair at every world has a nondegenerate CG2 interval (strict CG2 with positive constants);
 (4) every triple at every world passes the closed cycle test with strict slack on both sides (so it is not a tight
     triple; PP47 Thm 4.1 / PP49 Lemma 3.4(iii) give (TC) under zero-accepting gates);
 (5) at world 1 the six pair intervals admit no global constants (an exact negative 4-cycle), while worlds 2, 3 do.
Run: python3 -I -B four_model_exact.py > four_model_exact.out
"""
import itertools
import json
import math
import sys
from fractions import Fraction as Fr

sys.path.insert(0, '.')
from lib53 import params, advice

OK = True


def check(cond, msg):
    global OK
    if not cond:
        OK = False
        print("FAIL:", msg)


eps, c = params(Fr(3, 10))
SOLF = sys.argv[1] if len(sys.argv) > 1 else 'four_model_solution.json'
print('solution file:', SOLF)
sol = json.load(open(SOLF))
MODELS = ['A', 'B', 'C', 'D']
IDX = {N: [Fr(q) for q in sol['idx'][N]] for N in MODELS}
types = [(tuple(P), tuple(R)) for P, R in sol['types']]
PAIRS = list(itertools.combinations(MODELS, 2))
TRIPLES = list(itertools.combinations(MODELS, 3))


def rat(x):
    return Fr(math.exp(x))  # exact binary value of the float; verification below is exact


mag = {}
for key, val in sol['phi'].items():
    N, P, R, w = json.loads(key)
    mag[(N, (tuple(P), tuple(R)), w)] = rat(val)
lam = {}
for key, val in sol['ll'].items():
    N, w = json.loads(key)
    lam[(N, w)] = rat(val)

print("indices:", {N: [str(q) for q in IDX[N]] for N in MODELS})
print("weights (unnormalised):", {N: [str(lam[(N, w)]) for w in range(3)] for N in MODELS})

# (0) overlap: normalise(a/b) in M  <=>  a in M_b
for N, M in PAIRS:
    q = [IDX[N][i] / IDX[M][i] for i in range(3)]
    s = sum(q)
    check(all(x / s >= c for x in q), ("no overlap", N, M))
print("(0) pairwise overlap checked")

# (1) witnesses with strict margins; every type present
found = {}
for key, g in sol['found'].items():
    P, R = json.loads(key)
    found[(tuple(P), tuple(R))] = [Fr(x) for x in g]
for t in types:
    check(t in found, ("type without witness", t))
    g = found[t]
    P, R = t
    for N in MODELS:
        h = [IDX[N][i] * g[i] for i in range(3)]
        q1 = c * sum(h) + eps * min(h)
        q2 = c * sum([-x for x in h]) + eps * min([-x for x in h])
        check(q1 != 0 and q2 != 0, ("boundary witness", t, N))
    adv = {N: advice(IDX[N], g, eps, c) for N in MODELS}
    hs = 1 if 'A' in adv.values() else -1
    acc = 'A' if hs == 1 else 'B'
    check(tuple(N for N in MODELS if adv[N] == acc) == P, ("witness P", t))
    check(tuple(i for i in range(3) if hs * g[i] > 0) == R, ("witness R", t))
print("(1) %d types, each with an exact strict witness" % len(types))

# (2) full fields and strict own-Bayes over all four advice values.  Advice values relative to h:
# 'acc' (accept h), 'S', 'opp' (accept -h), 'X'.  At an h-correct world: acc 0 < S m < opp m+K < X m+2K.
# At an h-wrong world: opp 0 < S s < acc s+m < X s+m+K.   K = 10*max m, s = min m / 100.
for t in types:
    P, R = t
    for N in MODELS:
        ms = [mag[(N, t, w)] for w in range(3)]
        K = 10 * max(ms)
        s = min(ms) / 100
        cost = {'acc': 0, 'S': 0, 'opp': 0, 'X': 0}
        for w in range(3):
            m, L = ms[w], lam[(N, w)]
            if w in R:
                f = {'acc': 0, 'S': m, 'opp': m + K, 'X': m + 2 * K}
            else:
                f = {'opp': 0, 'S': s, 'acc': s + m, 'X': s + m + K}
            for a in cost:
                cost[a] += L * f[a]
        best = 'acc' if N in P else 'S'
        check(all(cost[best] < cost[a] for a in cost if a != best), ("Bayes", t, N, cost))
print("(2) strict own-Bayes for all 4 models on all types (all four advice values)")


def intervals(w):
    """multiplicative CG2 interval for c_N/c_M at world w: [lo, hi], hi=None for +inf."""
    out = {}
    for N, M in PAIRS:
        lo, hi = Fr(0), None
        for t in types:
            P, R = t
            if (N in P) == (M in P):
                continue
            worsens = (w in R) if N in P else (w not in R)
            rho = mag[(M, t, w)] / mag[(N, t, w)]
            if worsens:
                hi = rho if hi is None else min(hi, rho)
            else:
                lo = max(lo, rho)
        out[(N, M)] = (lo, hi)
    return out


def iv(I, X, Y):
    if (X, Y) in I:
        return I[(X, Y)]
    lo, hi = I[(Y, X)]
    return (Fr(1) / hi if hi is not None else Fr(0), Fr(1) / lo if lo > 0 else None)


def logs(p):
    lo, hi = p
    return ("%.4f" % math.log(lo) if lo > 0 else "-inf", "%.4f" % math.log(hi) if hi is not None else "+inf")


for w in range(3):
    I = intervals(w)
    print("world %d log-intervals for log(c_N/c_M):" % (w + 1))
    for N, M in PAIRS:
        lo, hi = I[(N, M)]
        check(hi is None or lo < hi, ("degenerate CG2", N, M, w))
        print("   ", N, M, logs(I[(N, M)]))
    # (4) triples: product of lower bounds around the cycle < 1 < product of upper bounds
    for (i, j, k) in TRIPLES:
        a, b, d = iv(I, i, j), iv(I, j, k), iv(I, k, i)
        plo = a[0] * b[0] * d[0]
        check(plo < 1, ("triple lower tight/infeasible", i, j, k, w))
        if None not in (a[1], b[1], d[1]):
            check(a[1] * b[1] * d[1] > 1, ("triple upper tight/infeasible", i, j, k, w))
    # (5) global feasibility: x_X - x_Y in [log lo, log hi]; negative cycle <=> some cycle has prod hi < 1
    cyc_bad = []
    for cyc in itertools.permutations(MODELS[1:]):
        order = ['A'] + list(cyc)
        prod_hi, ok_inf = Fr(1), True
        for X, Y in zip(order, order[1:] + order[:1]):
            hi = iv(I, X, Y)[1]
            if hi is None:
                ok_inf = False
                break
            prod_hi *= hi
        if ok_inf and prod_hi < 1:
            cyc_bad.append((order, float(prod_hi)))
    if w == 0:
        check(len(cyc_bad) > 0, "world 1 should be globally infeasible")
        print("  world 1: NO global constants; violating cycle(s):", cyc_bad)
    else:
        print("  world %d: %s" % (w + 1, "global constants exist" if not cyc_bad else ("also infeasible: %s" % cyc_bad)))

print("ALL PASS" if OK else "SOME FAIL")
