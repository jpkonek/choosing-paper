"""PP53 script: four posterior models, type-level field search (MILP proposes; exact check in four_model_exact.py).

Models A = u (= T), B, C, D (interior, pairwise-overlapping credal sets => two-valued, PP49 Lemma 1.2).
Point types tau = (P, R): P = set of models accepting the orientation h, others silent; R = worlds where h is correct.
SUPERSET of types: every (P, R) allowed by the boundary pair-ordering theorem (PP49 Prop 5.2) for every
acceptor/non-acceptor pair.  Actual types are a subset (pair-ordering theorem), so constraints imposed on the
superset are conservative.  Pins (for global infeasibility) are placed only on types found at exact sample points.

Unknowns (log scale): phi[N][tau][w] = log |l^N_w(accept h) - l^N_w(S)| on type tau; loglam[N][w].
Constraints:
 * own-Bayes (sufficient max-form, margin m): acceptor: some correct world c has psi_c >= psi_w + log|W| + m for all
   wrong w; non-acceptor: some wrong world w has psi_w >= psi_c + log|R| + m for all correct c.  psi = phi + loglam.
 * pair (N,M) (N<M), world w, log-constant z = log(c_N/c_M): at type tau with N,M on opposite sides,
   r = phi^M_w - phi^N_w; if the move N->M worsens w:  Uc <= r ; else Lc >= r.  Require Lc + m <= Uc.
 * triples: for each triple (i<j<k), world w:  L_ij + L_jk - U_ik <= -m  and U_ij + U_jk - L_ik >= m.
 * global infeasibility at world 0 along the cycle A->B->C->D->A: pinned upper bounds (an actual W-type with
   r <= Upin) with  Upin_AB + Upin_BC + Upin_CD + Upin_DA <= -m  (orientation handled by sign).
Output: solution written to four_model_solution.json.
"""
import itertools
import json
import math
import random
import sys
from fractions import Fraction as Fr

import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds

sys.path.insert(0, '.')
from lib53 import params, advice, norm

EPS = Fr(3, 10)
eps, c = params(EPS)
MODELS = ['A', 'B', 'C', 'D']
IDX = {'A': norm([10, 10, 10]), 'B': norm([11, 10, 9]), 'C': norm([11, 11, 8]), 'D': norm([10, 11, 9])}
CYCLE = [('A', 'B'), ('B', 'C'), ('C', 'D'), ('D', 'A')]
PAIRS = list(itertools.combinations(MODELS, 2))
TRIPLES = list(itertools.combinations(MODELS, 3))
WORLD_INF = 0
MARG = 0.05
FIXLAM = '--fixlam' in sys.argv
OUT = 'four_model_solution_fixlam.json' if FIXLAM else 'four_model_solution.json'


def admissible(P, R):
    """pair-ordering necessary condition for every acceptor N, non-acceptor M (move N -> M worsens exactly R)."""
    for N in P:
        for M in MODELS:
            if M in P:
                continue
            n, mm = IDX[N], IDX[M]
            r = [mm[i] / n[i] for i in range(3)]
            Wset = list(R)
            Rset = [i for i in range(3) if i not in R]
            if not (min(r[i] for i in Wset) < max(r[i] for i in Rset)):
                return False
    return True


def all_types():
    out = []
    for k in range(1, 4):
        for P in itertools.combinations(MODELS, k):
            for rs in (1, 2):
                for R in itertools.combinations(range(3), rs):
                    if admissible(P, R):
                        out.append((P, R))
    return out


def sample_types(n, seed=7):
    """find actual types by exact sampling; returns dict type -> witness g (exact, strict margins)."""
    rng = random.Random(seed)
    found = {}
    for _ in range(n):
        # heavy-ish tails so thin bands are hit
        g = []
        for _ in range(3):
            x = rng.gauss(0, 1) * math.exp(rng.uniform(-3, 3))
            g.append(Fr(x).limit_denominator(10 ** 6))
        if any(x == 0 for x in g):
            continue
        adv = {N: advice(IDX[N], g, eps, c) for N in MODELS}
        vals = set(adv.values())
        if len(vals) == 1:
            continue
        assert not ('A' in vals and 'B' in vals), "opposite answers"
        hsgn = 1 if 'A' in vals else -1
        acc = 'A' if hsgn == 1 else 'B'
        P = tuple(N for N in MODELS if adv[N] == acc)
        R = tuple(i for i in range(3) if hsgn * g[i] > 0)
        key = (P, R)
        if key not in found:
            found[key] = [str(x) for x in g]
    return found


def main():
    types = all_types()
    found = sample_types(int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 200000)
    print("superset types:", len(types), " sampled actual types:", len(found))
    for k in found:
        assert k in types, ("sampled type outside superset", k)
    # variable indexing
    var = {}

    def v(name):
        if name not in var:
            var[name] = len(var)
        return var[name]

    rows, lo, hi, integ = [], [], [], {}
    BIG = 60.0

    def add(coefs, l, h):
        rows.append(coefs)
        lo.append(l)
        hi.append(h)

    for N in MODELS:
        for w in range(3):
            v(('ll', N, w))
    for t in types:
        for N in MODELS:
            for w in range(3):
                v(('phi', N, t, w))
    for (N, M) in PAIRS:
        for w in range(3):
            v(('L', N, M, w))
            v(('U', N, M, w))
    # Bayes
    for t in types:
        P, R = t
        Wr = [i for i in range(3) if i not in R]
        for N in MODELS:
            if N in P:
                good, bad = list(R), Wr
            else:
                good, bad = Wr, list(R)
            choices = good
            bins = []
            for ch in choices:
                b = v(('bin', N, t, ch))
                integ[b] = 1
                bins.append(b)
                for o in bad:
                    # psi_ch - psi_o >= log|bad| + MARG  - BIG(1-b)
                    co = {v(('phi', N, t, ch)): 1, v(('ll', N, ch)): 1, v(('phi', N, t, o)): -1, v(('ll', N, o)): -1, b: -BIG}
                    add(co, math.log(len(bad)) + MARG - BIG, np.inf)
            add({b: 1 for b in bins}, 1, np.inf)
    # weights normalisation: loglam <= 0 and at least ... just bound
    # pair constraints
    for t in types:
        P, R = t
        for (N, M) in PAIRS:
            if (N in P) == (M in P):
                continue
            for w in range(3):
                if N in P:
                    worsens = w in R
                else:
                    worsens = w not in R
                co = {v(('phi', M, t, w)): 1, v(('phi', N, t, w)): -1}
                if worsens:
                    co[v(('U', N, M, w))] = -1   # r - U >= 0
                    add(co, 0, np.inf)
                else:
                    co[v(('L', N, M, w))] = -1   # r - L <= 0
                    add(co, -np.inf, 0)
    for (N, M) in PAIRS:
        for w in range(3):
            add({v(('U', N, M, w)): 1, v(('L', N, M, w)): -1}, MARG, np.inf)
    # triples
    for (i, j, k) in TRIPLES:
        for w in range(3):
            # z_ij + z_jk + z_ki = 0, z_ki = -z_ik
            add({v(('L', i, j, w)): 1, v(('L', j, k, w)): 1, v(('U', i, k, w)): -1}, -np.inf, -MARG)
            add({v(('U', i, j, w)): 1, v(('U', j, k, w)): 1, v(('L', i, k, w)): -1}, MARG, np.inf)
    # global infeasibility at WORLD_INF along CYCLE using pins on actual types
    w = WORLD_INF
    pin_terms = {}
    for (X, Y) in CYCLE:
        N, M = (X, Y) if (X, Y) in PAIRS else (Y, X)
        sgn = 1 if (X, Y) in PAIRS else -1   # z_XY = sgn * z_NM
        # want an upper bound on z_XY: if sgn=1 it is U_NM (pinned at a W-type), else -L_NM (pinned at an R-type)
        pv = v(('pin', X, Y))
        cands = []
        for t in found:
            P, R = t
            if (N in P) == (M in P):
                continue
            worsens = (w in R) if N in P else (w not in R)
            if (sgn == 1 and worsens) or (sgn == -1 and not worsens):
                b = v(('pinbin', X, Y, t))
                integ[b] = 1
                cands.append(b)
                # sgn=1: r <= pv + BIG(1-b);  sgn=-1: z_XY = -z_NM <= -r  i.e. pv >= -r -> -r - pv <= BIG(1-b)
                if sgn == 1:
                    add({v(('phi', M, t, w)): 1, v(('phi', N, t, w)): -1, pv: -1, b: BIG}, -np.inf, BIG)
                else:
                    add({v(('phi', M, t, w)): -1, v(('phi', N, t, w)): 1, pv: -1, b: BIG}, -np.inf, BIG)
        assert cands, ("no pin candidate", X, Y)
        add({b: 1 for b in cands}, 1, np.inf)
        pin_terms[pv] = 1
    add(pin_terms, -np.inf, -4 * MARG)
    nv = len(var)
    A = np.zeros((len(rows), nv))
    for r_i, co in enumerate(rows):
        for k, val in co.items():
            A[r_i, k] += val
    lb = np.full(nv, -BIG / 2)
    ub = np.full(nv, BIG / 2)
    for name, k in var.items():
        if name[0] in ('bin', 'pinbin'):
            lb[k], ub[k] = 0, 1
        if name[0] == 'll':
            lb[k], ub[k] = -6, 0
            if FIXLAM:
                val = math.log(float(IDX[name[1]][name[2]]))
                lb[k], ub[k] = val, val
    integrality = np.zeros(nv)
    for k in integ:
        integrality[k] = 1
    res = milp(c=np.zeros(nv), constraints=LinearConstraint(A, lo, hi), integrality=integrality,
               bounds=Bounds(lb, ub), options={'time_limit': 600})
    print("MILP status:", res.status, res.message)
    if res.x is None:
        print("NO SOLUTION")
        return
    x = res.x
    sol = {'idx': {N: [str(q) for q in IDX[N]] for N in MODELS}, 'types': [[list(P), list(R)] for (P, R) in types],
           'found': {json.dumps([list(k[0]), list(k[1])]): g for k, g in found.items()},
           'phi': {}, 'll': {}, 'pins': {}}
    for name, k in var.items():
        if name[0] == 'phi':
            _, N, t, w = name
            sol['phi'][json.dumps([N, list(t[0]), list(t[1]), w])] = x[k]
        if name[0] == 'll':
            sol['ll'][json.dumps([name[1], name[2]])] = x[k]
        if name[0] == 'pinbin' and x[k] > 0.5:
            _, X, Y, t = name
            sol['pins'][X + Y] = [list(t[0]), list(t[1])]
    json.dump(sol, open(OUT, 'w'), indent=0)
    for (N, M) in PAIRS:
        print(N, M, ["[%.3f, %.3f]" % (x[var[('L', N, M, w)]], x[var[('U', N, M, w)]]) for w in range(3)])
    print("pins", sol['pins'])


if __name__ == '__main__':
    main()
