"""PP53: boundary behaviour of the transported fields l^a(g) := l^T(a o g) (REFEREE_PP32 Sec 3.2 field), exact.

(a) Unnormalised, the world-3 field tends to 0 as a -> an edge point (a_3 -> 0): the limiting gate is not strictly
    guiding, so (H0) fails at the edge for the limit gate.
(b) Normalised per world (l^a_w / a_w; gate verdicts are unchanged by a per-world positive factor, Bayes weights
    become proportional to a), the edge limits exist and do not depend on the direction of approach.
(c) At a vertex e_1 the normalised world-2 field on M_3 depends on the approach direction rho = b_3/b_2, and the
    dependence is not a constant factor: two directions give limits whose ratio varies with g.  So no per-world
    renormalisation makes the transported design L1-continuous at the vertices ((H4)(b) of PP49 fails there).
Run: python3 -I -B transported_boundary.py > transported_boundary.out
"""
from fractions import Fraction as Fr

OK = True


def check(cond, msg):
    global OK
    if not cond:
        OK = False
        print("FAIL:", msg)


eps = Fr(3, 10)
c = (1 - eps) / 3
L = (c + eps) / c
d = 1 / (1 + L)


def F(t):
    if t <= d:
        return t / (2 * d)
    if t <= 1 / L:
        return Fr(1, 2) + L * (t - d) / (2 * d)
    return L * t


def G(s):
    return 1 / F(1 / s)


def beta_alpha(h, w):
    """(alpha_w, beta_w) of l^T at problem h (mixed class; odd world i = the coordinate of minority sign)."""
    pos = [x > 0 for x in h]
    i = [k for k in range(3) if pos.count(pos[k]) == 1][0]
    if w == i:
        return abs(h[i]), abs(h[i])
    s = abs(h[w]) / abs(h[i])
    return abs(h[i]) * G(s), abs(h[i]) * F(s)


# (a)/(b): edge e1-e2, approach a(t) = normalise((1, 1, t)); g on M_1 (odd world 1), world 3
g = [Fr(-1), Fr(2, 3), Fr(5, 7)]
prev = None
for t in [Fr(1, 10), Fr(1, 100), Fr(1, 1000), Fr(1, 10000)]:
    a = [Fr(1), Fr(1), t]
    s = sum(a)
    a = [x / s for x in a]
    h = [a[k] * g[k] for k in range(3)]
    al, be = beta_alpha(h, 2)
    print("edge approach t=%s: raw beta_3=%.3e   normalised beta_3/a_3=%s" % (t, float(be), be / a[2]))
    norm_val = be / a[2]
    if t <= Fr(1, 100):
        # linear region of F: normalised value = |g_3|/(2d) * (a_1/a_1) exactly
        check(norm_val == abs(g[2]) / (2 * d) * 1, ("normalised edge limit", t, norm_val))
check(be < Fr(1, 1000), "raw world-3 field must tend to 0 at the edge")
# direction independence at the edge: approach along (1+u, 1-u, t)
for u in [Fr(0), Fr(1, 5), Fr(-1, 3)]:
    a = [1 + u, 1 - u, Fr(1, 10000)]
    s = sum(a)
    a = [x / s for x in a]
    h = [a[k] * g[k] for k in range(3)]
    _, be = beta_alpha(h, 2)
    check(be / a[2] == abs(g[2]) / (2 * d), ("edge limit depends on direction?", u))
print("(a),(b) edge: raw world-3 field -> 0; normalised limit |g_3|/(2d), direction-independent")

# (c) vertex e_1: b = normalise((1, t, rho t)); normalised world-2 field beta_2/b_2 on M_3 (odd world 3)
def vert(g, rho, t=Fr(1, 10 ** 6)):
    b = [Fr(1), t, rho * t]
    s = sum(b)
    b = [x / s for x in b]
    h = [b[k] * g[k] for k in range(3)]
    _, be = beta_alpha(h, 1)
    return be / b[1]


ratios = []
for g in ([Fr(1), Fr(1), Fr(-1)], [Fr(1), Fr(30), Fr(-1)], [Fr(1), Fr(1, 30), Fr(-1)]):
    v1, v2 = vert(g, Fr(1)), vert(g, Fr(100))
    v1b = vert(g, Fr(1), Fr(1, 10 ** 8))
    check(v1 == v1b, "normalised value should not depend on the distance t along a direction")
    ratios.append(v2 / v1)
    print("vertex, g=%s: direction rho=1 -> %s ; rho=100 -> %s ; ratio %s" % ([str(x) for x in g], v1, v2, v2 / v1))
check(len(set(ratios)) > 1, "ratio of directional limits should vary with g")
print("(c) vertex: directional limits differ and are not proportional (ratios %s)" % [str(r) for r in ratios])
print("ALL PASS" if OK else "SOME FAIL")
