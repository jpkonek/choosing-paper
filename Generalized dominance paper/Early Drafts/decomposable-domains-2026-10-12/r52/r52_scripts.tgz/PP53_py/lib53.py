"""PP53 library: exact posterior models C_a = D_{M_a}, M = c1 + eps*Delta, on the closed simplex.

C_a(g) = T1(a o g) (PP12 Observation 1).  T1 accepts h iff c*sum(h) + eps*min(h) > 0.
Advice of a model at g (g mod sign is represented by g itself):
   'A' = accept g, 'B' = accept -g, 'S' = silent.   (Coherent models never give 'X'.)
World-w rank: correct 0 < silent 1 < wrong 2.  'A' is correct at w iff g_w > 0.
All arithmetic is exact (Fractions).
"""
from fractions import Fraction as Fr
import random


def params(eps):
    eps = Fr(eps)
    return eps, (1 - eps) / 3


def T_acc(h, eps, c):
    return c * sum(h) + eps * min(h) > 0


def advice(a, g, eps, c):
    h = [a[i] * g[i] for i in range(3)]
    if T_acc(h, eps, c):
        return 'A'
    if T_acc([-x for x in h], eps, c):
        return 'B'
    return 'S'


def rank(adv, g, w):
    if adv == 'S':
        return 1
    pos = g[w] > 0
    if adv == 'A':
        return 0 if pos else 2
    return 2 if pos else 0


def W_R(adv_old, adv_new, g):
    """W = worlds where the NEW advice is worse, R = where it is better (all worlds change rank)."""
    W, R = [], []
    for w in range(3):
        ro, rn = rank(adv_old, g, w), rank(adv_new, g, w)
        if rn > ro:
            W.append(w)
        elif rn < ro:
            R.append(w)
    return W, R


def rand_g(rng, K=60):
    while True:
        g = [Fr(rng.randint(-K, K), rng.randint(1, K)) for _ in range(3)]
        if all(x != 0 for x in g):
            return g


def norm(v):
    s = sum(v)
    return [Fr(x) / s for x in v]


def rand_interior(rng, K=40):
    return norm([Fr(rng.randint(1, K)) for _ in range(3)])


def rand_edge(rng, zero, K=40):
    v = [Fr(rng.randint(1, K)) for _ in range(3)]
    v[zero] = Fr(0)
    return norm(v)


def vertex(i):
    v = [Fr(0)] * 3
    v[i] = Fr(1)
    return v
