"""PP53: three-valued points of the boundary triple (T, C_b, E), b = (9,9,2)/20, E = C_(1/2,1/2,0): at each world,
both rank orders (E best ... C_b worst, and the reverse) occur at exact points with strict margins.
Relevant to Lemma 3.5 (common-shape fields fail (H3) on such triples).
Run: python3 -I -B three_valued_orders.py > three_valued_orders.out"""
import random, sys, math
from fractions import Fraction as Fr
sys.path.insert(0, '.')
from lib53 import params, advice, norm, rank
eps, c = params(Fr(3, 10))
M = {'T': norm([1, 1, 1]), 'Nb': norm([9, 9, 2]), 'E': norm([1, 1, 0])}
rng = random.Random(11)
seen = {}
for _ in range(200000):
    g = [Fr(rng.gauss(0, 1) * math.exp(rng.uniform(-4, 4))).limit_denominator(10 ** 6) for _ in range(3)]
    if 0 in g:
        continue
    adv = {N: advice(M[N], g, eps, c) for N in M}
    if len(set(adv.values())) < 3:
        continue
    strict = True
    for N in M:
        h = [M[N][i] * g[i] for i in range(3)]
        if c * sum(h) + eps * min(h) == 0 or -c * sum(h) + eps * min([-x for x in h]) == 0:
            strict = False
    if not strict:
        continue
    for w in range(3):
        order = tuple(sorted(M, key=lambda N: rank(adv[N], g, w)))
        seen.setdefault((w, order), g)
OK = True
for w in range(3):
    ords = sorted(o for (ww, o) in seen if ww == w)
    print("world", w + 1, "orders (best..worst):", ords)
    rev = [o for o in ords if tuple(reversed(o)) in ords]
    if w < 2 and not rev:
        OK = False
        print("FAIL: no reversed pair at world", w + 1)
for k, g in list(seen.items())[:6]:
    print("  witness", k, [str(x) for x in g])
print("ALL PASS" if OK else "SOME FAIL")
