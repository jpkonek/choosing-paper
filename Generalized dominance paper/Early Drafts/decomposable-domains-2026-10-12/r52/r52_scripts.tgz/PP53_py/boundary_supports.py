"""PP53: supp(lambda_a) = supp(a) is forced for every posterior index (exact witnesses).

For a in Delta and each world w in supp a we exhibit an exact problem g, with strict margins, at which C_a answers
with advice that is correct at w ONLY.  If lambda_{a,w} = 0, then at such points (on an open cone) the answer is
strictly worse than silence at every world of supp lambda, contradicting weak own-Bayes (H1).  With (H1)'s
supp lambda_a <= supp a this forces equality.  Also: edge models never answer 'correct only at the off-support
world', so nothing forces weight there (consistent with (H1)).
Run: python3 -I -B boundary_supports.py > boundary_supports.out
"""
import random
import sys
from fractions import Fraction as Fr

sys.path.insert(0, '.')
from lib53 import params, advice, norm, rank, rand_g

OK = True


def check(cond, msg):
    global OK
    if not cond:
        OK = False
        print("FAIL:", msg)


eps, c = params(Fr(3, 10))
rng = random.Random(3)
idxs = [norm([1, 1, 1]), norm([9, 9, 2]), norm([5, 1, 1]), norm([1, 1, 0]), norm([7, 1, 0]), norm([1, 6, 0]),
        norm([1, 0, 1]), norm([0, 3, 1])]
for a in idxs:
    supp = [w for w in range(3) if a[w] > 0]
    got = {}
    off = set()
    for _ in range(60000):
        g = rand_g(rng, K=200)
        adv = advice(a, g, eps, c)
        if adv == 'S':
            continue
        h = [a[i] * g[i] for i in range(3)]
        q1 = c * sum(h) + eps * min(h)
        q2 = -c * sum(h) + eps * min([-x for x in h])
        if q1 == 0 or q2 == 0:
            continue
        corr = [w for w in range(3) if rank(adv, g, w) == 0]
        if len(corr) == 1:
            if corr[0] in supp:
                got.setdefault(corr[0], g)
            else:
                off.add(corr[0])
    print("a=%s supp=%s : single-correct answers found at worlds %s ; off-support single-correct: %s"
          % ([str(x) for x in a], supp, sorted(got), sorted(off)))
    check(sorted(got) == supp, ("missing single-correct witness", a))
    check(not off, ("off-support single-correct answer", a))
print("ALL PASS" if OK else "SOME FAIL")
