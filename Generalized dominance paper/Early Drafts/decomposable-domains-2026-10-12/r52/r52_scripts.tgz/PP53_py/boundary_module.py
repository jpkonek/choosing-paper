"""PP53 boundary module (LP proposes, Fractions verify => CHECKED).

Module: T = C_u, an interior model near the edge, two edge models on [e1,e2], an edge model on [e1,e3], and the three
vertex models V_1, V_2, V_3.  Weights mu_N := index of N (so mu_E has a zero coordinate, mu_{V_i} = e_i).
At every point type we look for ONE local potential U(g, .) (per world, strictly increasing in rank) such that every
module member's advice is the STRICT mu_N-optimum of U(g, .).  If this holds on every type, then the fields
l^N_w := U_w x (1 -/+ eta) (humble perturbation) give, for the module:
  - strict pointwise own-Bayes at mu_N (edge models at edge weights, vertices at e_i);
  - a strict local potential for every set of gates at every point, hence strict CG2 for every pair and PP42's strict
    CG3 for every triple, so PP49 Lemma 3.4(ii) => (H3) for every ordered triple, three-valued points included.
Types: (advice vector, R) with advice relative to an orientation h.  The SUPERSET of types is every advice vector
allowed by PP49 Prop 5.2 for every disagreeing pair and by the vertex models' forced advice; actual types are a
subset.  We also sample exact points to see which types occur and to confirm three-valued points exist.
Run: python3 -I -B boundary_module.py > boundary_module.out
"""
import itertools
import math
import random
import sys
from fractions import Fraction as Fr

import numpy as np
from scipy.optimize import linprog

sys.path.insert(0, '.')
from lib53 import params, advice, norm, rank

OK = True


def check(cond, msg):
    global OK
    if not cond:
        OK = False
        print("FAIL:", msg)


eps, c = params(Fr(3, 10))
MOD = {
    'T': norm([1, 1, 1]),
    'Nb': norm([9, 9, 2]),        # interior, near the edge [e1,e2]
    'E': norm([1, 1, 0]),         # edge [e1,e2], the shadow edge model
    'E2': norm([2, 1, 0]),        # another edge model on [e1,e2]
    'F': norm([1, 0, 1]),         # edge [e1,e3]
    'V1': [Fr(1), Fr(0), Fr(0)], 'V2': [Fr(0), Fr(1), Fr(0)], 'V3': [Fr(0), Fr(0), Fr(1)],
}
NAMES = list(MOD)
ADV = ['acc', 'S', 'opp']


def rank_rel(a, w, R):
    """world-w rank of advice a (relative to orientation h) when R = worlds where h is correct."""
    if a == 'S':
        return 1
    corr = w in R
    if a == 'acc':
        return 0 if corr else 2
    return 2 if corr else 0


def prop52_ok(an, am, n, m, R):
    """PP49 Prop 5.2 condition for the move (index n, advice an) -> (index m, advice am)."""
    W = [w for w in range(3) if rank_rel(am, w, R) > rank_rel(an, w, R)]
    Rr = [w for w in range(3) if rank_rel(am, w, R) < rank_rel(an, w, R)]
    Z = [w for w in range(3) if n[w] == 0 and m[w] == 0]
    W2 = [w for w in W if w not in Z]
    R2 = [w for w in Rr if w not in Z]
    if not W2 or not R2:
        return False

    def r(i):
        if n[i] == 0:
            return math.inf
        return float(m[i] / n[i])
    return min(r(i) for i in W2) < max(r(j) for j in R2)


def superset():
    out = []
    for rs in (1, 2):
        for R in itertools.combinations(range(3), rs):
            for vec in itertools.product(ADV, repeat=len(NAMES)):
                d = dict(zip(NAMES, vec))
                if 'acc' not in vec:      # canonical orientation: someone accepts h
                    continue
                if any(d['V%d' % (i + 1)] != ('acc' if i in R else 'opp') for i in range(3)):
                    continue
                # coherent models never accept both; posterior advice is two-sided monotone -- keep all
                ok = True
                for N, M in itertools.combinations(NAMES, 2):
                    if d[N] != d[M] and not prop52_ok(d[N], d[M], MOD[N], MOD[M], R):
                        ok = False
                        break
                if ok:
                    out.append((vec, R))
    return out


def sample(n, seed=5):
    rng = random.Random(seed)
    found = {}
    for _ in range(n):
        g = [Fr(rng.gauss(0, 1) * math.exp(rng.uniform(-4, 4))).limit_denominator(10 ** 6) for _ in range(3)]
        if any(x == 0 for x in g):
            continue
        adv = {N: advice(MOD[N], g, eps, c) for N in NAMES}
        hs = 1 if adv['T'] == 'A' or ('A' in adv.values() and adv['T'] != 'B') else -1
        # canonical: orientation accepted by someone; prefer the one accepted by the first answering model
        for N in NAMES:
            if adv[N] != 'S':
                hs = 1 if adv[N] == 'A' else -1
                break
        rel = tuple(('acc' if (adv[N] == 'A') == (hs == 1) else 'opp') if adv[N] != 'S' else 'S' for N in NAMES)
        R = tuple(w for w in range(3) if hs * g[w] > 0)
        if len(set(rel)) == 1:
            continue
        key = (rel, R)
        found.setdefault(key, g)
    return found


def lp_type(vec, R):
    """variables: da_w = U_w(acc)-U_w(S), do_w = U_w(opp)-U_w(S).  margin 1 (homogeneous)."""
    nv = 6
    A, b = [], []

    def le(co, rhs):
        A.append(co)
        b.append(rhs)
    for w in range(3):
        if w in R:   # acc correct: da < 0 < do
            co = [0] * nv; co[w] = 1; le(co, -1)
            co = [0] * nv; co[3 + w] = -1; le(co, -1)
        else:
            co = [0] * nv; co[w] = -1; le(co, -1)
            co = [0] * nv; co[3 + w] = 1; le(co, -1)
    for N, a in zip(NAMES, vec):
        mu = [float(x) for x in MOD[N]]
        if N.startswith('V'):
            continue  # vertex optimal automatically (its advice is world-i best and mu = e_i)
        if a == 'acc':   # mu.da <= -1, mu.da - mu.do <= -1
            le(mu + [0, 0, 0], -1)
            le(mu + [-x for x in mu], -1)
        elif a == 'S':   # mu.da >= 1, mu.do >= 1
            le([-x for x in mu] + [0, 0, 0], -1)
            le([0, 0, 0] + [-x for x in mu], -1)
        else:
            le([0, 0, 0] + mu, -1)
            le([-x for x in mu] + mu, -1)
    res = linprog(np.zeros(nv), A_ub=np.array(A), b_ub=np.array(b), bounds=[(-1e4, 1e4)] * nv, method='highs')
    return res.x if res.status == 0 else None


def exact_verify(vec, R, x):
    d = [Fr(v).limit_denominator(10 ** 4) for v in x]
    da, do = d[:3], d[3:]
    for w in range(3):
        if w in R:
            if not (da[w] < 0 < do[w]):
                return False
        else:
            if not (do[w] < 0 < da[w]):
                return False
    for N, a in zip(NAMES, vec):
        mu = MOD[N]
        ca = sum(mu[w] * da[w] for w in range(3))
        co = sum(mu[w] * do[w] for w in range(3))
        cost = {'acc': ca, 'S': Fr(0), 'opp': co}
        if not all(cost[a] < cost[o] for o in cost if o != a):
            return False
    return True


types = superset()
found = sample(int(sys.argv[1]) if len(sys.argv) > 1 else 400000)
print("module:", {N: [str(q) for q in MOD[N]] for N in NAMES})
print("superset types:", len(types), "; sampled types:", len(found))
for k in found:
    check(k in types, ("sampled type outside superset", k))
three = [k for k in found if len(set(k[0][:5])) == 3]
print("sampled types where three non-vertex members give three different answers:", len(three))
for k in three[:4]:
    print("   e.g.", k, "at g =", [str(x) for x in found[k]])
infeasible_super, infeasible_found = [], []
for (vec, R) in types:
    x = lp_type(vec, R)
    if x is None or not exact_verify(vec, R, x):
        infeasible_super.append((vec, R))
        if (vec, R) in found:
            infeasible_found.append((vec, R))
print("superset types with no strict local potential at mu = index:", len(infeasible_super))
print("   of which actually sampled:", len(infeasible_found))
for k in infeasible_found[:10]:
    print("   ", k, [str(q) for q in found[k]])
check(len(infeasible_found) == 0, "an actual type has no local potential")
print("ALL PASS" if OK else "SOME FAIL")
