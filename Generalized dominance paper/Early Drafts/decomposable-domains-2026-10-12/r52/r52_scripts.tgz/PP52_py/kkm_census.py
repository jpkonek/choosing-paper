"""PP52 script 1: the KKM test (Theorem K) and the posterior census (Proposition P).

(A) Theorem K's mechanism at the PP45/PP46 checkpoint (T, combined cut AB), for three closed role rules:
    UNI (gate union, accept iff Phi_w >= 0), OA (own role-weighted argmax, random role weights theta),
    NEAR (accept at w iff Phi_w >= kappa * max_v Phi_v, kappa random in (0,1]).
    AB's own field on its pieces B_1, B_2, B_3 (sigma correct only at r) is random, subject to own-Bayes.
    The KKM point s* is computed and verified EXACTLY: AB's own gate accepts (D*: AB -> T) at all three
    worlds, so Y = T[D* -> AB] satisfies Y <=_w T at every w.  T is dominated or all-world tied with an
    incoherent model.  No assumption on T's field, on (TC) or on CG2 is used.
(B) Posterior census, eps = 3/10, exact rationals.  For index pairs (a, b) in the closed simplex (interior,
    edge, vertex), every sampled disagreement problem is classified by W (worlds where C_b is worse) and
    R (worlds where C_b is better).  Checks:
      (B1) generalised pair-ordering: no k in (0, inf) (k = 0 also excluded for silence->answer) with
           b_w >= k a_w on W and b_r <= k a_r on R;
      (B2) K2 = {k : W = {k} occurs} and K1 = {k : R = {k} occurs} are never all three worlds, and the
           predicted missing worlds (Prop P) are indeed missing.
(C) Multicap controls (exact models D_K): T vs single cap passes the KKM test; T vs combined cut and T vs full
    cut fail it (all three single types present), as Theorem K predicts.
Run: python3 -I -B kkm_census.py > kkm_census.out
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import itertools
import random
import numpy as np
from scipy.optimize import linprog
from oa_lib import exact_solve, feasible_point

random.seed(52)
rng = np.random.default_rng(52)
OK = True


def check(c, m):
    global OK
    if not c:
        OK = False
        print("FAIL:", m)


def rf(lo=1, hi=9):
    return Fr(random.randint(lo, hi), random.randint(1, 4))


# ------------------------------------------------------------------ (A)
print("(A) Theorem K at the (T, AB) checkpoint: AB's own gate, KKM point, exact")
counts = {'UNI': 0, 'OA': 0, 'NEAR': 0}
for trial in range(300):
    # v_r = Phi^AB(E_r : AB -> T) = l(S) - l(sigma): +alpha_r at r, -beta_w elsewhere
    while True:
        lam = [rf() for _ in range(3)]
        V = []
        for r in range(3):
            v = [Fr(0)] * 3
            for w in range(3):
                v[w] = rf() if w == r else -rf()
            V.append(v)
        if all(sum(l * x for l, x in zip(lam, v)) > 0 for v in V):
            break
    rule = ['UNI', 'OA', 'NEAR'][trial % 3]
    if rule == 'OA':
        th = [rf() for _ in range(3)]
        # triple ray: th_w V_w all equal  <=>  V = t * (1/th)
        rows = [[V[0][w], V[1][w], V[2][w], -1 / th[w]] for w in range(3)] + [[Fr(1), Fr(1), Fr(1), Fr(0)]]
        sol = exact_solve(rows, [Fr(0), Fr(0), Fr(0), Fr(1)])
        check(sol is not None, "OA KKM system solvable")
        s, t = sol[:3], sol[3]
        check(all(x >= 0 for x in s) and t > 0, f"OA KKM point in simplex {s} {t}")
        Vs = [sum(s[r] * V[r][w] for r in range(3)) for w in range(3)]
        acc = [all(th[w] * Vs[w] >= th[v] * Vs[v] for v in range(3)) and Vs[w] >= 0 for w in range(3)]
    else:
        kap = Fr(1) if rule == 'UNI' else Fr(random.randint(1, 9), 10)
        # rows (in s): Phi_w(s) >= kappa*Phi_v(s) for all w,v  (UNI: kappa irrelevant -> Phi_w >= 0)
        G = []
        for w in range(3):
            if rule == 'UNI':
                G.append([V[r][w] for r in range(3)])
            else:
                G.append([V[r][w] for r in range(3)])
                for v in range(3):
                    if v != w:
                        G.append([V[r][w] - kap * V[r][v] for r in range(3)])
        s = feasible_point(G)
        check(s is not None and s != 'UNVERIFIED', f"{rule} KKM point found and verified")
        Vs = [sum(s[r] * V[r][w] for r in range(3)) for w in range(3)]
        if rule == 'UNI':
            acc = [Vs[w] >= 0 for w in range(3)]
        else:
            acc = [Vs[w] >= 0 and all(Vs[w] >= kap * Vs[v] for v in range(3)) for w in range(3)]
    check(all(acc), f"{rule}: AB's own gate accepts at all three worlds")
    check(sum(s) == 1 and any(x > 0 for x in s), "nontrivial D*")
    counts[rule] += all(acc)
print(f"    all-world acceptance of (D*: AB -> T) verified exactly: {counts}")
print("    => Y = T[D* -> AB] <=_w T at w = 1,2,3; T is dominated by Y or all-world tied with Y (incoherent).")

# ------------------------------------------------------------------ (B)
eps = Fr(3, 10)
c = (1 - eps) / 3
Mv = [[c + (eps if i == j else 0) for j in range(3)] for i in range(3)]


def adv_posterior(a, g):
    vals = [sum(a[w] * m[w] * g[w] for w in range(3)) for m in Mv]
    if min(vals) > 0:
        return 1      # accept +g
    if max(vals) < 0:
        return -1     # accept -g
    return 0          # silent


def rk(advice, g, w):
    if advice == 0:
        return 1
    return 0 if advice * g[w] > 0 else 2


def WR(x, y, g):
    W = frozenset(w for w in range(3) if rk(y, g, w) > rk(x, g, w))
    R = frozenset(w for w in range(3) if rk(y, g, w) < rk(x, g, w))
    return W, R


def gen_pair_ordering_ok(a, b, x, y, W, R):
    """True iff NO k in (0,inf) (or [0,inf) when x is silent) with b_w >= k a_w on W, b_r <= k a_r on R."""
    lo, hi = Fr(0), None   # feasible k: k <= b_w/a_w on W (a_w>0); k >= b_r/a_r on R (a_r>0)
    strict = (y == 0)      # answer -> silence: the excluded constant must be > 0
    for w in W:
        if a[w] > 0:
            hi = b[w] / a[w] if hi is None else min(hi, b[w] / a[w])
        # a_w = 0: b_w >= 0 always holds
    for r in R:
        if a[r] > 0:
            lo = max(lo, b[r] / a[r])
        elif b[r] > 0:
            return True    # b_r <= k*0 impossible
    if hi is None:
        return False       # any large k works
    exists = (lo <= hi) and (hi > 0 if strict else True)
    return not exists


def rand_index(kind):
    if kind == 'int':
        v = [Fr(random.randint(1, 40)) for _ in range(3)]
    elif kind == 'near':
        v = [Fr(random.randint(95, 105)) for _ in range(3)]
    elif kind == 'edge':
        v = [Fr(random.randint(1, 40)) for _ in range(3)]
        v[random.randrange(3)] = Fr(0)
    else:
        v = [Fr(0)] * 3
        v[random.randrange(3)] = Fr(1)
    s = sum(v)
    return [x / s for x in v]


print("(B) posterior census, eps = 3/10, exact")
npairs = ndis = 0
allK = 0
tight = 0
kinds = [('int', 'int'), ('near', 'near'), ('int', 'edge'), ('edge', 'edge'), ('int', 'vert'), ('edge', 'vert'),
         ('near', 'int')]
probs = []
for _ in range(3000):
    g = [random.choice([-1, 1]) * random.randint(1, 60) for _ in range(3)]
    probs.append(g)
for ka, kb in kinds:
    for _ in range(40):
        a, b = rand_index(ka), rand_index(kb)
        if a == b:
            continue
        npairs += 1
        K1, K2 = set(), set()
        for g in probs:
            x, y = adv_posterior(a, g), adv_posterior(b, g)
            if x == y:
                continue
            ndis += 1
            W, R = WR(x, y, g)
            check(gen_pair_ordering_ok(a, b, x, y, W, R), f"pair ordering a={a} b={b} g={g}")
            if len(W) == 1:
                K2 |= W
            if len(R) == 1:
                K1 |= R
        check(len(K1) < 3 and len(K2) < 3, f"KKM test a={a} b={b}: K1={K1} K2={K2}")
        allK += (len(K1) == 3 or len(K2) == 3)
        tight += (max(len(K1), len(K2)) == 2)
        # predicted exclusions for interior pairs
        if all(v > 0 for v in a) and all(v > 0 for v in b):
            rho = [b[w] / a[w] for w in range(3)]
            check(not (K2 & {w for w in range(3) if rho[w] == max(rho)}), "W={argmax b/a} absent")
            check(not (K1 & {w for w in range(3) if rho[w] == min(rho)}), "R={argmin b/a} absent")
print(f"    {npairs} index pairs (interior, near-T, edge, vertex mixes), {ndis} exact disagreements:")
print(f"    generalised pair ordering holds at every disagreement; pairs failing the KKM test: {allK} (must be 0)")
print(f"    pairs with two of the three single types present on one side (one type short of failing): {tight}")

# ------------------------------------------------------------------ (C)
print("(C) multicap controls (exact D_K models), eps = 3/10; worlds numbered 1,2,3")


def cut_vertices(s):
    """vertices of K_s = M cap {m_i <= c+eps-s_i}, all s_i <= delta < eps/3."""
    vs = []
    for i in range(3):
        if s[i] == 0:
            vs.append(Mv[i])
        else:
            for j in range(3):
                if j != i:
                    vs.append([Mv[i][w] + (s[i] / eps) * (Mv[j][w] - Mv[i][w]) for w in range(3)])
    return vs


def adv_poly(V, g):
    vals = [sum(m[w] * g[w] for w in range(3)) for m in V]
    if min(vals) > 0:
        return 1
    if max(vals) < 0:
        return -1
    return 0


d = eps / 8
cases = {'single cap (d,0,0)': (d, 0, 0), 'combined cut (d,d,0)': (d, d, 0), 'full cut (d,d,d)': (d, d, d)}
VT = Mv
gs = rng.normal(size=(400000, 3))
for name, s in cases.items():
    Vc = cut_vertices([Fr(x) for x in s])
    Vcf = np.array([[float(x) for x in m] for m in Vc])
    VTf = np.array([[float(x) for x in m] for m in VT])
    vT = gs @ VTf.T
    vC = gs @ Vcf.T
    aT = np.where(vT.min(1) > 0, 1, np.where(vT.max(1) < 0, -1, 0))
    aC = np.where(vC.min(1) > 0, 1, np.where(vC.max(1) < 0, -1, 0))
    idx = np.nonzero(aT != aC)[0]
    K1, K2 = set(), set()
    nex = 0
    for i in idx[:4000]:
        g = [Fr(float(v)).limit_denominator(10 ** 6) for v in gs[i]]
        x, y = adv_poly(VT, g), adv_poly(Vc, g)   # x = T, y = cut
        if x == y:
            continue
        nex += 1
        W, R = WR(x, y, g)
        if len(W) == 1:
            K2 |= W
        if len(R) == 1:
            K1 |= R
    fails = (len(K1) == 3) or (len(K2) == 3)
    print(f"    T vs {name}: {nex} exact disagreements; K1 (cut better only at k) = {sorted(k + 1 for k in K1)}, "
          f"K2 (cut worse only at k) = {sorted(k + 1 for k in K2)}; KKM test {'FAILS' if fails else 'passes'}")
    expect_fail = name != 'single cap (d,0,0)'
    check(fails == expect_fail, f"multicap control {name}")

print("ALL PASS" if OK else "SOME CHECK FAILED")
