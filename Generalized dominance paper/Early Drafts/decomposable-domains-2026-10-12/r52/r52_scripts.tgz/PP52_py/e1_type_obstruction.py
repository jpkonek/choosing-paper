"""PP52 script 2 (CHECKED): own-argmax selectivity does not escape the PP45 type test (Theorem T).

E1 is the only kind of type-test failure that the KKM test (Theorem K) does not already exclude:
  disagreement types (W = worlds where M is worse than N, R = where better), worlds 0,1,2 (= 1,2,3 in the note)
     R1: W={1}, R={0,2}     R2: W={0,2}, R={1}     R3: W={2}, R={0,1}     R4: W={0,1}, R={2}.
Part (A), dual side.  Any (PX) certificate is a pair of matrices P, Q whose rows p^w, q^w lie in the duals of
  the role cones (role units: p^w_w >= sum_{v!=w} |p^w_v|, p^w_v <= 0), plus Bayes weights pi^N, pi^M.  With
  xh(t) = P^T t / pi^N and yh(t) = Q^T t / pi^M (t in the simplex), type k is UNBLOCKED (so no fields of that
  type can satisfy (PX)) iff (Gordan) xh, yh are in
     R1: T1(xh) & B1(yh)   R2: B1(xh) & T1(yh)   R3: T2(xh) & B2(yh)   R4: B2(xh) & T2(yh),
  T_w(z): z_w >= max(0, z_others);  B_w(z): min(z_others) >= max(0, z_w).
  The proof in the note: t* = KKM point of xh (xh(t*) = kappa*1); either yh(t*) is in T1,T2,B1 or B2 (violation
  at t*), or yh(t*) is strictly top at world 0, and then on the segment [a_x, t*] (a_x on edge e1e2 with
  xh_1 = xh_2) the first point b with yh_0 = max(yh_1, yh_2) is a violation of type R1 or R3.
  We draw random rational certificates and VERIFY EXACTLY that the predicted point is a violation.
Part (B), primal side.  Random own-Bayes type-constant E1 fields (with all agreement regions): the exact LP finds a
  co-active two-cycle ((PX) failure) at some world, verified by an exact feasible point; and we count how often
  it upgrades to an exact (TC) violation under the OA rule.
Run: python3 -I -B e1_type_obstruction.py > e1_type_obstruction.out
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import random
import math
from oa_lib import *

random.seed(2052)
OK = True


def check(c, m):
    global OK
    if not c:
        OK = False
        print("FAIL:", m)


def rq(lo, hi, den=12):
    return Fr(random.randint(int(lo * den), int(hi * den)), den)


def rand_dual_rows():
    P = []
    for w in range(3):
        row = [Fr(0)] * 3
        row[w] = Fr(1)
        budget = rq(0, 1)
        others = [v for v in range(3) if v != w]
        s = rq(0, 1)
        row[others[0]] = -budget * s
        row[others[1]] = -budget * (1 - s)
        P.append(row)
    return P


def T(z, w):
    return z[w] >= max([Fr(0)] + [z[v] for v in range(3) if v != w])


def Bp(z, w):
    return min(z[v] for v in range(3) if v != w) >= max(Fr(0), z[w])


def unblocked_at(xh, yh):
    return [T(xh, 1) and Bp(yh, 1), Bp(xh, 1) and T(yh, 1), T(xh, 2) and Bp(yh, 2), Bp(xh, 2) and T(yh, 2)]


def hat(M, t, pi):
    return [sum(t[w] * M[w][u] for w in range(3)) / pi[u] for u in range(3)]


print("(A) dual side: predicted violation point verified exactly")
n_at_tstar = n_on_seg = 0
for trial in range(2000):
    P, Q = rand_dual_rows(), rand_dual_rows()
    piN = [rq(0.2, 3) for _ in range(3)]
    piM = [rq(0.2, 3) for _ in range(3)]
    if min(piN) == 0 or min(piM) == 0:
        continue
    # t*: xh_0 = xh_1 = xh_2, sum t = 1
    rows = [[P[w][0] / piN[0] - P[w][1] / piN[1] for w in range(3)],
            [P[w][1] / piN[1] - P[w][2] / piN[2] for w in range(3)],
            [Fr(1)] * 3]
    ts = exact_solve(rows, [Fr(0), Fr(0), Fr(1)])
    if ts is None:
        continue  # degenerate (non-unique) draw; skipped
    check(all(v >= 0 for v in ts), f"KKM point in simplex {ts}")
    xs, ys = hat(P, ts, piN), hat(Q, ts, piM)
    check(xs[0] == xs[1] == xs[2] and xs[0] >= 0, "triple point")
    if any(unblocked_at(xs, ys)):
        n_at_tstar += 1
        continue
    check(ys[0] > ys[1] and ys[0] > ys[2] and ys[1] < 0 and ys[2] < 0, "yh(t*) strictly top at 0, negative elsewhere")
    # a_x on edge e1e2 with xh_1 = xh_2
    f = lambda t: hat(P, t, piN)[1] - hat(P, t, piN)[2]
    e1, e2 = [Fr(0), Fr(1), Fr(0)], [Fr(0), Fr(0), Fr(1)]
    f1, f2 = f(e1), f(e2)
    check(f1 > 0 > f2, "xh_1 - xh_2 changes sign on e1e2")
    lam = f1 / (f1 - f2)
    ax = [Fr(0), 1 - lam, lam]
    # on [ax, t*]: g(s) = yh_0 - max(yh_1, yh_2), g(0) <= 0 < g(1); find first zero exactly
    def pt(s):
        return [(1 - s) * ax[i] + s * ts[i] for i in range(3)]
    best = None
    for j in (1, 2):
        y0 = [hat(Q, ax, piM)[i] for i in range(3)]
        y1 = ys
        d0 = y0[0] - y0[j]
        d1 = y1[0] - y1[j]
        if d0 <= 0 < d1:
            s = -d0 / (d1 - d0)
            yb = hat(Q, pt(s), piM)
            if yb[0] >= max(yb[1], yb[2]) and (best is None or s < best):
                best = s
        elif d0 > 0:
            pass
    if best is None:
        # g(ax) > 0 cannot happen: yh_0 <= 0 <= max on e1e2
        check(False, "no crossing found")
        continue
    b = pt(best)
    xb, yb = hat(P, b, piN), hat(Q, b, piM)
    check(xb[1] == xb[2] and xb[1] >= xb[0] and xb[1] >= 0, "T1 and T2 for xh on [a_x,t*]")
    viol = unblocked_at(xb, yb)
    check(viol[0] or viol[2], f"violation R1 or R3 at b: {viol}")
    n_on_seg += 1
print(f"    {n_at_tstar + n_on_seg} exact certificate draws: violation at t* in {n_at_tstar}, "
      f"on the segment [a_x, t*] in {n_on_seg}; every draw leaves a type unblocked")

# ---------------------------------------------------------------- (B) primal side
print("(B) primal side: random own-Bayes E1 type models under OA, exact LP")


def region_list():
    regs = [('U', A, A)]
    for c in range(3):
        for x in (A, S, B):
            regs.append((c, x, x))
    regs += [(1, S, A), (1, A, S), (2, S, A), (2, A, S)]
    return regs


REGS = region_list()


def rand_incr():
    return [(rq(0.25, 4), rq(0.25, 4), Fr(1)) for _ in range(3)]


def build_random():
    pis = {m: [rq(0.3, 3) for _ in range(3)] for m in 'NM'}
    regions = []
    for cls, xn, xm in REGS:
        reg = dict(cls=cls, adv={'N': xn, 'M': xm}, L={})
        for mdl in 'NM':
            for _ in range(5000):
                reg['L'][mdl] = make_field(cls, rand_incr())
                if own_bayes_margin(reg, mdl, pis[mdl]) > 0:
                    break
            else:
                return None
        regions.append(reg)
    return regions, pis


npx = ntc = ntot = 0
for trial in range(40):
    out = build_random()
    if out is None:
        continue
    regions, pis = out
    ntot += 1
    pxviol = []
    for w in range(3):
        rows, ks = px_rows(regions, 'N', 'M', w, 'OA')
        d = decide(rows)
        check(d != 'UNKNOWN', "PX decided")
        if d != 'SAFE':
            pxviol.append(w)
    check(len(pxviol) > 0, "E1: (PX) fails at some world for every own-Bayes field")
    npx += bool(pxviol)
    tcv = False
    for sh in (('G', 'M', 'N'), ('G', 'N', 'M')):
        for w in pxviol:
            m = tc_guidance_violation(regions, sh, w, 'OA')
            if m not in (None, 'UNVERIFIED'):
                tcv = True
    ntc += tcv
print(f"    {ntot} random designs: exact (PX) failure in {npx}; exact (TC) violation (shape NMG/MNG) in {ntc}")
print("ALL PASS" if OK else "SOME CHECK FAILED")
