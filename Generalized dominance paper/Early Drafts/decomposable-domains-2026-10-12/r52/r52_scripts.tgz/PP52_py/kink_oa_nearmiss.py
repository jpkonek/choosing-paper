"""PP52 script 6 (search NUMERICS; verdicts CHECKED): nearest-miss OA designs for the kink triple.
Runs the dual-side search of kink_oa_dual.py (pairs (A,B), (A,D), OA duals) until a certificate leaves exactly
one infeasible cell, builds the corresponding type-constant fields, and decides EXACTLY:
  own-Bayes; (PX) for all three pairs at every world; and accepted triangles with a nontrivial guidance link
  (always genuine (TC) violations) for every shape with a guidance link.
Usage: python3 -I -B kink_oa_nearmiss.py <seed> > kink_oa_nearmiss.out
"""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
seed = int(sys.argv[1]) if len(sys.argv) > 1 else 21
sys.argv = ['kink_oa.py']
import kink_oa as K
import oa_lib
import numpy as np
K.PAIRS[:] = [('A', 'B'), ('A', 'D')]
rng = np.random.default_rng(seed)
state = None
for rs in range(60):
    cert = K.rand_cert(rng, True); pis = {N: list(np.exp(rng.normal(0, 1, 3))) for N in K.GATES}
    sc = K.cert_score(cert, pis)
    for it in range(400):
        if sc <= 1: break
        c2 = dict(cert); p2 = {N: list(v) for N, v in pis.items()}
        if rng.random() < 0.3:
            N = K.GATES[rng.integers(3)]; w = rng.integers(3); p2[N][w] *= math.exp(rng.normal(0, 0.5))
        else:
            key = list(c2.keys())[rng.integers(len(c2))]; w = key[2]; p, q = c2[key]
            def mut(r, scale):
                o = [v for v in range(3) if v != w]; t = [-r[v] / r[w] for v in o]
                t = [min(max(x + rng.normal(0, 0.15), 0), 1) for x in t]
                if sum(t) > 1: t = [x / sum(t) for x in t]
                return [x * scale * r[w] for x in K.dual_row(w, t[0], t[1])]
            c2[key] = (mut(p, 1.0), q) if rng.random() < 0.5 else (p, mut(q, math.exp(rng.normal(0, 0.5))))
        s2 = K.cert_score(c2, p2)
        if s2 <= sc: cert, pis, sc = c2, p2, s2
    if sc == 1:
        state = (cert, pis); print(f"near-miss certificate at restart {rs}"); break
OK = True
if state:
    regs, P, bad = K.design_from_cert(*state)
    print("infeasible cell under the certificate:", [K.TYPES[k] for k in bad])
    oa_lib.EXACT[0] = True
    b = all(oa_lib.own_bayes_margin(r, N, P[N]) > 0 for r in regs for N in K.GATES)
    print("own-Bayes (exact):", b)
    for (N, M) in [('A', 'B'), ('A', 'D'), ('B', 'D')]:
        for w in range(3):
            rows, ks = oa_lib.px_rows(regs, N, M, w, 'OA')
            d = oa_lib.decide(rows)
            print(f"  (PX) {N}{M} world {w + 1}: {'holds (exact certificate)' if d == 'SAFE' else ('FAILS (exact co-active two-cycle)' if d != 'UNKNOWN' else 'unknown')}")
    nv = 0
    for sh in oa_lib.all_shapes(K.GATES):
        if 'G' not in sh: continue
        for w in range(3):
            m = oa_lib.tc_guidance_violation(regs, sh, w, 'OA')
            if m not in (None, 'UNVERIFIED'):
                nv += 1
                if nv <= 4: print(f"  exact (TC) violation: shape {sh}, world {w + 1}")
    print(f"  shapes x worlds with an exact (TC) violation: {nv}")
print("done")
