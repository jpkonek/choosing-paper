"""PP52 script 3: what own-argmax selectivity does buy -- field systems that universal acceptance rejects.

Type model of T and a single cap C at vertex 1 (worlds 0,1,2 here = 1,2,3 in the note): C answers where T is
silent on three pieces of band 1 (PP45 Lemma 1.1):
   A-piece  class M_1, C = A (sigma wrong only at world 1)
   B-piece  class M_2, C = B (sigma right only at world 2)
   B-piece  class M_3, C = B (sigma right only at world 3)
and T = C on U and on every class with advice A, S, B.  The pair passes the type test and the KKM test.
Search (float LP) for type-constant own-Bayes fields such that
   (i)  under UNI (zero-accepting gate union) an exact (TC) violation with a nontrivial guidance link exists;
   (ii) under OA every check passes: own-Bayes, (PX) at all worlds, every triangle shape at every world
        (exact Farkas certificates).
The design found is printed with exact rational data and re-verified in exact arithmetic.
Run: python3 -I -B oa_room.py > oa_room.out
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import random
import math
import oa_lib
from oa_lib import *

random.seed(4)
OK = True


def check(c, m):
    global OK
    if not c:
        OK = False
        print("FAIL:", m)


REGS = [('U', A, A)] + [(c, x, x) for c in range(3) for x in (A, S, B)] + [(0, S, A), (1, S, B), (2, S, B)]


def q(x):
    return Fr(x).limit_denominator(24)


def rand_incr():
    return [(q(math.exp(random.uniform(-1.2, 1.2))), q(math.exp(random.uniform(-1.2, 1.2))), Fr(2)) for _ in range(3)]


def build(P):
    return [dict(cls=cls, adv={'T': xt, 'C': xc}, L={'T': make_field(cls, P['T'][k]), 'C': make_field(cls, P['C'][k])})
            for k, (cls, xt, xc) in enumerate(REGS)]


def fix_bayes(P, pis):
    for mdl in ('T', 'C'):
        for k, (cls, xt, xc) in enumerate(REGS):
            for _ in range(3000):
                reg = dict(cls=cls, adv={'T': xt, 'C': xc}, L={mdl: make_field(cls, P[mdl][k])})
                if own_bayes_margin(reg, mdl, pis[mdl]) > 0:
                    break
                P[mdl][k] = rand_incr()
            else:
                return False
    return True


def uni_violation(regions):
    for sh in all_shapes(['T', 'C']):
        if 'G' not in sh:
            continue
        for w in range(3):
            m = tc_guidance_violation(regions, sh, w, 'UNI')
            if m not in (None, 'UNVERIFIED'):
                return (sh, w, m)
    return None


oa_lib.EXACT[0] = False
found = None
for trial in range(400):
    pis = {m: [q(math.exp(random.uniform(-0.7, 0.7))) for _ in range(3)] for m in ('T', 'C')}
    P = {m: [rand_incr() for _ in REGS] for m in ('T', 'C')}
    if not fix_bayes(P, pis):
        continue
    regions = build(P)
    res = full_check(regions, ['T', 'C'], pis, 'OA')
    b, bp, bt = summary(res)
    if not (b and not bp and not bt):
        continue
    oa_lib.EXACT[0] = True
    uv = uni_violation(regions)
    res = full_check(regions, ['T', 'C'], pis, 'OA')
    b, bp, bt = summary(res)
    oa_lib.EXACT[0] = False
    if uv is not None and b and not bp and not bt:
        found = (P, pis, regions, uv, res)
        print(f"design found at trial {trial}")
        break

check(found is not None, "a field system accepted by OA and rejected by UNI exists in the search")
if found:
    P, pis, regions, uv, res = found
    print("Bayes weights (role units):", {m: [str(v) for v in pis[m]] for m in pis})
    print("fields: increments (alpha, beta, gamma) per world, regions in order", REGS)
    for m in ('T', 'C'):
        for k, inc in enumerate(P[m]):
            print(f"  {m} region {k} {REGS[k]}: " + "; ".join(f"({a},{b},{c})" for a, b, c in inc))
    sh, w, m = uv
    print(f"UNI: exact (TC) violation, shape {sh}, world {w + 1}; masses verified exactly (nonzero entries: "
          f"{sum(1 for v in m if v)})")
    nsafe = sum(1 for v in res['tc'].values() if v == 'SAFE') + sum(1 for v in res['px'].values() if v == 'SAFE')
    print(f"OA: own-Bayes {res['bayes']}; {nsafe} checks (PX x3 + 10 shapes x 3 worlds) all SAFE by exact Farkas "
          f"certificates")
    # CG2 at each world, universal sense: sandwich test on the disagreement pieces
    for w in range(3):
        lo, hi = Fr(0), None
        for reg in regions:
            if reg['adv']['T'] == reg['adv']['C']:
                continue
            fT = delta(reg, 'T', reg['adv']['T'], reg['adv']['C'])[w]
            fC = delta(reg, 'C', reg['adv']['T'], reg['adv']['C'])[w]
            r = fC / fT
            if fT > 0:
                hi = r if hi is None else min(hi, r)
            else:
                lo = max(lo, r)
        print(f"  CG2 sandwich at world {w + 1}: sup over f^T<0 of f^C/f^T = {lo}, inf over f^T>0 = {hi}: "
              f"{'holds' if hi is None or lo <= hi else 'FAILS'}")
    print("additive witnesses for the OA-accepted set (exact):")
    nw = 0
    for w in range(3):
        d = witness_decide(regions, ['T', 'C'], w, 'OA')
        check(d != 'UNKNOWN', f"witness decided at world {w + 1}")
        nw += d == 'NONE'
        print(f"  world {w + 1}: {'no additive witness (exact Farkas certificate)' if d == 'NONE' else d}")
print("ALL PASS" if OK else "SOME CHECK FAILED")
