"""PP52 script 5 (NUMERICS search; every reported per-cell LP is a float LP): the kink triple under OA, dual side.
(PX) for the pairs through T, (A,B) and (A,D) [option 'two'] or all three pairs ['three'], is searched in
certificate space: one dual row pair (p, q) per pair and world ('tilt' = OA duals; 'diag' = union duals, i.e.
CG2 constants), plus Bayes weights.  For given certificates each of the 28 cell types is an LP in the role-unit
increments; the score is the number of infeasible cells.  Reports, per restart, the score and the infeasible
cell types (class, advice of A, B, D; class 0 = M_1; advice 0 = A, 1 = S, 2 = B).
Usage: python3 -I -B kink_oa_dual.py <seed> tilt|diag two|three > kink_oa_dual_<...>.out
"""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
seed=int(sys.argv[1]); tilt=sys.argv[2]=='tilt'; pairs=sys.argv[3]
sys.argv=['kink_oa.py']
import kink_oa as K
K.PAIRS=[('A','B'),('A','D')] if pairs=='two' else [('A','B'),('A','D'),('B','D')]
if len(sys.argv)>0: pass
import numpy as np
rng=np.random.default_rng(seed)
best=99
for rs in range(150):
    cert=K.rand_cert(rng,tilt); pis={N:list(np.exp(rng.normal(0,1,3))) for N in K.GATES}
    sc=K.cert_score(cert,pis)
    for it in range(400):
        if sc==0: break
        c2=dict(cert); p2={N:list(v) for N,v in pis.items()}
        if rng.random()<0.3:
            N=K.GATES[rng.integers(3)]; w=rng.integers(3); p2[N][w]*=math.exp(rng.normal(0,0.5))
        else:
            key=list(c2.keys())[rng.integers(len(c2))]; w=key[2]
            p,q=c2[key]
            def mut(r,scale):
                if not tilt: return [x*scale for x in r]
                o=[v for v in range(3) if v!=w]; t=[-r[v] for v in o]
                t=[min(max(x+rng.normal(0,0.15),0),1) for x in t]
                if sum(t)>1: t=[x/sum(t) for x in t]
                rr=K.dual_row(w,t[0],t[1]); return [x*scale for x in rr]
            if rng.random()<0.5: c2[key]=(mut(p,1.0),q)
            else: c2[key]=(p,mut(q,math.exp(rng.normal(0,0.5)) if True else 1.0))
        s2=K.cert_score(c2,p2)
        if s2<=sc: cert,pis,sc=c2,p2,s2
    best=min(best,sc)
    print("restart",rs,"score",sc,"bad",[K.TYPES[k] for k in range(len(K.TYPES)) if not K.cell_lp(k,cert,pis)],flush=True)
    if rs%10==0: print("rs",rs,"best",best,flush=True)
    if sc==0:
        print("FOUND"); import pickle; pickle.dump((cert,pis),open('/tmp/claude-0/-home-claude/516e9253-01b8-5264-9018-734bfcf63f58/scratchpad/kcert_%d.pkl'%seed,'wb')); break
print("best",best)
