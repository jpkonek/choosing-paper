"""PP52 script 4: the PP51 kink triple under the own-argmax (OA) rule.

Triple (PP51 Thm 5.1 instance, eps = 3/10):  A = u,  B = (406,421,373)/1200,  D = (406,373,421)/1200.
Cells: exact enumeration of the plane arrangement (code copied from PP51_py/post51.py, unchanged in substance);
one region per (class, advice of A, B, D) (28 types; PP51's 31 types merge where all three are silent), which loses
nothing because every condition is per cell type.
Map to the oa_lib conventions: canonical h (sum > 0); wr = {w : h_w < 0}; |wr| = 0 -> class U, answer = A;
|wr| = 1 -> class M_c (c in wr), answer = A (majority orientation); |wr| = 2 -> class M_c (c the positive world),
answer = B (minority orientation).  A model's advice is the answer or S (the family is two-valued).
Search (float LP, then exact verification): own-Bayes fields under OA with (PX) for all pairs and every
triangle shape with up to three gates at every world.  Control: the same search under UNI.
Usage: python3 -I -B kink_oa.py [seed] [restarts] [iterations]  > kink_oa.out
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import itertools, random, math, json
import oa_lib
from oa_lib import *


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def sgn(x):
    return (x > 0) - (x < 0)


def mverts(eps):
    c = (1 - eps) / 3
    return [tuple(c + (eps if i == j else 0) for j in range(3)) for i in range(3)]


def had(a, b):
    return tuple(x * y for x, y in zip(a, b))


def adv_post(eps, a, g):
    vals = [dot(had(a, m), g) for m in mverts(eps)]
    return 1 if min(vals) > 0 else (-1 if max(vals) < 0 else 0)


def cells(eps, models):
    ns = [had(a, m) for a in models for m in mverts(eps)] + \
         [tuple(Fr(int(i == w)) for i in range(3)) for w in range(3)] + [(Fr(1), Fr(1), Fr(1))]
    sv_ = lambda g: tuple(sgn(dot(n, g)) for n in ns)
    found = {}
    for i, j in itertools.combinations(range(len(ns)), 2):
        r0 = cross(ns[i], ns[j])
        if r0 == (0, 0, 0):
            continue
        for r in (r0, tuple(-x for x in r0)):
            through = [k for k in range(len(ns)) if dot(ns[k], r) == 0]
            ds = [d for d in (cross(ns[k], r) for k in through) if d != (0, 0, 0)]
            for P, Q in itertools.combinations(range(len(ds)), 2):
                for s1, s2 in itertools.product((1, -1), repeat=2):
                    d = tuple(s1 * ds[P][q] + s2 * ds[Q][q] for q in range(3))
                    if d == (0, 0, 0):
                        continue
                    eta = Fr(1, 8)
                    g = None
                    while eta > Fr(1, 2 ** 60):
                        gg = tuple(r[q] + eta * d[q] for q in range(3))
                        sv = sv_(gg)
                        if 0 not in sv and all(sv[k] == sgn(dot(ns[k], r)) for k in range(len(ns)) if k not in through):
                            g = gg
                            break
                        eta /= 2
                    if g is None:
                        continue
                    if sum(g) < 0:
                        g = tuple(-x for x in g)
                    found.setdefault(sv_(g), g)
    return list(found.values())


EPS = Fr(3, 10)
MODELS = {'A': (Fr(1, 3),) * 3, 'B': (Fr(406, 1200), Fr(421, 1200), Fr(373, 1200)),
          'D': (Fr(406, 1200), Fr(373, 1200), Fr(421, 1200))}
GATES = ['A', 'B', 'D']


def type_regions():
    out = {}
    for g in cells(EPS, list(MODELS.values())):
        wr = tuple(w for w in range(3) if g[w] < 0)
        if len(wr) == 0:
            cls, ans = 'U', A
        elif len(wr) == 1:
            cls, ans = wr[0], A
        else:
            cls, ans = [w for w in range(3) if g[w] > 0][0], B
        adv = {}
        for nm, a in MODELS.items():
            x = adv_post(EPS, a, g)
            assert x in (0, 1)
            adv[nm] = ans if x == 1 else S
        key = (cls, tuple(adv[n] for n in GATES))
        out.setdefault(key, g)
    return sorted(out.keys(), key=str)


TYPES = type_regions()


def q(x):
    return Fr(x).limit_denominator(24)


def rand_incr():
    return [(q(math.exp(random.uniform(-1.3, 1.3))), q(math.exp(random.uniform(-1.3, 1.3))), Fr(2)) for _ in range(3)]


def build(P):
    regs = []
    for k, (cls, advs) in enumerate(TYPES):
        regs.append(dict(cls=cls, adv=dict(zip(GATES, advs)), L={n: make_field(cls, P[n][k]) for n in GATES}))
    return regs


def fix_bayes(P, pis):
    for n in GATES:
        for k, (cls, advs) in enumerate(TYPES):
            for _ in range(3000):
                reg = dict(cls=cls, adv=dict(zip(GATES, advs)), L={n: make_field(cls, P[n][k])})
                if own_bayes_margin(reg, n, pis[n]) > 0:
                    break
                P[n][k] = rand_incr()
            else:
                return False
    return True


def involved(P, pis, rule, res):
    """(gate, region) pairs carrying mass in some float violation"""
    regs = build(P)
    out = []
    for (N, M, w), v in res['px'].items():
        if v != 'SAFE' and v[1] is not None:
            rows, ks = px_rows(regs, N, M, w, rule)
            out += [(g, ks[i]) for i, x in enumerate(v[1]) if x > 1e-9 for g in (N, M)]
    for (sh, w), v in res['tc'].items():
        if v != 'SAFE' and v[1] is not None:
            rows, cols = tc_rows(regs, sh, w, rule)
            out += [(g, cols[i][0]) for i, x in enumerate(v[1]) if x > 1e-9 for g in sh if g != 'G']
    return out


STAGE1 = [('A', 'B', 'D'), ('A', 'D', 'B'), ('A', 'B', 'G'), ('A', 'G', 'B'), ('A', 'D', 'G'), ('A', 'G', 'D'),
          ('B', 'D', 'G'), ('B', 'G', 'D')]


def score(P, pis, rule, shapes=STAGE1):
    res = full_check(build(P), GATES, pis, rule, shapes=shapes)
    b, bp, bt = summary(res)
    return (0 if b else 1000) + 5 * len(bp) + len(bt), res


if __name__ == '__main__':
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    R = int(sys.argv[2]) if len(sys.argv) > 2 else 10
    IT = int(sys.argv[3]) if len(sys.argv) > 3 else 60
    rule = sys.argv[4] if len(sys.argv) > 4 else 'OA'
    random.seed(seed)
    print(f"{len(TYPES)} cell types; rule {rule}")
    oa_lib.EXACT[0] = False
    best = None
    for rs in range(R):
        pis = {n: [q(math.exp(random.uniform(-0.8, 0.8))) for _ in range(3)] for n in GATES}
        P = {n: [rand_incr() for _ in TYPES] for n in GATES}
        if not fix_bayes(P, pis):
            continue
        sc, res = score(P, pis, rule)
        for it in range(IT):
            if sc == 0:
                break
            P2 = {n: list(P[n]) for n in P}
            pis2 = {n: list(pis[n]) for n in pis}
            inv = involved(P, pis, rule, res)
            n = random.choice(GATES)
            if inv and random.random() < 0.8:
                n, k0 = random.choice(inv)
            else:
                k0 = random.randrange(len(TYPES))
            if random.random() < 0.1:
                w = random.randrange(3)
                pis2[n][w] = q(pis2[n][w] * math.exp(random.gauss(0, 0.5)))
            else:
                k = k0
                inc = list(P2[n][k]); w = random.randrange(3)
                al, be, ga = inc[w]
                inc[w] = (q(al * math.exp(random.gauss(0, 0.7))), q(be * math.exp(random.gauss(0, 0.7))), ga)
                P2[n][k] = inc
            if not fix_bayes(P2, pis2):
                continue
            sc2, res2 = score(P2, pis2, rule)
            if sc2 <= sc:
                P, pis, sc, res = P2, pis2, sc2, res2
        b, bp, bt = summary(res)
        print(f"restart {rs}: score {sc}; px fails {bp}; tc fails {[(s, w + 1) for s, w in bt][:6]}", flush=True)
        if best is None or sc < best[0]:
            best = (sc, P, pis)
        if sc == 0:
            break
    sc, P, pis = best
    if sc == 0:
        oa_lib.EXACT[0] = True
        res = full_check(build(P), GATES, pis, rule, shapes=all_shapes(GATES))
        b, bp, bt = summary(res)
        print("EXACT re-check:", "own-Bayes", b, "px fails", bp, "tc fails", bt)
        with open(f'kink_oa_design_{rule}.json', 'w') as f:
            json.dump({'types': [[str(c), list(a)] for c, a in TYPES],
                       'pis': {n: [str(v) for v in pis[n]] for n in pis},
                       'P': {n: [[[str(x) for x in t] for t in inc] for inc in P[n]] for n in P}}, f)
        print("design written")
    print("best score", sc)


# ---------------------------------------------------------------- structured designs
# Stage A: fields with strict pairwise CG2 for all three pairs (UNI-compatible pairs), from an LP in the
#          sigma-vs-silence increments e^N_{k,w} for given pair ratios kappa (one per pair and world).
# Stage B: role weights theta^N (OA) searched; (PX) then holds automatically (OA accepts a subset of UNI's
#          records, and strict CG2 gives UNI's (PX)); only the triangle shapes remain to be checked.
from scipy.optimize import linprog
import numpy as np

PAIRS = [('A', 'B'), ('A', 'D'), ('B', 'D')]


def sigma_correct(cls, ans, w):
    return rank(cls, ans, w) == 0


def pairwise_fields(kap, margin=0.05):
    """kap[(N,M)][w] > 0.  Variables e[N][k][w].  Returns dict or None."""
    idx = {}
    for N in GATES:
        for k in range(len(TYPES)):
            for w in range(3):
                idx[(N, k, w)] = len(idx)
    nv = len(idx)
    Aub, bub, bounds = [], [], [None] * nv
    for (N, k, w), j in idx.items():
        cls, advs = TYPES[k]
        ans = A if cls == 'U' else next((x for x in advs if x != S), None)
        if ans is None:   # nobody answers: orientation of sigma is the majority (A) by convention
            ans = A
        bounds[j] = (-100, -1) if sigma_correct(cls, ans, w) else (1, 100)
    for N in GATES:
        for k, (cls, advs) in enumerate(TYPES):
            own = dict(zip(GATES, advs))[N]
            row = [0.0] * nv
            for w in range(3):
                row[idx[(N, k, w)]] = 1.0
            if own == S:     # S strictly better: sum e > margin
                Aub.append([-x for x in row]); bub.append(-margin)
            else:            # sigma strictly better: sum e < -margin
                Aub.append(row); bub.append(-margin)
    for (N, M) in PAIRS:
        for k, (cls, advs) in enumerate(TYPES):
            ad = dict(zip(GATES, advs))
            if ad[N] == ad[M]:
                continue
            for w in range(3):
                row = [0.0] * nv
                kw = kap[(N, M)][w]
                if ad[N] == S:   # move S -> sigma: f = e;  need kw e^N <= e^M - margin*|.|
                    row[idx[(N, k, w)]] = kw; row[idx[(M, k, w)]] = -1.0
                else:            # move sigma -> S: f = -e: -kw e^N <= -e^M  <=>  e^M - kw e^N <= 0
                    row[idx[(N, k, w)]] = -kw; row[idx[(M, k, w)]] = 1.0
                Aub.append(row); bub.append(-margin)
    res = linprog(np.zeros(nv), A_ub=np.array(Aub), b_ub=np.array(bub), bounds=bounds, method='highs')
    if res.status != 0:
        return None
    return {key: res.x[j] for key, j in idx.items()}


def regions_from_e(e, theta):
    """full penalty tables in ROLE units; Bayes weights pi = (1/3)/theta"""
    regs = []
    for k, (cls, advs) in enumerate(TYPES):
        ans = A if cls == 'U' else next((x for x in advs if x != S), A)
        L = {}
        for N in GATES:
            tab = []
            for w in range(3):
                ev = Fr(e[(N, k, w)]).limit_denominator(1000)
                row = [Fr(0)] * 4
                if sigma_correct(cls, ans, w):   # sigma correct: l(sigma)=0, l(S)=-e, l(-sigma)=-e+60, l(X)=-e+70
                    vals = {ans: Fr(0), S: -ev}
                    opp = B if ans == A else A
                    vals[opp] = -ev + 1000; vals[X] = -ev + 1100
                else:                              # sigma wrong: l(-sigma)=0, l(S)=1/100, l(sigma)=1/100+e, l(X)=+70
                    opp = B if ans == A else A
                    vals = {opp: Fr(0), S: Fr(1, 100), ans: Fr(1, 100) + ev, X: Fr(1, 100) + ev + 1100}
                tab.append([theta[N][w] * vals[x] for x in range(4)])
            L[N] = tab
        regs.append(dict(cls=cls, adv=dict(zip(GATES, advs)), L=L))
    pis = {N: [Fr(1, 3) / theta[N][w] for w in range(3)] for N in GATES}
    return regs, pis


# ---------------------------------------------------------------- dual-side search for (PX) on all pairs
# Certificates: for each pair (N,M) and world w a pair of rows (p, q) in the duals of the OA role cones
# (role units: p_w = 1, p_v = -t_v <= 0, t_v summing to <= 1).  Given certificates and Bayes weights pi,
# each cell type is an LP in the role-unit sigma-vs-silence increments e^N (signs fixed by correctness).
def dual_row(w, t1, t2):
    r = [0.0] * 3
    others = [v for v in range(3) if v != w]
    r[w] = 1.0; r[others[0]] = -t1; r[others[1]] = -t2
    return r


def cell_lp(k, cert, pis, margin=1.0, want_x=False):
    cls, advs = TYPES[k]
    ad = dict(zip(GATES, advs))
    ans = A if cls == 'U' else next((x for x in advs if x != S), A)
    var = {(N, w): 3 * i + w for i, N in enumerate(GATES) for w in range(3)}
    bounds = [None] * 9
    for (N, w), j in var.items():
        bounds[j] = (-50, -1) if sigma_correct(cls, ans, w) else (1, 50)
    Aub, bub = [], []
    for N in GATES:
        row = [0.0] * 9
        for w in range(3):
            row[var[(N, w)]] = pis[N][w]
        if ad[N] == S:
            Aub.append([-x for x in row]); bub.append(-margin)
        else:
            Aub.append(row); bub.append(-margin)
    for (N, M) in PAIRS:
        if ad[N] == ad[M]:
            continue
        sN = 1.0 if ad[N] == S else -1.0          # f^N = sN * e^N  (N's increments, move N -> M)
        sM = -(1.0 if ad[N] == S else -1.0)       # g^M = M's increments, move M -> N = -f^M, f^M = sN e^M
        for w in range(3):
            p, q = cert[(N, M, w)]
            row = [0.0] * 9
            for v in range(3):
                row[var[(N, v)]] += p[v] * sN
                row[var[(M, v)]] += q[v] * sM
            Aub.append(row); bub.append(-margin)
    res = linprog(np.zeros(9), A_ub=np.array(Aub), b_ub=np.array(bub), bounds=bounds, method='highs')
    if want_x:
        return res.x if res.status == 0 else None
    return res.status == 0


def rand_cert(rng, tilt=True):
    cert = {}
    for (N, M) in PAIRS:
        for w in range(3):
            if tilt:
                a, b = rng.random(), rng.random()
                s = rng.random()
                cert[(N, M, w)] = (dual_row(w, a * s, (1 - a) * s), dual_row(w, b * rng.random(), (1 - b) * rng.random() * 0.999))
            else:
                cert[(N, M, w)] = (dual_row(w, 0, 0), [x * math.exp(rng.normal()) for x in dual_row(w, 0, 0)])
    return cert


def cert_score(cert, pis):
    return sum(not cell_lp(k, cert, pis) for k in range(len(TYPES)))


def design_from_cert(cert, pis):
    """Fields (role units) from the per-cell LPs of a certificate; a cell whose LP is infeasible gets
    sign- and Bayes-feasible increments without the pair constraints.  Returns regions and bad cells."""
    regs, bad = [], []
    saved = list(PAIRS)
    for k, (cls, advs) in enumerate(TYPES):
        x = cell_lp(k, cert, pis, want_x=True)
        if x is None:
            bad.append(k)
            globals()['PAIRS'][:] = []
            x = cell_lp(k, cert, pis, want_x=True)
            globals()['PAIRS'][:] = saved
        ans = A if cls == 'U' else next((y for y in advs if y != S), A)
        L = {}
        for i, N in enumerate(GATES):
            tab = []
            for w in range(3):
                ev = Fr(float(x[3 * i + w])).limit_denominator(1000)
                opp = B if ans == A else A
                if sigma_correct(cls, ans, w):
                    vals = {ans: Fr(0), S: -ev, opp: -ev + 1000, X: -ev + 1100}
                else:
                    vals = {opp: Fr(0), S: Fr(1, 100), ans: Fr(1, 100) + ev, X: Fr(1, 100) + ev + 1100}
                tab.append([vals[y] for y in range(4)])
            L[N] = tab
        regs.append(dict(cls=cls, adv=dict(zip(GATES, advs)), L=L))
    P = {N: [Fr(float(v)).limit_denominator(1000) for v in pis[N]] for N in GATES}
    return regs, P, bad
