"""L4 referee scratch checks (NUMERICS only; no verdict rests on them). Run: python3 -I ref_checks.py
(A) Facet geometry of T1: corner rays, crossings, sign patterns on F2, F3 (used in L4.6, L4.8, 5.3).
(B) L4.6(c): for K1 = conv(K' u {e1, a e1+(1-a) e2}), P_K1(w2) = -(1-a)*scale < 0 and (+,-,+) near w2 is outside D_K1.
(C) L4.1.2 overreach: c(g)=g with c:=0 on a cone W inside D_{K_u} cap (+,-,-): B_u is not midpoint convex,
    while B_u u W (a Bayes model, W in the tie set) is coherent.
(D) Shell facts used in the referee's exclusion of (I2): for credal sets K with T1 c K c Delta,
    (i) {tau : P_K(h(tau)) < 0} on F2 is a union of <= 2 intervals, each containing an endpoint;
    (ii) |P_K(h)| <= -min_i h_i when P_K(h) < 0, so the shell over points near r23 stays in (+,-,-)
         for small s, and the shell over middle-arc points near w2 is in (+,-,+) for small s.
"""
import numpy as np
rng = np.random.default_rng(16102026)

def setup(eps, s):
    c0 = (1 - eps) / 3
    V = np.array([c0 * np.ones(3) + eps * np.eye(3)[k] for k in range(3)])
    u = np.ones(3) / 3
    return V, u + s * (V - u)

def P(Kpts, G):
    return (np.atleast_2d(G) @ np.atleast_2d(Kpts).T).min(axis=1)

print("(A) facet geometry")
for eps in (0.1, 0.3, 0.7):
    V, Kp = setup(eps, 0.5)
    kap = (1 + 2 * eps) / (1 - eps)
    r12, r23, r31 = np.array([-1, -1, kap + 1]), np.array([kap + 1, -1, -1]), np.array([-1, kap + 1, -1])
    for name, r in (("r12", r12), ("r23", r23), ("r31", r31)):
        d = r @ V.T
        assert np.sum(np.abs(d) < 1e-12) == 2 and (d > -1e-12).all(), name
    w2, w3 = np.array([0, -1, kap]), np.array([0, kap, -1])
    assert abs(w2 @ V[1]) < 1e-12 and (w2 @ V[[0, 2]].T > 0).all()
    assert abs(w3 @ V[2]) < 1e-12 and (w3 @ V[[0, 1]].T > 0).all()
    taus = np.linspace(0, 1, 2001)[1:-1]
    H2 = np.outer(1 - taus, r12) + np.outer(taus, r23)
    pats = sorted(set(tuple(np.sign(h).astype(int)) for h in H2 if np.all(np.abs(h) > 1e-9)), key=lambda p: -p[0])
    H3 = np.outer(1 - taus, r23) + np.outer(taus, r31)
    pats3 = sorted(set(tuple(np.sign(h).astype(int)) for h in H3 if np.all(np.abs(h) > 1e-9)))
    print(f"   eps={eps}: F2 patterns {pats}; F3 patterns {pats3}")

print("(B) L4.6(c)")
for eps, s in ((0.3, 0.9), (0.1, 0.5), (0.6, 0.95)):
    V, Kp = setup(eps, s)
    kap = (1 + 2 * eps) / (1 - eps)
    w2 = np.array([0, -1, kap])
    for a in (0.0, 0.3, 0.7, 0.95):
        K1 = np.vstack([Kp, [1, 0, 0], [a, 1 - a, 0]])
        val = P(K1, w2)[0]
        G = w2 + 0.01 * rng.normal(size=(20000, 3))
        G = G[(G[:, 0] > 0) & (G[:, 1] < 0) & (G[:, 2] > 0)]
        frac_out = np.mean(P(K1, G) < 0)
        assert abs(val + (1 - a)) < 1e-12
        print(f"   eps={eps}, s={s}, a={a}: P_K1(w2)={val:+.4f}; share of (+,-,+) near w2 outside D_K1 = {frac_out:.3f}")

print("(C) L4.1.2 'every B_q coherent' needs c != 0 a.e.")
eps, s = 0.3, 0.9
V, Kp = setup(eps, s)
u = np.ones(3) / 3
ray = np.array([2.0, -0.5, -0.5])          # in (+,-,-), u.ray = 1/3 > 0, ray in U?
assert (P(Kp, ray) > 0)[0]
def inW(G):
    n = G / np.linalg.norm(G, axis=1, keepdims=True)
    return n @ (ray / np.linalg.norm(ray)) > np.cos(0.05)
def inU(G): return P(Kp, G) > 0
def Bu(G): return inU(G) & (G @ u > 0) & ~inW(G)     # strict Bayes set of the modified field
G = rng.normal(size=(400000, 3)) * 3
A = G[Bu(G)]
i1, i2 = rng.integers(0, len(A), 300000), rng.integers(0, len(A), 300000)
Mid = (A[i1] + A[i2]) / 2
print(f"   B_u (c:=0 on W): {np.sum(~Bu(Mid))} midpoint violations in 300000;",
      "B_u u W = U cap {u.g>0} = D_co(K' u {u}) is coherent")

print("(D) shells for K with T1 c K")
viol_i = viol_ii = 0
for trial in range(400):
    eps, s = rng.uniform(0.05, 0.9), rng.uniform(0.1, 0.95)
    V, Kp = setup(eps, s)
    kap = (1 + 2 * eps) / (1 - eps)
    r12, r23 = np.array([-1, -1, kap + 1]), np.array([kap + 1, -1, -1])
    extra = rng.dirichlet(np.ones(3), size=rng.integers(1, 4))
    K = np.vstack([V, extra])
    taus = np.linspace(0, 1, 4001)
    H = np.outer(1 - taus, r12) + np.outer(taus, r23)
    neg = P(K, H) < -1e-12
    # (i) negative set = prefix u suffix
    runs = np.flatnonzero(np.diff(neg.astype(int)) != 0)
    ok = True
    if neg.any() and not neg.all():
        # allowed patterns: T..TF..F, F..FT..T, T..TF..FT..T
        segs = np.split(neg, runs + 1)
        vals = [seg[0] for seg in segs]
        ok = vals in ([True, False], [False, True], [True, False, True])
    viol_i += (not ok)
    # (ii) |P_K(h)| <= -min h for negative h
    pk = P(K, H)
    m = pk < 0
    viol_ii += np.sum(-pk[m] > -H[m].min(axis=1) + 1e-12)
print(f"   (i) interval-structure violations: {viol_i}/400; (ii) bound violations: {viol_ii}")
