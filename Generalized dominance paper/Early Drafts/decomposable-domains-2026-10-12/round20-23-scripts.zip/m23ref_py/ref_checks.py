"""Referee scratch checks for M2/M3 (NUMERICS only; no verdict rests on them).
Run: python3 -I ref_checks.py

(1) M3.6(c) step 3: for random strictly patterned c (pattern of h), c' (pattern of -h), d = c - c',
    whenever the closed reject cell W = {c'.q >= 0, d.q <= 0} meets aff(Delta), the open cell
    R(-h) = {c'.q > 0, d.q < 0} is non-empty (LP on the plane, not only on Delta).
(2) M3.2(b): c.p + c'.p = sum_k p_k (s_k - w_k) for the ladder table, random instances.
(3) M3.11: doubly blind ladder (s_k = w_k = 0) at the vertex e_k gives a three-way tie,
    so wrong acceptance is optimal at e_k there (the GAP noted in the report).
(4) M2.2 step 3: discrete check of the sub-move identity psi_j(X') = (1-f)psi_j(C) + f psi_j(X)
    when delta' takes the same fraction f of delta+ and delta- in rho_j mu|A and rho_j mu|R.
"""
import numpy as np
from scipy.optimize import linprog

rng = np.random.default_rng(16102026)


def pattern_vec(sig):
    return sig * rng.uniform(0.05, 3.0, size=3)


def cell_nonempty(A, strict):
    # q in aff Delta: q = (q1, q2, 1-q1-q2) unbounded in the plane. Constraints rows a.q >= 0 (or > 0).
    # Write a.q = (a1-a3) q1 + (a2-a3) q2 + a3. Maximise t s.t. a.q >= t for all rows, |q| <= 1e3.
    M = np.array([[a[0] - a[2], a[1] - a[2]] for a in A])
    b0 = np.array([a[2] for a in A])
    # variables q1, q2, t ; constraint -(M q) + t <= b0
    Aub = np.hstack([-M, np.ones((len(A), 1))])
    res = linprog(c=[0, 0, -1], A_ub=Aub, b_ub=b0, bounds=[(-1e3, 1e3)] * 2 + [(None, 1.0)],
                  method="highs")
    t = -res.fun
    return t > 1e-9 if strict else t > -1e-9


bad1 = 0
n1 = 0
for _ in range(20000):
    while True:
        sig = rng.choice([-1.0, 1.0], size=3)
        if sig.max() > 0 > sig.min():
            break
    c = pattern_vec(sig)
    cp = pattern_vec(-sig)
    d = c - cp
    W = cell_nonempty([cp, -d], strict=False)
    R = cell_nonempty([cp, -d], strict=True)
    if W:
        n1 += 1
        if not R:
            bad1 += 1
print("(1) W nonempty:", n1, "of 20000; W nonempty but R(-h) empty:", bad1)

bad2 = 0
for _ in range(20000):
    g = rng.normal(size=3)
    s = rng.uniform(0, 2, 3)
    w = rng.uniform(0, 2, 3)
    p = rng.dirichlet(np.ones(3))
    lp = np.where(g > 0, 0.0, s + w)       # loss of +
    l0 = s                                 # loss of silence
    lm = np.where(g > 0, s + w, 0.0)       # loss of -
    c = l0 - lp
    cp = l0 - lm
    if abs(c @ p + cp @ p - p @ (s - w)) > 1e-12:
        bad2 += 1
print("(2) identity c.p + c'.p = p.(s-w) violations:", bad2)

k = 0
gk_pos = np.array([1.0, -1.0, 0.5])
s = np.array([0.0, 0.7, 0.4]); w = np.array([0.0, 0.3, 0.9])
lp = np.where(gk_pos > 0, 0.0, s + w); l0 = s; lm = np.where(gk_pos > 0, s + w, 0.0)
print("(3) losses at e_1 with s_1 = w_1 = 0: accept-correct", lp[k], "silence", l0[k],
      "accept-wrong", lm[k], "-> three-way tie" if lp[k] == l0[k] == lm[k] else "")

bad4 = 0
for _ in range(2000):
    n = 400
    rho = rng.uniform(0.1, 2.0, n)
    agree = rng.random(n) < 0.5            # A_{1j} (agreement) vs R_{1j}
    eta = np.where(agree, rho, -rho)
    delta = rng.choice([-1, 0, 1], size=n)
    # sub-move: proportional fraction in each of the 4 measures, realised exactly by splitting
    # cells into atoms of equal weight is not possible in a discrete toy; use fractional delta'
    f = rng.uniform(0.05, 1.0)
    deltap = f * delta                      # fractional sub-move (Lyapunov limit)
    lhs = deltap @ eta
    rhs = f * (delta @ eta)
    if abs(lhs - rhs) > 1e-9:
        bad4 += 1
print("(4) sub-move identity violations (fractional form):", bad4)
