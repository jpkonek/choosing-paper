"""Referee checks for P1_notes.md Part I (P1.10-P1.19).  Run: python3 -I -B ref_checks.py (from p1ref_py/).

(A) exact check of Lemma P1.10a (thinness) for k = 0..400, with the exact sup of the bound
    sum_{n'>=1} min(2^-n', s_{>=k}) (s_k at its maximal allowed value r_k/(100 N_k)), and the
    three margins used in P1.11 / P1.10 step 4.
(B) LP relaxations on the cell model of p1py/q_n2_common.py (cell densities in [0,1] instead of sets):
    (B1) strictness: max of -int(delta) over delta in [-1,0]^cells with delta - g_F in T   (expect 0)
    (B2) no weak domination: for every selector F and every cut breakpoint j,
         max lambda(P)+lambda(Q) over P<j, Q>=j fractional with 1_P - 1_Q - g_F in T,
         lambda(P) <= lambda(Q)                                                         (expect 0)
    (B3) same-level sums: for every pair of selectors sharing a level, is there sigma in [-1,1]^cells
         with sigma - g_F1 - g_F2 in T ?                                                 (expect none)
(C) P1.17 sanity on the same model: kappa(c_y) by LP, and the window bound for the generators.
No verdict rests on this.
"""
import os
import sys
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import linprog

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'p1py'))
from q_n2_common import Model, LEVELS  # noqa: E402

out = []


def say(*a):
    s = ' '.join(str(x) for x in a)
    print(s)
    out.append(s)


# ---------------- (A) thinness, exact ----------------
def N_of(r):
    N = 0
    while Fr(2) ** N < 50 / r:
        N += 1
    return N


u0 = Fr(1, 2)
K = 400
r = [(1 - u0) / Fr(5) ** k for k in range(K + 40)]
N = [N_of(x) for x in r]
s = [r[k] / (100 * N[k]) for k in range(K + 40)]
worst = Fr(0)
ok = True
for k in range(K):
    # tail beyond K+40 bounded by geometric series with N_{k'} >= N_k
    s_ge = sum(s[k:K + 40]) + r[K + 40 - 1] / 5 * Fr(5, 4) / (100 * N[k])
    # exact: sum_{n>=1} min(2^-n, s) = n0*s + 2^-n0 with n0 = max{n >= 0 : 2^-n >= s}
    n0 = 0
    while Fr(1, 2 ** (n0 + 1)) >= s_ge:
        n0 += 1
    tot = n0 * s_ge + Fr(1, 2 ** n0)
    ratio = tot / r[k]
    worst = max(worst, ratio)
    ok = ok and ratio <= Fr(1, 25)
    ok = ok and N[k] <= N[k + 1]
say('(A) P1.10a: max_k Theta-bound / r_k over k<400 =', float(worst), ' <= 1/25 :', ok)
say('(A) margins: strictness -16/25+1/25 =', Fr(-16, 25) + Fr(1, 25),
    '; sums -16/25+9/25+2/25 =', Fr(-16, 25) + Fr(9, 25) + Fr(2, 25),
    '; case (i) 16/25-1/25 =', Fr(16, 25) - Fr(1, 25))

# ---------------- (B) LP relaxations ----------------
M = Model()
nc = M.ncell
L = np.array([float(x) for x in M.len])
# tail operator: row i gives sum_{c>=i} len_c f_c
# rows scaled by the tail measure 1 - x_i (cell sizes span 5^-24; unscaled rows are below LP tolerance)
Tmat = np.zeros((nc, nc))
for i in range(nc):
    Tmat[i, i:] = L[i:] / float(1 - M.bps[i])
G = {sel: np.array([float(x) for x in M.gF(sel)]) for sel in M.selectors}
TOL = 1e-12

# (B1) strictness
worstB1 = 0.0
for sel in M.selectors:
    g = G[sel]
    # variables delta_c in [-1,0]; constraint: T(delta - g) >= 0  ->  -T delta <= -T g
    res = linprog(c=np.ones(nc), A_ub=-Tmat, b_ub=-(Tmat @ g), bounds=[(-1, 0)] * nc, method='highs')
    if res.status == 0:
        worstB1 = max(worstB1, -res.fun)
say('(B1) strictness LP: max total cell density of an accepted fractional delta <= 0 :', worstB1)

# (B2) no weak domination
worstB2 = 0.0
cnt = 0
for sel in M.selectors:
    g = G[sel]
    for j in range(1, nc):
        # x = (p_c)_{c<j} on cells < j, (q_c)_{c>=j}; delta' = p on c<j, -q on c>=j
        sgn = np.array([1.0 if c < j else -1.0 for c in range(nc)])
        A1 = -Tmat * sgn[None, :]                       # -T(sgn*x) <= -T g
        b1 = -(Tmat @ g)
        A2 = (L * sgn)[None, :] / float(1 - M.bps[j])   # lambda(P) - lambda(Q) <= 0 (scaled)
        b2 = np.array([0.0])
        res = linprog(c=-np.ones(nc), A_ub=np.vstack([A1, A2]), b_ub=np.concatenate([b1, b2]),
                      bounds=[(0, 1)] * nc, method='highs')
        cnt += 1
        if res.status == 0:
            worstB2 = max(worstB2, -res.fun)
say('(B2) no-weak-domination LP over', cnt, 'selector/cut pairs: max total cell density of P,Q =', worstB2)

# (B3) same-level sums
lev_of = lambda sel: {LEVELS[i][0] for i, j in enumerate(sel) if j is not None}
feas = 0
tested = 0
for a in M.selectors:
    for b in M.selectors:
        if not (lev_of(a) & lev_of(b)):
            continue
        g = G[a] + G[b]
        tested += 1
        res = linprog(c=np.zeros(nc), A_ub=-Tmat, b_ub=-(Tmat @ g), bounds=[(-1, 1)] * nc, method='highs')
        if res.status == 0:
            feas += 1
say('(B3) same-level selector pairs tested:', tested, ' feasible sigma found:', feas)

# ---------------- (C) P1.17 sanity ----------------
def kappa(jy):
    """min lambda(W), W in cells >= jy, with 1_W - 1_{c_y} - g_F in T for some F (fractional)."""
    best = None
    cy = np.array([1.0 if c < jy else 0.0 for c in range(nc)])
    for sel in M.selectors:
        g = G[sel]
        bounds = [(0, 0) if c < jy else (0, 1) for c in range(nc)]
        res = linprog(c=L, A_ub=-Tmat, b_ub=-(Tmat @ (cy + g)), bounds=bounds, method='highs')
        if res.status == 0 and (best is None or res.fun < best):
            best = res.fun
    return best


bps = [float(x) for x in M.bps]
viol = 0
checked = 0
for jy in [1, 2, 3]:
    y0 = 2 * bps[jy]          # c_{y0/2} = cells < jy
    k0 = kappa(jy)
    for (n, _, _) in LEVELS:
        for gg in M.gens[n][0]:
            P = gg['P']
            Q = gg['Q']
            lp = sum(L[c] for c in P if bps[c] >= y0)
            if lp == 0 or lp > y0 / 2:
                continue
            # shrink P to its part in d_{y0} (P1.18(a) shrinking); t = right end of Q
            t = bps[max(Q) + 1]
            lq = sum(L[c] for c in Q)
            bound = min(1 - t, k0) / y0
            checked += 1
            if lq / lp < bound - 1e-12:
                viol += 1
    say('(C) y0 =', round(y0, 4), ' kappa(c_{y0/2}) =', k0)
say('(C) P1.17 window bound on (shrunk) generator pairs: checked', checked, ' violations', viol)

with open(os.path.join(HERE, 'ref_checks.out'), 'w') as fh:
    fh.write('\n'.join(out) + '\n')
