"""M2 numerics (NUMERICS only; no proof depends on this file). Run: python3 -I m2_checks.py

(A) Prop. M2.3 (admissibility by separation). For a field c on U, the separating weight of
    "no (2,3)-strict improvement of T1 lowers the world-1 cost" is found by the LP
        max s  s.t.  chi(g) * w.c(g) >= s * |c(g)|_1  for sampled g in M,  w in Delta,
    with chi = +1 on D_T1, -1 off. If T1 is c-Bayes at p*, the optimum is s ~ 0 at w ~ p*.
    Checked on the facet-switching field (T1 = B_u) and on the Brier field (T1 not Bayes: s < 0).
(B) Prop. M2.2 (forced KKM step) on an additive Brier system (all three worlds additive, selection
    C_q = Brier-Bayes model). Grid version of the sets F_2, F_3, O, F_1 = cl O; checks the covering
    property, finds a grid point of F_1 n F_2 n F_3 and checks t.psi(C_q*) <= t.psi(B) + tolerance.
"""
import numpy as np
from scipy.optimize import linprog

rng = np.random.default_rng(20261016)


def setup(eps, s):
    c0 = (1 - eps) / 3
    V = np.array([c0 * np.ones(3) + eps * np.eye(3)[k] for k in range(3)])
    u = np.ones(3) / 3
    Kp = u + s * (V - u)
    return V, Kp, u


def inU(G, Kp):
    return (G @ Kp.T).min(axis=1) > 0


def inT1(G, V):
    return (G @ V.T).min(axis=1) > 0


def sample_M(n, Kp):
    G = rng.normal(size=(6 * n, 3)) * 3.0
    G = G[inU(G, Kp)]
    mixed = (G.max(axis=1) > 0) & (G.min(axis=1) < 0)
    return G[mixed][:n]


def sep_lp(C, chi):
    # variables (w1,w2,w3,s); maximise s
    n = len(C)
    norm = np.abs(C).sum(axis=1)
    A = np.hstack([-(chi[:, None] * C), norm[:, None]])   # -chi*w.c + s*|c| <= 0
    b = np.zeros(n)
    Aeq = np.array([[1, 1, 1, 0.0]])
    res = linprog(c=[0, 0, 0, -1], A_ub=A, b_ub=b, A_eq=Aeq, b_eq=[1],
                  bounds=[(0, 1)] * 3 + [(None, None)], method="highs")
    return res.x[:3], res.x[3]


print("(A) admissibility by separation")
for eps, s in [(0.3, 0.9), (0.2, 0.6)]:
    V, Kp, u = setup(eps, s)
    G = sample_M(20000, Kp)
    chi = np.where(inT1(G, V), 1.0, -1.0)
    j = np.argmin(G @ V.T, axis=1)                       # facet-switching field
    rho = V[j] * np.abs(G)
    Cfs = rho * np.sign(G)
    w, val = sep_lp(Cfs, chi)
    print(f"   eps={eps}, s={s}: facet-switching field: w*={np.round(w, 4)}, margin={val:.2e}, |w*-u|={np.abs(w-u).max():.2e}")
    w2, val2 = sep_lp(G.copy(), chi)                     # Brier field c(g) = g
    print(f"   eps={eps}, s={s}: Brier field:           w*={np.round(w2, 4)}, margin={val2:.3e}  (negative: T1 not Brier-Bayes)")

print("(B) forced KKM step on an additive Brier system")
eps, s = 0.3, 0.9
V, Kp, u = setup(eps, s)
G = sample_M(40000, Kp)
rhos = np.abs(G)                                         # Brier densities (empirical measure)
P = G > 0                                                # P_i: world-i ideal acceptance
# grid on Delta
N = 60
grid = np.array([(a / N, b / N, (N - a - b) / N) for a in range(N + 1) for b in range(N + 1 - a)])
acc_q = (G @ grid.T) > 0                                 # C_q = Brier-Bayes model, columns = q


def psi_of(acc):  # acc: (n,) or (n,m) boolean acceptance; returns world costs
    if acc.ndim == 1:
        acc = acc[:, None]
    err = acc[:, :, None] != P[:, None, :]               # (n, m, 3)
    return np.einsum("nmi,ni->mi", err, rhos) / len(G)


psiC = psi_of(acc_q)                                     # (m, 3)
fails = 0
worst_excess = -np.inf
forced_viol = -np.inf
scale = 0.0
for trial in range(40):
    t = rng.dirichlet([2, 2, 2])
    accB = (G @ t) > 0
    flip = rng.random(len(G)) < 0.01                     # near-optimal regular B
    accB = accB ^ flip
    # B_- / B_+ : toggle a small W in Q_1 (worlds 2,3 agree against 1)
    q1 = (np.sign(G[:, 1]) == np.sign(G[:, 2])) & (np.sign(G[:, 0]) != np.sign(G[:, 1]))
    W = q1 & (rng.random(len(G)) < 0.01)
    side23 = G[:, 1] > 0                                 # on Q_1 "side with 2,3" = accept iff g_2 > 0
    accBm = np.where(W, side23, accB)
    accBp = np.where(W, ~side23, accB)
    pB, pBm, pBp = psi_of(accB)[0], psi_of(accBm)[0], psi_of(accBp)[0]
    F2 = psiC[:, 1] <= pBp[1]
    F3 = psiC[:, 2] <= pBp[2]
    supp = grid > 1e-12
    O = supp[:, 0] & ~((supp[:, 1] & F2) | (supp[:, 2] & F3))
    # covering (grid version of competitiveness): every q in U_{i in supp q} F_i, F_1 := O
    cover = (O) | (supp[:, 1] & F2) | (supp[:, 2] & F3)
    if not cover.all():
        fails += 1
    # Sperner version of KKM on the grid: label q by 1 if q in O, else by some j in supp q with q in F_j
    lab = np.where(O, 1, np.where(supp[:, 1] & F2, 2, 3))
    idx = {(round(g[0] * N), round(g[1] * N)): k for k, g in enumerate(grid)}
    tri = []
    for a in range(N):
        for b in range(N - a):
            T_up = [idx[(a, b)], idx[(a + 1, b)], idx[(a, b + 1)]]
            tri.append(T_up)
            if a + b + 1 < N:
                tri.append([idx[(a + 1, b)], idx[(a, b + 1)], idx[(a + 1, b + 1)]])
    full = [T for T in tri if set(lab[T]) == {1, 2, 3}]
    if not full:
        fails += 1
        continue
    # excess of the best vertex of the best fully labelled triangle (its vertices -> q* as N -> oo)
    excess = min(min(t @ psiC[k] for k in T) for T in full) - t @ pB
    worst_excess = max(worst_excess, excess)
    forced_viol = max(forced_viol, (psiC[O, 0] - pBm[0]).max())
    scale = max(scale, t @ pB)
print(f"   40 trials: covering/Sperner failures = {fails}")
print(f"   forced endorsement on O: max_q (psi_1(C_q) - psi_1(B_-)) = {forced_viol:.2e} (must be <= 0)")
print(f"   best vertex of a fully labelled triangle: max over trials of t.psi(C) - t.psi(B) = {worst_excess:.2e}"
      f" (scale t.psi(B) <= {scale:.3f}; grid 1/{N})")
