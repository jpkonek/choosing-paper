"""1-D scan over symmetric boxes [1,r]^3 for c(eps) (support-function Hausdorff distance)."""
import numpy as np
E=np.eye(3); A2=np.array([[0,0],[1,0],[0.5,np.sqrt(3)/2]])
th=np.linspace(0,2*np.pi,20000,endpoint=False); D=np.stack([np.cos(th),np.sin(th)],1)
sup=lambda P:((P@A2)@D.T).max(0)
for eps in [0.05,0.3,0.6,0.9]:
    c0=(1-eps)/3; V=np.array([c0*np.ones(3)+eps*E[k] for k in range(3)])
    best=(9,None)
    for r in np.exp(np.linspace(0,np.log(100),20000)):
        C=np.array([[a,b,c] for a in (1,r) for b in (1,r) for c in (1,r)],float); C/=C.sum(1,keepdims=True)
        d=np.abs(sup(C)-sup(V)).max()
        if d<best[0]: best=(d,r)
    print(f"eps={eps}: symmetric-cube min d_H = {best[0]:.5f} at r = {best[1]:.4f}")
