"""Referee checks for L3 (independent of l3py/).  Run: python3 -I l3_checks.py

(1) L3.3(a): on the deep veto region the stage gauge is b*v_i.h exactly (no a*h_i term), so the
    lexicographic limit's second level is the Brier error OFF the veto set, not Psi_i.
(2) L3.3(c): along the open edge [e1,e2], f(t) = Phi_3(C_{q_t}) is non-constant, so a world-3
    section is not closed relative to the open edge.
(3) L3.1(c): independent estimate of c(eps) = inf_box d_H(nu(box), T1).
"""
import numpy as np
from scipy.optimize import minimize

rng = np.random.default_rng(11)
E = np.eye(3); u = np.ones(3) / 3

def T1verts(eps):
    c0 = (1 - eps) / 3
    return np.array([c0 * np.ones(3) + eps * E[k] for k in range(3)])

# ---------------- (1) stage gauge on the deep veto region ----------------
eps, s = 0.3, 0.5
V = T1verts(eps); Kp = u + s * (V - u)
H = rng.normal(size=(400000, 3))
H = H[(H @ Kp.T).min(1) > 0]
i = 0
for ab in [1e-2, 1e-3, 1e-4]:
    a, b = ab, 1.0
    f = np.minimum(np.minimum(a * H[:, i], b * (H @ Kp.T).min(1)), b * (H @ V[i]))
    deep = (H @ V[i]) < -0.05 * np.linalg.norm(H, axis=1)
    err = np.abs(f[deep] - b * (H[deep] @ V[i])).max()
    print(f"(1) a/b={ab:g}: deep-veto points {deep.sum()}, max|f_i - b v_i.h| = {err:.2e}"
          f"  (a*|h_i| there is up to {a*np.abs(H[deep,i]).max():.2e})")
# two models differing only on deep veto set with equal Phi but different Psi
deep = (H @ V[i]) < -0.05 * np.linalg.norm(H, axis=1)
idx = np.nonzero(deep)[0]
w_phi = -(H[idx] @ V[i]); w_psi = np.abs(H[idx, i])
r = w_psi / w_phi
order = np.argsort(r)
A1 = idx[order[: len(order) // 4]]          # low |h_i| per unit veto
A2 = idx[order[-len(order) // 4:]]          # high |h_i| per unit veto
# trim A2 so that Phi(A1) = Phi(A2) approximately
phi1 = -(H[A1] @ V[i]); phi2 = -(H[A2] @ V[i])
if phi1.sum() > phi2.sum():
    A1 = A1[: np.searchsorted(np.cumsum(phi1), phi2.sum())]
else:
    A2 = A2[: np.searchsorted(np.cumsum(phi2), phi1.sum())]
PhiA1, PhiA2 = (-(H[A1] @ V[i])).sum(), (-(H[A2] @ V[i])).sum()
PsiA1, PsiA2 = np.abs(H[A1, i]).sum(), np.abs(H[A2, i]).sum()
print(f"(1) X accepts A1, Y accepts A2 (rest equal): Phi {PhiA1:.3f} vs {PhiA2:.3f};  Psi {PsiA1:.3f} vs {PsiA2:.3f}")
for ab in [1e-2, 1e-3, 1e-4]:
    a, b = ab, 1.0
    f = np.minimum(np.minimum(a * H[:, i], b * (H @ Kp.T).min(1)), b * (H @ V[i]))
    LX, LY = -f[A1].sum(), -f[A2].sum()
    print(f"    stage a/b={ab:g}: (L_i(X)-L_i(Y))/a = {(LX-LY)/a:+.4f}   [VB says (Psi diff) = {PsiA1-PsiA2:+.4f}"
          f" after Phi-tie; if VB were the limit this ratio would tend to it]")

# ---------------- (2) Phi_3 along the open edge [e1,e2] ----------------
V = T1verts(eps); Kp = u + s * (V - u)
G = rng.normal(size=(2000000, 3)); G = G[(G @ Kp.T).min(1) > 0]
VG = G @ V.T
R = (VG[:, 0] >= 0) & (VG[:, 1] >= 0) & (VG[:, 2] < 0)
wv = -VG[:, 2]
ts = [0.001, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5]
fvals = []
for t in ts:
    q = np.array([1 - t, t, 0.0])
    acc = R & ((G @ q) > 0)
    fvals.append(wv[acc].sum() / len(G))
print("(2) f(t)=Phi_3(C_{q_t}) on open edge [e1,e2]:", ", ".join(f"t={t}: {v:.5f}" for t, v in zip(ts, fvals)))
# build X = C_{q_t0} minus a Phi_3-neutral world-3-wrong piece; check section along the edge
t0 = 0.1; q0 = np.array([1 - t0, t0, 0.0])
C0 = ((G @ q0) > 0) & (VG[:, 0] >= 0) & (VG[:, 1] >= 0)
cand = np.nonzero(C0 & (G[:, 2] < 0) & (VG[:, 2] > 0))[0]
X = C0.copy(); X[cand[: len(cand) // 10]] = False
def vec3(Y):
    return (wv * (Y & (VG[:, 2] < 0))).sum(), (np.abs(G[:, 2]) * (Y != (G[:, 2] > 0))).sum()
px, sx = vec3(X)
def leq3(Y):
    py, sy = vec3(Y)
    return py < px - 1e-9 or (abs(py - px) <= 1e-9 and sy <= sx + 1e-9)
for t in [0.08, 0.09, 0.095, 0.1]:
    q = np.array([1 - t, t, 0.0])
    Ct = ((G @ q) > 0) & (VG[:, 0] >= 0) & (VG[:, 1] >= 0)
    print(f"    C_q(t={t}) <=_3 X : {leq3(Ct)}")

# ---------------- (3) c(eps) ----------------
def to2d(P):
    B = np.array([[1, 0, 0], [0.5, np.sqrt(3) / 2, 0]])  # use (x2 + x3/2, x3*sqrt3/2) coordinates
    return np.stack([P[:, 1] + P[:, 2] / 2, P[:, 2] * np.sqrt(3) / 2], 1)
def hull(P):
    P = sorted(map(tuple, P))
    def cr(o, a, b): return (a[0]-o[0])*(b[1]-o[1]) - (a[1]-o[1])*(b[0]-o[0])
    lo, up = [], []
    for p in P:
        while len(lo) >= 2 and cr(lo[-2], lo[-1], p) <= 0: lo.pop()
        lo.append(p)
    for p in reversed(P):
        while len(up) >= 2 and cr(up[-2], up[-1], p) <= 0: up.pop()
        up.append(p)
    return np.array(lo[:-1] + up[:-1])
def dist_pt_poly(x, Q):
    n = len(Q); inside = True; best = np.inf
    for k in range(n):
        a, b = Q[k], Q[(k + 1) % n]
        if (b[0]-a[0])*(x[1]-a[1]) - (b[1]-a[1])*(x[0]-a[0]) < 0: inside = False
        ab = b - a; tt = np.clip(np.dot(x - a, ab) / np.dot(ab, ab), 0, 1)
        best = min(best, np.linalg.norm(x - a - tt * ab))
    return 0.0 if inside else best
def dH(P, Q):
    return max(max(dist_pt_poly(p, Q) for p in P), max(dist_pt_poly(q, P) for q in Q))
for eps in [0.05, 0.3, 0.6, 0.9]:
    T = hull(to2d(T1verts(eps)))
    def obj(z):
        al = np.exp(z[:3]); be = al * np.exp(np.abs(z[3:]))
        corners = np.array([[ (al, be)[c1][0], (al, be)[c2][1], (al, be)[c3][2]]
                            for c1 in (0, 1) for c2 in (0, 1) for c3 in (0, 1)])
        corners = corners / corners.sum(1, keepdims=True)
        return dH(hull(to2d(corners)), T)
    best = np.inf
    for _ in range(60):
        z0 = np.concatenate([rng.normal(scale=0.5, size=3), rng.uniform(0, 2, size=3)])
        res = minimize(obj, z0, method="Nelder-Mead", options=dict(maxiter=3000, xatol=1e-9, fatol=1e-11))
        if res.fun < best: best, bz = res.fun, res.x
    al = np.exp(bz[:3]); be = al * np.exp(np.abs(bz[3:]))
    corners = np.array([[ (al, be)[c1][0], (al, be)[c2][1], (al, be)[c3][2]] for c1 in (0, 1) for c2 in (0, 1) for c3 in (0, 1)])
    corners = corners / corners.sum(1, keepdims=True)
    th = np.linspace(0, 2*np.pi, 7200, endpoint=False); D = np.stack([np.cos(th), np.sin(th)], 1)
    sup = lambda P: (P @ D.T).max(0)
    dsup = np.abs(sup(to2d(corners)) - sup(to2d(T1verts(eps)))).max()
    print(f"(3) eps={eps}: min_box d_H(nu(box),T1) ~ {best:.4f}  (support-function cross-check {dsup:.4f}); box alpha={np.round(al/al.sum(),4)}, beta/alpha={np.round(be/al,4)}")
