"""Finite cell model of the L2 world (two worlds, world 2 = lambda).

Chain coordinate x in [0,1); lambda = Lebesgue.  Exact rational arithmetic.
Levels n = 1, 2 with PG(2,2) and PG(2,3); geometric blocks r_k = r0 * 5^-k,
ref = left 4/5 of a block, free = right 1/5.
"""
from fractions import Fraction as Fr
import itertools

A_CUT = Fr(1, 2)          # a
U0 = Fr(3, 4)             # first block starts here, r0 = 1/4
LEVELS = [(1, 2, 2), (2, 4, 3)]   # (n, K_n, q_n)


def pg2_lines(q):
    """Points and lines of PG(2,q), q prime. Returns list of lines (sets of point indices)."""
    pts = []
    for v in itertools.product(range(q), repeat=3):
        if v == (0, 0, 0):
            continue
        # normalise: first nonzero coordinate = 1
        i = next(j for j in range(3) if v[j])
        inv = pow(v[i], q - 2, q)
        w = tuple((x * inv) % q for x in v)
        if w not in pts:
            pts.append(w)
    lines = []
    for nrm in pts:
        lines.append(frozenset(j for j, p in enumerate(pts)
                               if sum(a * b for a, b in zip(nrm, p)) % q == 0))
    return pts, lines


class Model:
    def __init__(self, sub_src=8, sub_ref=2, sub_free=2, gap_cells=4):
        bps = [Fr(0)]
        # source region [0,a): sub_src equal cells
        for i in range(1, sub_src + 1):
            bps.append(A_CUT * i / sub_src)
        # gap [a,u0)
        for i in range(1, gap_cells + 1):
            bps.append(A_CUT + (U0 - A_CUT) * i / gap_cells)
        # blocks
        self.blocks = []        # list of dicts: level, point, start, ref cells, free cells
        r = 1 - U0
        k = 0
        self.level_blocks = {}
        for (n, K, q) in LEVELS:
            pts, lines = pg2_lines(q)
            Pi = len(pts)
            idx = []
            for pnt in range(Pi):
                u = 1 - r
                blen = r * Fr(4, 5)
                reflen = blen * Fr(4, 5)
                start_cell = len(bps) - 1
                for i in range(1, sub_ref + 1):
                    bps.append(u + reflen * i / sub_ref)
                ref_cells = list(range(start_cell, len(bps) - 1))
                c0 = len(bps) - 1
                for i in range(1, sub_free + 1):
                    bps.append(u + reflen + (blen - reflen) * i / sub_free)
                free_cells = list(range(c0, len(bps) - 1))
                self.blocks.append(dict(level=n, point=pnt, u=u, r=r,
                                        ref=ref_cells, free=free_cells))
                idx.append(len(self.blocks) - 1)
                r = r / 5
                k += 1
            self.level_blocks[n] = (idx, lines)
        self.tail_start = len(bps) - 1
        bps.append(Fr(1))
        self.bps = bps
        self.ncell = len(bps) - 1
        self.len = [bps[i + 1] - bps[i] for i in range(self.ncell)]
        self.src_cells = list(range(sub_src))
        # generators
        self.gens = {}
        for (n, K, q) in LEVELS:
            idx, lines = self.level_blocks[n]
            Pi = len(lines)
            L = Pi // K
            gl = []
            for i in range(K):
                lo, hi = A_CUT * i / K, A_CUT * (i + 1) / K
                P = [c for c in self.src_cells if bps[c] >= lo and bps[c + 1] <= hi]
                for l in range(L):
                    line = sorted(lines[i * L + l])
                    Q = [c for pnt in line for c in self.blocks[idx[pnt]]['ref']]
                    g = [0] * self.ncell
                    for c in Q:
                        g[c] = 1
                    for c in P:
                        g[c] = -1
                    gl.append(dict(n=n, i=i, l=l, line=line, P=P, Q=Q, g=g))
            self.gens[n] = (gl, L, K, q)
        # selectors: at most one generator per level
        opts = [[None] + list(range(len(self.gens[n][0]))) for (n, _, _) in LEVELS]
        self.selectors = list(itertools.product(*opts))

    # ---------- basic functionals ----------
    def tails(self, f):
        """Tail values tau_f(x_j) at every breakpoint (cell-constant f)."""
        out = [Fr(0)] * (self.ncell + 1)
        s = Fr(0)
        for c in range(self.ncell - 1, -1, -1):
            s += f[c] * self.len[c]
            out[c] = s
        return out

    def in_T(self, f):
        return all(t >= 0 for t in self.tails(f))

    def gF(self, sel):
        g = [0] * self.ncell
        for (n, _, _), j in zip(LEVELS, sel):
            if j is None:
                continue
            gg = self.gens[n][0][j]['g']
            g = [x + y for x, y in zip(g, gg)]
        return g

    def accept(self, delta):
        """World-1 acceptance of a ternary cell function on M (D(delta)=0, regular case)."""
        for sel in self.selectors:
            g = self.gF(sel)
            if self.in_T([d - x for d, x in zip(delta, g)]):
                return True, sel
        return False, None

    def lam(self, cells):
        return sum(self.len[c] for c in cells)
