"""Q3 (round 21) NUMERICS for the forced KKM without (RL-1) (Thm Q3.23 of Q3_notes Part I).
Additive Brier system on M_U(T1), eps=0.3, s=0.9; selection C_q = {q.g > 0} cap U.
KKM sets of Q3.23: F_j = {q : psi_j(C_q) <= psi_j(B) + eta} (j = 2,3), O = {q : 1 in supp q,
psi_j(C_q) > psi_j(B) + eta for all j in supp q minus 1}.  Grid/Sperner version.
Checks: (A) covering q in union_{i in supp q} F_i at every grid point (by construction plus
competitiveness at q_1 = 0); (B) a fully labelled small triangle exists; at its vertices the
partner bounds hold and the label-1 vertex gives a forced pair (C_q, B) whose world-1 cost
does not exceed that of B (additive world 1, so forced pairs are rho_1-endorsed).
(C) lower semicontinuity device of Lemma Q3.21: psi_j(Y_m0) with E_jY_m0 = union of tail error sets
converges to psi_j(C_q*) along q_m -> q*.  No proof rests on this script."""
import numpy as np
rng = np.random.default_rng(21)
eps, s = 0.3, 0.9
u = np.ones(3) / 3
V = np.array([(1 - eps) * u + eps * np.eye(3)[k] for k in range(3)])
Kp = u + s * (V - u)
g = rng.standard_normal((200000, 3))
g = g[(g @ Kp.T).min(axis=1) > 0]
mixed = (g.max(axis=1) > 0) & (g.min(axis=1) < 0)
g = g[mixed]
w = 1.0 / len(g)
absg = np.abs(g)

def err(acc, j):
    return acc ^ (g[:, j] > 0)

def psi(acc):
    return np.array([w * absg[err(acc, j), j].sum() for j in range(3)])

def C(q):
    return (g @ q) > 0

N = 40
pts = [(a, b, N - a - b) for a in range(N + 1) for b in range(N + 1 - a)]
fails_cover, worst_partner, worst_w1, found = 0, -1e9, -1e9, 0
for trial in range(20):
    t = rng.dirichlet([2, 2, 2])
    accB = C(t)
    flip = rng.random(len(g)) < 0.01
    accB = accB ^ flip
    psiB = psi(accB)
    eta = 0.002
    lab, cache = {}, {}
    for p in pts:
        q = np.array(p, float) / N
        acc = C(q); ps = psi(acc); cache[p] = (acc, ps)
        supp = [i for i in range(3) if p[i] > 0]
        L = [j for j in supp if j != 0 and ps[j] <= psiB[j] + eta]
        if L:
            lab[p] = L[0]
        elif 0 in supp:
            lab[p] = 0
        else:
            fails_cover += 1; lab[p] = -1
    for a in range(N):
        for b in range(N - a):
            tris = [[(a, b, N - a - b), (a + 1, b, N - a - b - 1), (a, b + 1, N - a - b - 1)]]
            if a + b + 2 <= N:
                tris.append([(a + 1, b, N - a - b - 1), (a, b + 1, N - a - b - 1), (a + 1, b + 1, N - a - b - 2)])
            for tri in tris:
              if sorted(lab[x] for x in tri) == [0, 1, 2]:
                found += 1
                for x in tri:
                    acc, ps = cache[x]
                    if lab[x] in (1, 2):
                        worst_partner = max(worst_partner, ps[lab[x]] - psiB[lab[x]] - eta)
                    else:
                        worst_w1 = max(worst_w1, ps[0] - psiB[0])
print("covering failures:", fails_cover)
print("fully labelled triangles found over 20 tests (Sperner: >= 1 per test):", found)
print("max partner excess over psi_j(B)+eta at j-labelled vertices (should be <= 0):", round(worst_partner, 6))
print("max world-1 excess psi_1(C_q)-psi_1(B) at the forced (label-1) vertex (should be <= 0):", round(worst_w1, 6))
# (C) lsc device
qs = np.array([0.5, 0.3, 0.2]); acc_star = C(qs)
for m0 in [5, 20, 80, 320]:
    U_err = np.zeros(len(g), bool)
    for m in range(m0, m0 + 2000):
        qm = qs + np.array([1, -1, 0]) * 0.3 / m ** 1.5
        U_err |= err(C(qm), 1)
    print("m0=%4d  psi_2(Y_m0)=%.6f  psi_2(C_q*)=%.6f" % (m0, w * absg[U_err, 1].sum(), psi(acc_star)[1]))
