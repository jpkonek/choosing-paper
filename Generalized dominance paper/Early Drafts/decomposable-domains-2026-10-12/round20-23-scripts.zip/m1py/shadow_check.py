"""M1 NUMERICS (1)-(3): the T1-shadow field.
(1) B_q = T1 for every interior q, T1 Bayes at boundary q (ties only), no interior ties.
(2) the splices Y_k = T1 off J_k, P_i on J_k are incoherent (midpoint-convexity witnesses); T1 baseline.
(3) for the shadow field, the tie-broken edge Bayes model T^i_theta equals Y_k on the sample.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from m1_common import Geo, midpoint_violations, rand_simplex

rng = np.random.default_rng(20261016)
for eps, s in [(0.1, 0.9), (0.3, 0.9), (0.6, 0.5)]:
    geo = Geo(eps, s)
    G = geo.sample_mixed_U(rng, 200000)
    acc = geo.T1(G)
    cor = geo.correct(G, acc)                    # T1 correct at k
    sgn = np.sign(G)
    rho = cor.astype(float)                      # shadow: rho_k = 1 on R0_k, 0 on E_k(T1)
    c = rho * sgn
    sT = np.where(acc, 1.0, -1.0)
    ncor = cor.sum(axis=1)
    print(f"eps={eps}, s={s}: n={len(G)}; #correct worlds per g in {{1,2}}: "
          f"{np.unique(ncor).tolist()}  (frac exactly one = {np.mean(ncor == 1):.4f})")
    # (1) interior and boundary weights
    Q = rand_simplex(rng, 1500)
    bad_int, ties_int = 0, 0
    for q in Q:
        v = c @ q
        bad_int += int(np.sum((v != 0) & (np.sign(v) != sT)))
        ties_int += int(np.sum(v == 0))
    bnd = [np.array([1, 0, 0.]), np.array([0, 1, 0.]), np.array([0, 0, 1.])]
    for t in np.linspace(0.05, 0.95, 19):
        bnd += [np.array([t, 1 - t, 0]), np.array([0, t, 1 - t]), np.array([1 - t, 0, t])]
    bad_b = 0
    for q in bnd:
        v = c @ q
        bad_b += int(np.sum((v != 0) & (np.sign(v) != sT)))
    print(f"  (1) interior q: sign mismatches with T1 = {bad_int}, ties = {ties_int} (over 1500 q);"
          f" boundary q (60): strict mismatches = {bad_b}")
    # joint blind sets J_k = E_i ∩ E_j (T1 correct only at k)
    for k in range(3):
        Jk = (ncor == 1) & cor[:, k]
        print(f"  J_{k+1} = Lambda_i ∩ Lambda_j (i,j != {k+1}): fraction {Jk.mean():.4f}")
    # (2) incoherence of Y_k
    odd = geo.oddworld(G)
    def make_Y(k):
        i = (k + 1) % 3
        def Y(g):
            a = geo.T1(g)
            o = geo.oddworld(g)
            return np.where(o == k, g[:, i] > 0, a)   # on Q_k (worlds i,j agree) follow P_i
        return Y
    v0, n0 = midpoint_violations(geo.T1, G, geo, rng)
    out = [f"T1 baseline {v0}/{n0}"]
    for k in range(3):
        v, n = midpoint_violations(make_Y(k), G, geo, rng)
        out.append(f"Y_{k+1}: {v}/{n}")
    print("  (2) midpoint-convexity violations: " + "; ".join(out))
    # (3) tie-broken edge Bayes model T^i_theta for the shadow equals Y_k
    for (i, j, k) in [(0, 1, 2), (1, 2, 0), (2, 0, 1)]:
        mism = 0
        for th in [0.1, 0.37, 0.5, 0.83]:
            e = th * c[:, i] + (1 - th) * c[:, j]
            Tth = np.where(e > 0, True, np.where(e < 0, False, G[:, i] > 0))
            Yk = np.where(odd == k, G[:, i] > 0, acc)
            mism += int(np.sum(Tth != Yk))
        print(f"  (3) edge ({i+1},{j+1}): #samples where T^{i+1}_theta != Y_{k+1}, 4 thetas: {mism}")
