"""M1 NUMERICS (4)-(5): the vertex case (V) under (B1).
(4) the totally blind vertex field c = (0, s2, s3): every B_q is P2, P3 or P2∩P3 (midpoint test), T1 admissible at e1.
(5) Prop. M1.2: if K1 ⊆ co(K' ∪ [e1,e2]) meets [e1,e2] only at m = (a,1-a,0) with a > 0, then D_{K1} misses part of
    D_{T1} ∩ (-,+,+) near w21 = (-1,0,kappa) (so Lambda_1 ⊉ E_1(T1) on R_12); with e2 ∈ K1, D_{K1} ∩ (+,-,.) = ∅.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from m1_common import Geo, midpoint_violations, rand_simplex

rng = np.random.default_rng(7)
for eps, s in [(0.1, 0.9), (0.3, 0.9), (0.6, 0.5)]:
    geo = Geo(eps, s)
    G = geo.sample_mixed_U(rng, 100000)
    sg = np.sign(G)
    # (4)
    worst = 0
    for q in rand_simplex(rng, 40):
        th = q[1] / (q[1] + q[2])
        acc = lambda g, th=th: (th * np.sign(g[:, 1]) + (1 - th) * np.sign(g[:, 2])) > 0
        v, n = midpoint_violations(acc, G, geo, rng, trials=5000)
        worst = max(worst, v)
    print(f"eps={eps}, s={s}: (4) field (0,s2,s3): max midpoint violations over 40 interior q = {worst}; "
          f"T1 admissible at e1 (v1 = 0 identically): True")
    # (5)
    w21 = np.array([-1.0, 0.0, geo.kappa])
    near = w21 + 1e-3 * np.array([0, 1, 0])          # inside D_{T1}? small positive g2
    inside = geo.T1(near[None])[0]
    fails = 0
    for trial in range(300):
        a = rng.uniform(0.01, 1.0)
        m = np.array([a, 1 - a, 0.0])
        lam = rng.dirichlet(np.ones(5), size=3)
        pts = np.vstack([geo.Vp, np.eye(3)[0], np.eye(3)[1]])
        extra = lam @ pts                           # points of co(K' ∪ [e1,e2])
        K1 = np.vstack([geo.Vp, m, extra])
        # a point of D_{T1} ∩ (-,+,+) near w21 not in D_{K1}:
        gs = w21 + np.outer(np.linspace(1e-4, 1e-2, 50), np.array([0, 1, 0])) + 1e-5 * np.array([0, 0, 1])
        ok = geo.T1(gs) & (gs[:, 1] > 0) & ~geo.inD(gs, K1)
        fails += int(ok.any())
    K1e2 = np.vstack([geo.Vp, np.eye(3)[1]])
    pm = (sg[:, 0] > 0) & (sg[:, 1] < 0)
    print(f"  (5) point near w21 inside D_T1: {inside}; K1 with a>0 missing part of D_T1∩(-,+,+): {fails}/300;"
          f" e2 ∈ K1 => D_K1 ∩ (+,-,.) sample count = {int(geo.inD(G[pm], K1e2).sum())} (of {int(pm.sum())})")
