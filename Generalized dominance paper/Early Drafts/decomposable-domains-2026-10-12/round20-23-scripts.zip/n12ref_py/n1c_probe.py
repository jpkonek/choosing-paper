"""Referee probe of CONJECTURE N1.C: search between models D_K (K ⊇ K', K meets [e_i,e_j],
K ⊆ conv(K' ∪ [e_i,e_j])) that do NOT cross T1 on R_ij, including K containing a vertex e_i or e_j
(other than P_i, P_j) and edge points very close to the vertices. NUMERICS only."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from n1b_common_copy import Geo, errors
rng = np.random.default_rng(7)
E = np.eye(3)
for eps, s in [(0.1, 0.9), (0.3, 0.5), (0.6, 0.5)]:
    geo = Geo(eps, s)
    G = np.concatenate([geo.sample_mixed_U(rng, 60000), geo.near_T1_boundary(rng, 60000)])
    accT = geo.T1(G)
    print(f"eps={eps}, s={s}")
    for (i, j) in [(0, 1), (1, 2), (2, 0)]:
        R = (G[:, i] * G[:, j]) < 0
        EiT = errors(G, accT, i) & R
        Pi = geo.inD(G, np.vstack([geo.Vp, E[i]])); Pj = geo.inD(G, np.vstack([geo.Vp, E[j]]))
        nc, tot, minab = 0, 0, 10**9
        for trial in range(400):
            mode = trial % 4
            H = np.vstack([geo.Vp, E[i], E[j]])
            if mode == 0: m = [E[j]]
            elif mode == 1: m = [E[i]]
            elif mode == 2: m = [(1-t)*E[i]+t*E[j] for t in [rng.uniform(0, 0.02)]]
            else: m = [(1-t)*E[i]+t*E[j] for t in [rng.uniform(0.98, 1)]]
            extra = []
            for _e in range(rng.integers(1, 5)):
                w = rng.exponential(size=len(H)) ** 3; w /= w.sum(); extra.append(w @ H)
            K = np.vstack([geo.Vp] + m + extra)
            acc = geo.inD(G, K)
            if np.array_equal(acc[R], Pi[R]) or np.array_equal(acc[R], Pj[R]):
                continue
            EiC = errors(G, acc, i) & R
            a = int(np.sum(EiT & ~EiC)); b = int(np.sum(EiC & ~EiT))
            tot += 1; cr = (a > 0 and b > 0); nc += int(not cr); minab = min(minab, min(a, b))
        print(f"  edge ({i+1},{j+1}): non-crossing {nc}/{tot}; min smaller piece {minab}")
