"""Round-20 note N1 (blind targets): shared geometry. NUMERICS only; no proof depends on it.
T1 = eps-contamination of u = (1/3,1/3,1/3); U = D_{K'}, K' = u + s(T1 - u).
Run the scripts with  python3 -I -B <script>  from inside n1py/."""
import numpy as np


class Geo:
    def __init__(self, eps, s):
        self.eps, self.s = eps, s
        self.c0 = (1 - eps) / 3
        self.u = np.ones(3) / 3
        self.V = np.array([self.c0 * np.ones(3) + eps * np.eye(3)[k] for k in range(3)])
        self.Vp = np.array([self.u + s * (self.V[k] - self.u) for k in range(3)])

    @staticmethod
    def PK(g, K):
        return np.min(g @ np.asarray(K).T, axis=-1)

    def inD(self, g, K):
        return self.PK(g, K) > 0

    def inU(self, g):
        return self.inD(g, self.Vp)

    def T1(self, g):
        return self.inD(g, self.V)

    def sample_mixed_U(self, rng, n):
        out, m = [], 0
        while m < n:
            g = rng.normal(size=(4 * n, 3))
            k = rng.integers(0, 3, size=len(g))
            lam = np.exp(rng.uniform(0, 3, size=len(g)))
            g[np.arange(len(g)), k] *= lam
            g /= np.linalg.norm(g, axis=1, keepdims=True)
            sg = np.sign(g)
            keep = self.inU(g) & (sg.max(axis=1) > 0) & (sg.min(axis=1) < 0)
            out.append(g[keep])
            m += keep.sum()
        return np.concatenate(out)[:n]

    def near_T1_boundary(self, rng, n, width=0.02):
        """mixed gambles of U within angular distance ~width of the boundary of D_{T1}"""
        out, m = [], 0
        while m < n:
            g = self.sample_mixed_U(rng, 4 * n)
            d = np.min(g @ self.V.T, axis=1)          # P_{T1}(g) on the unit sphere
            keep = np.abs(d) < width
            out.append(g[keep])
            m += keep.sum()
        return np.concatenate(out)[:n]


def errors(G, acc, i):
    """world-i error indicator of the model with acceptance acc on the sample G"""
    return (G[:, i] > 0) != acc


def odd_world(G):
    sg = np.sign(G)
    tot = sg.sum(axis=1)
    return np.where(tot > 0, np.argmin(sg, axis=1), np.argmax(sg, axis=1))
