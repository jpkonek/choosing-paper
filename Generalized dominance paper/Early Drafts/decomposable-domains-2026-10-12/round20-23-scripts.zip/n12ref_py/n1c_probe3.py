"""(a) Explicit counterexample to N1.C as stated: K = conv(K' ∪ {e_1, q}), q = midpoint(v_1, v_2) ∈ T1,
q ∈ conv(K' ∪ [e_1,e_2]) \ conv(K' ∪ {e_1}). Then D_K ≠ P_1 on R_12 and E_1(D_K) ∩ R_12 ⊆ E_1(T1) ∩ R_12 (no crossing).
(b) The same search as n1c_probe.py but only with K meeting the OPEN edge (t in (0, 0.02) ∪ (0.98, 1)) plus a point q ∈ T1.
NUMERICS only."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from n1b_common_copy import Geo, errors
rng = np.random.default_rng(11)
E = np.eye(3)
for eps, s in [(0.1, 0.9), (0.3, 0.5), (0.6, 0.5)]:
    geo = Geo(eps, s)
    G = np.concatenate([geo.sample_mixed_U(rng, 200000), geo.near_T1_boundary(rng, 200000, width=0.005)])
    R = (G[:, 0] * G[:, 1]) < 0
    EiT = errors(G, geo.T1(G), 0) & R
    q = 0.5 * (geo.V[0] + geo.V[1])
    # membership of q in conv(K' ∪ [e1,e2]): solve q = a*k + (1-a)*(x e1 + (1-x) e2) with k on segment v'_1 v'_2
    K = np.vstack([geo.Vp, E[0], q])
    acc = geo.inD(G, K); P1 = geo.inD(G, np.vstack([geo.Vp, E[0]]))
    EiC = errors(G, acc, 0) & R
    a = int(np.sum(EiT & ~EiC)); b = int(np.sum(EiC & ~EiT)); d = int(np.sum((acc != P1) & R))
    # check q in conv(K' ∪ [e1,e2]) via third coordinate argument: need q3 >= 0 and q3 <= max k'_3 etc. (LP-free test)
    mid = 0.5 * (geo.Vp[0] + geo.Vp[1]); alpha = q[2] / mid[2]
    rest = (q - alpha * mid) / (1 - alpha)
    inhull = (0 <= alpha <= 1) and np.all(rest >= -1e-12) and abs(rest[2]) < 1e-12
    ratio_q = q[1] / q[2]; ratio_max = max(geo.Vp[:, 1] / geo.Vp[:, 2])
    print(f"eps={eps}, s={s}: (a) q in conv(K'∪[e1,e2]): {inhull}; q2/q3={ratio_q:.3f} > max over K' {ratio_max:.3f} (so q ∉ conv(K'∪{{e1}})): {ratio_q > ratio_max}")
    print(f"   |D_K △ P_1| on R_12 = {d} samples; crossing pieces (E_1T1∖E_1C, E_1C∖E_1T1) = ({a}, {b})")
    # (b)
    nc, tot = 0, 0
    for (i, j) in [(0, 1), (1, 2), (2, 0)]:
        Rij = (G[:, i] * G[:, j]) < 0
        EiTij = errors(G, geo.T1(G), i) & Rij
        for trial in range(150):
            t = rng.uniform(0, 0.02) if trial % 2 == 0 else rng.uniform(0.98, 1)
            m = (1 - t) * E[i] + t * E[j]
            w = rng.exponential(size=3); w /= w.sum(); qq = w @ geo.V
            K = np.vstack([geo.Vp, m, qq])
            acc = geo.inD(G, K)
            EiC = errors(G, acc, i) & Rij
            a = int(np.sum(EiTij & ~EiC)); b = int(np.sum(EiC & ~EiTij))
            tot += 1; nc += int(not (a > 0 and b > 0))
    print(f"   (b) open-edge m near a vertex + q ∈ T1: non-crossing {nc}/{tot}")
