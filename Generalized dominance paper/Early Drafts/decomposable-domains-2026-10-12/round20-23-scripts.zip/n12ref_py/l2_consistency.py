"""Consistency of N2.1/N2.3 with L2 (exact, cell model of the two-world chain).
World 1's maximal endorser: lambda restricted to d_a (density 1 on x >= a, 0 on c_a = {x < a}); world 2: density 1.
Check: (i) every path model C_b is theta-Bayes for some theta (N2.1(c)); (ii) every extreme edge Bayes model
E^{theta,-}, E^{theta,+} (theta on a grid incl. 0, 1/2, 1) is a path model C_b (N2.3). NUMERICS (exact on a grid)."""
from fractions import Fraction as F
a = F(2, 5); N = 40                      # cells [k/N,(k+1)/N); a is a cell boundary
cells = [F(k, N) for k in range(N)]
rho1 = [0 if x < a else 1 for x in cells]; rho2 = [1] * N
def e(th, k): return th * rho1[k] - (1 - th) * rho2[k]
def is_theta_bayes(c, th):               # c = set of cells in world-1 error set
    return all((e(th, k) <= 0) if k in c else (e(th, k) >= 0) for k in range(N))
thetas = [F(k, 200) for k in range(201)]
ok1 = all(any(is_theta_bayes(set(range(b)), th) for th in thetas) for b in range(N + 1))
paths = {frozenset(range(b)) for b in range(N + 1)}
ok2 = True
for th in thetas:
    L = frozenset(k for k in range(N) if e(th, k) < 0); Uu = frozenset(k for k in range(N) if e(th, k) <= 0)
    ok2 &= (L in paths) and (Uu in paths)
print("(i) every C_b theta-Bayes:", ok1, "; (ii) every E^{theta,+-} is a path model:", ok2)
