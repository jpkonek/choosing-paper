"""Re-find the open-edge non-crossing case of n1c_probe3 (b) at eps=0.6 and test it on a much larger,
boundary-concentrated sample. Also a systematic family: K = conv(K' ∪ {m_t, q}) with q = midpoint(v_i, v_j) and
m_t near e_i. NUMERICS only."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from n1b_common_copy import Geo, errors
E = np.eye(3)
for eps, s in [(0.3, 0.5), (0.6, 0.5)]:
    geo = Geo(eps, s)
    rng = np.random.default_rng(5)
    G = np.concatenate([geo.sample_mixed_U(rng, 400000), geo.near_T1_boundary(rng, 400000, width=0.003)])
    for (i, j) in [(0, 1)]:
        R = (G[:, i] * G[:, j]) < 0
        EiT = errors(G, geo.T1(G), i) & R
        q = 0.5 * (geo.V[i] + geo.V[j])
        for t in [1e-1, 3e-2, 1e-2, 1e-3, 1e-4, 1e-6]:
            m = (1 - t) * E[i] + t * E[j]
            K = np.vstack([geo.Vp, m, q])
            acc = geo.inD(G, K)
            EiC = errors(G, acc, i) & R
            a = int(np.sum(EiT & ~EiC)); b = int(np.sum(EiC & ~EiT))
            # where is the b-piece?  (C wrong at i, T1 right at i): report sign patterns
            pat = np.sign(G[EiC & ~EiT]).astype(int)
            pats = {tuple(p) for p in pat[:2000]}
            print(f"eps={eps} edge ({i+1},{j+1}) t={t:g}: pieces (a,b)=({a},{b}); b-piece sign patterns {sorted(pats)[:4]}")
