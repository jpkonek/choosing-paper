"""Diagnose non-crossing between models found by n1c_probe.py: which mode, which direction,
and whether the non-crossing persists on a larger fresh sample. NUMERICS only."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from n1b_common_copy import Geo, errors
rng = np.random.default_rng(7)
E = np.eye(3)
eps, s = 0.3, 0.5
geo = Geo(eps, s)
G = np.concatenate([geo.sample_mixed_U(rng, 60000), geo.near_T1_boundary(rng, 60000)])
G2 = np.concatenate([geo.sample_mixed_U(rng, 300000), geo.near_T1_boundary(rng, 300000, width=0.005)])
i, j = 0, 1
H = np.vstack([geo.Vp, E[i], E[j]])
found = 0
for trial in range(400):
    mode = trial % 4
    if mode == 0: m = [E[j]]
    elif mode == 1: m = [E[i]]
    elif mode == 2: m = [(1-t)*E[i]+t*E[j] for t in [rng.uniform(0, 0.02)]]
    else: m = [(1-t)*E[i]+t*E[j] for t in [rng.uniform(0.98, 1)]]
    extra = []
    for _e in range(rng.integers(1, 5)):
        w = rng.exponential(size=len(H)) ** 3; w /= w.sum(); extra.append(w @ H)
    K = np.vstack([geo.Vp] + m + extra)
    for GG, tag in [(G, 'small')]:
        R = (GG[:, i] * GG[:, j]) < 0
        EiT = errors(GG, geo.T1(GG), i) & R
        acc = geo.inD(GG, K)
        EiC = errors(GG, acc, i) & R
        a = int(np.sum(EiT & ~EiC)); b = int(np.sum(EiC & ~EiT))
    if not (a > 0 and b > 0):
        R2 = (G2[:, i] * G2[:, j]) < 0
        EiT2 = errors(G2, geo.T1(G2), i) & R2
        EiC2 = errors(G2, geo.inD(G2, K), i) & R2
        a2 = int(np.sum(EiT2 & ~EiC2)); b2 = int(np.sum(EiC2 & ~EiT2))
        Pj = geo.inD(G2, np.vstack([geo.Vp, E[j]])); Pi = geo.inD(G2, np.vstack([geo.Vp, E[i]]))
        accC = geo.inD(G2, K)
        dPj = int(np.sum((accC != Pj) & R2)); dPi = int(np.sum((accC != Pi) & R2))
        print(f"mode {mode}: small (a,b)=({a},{b}); big (a,b)=({a2},{b2}); |C△P_j| on R={dPj}, |C△P_i| on R={dPi}; K extra={np.round(np.array(extra),3).tolist()}")
        found += 1
        if found >= 12: break
