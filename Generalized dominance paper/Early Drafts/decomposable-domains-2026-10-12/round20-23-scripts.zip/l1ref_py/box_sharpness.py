"""L1 referee: sharpness test of Lemma L1.3 (crossing-box formula). In the two-arc configuration at eps=0.3,
move x1 across the predicted thresholds (b=3: x1*x2 <= m3 ; b=2: x1*M <= kappa^2) and check that the
exact per-pair test (twoarc_exact.exact_box) finds violations exactly beyond the threshold, near crossings.
Run: python3 -I box_sharpness.py
"""
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import twoarc_exact as T
base = T.setup(0.3)
K, x2 = base['K'], base['x2']
m3 = (K + 2) * (base['t3F2'] - base['b']) / (1 - base['b'])
print('predicted b=3,a=2 threshold x1 <= m3/x2 = %.5f' % (m3 / x2))
for x1 in (m3 / x2 * 0.97, m3 / x2 * 1.03):
    info = T.setup(0.3, x1=x1)
    cb = T.crossing_boxes(info)
    v, n, best = T.exact_box(info, T.samples(info, n=200))
    print('x1=%.5f crossing boxes ok=%s ; exact pair test violations=%d best=%s' % (x1, {k: bool(t[2]) for k, t in cb.items()}, v, best))
