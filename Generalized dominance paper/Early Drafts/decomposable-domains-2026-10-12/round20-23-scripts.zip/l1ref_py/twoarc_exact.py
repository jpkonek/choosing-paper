"""L1 referee: independent re-implementation of the two-R*-arc configuration of L1 Prop. L1.2 at eps=0.3,
with an EXACT per-pair box test (no q-grid): for each ordered (a,b), each pair (A,B) of facet points with
A_a<0<A_b, B_b<0<B_a, A_b B_a < |A_a||B_b|, decide exactly whether some q0=(1-s)e_a+s e_b, s in (0,1),
has c(A).q0>0 and c(B).q0>0.  Pairs are sampled densely with log-clustering at the six crossings.
Also: analytic crossing boxes via Lemma L1.3 formula, recomputed from the data, and a sweep over kappa.
Run: python3 -I twoarc_exact.py
"""
import itertools
import numpy as np

def setup(eps, x1=0.5, db=0.02, N=5.0):
    K = (1 + 2 * eps) / (1 - eps)
    R12 = np.array([-1, -1, K + 1.]); R23 = np.array([K + 1, -1, -1.]); R31 = np.array([-1, K + 1, -1.])
    ENDS = {1: (R12, R31), 2: (R12, R23), 3: (R23, R31)}
    h = lambda f, t: (1 - t) * ENDS[f][0] + t * ENDS[f][1]
    cr = lambda f, l: ENDS[f][0][l] / (ENDS[f][0][l] - ENDS[f][1][l])
    t1F2, t3F2, t2F3, t1F3 = cr(2, 0), cr(2, 2), cr(3, 1), cr(3, 0)
    b = t1F2 + db; a = t1F2 - db; ap = t1F3 - db; bp = t1F3 + db
    x2 = (K + 2) * (1 - 1 / N)
    def cF1(t):
        H = h(1, t); return np.array([-(x1 * H[1] + H[2]), x1 * H[1], H[2]])
    c_r12 = cF1(0.0); c_r31 = cF1(1.0)
    def cF2(t):
        if t < a:
            w = t / a; return (1 - w) * c_r12 + w * np.array([0, -1., 1.])
        if t <= b:
            return np.array([0, -1., 1.])
        H = h(2, t); c1 = (K + 2) * (t - b) / (1 - b); c3 = x2 * H[2]; return np.array([c1, -c1 - c3, c3])
    def cF3(t):
        if t < ap:
            H = h(3, t); c1 = N * (ap - t) / ap; c2 = H[1]; return np.array([c1, c2, -c1 - c2])
        if t <= bp:
            return np.array([0, 1., -1.])
        w = (t - bp) / (1 - bp); return (1 - w) * np.array([0, 1., -1.]) + w * c_r31
    C = {1: cF1, 2: cF2, 3: cF3}
    info = dict(K=K, x1=x1, x2=x2, N=N, a=a, b=b, ap=ap, bp=bp, t1F2=t1F2, t3F2=t3F2, t2F3=t2F3, t1F3=t1F3,
                h=h, C=C, cr=cr)
    return info

def samples(info, n=700):
    pts = []
    crosses = {1: [info['cr'](1, 1), info['cr'](1, 2)], 2: [info['t1F2'], info['t3F2']], 3: [info['t2F3'], info['t1F3']]}
    for f in (1, 2, 3):
        ts = list(np.linspace(1e-4, 1 - 1e-4, n))
        for tc in crosses[f]:
            for e in np.logspace(-7, -1, 60):
                ts += [tc - e, tc + e]
        for t in ts:
            if 0 < t < 1:
                pts.append((f, t, info['h'](f, t), info['C'][f](t)))
    return pts

def pos_interval(ca, cb):
    """{s in (0,1): (1-s) ca + s cb > 0} as (lo, hi) open interval or None."""
    if ca > 0 and cb > 0: return (0., 1.)
    if ca <= 0 and cb <= 0: return None
    s0 = ca / (ca - cb)
    return (0., s0) if ca > 0 else (s0, 1.)

def exact_box(info, pts):
    viol = 0; tested = 0; best = None
    for a, b in itertools.permutations(range(3), 2):
        As = [(f, t, H, c) for f, t, H, c in pts if H[a] < 0 < H[b]]
        Bs = [(f, t, H, c) for f, t, H, c in pts if H[b] < 0 < H[a]]
        for fA, tA, HA, cA in As:
            IA = pos_interval(cA[a], cA[b])
            if IA is None: continue
            for fB, tB, HB, cB in Bs:
                if not (HA[b] * HB[a] < abs(HA[a]) * abs(HB[b])): continue
                IB = pos_interval(cB[a], cB[b])
                tested += 1
                if IB is None: continue
                lo, hi = max(IA[0], IB[0]), min(IA[1], IB[1])
                if lo < hi - 1e-12:
                    viol += 1
                    m = (hi - lo)
                    if best is None or m > best[0]: best = (m, (a, b), (fA, tA), (fB, tB))
    return viol, tested, best

def crossing_boxes(info):
    """Lemma L1.3 for b=2 (F1 w21, F3 w23) and b=3 (F1 w31, F2 w32), recomputed from data."""
    h, C, cr = info['h'], info['C'], info['cr']
    out = {}
    # coordinate b crossings, facet data: lambda = c_b / h_b slope near crossing
    def lam(f, t, bb):
        d = 1e-6; return (C[f](t + d)[bb] - C[f](t - d)[bb]) / (h(f, t + d)[bb] - h(f, t - d)[bb])
    for bb, (fa, ta), (fb, tb) in ((1, (1, cr(1, 1)), (3, info['t2F3'])), (2, (1, cr(1, 2)), (2, info['t3F2']))):
        wA, wB = h(fa, ta), h(fb, tb)
        for aa in range(3):
            if aa == bb: continue
            # orient: need w_A,a < 0 < w_B,a
            P, Q = ((fa, ta, wA), (fb, tb, wB)) if wA[aa] < 0 < wB[aa] else ((fb, tb, wB), (fa, ta, wA))
            if not (P[2][aa] < 0 < Q[2][aa]): continue
            lA, lB = lam(P[0], P[1], bb), lam(Q[0], Q[1], bb)
            lhs = lB * abs(C[P[0]](P[1])[aa]) * Q[2][aa]; rhs = lA * C[Q[0]](Q[1])[aa] * abs(P[2][aa])
            out[(aa + 1, bb + 1)] = (lhs, rhs, lhs >= rhs)
    return out

if __name__ == '__main__':
    info = setup(0.3)
    print('eps=0.3 kappa=%.4f x1=%.3f x2=%.4f' % (info['K'], info['x1'], info['x2']))
    # strict signs
    bad = 0
    for f in (1, 2, 3):
        for t in np.linspace(1e-4, 1 - 1e-4, 4001):
            H = info['h'](f, t); c = info['C'][f](t)
            inarc = (f == 2 and info['a'] <= t <= info['b']) or (f == 3 and info['ap'] <= t <= info['bp'])
            for l in range(3):
                if inarc and l == 0: continue
                if abs(H[l]) > 1e-9 and np.sign(c[l]) != np.sign(H[l]): bad += 1
    print('strict-sign failures:', bad)
    print('crossing boxes (a,b): (lhs, rhs, ok)', crossing_boxes(info))
    pts = samples(info, n=500)
    v, n, best = exact_box(info, pts)
    print('exact per-pair box test: tested %d pairs, violations %d, best %s' % (n, v, best))
    # kappa sweep of the analytic claim: exists x1 in corner window with b=3 boxes, b=2 box attainable
    for eps in (0.01, 0.05, 0.1, 0.3, 0.6, 0.9, 0.99):
        K = (1 + 2 * eps) / (1 - eps)
        lo3, hi3 = 1 / (K * (K + 1)), K / (K + 1)
        lo, hi = max(lo3, 1 / (K + 1)), min(hi3, K + 1)
        print('eps=%.2f kappa=%.3f limiting x1-window (%.4f, %.4f] nonempty=%s' % (eps, K, lo, hi, lo < hi))
