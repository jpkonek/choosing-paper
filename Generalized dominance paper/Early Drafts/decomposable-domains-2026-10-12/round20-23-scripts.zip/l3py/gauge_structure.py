"""L3 NUMERICS: structure of near-optimal fixed-domain gauge mixtures approaching T1.
Admissible class as in fixed_domain_gauges3.py (compatible, fixed (LF) margin of W=T1(eps_w)).
Prints d_H, the gauge points, and the normalised penalties f_i/s on test gambles across facet F_1.
"""
import numpy as np, sys, time
sys.path.insert(0, '.')
from fastgeo import *
from fixed_domain_gauges3 import base_points, Ku, unpack, obj
from scipy.optimize import minimize
eps, eps_w = 0.3, 0.25
tgt = T1(eps); tgt2 = to2(tgt)
base = [base_points(eps_w, i, 1, 0) for i in range(3)]
nv = sum(len(b) for b in base)
rng = np.random.default_rng(3)
best = (1, None)
for s in range(4):
    x0 = rng.normal(0, 1.5, nv)
    r = minimize(obj, x0, args=(base, tgt2), method="L-BFGS-B", options={"maxiter": 4000})
    r = minimize(obj, r.x, args=(base, tgt2), method="Nelder-Mead", options={"maxiter": 30000, "xatol":1e-7, "fatol":1e-10})
    if r.fun < best[0]: best = (r.fun, r.x)
    print("seed", s, r.fun, flush=True)
val, x = best
Ms = unpack(x, base)
np.save("gauge_best_x.npy", x)
print("best d_H =", val)
for i in range(3):
    print("M_%d points:" % (i+1))
    for m in Ms[i]:
        print("   ", np.round(m, 5), " |m|=%.3g" % np.linalg.norm(m))
s = max(np.abs(M).max() for M in Ms)
def f(h): return np.array([(M @ h).min() for M in Ms])
kap = (1+2*eps)/(1-eps)
r12 = np.array([-1,-1,kap+1.]); r31 = np.array([-1,kap+1,-1.])
n1 = tgt[0]/np.linalg.norm(tgt[0])
for tau in [0.02, 0.1, 0.3, 0.5, 0.7, 0.9, 0.98]:
    h = (1-tau)*r31 + tau*r12; h = h/np.linalg.norm(h)
    for d in [0.0, 0.01, 0.03]:
        g = h - d*n1
        print(f"F1 tau={tau:.2f} out={d:.2f} sign={np.sign(np.round(g,9)).astype(int)} f/s={np.round(f(g)/s,5)} mean={f(g).mean()/s:.2e}", flush=True)
