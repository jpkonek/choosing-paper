import numpy as np, sys
sys.path.insert(0,'.')
from fixed_domain_gauges import *
eps, eps_w = 0.3, 0.25
W = T1(eps_w); Wpts = np.array(list(W))
tgt = T1(eps); tgt2 = to2(tgt)
val, x = run(eps, eps_w, 0, seeds=3, iters=2500)
Ms = build(x, Wpts)
K = Ku(Ms)
H = hull2(to2(K))
print("best dH", val)
print("a_i =", np.exp(x[:3]))
print("lifts =", np.exp(x[3:]).reshape(3,3))
# signed support comparison in many directions
th = np.linspace(0,2*np.pi,24,endpoint=False)
for t in th:
    d = np.array([np.cos(t), np.sin(t)])
    print(f"{t:5.2f} hK={max(H@d):.4f} hT1={max(tgt2@d):.4f} hW={max(to2(W)@d):.4f}")
