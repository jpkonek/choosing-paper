"""L3 NUMERICS for Theorem L3.3 (the veto-Brier ranking VB on M_U) and Theorem L3.4 (veto lemma).

Empirical version: the measure mu is replaced by N sampled gambles of U (the proofs in L3_notes
hold for every finite non-atomic measure; an empirical measure is atomic, so this checks the
pointwise / lexicographic algebra, not non-atomicity).
U = D_{K'}, K' = u + s(T1-u).  World i:  lexicographic (Phi_i, Psi_i) with
  Phi_i(X) = sum_{h in X, v_i.h<0} |v_i.h|           (veto of T1's facet F_i)
  Psi_i(X) = sum over errors |h_i|                    (Brier/identity level)
Selection: C_p = U n {p.h>0} n {v_m.h >= 0 : m in supp p}  (= D_{conv(K' u {p} u {v_m})}).
Tests (counts of violations should be 0):
  (a) competitiveness of C_p on supp p against many test models X;
  (b) no X dominates C_p;
  (c) T1 = C_p for p in T1 (plateau);
  (d) closed sections fail at world 1 for X = C_{e2} minus part of the world-1 veto set.
"""
import numpy as np
rng = np.random.default_rng(5)
E = np.eye(3); u = np.ones(3) / 3
eps, s = 0.3, 0.5
c0 = (1 - eps) / 3
V = np.array([c0 * np.ones(3) + eps * E[k] for k in range(3)])          # vertices of T1
Kp_ = u + s * (V - u)                                                    # vertices of K'
N = 60000
H = rng.normal(size=(4 * N, 3))
H = H[(H @ Kp_.T).min(1) > 0][:N]                                        # gambles of U
VH = H @ V.T                                                             # v_m . h
veto = np.where(VH < 0, -VH, 0.0)                                        # weight of vetoed acceptance at world m
pos = H > 0
def vec(X):
    """6-vector (Phi_1..3, Psi_1..3) of a model X (boolean array over the sample)."""
    Phi = (veto * X[:, None]).sum(0)
    Psi = (np.abs(H) * (X[:, None] != pos)).sum(0)
    return Phi, Psi
def leq(a, b, m, tol=1e-9):
    """X <=_m Y lexicographically, given vec(X)=a, vec(Y)=b."""
    if a[0][m] < b[0][m] - tol: return True
    if a[0][m] > b[0][m] + tol: return False
    return a[1][m] <= b[1][m] + tol
def C(p):
    X = (H @ p) > 0
    for m in range(3):
        if p[m] > 0: X &= VH[:, m] >= 0
    return X
def coherentD(K):
    return (H @ np.atleast_2d(K).T).min(1) > 0
def test_models(p, k):
    """A family of competitors: other selected models, random coherent models,
    random additive-Bayes models, and random splices / perturbations of C_p."""
    Xs = []
    Cp = C(p)
    for _ in range(k):
        q = rng.dirichlet(np.ones(3) * rng.uniform(0.2, 3))
        Xs.append(C(q))
        Xs.append(coherentD(rng.dirichlet(np.ones(3), size=rng.integers(1, 4))))
        w = rng.exponential(size=3); cvec = H * rng.uniform(0.2, 2, size=(len(H), 3))
        Xs.append((cvec @ w) > 0)                                        # random additive Bayes model
        A = rng.random(len(H)) < rng.uniform(0.001, 0.2)
        Xs.append(Cp ^ A)                                                # random flips
        B = (np.abs((H @ V.T).min(1)) < rng.uniform(0.05, 0.5)) & (rng.random(len(H)) < 0.5)
        Xs.append(Cp ^ B)                                                # flips near the boundary of D_T1
        Xs.append(Cp | (B & pos[:, rng.integers(3)]))                    # add near-boundary gambles good at one world
        Xs.append(Cp & ~(B & ~pos[:, rng.integers(3)]))                  # remove near-boundary gambles bad at one world
    return Xs
priors = [rng.dirichlet(np.ones(3)) for _ in range(8)] + [u, V[0], np.array([.5, .5, 0]),
          np.array([.2, 0, .8]), np.array([0, .7, .3]), E[0], E[1], E[2]]
viol_comp = viol_dom = ntest = 0
for p in priors:
    Cp = C(p); vp = vec(Cp); S = [m for m in range(3) if p[m] > 0]
    for X in test_models(p, 40):
        vx = vec(X); ntest += 1
        if not any(leq(vp, vx, m) for m in S): viol_comp += 1
        if all(leq(vx, vp, m) for m in range(3)) and any(not leq(vp, vx, m) for m in range(3)):
            viol_dom += 1
print(f"(a) competitiveness violations: {viol_comp} / {ntest}")
print(f"(b) domination of a selected model: {viol_dom} / {ntest}")
T1model = coherentD(V)
print("(c) plateau: |C_p xor D_T1| for p in T1:",
      [int((C(q) ^ T1model).sum()) for q in [u, 0.5 * u + 0.5 * V[1], V[2] * 0.99 + 0.01 * u]])
# (d) closed sections fail
Ce2 = C(E[1])
Vset = Ce2 & (VH[:, 0] < 0)
idx = np.nonzero(Vset)[0]; Apart = np.zeros(len(H), bool); Apart[idx[: len(idx) // 2]] = True
X = Ce2 & ~Apart
vx = vec(X)
ts = [0.9, 0.99, 0.999, 0.9999]
inside = [leq(vec(C((1 - t) * u + t * E[1])), vx, 0) for t in ts]
print(f"(d) |veto set of world 1 accepted by C_e2| = {len(idx)};  C_q <=_1 X along q -> e2: {inside};"
      f"  C_e2 <=_1 X: {leq(vec(Ce2), vx, 0)}  (section not closed if all True then False)")
