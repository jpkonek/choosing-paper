"""L3 NUMERICS: can gauge mixtures (R10a Thm M) approach T1 on a FIXED domain?

Domain fixed by W = T1(eps_w), eps_w < eps (so (LF) at T1(eps) holds with a fixed margin):
V_i = conv(e_i u W), Av = union D_{V_i}.  Gauges: M_i = conv{a_i e_i, lam_{ik} w_k}, w_k points of W
(vertices of W and extra points on its edges), all lifts free.  K_u = nu(sum_i M_i / 3).
We minimise the Hausdorff distance d_H(K_u, T1(eps)) over the lifts (log-parametrised).
Evidence only.
"""
import numpy as np
from scipy.spatial import ConvexHull
from scipy.optimize import minimize
import itertools, sys

E = np.eye(3)
# planar coordinates of the simplex
B2 = np.array([[1, 0], [0.5, np.sqrt(3) / 2], [0, 0]])  # rows: images of e1,e2,e3? use affine map
def to2(P):
    P = np.atleast_2d(P)
    return P @ np.array([[0, 0], [1, 0], [0.5, np.sqrt(3) / 2]])

def T1(eps):
    c0 = (1 - eps) / 3
    return np.array([c0 * np.ones(3) + eps * E[k] for k in range(3)])

def dist_pt_poly(x, V):
    # V: convex polygon vertices (ordered ccw), x point; distance (0 if inside)
    n = len(V)
    inside = True
    best = np.inf
    for k in range(n):
        a, b = V[k], V[(k + 1) % n]
        e = b - a
        cr = e[0] * (x - a)[1] - e[1] * (x - a)[0]
        if cr < 0:
            inside = False
        t = np.clip(np.dot(x - a, e) / np.dot(e, e), 0, 1)
        best = min(best, np.linalg.norm(x - (a + t * e)))
    return 0.0 if inside else best

def hull2(P):
    h = ConvexHull(P)
    return P[h.vertices]

def dH(A, B):
    A, B = hull2(A), hull2(B)
    return max(max(dist_pt_poly(a, B) for a in A), max(dist_pt_poly(b, A) for b in B))

def build(params, Wpts):
    nW = len(Wpts)
    la = params[:3]
    ll = params[3:].reshape(3, nW)
    Ms = []
    for i in range(3):
        pts = [np.exp(la[i]) * E[i]] + [np.exp(ll[i, k]) * Wpts[k] for k in range(nW)]
        Ms.append(np.array(pts))
    return Ms

def Ku(Ms, p=np.ones(3) / 3):
    S = [p[0] * x + p[1] * y + p[2] * z for x in Ms[0] for y in Ms[1] for z in Ms[2]]
    S = np.array(S)
    K = S / S.sum(axis=1, keepdims=True)
    return K

def objective(params, Wpts, tgt2):
    Ms = build(params, Wpts)
    K = Ku(Ms)
    try:
        return dH(to2(K), tgt2)
    except Exception:
        return 1.0

def run(eps, eps_w, nedge, seeds=6, iters=4000):
    W = T1(eps_w)
    pts = list(W)
    for k in range(3):
        a, b = W[k], W[(k + 1) % 3]
        for t in np.linspace(0, 1, nedge + 2)[1:-1]:
            pts.append((1 - t) * a + t * b)
    Wpts = np.array(pts)
    tgt2 = to2(T1(eps))
    rng = np.random.default_rng(0)
    best = (np.inf, None)
    for s in range(seeds):
        x0 = rng.normal(0, 1.0, 3 + 3 * len(Wpts))
        r = minimize(objective, x0, args=(Wpts, tgt2), method="Nelder-Mead",
                     options={"maxiter": iters, "xatol": 1e-6, "fatol": 1e-9})
        r = minimize(objective, r.x, args=(Wpts, tgt2), method="Powell",
                     options={"maxiter": iters})
        if r.fun < best[0]:
            best = (r.fun, r.x)
    return best

if __name__ == "__main__":
    eps = 0.3
    dW = dH(to2(T1(0.3)), to2(T1(0.25)))
    print("d_H(T1(.3),T1(.25)) =", dW)
    for eps_w in [0.29, 0.27, 0.25, 0.2]:
        for nedge in [0, 1, 2]:
            val, x = run(eps, eps_w, nedge, seeds=4, iters=3000)
            margin = dH(to2(T1(eps)), to2(T1(eps_w)))
            print(f"eps_w={eps_w} nedge={nedge}  margin d_H(T1,W)={margin:.4f}  best d_H(K_u,T1)={val:.5f}  ratio={val/margin:.3f}", flush=True)
