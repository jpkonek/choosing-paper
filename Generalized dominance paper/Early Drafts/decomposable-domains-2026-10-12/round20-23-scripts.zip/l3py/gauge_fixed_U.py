"""L3 NUMERICS for Proposition L3.2 (fixed-domain gauge covers converging to T1).

Domain: U-domain M_U with U = D_{K'}, K' = u + s(T1-u) (s = 0 gives U = {sum h > 0}).
Gauges (R10a Thm M): M_i = conv{ a e_i, b u, b v_i }  (v_i the vertices of T1).
Then V_i = nu(M_i) = [e_i, u] (compatible), Av = D_u, and for s>0 we intersect with U
(the Thm M system lives on Av = D_u; the U-domain with K' containing u is a sub-case: see note).
Checks:
 (1) d_H(K_u, T1) as a function of a/b   (K_u = nu(sum_i M_i / 3));
 (2) (G)-signs of f_i(h) = min_{m in M_i} m.h on sampled h in Av;
 (3) Bayes act {sum_i p_i f_i(h) > 0} == D_{K_p}, K_p = nu(sum p_i M_i), at random priors;
 (4) leading / second scale structure: f_i/b -> min(0, v_i.h) and f_i/a -> h_i off the veto.
"""
import numpy as np
from scipy.spatial import ConvexHull
rng = np.random.default_rng(11)
E = np.eye(3); u = np.ones(3) / 3
A2 = np.array([[0, 0], [1, 0], [0.5, np.sqrt(3) / 2]])
def to2(P): return np.atleast_2d(P) @ A2
def T1(eps):
    c0 = (1 - eps) / 3
    return np.array([c0 * np.ones(3) + eps * E[k] for k in range(3)])
DIRS = np.stack([np.cos(t := np.linspace(0, 2 * np.pi, 2000, endpoint=False)), np.sin(t)], 1)
def dH(P, Q):
    return np.abs((to2(P) @ DIRS.T).max(0) - (to2(Q) @ DIRS.T).max(0)).max()
def gauges(eps, a, b):
    V = T1(eps)
    return [np.array([a * E[i], b * u, b * V[i]]) for i in range(3)]
def Kp(Ms, p):
    S = np.array([p[0] * x + p[1] * y + p[2] * z for x in Ms[0] for y in Ms[1] for z in Ms[2]])
    return S / S.sum(1, keepdims=True)
def f(Ms, H):
    return np.stack([(H @ M.T).min(1) for M in Ms], 1)
for eps in [0.05, 0.3, 0.6]:
    print(f"== eps = {eps}")
    for r in [0.3, 0.1, 0.03, 0.01, 0.003, 0.001]:
        Ms = gauges(eps, r, 1.0)
        d = dH(Kp(Ms, u), T1(eps))
        print(f"   a/b = {r:7.4f}   d_H(K_u, T1) = {d:.3e}   d_H/(a/b) = {d / r:.3f}")
    # (2), (3) at a/b = 0.01
    Ms = gauges(eps, 0.01, 1.0)
    H = rng.normal(size=(200000, 3))
    Av = H.sum(1) > 0
    F = f(Ms, H[Av]); Hs = H[Av]
    bad = ((np.sign(F) != np.sign(Hs)) & (np.abs(Hs) > 1e-12)).sum()
    print(f"   (G)-sign violations on {Av.sum()} sampled h in Av: {bad}")
    mism = 0
    for k in range(12):
        p = rng.dirichlet(np.ones(3)) if k < 9 else E[k - 9]
        K = Kp(Ms, p)
        acc_bayes = (F @ p) > 0
        acc_K = (Hs @ K.T).min(1) > 0
        mism += (acc_bayes != acc_K).sum()
    print(f"   Bayes-vs-D_(K_p) mismatches (12 priors): {mism}")
# (4) scale structure at eps = 0.3
eps = 0.3; V = T1(eps)
H = rng.normal(size=(20000, 3)); H = H[H.sum(1) > 0]
for r in [1e-2, 1e-4, 1e-6]:
    Ms = gauges(eps, r, 1.0)
    F = f(Ms, H)
    lead = np.minimum(0, H @ V.T)          # min(0, v_i.h)
    err0 = np.abs(F - lead).max()
    off = (H @ V.T) > 1e-3                 # not vetoed at world i
    err1 = np.abs(F[off] / r - H[off.nonzero()[0], :][np.arange(off.sum()), off.nonzero()[1]]).max()
    print(f"a/b={r:g}: max|f - min(0,v_i.h)| = {err0:.2e} (leading scale b=1);  max|f/a - h_i| off veto (v_i.h>1e-3) = {err1:.2e}")
