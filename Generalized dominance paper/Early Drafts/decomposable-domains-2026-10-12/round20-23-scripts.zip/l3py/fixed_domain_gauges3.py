"""L3 NUMERICS (v3): richer gauges on a fixed domain, fast support-function Hausdorff distance.
Same admissible class as v2 (V_i subset conv(e_i u W), W subset V_i): compatible, fixed (LF) margin.
"""
import numpy as np, sys, time
sys.path.insert(0, '.')
from fastgeo import *
from scipy.optimize import minimize
u = np.ones(3)/3
def base_points(eps_w, i, m, mw):
    W = T1(eps_w)
    pts = [E[i]] + list(W)
    # extra points of W (on its edges)
    for k in range(3):
        for t in np.linspace(0, 1, mw + 2)[1:-1]:
            pts.append((1-t)*W[k] + t*W[(k+1) % 3])
    for t in np.linspace(0.1, 0.9, m):
        pts.append((1-t)*u + t*E[i])
        for k in range(3):
            pts.append((1-t)*W[k] + t*E[i])
    return np.array(pts)
def Ku(Ms):
    S = (Ms[0][:, None, None, :] + Ms[1][None, :, None, :] + Ms[2][None, None, :, :]).reshape(-1, 3)
    return S / S.sum(axis=1, keepdims=True)
def unpack(x, base):
    off = 0; Ms = []
    for b in base:
        n = len(b); Ms.append(np.exp(x[off:off+n])[:, None] * b); off += n
    return Ms
def obj(x, base, tgt2):
    return dH_support(to2(Ku(unpack(x, base))), tgt2)
if __name__ == "__main__":
    eps = 0.3; tgt2 = to2(T1(eps))
    rng = np.random.default_rng(int(sys.argv[1]) if len(sys.argv) > 1 else 0)
    for eps_w in [0.25, 0.2, 0.15]:
        for (m, mw) in [(1, 0), (2, 1), (3, 1)]:
            base = [base_points(eps_w, i, m, mw) for i in range(3)]
            nv = sum(len(b) for b in base)
            best = 1.0; t0 = time.time()
            for s in range(4):
                x0 = rng.normal(0, 1.5, nv)
                r = minimize(obj, x0, args=(base, tgt2), method="L-BFGS-B", options={"maxiter": 3000})
                r = minimize(obj, r.x, args=(base, tgt2), method="Powell", options={"maxiter": 20000, "xtol": 1e-5, "ftol": 1e-9})
                best = min(best, r.fun)
            margin = dH_support(to2(T1(eps)), to2(T1(eps_w)))
            print(f"eps_w={eps_w} m={m} mw={mw} nvars={nv} margin={margin:.4f} best={best:.5f} ratio={best/margin:.3f} ({time.time()-t0:.0f}s)", flush=True)
