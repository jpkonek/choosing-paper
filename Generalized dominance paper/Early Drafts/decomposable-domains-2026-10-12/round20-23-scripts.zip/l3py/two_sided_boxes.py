"""L3 NUMERICS for Proposition L3.1 (two-sided domains: precise vertex models; gauges are boxes).

(1) Geometric core: with x_j := lin(e_i, v_j) n [e_j, e_k] and x_k := lin(e_i, v_k) n [e_j, e_k],
    the triangles conv(e_i, e_j, x_j) and conv(e_i, e_k, x_k) meet only at e_i.
    (These contain conv(wedge_j u e_i) and conv(wedge_k u e_i).)  Checked by LP area / sampling.
(2) Gauge mixtures with V_i = {e_i} are normalised boxes K = nu(p* (.) prod[alpha_i, beta_i]);
    by the rescaling p* -> u we minimise d_H(nu(box), T1) over boxes: the minimum is positive.
"""
import numpy as np
from scipy.optimize import minimize
E = np.eye(3); u = np.ones(3) / 3
A2 = np.array([[0, 0], [1, 0], [0.5, np.sqrt(3) / 2]])
def to2(P): return np.atleast_2d(P) @ A2
def T1(eps):
    c0 = (1 - eps) / 3
    return np.array([c0 * np.ones(3) + eps * E[k] for k in range(3)])
DIRS = np.stack([np.cos(t := np.linspace(0, 2 * np.pi, 1440, endpoint=False)), np.sin(t)], 1)
def dH(P, Q): return np.abs((to2(P) @ DIRS.T).max(0) - (to2(Q) @ DIRS.T).max(0)).max()
def line_hit(a, b, e1, e2):
    # intersection of line through a,b with segment [e1,e2] (barycentric)
    M = np.stack([b - a, -(e2 - e1)], 1)[:2]
    t, s = np.linalg.lstsq(np.stack([b - a, -(e2 - e1)], 1), e1 - a, rcond=None)[0]
    return e1 + s * (e2 - e1), s
rng = np.random.default_rng(2)
for eps in [0.05, 0.3, 0.6, 0.9]:
    V = T1(eps); worst = 0
    for i in range(3):
        j, k = [m for m in range(3) if m != i]
        xj, sj = line_hit(E[i], V[j], E[j], E[k])
        xk, sk = line_hit(E[i], V[k], E[j], E[k])
        # sample points of Delta, test membership in both triangles
        P = rng.dirichlet(np.ones(3), size=200000)
        def in_tri(P, A, B, Cc):
            M = np.stack([A, B, Cc], 1)
            lam = np.linalg.solve(M, P.T).T
            return (lam >= -1e-12).all(1)
        both = in_tri(P, E[i], E[j], xj) & in_tri(P, E[i], E[k], xk)
        worst = max(worst, np.linalg.norm(P[both] - E[i], axis=1).max() if both.any() else 0.0)
        print(f"eps={eps} i={i+1}: x_j param on [e_j,e_k] = {sj:.4f}, x_k param = {sk:.4f};"
              f" sampled points in both triangles: {both.sum()}")
    # (2) best normalised box
    def obj(z):
        al = np.exp(z[:3]); be = al + np.exp(z[3:])
        corners = np.array([[ (be if b else al)[m] for m, b in enumerate(bits)] for bits in
                            [(x, y, w) for x in (0, 1) for y in (0, 1) for w in (0, 1)]])
        K = corners / corners.sum(1, keepdims=True)
        return dH(K, V)
    best = min(minimize(obj, rng.normal(size=6), method="Nelder-Mead",
                        options={"maxiter": 20000, "xatol": 1e-9, "fatol": 1e-12}).fun for _ in range(12))
    print(f"eps={eps}: min over normalised boxes of d_H(nu(box), T1) = {best:.5f}"
          f"   (inradius of T1 = {eps/(2*np.sqrt(3))*np.sqrt(3)/np.sqrt(3):.5f} scale ref)")
