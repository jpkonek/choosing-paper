"""L3 NUMERICS (v2): richer gauges on a FIXED domain.
M_i = conv{ a_i e_i, lifted W-vertices (shared shape), lifted extra points of conv(e_i u W) }.
V_i = nu(M_i) subset conv(e_i u W) and V_i contains W, so the tuple is compatible (R10a (M2))
and Av contains D_W n {h not <= 0}: the (LF) margin at T1(eps) is that of W = T1(eps_w).
Minimise d_H(K_u, T1(eps)), K_u = nu(sum M_i /3). Evidence only.
"""
import numpy as np, sys
sys.path.insert(0, '.')
from fixed_domain_gauges import T1, to2, dH, E
from scipy.optimize import minimize

def extra_points(eps_w, i, m):
    W = T1(eps_w)
    u = np.ones(3)/3
    pts = []
    # points on segments from e_i to W-vertices and to u (all inside conv(e_i u W))
    for t in np.linspace(0.15, 0.85, m):
        pts.append((1-t)*u + t*E[i])
        for k in range(3):
            pts.append((1-t)*W[k] + t*E[i])
    return np.array(pts)

def make(eps_w, m):
    W = T1(eps_w)
    base = [np.vstack([E[i][None, :], W, extra_points(eps_w, i, m)]) for i in range(3)]
    return base

def Ku(Ms):
    S = (Ms[0][:, None, None, :] + Ms[1][None, :, None, :] + Ms[2][None, None, :, :]).reshape(-1, 3) / 3
    return S / S.sum(axis=1, keepdims=True)

def obj(x, base, tgt2):
    off = 0; Ms = []
    for i in range(3):
        n = len(base[i])
        Ms.append(np.exp(x[off:off+n])[:, None] * base[i]); off += n
    K = Ku(Ms)
    try:
        return dH(to2(K), tgt2)
    except Exception:
        return 1.0

if __name__ == "__main__":
    eps = 0.3
    tgt2 = to2(T1(eps))
    rng = np.random.default_rng(1)
    for eps_w in [0.27, 0.25]:
        for m in [1, 2]:
            base = make(eps_w, m)
            nv = sum(len(b) for b in base)
            best = 1.0
            for s in range(3):
                x0 = rng.normal(0, 1, nv)
                r = minimize(obj, x0, args=(base, tgt2), method="Powell", options={"maxiter": 20000, "xtol": 1e-4, "ftol": 1e-7})
                best = min(best, r.fun)
            margin = dH(to2(T1(eps)), to2(T1(eps_w)))
            print(f"eps_w={eps_w} m={m} nvars={nv} margin={margin:.4f} best={best:.5f} ratio={best/margin:.3f}", flush=True)
