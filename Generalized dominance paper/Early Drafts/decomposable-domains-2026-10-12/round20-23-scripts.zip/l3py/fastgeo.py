import numpy as np
from scipy.spatial import ConvexHull
E = np.eye(3)
A2 = np.array([[0, 0], [1, 0], [0.5, np.sqrt(3) / 2]])
def to2(P): return np.atleast_2d(P) @ A2
def T1(eps):
    c0 = (1 - eps) / 3
    return np.array([c0 * np.ones(3) + eps * E[k] for k in range(3)])
def support(P2, dirs):  # P2 (N,2), dirs (D,2)
    return (P2 @ dirs.T).max(axis=0)
DIRS = np.stack([np.cos(np.linspace(0, 2*np.pi, 720, endpoint=False)), np.sin(np.linspace(0, 2*np.pi, 720, endpoint=False))], 1)
def dH_support(P2, Q2):
    # Hausdorff distance of convex hulls = sup over unit dirs of |h_P - h_Q| (approx on 720 dirs)
    return np.abs(support(P2, DIRS) - support(Q2, DIRS)).max()
