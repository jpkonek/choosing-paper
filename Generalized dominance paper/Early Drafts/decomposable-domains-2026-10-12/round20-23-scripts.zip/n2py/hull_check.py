"""N2: sharper coherence test for band-surgered gauge mixtures (evidence only).

For a prior q let B_q be the per-problem Bayes acceptance set (from surgery_check).  Its coherent
hull is D_{Khat}, Khat = {m in Delta : m.h >= 0 for all accepted h}.  If B_q is coherent then
D_{Khat} \\ B_q is null.  We report the Gaussian mass fraction of D_{Khat} \\ B_q (rejected with
margin), on a grid of m and a large sample of h.  Strict systems (theta = 0) give ~0.
"""
import numpy as np
from surgery_check import system, bayes_accept, E, u
rng = np.random.default_rng(5)

def simplex_grid(n):
    pts = [(i, j, n - i - j) for i in range(n + 1) for j in range(n + 1 - i)]
    return np.array(pts, float) / n

MG = simplex_grid(140)

def hull_defect(Ms, q, theta, which, N=60000):
    H = rng.normal(size=(N, 3)); H /= np.linalg.norm(H, axis=1, keepdims=True)
    acc, marg = bayes_accept(Ms, H, q, theta, which)
    A = H[acc]
    # Khat: grid points m with m.h >= -1e-9 for all accepted h (chunked)
    keep = np.ones(len(MG), bool)
    for k in range(0, len(A), 5000):
        keep &= (MG @ A[k:k + 5000].T).min(axis=1) >= -1e-9
    K = MG[keep]
    if len(K) == 0: return None
    inhull = (H @ K.T).min(axis=1) > 0.02          # margin into the hull
    defect = inhull & (~acc) & (marg > 1e-4)
    return defect.mean(), inhull.mean(), len(K)

if __name__ == "__main__":
    for kind in ["hexagon", "9gon"]:
        Ms = system(kind)
        for which in ["E", "S"]:
            for theta in [0.0, 0.05, 0.2]:
                row = []
                for s in [1.0, 0.5, 0.2, 0.05]:
                    q = (1 - s) * E[0] + s * u
                    d = hull_defect(Ms, q, theta, which)
                    row.append("none" if d is None else f"{d[0]:.4f}")
                print(f"{kind:8s} norm {which} theta={theta:4.2f}: defect mass along ray s=1,.5,.2,.05: {row}")
