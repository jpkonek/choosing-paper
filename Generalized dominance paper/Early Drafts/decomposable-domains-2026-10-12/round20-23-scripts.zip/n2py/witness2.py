"""N2: explicit non-convexity witness for Theorem B in a band-surgered gauge mixture (evidence only).
System: R10a Prop M' 9-gon tuple with NSI_theta surgery (theta=0.05, Euclidean), p* = u.  Finds a band-1+
boundary gamble w of B_u, its contact m*, an available non-band x with m*.x < 0, and checks at
q = (1-s)e_1 + s u that x and z (inside, near w) are accepted while y in [z,x] (beyond the facet plane,
band-1+) is rejected, i.e. B_q is not convex.  Contact m* = facet normal from neighbouring boundary gambles."""
import numpy as np
from surgery_check import system, bayes_accept, avail, E, u
theta, which = 0.05, "E"
Ms = system("9gon")
acc = lambda q, H: bayes_accept(Ms, np.atleast_2d(H), q, theta, which)[0]
one = np.ones(3)
b1 = np.array([1, -1, 0]) / np.sqrt(2); b2 = np.array([1, 1, -2]) / np.sqrt(6)
def bdry_all(alphas, q=u):
    G = np.cos(alphas)[:, None] * b1 + np.sin(alphas)[:, None] * b2
    lo = -3.0 * np.ones(len(alphas)); hi = 3.0 * np.ones(len(alphas))
    for _ in range(60):
        mid = (lo + hi) / 2
        a = acc(q, G + mid[:, None] * one)
        hi = np.where(a, mid, hi); lo = np.where(a, lo, mid)
    return G + hi[:, None] * one
alphas = np.linspace(0, 2 * np.pi, 20001)
W = bdry_all(alphas)
phi1 = W[:, 0] / np.linalg.norm(W, axis=1)
idx = np.where((phi1 > 0.5 * theta) & (phi1 < 0.9 * theta))[0]
k = idx[len(idx) // 2]; w = W[k]
n = np.cross(W[k + 3] - W[k - 3], w); n = n / n.sum()
if n @ (w + 0.01 * one) < 0: n = -n
print("w =", w, "phi_1(w) =", w[0] / np.linalg.norm(w), " contact m* =", n, " m*.w =", n @ w)
# facet extent: same contact on a range of alpha?
same = [j for j in range(k - 400, k + 400) if abs(n @ W[j]) < 1e-6]
print("boundary gambles on the same facet (|m*.w|<1e-6):", len(same), " phi_1 range there:",
      phi1[same].min(), phi1[same].max())
# non-band point of the same facet if any (same-contact version of Thm B)
nb = [j for j in same if phi1[j] > theta]
if nb:
    wp = W[nb[len(nb)//2]]; x = wp - 1e-3 * one
    print("same-facet non-band gamble w' found, phi_1 =", wp[0]/np.linalg.norm(wp))
else:
    # level-theta crossing: take the boundary gamble with phi_1 closest above theta and perturb
    j0 = np.where(phi1 > theta)[0]; j0 = j0[np.argmin(np.abs(j0 - k))]
    wp = W[j0]; print("nearest non-band boundary gamble: alpha index", j0, "vs", k, " m*.w' =", n @ wp)
    kappa = (n[0] + 1) / 2; h = E[0] - kappa * one
    best = None
    for d in np.linspace(1e-4, 0.3, 3000):
        x = wp + d * h
        if avail(Ms, np.atleast_2d(x))[0] and x[0] > theta*np.linalg.norm(x) and n @ x < 0: best = x
    x = best
print("x =", x, " phi_1(x) =", x[0]/np.linalg.norm(x), " m*.x =", n @ x, " available:", avail(Ms, np.atleast_2d(x))[0])
for s in [0.5, 0.02, 2e-3, 3e-4, 5e-5]:
    q = (1 - s) * E[0] + s * u
    res = None
    for eta in [1e-4, 1e-5, 1e-6]:
        z = w + eta * n / np.linalg.norm(n)
        if not acc(q, z)[0]: continue
        for lam in np.linspace(1e-5, 0.5, 5000):
            y = (1 - lam) * z + lam * x
            if n @ y < 0 and not acc(q, y)[0]:
                res = (eta, lam, y); break
        if res: break
    ok = acc(q,x)[0] and res is not None and acc(q,res[2]*0+z)[0]
    print(f" s={s}: WITNESS={ok}; x acc {acc(q,x)[0]}, z acc {acc(q,z)[0]};",
          "no witness" if res is None else f"y=[z,x] point lam={res[1]:.2e} beyond plane, rejected at q; |y-w|={np.linalg.norm(res[2]-w):.2e}, phi_1(y)={res[2][0]/np.linalg.norm(res[2]):.4f}")
