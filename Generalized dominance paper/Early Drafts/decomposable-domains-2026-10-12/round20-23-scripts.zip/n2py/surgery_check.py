"""N2: band surgery of R10a gauge mixtures (evidence only).

Start from a strict gauge-mixture system (R10a Thm M): f_i(h) = min_{m in M_i} m.h, Av = U_i D_{V_i}.
NSI_theta surgery: f_i^theta(h) = 0 on mixed h with 0 < h_i <= theta*||h||, f_i otherwise
(this is forced by NSI_theta-(G): good ~ silence there).  Bayes set at q:
    B_q = {h in Av : sum_i q_i f_i^theta(h) > 0}  (three-action menus resolve as in Thm M since
    F_q(h)+F_q(-h) <= 0 still holds off the band? -- we simply compute the per-problem argmin).
We test midpoint convexity of B_q at priors along the ray from delta_1 through p* = u,
and on a random interior grid.  Theorem B/Z of N2 predict failure at priors close to delta_1.
"""
import numpy as np
rng = np.random.default_rng(3)
E = np.eye(3); u = np.ones(3) / 3

def system(kind):
    if kind == "hexagon":
        return [np.vstack([E[i], u]) for i in range(3)]
    if kind == "9gon":   # R10a Prop M' with W = T1(0.29), a/b = 0.01
        W = (1 - .29) / 3 + .29 * E
        return [np.vstack([0.01 * E[i]] + [w for w in W]) for i in range(3)]

def fvals(Ms, H):
    return np.stack([(H @ M.T).min(axis=1) for M in Ms], axis=1)

def avail(Ms, H):
    Vs = [M / M.sum(axis=1, keepdims=True) for M in Ms]
    return np.any(np.stack([(H @ V.T).min(axis=1) > 0 for V in Vs], 1), 1)

def norm(H, which):
    return np.linalg.norm(H, axis=1) if which == "E" else np.abs(H).max(axis=1)

def ftheta(Ms, H, theta, which):
    F = fvals(Ms, H)
    mixed = (H.max(1) > 0) & (H.min(1) < 0)
    band = mixed[:, None] & (H > 0) & (H <= theta * norm(H, which)[:, None])
    F[band] = 0.0
    return F

def bayes_accept(Ms, H, q, theta, which):
    """per-problem argmin over menu {+,0,-} restricted to availability; returns accept-h mask"""
    c = ftheta(Ms, H, theta, which) @ q      # silence minus accept h
    cp = ftheta(Ms, -H, theta, which) @ q    # silence minus accept -h
    aH, aM = avail(Ms, H), avail(Ms, -H)
    c = np.where(aH, c, -np.inf); cp = np.where(aM, cp, -np.inf)
    return (c > 0) & (c > cp), np.minimum(np.abs(c), np.abs(c - cp))

def midpoint_failures(Ms, q, theta, which, N=60000, pairs=60000):
    H = rng.normal(size=(N, 3))
    acc, marg = bayes_accept(Ms, H, q, theta, which)
    A = H[acc & (marg > 1e-6)]
    if len(A) < 10: return 0, 0
    i = rng.integers(len(A), size=pairs); j = rng.integers(len(A), size=pairs)
    Mid = (A[i] / np.linalg.norm(A[i], axis=1, keepdims=True) + A[j] / np.linalg.norm(A[j], axis=1, keepdims=True)) / 2
    accm, margm = bayes_accept(Ms, Mid, q, theta, which)
    bad = (~accm) & (margm > 1e-6)
    return int(bad.sum()), pairs

if __name__ == "__main__":
  for kind in ["hexagon", "9gon"]:
      Ms = system(kind)
      for which in ["E", "S"]:
          for theta in [0.05, 0.2]:
              print(f"{kind}, norm {which}, theta={theta}")
              # strict system sanity (theta = 0): expect 0 failures
              if theta == 0.05:
                  fb, P = midpoint_failures(Ms, u, 0.0, which)
                  print(f"   strict (theta=0) at u: midpoint failures {fb}/{P}")
              for s in [1.0, 0.5, 0.2, 0.05, 0.01]:
                  q = (1 - s) * E[0] + s * u
                  fb, P = midpoint_failures(Ms, q, theta, which)
                  print(f"   q on ray delta1->u, s={s}: midpoint failures {fb}/{P}")
