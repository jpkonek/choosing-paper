"""N2 geometry checks (evidence only).

phi_i(h) = h_i / ||h|| on boundary gambles of D_K.
1. T1 facet F_3: h(s) = (-1+s, b-s, -1), s in (0, b+1).  phi_2 on F_3, both norms:
   value at the edge ray r_31 (s -> 0), max over the facet, location of the max.
2. Cap thresholds theta_cap(K) = largest theta with K disjoint from every cap_theta(i):
   Euclidean cap_theta(i) = {m in Delta : angle(m, e_i) <= arcsin theta}
   sup-norm  cap_theta(i) = {m in Delta : m_i >= 1/(1+theta)}.
3. Edge-ray sign patterns of random interior triangles: fraction with a single-positive edge ray
   (Theorem C applies for every theta) vs all edge rays two-positive.
"""
import numpy as np

rng = np.random.default_rng(1)

def t1_facet(eps, N=200001):
    b = (2 + eps) / (1 - eps)
    s = np.linspace(1e-9, b + 1 - 1e-9, N)
    H = np.stack([-1 + s, b - s, -np.ones_like(s)], axis=1)
    phiE = H[:, 1] / np.linalg.norm(H, axis=1)
    phiS = H[:, 1] / np.abs(H).max(axis=1)
    v3 = (1 - eps) / 3 + eps * np.array([0, 0, 1.0])
    assert np.abs(H @ v3).max() < 1e-9
    return b, s, phiE, phiS

print("1. T1, facet F_3, coordinate 2")
for eps in [0.05, 0.1, 0.3, 0.5, 0.9]:
    b, s, pE, pS = t1_facet(eps)
    k = pE.argmax()
    print(f" eps={eps}: b={b:.4f}; Euclid phi2(r31)={pE[0]:.4f}, max={pE.max():.4f} at s={s[k]:.4f} (interior: {s[k]>1e-6});"
          f" sup phi2 near r31={pS[0]:.4f}; min phi2={pE.min():.3f} (crossing)")

print("\n2. cap thresholds")
def theta_cap(V):
    # V: vertices of polytope K (rows).  Euclid: min over i of sin(min angle(K,e_i)).
    # min angle to e_i over a polytope: sample the polytope densely (evidence only)
    w = rng.dirichlet(np.ones(len(V)), 200000)
    P = w @ V
    P = np.vstack([P, V])
    ang = np.arccos(np.clip(P / np.linalg.norm(P, axis=1, keepdims=True), -1, 1))
    tE = min(np.sin(ang[:, i].min()) for i in range(3))
    tS = min(1 / V[:, i].max() - 1 for i in range(3))
    return tE, tS
for eps in [0.05, 0.3, 0.6, 0.9]:
    V = (1 - eps) / 3 + eps * np.eye(3)
    tE, tS = theta_cap(V)
    print(f" T1 eps={eps}: theta_cap Euclid={tE:.4f}, sup={tS:.4f}  (sup formula 2(1-eps)/(1+2eps)={2*(1-eps)/(1+2*eps):.4f})")

print("\n3. edge-ray patterns of random interior triangles")
def edge_rays(V):
    rays = []
    for (k, j, l) in [(0, 1, 2), (1, 2, 0), (2, 0, 1)]:
        r = np.cross(V[k], V[j])
        if r @ V[l] < 0: r = -r
        rays.append(r)
    return rays
cnt = {"single": 0, "allTwo": 0}
for _ in range(20000):
    V = rng.dirichlet(np.ones(3) * 3, 3)
    pats = [int((r > 0).sum()) for r in edge_rays(V)]
    if min(pats) == 1: cnt["single"] += 1
    else: cnt["allTwo"] += 1
print(" ", cnt)
# symmetric inverted triangle: vertices u - eps(e_k - u)/2
for eps in [0.1, 0.3, 0.6, 0.9]:
    V = np.array([np.ones(3)/3 - eps*(np.eye(3)[k]-np.ones(3)/3)/2 for k in range(3)])
    rays = edge_rays(V)
    r = rays[0]; r = r/np.linalg.norm(r)
    pos = np.where(r > 0)[0]
    th = r[pos[0]]
    # vertex v of K at the facet where pos[0] crosses: test cap membership
    tE, tS = theta_cap(V)
    print(f" inverted eps={eps}: pattern {np.sign(r)}, theta_inv(Euclid)={th:.4f}, theta_cap Euclid={tE:.4f} -> Thm Z excludes theta_inv: {th < tE}")
