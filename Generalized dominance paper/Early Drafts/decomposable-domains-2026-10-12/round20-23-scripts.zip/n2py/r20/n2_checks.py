"""N2 (round 20) NUMERICS. No proof depends on these checks. Run: python3 -I n2_checks.py (from inside n2py/r20/).
(A) Threshold lemma (core of Thm N2.1): on a finite cell model of an atomless edge region R
    (cell n has CA masses a_n = rho_i(cell), b_n = rho_j(cell), homogeneous ratio inside the cell,
    fractional membership x_n in c), weak Pareto  <=>  some theta in [0,1] has
    theta*a_n - (1-theta)*b_n <= 0 on cells meeting c and >= 0 on cells meeting R\\c.
    Weak Pareto is tested by the LP  max s  s.t.  sum a(p-q) >= s, sum b(q-p) >= s, 0<=p<=x, 0<=q<=1-x.
(B) The T1-shadow on the edge (1,2): the blind-set model X_12 (world-1 errors = Lambda_1 ∩ R_12) equals
    Y_3 = T1 on R_12, P_1 on Q_3, and is incoherent (midpoint-convexity witnesses); T1 baseline.
    (Thm N2.4 shows X_12 would be selected, hence coherent, in any cover with this blind pattern.)
"""
import os, sys
here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, here)
import numpy as np
from scipy.optimize import linprog

rng = np.random.default_rng(16102026)

# ---------------- (A) ----------------
def weak_pareto_margin(a, b, x):
    n = len(a)
    # variables p (n), q (n), s ; maximise s
    c = np.zeros(2 * n + 1); c[-1] = -1.0
    A = np.zeros((2, 2 * n + 1)); bu = np.zeros(2)
    # s - sum a p + sum a q <= 0
    A[0, :n] = -a; A[0, n:2 * n] = a; A[0, -1] = 1.0
    # s - sum b q + sum b p <= 0
    A[1, :n] = b; A[1, n:2 * n] = -b; A[1, -1] = 1.0
    bounds = [(0, xi) for xi in x] + [(0, 1 - xi) for xi in x] + [(None, 1.0)]
    r = linprog(c, A_ub=A, b_ub=bu, bounds=bounds, method='highs')
    return -r.fun

def has_threshold(a, b, x, tol=1e-12):
    # candidate thetas: all breakpoints theta_n = b_n/(a_n+b_n) plus 0, 1
    cands = [0.0, 1.0] + [bn / (an + bn) for an, bn in zip(a, b) if an + bn > 0]
    for th in cands:
        e = th * a - (1 - th) * b
        if np.all(e[x > tol] <= 1e-12) and np.all(e[x < 1 - tol] >= -1e-12):
            return True
    return False

agree = 0; disagree = 0; npar = 0; nthr = 0
for trial in range(4000):
    n = rng.integers(3, 12)
    a = rng.exponential(size=n); b = rng.exponential(size=n)
    # blind cells (CA-null at i or at j or both)
    z = rng.random(n)
    a[z < 0.15] = 0.0
    b[(z >= 0.15) & (z < 0.3)] = 0.0
    both = (z >= 0.3) & (z < 0.35); a[both] = 0.0; b[both] = 0.0
    mode = trial % 3
    if mode == 0:            # random set
        x = rng.choice([0.0, 1.0, 0.5], size=n, p=[0.4, 0.4, 0.2])
    else:                    # a threshold set at a random theta, with random tie splits
        th = rng.choice([0.0, 1.0, rng.random()]) if mode == 1 else rng.random()
        e = th * a - (1 - th) * b
        x = np.where(e < 0, 1.0, np.where(e > 0, 0.0, rng.random(n)))
        if mode == 2:        # perturb one cell to break the threshold sometimes
            k = rng.integers(n); x[k] = 1 - x[k]
    m = weak_pareto_margin(a, b, x)
    wp = m <= 1e-9
    th = has_threshold(a, b, x)
    npar += wp; nthr += th
    if wp == th: agree += 1
    else: disagree += 1
print("(A) threshold lemma on random cell models: instances = 4000, weakly Pareto =", npar,
      ", threshold sets =", nthr, ", agreements =", agree, ", disagreements =", disagree)

# ---------------- (B) ----------------
from n2_geo import Geo, midpoint_violations
for eps, s in [(0.1, 0.9), (0.3, 0.9), (0.6, 0.5)]:
    geo = Geo(eps, s)
    G = geo.sample_mixed_U(rng, 200000)
    acc = geo.T1(G)
    cor = geo.correct(G, acc)
    sg = np.sign(G)
    R12 = sg[:, 0] != sg[:, 1]
    lam1 = ~cor[:, 0]                       # shadow blind set of world 1 = E_1(T1)
    # X_12: world-1 errors = Lambda_1 on R_12 ; P_1 on Q_3
    def X12(g):
        a_ = geo.T1(g); sgg = np.sign(g)
        r = sgg[:, 0] != sgg[:, 1]
        return np.where(r, a_, g[:, 0] > 0)
    x12 = X12(G)
    errs1 = (x12 != (G[:, 0] > 0))
    same = np.all(errs1[R12] == lam1[R12]) and np.all(~errs1[~R12])
    bad, tot = midpoint_violations(X12, G, geo, rng, trials=60000)
    badT, totT = midpoint_violations(geo.T1, G, geo, rng, trials=60000)
    print(f"(B) eps={eps}, s={s}: E_1(X_12) = Lambda_1 on R_12 and empty on Q_3: {same};"
          f" midpoint violations X_12: {bad}/{tot}; T1 baseline: {badT}/{totT}")
