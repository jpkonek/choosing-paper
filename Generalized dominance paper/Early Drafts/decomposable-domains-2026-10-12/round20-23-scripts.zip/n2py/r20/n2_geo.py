"""Copy of m1py/m1_common.py (M1 geometry), used by n2_checks.py so that nothing is imported from m1py.
(NUMERICS only; no proof depends on it.)
T1 = eps-contamination of u; U = D_{K'}, K' = u + s(T1 - u).  Run with python3 -I from inside m1py/."""
import numpy as np


class Geo:
    def __init__(self, eps, s):
        self.eps, self.s = eps, s
        self.c0 = (1 - eps) / 3
        self.u = np.ones(3) / 3
        self.V = np.array([self.c0 * np.ones(3) + eps * np.eye(3)[k] for k in range(3)])
        self.Vp = np.array([self.u + s * (self.V[k] - self.u) for k in range(3)])
        self.kappa = (1 + 2 * eps) / (1 - eps)

    def PK(self, g, K):
        return np.min(g @ np.asarray(K).T, axis=-1)

    def inD(self, g, K):
        return self.PK(g, K) > 0

    def inU(self, g):
        return self.inD(g, self.Vp)

    def T1(self, g):
        return self.inD(g, self.V)

    def sample_mixed_U(self, rng, n):
        out, m = [], 0
        while m < n:
            g = rng.normal(size=(4 * n, 3))
            k = rng.integers(0, 3, size=len(g))
            lam = np.exp(rng.uniform(0, 3, size=len(g)))
            g[np.arange(len(g)), k] *= lam
            g /= np.linalg.norm(g, axis=1, keepdims=True)
            sg = np.sign(g)
            keep = self.inU(g) & (sg.max(axis=1) > 0) & (sg.min(axis=1) < 0)
            out.append(g[keep])
            m += keep.sum()
        return np.concatenate(out)[:n]

    def correct(self, g, acc):
        """correct[:,k]: model with acceptance acc is correct at world k on g"""
        return (g > 0) == acc[:, None]

    def oddworld(self, g):
        """index l of the odd world (sign differing from the other two) of a mixed g"""
        sg = np.sign(g)
        tot = sg.sum(axis=1)          # +1 if two plus one minus, -1 if two minus one plus
        odd = np.where(tot > 0, np.argmin(sg, axis=1), np.argmax(sg, axis=1))
        return odd


def midpoint_violations(acc_fn, G, geo, rng, trials=40000):
    A = G[acc_fn(G)]
    if len(A) < 2:
        return 0, 0
    i = rng.integers(0, len(A), size=trials)
    j = rng.integers(0, len(A), size=trials)
    S = A[i] + A[j]
    sg = np.sign(S)
    keep = geo.inU(S) & (sg.max(axis=1) > 0) & (sg.min(axis=1) < 0)
    S = S[keep]
    S /= np.linalg.norm(S, axis=1, keepdims=True)
    bad = ~acc_fn(S)
    return int(bad.sum()), int(keep.sum())


def rand_simplex(rng, n):
    x = rng.exponential(size=(n, 3))
    return x / x.sum(axis=1, keepdims=True)
