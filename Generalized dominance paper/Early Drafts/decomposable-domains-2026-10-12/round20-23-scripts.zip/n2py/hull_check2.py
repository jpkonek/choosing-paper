"""N2: hull defect for the surgered 9-gon system at priors very close to delta_1 (evidence only)."""
import numpy as np
from surgery_check import system, E, u
from hull_check import hull_defect
Ms = system("9gon")
for which in ["E", "S"]:
    for theta in [0.0, 0.05, 0.2]:
        row = []
        for s in [0.02, 0.005, 0.002, 0.0005]:
            q = (1 - s) * E[0] + s * u
            d = hull_defect(Ms, q, theta, which, N=80000)
            row.append("none" if d is None else f"{d[0]:.4f}")
        print(f"9gon norm {which} theta={theta:4.2f}: defect mass, s=.02,.005,.002,.0005: {row}")
