"""L1 NUMERICS: the facet-data algebra of the T1 chain (write-up S4.3-4.6, Prop. boxbridge, Prop. T1)
with R*-arcs: facet arcs whose chord is pinned to the vertex chord R* = line(e1, p*), p* = u
(after the rescaling of Prop. reduction(d)).  An R*-arc ending at tau = a in a rotating piece turns
the coordinate-1 row of that piece into a "virtual crossing" at h(a) (L1_notes S3.4).

Facet maps (normalised as in Prop. T1):
  F1: c = (-(x1 h2 + h3), x1 h2, h3)                      [pinned crossings of coords 2, 3]
  F2: c1 = (kappa+2)(tau - b2), c3 = x2 h3, c2 = -c1 - c3   [virtual coord-1 crossing at b2; b2 = tau_1 strict]
  F3: c = (x3 h1, h2, -(x3 h1 + h2))                       [strict]
Configurations:
  STRICT : b2 = tau_1 and all three corner equations.
  V      : corner r12 inside an R*-arc (F1 on [0,a1), F2 on [0,b2)); virtual crossing on F1 at a1
           forces x1 = h3/|h2| at h(a1); corner equations at r23 and r31 only.
Boxes: every pair (A, B) of facet gambles (rotating pieces; R*-arcs carry c = (0,-1,1)) and every
edge [e_a, e_b]: A_a<0<A_b, B_b<0<B_a, A_b B_a < |A_a||B_b|  =>  not (c(A).q0 > 0 and c(B).q0 > 0)
for q0 in the open edge.  Reports the worst violation.  No proof depends on this script.
Run:  python3 -I facet_algebra.py
"""
import numpy as np

def setup(eps):
    k = (1 + 2 * eps) / (1 - eps)
    r12 = np.array([-1, -1, k + 1.]); r23 = np.array([k + 1, -1, -1.]); r31 = np.array([-1, k + 1, -1.])
    return k, {1: (r12, r31), 2: (r12, r23), 3: (r23, r31)}

def facet_points(ends, f, ts):
    r, rp = ends[f]
    return (1 - ts)[:, None] * r + ts[:, None] * rp

def maps(eps, x1, x2, x3, b2):
    k, ends = setup(eps)
    def c1(H): return np.stack([-(x1 * H[:, 1] + H[:, 2]), x1 * H[:, 1], H[:, 2]], 1)
    def c3(H): return np.stack([x3 * H[:, 0], H[:, 1], -(x3 * H[:, 0] + H[:, 1])], 1)
    def c2(ts, H):
        a = (k + 2) * (ts - b2); cc = x2 * H[:, 2]
        return np.stack([a, -a - cc, cc], 1)
    return k, ends, c1, c2, c3

def box_violation(H, C, nq=200):
    """max over admissible pairs and q0 of min(c(A).q0, c(B).q0) (normalised); > 0 means violated."""
    C = C / np.linalg.norm(C, axis=1, keepdims=True)
    worst, arg = -np.inf, None
    s = np.linspace(0, 1, nq)[1:-1]
    for a in range(3):
        for b in range(3):
            if a == b:
                continue
            IA = np.where((H[:, a] < 0) & (H[:, b] > 0))[0]
            IB = np.where((H[:, b] < 0) & (H[:, a] > 0))[0]
            if len(IA) == 0 or len(IB) == 0:
                continue
            Q = np.zeros((len(s), 3)); Q[:, a] = 1 - s; Q[:, b] = s
            VA = C[IA] @ Q.T                 # |IA| x nq
            VB = C[IB] @ Q.T
            ok = (H[IA, b][:, None] * H[IB, a][None, :]) < (np.abs(H[IA, a])[:, None] * np.abs(H[IB, b])[None, :])
            # for each pair the best q0
            for i in range(len(IA)):
                m = np.minimum(VA[i][None, :], VB).max(axis=1)
                m = np.where(ok[i], m, -np.inf)
                j = np.argmax(m)
                if m[j] > worst:
                    worst, arg = m[j], (a + 1, b + 1, H[IA[i]], H[IB[j]])
    return worst, arg

def system(eps, x1, x2, x3, b2, a1=0.0, n=120):
    k, ends, c1, c2, c3 = maps(eps, x1, x2, x3, b2)
    Hs, Cs = [], []
    t = np.linspace(a1, 1, n)[1:-1]; H = facet_points(ends, 1, t); Hs.append(H); Cs.append(c1(H))
    t = np.linspace(b2, 1, n)[1:-1]; H = facet_points(ends, 2, t); Hs.append(H); Cs.append(c2(t, H))
    t = np.linspace(0, 1, n)[1:-1]; H = facet_points(ends, 3, t); Hs.append(H); Cs.append(c3(H))
    # R*-arcs
    for f, lo, hi in ((1, 0, a1), (2, 0, b2)):
        if hi > 0:
            t = np.linspace(lo, hi, max(3, int(n * (hi - lo))))[1:-1]
            H = facet_points(ends, f, t); Hs.append(H); Cs.append(np.tile([0., -1., 1.], (len(H), 1)))
    H = np.concatenate(Hs); C = np.concatenate(Cs)
    return box_violation(H, C)

def signs_ok(eps, x1, x2, x3, b2, a1=0.0, n=200):
    k, ends, c1, c2, c3 = maps(eps, x1, x2, x3, b2)
    bad = 0
    for f, lo, cf in ((1, a1, None), (2, b2, None), (3, 0, None)):
        t = np.linspace(lo, 1, n)[1:-1]; H = facet_points(ends, f, t)
        C = c1(H) if f == 1 else (c2(t, H) if f == 2 else c3(H))
        S = np.sign(H) * C
        S[np.abs(H) < 1e-9] = 1
        bad += int((S <= 0).sum())
    return bad

if __name__ == '__main__':
    for eps in (0.1, 0.3, 0.6):
        k, ends = setup(eps)
        tau1 = 1 / (k + 2)
        print(f'=== eps {eps}  kappa {k:.4f}  tau1(F2) {tau1:.4f}')
        # STRICT: x1 = x2 = x3 = x+ (corner equations), check box
        xp = ((k + 1) + np.sqrt((k + 1) ** 2 - 4)) / 2
        for x in (xp, 1 / xp):
            w, arg = system(eps, x, x, x, tau1)
            print(f' STRICT x={x:.4f}: sign failures {signs_ok(eps, x, x, x, tau1)}, worst box {w:.4f} at edge {arg[:2]}')
        # V: scan a1 in (0, tau2(F1)), b2 in [tau1, tau3(F2))
        r12, r31 = ends[1]
        tau2F1 = 1 / (k + 2)                  # h2 = 0 on F1 at tau = 1/(k+2)
        tau3F2 = (k + 1) / (k + 2)
        best = (np.inf, None)
        for a1 in np.linspace(1e-3, tau2F1 - 1e-3, 25):
            hA = (1 - a1) * r12 + a1 * r31
            x1 = hA[2] / (-hA[1])
            x3 = k + 1 - 1 / x1
            for b2 in np.linspace(tau1, tau3F2 - 1e-3, 25):
                x2 = (k + 2) * (1 - b2) * (1 - 1 / (x3 * (k + 1)))
                if min(x1, x2, x3) <= 0:
                    continue
                w, arg = system(eps, x1, x2, x3, b2, a1=a1, n=80)
                sb = signs_ok(eps, x1, x2, x3, b2, a1=a1)
                if sb == 0 and w < best[0]:
                    best = (w, (a1, b2, x1, x2, x3, arg[:2]))
        print(' V best worst-box', best)
