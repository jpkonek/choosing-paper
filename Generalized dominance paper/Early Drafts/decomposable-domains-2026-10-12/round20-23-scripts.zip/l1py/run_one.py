"""run one configuration of facet_configs with more starts; usage: python3 -I run_one.py eps F1 F2 F3 starts seed"""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.argv = [sys.argv[0], sys.argv[1]] + sys.argv[2:]
import facet_configs as fc
F1, F2, F3, starts, seed = sys.argv[2], sys.argv[3], sys.argv[4], int(sys.argv[5]), int(sys.argv[6])
cfg = dict(F1=F1, F2=F2, F3=F3)
r, (tot, pen, worst) = fc.run(cfg, starts=starts, seed=seed)
print(cfg, 'eps', fc.EPS, f'penalty {tot:.3e}', pen, f'worst {worst:.5f}')
np.save(f'best_{F1}_{F2}_{F3}_{fc.EPS}_{seed}.npy', r.x)
print('x', list(r.x))
