"""L1 NUMERICS: corner + box algebra of the T1 chain for every admissible placement of R*-arcs
(facet arcs with chord pinned to R* = line(e1, u); L1_notes S3.4 lists the placements):
  F1: an arc inside a corner portion, possibly ending at the corner ray (r12 side or r31 side);
  F2: an arc J = (a, b) containing the coordinate-1 crossing w12 (a = 0 allowed);
  F3: an arc J' = (a', b') containing w13 (b' = 1 allowed).
Rotating pieces carry affine chart fields with strict signs at worlds 2, 3 (and 1 away from the
arc ends), pinned rows at their true crossings, a vanishing coordinate-1 row at an arc end
("virtual crossing"), corner equations where two rotating pieces meet, and all boxes.
Penalty 0 = consistent necessary algebra.  NUMERICS only.
Run:  python3 -I facet_configs.py
"""
import itertools, sys
import numpy as np
from scipy.optimize import minimize

EPS = float(sys.argv[1]) if len(sys.argv) > 1 else 0.3
K = (1 + 2 * EPS) / (1 - EPS)
R12 = np.array([-1, -1, K + 1.]); R23 = np.array([K + 1, -1, -1.]); R31 = np.array([-1, K + 1, -1.])
ENDS = {1: (R12, R31), 2: (R12, R23), 3: (R23, R31)}
def hpt(f, t):
    r, rp = ENDS[f]; t = np.atleast_1d(t)
    return (1 - t)[:, None] * r + t[:, None] * rp
def cross(f, l):
    r, rp = ENDS[f]; return r[l] / (r[l] - rp[l])
NAMES = {}

def zs(a, b):            # zero-sum vector from two coords (c1, c2)
    return np.array([a, b, -a - b])

class Piece:
    """affine chart field on [t0, t1] of facet f: C(t) = C0 + (t - t0)/(t1 - t0) (C1 - C0)."""
    def __init__(self, f, t0, t1, C0, C1):
        self.f, self.t0, self.t1, self.C0, self.C1 = f, t0, t1, np.asarray(C0, float), np.asarray(C1, float)
    def c(self, t):
        w = (np.atleast_1d(t) - self.t0) / (self.t1 - self.t0)
        return (1 - w)[:, None] * self.C0 + w[:, None] * self.C1

def pinned_piece(f, t0, t1, rows):
    """rows: dict l -> lam (c_l = lam * h_l, 0-based l); exactly two given, third by zero sum."""
    H = hpt(f, np.array([t0, t1]))
    C = np.zeros((2, 3)); miss = [l for l in range(3) if l not in rows][0]
    for l, lam in rows.items():
        C[:, l] = lam * H[:, l]
    C[:, miss] = -C.sum(axis=1)
    return Piece(f, t0, t1, C[0], C[1])

def virt_piece(f, t0, t1, vend, other_row, mu):
    """coordinate-1 row affine, vanishing at vend (t0 or t1), slope sign so that it has the sign of h1
    on the open piece; other_row = (l, lam): pinned row c_l = lam h_l."""
    H = hpt(f, np.array([t0, t1]))
    C = np.zeros((2, 3))
    s1 = np.sign(H[1 if vend == t0 else 0, 0])         # sign of h1 at the far end
    C[:, 0] = [0, s1 * mu] if vend == t0 else [s1 * mu, 0]
    l, lam = other_row
    C[:, l] = lam * H[:, l]
    m = 3 - l          # remaining index among {1, 2} (0-based) -> zero sum
    C[:, m] = -C[:, 0] - C[:, l]
    return Piece(f, t0, t1, C[0], C[1])

def free_piece(f, t0, t1, C0, C1):
    return Piece(f, t0, t1, C0, C1)

# ---------------------------------------------------------------- penalties
def sign_pen(p, n=30, margin=1e-3):
    t = np.linspace(p.t0, p.t1, n)[1:-1]; H = hpt(p.f, t); C = p.c(t)
    S = np.sign(H) * C / np.linalg.norm(C, axis=1, keepdims=True)
    return float(np.sum(np.maximum(0, margin - S) ** 2))

def corner_pen(pa, ta, pb, tb):
    a = pa.c(ta)[0]; b = pb.c(tb)[0]
    na, nb = np.linalg.norm(a), np.linalg.norm(b)
    if na < 1e-9 or nb < 1e-9:
        return 10.
    return float(np.sum((a / na - b / nb) ** 2))

def box_pen(H, C, nq=40, detail=False):
    C = C / np.linalg.norm(C, axis=1, keepdims=True)
    s = np.linspace(0, 1, nq)[1:-1]
    tot, worst = 0., -np.inf
    for a, b in itertools.permutations(range(3), 2):
        IA = np.where((H[:, a] < 0) & (H[:, b] > 0))[0]; IB = np.where((H[:, b] < 0) & (H[:, a] > 0))[0]
        if len(IA) == 0 or len(IB) == 0:
            continue
        Q = np.zeros((len(s), 3)); Q[:, a] = 1 - s; Q[:, b] = s
        VA = C[IA] @ Q.T; VB = C[IB] @ Q.T
        M = np.minimum(VA[:, None, :], VB[None, :, :]).max(axis=2)
        ok = (H[IA, b][:, None] * H[IB, a][None, :]) < (np.abs(H[IA, a])[:, None] * np.abs(H[IB, b])[None, :])
        M = np.where(ok, M, -np.inf)
        worst = max(worst, M.max())
        tot += float(np.sum(np.maximum(0, M[ok]) ** 2))
    return (tot, worst) if detail else tot

# ---------------------------------------------------------------- configurations
T2F1, T3F1 = cross(1, 1), cross(1, 2)          # F1 crossings of coords 2, 3
T1F2, T3F2 = cross(2, 0), cross(2, 2)
T2F3, T1F3 = cross(3, 1), cross(3, 0)

def build(cfg, x):
    """cfg: dict with keys F1 in {'strict','r12end','r31end'}, F2 in {'strict','J0','J'}, F3 in {'strict','J1','J'}.
    returns list of rotating pieces, list of R*-arc point arrays (with orientation), corner pieces."""
    it = iter(x)
    def nxt(lo=None):
        v = next(it); return v
    pieces, arcs, corner = [], [], {}
    sig = lambda v: 1 / (1 + np.exp(-v))
    pos = lambda v: np.exp(v)
    # F1
    if cfg['F1'] == 'strict':
        x1 = pos(nxt()); p = pinned_piece(1, 0, 1, {1: x1, 2: 1.}); pieces.append(p); corner['r12_1'] = (p, 0); corner['r31_1'] = (p, 1)
    elif cfg['F1'] == 'r12end':
        a1 = T2F1 * sig(nxt()); hA = hpt(1, a1)[0]; x1 = hA[2] / -hA[1]
        p = pinned_piece(1, a1, 1, {1: x1, 2: 1.}); pieces.append(p); corner['r31_1'] = (p, 1)
        arcs.append((1, 0, a1, np.array([0, -1, 1.])))
    elif cfg['F1'] == 'r31end':
        b1 = T3F1 + (1 - T3F1) * sig(nxt()); hB = hpt(1, b1)[0]; x1 = -hB[2] / hB[1]   # c3 = h3 ; c2 = x1 h2 ; c1 = 0 at b1
        # c1 = -(x1 h2 + h3) = 0  ->  x1 = -h3/h2
        p = pinned_piece(1, 0, b1, {1: x1, 2: 1.}); pieces.append(p); corner['r12_1'] = (p, 0)
        arcs.append((1, b1, 1, np.array([0, 1, -1.])))
    # F2
    if cfg['F2'] == 'strict':
        x2 = pos(nxt()); p = pinned_piece(2, 0, 1, {0: 1., 2: x2}); pieces.append(p); corner['r12_2'] = (p, 0); corner['r23_2'] = (p, 1)
    else:
        b = T1F2 + (T3F2 - T1F2) * sig(nxt()); x2 = pos(nxt())
        p = virt_piece(2, b, 1, b, (2, x2), K + 2); pieces.append(p); corner['r23_2'] = (p, 1)
        if cfg['F2'] == 'J0':
            arcs.append((2, 0, b, np.array([0, -1, 1.])))
        else:
            a = T1F2 * sig(nxt())
            C0 = zs(-pos(nxt()), -pos(nxt()))          # (c1<0, c2<0, c3>0 required by sign pen)
            g = pos(nxt())
            q = free_piece(2, 0, a, C0, np.array([0, -g, g])); pieces.append(q); corner['r12_2'] = (q, 0)
            arcs.append((2, a, b, np.array([0, -1, 1.])))
    # F3
    if cfg['F3'] == 'strict':
        x3 = pos(nxt()); p = pinned_piece(3, 0, 1, {0: x3, 1: 1.}); pieces.append(p); corner['r23_3'] = (p, 0); corner['r31_3'] = (p, 1)
    else:
        ap = T2F3 + (T1F3 - T2F3) * sig(nxt()); x3 = pos(nxt())
        p = virt_piece(3, 0, ap, ap, (1, 1.), x3); pieces.append(p); corner['r23_3'] = (p, 0)
        if cfg['F3'] == 'J1':
            arcs.append((3, ap, 1, np.array([0, 1, -1.])))
        else:
            bp = T1F3 + (1 - T1F3) * sig(nxt())
            C1 = np.array([-pos(nxt()), pos(nxt()), 0.]); C1[2] = -C1[0] - C1[1]
            g = pos(nxt())
            q = free_piece(3, bp, 1, np.array([0, g, -g]), C1); pieces.append(q); corner['r31_3'] = (q, 1)
            arcs.append((3, ap, bp, np.array([0, 1, -1.])))
    return pieces, arcs, corner

NPAR = {('F1', 'strict'): 1, ('F1', 'r12end'): 1, ('F1', 'r31end'): 1,
        ('F2', 'strict'): 1, ('F2', 'J0'): 2, ('F2', 'J'): 6,
        ('F3', 'strict'): 1, ('F3', 'J1'): 2, ('F3', 'J'): 6}

def total(cfg, x, n=40, detail=False):
    pieces, arcs, corner = build(cfg, x)
    pen = {'sign': 0., 'corner': 0., 'box': 0.}
    for p in pieces:
        pen['sign'] += sign_pen(p)
    for r in ('r12', 'r23', 'r31'):
        ks = [k for k in corner if k.startswith(r)]
        if len(ks) == 2:
            (pa, ta), (pb, tb) = corner[ks[0]], corner[ks[1]]
            pen['corner'] += corner_pen(pa, ta, pb, tb)
    Hs, Cs = [], []
    for p in pieces:
        t = np.linspace(p.t0, p.t1, n)[1:-1]; Hs.append(hpt(p.f, t)); Cs.append(p.c(t))
    for f, lo, hi, cv in arcs:
        t = np.linspace(lo, hi, max(4, int(n * (hi - lo) * 2)))[1:-1]
        Hs.append(hpt(f, t)); Cs.append(np.tile(cv, (len(t), 1)))
    H = np.concatenate(Hs); C = np.concatenate(Cs)
    bp, worst = box_pen(H, C, detail=True)
    pen['box'] = bp
    tot = 100 * pen['sign'] + 10 * pen['corner'] + pen['box']
    if detail:
        return tot, pen, worst
    return tot

def run(cfg, starts=40, seed=1):
    npar = sum(NPAR[(k, v)] for k, v in cfg.items())
    rng = np.random.default_rng(seed)
    best = None
    for _ in range(starts):
        x0 = rng.normal(scale=1.0, size=npar)
        r = minimize(lambda x: total(cfg, x, n=25), x0, method='Nelder-Mead',
                     options={'maxiter': 400 * npar, 'xatol': 1e-8, 'fatol': 1e-12})
        if best is None or r.fun < best.fun:
            best = r
    r = minimize(lambda x: total(cfg, x, n=40), best.x, method='Nelder-Mead', options={'maxiter': 2000 * npar})
    return r, total(cfg, r.x, n=60, detail=True)

if __name__ == '__main__':
    print(f'eps {EPS}  kappa {K:.4f}')
    cfgs = [dict(F1=a, F2=b, F3=c) for a in ('strict', 'r12end', 'r31end')
            for b in ('strict', 'J0', 'J') for c in ('strict', 'J1', 'J')]
    def consistent(c):
        # an arc containing a corner ray lies on both facets through it
        if (c['F1'] == 'r12end') != (c['F2'] == 'J0'):
            return False
        if (c['F1'] == 'r31end') != (c['F3'] == 'J1'):
            return False
        return True
    for cfg in [c for c in cfgs if consistent(c)]:
        r, (tot, pen, worst) = run(cfg)
        print(cfg, f'penalty {tot:.3e}', {k: f'{v:.2e}' for k, v in pen.items()}, f'worst box {worst:.4f}', flush=True)
