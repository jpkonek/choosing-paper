"""verify the consistent corner+box solution found for configuration F1 strict, F2 strict, F3 R*-arc
around w13; fine grids; decode parameters.  NUMERICS."""
import sys, os, glob, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.argv = [sys.argv[0], '0.3']
import facet_configs as fc
cfg = dict(F1='strict', F2='strict', F3='J')
x = np.load(sorted(glob.glob('best_strict_strict_J_0.3_*.npy'))[0])
pieces, arcs, corner = fc.build(cfg, x)
for p in pieces:
    print('piece F%d [%.4f, %.4f]  C(t0)=%s  C(t1)=%s' % (p.f, p.t0, p.t1, np.round(p.C0, 4), np.round(p.C1, 4)))
for a in arcs:
    print('R*-arc F%d (%.4f, %.4f)' % a[:3])
print('F3 crossings: coord2 %.4f coord1 %.4f' % (fc.T2F3, fc.T1F3))
e = np.exp
x1, x2 = e(x[0]), e(x[1])
print('x1 = %.5f, x2 = %.5f, x1 + 1/x2 = %.5f, kappa+1 = %.5f, x1*x2 = %.5f, kappa = %.5f' % (x1, x2, x1 + 1/x2, fc.K + 1, x1*x2, fc.K))
for n, nq in ((60, 100), (150, 400)):
    Hs, Cs = [], []
    for p in pieces:
        t = np.linspace(p.t0, p.t1, n)[1:-1]; Hs.append(fc.hpt(p.f, t)); Cs.append(p.c(t))
    for f, lo, hi, cv in arcs:
        t = np.linspace(lo, hi, n)[1:-1]; Hs.append(fc.hpt(f, t)); Cs.append(np.tile(cv, (len(t), 1)))
    tot, worst = fc.box_pen(np.concatenate(Hs), np.concatenate(Cs), nq=nq, detail=True)
    print('grid', n, nq, 'box penalty', tot, 'worst', worst)
print('sign pen', [fc.sign_pen(p, n=400) for p in pieces])
