"""L1 NUMERICS + exact algebra: an explicit solution of the corner + box algebra (write-up Prop. boxbridge,
Prop. T1) when R*-arcs surround BOTH coordinate-1 crossings w12 (on F2) and w13 (on F3).  eps = 0.3.
Analytic crossing boxes (limits at the crossings, L1_notes S3.5) are checked exactly; all boxes are also
checked on fine grids.  Theorem L1.A excludes the configuration; this script only shows that the ALGEBRA is
consistent, so the exclusion cannot come from the corner equations and boxes.
Run:  python3 -I explicit_twoarc.py
"""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.argv = [sys.argv[0], '0.3']
import facet_configs as fc
K = fc.K
t1F2, t3F2, t2F3, t1F3 = fc.T1F2, fc.T3F2, fc.T2F3, fc.T1F3
x1 = 0.5
b = t1F2 + 0.02            # F2 arc J = (a, b), b just past w12
ap = t1F3 - 0.02           # F3 arc J' = (a', b'), a' just before w13
N = 5.0; mu = N            # virt_piece on F3 [0, a']: c1(0) = mu, c1(a') = 0, c2 = h2
m = K + 2                  # virt_piece on F2 [b, 1]: c1(b) = 0, c1(1) = K + 2, c3 = x2 h3
m3 = (K + 2) * (t3F2 - b) / (1 - b)      # c1 at the coordinate-3 crossing of F2
x2 = m * (1 - 1 / N)       # corner r23: (m, x2 - m, -x2) parallel to (N, -1, 1 - N)
M = mu * (ap - t2F3) / ap  # c1 at the coordinate-2 crossing of F3
print(f"kappa={K:.4f} x1={x1} x2={x2:.4f} b={b:.4f} a'={ap:.4f} mu={mu:.4f}")
print('analytic crossing boxes (must all be True):')
print('  b=2,a=1: x1*M <= kappa^2 :', x1 * M <= K**2, f'({x1*M:.3f} <= {K**2:.3f})')
print('  b=2,a=3: x1*M >= 1       :', x1 * M >= 1)
print('  b=3,a=1: x1*x2*kappa^2 >= m3:', x1 * x2 * K**2 >= m3, f'({x1*x2*K**2:.3f} >= {m3:.3f})')
print('  b=3,a=2: x1*x2 <= m3     :', x1 * x2 <= m3, f'({x1*x2:.3f} <= {m3:.3f})')
print('  corner r31 sign x1(kappa+1) > 1:', x1 * (K + 1) > 1, '; corner r12 sign x1 < kappa+1:', x1 < K + 1)
P1 = fc.pinned_piece(1, 0, 1, {1: x1, 2: 1.})
P2B = fc.virt_piece(2, b, 1, b, (2, x2), K + 2)
P3B = fc.virt_piece(3, 0, ap, ap, (1, 1.), mu)
a = t1F2 - 0.02; bp = t1F3 + 0.02
P2A = fc.free_piece(2, 0, a, P1.c(0.0)[0], np.array([0, -1., 1.]))      # corner r12 with F1
P3A = fc.free_piece(3, bp, 1, np.array([0, 1., -1.]), P1.c(1.0)[0])     # corner r31 with F1
pieces = [P1, P2A, P2B, P3B, P3A]
arcs = [(2, a, b, np.array([0, -1, 1.])), (3, ap, bp, np.array([0, 1, -1.]))]
print('sign penalties (0 = all strict signs hold):', [round(fc.sign_pen(p, n=600, margin=0.0), 12) for p in pieces])
print('corner r23 mismatch:', fc.corner_pen(P2B, 1.0, P3B, 0.0))
for n, nq in ((80, 200), (200, 600)):
    Hs, Cs = [], []
    for p in pieces:
        t = np.linspace(p.t0, p.t1, n)[1:-1]; Hs.append(fc.hpt(p.f, t)); Cs.append(p.c(t))
    for f, lo, hi, cv in arcs:
        t = np.linspace(lo, hi, 20)[1:-1]; Hs.append(fc.hpt(f, t)); Cs.append(np.tile(cv, (len(t), 1)))
    tot, worst = fc.box_pen(np.concatenate(Hs), np.concatenate(Cs), nq=nq, detail=True)
    print(f'grid n={n} nq={nq}: box penalty {tot:.3e}, worst min(c(A).q0, c(B).q0) = {worst:.5f} (<= 0: no box violated)')
