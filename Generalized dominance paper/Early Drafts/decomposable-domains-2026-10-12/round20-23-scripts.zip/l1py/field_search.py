"""L1 NUMERICS: weak fields on M_U with T1 exactly Bayes at p* = u, world 1 blind on a rigid set
Lambda = (+,-,+) n {m1.g <= 0}  u  (+,+,-) n {m0.g <= 0},  m1 = (a, 1-a, 0), m0 = (b, 0, 1-b)
(K3.7(beta'): K1 = co(K' u {e1, m1}), K0 = co(K' u {e1, m0}); consistent on R12 n R13 because both
contain e1).  Densities are homogeneous of degree 0.  On Lambda the ratio of the two live densities
is chosen so that G_{1/2} n Lambda = D_T1 n Lambda; off Lambda rho1 is solved so that sign(u.c) =
sign(P_T1) (T1 Bayes at u, no ties).  For t on a grid, B_t = {t.c > 0} is tested for coherence by
midpoint convexity (pairs of accepted gambles whose sum lies in U but is rejected) and by the
1-shift test (g accepted, g + s*1 in U rejected).  Reports violation rates and where they sit.
Run:  python3 -I field_search.py
"""
import numpy as np

EPS, S = 0.3, 0.9
C0 = (1 - EPS) / 3
V = np.array([C0 * np.ones(3) + EPS * np.eye(3)[k] for k in range(3)])
U_ = np.ones(3) / 3
VP = np.array([U_ + S * (V[k] - U_) for k in range(3)])
def P(g, K): return np.min(g @ np.asarray(K).T, axis=-1)
def inU(g): return P(g, VP) > 0

def sample(rng, n):
    out, m = [], 0
    while m < n:
        g = rng.normal(size=(4 * n, 3)); g /= np.linalg.norm(g, axis=1, keepdims=True)
        sg = np.sign(g); mixed = (sg.max(1) > 0) & (sg.min(1) < 0)
        g = g[inU(g) & mixed]; out.append(g); m += len(g)
    return np.concatenate(out)[:n]

def field(G, a, b, beta, coef, rng):
    sg = np.sign(G); PT = P(G, V) / np.linalg.norm(G, axis=1)
    m1 = np.array([a, 1 - a, 0.]); m0 = np.array([b, 0, 1 - b])
    L12 = (sg[:, 0] > 0) & (sg[:, 1] < 0) & (sg[:, 2] > 0) & (G @ m1 <= 0)
    L13 = (sg[:, 0] > 0) & (sg[:, 1] > 0) & (sg[:, 2] < 0) & (G @ m0 <= 0)
    Lam = L12 | L13
    # live densities off Lambda: smooth homogeneous
    n = G
    r2 = np.exp(n @ coef[0]); r3 = np.exp(n @ coef[1])
    # on Lambda: ratio fixes T1
    r2 = np.where(L12, 1.0, r2); r3 = np.where(L12, np.exp(beta * PT), r3)
    r2 = np.where(L13, np.exp(beta * PT), r2); r3 = np.where(L13, 1.0, r3)
    A = (r2 * sg[:, 1] + r3 * sg[:, 2]) / 3
    sp = np.sign(PT)
    # where T1 errs at world 1 off Lambda, the world agreeing with T1 must outvote
    bad = (~Lam) & (sp != sg[:, 0]) & (np.sign(A) != sp)
    j2 = bad & (sg[:, 1] == sp); j3 = bad & (sg[:, 2] == sp)
    r2 = np.where(j2, 4 * r3 + 1, r2); r3 = np.where(j3, 4 * r2 + 1, r3)
    A = (r2 * sg[:, 1] + r3 * sg[:, 2]) / 3
    F = np.where(sp == sg[:, 0], sp * (np.abs(A) + 1.0), sp * np.abs(A) / 2)
    r1 = 3 * (F - A) * sg[:, 0]
    r1 = np.where(Lam, 0.0, r1)
    assert np.all(r1[~Lam] > 0), 'rho1 sign'
    c = np.stack([r1 * sg[:, 0], r2 * sg[:, 1], r3 * sg[:, 2]], 1)
    # check T1 Bayes at u
    acc = c @ U_ > 0
    assert np.all(acc == (PT > 0)), 'T1 not Bayes'
    return c, Lam

def coherence_test(G, c, t, rng, trials=4000):
    """nearest-neighbour field evaluation: the field is known on the sample; test pairs whose sum is
    close to a sample point."""
    acc = c @ t > 0
    return acc

def run(seed=0, ngrid=12):
    rng = np.random.default_rng(seed)
    G = sample(rng, 60000)
    from scipy.spatial import cKDTree
    tree = cKDTree(G)
    res = []
    # baseline: the linear field c(g) = g (B_t = U n {t.g > 0}, coherent): NN-test noise level
    cb = G.copy(); rb = []
    for i in range(1, ngrid):
        for j in range(1, ngrid - i):
            t = np.array([i, j, ngrid - i - j]) / ngrid
            acc = cb @ t > 0; A = G[acc]
            I = rng.integers(0, len(A), 3000); J = rng.integers(0, len(A), 3000)
            Ssum = A[I] + A[J]; Ssum = Ssum[inU(Ssum)]; Ssum /= np.linalg.norm(Ssum, axis=1, keepdims=True)
            d, k = tree.query(Ssum); ok = d < 0.01
            rb.append(np.mean(~acc[k[ok]]))
    print(f'baseline (coherent linear field): mean violation {np.mean(rb):.4f}, max {np.max(rb):.4f}', flush=True)
    for trial in range(6):
        a, b = rng.uniform(0.2, 0.8, 2); beta = rng.uniform(2, 20)
        coef = rng.normal(scale=1.5, size=(2, 3))
        c, Lam = field(G, a, b, beta, coef, rng)
        worst = (0, None)
        rates = []
        for i in range(1, ngrid):
            for j in range(1, ngrid - i):
                t = np.array([i, j, ngrid - i - j]) / ngrid
                acc = c @ t > 0
                A = G[acc]
                I = rng.integers(0, len(A), 3000); J = rng.integers(0, len(A), 3000)
                Ssum = A[I] + A[J]; Ssum = Ssum[inU(Ssum)]
                Ssum /= np.linalg.norm(Ssum, axis=1, keepdims=True)
                d, k = tree.query(Ssum)
                ok = d < 0.01
                viol = np.mean(~acc[k[ok]]) if ok.sum() else 0
                rates.append((t, viol, ok.sum()))
                if viol > worst[0]:
                    worst = (viol, t)
        rates_arr = np.array([r[1] for r in rates])
        res.append((a, b, beta, Lam.mean(), rates_arr.mean(), worst))
        print(f'trial {trial}: a={a:.2f} b={b:.2f} beta={beta:.1f} |Lambda|={Lam.mean():.3f} '
              f'mean violation {rates_arr.mean():.4f}  frac t with violation>0.001: {np.mean(rates_arr > 1e-3):.2f} '
              f' worst {worst[0]:.4f} at t={np.round(worst[1], 3)}', flush=True)
    return res

if __name__ == '__main__':
    run()
