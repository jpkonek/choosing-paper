"""Referee NUMERICS for M1 (no verdict rests on these). Run: python3 -I ref_checks.py (from inside m1ref_py/).
(A) set identities used in M1.1, M1.6, M1.7: J_l = E_i(T1) ∩ Q_l = Λ_i ∩ Λ_j; E_i(Y_k) = E_i(T1) ∩ R_ij;
    on R_ij T1 errs at exactly one of i, j; F_j ⊆ E_i C \\ E_i Y_k for every C (by logic, on random C).
(B) M1.11: field with Λ_1 = E_1(T1), ρ2 = ρ3 = 1.  Along q = (1-s, sη, s(1-η)), s, η small, B_q -> Y_2:
    count disagreements with Y_2 and midpoint violations of B_q (B_q must be incoherent for such q).
(C) R_ij-arcs of each facet: sign classes met along F_1, F_2, F_3 (relint, off crossings).
(D) M1.2: m·w21 and m·w31 for m on the edges.
"""
import os, sys
here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(here, '..', 'm1py'))
import numpy as np
from m1_common import Geo, midpoint_violations

rng = np.random.default_rng(99)
for eps, s in [(0.1, 0.9), (0.3, 0.9), (0.6, 0.5)]:
    geo = Geo(eps, s)
    G = geo.sample_mixed_U(rng, 100000)
    acc = geo.T1(G)
    cor = geo.correct(G, acc)
    odd = geo.oddworld(G)
    print(f"eps={eps}, s={s}")
    # (A)
    badA = 0
    for l in range(3):
        i, j = [x for x in range(3) if x != l]
        Jl = cor[:, l] & ~cor[:, i] & ~cor[:, j]
        badA += int(np.sum(Jl != (~cor[:, i] & (odd == l))))
        Rij = (odd == i) | (odd == j)
        badA += int(np.sum(Rij & (cor[:, i] == cor[:, j])))          # exactly one correct on R_ij
        Yl = np.where(odd == l, G[:, i] > 0, acc)
        EiY = (G[:, i] > 0) != Yl
        badA += int(np.sum(EiY != (~cor[:, i] & Rij)))
        for _ in range(20):                                           # random C (arbitrary model)
            C = rng.random(len(G)) < 0.5
            EiC = (G[:, i] > 0) != C
            EjC = (G[:, j] > 0) != C
            EjY = (G[:, j] > 0) != Yl
            Fj = EjY & ~EjC
            badA += int(np.sum(Fj & ~(EiC & ~EiY)))
    print(f"  (A) violations of the set identities: {badA}")
    # (B)
    rho = np.ones_like(G)
    rho[:, 0] = cor[:, 0].astype(float)          # world 1 exactly shadow-blind, worlds 2,3 positive
    c = rho * np.sign(G)
    Y2 = np.where(odd == 1, G[:, 0] > 0, acc)    # Y_2 = T1 off J_2, P_1 on Q_2
    for (sv, eta) in [(1e-2, 0.2), (1e-3, 0.05), (1e-4, 0.01)]:
        q = np.array([1 - sv, sv * eta, sv * (1 - eta)])
        B = (c @ q) > 0
        dis = int(np.sum(B != Y2))
        def accB(g, q=q):
            a = geo.T1(g)
            cg = geo.correct(g, a)
            r = np.ones_like(g); r[:, 0] = cg[:, 0]
            return ((r * np.sign(g)) @ q) > 0
        v, n = midpoint_violations(accB, G, geo, rng, trials=20000)
        print(f"  (B) s={sv}, eta={eta}: #disagreements B_q vs Y_2 = {dis}; midpoint violations of B_q = {v}/{n}")
    # (C)
    V = geo.V
    rays = {'r12': np.cross(V[0], V[1]), 'r23': np.cross(V[1], V[2]), 'r31': np.cross(V[2], V[0])}
    for r in rays:
        x = rays[r]
        # orient into the boundary of D_T1: v_k · r >= 0 for all k
        if np.min(V @ x) < -1e-12: x = -x
        rays[r] = x
    facets = {'F1': ('r12', 'r31'), 'F2': ('r12', 'r23'), 'F3': ('r23', 'r31')}
    names = {0: 'Q1', 1: 'Q2', 2: 'Q3'}
    for F, (a, b) in facets.items():
        seq = []
        for tau in np.linspace(0.002, 0.998, 997):
            h = (1 - tau) * rays[a] + tau * rays[b]
            sg = np.sign(h)
            if 0 in sg: continue
            o = geo.oddworld(h[None])[0]
            lab = ''.join('+' if x > 0 else '-' for x in sg) + ':' + names[o]
            if not seq or seq[-1] != lab: seq.append(lab)
        print(f"  (C) {F} ({a}->{b}): {' | '.join(seq)}")
    # (D)
    w21 = np.array([-1, 0, geo.kappa]); w31 = np.array([-1, geo.kappa, 0])
    worst = 0
    for a in np.linspace(0, 1, 11):
        m12 = np.array([a, 1 - a, 0]); m13 = np.array([a, 0, 1 - a])
        worst = max(worst, abs(m12 @ w21 + a), abs(m13 @ w31 + a))
    print(f"  (D) max |m·w + a| over edge points: {worst:.2e}; v1·w21 = {V[0] @ w21:.2e}, v1·w31 = {V[0] @ w31:.2e}")
