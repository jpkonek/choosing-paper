"""M3 numerics (no proof rests on these).  Run: python3 -I m3_checks.py
(1) ladder algebra on a {+,0,-} pair: sign patterns of c, c', d; silence weakly
    optimal => sum_k q_k s_k <= sum_k q_k w_k; equal increments (single graded
    charge, s = w) => silence weakly optimal only at apex ties.
(2) closed reject cell {c'.q>=0, d.q<=0} is the closure of the open cell whenever the
    open cell is nonempty (used in Lemma M3.6(c)).
(3) convex K with d_H(K,T1) < eta contains the inner parallel body of T1 at depth eta
    (used in Lemma M3.6(b)); random polygons near T1.
"""
import numpy as np
rng = np.random.default_rng(20261016)

def ladder_losses(g, s, w):
    # losses of advice +, 0, - at each world (rank ladder: good 0, silent s, bad s+w)
    lp = np.where(g > 0, 0.0, s + w)
    l0 = s.copy()
    lm = np.where(g > 0, s + w, 0.0)
    return lp, l0, lm

def check1(n=200000):
    bad_sign = 0; viol_ineq = 0; sil_opt = 0; single_nonapex = 0; single_sil = 0
    for _ in range(n):
        g = rng.normal(size=3)
        if np.all(g > 0) or np.all(g < 0):
            continue
        s = rng.exponential(size=3); w = rng.exponential(size=3)
        q = rng.dirichlet(np.ones(3))
        lp, l0, lm = ladder_losses(g, s, w)
        c = l0 - lp; cp = l0 - lm; d = c - cp
        if not (np.all(np.sign(c) == np.sign(g)) and np.all(np.sign(d) == np.sign(g))
                and np.all(np.sign(cp) == -np.sign(g))):
            bad_sign += 1
        if c @ q <= 0 and cp @ q <= 0:          # silence weakly optimal
            sil_opt += 1
            if q @ s > q @ w + 1e-12:
                viol_ineq += 1
        # single graded charge: w = s
        lp1, l01, lm1 = ladder_losses(g, s, s)
        c1 = l01 - lp1; cp1 = l01 - lm1
        if c1 @ q <= 1e-12 and cp1 @ q <= 1e-12:
            single_sil += 1
            if abs(c1 @ q) > 1e-9 or abs(cp1 @ q) > 1e-9:
                single_nonapex += 1
    print("(1) sign-pattern violations:", bad_sign)
    print("    silence weakly optimal in", sil_opt, "samples; violations of q.s <= q.w:", viol_ineq)
    print("    single graded charge: silence weakly optimal in", single_sil,
          "samples; of these not apex ties:", single_nonapex)

def check2(n=20000, eps=1e-3):
    fails = 0; tested = 0
    for _ in range(n):
        g = rng.normal(size=3)
        if np.all(g > 0) or np.all(g < 0):
            continue
        s = rng.exponential(size=3); w = rng.exponential(size=3)
        lp, l0, lm = ladder_losses(g, s, w)
        c = l0 - lp; cp = l0 - lm; d = c - cp
        # exact boundary points of the closed reject cell {cp.q >= 0, d.q <= 0} inside Delta:
        # points on the line cp.q = 0 (resp. d.q = 0) of aff Delta, inside Delta, satisfying the other inequality
        for (a, b, sgn) in ((cp, d, -1.0), (d, cp, 1.0)):
            # line {a.q = 0, 1.q = 1}: q = q_p + t*dirn
            M = np.vstack([a, np.ones(3)])
            qp = np.linalg.lstsq(M, np.array([0.0, 1.0]), rcond=None)[0]
            dirn = np.cross(a, np.ones(3)); dirn /= np.linalg.norm(dirn)
            ts = np.linspace(-2, 2, 4001)
            Q = qp[None, :] + ts[:, None] * dirn[None, :]
            ok = np.all(Q >= 1e-9, axis=1) & (sgn * (Q @ b) >= 0)
            if not ok.any():
                continue
            q0 = Q[np.flatnonzero(ok)[rng.integers(ok.sum())]]
            tested += 1
            pert = q0 + eps * rng.normal(size=(5000, 3)); pert -= (pert.sum(1, keepdims=True) - 1) / 3
            if not ((pert @ cp > 0) & (pert @ d < 0)).any():
                fails += 1
    print("(2) exact closed-cell boundary points tested:", tested,
          "; with no open-cell point within", eps, ":", fails)

def t1_vertices(eps):
    c0 = (1 - eps) / 3
    return np.array([c0 + eps * (np.arange(3) == k) for k in range(3)])

def to2d(p):
    # coordinates in aff Delta
    e1 = np.array([1, -1, 0]) / np.sqrt(2); e2 = np.array([1, 1, -2]) / np.sqrt(6)
    return np.stack([p @ e1, p @ e2], axis=-1)

def check3(n=3000):
    fails = 0
    for _ in range(n):
        eps = rng.uniform(0.05, 0.9)
        V = to2d(t1_vertices(eps))
        eta = rng.uniform(0.002, 0.02) * eps
        # random convex polygon near T1: perturb many boundary points by < eta/2 and take hull
        ts = rng.uniform(size=(60, 1)); k = rng.integers(0, 3, size=60)
        pts = V[k] * (1 - ts) + V[(k + 1) % 3] * ts + rng.uniform(-1, 1, size=(60, 2)) * eta / 3
        pts = np.vstack([pts, V + rng.uniform(-1, 1, size=(3, 2)) * eta / 3])
        from scipy.spatial import ConvexHull
        H = ConvexHull(pts); K = pts[H.vertices]
        # inner parallel body points: sample interior of T1 at depth > eta
        lam = rng.dirichlet(np.ones(3), size=2000); x = lam @ V
        # distance to edges of T1
        def dist_edges(x):
            dd = []
            for i in range(3):
                a, b = V[i], V[(i + 1) % 3]
                t = np.clip(((x - a) @ (b - a)) / ((b - a) @ (b - a)), 0, 1)
                dd.append(np.linalg.norm(x - (a + t[:, None] * (b - a)), axis=1))
            return np.min(dd, axis=0)
        deep = x[dist_edges(x) > eta]
        # point-in-K test via hull equations
        inside = np.all(deep @ H.equations[:, :2].T + H.equations[:, 2] <= 1e-12, axis=1)
        if not inside.all():
            fails += 1
    print("(3) random near-T1 polygons:", n, "; inner-parallel-body containment failures:", fails)

if __name__ == "__main__":
    check1(); check2(); check3()
