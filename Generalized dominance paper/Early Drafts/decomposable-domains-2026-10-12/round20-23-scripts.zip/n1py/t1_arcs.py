"""T1: structure of out-band arcs {phi_1>theta} on dD_T (Euclidean): endpoints adjacent to the strip
{0<phi_1<theta} must lie in a facet relative interior (=> non-degenerate). Also corner values."""
import numpy as np, thresholds as T
for eps in [0.05,0.3,0.6]:
    V=T.T1(eps); H,lab=T.curve(V,3000); phi=H[:,0]/np.linalg.norm(H,axis=1)
    R=T.corners(V); cv=[R[(1,2)][0]/1.0]  # corner r_23 (unit)
    th0=phi.max(); bad=0; tested=0
    for th in np.linspace(0.02,th0-1e-3,200):
        s=(phi>th); n=len(s)
        for i in range(n):
            j=(i+1)%n
            if s[i]!=s[j]:
                # endpoint between i,j ; strip side must have 0<phi<th
                other = j if s[i] else i
                if 0<phi[other]<th:
                    tested+=1
                    k,t=lab[i]
                    if t<1e-3 or t>1-1e-3: bad+=1
    print(f'eps={eps}: theta0={th0:.4f}, corner r23 phi1={R[(1,2)][0]:.4f}, endpoints tested={tested}, at corners={bad}')
