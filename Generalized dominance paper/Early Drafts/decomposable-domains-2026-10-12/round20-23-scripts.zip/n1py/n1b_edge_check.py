"""N1 (round 20) NUMERICS.
(1) Set algebra used in Thm N1.2/N1.5: on R_ij, E_i(T1) = W_i ⊔ J_j and E_j(T1) = W_j ⊔ J_i, and
    E_i(T1) ∩ E_j(T1) ∩ R_ij = ∅ (so the shadow has no doubly blind part on any edge region).
(2) Every sampled coherent 'between' model C = D_K (K ⊇ K', K meets the open edge (e_i,e_j),
    K ⊆ conv(K' ∪ [e_i,e_j])) CROSSES T1 on R_ij: both (E_iT1 \ E_iC) ∩ R_ij and (E_iC \ E_iT1) ∩ R_ij
    are non-empty on the sample.  (Under the shadow, Lemma N1.1 forces every open-edge selected model
    to be comparable with T1 on R_ij; (2) illustrates that no intermediate between-model is.)
(3) The same for the explicit nested family K_t = conv(K' ∪ {(1-t)e_i + t e_j}), t in (0,1).
Run:  python3 -I -B n1b_edge_check.py   (from inside n1py/)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from n1b_common import Geo, errors

rng = np.random.default_rng(20261016)
E = np.eye(3)
for eps, s in [(0.1, 0.9), (0.3, 0.5), (0.6, 0.5)]:
    geo = Geo(eps, s)
    G = np.concatenate([geo.sample_mixed_U(rng, 150000), geo.near_T1_boundary(rng, 150000)])
    accT = geo.T1(G)
    cor = np.stack([~errors(G, accT, k) for k in range(3)], axis=1)
    print(f"eps={eps}, s={s}: n={len(G)}")
    for (i, j) in [(0, 1), (1, 2), (2, 0)]:
        k = 3 - i - j
        R = (G[:, i] * G[:, j]) < 0
        EiT = ~cor[:, i] & R
        EjT = ~cor[:, j] & R
        W_i = (~cor[:, i]) & cor[:, j] & cor[:, k]
        J_j = (~cor[:, i]) & cor[:, j] & (~cor[:, k])
        part_ok = np.array_equal(EiT, (W_i | J_j) & R)
        W_j = (~cor[:, j]) & cor[:, i] & cor[:, k]
        J_i = (~cor[:, j]) & cor[:, i] & (~cor[:, k])
        part2_ok = np.array_equal(EjT, (W_j | J_i) & R)
        both = int(np.sum(EiT & EjT))
        # (2) random between models
        n_test, n_cross, minA, minB = 0, 0, 10**9, 10**9
        for _ in range(300):
            t = rng.uniform(0.02, 0.98)
            m = (1 - t) * E[i] + t * E[j]
            H = np.vstack([geo.Vp, E[i], E[j]])
            extra = []
            for _e in range(rng.integers(0, 4)):
                w = rng.exponential(size=len(H)); w /= w.sum()
                extra.append(w @ H)
            K = np.vstack([geo.Vp, m] + extra) if extra else np.vstack([geo.Vp, m])
            acc = geo.inD(G, K)
            EiC = errors(G, acc, i) & R
            a = int(np.sum(EiT & ~EiC)); b = int(np.sum(EiC & ~EiT))
            n_test += 1; n_cross += int(a > 0 and b > 0)
            minA, minB = min(minA, a), min(minB, b)
        # (3) nested family
        nest_cross, nest_tot = 0, 0
        for t in np.linspace(0.01, 0.99, 50):
            K = np.vstack([geo.Vp, (1 - t) * E[i] + t * E[j]])
            acc = geo.inD(G, K)
            EiC = errors(G, acc, i) & R
            a = int(np.sum(EiT & ~EiC)); b = int(np.sum(EiC & ~EiT))
            nest_tot += 1; nest_cross += int(a > 0 and b > 0)
        print(f"  edge ({i+1},{j+1}): (1) E_iT1=W_i⊔J_j on R_ij: {part_ok}; E_jT1=W_j⊔J_i: {part2_ok};"
              f" #E_iT1∩E_jT1∩R_ij = {both}")
        print(f"     (2) random between-models crossing T1 on R_ij: {n_cross}/{n_test}"
              f" (min sample counts of the two crossing pieces: {minA}, {minB})")
        print(f"     (3) nested family K_t crossing T1 on R_ij: {nest_cross}/{nest_tot}")
