import numpy as np, warnings; warnings.filterwarnings('ignore')
import thresholds as T
def thr(V,norm,M=600):
    H,_=T.curve(V,M); n=T.nrm(H,norm); phi=H/n[:,None]
    th0=phi.max(); th1=phi.max(axis=1).min(); t2=[]
    for S in [(0,),(1,),(2,),(0,1),(0,2),(1,2)]:
        m=np.all(H[:,list(S)]>0,axis=1)
        if m.any(): t2.append(phi[m][:,list(S)].max())
    return th0,th1,min(t2)
rng=np.random.default_rng(1)
for norm in ['e','s']:
    A=[]
    for _ in range(400):
        V=rng.dirichlet(np.ones(3),3)*0.9+0.1/3
        if abs(np.linalg.det(V))<1e-3: continue
        A.append(thr(V,norm))
    A=np.array(A)
    print(norm,len(A),'min th0',A[:,0].min().round(4),'max th1',A[:,1].max().round(4),
          'min(th0-th1)',(A[:,0]-A[:,1]).min().round(4),'#(th1>=th2)',int((A[:,1]>=A[:,2]-1e-9).sum()),
          'min th2',A[:,2].min().round(4))
