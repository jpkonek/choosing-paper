"""N1: band thresholds for interior triangles.
theta0(T,norm) = max_c max_{h in dD_T} h_c/||h||   (chord no-go holds for theta < theta0)
theta1(T,norm) = min_{h in dD_T} max_c h_c/||h|| (acceptance condition W needs theta <= theta1)
theta2: Prop 2.6_theta threshold (target prior forced interior for theta < theta2).
Also reports where the out-band arcs' endpoints sit (facet relint vs corner)."""
import numpy as np, sys
def corners(V):
    R={}
    for k in range(3):
        for j in range(k+1,3):
            l=3-k-j; r=np.cross(V[k],V[j]); 
            if r@V[l]<0: r=-r
            R[(k,j)]=R[(j,k)]=r/np.linalg.norm(r)
    return R
def curve(V,M=4000):
    R=corners(V); pts=[];lab=[]
    for k in range(3):
        j,l=[x for x in range(3) if x!=k]
        a,b=R[(k,j)],R[(k,l)]
        for t in np.linspace(0,1,M,endpoint=False):
            h=(1-t)*a+t*b; pts.append(h); lab.append((k,t))
    return np.array(pts),lab
def nrm(H,norm): return np.linalg.norm(H,axis=1) if norm=='e' else np.abs(H).max(axis=1)
def thresholds(V,norm):
    H,lab=curve(V); n=nrm(H,norm); phi=H/n[:,None]
    th0=phi.max(); th1=phi.max(axis=1).min()
    # theta2: for each S of size 2 (and 1), max over boundary pts with h_S>0 of max_{s in S} phi_s; take min over S
    t2=[]
    for S in [(0,),(1,),(2,),(0,1),(0,2),(1,2)]:
        m=np.all(H[:,list(S)]>0,axis=1)
        t2.append(phi[m][:,list(S)].max() if m.any() else np.nan)
    return th0,th1,np.nanmin(t2),phi,lab
def T1(eps):
    b=(1-eps)/3; return np.array([b*np.ones(3)+eps*np.eye(3)[k] for k in range(3)])
if __name__=='__main__':
    for norm in ['e','s']:
        print('norm',norm)
        for eps in [0.01,0.05,0.1,0.2,0.25,0.3,0.5,0.6,0.9]:
            th0,th1,th2,phi,lab=thresholds(T1(eps),norm)
            b=(1-eps)/3; v2=np.array([b,b+eps,b]); foot=np.sqrt(1-b*b/(v2@v2))
            print(f' eps={eps:.2f} theta0={th0:.4f} theta1={th1:.4f} theta2={th2:.4f}' + (f' foot={foot:.4f}' if norm=='e' else ''))
    # random interior triangles
    rng=np.random.default_rng(1); out=[]
    for _ in range(3000):
        V=rng.dirichlet(np.ones(3),3)*0.9+0.1/3
        if abs(np.linalg.det(V))<1e-3: continue
        for norm in ['e','s']:
            th0,th1,th2,_,_=thresholds(V,norm); out.append((norm,th0,th1,th2))
    for norm in ['e','s']:
        A=np.array([o[1:] for o in out if o[0]==norm])
        print(norm,'random: min theta0',A[:,0].min(),' max theta1',A[:,1].max(),' min(theta0-theta1)',(A[:,0]-A[:,1]).min(), ' min theta2', A[:,2].min())
