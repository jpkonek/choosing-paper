"""L4 numerics (NUMERICS only; no proof depends on this file). Run: python3 -I l4_checks.py
(1) Margins (v3)_3 - max_{conv(K' u [e1,e2])} m_3 and (v2)_2 - max_{conv(K' u [e1,e3])} m_2  (Lemma L4.6 input).
(2) Joint T1-error sets Q_l cap E_i(T1) are non-null (Prop. L4.3 input), by sampling.
(3) The splice S_1 = (T1 on Q1 u Q2, P1 on Q3) is not convex (Example L4.7), by midpoint search.
"""
import numpy as np
rng = np.random.default_rng(20261016)

def setup(eps, s):
    c0 = (1 - eps) / 3
    V = np.array([c0 * np.ones(3) + eps * np.eye(3)[k] for k in range(3)])   # vertices of T1
    u = np.ones(3) / 3
    Kp = u + s * (V - u)                                                      # vertices of K'
    return V, Kp

def inU(G, Kp):   return (G @ Kp.T).min(axis=1) > 0
def inT1(G, V):   return (G @ V.T).min(axis=1) > 0

def qclass(G):
    sg = np.sign(G)
    odd = np.zeros(len(G), dtype=int)                 # world whose sign differs (0 if all equal)
    for k in range(3):
        others = [j for j in range(3) if j != k]
        m = (sg[:, others[0]] == sg[:, others[1]]) & (sg[:, k] != sg[:, others[0]])
        odd[m] = k + 1
    return odd

def sample_U(n, Kp, scale=3.0):
    G = rng.normal(size=(4 * n, 3)) * scale
    G = G[inU(G, Kp)]
    return G[:n]

print("(1) margins")
worst = np.inf
for eps in np.linspace(0.02, 0.98, 25):
    for s in np.linspace(0.02, 0.98, 25):
        V, Kp = setup(eps, s)
        m3 = V[2, 2] - Kp[:, 2].max()      # conv(K' u [e1,e2]) has max 3rd coord = max over K'
        m2 = V[1, 1] - Kp[:, 1].max()
        formula = (1 - s) * 2 * eps / 3
        assert abs(m3 - formula) < 1e-12 and abs(m2 - formula) < 1e-12
        worst = min(worst, m3, m2)
print("   margins equal (1-s)*2*eps/3 on the 25x25 grid; min margin =", round(worst, 6))

print("(2) joint T1-error sets")
for eps, s in [(0.3, 0.9), (0.1, 0.5), (0.6, 0.95)]:
    V, Kp = setup(eps, s)
    G = sample_U(200000, Kp)
    T = inT1(G, V)
    q = qclass(G)
    for l in (1, 2, 3):
        i = [k for k in (1, 2, 3) if k != l][0]
        wrong_i = np.where(G[:, i - 1] > 0, ~T, T)       # T1 errs at world i
        frac = np.mean((q == l) & wrong_i)
        print(f"   eps={eps}, s={s}: mu(Q_{l} cap E_{i}(T1))/mu(U) ~ {frac:.4f}")

print("(3) S_1 = T1 on Q1uQ2, P1 on Q3: midpoint-convexity violations")
for eps, s in [(0.3, 0.9), (0.1, 0.5), (0.6, 0.95)]:
    V, Kp = setup(eps, s)
    G = sample_U(60000, Kp)
    q = qclass(G)
    def S1(X):
        qq = qclass(X); T = inT1(X, V)
        out = np.where(qq == 3, X[:, 0] > 0, T)
        out = out | (X > 0).all(axis=1)
        return out & inU(X, Kp)
    A = G[S1(G)]
    i1 = rng.integers(0, len(A), 200000); i2 = rng.integers(0, len(A), 200000)
    Mid = (A[i1] + A[i2]) / 2
    viol = ~S1(Mid)
    print(f"   eps={eps}, s={s}: {viol.sum()} violations in 200000 midpoints of accepted pairs")
