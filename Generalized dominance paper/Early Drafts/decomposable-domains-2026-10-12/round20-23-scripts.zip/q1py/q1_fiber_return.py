"""Q1.21 illustration (NUMERICS): a lifted L2/P1 generator that is rho*-unfavourable is undone by two or three
forced edge cut moves along the transverse fibres, giving an accepted nonzero vector <= 0 (strict (G) fails).

Linear host, partners additive with integral penalties (w_2 = |g_2|, w_3 = |g_3|), rho* = |g_1|.
A 12-cut move: source P' with s >= sigma (early), target Q' with s < sigma, w_2(Q') > w_2(P').
A 13-cut move: source with t >= tau (early), target with t < tau, w_3(target) > w_3(source).
Both are accepted at world 1 by competitiveness of the edge model at the cut (Lemma Q1.20).
Run: python3 -I -B q1_fiber_return.py  (from inside q1py/).
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from q1_common import mass, rect_in_U, solve_t_extent

ETA = 1e-3      # strict slack in every cut move
RATIO = 0.5     # generator: rho*(target) = RATIO * rho*(source)


def show(name, R):
    ch, s0, s1, t0, t1 = R
    vals = {w: mass(ch, s0, s1, t0, t1, w) for w in ('rho', 'w2', 'w3')}
    print(f"  {name:4s} {ch} s in [{s0:.6f},{s1:.6f}] t in [{t0:.6f},{t1:.6f}]  in U: {rect_in_U(*R)}  "
          f"rho*={vals['rho']:.6e} w2={vals['w2']:.6e} w3={vals['w3']:.6e}")
    return vals


def run(label, B_chart, B_s, B_t0, first_move):
    print(f"\n=== {label} ===")
    P = ('Q1m', 3.00, 3.02, 3.00, 3.02)
    vP = show('P', P)
    # generator target B with rho*(B) = RATIO rho*(P)
    LB = solve_t_extent(B_chart, B_s[0], B_s[1], B_t0, RATIO * vP['rho'], 'rho', upward=True, hi=5.0)
    B = (B_chart, B_s[0], B_s[1], B_t0, B_t0 + LB)
    vB = show('B', B)
    print(f"  generator 1_B - 1_P: w2 ratio = {vB['w2']/vP['w2']:.3e} (vanishing-ratio trade at world 2), "
          f"rho* ratio = {vB['rho']/vP['rho']:.4f} < 1")
    steps, cur, vcur = [], B, vB
    if first_move == '12':
        # x_2-move along s ~ B_s[0]: target in Q1m, s slightly smaller (later), t anywhere admissible
        sig = B_s[0]
        tgt_w2 = (1 + ETA) * vcur['w2']
        L0 = solve_t_extent('Q1m', sig * 0.9, sig, 4.0, tgt_w2, 'w2', upward=True, hi=20.0)
        T0 = ('Q1m', sig * 0.9, sig, 4.0, 4.0 + L0)
        v0 = show('T0', T0)
        ok = cur[1] >= sig - 1e-15 and T0[2] <= sig + 1e-15 and v0['w2'] > vcur['w2']
        steps.append(('12-cut at s=%.4f' % sig, ok, v0['rho'] / vcur['rho']))
        cur, vcur = T0, v0
    # x_3-move along t ~ cur's lower t: target in Q1m with s in [3.02, 3.04] (just early of P in the 12-chain)
    tau = cur[3]
    tgt_w3 = (1 + ETA) * vcur['w3']
    L1 = solve_t_extent('Q1m', 3.02, 3.04, tau, tgt_w3, 'w3', upward=False, hi=tau * 0.5)
    T1 = ('Q1m', 3.02, 3.04, tau - L1, tau)
    v1 = show('T1', T1)
    ok = cur[3] >= tau - 1e-15 and T1[4] <= tau + 1e-15 and v1['w3'] > vcur['w3']
    steps.append(('13-cut at t=%.4f' % tau, ok, v1['rho'] / vcur['rho']))
    # x_2-move at s = 3.02 into P
    tgt_w2 = (1 + ETA) * v1['w2']
    L2 = solve_t_extent('Q1m', 3.00, 3.02, 3.00, tgt_w2, 'w2', upward=True, hi=0.5)
    T2 = ('Q1m', 3.00, 3.02, 3.00, 3.00 + L2)
    v2 = show('T2', T2)
    ok = T1[1] >= 3.02 - 1e-15 and T2[2] <= 3.02 + 1e-15 and v2['w2'] > v1['w2']
    steps.append(('12-cut at s=3.0200', ok, v2['rho'] / v1['rho']))
    for name, ok, f in steps:
        print(f"  step {name}: valid cut move = {ok}, rho* factor = {f:.6f}")
    sub = L2 < 0.02
    print(f"  T2 is a proper subset of P: {sub} (T2 has t-extent {L2:.6f} of P's 0.02); "
          f"rho*(T2)/rho*(P) = {v2['rho']/vP['rho']:.4f}")
    print(f"  net vector = generator + moves = 1_T2 - 1_P <= 0 and nonzero: {sub and all(s[1] for s in steps)}")
    return sub and all(s[1] for s in steps)


if __name__ == '__main__':
    print("Q1.21 numerics: fibre return chains in the linear host (eps = 0.3, s = 0.9)")
    r = []
    r.append(run("target at the 12-end inside Q_1 (-,+,+), plane g_2 = 0", 'Q1m', (0.010, 0.011), 4.0, None))
    r.append(run("target at the 12-end inside Q_2 (+,-,+), plane g_2 = 0", 'Q2p', (0.010, 0.011), 1.0, '12'))
    r.append(run("target near the e_1 ray inside Q_1 (+,-,-)", 'Q1p', (0.010, 0.011), 0.010, None))
    print(f"\nall three generators undone (strict (G) violated): {all(r)}")
