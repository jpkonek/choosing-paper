"""Prop. Q1.26 sanity check (NUMERICS): (TC) for the linear host, eps = 0.3, s = 0.9.

Chart Q1m: (-1, s, t) in U iff min_q(-q1 + q2 s + q3 t) > 0  (region D-, upward closed).
Chart Q1p: ( 1,-s,-t) in U iff min_q( q1 - q2 s - q3 t) > 0  (region D+, convex, contains small (s,t)).
r_2 = 1/s, r_3 = 1/t; x_j is an increasing function of r_j, so rook structure in (s,t) = rook structure in chi.
Checks: both regions nonempty; s-projection of D- is all of (0, inf) (so x_2(Q_1) = (0,1) and TC3 holds);
s-projections of D+ and D- overlap (one 12-step links the two components); grid rook-connectivity.
Run: python3 -I -B q1_tc_linear.py
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from q1_common import KV, in_U, point

grid = np.exp(np.linspace(np.log(1e-3), np.log(1e3), 241))
Dm = np.array([[in_U(point('Q1m', s, t)) for t in grid] for s in grid])
Dp = np.array([[in_U(point('Q1p', s, t)) for t in grid] for s in grid])
print("K' vertices:", [np.round(q, 4).tolist() for q in KV])
print("D- nonempty:", Dm.any(), " D+ nonempty:", Dp.any())
print("every grid s has some t in D-:", bool(Dm.any(axis=1).all()), " every grid t has some s in D-:",
      bool(Dm.any(axis=0).all()))
sp = grid[Dp.any(axis=1)]
print(f"s-projection of D+ on the grid: ({sp.min():.4g}, {sp.max():.4g});  min_q q1/q2 = "
      f"{min(q[0] / q[1] for q in KV):.4g}")
print("s-projections of D+ and D- overlap:", bool((Dp.any(axis=1) & Dm.any(axis=1)).any()))


def rook_components(cells):
    """cells: list of (i, j) grid indices; rook adjacency = same i or same j."""
    parent = list(range(len(cells)))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    by_i, by_j = {}, {}
    for k, (i, j) in enumerate(cells):
        by_i.setdefault(i, []).append(k)
        by_j.setdefault(j, []).append(k)
    for group in list(by_i.values()) + list(by_j.values()):
        for k in group[1:]:
            parent[find(k)] = find(group[0])
    return len({find(k) for k in range(len(cells))})


cells = [(i, j) for i in range(len(grid)) for j in range(len(grid)) if Dm[i, j] or Dp[i, j]]
print("grid points of G:", len(cells), " rook components of G (D+ union D-, same (s,t) grid):",
      rook_components(cells))
