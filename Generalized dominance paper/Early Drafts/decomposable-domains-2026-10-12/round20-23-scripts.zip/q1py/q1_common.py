"""Q1 (round 21b) common geometry: the linear host on M_U, n = 3, in projective charts.

T1 = eps-contamination of u, K' = u + s(T1 - u), U = D_{K'}.  Run scripts with python3 -I -B from inside q1py/.

Charts (cones over planar regions; every set used is a cone, so only directions matter):
  Q1m : g = (-1, s, t), s, t > 0      (sign class (-,+,+) of Q_1)
  Q1p : g = ( 1,-s,-t), s, t > 0      (sign class (+,-,-) of Q_1)
  Q2p : g = ( 1,-s, t), s, t > 0      (sign class (+,-,+) of Q_2)
In every chart |g_1| = 1, |g_2| = s, |g_3| = t, so r_2 = |g_1|/|g_2| = 1/s and r_3 = 1/t.

Linear host: edge models C_theta = U ∩ {(1-theta) g_1 + theta g_j > 0}.  On R_1j their world-1 error set is
{r_j < theta/(1-theta)}, so the edge chain coordinate x_j is an increasing function of r_j:
"early" in the 12-chain = large s, "early" in the 13-chain = large t.

Measures (standard Gaussian mu on R^3).  For a cone over a chart region A and a weight f homogeneous of degree 1,
  int_{cone A} f dmu = C1 * int_A f(chart point) (1+s^2+t^2)^(-2) ds dt,   C1 = 2 (2 pi)^(-3/2).
Partner densities w_2 = h|g_2|, w_3 = h|g_3| (h = 1 here: integral penalties); rho* = h|g_1|.
"""
import numpy as np
from scipy import integrate

EPS, SSC = 0.3, 0.9
C1 = 2.0 * (2.0 * np.pi) ** -1.5


def kprime_vertices(eps=EPS, s=SSC):
    u = np.ones(3) / 3.0
    c0 = (1 - eps) / 3.0
    V = [c0 * np.ones(3) + eps * np.eye(3)[k] for k in range(3)]
    return [u + s * (v - u) for v in V]


KV = kprime_vertices()


def point(chart, s, t):
    if chart == 'Q1m':
        return np.array([-1.0, s, t])
    if chart == 'Q1p':
        return np.array([1.0, -s, -t])
    if chart == 'Q2p':
        return np.array([1.0, -s, t])
    raise ValueError(chart)


def in_U(g):
    """g in U = D_{K'} iff min over K' of q.g > 0 (min over the vertices)."""
    return min(float(q @ g) for q in KV) > 0


def rect_in_U(chart, s0, s1, t0, t1, n=7):
    return all(in_U(point(chart, s, t)) for s in np.linspace(s0, s1, n) for t in np.linspace(t0, t1, n))


def mass(chart, s0, s1, t0, t1, which):
    """which in {'rho', 'w2', 'w3'}: rho* = |g1| (h = 1), w2 = |g2|, w3 = |g3|."""
    def f(t, s):
        N = 1.0 + s * s + t * t
        val = {'rho': 1.0, 'w2': s, 'w3': t}[which]
        return val * N ** -2
    v, _ = integrate.dblquad(f, s0, s1, lambda s: t0, lambda s: t1, epsabs=1e-14, epsrel=1e-12)
    return C1 * v


def solve_t_extent(chart, s0, s1, t0, target, which, upward=True, hi=10.0):
    """Find L with mass(chart, s0, s1, t0, t0+L) = target (upward) or mass(..., t0-L, t0) = target."""
    lo_L, hi_L = 0.0, hi
    for _ in range(200):
        mid = 0.5 * (lo_L + hi_L)
        m = mass(chart, s0, s1, t0, t0 + mid, which) if upward else mass(chart, s0, s1, t0 - mid, t0, which)
        if m < target:
            lo_L = mid
        else:
            hi_L = mid
    return 0.5 * (lo_L + hi_L)
