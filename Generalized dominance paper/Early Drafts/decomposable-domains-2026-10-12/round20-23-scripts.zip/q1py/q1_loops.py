"""Q1.20(a) illustration (NUMERICS): rook loops of forced edge cut moves on Q_1.

A loop A -> b (13-cut) -> c (12-cut) -> d (13-cut) -> A (12-cut) returns to A a set whose size is fixed by the
partner densities.  If omega = w_2/w_3 is of product form psi(x_3)/phi(x_2) the loop is (asymptotically) neutral;
otherwise one orientation returns a strictly smaller subset of A, i.e. an accepted nonzero vector <= 0.

Each 12-cut keeps w_2-mass (times 1+ETA) and needs: source s >= sigma > target s.
Each 13-cut keeps w_3-mass (times 1+ETA) and needs: source t >= tau > target t.
Cells are cones over chart rectangles in Q1m (g = (-1, s, t)).  Run: python3 -I -B q1_loops.py
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from scipy import integrate
from q1_common import C1, rect_in_U

ETA = 1e-4
H = 0.01   # cell half-width


def make_weights(beta):
    """w_2 = |g_2| (1 + beta |g_2||g_3|/|g|^2), w_3 = |g_3|; beta = 0 is integral penalties (product form)."""
    def w2(s, t):
        return s * (1.0 + beta * s * t / (1.0 + s * s + t * t))

    def w3(s, t):
        return t
    return w2, w3


def m(f, s0, s1, t0, t1):
    v, _ = integrate.dblquad(lambda t, s: f(s, t) * (1 + s * s + t * t) ** -2, s0, s1,
                             lambda s: t0, lambda s: t1, epsabs=1e-15, epsrel=1e-11)
    return C1 * v


def ext(f, s0, s1, t0, target, up=True):
    lo, hi = 0.0, 5.0
    for _ in range(100):
        mid = 0.5 * (lo + hi)
        val = m(f, s0, s1, t0, t0 + mid) if up else m(f, s0, s1, t0 - mid, t0)
        lo, hi = (mid, hi) if val < target else (lo, mid)
    return 0.5 * (lo + hi)


def sext(f, s_hi, t0, t1, target):
    """cell [s_hi - L, s_hi] x [t0, t1] with given mass (moving s downward = later in the 12-chain)."""
    lo, hi = 0.0, s_hi * 0.9
    for _ in range(100):
        mid = 0.5 * (lo + hi)
        val = m(f, s_hi - mid, s_hi, t0, t1)
        lo, hi = (mid, hi) if val < target else (lo, mid)
    return 0.5 * (lo + hi)


DEL = 0.002   # thickness of every cell in the coordinate that a move keeps (almost) constant


def sfree(f, s0, t0, t1, target):
    """cell [s0, s0+L] x [t0, t1] with the given mass (free coordinate s)."""
    lo, hi = 0.0, 5.0
    for _ in range(100):
        mid = 0.5 * (lo + hi)
        lo, hi = (mid, hi) if m(f, s0, s0 + mid, t0, t1) < target else (lo, mid)
    return 0.5 * (lo + hi)


def tfree(f, s0, s1, t0, target):
    """cell [s0, s1] x [t0, t0+L] with the given mass (free coordinate t)."""
    lo, hi = 0.0, 5.0
    for _ in range(100):
        mid = 0.5 * (lo + hi)
        lo, hi = (mid, hi) if m(f, s0, s1, t0, t0 + mid) < target else (lo, mid)
    return 0.5 * (lo + hi)


def loop(beta, a, b_s, c_t, orient):
    """Returns (w(final deposit)/w(S)) in the measure of the closing move; < 1 means the deposit is a proper
    subset of the source S, i.e. an accepted nonzero vector <= 0."""
    w2, w3 = make_weights(beta)
    sa, ta = a
    d = DEL
    S = (sa, sa + d, ta, ta + d)
    cells = [S]
    if orient == '+':
        L = sfree(w3, b_s, ta - d, ta, (1 + ETA) * m(w3, *S)); B = (b_s, b_s + L, ta - d, ta)          # 13-cut at t=ta
        L = tfree(w2, b_s - d, b_s, c_t, (1 + ETA) * m(w2, *B)); C = (b_s - d, b_s, c_t, c_t + L)      # 12-cut at s=b_s
        L = sfree(w3, sa + d, c_t - d, c_t, (1 + ETA) * m(w3, *C)); D = (sa + d, sa + d + L, c_t - d, c_t)  # 13 at t=c_t
        need = (1 + ETA) * m(w2, *D)                                                                  # 12-cut at s=sa+d
        LT = tfree(w2, sa, sa + d, ta, need)
        cells += [B, C, D]
        ratio = need / m(w2, *S)
    else:
        L = tfree(w2, sa - d, sa, c_t, (1 + ETA) * m(w2, *S)); D = (sa - d, sa, c_t, c_t + L)           # 12-cut at s=sa
        L = sfree(w3, b_s, c_t - d, c_t, (1 + ETA) * m(w3, *D)); C = (b_s, b_s + L, c_t - d, c_t)      # 13-cut at t=c_t
        L = tfree(w2, b_s - d, b_s, ta + d, (1 + ETA) * m(w2, *C)); B = (b_s - d, b_s, ta + d, ta + d + L)  # 12 at s=b_s
        need = (1 + ETA) * m(w3, *B)                                                                  # 13-cut at t=ta+d
        cells += [D, C, B]
        ratio = need / m(w3, *S)
    assert all(rect_in_U('Q1m', *R) for R in cells)
    return ratio


if __name__ == '__main__':
    print("rook loops on Q_1 (chart (-1,s,t)); ratio = (mass the loop must deposit in A)/(mass of A),"
          " in the measure of the closing move.  ratio < 1 => strict (G) fails.")
    a, b_s, c_t = (2.0, 2.0), 6.0, 6.0
    for beta in (0.0, 0.5, -0.5, 2.0):
        rp = loop(beta, a, b_s, c_t, '+')
        rm = loop(beta, a, b_s, c_t, '-')
        tag = 'product form' if beta == 0 else 'non-product omega'
        print(f"beta = {beta:+.1f} ({tag}): orientation + ratio = {rp:.6f}, orientation - ratio = {rm:.6f}, "
              f"violation = {min(rp, rm) < 1}")
