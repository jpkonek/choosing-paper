"""Finite cell model of the P1 (round 21) totally blind world (two worlds, world 2 = lambda).

Chain coordinate x in [0,1); lambda = Lebesgue on M.  Exact rational arithmetic.
Design (P1_notes.md section 2), truncated to two levels with small projective planes
(PG(2,2), PG(2,3)); the axioms do not use q_n >= 4^n, only the blindness rate eps_n -> 0 does.

Blocks B_k = [u_k, u_{k+1}), r_k = (1-u0) 5^-k, u_k = 1 - r_k:
  ref_k  = left 16/25 r_k            (2 cells)
  Fo_k   = F_k minus S_k             (1 cell)
  S_k    = right s_k of F_k          (1 cell),  s_k = r_k / (100 N_k),  N_k = min{N : 2^N >= 50/r_k}
Source region S = c_{u0} (8 cells) union all S_k.
Roles of blocks: G0 = 2 gap blocks, I_1 = 7 blocks (PG(2,2)), G1 = 2 gap blocks, I_2 = 13 blocks (PG(2,3)).
Level n sources: Sigma_n = S cap c_{v_n}, v_n = u_{min I_n}, split into K_n strips.
"""
from fractions import Fraction as Fr
import itertools

U0 = Fr(3, 4)
LEVELS = [(1, 2, 2), (2, 4, 3)]   # (n, K_n, q_n)
ROLES = ['G'] * 2 + ['I1'] * 7 + ['G'] * 2 + ['I2'] * 13


def pg2_lines(q):
    pts = []
    for v in itertools.product(range(q), repeat=3):
        if v == (0, 0, 0):
            continue
        i = next(j for j in range(3) if v[j])
        inv = pow(v[i], q - 2, q)
        w = tuple((x * inv) % q for x in v)
        if w not in pts:
            pts.append(w)
    lines = []
    for nrm in pts:
        lines.append(frozenset(j for j, p in enumerate(pts)
                               if sum(a * b for a, b in zip(nrm, p)) % q == 0))
    return pts, lines


def N_of(r):
    N = 0
    while Fr(2) ** N < 50 / r:
        N += 1
    return N


class Model:
    def __init__(self, sub_src=8):
        bps = [Fr(0)]
        for i in range(1, sub_src + 1):
            bps.append(U0 * i / sub_src)
        self.src0 = list(range(sub_src))          # cells of c_{u0}
        self.blocks = []
        r = 1 - U0
        for k, role in enumerate(ROLES):
            u = 1 - r
            N = N_of(r)
            s = r / (100 * N)
            reflen = r * Fr(16, 25)
            blen = r * Fr(4, 5)
            c_ref0 = len(bps) - 1
            bps.append(u + reflen / 2)
            bps.append(u + reflen)
            ref = [c_ref0, c_ref0 + 1]
            bps.append(u + blen - s)
            fo = [c_ref0 + 2]
            bps.append(u + blen)
            S = [c_ref0 + 3]
            self.blocks.append(dict(k=k, role=role, u=u, r=r, N=N, s=s, ref=ref, fo=fo, S=S))
            r = r / 5
        self.tail = len(bps) - 1
        bps.append(Fr(1))
        self.bps = bps
        self.ncell = len(bps) - 1
        self.len = [bps[i + 1] - bps[i] for i in range(self.ncell)]
        self.Scells = set(self.src0) | {b['S'][0] for b in self.blocks}
        self.refcells = {c for b in self.blocks for c in b['ref']}
        # level structure
        self.level_blocks = {}
        self.gens = {}
        for (n, K, q) in LEVELS:
            idx = [b['k'] for b in self.blocks if b['role'] == 'I%d' % n]
            pts, lines = pg2_lines(q)
            assert len(pts) == len(idx)
            vn = self.blocks[idx[0]]['u']
            Sigma = sorted(c for c in self.Scells if self.bps[c + 1] <= vn)
            # strips: c_{u0} cells split evenly; deep S cells appended to strips round-robin
            strips = [[] for _ in range(K)]
            per = len(self.src0) // K
            for i in range(K):
                strips[i] = self.src0[i * per:(i + 1) * per]
            deep = [c for c in Sigma if c not in self.src0]
            for j, c in enumerate(deep):
                strips[j % K].append(c)
            Pi = len(lines)
            L = Pi // K
            gl = []
            for i in range(K):
                for l in range(L):
                    line = sorted(lines[i * L + l])
                    Q = [c for pnt in line for c in self.blocks[idx[pnt]]['ref']]
                    g = [0] * self.ncell
                    for c in Q:
                        g[c] = 1
                    for c in strips[i]:
                        g[c] = -1
                    gl.append(dict(n=n, i=i, l=l, line=line, P=list(strips[i]), Q=Q, g=g))
            self.level_blocks[n] = (idx, lines, vn, Sigma, strips)
            self.gens[n] = (gl, L, K, q)
        opts = [[None] + list(range(len(self.gens[n][0]))) for (n, _, _) in LEVELS]
        self.selectors = list(itertools.product(*opts))
        self._gF = {sel: self._make_gF(sel) for sel in self.selectors}

    def _make_gF(self, sel):
        g = [0] * self.ncell
        for (n, _, _), j in zip(LEVELS, sel):
            if j is None:
                continue
            gg = self.gens[n][0][j]['g']
            g = [x + y for x, y in zip(g, gg)]
        return g

    def tails(self, f):
        out = [Fr(0)] * (self.ncell + 1)
        s = Fr(0)
        for c in range(self.ncell - 1, -1, -1):
            s += f[c] * self.len[c]
            out[c] = s
        return out

    def in_T(self, f):
        return all(t >= 0 for t in self.tails(f))

    def gF(self, sel):
        return self._gF[sel]

    def accept(self, delta):
        for sel in self.selectors:
            g = self._gF[sel]
            if self.in_T([d - x for d, x in zip(delta, g)]):
                return True, sel
        return False, None

    def lam(self, cells):
        return sum(self.len[c] for c in cells)
