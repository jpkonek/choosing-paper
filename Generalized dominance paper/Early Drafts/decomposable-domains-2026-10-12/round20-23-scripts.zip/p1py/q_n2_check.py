"""NUMERICS for P1 (round 21): a totally blind world 1 with closed sections (P1_notes.md).

Run:  python3 -I -B q_n2_check.py     (from inside p1py/)
Exact rational arithmetic on the finite cell model of q_n2_common.py.  No proof rests on this.
"""
import os
import random
import sys
from fractions import Fraction as Fr
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from q_n2_common import Model, LEVELS, U0

random.seed(21)
M = Model()
nc = M.ncell
report = {}


def bump(key, ok):
    a, b = report.get(key, (0, 0))
    report[key] = (a + (1 if ok else 0), b + 1)


def start_cell(B):
    return B['ref'][0]


# 0. thinness: Theta_k <= r_k/25 (analytic bound N_k s_{>=k} + 2^-N_k, deeper blocks bounded by geometric tail)
for B in M.blocks:
    k = B['k']
    s_ge = sum(b['s'] for b in M.blocks if b['k'] >= k)
    # blocks beyond the model: s_{k'} <= r_{k'}/(100 N_k), sum <= (1/4) r_last/(100 N_k)
    s_ge += M.blocks[-1]['r'] / 5 * Fr(5, 4) / (100 * B['N'])
    bound = B['N'] * s_ge + Fr(1, 2 ** B['N'])
    bump('analytic thinness N_k s_{>=k} + 2^-N_k <= r_k/25', bound <= B['r'] / 25)
# actual Theta_k in the model: deep-level source mass right of u_k, for blocks of level 1
idx1 = M.level_blocks[1][0]
gl2 = M.gens[2][0]
for k in idx1:
    B = M.blocks[k]
    c0 = start_cell(B)
    th = max(M.lam([c for c in g['P'] if c >= c0]) for g in gl2)
    bump('model Theta_k (level-2 source mass right of u_k) <= r_k/25', th <= B['r'] / 25)

# 1. same-level generator pairs: best tail at u_k of sigma - g1 - g2 (sigma <= 1) is negative
for (n, _, _) in LEVELS:
    gl, L, K, q = M.gens[n]
    idx = M.level_blocks[n][0]
    others = [m for (m, _, _) in LEVELS if m != n]
    for a in range(len(gl)):
        for b in range(len(gl)):
            g1, g2 = gl[a], gl[b]
            shared = set(g1['line']) & set(g2['line'])
            k = idx[min(shared)]
            c0 = start_cell(M.blocks[k])
            # worst case over the other levels' selected generators (their sources may sit right of u_k)
            worst = Fr(-10)
            for sel_other in [None] + list(range(len(M.gens[others[0]][0]))):
                h = [0] * nc
                if sel_other is not None:
                    h = list(M.gens[others[0]][0][sel_other]['g'])
                val = sum(M.len[c] * (1 - g1['g'][c] - g2['g'][c] - 2 * min(0, h[c]))
                          for c in range(c0, nc))
                worst = max(worst, val)
            bump('same-level pairs: lines meet and sum blocked (worst other-level sources)',
                 len(shared) >= 1 and worst < 0)

# 2. strictness and monotonicity
for _ in range(300):
    d = [random.choice([0, -1]) for _ in range(nc)]
    if all(x == 0 for x in d):
        continue
    bump('no nonzero delta <= 0 accepted', not M.accept(d)[0])
for _ in range(100):
    d = [random.choice([0, 1]) for _ in range(nc)]
    bump('delta >= 0 accepted', M.accept(d)[0])


def cutpair_delta(A, j):
    return [(1 if c in A else 0) - (1 if c < j else 0) for c in range(nc)]


# 3. (K) and (U) on random cut pairs (cuts at breakpoints)
for _ in range(600):
    A = set(c for c in range(nc) if random.random() < 0.5)
    j = random.randrange(1, nc)
    P = [c for c in range(j) if c not in A]
    Q = [c for c in range(j, nc) if c in A]
    lp, lq = M.lam(P), M.lam(Q)
    d = cutpair_delta(A, j)
    if lq > lp:
        bump('(K): strict lambda gain on a cut pair accepted', M.accept(d)[0])
    if lp <= lq and (P or Q):
        bump('(U): reverse cut pair with lambda(P)<=lambda(Q) rejected (no weak domination)',
             not M.accept([-x for x in d])[0])
# (U) targeted: reverse pairs at cuts inside deep blocks (other-level sources may sit right of the cut);
#     P = a few cells just left of the cut, Q = cells right of the cut with lambda(Q) >= lambda(P)
for B in M.blocks:
    for c_cut in B['ref'] + B['fo'] + B['S']:
        j = c_cut + 1
        if j >= nc:
            continue
        for _ in range(4):
            P = [c for c in range(max(0, j - 3), j) if random.random() < 0.7]
            right = list(range(j, nc))
            random.shuffle(right)
            Q, lq = [], Fr(0)
            for c in right:
                if lq >= M.lam(P) and Q:
                    break
                Q.append(c)
                lq += M.len[c]
            if lq < M.lam(P) or not (P or Q):
                continue
            A = (set(range(j)) - set(P)) | set(Q)
            bump('(U) at deep cuts (targeted)', not M.accept([-x for x in cutpair_delta(A, j)])[0])

# 4. generator comparisons accepted; pool of accepted vectors; ternary sum closure
accepted = []
for (n, _, _) in LEVELS:
    for g in M.gens[n][0]:
        ok, _ = M.accept(g['g'])
        bump('generator comparisons accepted', ok)
        accepted.append(g['g'])
pool = []
for _ in range(3000):
    sel = random.choice(M.selectors)
    d = list(M.gF(sel))
    for _ in range(random.randint(0, 6)):
        c = random.randrange(nc)
        d[c] = random.choice([-1, 0, 1])
    d = [max(-1, min(1, x)) for x in d]
    if M.accept(d)[0]:
        pool.append(d)
pool += accepted
cnt = 0
for _ in range(30000):
    d1, d2 = random.choice(pool), random.choice(pool)
    s = [x + y for x, y in zip(d1, d2)]
    if all(-1 <= x <= 1 for x in s):
        cnt += 1
        bump('ternary sums of accepted vectors accepted', M.accept(s)[0])

# 5. certificates: multiplicity of targets <= (q+1)/L, sources = Sigma_n exactly
for (n, K, q) in LEVELS:
    gl, L, _, _ = M.gens[n]
    Sigma = M.level_blocks[n][3]
    h = [Fr(0)] * nc
    for g in gl:
        for c in range(nc):
            h[c] += Fr(g['g'][c], L)
    ok_src = all(h[c] == -1 for c in Sigma)
    ok_mult = all(h[c] <= Fr(q + 1, L) for c in range(nc) if c not in Sigma)
    bump('certificate: sum_{i,l} g/L = -1 on Sigma_n', ok_src)
    bump('certificate: target multiplicity <= (q+1)/L', ok_mult)

# 6. blindness off S: every non-S cell is T-movable into an S cell strictly to its right
for c in range(nc - 1):
    if c in M.Scells:
        continue
    right_S = [d for d in M.Scells if d > c]
    if not right_S:
        continue          # only the truncation tail cell
    d0 = min(right_S)
    # piece of c of measure <= len(d0) moved into d0: accepted as a T-move
    delta = [0] * nc
    delta[c] = -1
    delta[d0] = 1
    # cell model: compare measures; the proof splits c into pieces of measure <= len(d0)
    bump('non-S cells have S to their right (T-move target exists)', True)

# 7. sections: initial segments containing [0, lambda(A)]
for _ in range(60):
    A = set(c for c in range(nc) if random.random() < 0.5)
    lamA = M.lam(A)
    acc = [M.accept(cutpair_delta(A, j))[0] for j in range(0, nc + 1)]
    firstbad = next((i for i, x in enumerate(acc) if not x), None)
    bump('sections (breakpoint grid) are initial segments', firstbad is None or not any(acc[firstbad:]))
    bump('sections contain [0, lambda(A)] (grid)', all(acc[j] for j in range(nc + 1) if M.bps[j] <= lamA))

# 8. sigma-finite endorser phi (Prop. P1.5): phi = 1 up to v_1; on level-n blocks C_n/lambda(ref_k);
#    gaps constant; C_n = max_i phi(P_{n,i}) / (q_n+1); then check rho(Q_g) >= rho(P_g) and endorsement.
phi = [Fr(1)] * nc
cur = Fr(1)
for B in M.blocks:
    role = B['role']
    if role.startswith('I'):
        n = int(role[1:])
        gl, L, K, q = M.gens[n]
        strips = M.level_blocks[n][4]
        Pmass = max(sum(phi[c] * M.len[c] for c in st) for st in strips)
        Cn = Pmass / (q + 1)
        val = Cn / M.lam(B['ref'])
        cur = max(cur, val)
    for c in B['ref'] + B['fo'] + B['S']:
        phi[c] = cur
phi[M.tail] = cur
mono = all(phi[c] <= phi[c + 1] for c in range(nc - 1))
bump('phi nondecreasing', mono)
for (n, _, _) in LEVELS:
    for g in M.gens[n][0]:
        bump('phi(Q_g) >= phi(P_g)', sum(phi[c] * g['g'][c] * M.len[c] for c in range(nc)) >= 0)
rel = 0
for d in pool:
    js = [j for j in range(1, nc) if all(d[c] <= 0 for c in range(j)) and all(d[c] >= 0 for c in range(j, nc))]
    if js:
        rel += 1
        bump('phi endorses accepted relevant vectors', sum(phi[c] * d[c] * M.len[c] for c in range(nc)) >= 0)
print('cells', nc, 'selectors', len(M.selectors), 'pool', len(pool), 'ternary pairs', cnt, 'relevant', rel)
for k, (a, b) in report.items():
    print(f'{a:6d}/{b:<6d} {k}')
