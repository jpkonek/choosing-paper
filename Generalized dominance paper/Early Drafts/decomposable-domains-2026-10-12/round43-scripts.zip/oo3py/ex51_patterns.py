# OO3: which sign patterns do NN1 Example 5.1's fixed columns realise?
# A_s = {beta in Q^2 : sgn<a_iv,beta> = s_i for all judges v of world i}.
# A found beta is an exact certificate that A_s is nonempty.
from fractions import Fraction as Fr
from itertools import product
W = {1: [(10,10),(10,11),(11,10),(10,12),(12,10),(11,12),(12,11)],
     2: [(-26,7),(-26,8),(-25,7),(-27,7),(-26,6),(-25,8),(-27,6)],
     3: [(7,-26),(8,-26),(7,-25),(7,-27),(6,-26),(8,-25),(6,-27)]}
def sgn(x): return (x>0)-(x<0)
found = {}
R = 60
for x, y in product(range(-R, R+1), repeat=2):
    if (x, y) == (0, 0): continue
    pat = []
    ok = True
    for i in (1,2,3):
        ss = {sgn(a*x+b*y) for (a,b) in W[i]}
        if len(ss) != 1 or 0 in ss: ok = False; break
        pat.append(ss.pop())
    if ok:
        found.setdefault(tuple(pat), (x, y))
for s in sorted(found): print(s, "beta =", found[s])
mixed = [s for s in product((1,-1), repeat=3) if len(set(s)) == 2]
print("mixed patterns realised:", sum(s in found for s in mixed), "of 6")
print("pure patterns realised:", [s for s in found if len(set(s)) == 1])
# Check the exact statement of NN2 Prop 6.3 step 3 on these columns: if all six
# mixed pattern cones are nonempty, fixed-column realisations near T1 fail (QS).
print("ALL SIX" if all(s in found for s in mixed) else "NOT ALL SIX")
