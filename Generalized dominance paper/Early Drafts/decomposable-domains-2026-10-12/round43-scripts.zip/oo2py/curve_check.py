# OO2, exact check of the one-parameter construction (Section 2 of OO2_notes.md).
# Exact rational arithmetic only (fractions.Fraction). Run: python3 -I curve_check.py
from fractions import Fraction as Fr
import random

random.seed(20261019)
ONE3 = Fr(1, 3)
O = (Fr(-1), Fr(0), Fr(2))          # homothety centre
d = (Fr(1), Fr(0), Fr(-1))          # weight direction
u = (ONE3, ONE3, ONE3)

def dot(a, b):
    return sum(x * y for x, y in zip(a, b))

def sgn(x):
    return (x > 0) - (x < 0)

def setup(eps):
    c0 = (1 - eps) / 3
    v = [tuple(c0 + (eps if j == k else 0) for j in range(3)) for k in range(3)]
    eta = c0 / (4 * (c0 + 2))
    return c0, v, eta

def P_T1(g, v):
    return min(dot(vk, g) for vk in v)

def K_vertices(rho, v):
    return [tuple((1 - rho) * O[j] + rho * vk[j] for j in range(3)) for vk in v]

def P_K(rho, g, v):
    return min(dot(m, g) for m in K_vertices(rho, v))

def lam(rho):
    return tuple(u[j] + (rho - 1) * d[j] for j in range(3))

def sigma(g, v):
    """The single switch field of Section 2. Returns (sigma, kind)."""
    if all(x > 0 for x in g) or all(x < 0 for x in g):
        return tuple(g), 'pure'
    P = P_T1(g, v)
    D = P - dot(O, g)
    n1 = sum(abs(x) for x in g)
    g1, g2, g3 = g
    feas, s = True, None
    if g1 > 0 and g3 > 0:
        s = max(abs(D) / 2, 3 * P / 2) + n1
    elif g1 < 0 and g3 < 0:
        s = min(-abs(D) / 2, 3 * P / 2) - n1
    else:
        if g1 > 0:   # g3 < 0
            lo, hi = -D / 2, D / 2
        else:        # g1 < 0 < g3
            lo, hi = D / 2, -D / 2
        if g2 > 0:
            hi = min(hi, 3 * P / 2)
        else:
            lo = max(lo, 3 * P / 2)
        if lo < hi:
            s = (lo + hi) / 2
        else:
            feas = False
    if feas:
        return (s + D / 2, 3 * P - 2 * s, s - D / 2), 'exact'
    Sp = sum(x for x in g if x > 0)
    Sm = sum(-x for x in g if x < 0)
    if P > 0:
        M = 1 + 2 * Sm / Sp
        return tuple(M * x if x > 0 else x for x in g), 'dominant+'
    M = 1 + 2 * Sp / Sm
    return tuple(x if x > 0 else M * x for x in g), 'dominant-'

def rand_fr(k=60):
    return Fr(random.randint(-k, k), random.randint(1, k))

def run(eps):
    c0, v, eta = setup(eps)
    ok = True
    # (a) parameter facts
    assert eta < c0 / (c0 + 2) and eta < Fr(1, 9)
    for rho in (1 - eta, 1 + eta):
        for m in K_vertices(rho, v):
            assert all(x > 0 for x in m) and sum(m) == 1
        assert all(x > 0 for x in lam(rho))
    # (b) samples: random gambles, and gambles near the boundaries of K(rho0)
    counts = {}
    nsamp = 0
    for t in range(6000):
        if t % 2 == 0:
            g = tuple(rand_fr() for _ in range(3))
        else:
            # a point near the boundary of D_{K(rho0)}: take random h, shift along 1
            rho0 = 1 - eta + 2 * eta * Fr(random.randint(0, 1000), 1000)
            h = tuple(rand_fr() for _ in range(3))
            sh = P_K(rho0, h, v)          # P_K(h - s*1) = P_K(h) - s
            pert = Fr(random.randint(-5, 5), 10 ** random.randint(2, 6))
            g = tuple(h[j] - sh + pert for j in range(3))
        if any(x == 0 for x in g) or P_T1(g, v) == 0:
            continue
        sg, kind = sigma(g, v)
        counts[kind] = counts.get(kind, 0) + 1
        # sign pattern of the switch values
        if any(sgn(sg[j]) != sgn(g[j]) for j in range(3)):
            print('SIGN FAIL', eps, g, sg, kind); ok = False
        if kind == 'exact':
            P = P_T1(g, v)
            if dot(u, sg) != P or dot(d, sg) != P - dot(O, g):
                print('EXACT FAIL', eps, g); ok = False
        else:
            # Lemma 2.2: no zero of f_g on the closed interval J
            f_lo, f_hi = P_K(1 - eta, g, v), P_K(1 + eta, g, v)
            if not (sgn(f_lo) == sgn(f_hi) != 0):
                print('LEMMA FAIL', eps, g, kind); ok = False
        # certificate: sign agreement at random rho in J and at the endpoints
        rhos = [1 - eta, 1 + eta, Fr(1)] + [1 - eta + 2 * eta * Fr(random.randint(0, 997), 997) for _ in range(4)]
        for rho in rhos:
            a, b = dot(lam(rho), sg), P_K(rho, g, v)
            if b != 0 and sgn(a) != sgn(b):
                print('CERT FAIL', eps, g, rho, kind); ok = False
            if kind == 'exact' and a != b:
                print('IDENTITY FAIL', eps, g, rho); ok = False
        nsamp += 1
    print(f'eps={eps}: c0={c0}, eta={eta}, samples={nsamp}, kinds={counts}')
    return ok

allok = True
for eps in (Fr(1, 10), Fr(3, 10), Fr(1, 2)):
    allok &= run(eps)
print('ALL CHECKS PASSED' if allok else 'SOME CHECK FAILED')
