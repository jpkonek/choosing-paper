# OO2, Proposition 3.4 step (d=3 case): the images under x(g) = (1-eps) g + eps*min(g)*1 of the
# two plane pieces {g_i = 0} near the two crossing rays of coordinate i on dT1 span different planes.
# Symbolic in eps (sympy), plus the crossing rays themselves. Run: python3 -I planes_check.py
import sympy as sp
eps = sp.symbols('epsilon', positive=True)
c0 = (1 - eps) / 3
kap = (1 + 2 * eps) / (1 - eps)
E = sp.eye(3)
ok = True
for i in range(3):
    others = [k for k in range(3) if k != i]
    normals = []
    for k in others:
        l = [m for m in others if m != k][0]
        # crossing ray of coordinate i on facet k: w_k = -1, w_i = 0, w_l = kappa
        w = sp.zeros(3, 1); w[k] = -1; w[l] = kap
        vk = sp.Matrix([c0 + (eps if j == k else 0) for j in range(3)])
        vl = sp.Matrix([c0 + (eps if j == l else 0) for j in range(3)])
        vi = sp.Matrix([c0 + (eps if j == i else 0) for j in range(3)])
        # w on facet k: v_k.w = 0, v_j.w >= 0
        ok &= sp.simplify(vk.dot(w)) == 0
        ok &= all(sp.simplify(vv.dot(w)).subs(eps, sp.Rational(3, 10)) > 0 for vv in (vl, vi))
        # linear map of x on the min-cell M_k, restricted to the plane g_i = 0: basis e_k, e_l
        xk = (1 - eps) * E[:, k] + eps * sp.ones(3, 1)
        xl = (1 - eps) * E[:, l]
        n = xk.cross(xl)
        normals.append(sp.simplify(n / n.norm()) if False else sp.simplify(n))
    n1, n2 = normals
    cr = sp.simplify(n1.cross(n2))
    differ = any(sp.simplify(c) != 0 for c in cr)
    print(f'coordinate {i+1}: normals {list(n1)} and {list(n2)}; planes differ: {differ}')
    ok &= differ
print('ALL CHECKS PASSED' if ok else 'SOME CHECK FAILED')
