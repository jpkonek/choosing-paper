# NUMERICS ONLY (illustration for OO2 Section 3; nothing is proved from this file).
# Searches for 12 vectors J_iv = (A_iv in R^4, b_iv in R^2) with xi in the open cone of every branch
# (2 of 4 per world). Lemma 3.3 of OO2_notes.md proves no such configuration exists (dimension 6 > 3).
# b_iv constrained to an open sector of half-width < 30 deg around beta_i (120 deg apart).
import numpy as np, itertools, sys
rng = np.random.default_rng(int(sys.argv[1]) if len(sys.argv) > 1 else 0)
eps = 0.3; c0 = (1 - eps) / 3
xi = np.array([c0, c0, c0, eps, 0, 0])
pairs = list(itertools.combinations(range(4), 2))
branches = list(itertools.product(pairs, repeat=3))
ang0 = np.deg2rad([90, 210, 330])

def build(params):
    A = params[:48].reshape(3, 4, 4)
    th = params[48:60].reshape(3, 4)
    rad = np.exp(params[60:72].reshape(3, 4))
    J = np.zeros((3, 4, 6))
    for i in range(3):
        for v in range(4):
            a = ang0[i] + np.deg2rad(28) * np.tanh(th[i, v])
            J[i, v, :4] = A[i, v]
            J[i, v, 4:] = rad[i, v] * np.array([np.cos(a), np.sin(a)])
    return J

def score(J):
    worst = np.inf
    for br in branches:
        M = np.array([J[i, v] for i in range(3) for v in br[i]])  # 6x6 rows
        try:
            w = np.linalg.solve(M.T, xi)
        except np.linalg.LinAlgError:
            return -np.inf
        m = w.min() / (np.abs(w).sum())
        worst = min(worst, m)
    return worst

best = None
for restart in range(40):
    p = rng.normal(size=72)
    s = score(build(p))
    step = 0.5
    for it in range(3000):
        q = p + step * rng.normal(size=72) * (rng.random(72) < 0.2)
        t = score(build(q))
        if t > s:
            p, s = q, t
        if it % 500 == 499:
            step *= 0.7
    print(restart, s, flush=True)
    if best is None or s > best[0]:
        best = (s, p.copy())
    if s > 0.02:
        break
np.save('best_params.npy', best[1])
print('best', best[0])
