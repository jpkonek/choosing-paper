# OO1: exact check that pattern counting gives no neutral rival in rank 3.
# Fixed columns a_iv in Q^3 (n=7 judges per world), six mixed-pattern vectors x_s in Q^3,
# and f in Q^3 with <f,x_s> > 0 for all six s (so the x_s are not positively dependent).
# Also: every branch (3-subsets per world) has F-restricted pattern vectors of rank 3.
from fractions import Fraction as Fr
from itertools import combinations, product

n, b = 7, 3
def e(i): return [Fr(int(i == k)) for k in range(3)]
# columns: a_iv = e_i + (k/50)*(e_{i+1} - e_{i+2}) + (k*k/400)*e_{i+1}, k = -3..3
A = {}
for i in range(3):
    for v, k in enumerate(range(-3, 4)):
        col = e(i)
        col[(i+1) % 3] += Fr(k, 50) + Fr(k*k, 400)
        col[(i+2) % 3] -= Fr(k, 50)
        A[(i, v)] = col
def dot(x, y): return sum(p*q for p, q in zip(x, y))
pats = [s for s in product((1, -1), repeat=3) if len(set(s)) == 2]
X = {}
for s in pats:
    # dominant positive entries: +10 on positive worlds, -1 on negative worlds
    X[s] = [Fr(10) if si > 0 else Fr(-1) for si in s]
ok = True
# 1. signs: sgn<a_iv, x_s> = s_i for every judge and pattern
for s in pats:
    for (i, v), col in A.items():
        val = dot(col, X[s])
        if (val > 0) != (s[i] > 0) or val == 0:
            ok = False; print("sign failure", s, i, v, val)
print("1. strict world signs for all 21 columns x 6 patterns:", ok)
# 2. pointedness: f = (1,1,1)
f = [Fr(1)]*3
vals = {s: dot(f, X[s]) for s in pats}
pt = all(v > 0 for v in vals.values())
print("2. <f,x_s> =", {s: str(v) for s, v in vals.items()}, " all > 0:", pt)
ok &= pt
# 3. no two columns proportional within a world
def prop(x, y):
    return all(x[a]*y[c] == x[c]*y[a] for a in range(3) for c in range(3))
np_ok = all(not prop(A[(i, v)], A[(i, w)]) for i in range(3) for v, w in combinations(range(n), 2))
print("3. no two columns of one world proportional:", np_ok)
ok &= np_ok
# 4. every branch: the F-restricted pattern vectors (6 vectors in Q^{9}) have rank 3
def rank(M):
    M = [r[:] for r in M]; r = 0; cols = len(M[0])
    for c in range(cols):
        piv = next((k for k in range(r, len(M)) if M[k][c] != 0), None)
        if piv is None: continue
        M[r], M[piv] = M[piv], M[r]
        for k in range(len(M)):
            if k != r and M[k][c] != 0:
                fct = M[k][c] / M[r][c]
                M[k] = [a - fct*bb for a, bb in zip(M[k], M[r])]
        r += 1
    return r
cnt = 0; rk_ok = True
for F in product(*[list(combinations(range(n), b)) for _ in range(3)]):
    rows = [[dot(A[(i, v)], X[s]) for i in range(3) for v in F[i]] for s in pats]
    if rank(rows) != 3: rk_ok = False
    cnt += 1
print("4. branches checked:", cnt, " all F-restricted ranks = 3:", rk_ok)
ok &= rk_ok
print("ALL CHECKS PASSED" if ok else "SOME CHECK FAILED")
