"""CC2 geometry checks (exact rational arithmetic).

(A) Rank-weighted Brier field with weights (0, s, b, c) on (good, silent, bad, contradictory),
    kappa := (b - s)/s >= 1.  Its pointwise q-Bayes advice is compared with the advice of the
    coherent model D_{R(q)}, R(q) := conv{ normalise(q * t) : t in {1,kappa}^3 } (density-ratio class).
(B) On the boundary of the simplex R(q) equals the posterior nu(q * T1) when kappa = (1+2eps)/(1-eps).
(C) At u: T1 is contained in R(u) (hexagon); D_T1 minus D_R(u) is the union of the three corner wedges
    Gamma_l; Gamma_3 lies in the closed sign class (-,-,+) and, in the chart h = h3(-x,-y,1), equals
    {x + y >= 1/kappa, kappa*max(x,y) + min(x,y) < 1}.
(D) The corner inequality used in Theorem CC2.R:
       (1/(kappa x) - 1)(1/(kappa y) - 1) < 1   iff   x + y > 1/kappa      (for 0 < kappa x, kappa y < 1)
    checked symbolically.
Run: python3 -I geometry.py
"""
from fractions import Fraction as F
import itertools, random

random.seed(20261017)

def P(K, h):
    return min(sum(m[i] * h[i] for i in range(3)) for m in K)

def advice_model(K, h):
    # coherent model D_K: accept h if P_K(h) > 0, accept -h if P_K(-h) > 0, else silent
    a, b = P(K, h) > 0, P(K, [-x for x in h]) > 0
    if a and b:
        return 'x'
    return '+' if a else ('-' if b else '0')

def bayes_advice(q, h, s, b, c):
    # penalty at world k: lam(rank)*|h_k|; ranks: accept h good if h_k>0
    cost = {}
    for a in ['+', '0', '-', 'x']:
        tot = F(0)
        for k in range(3):
            if a == '0':
                lam = s
            elif a == 'x':
                lam = c
            elif a == '+':
                lam = 0 if h[k] > 0 else b
            else:
                lam = 0 if h[k] < 0 else b
            tot += q[k] * lam * abs(h[k])
        cost[a] = tot
    m = min(cost.values())
    best = [a for a in cost if cost[a] == m]
    return best[0] if len(best) == 1 else None

def ratio_class(q, kappa):
    pts = []
    for t in itertools.product([F(1), kappa], repeat=3):
        v = [q[i] * t[i] for i in range(3)]
        z = sum(v)
        if z == 0:
            continue
        pts.append([x / z for x in v])
    return pts

def rand_q(boundary=None):
    if boundary is None:
        a = [F(random.randint(1, 60)) for _ in range(3)]
    else:
        a = [F(random.randint(1, 60)) for _ in range(3)]
        a[boundary] = F(0)
    z = sum(a)
    return [x / z for x in a]

def rand_h():
    return [F(random.randint(-400, 400), random.randint(1, 50)) for _ in range(3)]

out = []
# (A)
bad = 0; tested = 0
for (s, b) in [(F(1), F(3)), (F(1), F(4)), (F(2), F(7)), (F(1), F(11, 5))]:
    c = b + 1
    kappa = (b - s) / s
    for _ in range(4000):
        q = rand_q(None if random.random() < 0.7 else random.randint(0, 2))
        h = rand_h()
        if any(x == 0 for x in h):
            continue
        ba = bayes_advice(q, h, s, b, c)
        if ba is None:
            continue
        tested += 1
        if ba != advice_model(ratio_class(q, kappa), h):
            bad += 1
out.append(f"(A) Bayes advice of rank-weighted Brier vs D_R(q): {tested} tests, {bad} mismatches")

# (B), (C)
for eps in [F(1, 10), F(3, 10), F(1, 2), F(4, 5)]:
    kappa = (1 + 2 * eps) / (1 - eps)
    c0 = (1 - eps) / 3
    T1 = [[c0 + (eps if i == k else 0) for i in range(3)] for k in range(3)]
    # (B) boundary: R(q) vs posterior, compared through acceptance on random gambles
    mism = 0; nb = 0
    for _ in range(3000):
        j = random.randint(0, 2)
        q = rand_q(j)
        post = []
        for m in T1:
            v = [q[i] * m[i] for i in range(3)]
            z = sum(v)
            post.append([x / z for x in v])
        h = rand_h()
        nb += 1
        if (P(ratio_class(q, kappa), h) > 0) != (P(post, h) > 0):
            mism += 1
    # interior: posterior strictly smaller acceptance region?  R(q) contains posterior: D_R subset D_post
    viol = 0; strict = 0; ni = 0
    for _ in range(3000):
        q = rand_q()
        post = []
        for m in T1:
            v = [q[i] * m[i] for i in range(3)]
            z = sum(v)
            post.append([x / z for x in v])
        h = rand_h(); ni += 1
        aR, aP = P(ratio_class(q, kappa), h) > 0, P(post, h) > 0
        if aR and not aP:
            viol += 1
        if aP and not aR:
            strict += 1
    # (C) corner wedges at u
    u = [F(1, 3)] * 3
    H = ratio_class(u, kappa)
    wedge_bad = 0; nwedge = 0; chart_bad = 0
    for _ in range(20000):
        h = rand_h()
        if any(x == 0 for x in h):
            continue
        inT = P(T1, h) > 0
        inH = P(H, h) > 0
        if inH and not inT:
            wedge_bad += 1   # H must be inside T1
        if inT and not inH:
            nwedge += 1
            # must lie in a closed sign class with exactly one positive coordinate
            pos = [i for i in range(3) if h[i] > 0]
            if len(pos) != 1:
                wedge_bad += 1
            l = pos[0] if len(pos) == 1 else None
            if l is not None:
                o = [i for i in range(3) if i != l]
                x, y = -h[o[0]] / h[l], -h[o[1]] / h[l]
                if not (x + y >= 1 / kappa and kappa * max(x, y) + min(x, y) < 1):
                    chart_bad += 1
    # chart description converse
    conv_bad = 0
    for _ in range(5000):
        x = F(random.randint(1, 999), 1000) / kappa
        y = F(random.randint(1, 999), 1000) / kappa
        h = [-x, -y, F(1)]
        inT = P(T1, h) > 0; inH = P(H, h) > 0
        pred = (x + y >= 1 / kappa) and (kappa * max(x, y) + min(x, y) < 1)
        if (inT and not inH) != pred:
            conv_bad += 1
    # crossing rays on boundary of both cones
    w21 = [F(-1), F(0), kappa]
    rays = f"P_T1(w21)={P(T1, w21)}, P_H(w21)={P(H, w21)}"
    out.append(f"eps={eps}, kappa={kappa}: (B) boundary mismatches {mism}/{nb}; interior: D_R not subset D_post {viol}/{ni}, D_post strictly larger {strict}/{ni}; "
               f"(C) H in T1 and wedge-in-one-sign-class failures {wedge_bad} (wedge samples {nwedge}), chart formula failures {chart_bad}, converse {conv_bad}/5000; {rays}")

# (D) symbolic
import sympy as sp
x, y, k = sp.symbols('x y k', positive=True)
expr = sp.simplify((1 / (k * x) - 1) * (1 / (k * y) - 1) - 1)
num = sp.factor(sp.together(expr))
out.append(f"(D) (1/(kx)-1)(1/(ky)-1) - 1 = {num}   [sign = sign of 1 - k(x+y)]")

print("\n".join(out))
