"""CC2 corner seed at world 3 inside the corner wedge Gamma_3 of T1 (exact rational arithmetic).

Chart of the sign class Q3+ = {h1, h2 < 0 < h3}:  h = h3 * (-x, -y, 1),  (x, y) in (0, oo)^2.
A coherent model D_K accepts h in Q3+ iff (x, y) lies in the open convex down-set
   {(x, y) : m3 - m1 x - m2 y > 0 for all m in K}.
Gamma_3 = {x + y >= 1/kappa, kappa max + min < 1} (geometry.py, (C)).

Construction (eps = 3/10):
 * ten cell centres P_S, S a 2-subset of {0,...,4}, on a strictly convex (outward bulging) arc inside Gamma_3;
 * for k = 0..4 the base B_k := D_{K_k}, K_k := conv(T1 u N_k), N_k = normals of the chords of
   conv{P_S : k in S} (consecutive in x) plus two end cuts of slopes -kappa and -1/kappa through the
   extreme points; its trace on the ten centres is exactly C_k = {S : k in S}; K_k contains T1, so B_k is
   a coherent model contained in D_T1;
 * comparison k at world 3:  B_k <=_3 X_k,  X_k := B_k with the C_k-cells silenced and the other six
   cells accepted.  World-3 error vector g_k = +1 on C_k, -1 on the other six cells.
Checks: (i) traces; (ii) whether N_k lies inside the hexagon R(u) (reported; it does NOT for this choice, so the
B_k are not sandwiched between D_R(u) and D_T1), and the trace margin; (iii) sum_k g_k = -1 (a certificate:
sum <= 0 and != 0); (iv) pairwise overlaps of the
positive parts; (v) the composition closure of {g_k} and all nonnegative ternary vectors on the ten-cell algebra
contains no nonzero nonpositive vector (exhaustive).
Run: python3 -I seed.py
"""
from fractions import Fraction as F
import itertools

eps = F(3, 10)
kappa = (1 + 2 * eps) / (1 - eps)
c0 = (1 - eps) / 3
T1 = [[c0 + (eps if i == k else 0) for i in range(3)] for k in range(3)]
Ru = []
for t in itertools.product([F(1), kappa], repeat=3):
    z = sum(t)
    Ru.append([x / z for x in t])

def acc(K, x, y):
    return min(m[2] - m[0] * x - m[1] * y for m in K) > 0

def in_T1(x, y):
    return acc(T1, x, y)

def in_H(x, y):
    return acc(Ru, x, y)

# arc: exact rational points on the circle of radius r about the origin, angles in about [27, 63] degrees
r = F(37, 100)
def circ(t):                       # rational parametrisation, angle = 2 atan t
    return (r * (1 - t * t) / (1 + t * t), r * 2 * t / (1 + t * t))
import math
angs = [27 + 4 * i for i in range(10)]          # degrees, increasing: x decreasing, y increasing
ts = [F(math.tan(math.radians(a) / 2)).limit_denominator(10**6) for a in angs]
subsets = list(itertools.combinations(range(5), 2))
pts = {S: circ(ts[i]) for i, S in enumerate(subsets)}
out = []
ok_wedge = all(in_T1(*p) and not in_H(*p) for p in pts.values())
out.append(f"kappa = {kappa}; all ten centres in the interior of Gamma_3: {ok_wedge}")

def normal_of(p, q):
    # line a x + b y = 1 through p, q
    (x1, y1), (x2, y2) = p, q
    det = x1 * y2 - x2 * y1
    a = (y2 - y1) / det; b = (x1 - x2) / det
    return (a, b)

Ks = []; all_ok = True; inH_all = True; margins = []
LAM = 1 + F(1, 10**5)
for k in range(5):
    S_k = sorted([pts[S] for S in subsets if k in S], key=lambda p: p[0])
    lines = []
    for p, q in zip(S_k, S_k[1:]):
        a, b = normal_of(p, q)
        lines.append((a, b, LAM))
    pr = S_k[-1]; pl = S_k[0]                 # rightmost (largest x), leftmost
    lines.append((kappa, F(1), (kappa * pr[0] + pr[1]) * LAM))
    lines.append((F(1), kappa, (pl[0] + kappa * pl[1]) * LAM))
    normals = []
    for (a, b, c) in lines:
        if not (a > 0 and b > 0 and c > 0):
            all_ok = False
        z = a + b + c
        normals.append([a / z, b / z, c / z])
    K = T1 + normals
    Ks.append(K)
    trace = [S for S in subsets if acc(K, *pts[S])]
    want = [S for S in subsets if k in S]
    if sorted(trace) != sorted(want):
        all_ok = False
        out.append(f"  base {k}: trace {trace} != {want}")
    for S in subsets:
        x, y = pts[S]
        margins.append(abs(min(m[2] - m[0] * x - m[1] * y for m in K)))
    for m in normals:
        if any(m[i] > kappa * m[j] for i in range(3) for j in range(3)):
            inH_all = False
out.append(f"(i) traces exact for all five bases: {all_ok}")
out.append(f"(ii) all cut normals in the hexagon R(u) (so T1 <= K_k <= R(u)): {inH_all}; min |margin| at centres = {float(min(margins)):.3e} (cells of chart radius < margin/4 have the same trace)")

# certificate on the ten cells (unit masses; any positive masses work since the sum is -1 cellwise)
g = []
for k in range(5):
    g.append(tuple(1 if k in S else -1 for S in subsets))
tot = [sum(gk[i] for gk in g) for i in range(10)]
out.append(f"(iii) sum_k g_k cellwise = {tot}")
ov = all(any(g[k][i] == 1 and g[l][i] == 1 for i in range(10)) for k in range(5) for l in range(5) if k != l)
out.append(f"(iv) every two positive parts overlap (in the cell {{k,l}}): {ov}")

# (v) exhaustive closure on {-1,0,1}^10
gens = set(g)
nonneg = [v for v in itertools.product([0, 1], repeat=10)]
def ternary_sum(a, b):
    s = tuple(x + y for x, y in zip(a, b))
    return s if all(-1 <= x <= 1 for x in s) else None
closure = set(nonneg) | gens
frontier = set(closure)
while frontier:
    new = set()
    for a in frontier:
        for b in list(closure):
            for s in (ternary_sum(a, b), ternary_sum(b, a)):
                if s is not None and s not in closure:
                    new.add(s)
    closure |= new
    frontier = new
bad = [v for v in closure if all(x <= 0 for x in v) and any(x < 0 for x in v)]
out.append(f"(v) closure size {len(closure)}; nonzero nonpositive vectors in it: {len(bad)}")
out.append("Centres (x, y): " + "; ".join(f"{S}:({float(p[0]):.4f},{float(p[1]):.4f})" for S, p in pts.items()))
print("\n".join(out))
