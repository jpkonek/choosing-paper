"""CC3 referee sanity checks for BB2 (NUMERICS only; no verdict in CC3_referee.md rests on them).

Run from inside this folder:  python3 -I cc3_checks.py > cc3_checks.out

(1) Sign patterns of tie vectors (BB2 §1, Lemma 2.1(e)): for random strictly guiding
    penalties on a mixed pair, c and d carry the pattern of g, c' carries the opposite one.
(2) Reject cell dichotomy (BB2 Lemma 2.5(c), M3.6(c)): W(h) = {c'.q >= 0, d.q <= 0} in aff Delta
    is either empty or has interior (LP with a slack variable).
(3) Corner algebra (write-up Prop T1, BB2 Cor 3.5(c)): c_1(r12) and c_2(r12) are positively
    proportional iff x1 + 1/x2 = kappa + 1; the cyclic system has only x1=x2=x3 in {x+, x-}.
(4) Sandwich with a lower semicontinuous profile (BB2 §3.3 Step 7; write-up Lemma sandwich):
    f(y, x) = phi(x / (R - y)) for x >= 0 (mirror for x < 0), R >= r, phi nondecreasing,
    lower semicontinuous, with jumps.  Its strict and weak level sets in B are half-planes and
    f = 0 on the chord.  Check the EXACT bounds D+(x r/(r+|y|)) <= f(q) <= D+(x r/(r-|y|)),
    including points placed exactly at the preimages of jumps.
(5) Audit repair (Lemma 2.0 in CC3): toy one-pair-type field where the q-optimum is unique
    off a line; approach a fixed q off the line by random q_n and check that the advice
    converges pointwise (margin argument), i.e. the exceptional set {margin <= 2|q_n-q| env}
    shrinks to null.
"""
import numpy as np
from scipy.optimize import linprog

rng = np.random.default_rng(20261017)


def random_guiding_penalties(g):
    """Penalties l_k(a) for a in (accept g, silence, accept -g, x), strictly increasing in
    world-k rank: at g_k>0 the order is +g < 0 < -g < x; at g_k<0 it is -g < 0 < +g < x."""
    L = np.zeros((4, 3))  # rows: +g, 0, -g, x
    for k in range(3):
        steps = np.cumsum(rng.exponential(size=4)) * 10 ** rng.uniform(-2, 2)
        if g[k] > 0:
            L[0, k], L[1, k], L[2, k], L[3, k] = steps
        else:
            L[2, k], L[1, k], L[0, k], L[3, k] = steps
    return L


def check_patterns(trials=20000):
    bad = 0
    for _ in range(trials):
        g = rng.normal(size=3)
        if np.all(g > 0) or np.all(g < 0):
            continue
        L = random_guiding_penalties(g)
        c = L[1] - L[0]
        cp = L[1] - L[2]
        d = L[2] - L[0]
        s = np.sign(g)
        if not (np.all(np.sign(c) == s) and np.all(np.sign(d) == s) and np.all(np.sign(cp) == -s)):
            bad += 1
    return bad


def W_nonempty_interior(cp, d):
    # variables (q1, q2, q3, t); q in aff Delta (sum = 1); maximise t subject to
    # -cp.q + t <= 0, d.q + t <= 0, |q| bounded.
    A_ub = np.array([np.append(-cp, 1.0), np.append(d, 1.0)])
    b_ub = np.zeros(2)
    A_eq = np.array([[1.0, 1.0, 1.0, 0.0]])
    b_eq = np.array([1.0])
    bounds = [(-50, 50)] * 3 + [(None, 1.0)]
    res = linprog(c=[0, 0, 0, -1.0], A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq, bounds=bounds)
    if res.status != 0:
        return None
    return -res.fun  # max slack t


def check_reject_cells(trials=20000):
    nonempty = 0
    thin = 0
    for _ in range(trials):
        g = rng.normal(size=3)
        if np.all(g > 0) or np.all(g < 0):
            continue
        L = random_guiding_penalties(g)
        cp = L[1] - L[2]
        d = L[2] - L[0]
        t = W_nonempty_interior(cp, d)
        if t is None:
            continue
        if t >= 0:
            nonempty += 1
            if t < 1e-9:
                thin += 1
    return nonempty, thin


def check_corner_fixed_points(n=5000):
    """Exact: phi(t) = kappa+1-1/t has matrix M = [[kappa+1,-1],[1,0]]; the fixed points of
    phi^3 are the roots of c x^2 + (d-a) x - b = 0 for M^3 = [[a,b],[c,d]]."""
    bad = 0
    for _ in range(n):
        eps = rng.uniform(0.001, 0.999)
        kappa = (1 + 2 * eps) / (1 - eps)
        M = np.array([[kappa + 1, -1.0], [1.0, 0.0]])
        M3 = M @ M @ M
        a, b, c, d = M3[0, 0], M3[0, 1], M3[1, 0], M3[1, 1]
        roots = np.roots([c, d - a, -b])
        xp = ((kappa + 1) + np.sqrt((kappa + 1) ** 2 - 4)) / 2
        xm = 1 / xp
        if not (np.all(np.isreal(roots)) and
                sorted(np.real(roots)) == sorted(np.real(roots)) and
                np.allclose(sorted(np.real(roots)), sorted([xm, xp]), rtol=1e-7)):
            bad += 1
    return bad


def make_phi():
    jumps = np.sort(rng.uniform(0.01, 0.4, size=rng.integers(1, 5)))
    sizes = rng.exponential(size=len(jumps)) * 0.3
    slope = rng.uniform(0.5, 2.0)

    def phi(s):
        s = np.asarray(s, dtype=float)
        # lower semicontinuous nondecreasing: value at a jump point is the lower one (strict >)
        return slope * s + np.sum(sizes[None, :] * (s[..., None] > jumps[None, :]), axis=-1)

    return phi, jumps


def check_sandwich(trials=400, pts=400):
    r = 1.0
    bad = 0
    tested = 0
    for _ in range(trials):
        R = r * (1 + rng.choice([0.0, rng.exponential()]))  # R = r allowed (pencil at chord end)
        sgn = rng.choice([-1.0, 1.0])  # pencil on either side
        phi, jumps = make_phi()

        def f(y, x):
            return phi(x / (R - sgn * y))

        def Dp(s):
            return f(0.0, s)

        ys = rng.uniform(-r / 2, r / 2, size=pts)
        xs = rng.uniform(1e-4, 0.15, size=pts)
        # add points exactly at jump preimages of the upper and lower bound arguments
        extra_y = rng.uniform(-r / 2, r / 2, size=2 * len(jumps))
        extra_x = []
        for j, J in enumerate(jumps):
            yv = extra_y[2 * j]
            extra_x.append(J * (r - abs(yv)) / r)  # upper argument hits the jump
            yv2 = extra_y[2 * j + 1]
            extra_x.append(J * (r + abs(yv2)) / r)  # lower argument hits the jump
        ys = np.concatenate([ys, extra_y])
        xs = np.concatenate([xs, np.array(extra_x)])
        for y, x in zip(ys, xs):
            if x <= 0 or x > 0.2:
                continue
            tested += 1
            lo = Dp(x * r / (r + abs(y)))
            up = Dp(x * r / (r - abs(y)))
            val = f(y, x)
            if not (lo <= val + 1e-12 and val <= up + 1e-12):
                bad += 1
    return tested, bad


def check_margin_repair(trials=200, ngam=4000):
    """Toy: gambles g with two candidate advices whose loss difference is v(g).q with v(g) random
    mixed; at a fixed q (no tie at q for a.e. g) and q_n -> q, the advice at q_n agrees with the
    advice at q off {margin <= C |q_n - q| env}; check the mismatch fraction tends to 0."""
    fracs = []
    for _ in range(trials):
        V = rng.normal(size=(ngam, 3)) * np.exp(rng.normal(size=(ngam, 1)))
        q = rng.dirichlet(np.ones(3))
        base = np.sign(V @ q)
        out = []
        for h in (1e-1, 1e-2, 1e-3, 1e-4):
            dq = rng.normal(size=3)
            dq -= dq.mean()
            dq *= h / np.linalg.norm(dq)
            out.append(np.mean(np.sign(V @ (q + dq)) != base))
        fracs.append(out)
    return np.mean(np.array(fracs), axis=0)


def main():
    print("CC3 referee checks (NUMERICS). seed 20261017")
    print(f"(1) tie-vector patterns, 20000 random mixed pairs: {check_patterns()} failures")
    ne, thin = check_reject_cells()
    print(f"(2) reject cells W(h): {ne} nonempty, of which {thin} with empty interior (must be 0)")
    bad_equiv = 0
    for _ in range(5000):
        eps = rng.uniform(0.01, 0.99)
        kappa = (1 + 2 * eps) / (1 - eps)
        x2 = np.exp(rng.normal())
        r = np.array([-1.0, -1.0, kappa + 1])
        for x1 in (np.exp(rng.normal()), kappa + 1 - 1 / x2):
            if x1 <= 0:
                continue
            c1 = np.array([-(x1 * r[1] + r[2]), x1 * r[1], r[2]])
            c2 = np.array([r[0], -(r[0] + x2 * r[2]), x2 * r[2]])
            prop = np.linalg.norm(np.cross(c1, c2)) < 1e-8 * np.linalg.norm(c1) * np.linalg.norm(c2) and c1 @ c2 > 0
            eq = abs(x1 + 1 / x2 - (kappa + 1)) < 1e-9
            if prop != eq:
                bad_equiv += 1
    print(f"(3a) corner proportionality <=> x1 + 1/x2 = kappa+1: {bad_equiv} failures in 10000 tests")
    print(f"(3b) positive fixed points of phi^3 are exactly x+-: {check_corner_fixed_points()} failures in 5000 kappas (exact quadratic)")
    t, b = check_sandwich()
    print(f"(4) exact sandwich for lsc jump profiles (pencil through a point of the line at distance >= r): {t} points, {b} failures")
    fr = check_margin_repair()
    print("(5) audit repair, mismatch fraction of the advice at |q_n - q| = 1e-1,1e-2,1e-3,1e-4: "
          + ", ".join(f"{x:.5f}" for x in fr))


if __name__ == "__main__":
    main()
