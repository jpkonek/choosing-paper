# LP search for a K4 seed configuration.
# Models B_k = D_{K_k}, K_k = co(K' u V_k) (V_k = extra vertices). Cell direction h in U realises
# world-1 correctness pattern S (set of k correct at world 1) robustly (margin).
import numpy as np, itertools, sys
from scipy.optimize import linprog
eps=0.3; s=0.9; u=np.ones(3)/3
T1=np.array([(1-eps)*u+eps*np.eye(3)[k] for k in range(3)])
Kp=u+s*(T1-u)
pairs=list(itertools.combinations(range(4),2))
PATTERNS=[set(S) for S in pairs]+[set()]
def find_h(Vs,S):
    # returns h or None. Constraints A h <= b
    for sgn in (+1,-1):
        # choose for each model the 'witness' vertex where needed (disjunction)
        choice_lists=[]
        for k,V in enumerate(Vs):
            acc_needed = (k in S) if sgn>0 else (k not in S)
            choice_lists.append([None] if acc_needed else list(range(len(V))))
        for choice in itertools.product(*choice_lists):
            A=[];b=[]
            for v in Kp: A.append(-v); b.append(-1.0)        # v.h >= 1
            A.append(np.array([-sgn,0,0])); b.append(-1.0)    # sgn*h1 >= 1
            for k,V in enumerate(Vs):
                if choice[k] is None:
                    for m in V: A.append(-m); b.append(-1.0)  # accept: m.h>=1
                else:
                    A.append(V[choice[k]]); b.append(-1.0)    # not accept: m.h<=-1
            r=linprog(np.zeros(3),A_ub=np.array(A),b_ub=np.array(b),bounds=[(-1e4,1e4)]*3,method='highs')
            if r.status==0: return r.x
    return None
def check(Vs):
    out=[]
    for S in PATTERNS:
        h=find_h(Vs,S)
        if h is None: return None
        out.append(h)
    return out
if __name__=="__main__":
    rng=np.random.default_rng(int(sys.argv[1]) if len(sys.argv)>1 else 0)
    useT1 = len(sys.argv)>2 and sys.argv[2]=='T1'
    for trial in range(20000):
        Vs=[rng.dirichlet(np.ones(3),size=1) for _ in range(4)]
        if useT1: Vs[0]=T1.copy()
        hs=check(Vs)
        if hs is not None:
            print("FOUND trial",trial)
            for V in Vs: print(np.round(V,4).tolist())
            for S,h in zip(PATTERNS,hs): print(sorted(S),np.round(h,4).tolist())
            np.save('found_Vs.npy',np.array([V for V in Vs],dtype=object),allow_pickle=True)
            break
    else: print("none")
