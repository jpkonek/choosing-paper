# Search for a K4 seed: 4 coherent credal sets K_k (containing K'), and cell directions h in U,
# realising world-1 correctness patterns: {exactly S} for all 6 pairs S, and the all-error pattern.
import numpy as np, itertools, sys
rng=np.random.default_rng(int(sys.argv[1]) if len(sys.argv)>1 else 0)
eps=0.3; s=0.9
u=np.ones(3)/3
T1=np.array([(1-eps)*u+eps*np.eye(3)[k] for k in range(3)])
Kp=u+s*(T1-u)           # vertices of K'
def Pmin(V,h): return (V@h).min()
def patterns(Ks,H):
    # H: N x 3 directions. returns mask of h in U and correctness matrix
    inU=(H@Kp.T).min(1)>0
    acc=np.stack([(H@K.T).min(1)>0 for K in Ks],1)
    good1=H[:,0]>0
    corr=(acc==good1[:,None])
    return inU,corr
pairs=list(itertools.combinations(range(4),2))
best=None
H=rng.normal(size=(400000,3))
for trial in range(4000):
    ms=rng.dirichlet(np.ones(3)*0.7,size=4)
    Ks=[np.vstack([Kp,m[None]]) for m in ms]
    if trial%2==0: Ks[0]=np.vstack([Kp,T1])  # try T1 (as co(K' u T1)=T1) as base 1
    inU,corr=patterns(Ks,H)
    c=corr[inU]
    codes=set(map(tuple,c.astype(int)))
    need=[tuple(1 if k in S else 0 for k in range(4)) for S in pairs]+[(0,0,0,0)]
    got=sum(t in codes for t in need)
    if best is None or got>best[0]:
        best=(got,trial,[K.tolist() for K in Ks])
        print(got,trial,flush=True)
    if got==7:
        print("FOUND",trial); print(np.array2string(ms,precision=4)); 
        np.save('seed_ms.npy',ms); np.save('seed_T1flag.npy',np.array([trial%2==0]))
        break
