# Margin-maximising LP for K4 seed patterns; cells kept away from coordinate planes.
import numpy as np, itertools, sys
from fractions import Fraction as F
from scipy.optimize import linprog
eps=F(3,10); s=F(9,10); u=[F(1,3)]*3
def vec(*a): return [F(x) for x in a]
T1=[[ (1-eps)*u[i]+eps*(1 if i==k else 0) for i in range(3)] for k in range(3)]
Kp=[[u[i]+s*(T1[k][i]-u[i]) for i in range(3)] for k in range(3)]
pairs=list(itertools.combinations(range(4),2))
PATTERNS=[set(S) for S in pairs]+[set()]
TAU=0.15
def lp_cell(Vs,S):
    best=None
    for sgn in itertools.product((1,-1),repeat=3):
        if all(x<0 for x in sgn): continue
        for choice in itertools.product(*[[None] if ((k in S) if sgn[0]>0 else (k not in S)) else range(len(V)) for k,V in enumerate(Vs)]):
            # variables h(3), t ; maximise t ; |h|_inf<=1
            A=[];b=[]
            def ge(row,c=1.0):  # row.h >= c*t
                A.append([-float(x) for x in row]+[c]); b.append(0.0)
            for v in Kp: ge(v)
            for i in range(3): ge([sgn[i] if j==i else 0 for j in range(3)],1.0); A.append([sgn[i] if j==i else 0 for j in range(3)]+[0]); b.append(1.0)
            for i in range(3):
                ge([sgn[i] if j==i else 0 for j in range(3)],0)  # sign
            # coordinate floor: sgn_i h_i >= TAU (with h_inf normalised by bound 1 at the max coord) -> use sgn_i h_i >= TAU*1 enforced via t? keep separate:
            for i in range(3): A.append([-sgn[i] if j==i else 0 for j in range(3)]+[0]); b.append(-TAU)
            for k,V in enumerate(Vs):
                if choice[k] is None:
                    for m in V: ge(m)
                else: ge([-x for x in V[choice[k]]])
            r=linprog([0,0,0,-1],A_ub=np.array(A,float),b_ub=np.array(b),bounds=[(-1,1)]*3+[(0,10)],method='highs')
            if r.status==0 and r.x[3]>1e-9 and (best is None or r.x[3]>best[0]): best=(r.x[3],r.x[:3],sgn,choice)
    return best
def margins(Vs):
    res=[]
    for S in PATTERNS:
        b=lp_cell(Vs,S)
        if b is None: return None
        res.append(b)
    return res
if __name__=="__main__":
    rng=np.random.default_rng(int(sys.argv[1])); den=int(sys.argv[2]); amp=int(sys.argv[3])
    bestmin=0
    for trial in range(int(sys.argv[4])):
        Vs=[T1]
        for k in range(3):
            V=[]
            for j in range(3):
                d=rng.integers(-amp,amp+1,size=2)
                v=[T1[j][0]+F(int(d[0]),den),T1[j][1]+F(int(d[1]),den)]; v.append(1-v[0]-v[1])
                V.append(v)
            Vs.append(V)
        if any(x<=0 for V in Vs for v in V for x in v): continue
        res=margins(Vs)
        if res is None: continue
        mn=min(r[0] for r in res)
        if mn>bestmin:
            bestmin=mn; print("trial",trial,"min margin",round(mn,5),flush=True)
            with open('best_seed.txt','w') as f:
                f.write(repr([[[str(x) for x in v] for v in V] for V in Vs])+"\n")
                for S,r in zip(PATTERNS,res): f.write(f"{sorted(S)} t={r[0]:.5f} h={np.round(r[1],5).tolist()} sgn={r[2]}\n")
