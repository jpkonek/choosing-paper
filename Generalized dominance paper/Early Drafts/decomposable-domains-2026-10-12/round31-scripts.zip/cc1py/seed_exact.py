# CC1 seed: exact rational verification of the K4 seed (world 1), and world-2/3 effects.
import itertools, json
from fractions import Fraction as F
eps=F(3,10); s=F(9,10); u=[F(1,3)]*3
T1=[[(1-eps)*u[i]+eps*(1 if i==k else 0) for i in range(3)] for k in range(3)]
Kp=[[u[i]+s*(T1[k][i]-u[i]) for i in range(3)] for k in range(3)]
Fr=lambda L:[[F(x) for x in v] for v in L]
V=[T1,
   Fr([['19/30','3/20','13/60'],['17/60','8/15','11/60'],['1/5','11/60','37/60']]),
   Fr([['13/30','1/5','11/30'],['11/60','3/5','13/60'],['19/60','13/60','7/15']]),
   Fr([['31/60','3/10','11/60'],['3/20','13/30','5/12'],['1/6','1/3','1/2']])]
# credal sets K_k = co(K' u V_k); since h in U forces K'.h>0, acceptance of h <=> all V_k vertices .h > 0
H={ (0,1):['1','-30809/100000','-3/20'], (0,2):['1','-3/20','-319/1000'], (0,3):['3/20','-46328/100000','1'],
    (1,2):['-2766/10000','1','-2766/10000'], (1,3):['-29159/100000','-23288/100000','1'],
    (2,3):['1','1','-91083/100000'], ():['-22449/100000','1','1']}
dot=lambda a,b:sum(x*y for x,y in zip(a,b))
def info(h):
    assert all(dot(v,h)>0 for v in Kp), "h not in U"
    acc=[all(dot(m,h)>0 for m in Vk) for Vk in V]
    # robustness: no vertex value is 0 and no coordinate 0
    assert all(dot(m,h)!=0 for Vk in V for m in Vk) and all(x!=0 for x in h)
    corr=[[acc[k]==(h[j]>0) for j in range(3)] for k in range(4)]  # corr[k][j]
    return acc,corr
out={}
ok=True
for S,hs in H.items():
    h=[F(x) for x in hs]; acc,corr=info(h)
    c1=[k for k in range(4) if corr[k][0]]
    print("cell",S,"h=",[str(x) for x in h],"sign",['+' if x>0 else '-' for x in h],
          "accept",[int(a) for a in acc],"world1-correct",c1)
    ok &= (set(c1)==set(S))
    out[S]=corr
print("K4 world-1 pattern realised exactly:",ok)
cells=list(H.keys())
# seed vectors g^j_k(cell) at world j: +1 if B_k correct at j there (toggle creates error), -1 if erring
g={(k,j):{c:(1 if out[c][k][j] else -1) for c in cells} for k in range(4) for j in range(3)}
tot={c:sum(g[(k,0)][c] for k in range(4)) for c in cells}
print("world-1 certificate sum per cell (weights 1):",tot)
print("certificate <=0 everywhere and !=0:",all(v<=0 for v in tot.values()) and any(v<0 for v in tot.values()))
for k in range(4):
    for l in range(4):
        assert any(g[(k,0)][c]==1 and g[(l,0)][c]==1 for c in cells)
print("every ordered pair (k,l), k=l included, has a common positive cell: True")
for k in range(4):
    for j in (1,2):
        imp=[c for c in cells if g[(k,j)][c]==-1]; wor=[c for c in cells if g[(k,j)][c]==1]
        print(f"X_{k+1} vs B_{k+1} at world {j+1}: improves on {imp}; worsens on {wor}")
# crossing of world-1 error sets restricted to the cells
for k,l in itertools.combinations(range(4),2):
    Ek={c for c in cells if not out[c][k][0]}; El={c for c in cells if not out[c][l][0]}
    assert Ek-El and El-Ek
print("world-1 error sets of B_1..B_4 pairwise cross on the cells: True")
