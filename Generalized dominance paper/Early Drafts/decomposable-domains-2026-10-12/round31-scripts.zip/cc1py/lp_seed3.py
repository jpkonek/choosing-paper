import numpy as np, sys
from lp_seed import check, T1, PATTERNS, Kp
rng=np.random.default_rng(int(sys.argv[1])); sc=float(sys.argv[2])
def proj(v):
    v=np.clip(v,1e-3,None); return v/v.sum()
for trial in range(3000):
    Vs=[T1.copy()]
    for k in range(3):
        V=np.array([proj(T1[j]+sc*rng.normal(size=3)) for j in range(3)])
        Vs.append(V)
    hs=check(Vs)
    if hs is not None:
        print("FOUND trial",trial)
        for V in Vs: print(np.round(V,5).tolist())
        for S,h in zip(PATTERNS,hs): print(sorted(S),np.round(h/np.abs(h).max(),5).tolist())
        break
else: print("none")
