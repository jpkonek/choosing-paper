import numpy as np, sys
from lp_seed import check, T1, PATTERNS
rng=np.random.default_rng(int(sys.argv[1]))
nv=int(sys.argv[2])
for trial in range(3000):
    Vs=[rng.dirichlet(np.ones(3)*0.6,size=rng.integers(1,nv+1)) for _ in range(4)]
    if len(sys.argv)>3: Vs[0]=T1.copy()
    hs=check(Vs)
    if hs is not None:
        print("FOUND trial",trial)
        for V in Vs: print(np.round(V,5).tolist())
        for S,h in zip(PATTERNS,hs): print(sorted(S),np.round(h,5).tolist())
        break
else: print("none")
