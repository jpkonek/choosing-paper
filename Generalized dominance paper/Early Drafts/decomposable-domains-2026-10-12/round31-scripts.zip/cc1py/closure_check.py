# CHECKED (finite, exhaustive on a cell model): realisable compositions of the four K4 seed records with
# guidance steps, on the four-advice ladder (world-1 ranks 0..3 per cell), never give a strict guidance reversal.
# One state per cell. Seed k needs rank r on its positive cells (moves them to r+1) and rank r+1 on its negative
# cells (moves them to r); we take r = 0 on every cell (cells with h_1 < 0 have r = 1 in absolute terms, which only
# shifts the ladder; the top rank 3 is then unreachable there, which can only remove paths).
# Guidance steps raise the rank of one cell by one (partial-cell guidance steps only raise ranks further and
# cannot enable a seed move, since seeds act on whole cells with a fixed source advice).
import itertools
from collections import deque
cells=[(0,1),(0,2),(0,3),(1,2),(1,3),(2,3),()]
pos={k:{i for i,c in enumerate(cells) if k in c} for k in range(4)}
N=len(cells)
def seed_move(x,k):
    y=list(x)
    for i in range(N):
        if i in pos[k]:
            if x[i]!=0: return None
            y[i]=1
        else:
            if x[i]!=1: return None
            y[i]=0
    return tuple(y)
bad=0; explored=0; maxseeds=0
starts=list(itertools.product(range(2),repeat=N))   # all starts in {0,1}^7 (only these allow any seed move)
for st in starts:
    seen={st:0}; dq=deque([st])
    while dq:
        x=dq.popleft(); explored+=1; ns=seen[x]
        d=[x[i]-st[i] for i in range(N)]
        if all(v<=0 for v in d) and any(v<0 for v in d): bad+=1
        nxt=[]
        for k in range(4):
            y=seed_move(x,k)
            if y: nxt.append((y,ns+1))
        for i in range(N):
            if x[i]<3:
                y=list(x); y[i]+=1; nxt.append((tuple(y),ns))
        for y,m in nxt:
            if y not in seen or seen[y]<m:
                seen[y]=m; maxseeds=max(maxseeds,m); dq.append(y)
print("start states:",len(starts),"state visits:",explored)
print("strict reversals reachable:",bad)
print("max number of seed records in one realisable composition:",maxseeds)
