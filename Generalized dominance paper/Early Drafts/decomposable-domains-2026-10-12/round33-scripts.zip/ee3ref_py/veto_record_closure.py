# EE3 referee: DD2 sec. 3.5 (veto fragment).  veto_bfs.py computes the transitive closure of TRANSPORTED GENERATORS on
# full patterns, which does not include (IB)-transports of composite records (the same gap DD3 found in CC1 Thm 1.1(b)).
# Here we close the gap with a stronger certificate: an additive world-w valuation  Phi(r) = sum_c w_c * drank_c(r)
# with w_c >= 1 that is >= 0 on every forced record and on every world-w worsening record.  Phi telescopes under
# composition and depends only on the record, so the full (composition + IB) record closure has Phi >= 0, while every
# nontrivial strict world-w improvement has Phi < 0.  Feasibility is found by LP and then verified in exact rationals.
import os, sys, itertools
from fractions import Fraction as F
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'dd2py'))
from common import *          # DD2 data: CELLS, rank, ladder, B_accepts, grid_bases, ADV, NC
import numpy as np
from scipy.optimize import linprog


def forced_records(edge):
    bases = grid_bases(120)
    eb = sorted({pt for (pt, s) in bases if s == edge})
    recs = set()
    for pi in eb:
        # records out of C_pi: any nonempty set of cells changed to other advice
        for vals in itertools.product(*[[None] + [a for a in ADV if a != pi[c]] for c in range(NC)]):
            if all(v is None for v in vals):
                continue
            end = ''.join(pi[c] if v is None else v for c, v in zip(range(NC), vals))
            if B_accepts(ladder(0, pi, end)):
                continue
            recs.add(tuple((pi[c], end[c]) if end[c] != pi[c] else None for c in range(NC)))
    return eb, recs


def drank_rec(world, r):
    return [0 if e is None else rank(world, c, e[1]) - rank(world, c, e[0]) for c, e in enumerate(r)]


for edge, world in (((0, 1), 1), ((0, 2), 2)):
    eb, recs = forced_records(edge)
    D = np.array([drank_rec(world, r) for r in recs], dtype=float)
    # maximise nothing; constraints: -D w <= 0, w >= 1
    res = linprog(c=np.ones(NC), A_ub=-D, b_ub=np.zeros(len(D)), bounds=[(1, None)]*NC, method='highs')
    print(f"edge {tuple(i+1 for i in edge)}, world {world+1}: {len(eb)} edge patterns, {len(recs)} forced records")
    if not res.success:
        print("  LP infeasible: no additive certificate; (IB)-closure of composites NOT settled by this method")
        continue
    w = [F(round(x*1000)).limit_denominator(1000) for x in res.x]
    w = [max(x, F(1)) for x in w]
    ok = all(sum(wc*dc for wc, dc in zip(w, drank_rec(world, r))) >= 0 for r in recs)
    print("  weights (exact):", [str(x) for x in w], " every forced record has Phi>=0 (exact):", ok)
    print("  => the full record closure (composition + (IB) transports of composites) contains no strict world-%d"
          " improvement" % (world+1) if ok else "  rational rounding failed")
