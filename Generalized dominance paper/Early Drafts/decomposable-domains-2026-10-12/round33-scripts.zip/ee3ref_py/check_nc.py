# EE3 referee checks on DD1 sec. 2: (a) the nine window certificates and the forbidden configuration, with an
# independent exact cone test; (b) agreement with DD1's compatible_fast on posterior triples; (c) Prop 2.5 on grids
# INCLUDING boundary indices: compatibility => sum p^i_i <= 1, equality only on the diagonal.
import sys, os, json, math, random
from fractions import Fraction as F
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from indep_compat import *

# seed credal sets (data copied from CC1 / DD1 geom.py; only generating points matter)
u = [F(1, 3)]*3; s = F(9, 10)
Kp = [[u[i] + s*(V[k][i]-u[i]) for i in range(3)] for k in range(3)]
Fr = lambda L: [[F(x) for x in v] for v in L]
Vs = [None,
      Fr([['19/30', '3/20', '13/60'], ['17/60', '8/15', '11/60'], ['1/5', '11/60', '37/60']]),
      Fr([['13/30', '1/5', '11/30'], ['11/60', '3/5', '13/60'], ['19/60', '13/60', '7/15']]),
      Fr([['31/60', '3/10', '11/60'], ['3/20', '13/30', '5/12'], ['1/6', '1/3', '1/2']])]
Kseed = [V] + [Kp + Vs[k] for k in (1, 2, 3)]

print("(a) window certificates, independent cone test")
C = json.load(open(os.path.join(HERE, '..', 'dd1py', 'nc_window_exact.json')))
allok = True
for k, i, pj, pl, U in C:
    pj = [F(x) for x in pj]; pl = [F(x) for x in pl]; U = F(U)
    j, l = [x for x in range(3) if x != i]
    sl = [None]*3; sl[i] = Kseed[k]; sl[j] = post(pj); sl[l] = post(pl)
    ok = compatible(*sl)
    Ucalc = 1 - pj[j] - pl[l]
    allok &= ok and Ucalc == U and sum(pj) == 1 and sum(pl) == 1
    print(f"  K_{k+1} slot {i+1}: compatible={ok}  U=1-p^{j+1}_{j+1}-p^{l+1}_{l+1}={Ucalc} (claimed {U})")
print("  all nine certificates independently confirmed:", allok)

# witnesses vs bumps (they must be posterior indices, i.e. outside every bump, for the certificate to apply)
def qs(D):
    out = []
    for ang in (90, 210, 330):
        a = math.radians(ang)
        d = [math.sqrt(2/3)*math.cos(a), math.sqrt(2/3)*math.cos(a-2*math.pi/3), math.sqrt(2/3)*math.cos(a+2*math.pi/3)]
        out.append([1/3 + D*x for x in d])
    return out
for D in (0.06, 0.25):
    Q = qs(D)
    md = min(math.dist([float(F(x)) for x in w], q) for c in C for w in (c[2], c[3]) for q in Q)
    print(f"  design D={D}: q_2={[round(x,4) for x in Q[0]]}; min distance witness-to-bump-centre = {md:.4f} (rho=0.025)")
# forbidden configuration at D=1/4: K_2 in slot 2
Q = qs(0.25)
print("  D=1/4: (q_2)_2 =", round(Q[0][1], 4), ">= 99/200 =", 99/200, ":", Q[0][1] >= 99/200)

print("(b) agreement with dd1py.compatible_fast on random posterior triples (interior and boundary)")
sys.path.insert(0, os.path.join(HERE, '..', 'dd1py'))
import geom as G
random.seed(7)
def rp(den, boundary=False):
    while True:
        a = random.randint(0, den); b = random.randint(0, den - a)
        p = [F(a, den), F(b, den), F(den-a-b, den)]
        if boundary == (min(p) == 0):
            return p
mism = 0; ncomp = 0; N = 0
for t in range(600):
    p1 = rp(40, boundary=(t % 3 == 0))
    # perturbations that make compatibility likely
    p2 = [p1[0], p1[1], p1[2]]; p3 = [p1[0], p1[1], p1[2]]
    for p in (p2, p3):
        i, j = random.sample(range(3), 2); d = F(random.randint(0, 3), 40)
        if p[i] >= d: p[i] -= d; p[j] += d
    K1, K2, K3 = post(p1), post(p2), post(p3)
    a = compatible(K1, K2, K3)
    b = G.compatible_fast(G.post(p1), G.post(p2), G.post(p3))
    N += 1; ncomp += a; mism += (a != b)
print(f"  {N} triples, {ncomp} compatible, mismatches with DD1's test: {mism}")

print("(c) Prop 2.5 on the grid 1/den (all triples, boundary included)")
for den in (6, 8):
    pts = [[F(a, den), F(b, den), F(den-a-b, den)] for a in range(den+1) for b in range(den+1-a)]
    P = {tuple(p): post(p) for p in pts}
    viol = []; eq_diag = 0; comp = 0
    for p1 in pts:
        for p2 in pts:
            if not le(P[tuple(p2)], P[tuple(p1)], 1):
                continue
            for p3 in pts:
                if not le(P[tuple(p3)], P[tuple(p1)], 2):
                    continue
                if compatible(P[tuple(p1)], P[tuple(p2)], P[tuple(p3)]):
                    comp += 1
                    S = p1[0] + p2[1] + p3[2]
                    if S > 1 or (S == 1 and not (p1 == p2 == p3)):
                        viol.append((p1, p2, p3, S))
                    if p1 == p2 == p3:
                        eq_diag += 1
    print(f"  den={den}: {len(pts)} points, compatible triples={comp} (diagonal {eq_diag}), violations={len(viol)}")
    for v in viol[:10]:
        print("    VIOLATION", [[str(x) for x in p] for p in v[:3]], str(v[3]))
