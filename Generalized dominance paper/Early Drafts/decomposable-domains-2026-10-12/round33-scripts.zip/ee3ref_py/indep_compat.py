# EE3 referee: independent exact compatibility test (Lemma 2.3 of DD1) by H->V enumeration of polyhedral cones.
# No import from dd1py except (optionally) for cross-checking.  Exact rationals throughout.
from fractions import Fraction as F
import itertools, random, sys, os

eps = F(3, 10); c0 = (1 - eps) / 3
V = [[c0 + (eps if i == k else 0) for i in range(3)] for k in range(3)]   # T1 vertices


def cross(a, b):
    return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]


def dot(a, b):
    return sum(x*y for x, y in zip(a, b))


def rays(cons):
    """candidate extreme rays of the pointed cone {h: a.h >= 0 for a in cons} (R^3)."""
    out = []
    for a, b in itertools.combinations(cons, 2):
        r = cross(a, b)
        if all(x == 0 for x in r):
            continue
        for s in (1, -1):
            rr = [s*x for x in r]
            if all(dot(c, rr) >= 0 for c in cons):
                out.append(rr)
    return out


def full_dim(cons, R):
    if not R:
        return False
    tot = [sum(r[i] for r in R) for i in range(3)]
    return all(dot(c, tot) > 0 for c in cons)


def included(cons, target):
    """{h: cons >= 0} subset of {h: target >= 0} up to null sets."""
    R = rays(cons)
    if not full_dim(cons, R):
        return True           # null cone
    return all(dot(t, r) >= 0 for t in target for r in R)


def E(i):
    return [F(1) if j == i else F(0) for j in range(3)]


def neg(v):
    return [-x for x in v]


def le(Ko, Kj, o):
    """on Q_o = {h_o<0, h_j,h_l>0}: acc(Kj) c acc(Ko) and rej(Ko) c rej(Kj)."""
    j, l = [x for x in range(3) if x != o]
    Q = [E(j), E(l), neg(E(o))]
    acc = included([list(m) for m in Kj] + Q, [list(m) for m in Ko])
    # rej(Ko): {h in Q: m.h<0 all m in Ko}  -> {h: -m.h>=0} ; target: -k.h>=0 for k in Kj
    rej = included([neg(m) for m in Ko] + Q, [neg(k) for k in Kj])
    return acc and rej


def compatible(K1, K2, K3):
    Ks = [K1, K2, K3]
    return all(le(Ks[o], Ks[j], o) for o in range(3) for j in range(3) if j != o)


def post(p):
    pts = []
    for v in V:
        w = [p[i]*v[i] for i in range(3)]
        t = sum(w)
        pts.append([x/t for x in w])
    # dedupe (vertices of Delta collapse)
    uniq = []
    for q in pts:
        if q not in uniq:
            uniq.append(q)
    return uniq   # vertex list (cone generated is what matters; non-extreme points harmless)
