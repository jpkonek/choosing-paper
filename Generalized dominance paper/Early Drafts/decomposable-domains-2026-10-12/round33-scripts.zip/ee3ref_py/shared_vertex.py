# DD1 Prop 2.6(c): two distinct interior posterior triangles share at most one vertex (exact, eps=3/10).
from fractions import Fraction as F
import itertools
eps=F(3,10); c0=(1-eps)/3
V=[[c0+(eps if i==k else 0) for i in range(3)] for k in range(3)]
def ratio(a,b): return [V[a][i]/V[b][i] for i in range(3)]
def prop(x,y): return all(x[i]*y[0]==y[i]*x[0] for i in range(3))
bad=[]
for (a,b),(c,d) in itertools.combinations(itertools.product(range(3),repeat=2),2):
    if a==c or b==d: continue          # one vertex of each triangle used once
    if a==b or c==d: continue          # forces q=p
    if prop(ratio(a,b),ratio(c,d)): bad.append(((a,b),(c,d)))
print("pairs of vertex identifications giving the same q != p:",bad)
