# Sanity checks for veto_ib_closure.py: the fixed point is transitive and (IB)-closed (sampled), it contains the
# generators, and the reversal detector fires when one improving world-2 move is added as a generator.
import os, sys, random
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import veto_ib_closure as V
bad, R = V.closure_check((0, 1), 1)
n = V.n; S = V.states; random.seed(3)
def has(a, b): return (R[a] >> b) & 1
viol_t = 0; viol_ib = 0
for _ in range(20000):
    a, b, c = random.randrange(n), random.randrange(n), random.randrange(n)
    if has(a, b) and has(b, c) and not has(a, c): viol_t += 1
    if has(a, b):
        for x, y in list(V.transports(S[a], S[b]))[:5]:
            if not has(x, y): viol_ib += 1
print("sampled transitivity violations:", viol_t, " sampled (IB) violations:", viol_ib)
# detector test: one world-2-improving single-cell move must create a reversal
st = S[0]
for c in range(V.NC):
    for a in V.ADV:
        if V.rank(1, c, a) < V.rank(1, c, st[c]):
            print("detector test: improving move", st, "->", st[:c]+a+st[c+1:], "better():",
                  V.drank(1, st, st[:c]+a+st[c+1:]))
            raise SystemExit
