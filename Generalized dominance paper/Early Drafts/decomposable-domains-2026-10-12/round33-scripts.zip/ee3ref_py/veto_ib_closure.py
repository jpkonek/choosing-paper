# EE3 referee: DD2 sec. 3.5 (veto fragment), done with the FULL closure: transitivity AND (IB)-transport of every
# accepted pair (composites included), iterated to a fixed point on the 3^7 cell patterns.
# veto_bfs.py transports only the generators.  Run: python3 -I veto_ib_closure.py
import os, sys, itertools, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'dd2py'))
from common import *          # CELLS, rank, ladder, drank, B_accepts, grid_bases, ADV, NC

states = [''.join(t) for t in itertools.product(ADV, repeat=NC)]
idx = {s: n for n, s in enumerate(states)}
n = len(states)


def transports(P, Q):
    """all pairs (B, B with Q's advice on the support of rec(P,Q)) with B = P on that support"""
    D = [c for c in range(NC) if P[c] != Q[c]]
    free = [c for c in range(NC) if c not in D]
    for vals in itertools.product(ADV, repeat=len(free)):
        B = list(P); E = list(Q)
        for c, v in zip(free, vals):
            B[c] = v; E[c] = v
        yield idx[''.join(B)], idx[''.join(E)]


def closure_check(edge, world):
    t0 = time.time()
    bases = grid_bases(120)
    eb = sorted({pt for (pt, s) in bases if s == edge})
    R = [1 << a for a in range(n)]          # reflexive
    # generators: forced records out of edge patterns (rejected by (B) at world 1), and world-w worsening moves
    gens = []
    for pi in eb:
        for vals in itertools.product(*[[None] + [a for a in ADV if a != pi[c]] for c in range(NC)]):
            if all(v is None for v in vals):
                continue
            end = ''.join(pi[c] if v is None else v for c, v in zip(range(NC), vals))
            if not B_accepts(ladder(0, pi, end)):
                gens.append((pi, end))
    for st in states:
        for c in range(NC):
            for a in ADV:
                if a != st[c] and rank(world, c, a) >= rank(world, c, st[c]):
                    gens.append((st, st[:c] + a + st[c+1:]))
    seen = set()
    def add_record(P, Q):
        key = tuple((P[c], Q[c]) if P[c] != Q[c] else None for c in range(NC))
        if key in seen:
            return False
        seen.add(key)
        for a, b in transports(P, Q):
            R[a] |= 1 << b
        return True
    for P, Q in gens:
        add_record(P, Q)
    rounds = 0
    while True:
        rounds += 1
        # transitive closure (Warshall over bitsets)
        for k in range(n):
            bk = 1 << k; Rk = R[k]
            for a in range(n):
                if R[a] & bk:
                    R[a] |= Rk
        # (IB): transport every accepted pair's record
        new = 0
        for a in range(n):
            m = R[a]; P = states[a]
            while m:
                low = m & -m; b = low.bit_length() - 1; m ^= low
                if b != a and add_record(P, states[b]):
                    new += 1
        print(f"  round {rounds}: records {len(seen)}, new records from closure {new}, pairs {sum(bin(x).count('1') for x in R)}")
        if new == 0:
            break
    def better(q, p):
        d = drank(world, p, q)
        return all(x <= 0 for x in d) and any(x < 0 for x in d)
    bad = []
    for a in range(n):
        m = R[a]
        while m:
            low = m & -m; b = low.bit_length() - 1; m ^= low
            if better(states[b], states[a]):
                bad.append((states[a], states[b]))
    print(f"edge {tuple(i+1 for i in edge)}, world {world+1}: strict world-{world+1} improvements in the FULL closure: "
          f"{len(bad)}  ({time.time()-t0:.0f}s)")
    for P, Q in bad[:5]:
        print("   e.g.", P, "->", Q, "world rank change", drank(world, P, Q))
    return bad, R


if __name__ == "__main__":
    closure_check((0, 1), 1)
    closure_check((0, 2), 2)
