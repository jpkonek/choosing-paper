# EE1 Example 4.4 (CHECKED, independent of toy.py's closure code): explicit two-cap exchange producing (F1)
# that no single-generator monotonicity test detects.
# Three problem cells f,g,h with sign patterns (world 1,2,3); advice 0='+', 1='0', 2='-'.
# Run: python3 -I verify_example.py
from fractions import Fraction as F
signs = [(-1, 1, -1), (1, 1, -1), (1, -1, 1)]
NAME = {0: '+', 1: '0', 2: '-', 3: 'x'}
def rk(c, i, a):
    if a == 3: return 3
    return a if signs[c][i] > 0 else {0: 2, 1: 1, 2: 0}[a]
Cp, p = (2, 2, 1), (F(1, 3), F(0), F(2, 3))
Cq, q = (0, 0, 0), (F(5, 12), F(7, 12), F(0))
Cs, s = (1, 2, 0), (F(1, 12), F(1, 6), F(3, 4))
Cz, z = (1, 0, 2), (F(1, 4), F(2, 3), F(1, 12))
X = (0, 0, 1)   # = C_p with f -> C_q's advice, g -> C_z's advice
Y = (2, 0, 2)   # = C_q with f -> C_p's advice, h -> C_z's advice
def rec(A, B): return tuple(None if A[c] == B[c] else (A[c], B[c]) for c in range(3))
def show(d): return '[' + ', '.join('id' if e is None else NAME[e[0]] + '->' + NAME[e[1]] for e in d) + ']'
def compose(d1, d2):
    out = []
    for e1, e2 in zip(d1, d2):
        if e1 is None: out.append(e2); continue
        if e2 is None: out.append(e1); continue
        if e1[1] != e2[0]: return None
        out.append(None if e1[0] == e2[1] else (e1[0], e2[1]))
    return tuple(out)
g1 = rec(Cp, X); g2 = rec(Cq, Y); d = compose(g1, g2)
print('world-1 ranks of (+,0,-) per cell:', [[rk(c, 0, a) for a in range(3)] for c in range(3)])
print('g1 = rec(C_p, X) =', show(g1), '  cap at world 1 iff p_1 >= r_1(X)')
print('g2 = rec(C_q, Y) =', show(g2), '  cap at world 1 iff q_1 >= r_1(Y)')
print('g1 o g2          =', show(d))
print('rec(C_s, C_z)    =', show(rec(Cs, Cz)), ' equal:', d == rec(Cs, Cz))
print('factorable at (C_s, C_z)?  needs C_s(f) = C_p(f):', Cs[0] == Cp[0])
print('s_1 =', s[0], ' z_1 =', z[0], ' -> accepting rec(C_s,C_z) at world 1 is (F1):', s[0] < z[0])
# a factorable realisation of g1 o g2: start from C_s with f reset to C_p's advice
Xp = (Cp[0], Cs[1], Cs[2]); W = tuple(Xp[c] if g1[c] is None else g1[c][1] for c in range(3))
Zp = tuple(W[c] if g2[c] is None else g2[c][1] for c in range(3))
print('factorable realisation:', Xp, '->', W, '->', Zp, '; same record as (C_s,C_z):', rec(Xp, Zp) == rec(Cs, Cz))
# The thresholds produced by the generator-wise ("pairwise") process in toy.py for this instance:
import os, sys, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from toy import Toy, Inst
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'two_cap_search.py')).read()
exec(src.split('seed = int')[0].split('from fractions import Fraction as Fr\n')[1])
t = Toy(signs); inst = Inst(t, [(Cp, p), (Cq, q), (Cs, s), (Cz, z)])
r0 = {M: (inst.selmodels[M] if M in inst.selmodels else (F(2),) * 3) for M in t.models}
r0[X] = (p[0], F(2), F(2)); r0[Y] = (q[0], F(2), F(2))
o, why, r = pairwise_process(inst, r0)
print('generator-wise process:', o, ' r_1(X) =', r[X][0], ' r_1(Y) =', r[Y][0], ' r_1(C_z) =', r[Cz][0])
mono = all(r[B][i] <= r[A][i] for i in range(3) for dd in (set(inst.guid[i]) | inst.caps(r, i)) for A, B in t.realizations(dd))
print('r non-increasing along every realisation of every generator:', mono)
A = inst.closures(r)
print('rec(C_s,C_z) in closure A_1:', rec_t := t.rec(Cs, Cz) in A[0])
o2, w2, r2 = inst.process(r0, stopF2=False)
print('closure process from the same r0:', o2, w2)
from toy import som_violation, som_process
print('saturated one-step monotone (guidance-saturated generators):', som_violation(inst, r) is None)
o3, w3, r3 = som_process(inst, r0)
print('saturated one-step process from r0:', o3, w3, ' r_1(C_z) =', r3[Cz][0] if o3 == 'ok' else None)
if o3 == 'ok':
    A3 = inst.closures(r3)
    print('  closure of its thresholds contains rec(C_s,C_z) at world 1 ((F1)):', t.rec(Cs, Cz) in A3[0])
