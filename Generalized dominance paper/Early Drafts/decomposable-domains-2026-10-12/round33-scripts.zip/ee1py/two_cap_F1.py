# EE1 Example 4.5 (CHECKED): can a two-cap loop with a context change produce (F1) that generator-wise
# monotonicity misses?  Plant Z=(w,c',y) as a FOURTH selected model with z_1 > s_1.
# Run: python3 -I two_cap_F1.py [seed] [trials]
import sys, os, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from toy import Toy, Inst, rank, DEC, CODE, som_process
from fractions import Fraction as Fr
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'two_cap_search.py')).read().split('seed = int')[0].split('from fractions import Fraction as Fr\n')[1])
seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
trials = int(sys.argv[2]) if len(sys.argv) > 2 else 3000
random.seed(seed)
MIX=[s_ for s_ in itertools.product((1,-1),repeat=3) if len(set(s_))==2]
cnt={}; shown=0
for tr in range(trials):
    signs=[random.choice(MIX) for _ in range(3)]
    a,b=random.sample(range(3),2); c,c2=random.sample(range(3),2); x,x2=random.sample(range(3),2)
    u=random.randrange(3); y=random.choice([v for v in range(3) if v!=x2]); w=random.choice([v for v in range(3) if v!=a])
    Cp,Cq,Cs,Cz=(a,c,x),(b,u,x2),(w,c,x2),(w,c2,y)
    if len({Cp,Cq,Cs,Cz})<4: continue
    p,q,s,z=rand_simplex(),rand_simplex(),rand_simplex(),rand_simplex()
    if len({p,q,s,z})<4 or not (z[0]>s[0]): continue
    t=Toy(signs); sel=[(Cp,p),(Cq,q),(Cs,s),(Cz,z)]
    if not consistent_selected(t,sel): cnt['incons']=cnt.get('incons',0)+1; continue
    inst=Inst(t,sel)
    X=(b,c2,x); Y=(a,u,y)
    if X in inst.selmodels or Y in inst.selmodels: continue
    r0={M:(inst.selmodels[M] if M in inst.selmodels else (Fr(2),)*3) for M in t.models}
    r0[X]=(p[0],Fr(2),Fr(2)); r0[Y]=(q[0],Fr(2),Fr(2))
    o,why,r=pairwise_process(inst,r0)
    o5,w5,r5=inst.process(r0, stopF2=False)
    o6,w6,r6=som_process(inst,r0)
    key=('pairwise',o,why,'saturated',o6,w6,'closure',o5,w5)
    cnt[key]=cnt.get(key,0)+1
    if o6=='ok' and o5=='fail' and shown<3:
        shown+=1
        print('EXAMPLE (saturated one-step ok, closure F1):',signs,'sel',[(m,tuple(map(str,v))) for m,v in sel])
for k,v in sorted(cnt.items(),key=str): print(v,k)
