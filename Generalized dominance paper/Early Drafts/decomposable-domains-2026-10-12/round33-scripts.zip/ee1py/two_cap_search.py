# EE1 Thm 4.3 / Example 4.4 (CHECKED): generator-wise monotonicity of r does NOT imply a clean closure;
# the extra forced comparisons come from two-cap loops followed by a context change.
# Planted pattern on 3 cells (f,g,h):  C_p=(a,c,x), C_q=(b,c',x), C_s=(w,c,x), w != a.
# Run: python3 -I two_cap_search.py [seed] [trials]
import sys, os, random, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from toy import Toy, Inst, rank, DEC
from fractions import Fraction as Fr
MIXED = [s for s in itertools.product((1, -1), repeat=3) if len(set(s)) == 2]
def rand_simplex(den=12):
    while True:
        a, b = random.randint(0, den), random.randint(0, den)
        if a + b <= den: return (Fr(a, den), Fr(b, den), Fr(den - a - b, den))
def pw_better(t, i, X, Y):
    return all(rank(t.signs[c][i], X[c]) <= rank(t.signs[c][i], Y[c]) for c in range(t.n))
def consistent_selected(t, sel):
    for (m, p), (m2, q) in itertools.permutations(sel, 2):
        for i in range(3):
            if pw_better(t, i, m2, m) and q[i] < p[i]: return False
            if pw_better(t, i, m2, m) and m2 != m and q[i] <= p[i]: return False
    return True
def rand_r(inst, high_bias=0.7):
    vals = [sorted(set(p[i] for _, p in inst.sel)) + [Fr(2)] for i in range(3)]
    r = {}
    for X in inst.t.models:
        if X in inst.selmodels: r[X] = tuple(inst.selmodels[X])
        else:
            r[X] = tuple(random.choice(vals[i][-2:]) if random.random() < high_bias else random.choice(vals[i]) for i in range(3))
    return r
def pairwise_process(inst, r0, maxit=200):
    r = dict(r0)
    for it in range(maxit):
        changed = False
        for i in range(3):
            gens = set(inst.guid[i]) | inst.caps(r, i)
            for d in gens:
                for X, Y in inst.t.realizations(d):
                    if r[Y][i] > r[X][i]:
                        if Y in inst.selmodels: return ('fail', 'F1', r)
                        v = list(r[Y]); v[i] = r[X][i]; r[Y] = tuple(v); changed = True
        if not changed: return ('ok', None, r)
    return ('nonterm', None, r)

seed = int(sys.argv[1]) if len(sys.argv) > 1 else 5
trials = int(sys.argv[2]) if len(sys.argv) > 2 else 100
random.seed(seed)
found = 0
cnt = dict(cons=0, pwok=0, pwfail=0)
for tr in range(trials):
    signs = [random.choice(MIXED) for _ in range(3)]
    t = Toy(signs)
    a, b = random.sample(range(3), 2); c, c2 = random.sample(range(3), 2); x = random.randrange(3)
    w = random.choice([v for v in range(3) if v != a])
    Cp, Cq, Cs = (a, c, x), (b, c2, x), (w, c, x)
    if len({Cp, Cq, Cs}) < 3: continue
    extra = random.random() < 0.5
    ms = [Cp, Cq, Cs]
    if extra:
        ms.append(random.choice([m for m in t.models if 3 not in m and m not in ms]))
    ok = False
    for _ in range(300):
        sel = [(m, rand_simplex()) for m in ms]
        if sel[0][1][0] >= sel[1][1][0] and len(set(p for _, p in sel)) == len(sel) and consistent_selected(t, sel):
            ok = True; break
    if not ok: continue
    cnt['cons'] += 1
    inst = Inst(t, sel)
    if random.random() < 0.5:
        r0 = rand_r(inst, high_bias=0.8)
    else:
        r0 = {X: (inst.selmodels[X] if X in inst.selmodels else (Fr(2), Fr(2), Fr(2))) for X in t.models}
    yv = random.choice([v for v in range(3) if v != x])
    Y = (a, c2, yv)
    if Y not in inst.selmodels:
        r0[Y] = (sel[1][1][0], r0[Y][1], r0[Y][2])
    o, why, r = pairwise_process(inst, r0)
    if o != 'ok':
        cnt['pwfail'] += 1; continue
    cnt['pwok'] += 1
    A = inst.closures(r)
    ce, wit = inst.cap_exact(r, A)
    if not ce:
        found += 1
        X, m, i = wit
        print('EXAMPLE', found, 'signs', signs, 'selected', [(mm, tuple(str(v) for v in pp)) for mm, pp in sel])
        print('   violation: rec(C, X) in A_%d with C=%s, p_i=%s < r_i(X)=%s, X=%s' % (i + 1, m, inst.selmodels[m][i], r[X][i], X))
        # is the violating record a single generator realization? (it is not, by pairwise monotonicity)
        d = t.rec(m, X)
        print('   record', [None if e == 0 else DEC[e] for e in d])
        # is the closure (with r fixed) F2-free?
        print('   closure F2-free:', not inst.F2(A))
        if found >= 3: break
print('seed', seed, 'trials', trials, 'examples found', found, cnt)
