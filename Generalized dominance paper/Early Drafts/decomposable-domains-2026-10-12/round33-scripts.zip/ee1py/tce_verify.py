# EE1 Prop 4.6 (NUMERICS): re-test the first configuration of tce_posterior.out with 10^6 directions.
import math, random, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
random.seed(11)
eps = 0.3
T1 = [[(1 - eps) / 3 + (eps if i == k else 0) for i in range(3)] for k in range(3)]
def post(p):
    out = []
    for v in T1:
        w = [p[i] * v[i] for i in range(3)]; s = sum(w); out.append([x / s for x in w])
    return out
def advice(K, h):
    vals = [sum(m[i] * h[i] for i in range(3)) for m in K]
    if min(vals) > 0: return '+'
    if max(vals) < 0: return '-'
    return '0'
z = (0.3451, 0.3253, 0.3295); p = (0.506, 0.383, 0.111); q = (0.288, 0.355, 0.357)
z = (z[0], z[1], 1 - z[0] - z[1]); p = (p[0], p[1], 1 - p[0] - p[1]); q = (q[0], q[1], 1 - q[0] - q[1])
Ku, Kz, Kp, Kq = T1, post(z), post(p), post(q)
N = 1000000; viol = nD = nD1 = nC = 0
for _ in range(N):
    h = [random.gauss(0, 1) for _ in range(3)]
    au, az, ap, aq = advice(Ku, h), advice(Kz, h), advice(Kp, h), advice(Kq, h)
    if au != az:
        nD += 1
        if au == ap: nD1 += 1
        elif au != aq: viol += 1
    elif len({au, ap, aq}) == 3: nC += 1
print('z', z, 'p', p, 'q', q)
print('Gaussian directions:', N, ' #Delta(u,z)=', nD, ' #D1=', nD1, ' #D2=', nD - nD1, ' #violations of (i)=', viol, ' #C=', nC)
