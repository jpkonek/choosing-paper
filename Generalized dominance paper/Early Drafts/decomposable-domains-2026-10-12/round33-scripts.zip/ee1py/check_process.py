# EE1 CHECK of the order-theoretic statements (Thm 1.1, 1.2) and of the failure of the pairwise reduction (Thm 4.2)
# on random finite toys.  Run:  python3 -I check_process.py [seed] [ncells] [trials]
import sys, os, random, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from toy import Toy, Inst, rank
from fractions import Fraction as Fr

seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
n = int(sys.argv[2]) if len(sys.argv) > 2 else 2
trials = int(sys.argv[3]) if len(sys.argv) > 3 else 60
random.seed(seed)
MIXED = [s for s in itertools.product((1, -1), repeat=3) if len(set(s)) == 2]

def rand_simplex(den=12):
    while True:
        a, b = random.randint(0, den), random.randint(0, den)
        if a + b <= den: return (Fr(a, den), Fr(b, den), Fr(den - a - b, den))

def pw_better(t, i, X, Y):   # X pointwise weakly i-better than Y
    return all(rank(t.signs[c][i], X[c]) <= rank(t.signs[c][i], Y[c]) for c in range(t.n))

def consistent_selected(t, sel):
    for (m, p), (m2, q) in itertools.permutations(sel, 2):
        for i in range(3):
            if pw_better(t, i, m2, m) and q[i] < p[i]: return False
            if pw_better(t, i, m2, m) and m2 != m and q[i] <= p[i]: return False
    return True

def make_instance():
    signs = [random.choice(MIXED) for _ in range(n)]
    t = Toy(signs)
    coh = [m for m in t.models if 3 not in m]
    for _ in range(200):
        k = random.randint(2, 4)
        ms = random.sample(coh, k)
        sel = [(m, rand_simplex()) for m in ms]
        if len(set(p for _, p in sel)) == k and consistent_selected(t, sel):
            return t, Inst(t, sel)
    return None

def rand_r(inst, high_bias=0.7):
    vals = [sorted(set(p[i] for _, p in inst.sel)) + [Fr(2)] for i in range(3)]
    r = {}
    for X in inst.t.models:
        if X in inst.selmodels: r[X] = tuple(inst.selmodels[X])
        else:
            r[X] = tuple(random.choice(vals[i][-2:]) if random.random() < high_bias else random.choice(vals[i]) for i in range(3))
    return r

def leq(r, s): return all(all(a <= b for a, b in zip(r[X], s[X])) for X in r)

def pairwise_process(inst, r0, maxit=200):
    r = dict(r0)
    for it in range(maxit):
        changed = False
        for i in range(3):
            gens = set(inst.guid[i]) | inst.caps(r, i)
            for d in gens:
                for X, Y in inst.t.realizations(d):
                    if r[Y][i] > r[X][i]:
                        if Y in inst.selmodels: return ('fail', 'F1', r)
                        v = list(r[Y]); v[i] = r[X][i]; r[Y] = tuple(v); changed = True
        if not changed: return ('ok', None, r)
    return ('nonterm', None, r)

stats = dict(inst=0, ok=0, fail=0, upclosed_ok=0, upclosed_bad=0, fixed_bad=0, pw_ok=0, pw_capexact=0, pw_not_capexact=0, agree=0, disagree=0)
examples = []
for tr in range(trials):
    mk = make_instance()
    if mk is None: continue
    t, inst = mk; stats['inst'] += 1
    r0 = rand_r(inst)
    out, why, r = inst.process(r0)
    if out == 'ok':
        stats['ok'] += 1
        A = inst.closures(r)
        nr, F1 = inst.F(r, A)
        ce, _ = inst.cap_exact(r, A)
        if nr != r or F1 or not ce or inst.F2(A): stats['fixed_bad'] += 1
        # up-closure: raise r* randomly (within the original value set), process must succeed and stay >= r*
        r1 = dict(r)
        vals = [sorted(set(p[i] for _, p in inst.sel)) + [Fr(2)] for i in range(3)]
        for X in t.models:
            if X not in inst.selmodels and random.random() < 0.5:
                r1[X] = tuple(max(a, random.choice(vals[i])) for i, a in enumerate(r1[X]))
        o2, w2, rr = inst.process(r1)
        if o2 == 'ok' and leq(r, rr) and leq(rr, r1): stats['upclosed_ok'] += 1
        else: stats['upclosed_bad'] += 1
    else:
        stats['fail'] += 1
    # pairwise (generator-wise) monotonicity versus the closure
    o3, w3, rp = pairwise_process(inst, r0)
    if o3 == 'ok':
        stats['pw_ok'] += 1
        A = inst.closures(rp)
        ce, wit = inst.cap_exact(rp, A)
        if ce: stats['pw_capexact'] += 1
        else:
            stats['pw_not_capexact'] += 1
            if len(examples) < 3: examples.append((t.signs, inst.sel, wit))
    o4, w4, rq = inst.process(r0, stopF2=False)
    same = (o4 == o3) and (o4 != 'ok' or rq == rp)
    stats['agree' if same else 'disagree'] += 1
    stats['why_' + str(why)] = stats.get('why_' + str(why), 0) + 1
    if not same and len(examples) < 6: examples.append(('DISAGREE', t.signs, inst.sel, o4, o3))
print('seed', seed, 'ncells', n, 'trials', trials)
for k, v in stats.items(): print(f'  {k:16s} {v}')
for ex in examples:
    print('  pairwise-monotone but NOT cap-exact:', ex)
