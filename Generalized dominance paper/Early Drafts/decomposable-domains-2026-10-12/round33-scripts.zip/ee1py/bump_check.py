# EE1 Prop 4.4: the four indices lie outside the DD1 bumps (so the posterior models are patched-family models).
import sys, os, math
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'dd1py'))
import family
F = family.default_family()
for name, v in [('u', (1/3, 1/3, 1/3)), ('z', (0.3451, 0.3253, 1 - 0.3451 - 0.3253)), ('p', (0.506, 0.383, 0.111)), ('q', (0.288, 0.355, 0.357))]:
    print(name, 'distances to bump centres', [round(math.dist(v, c), 4) for c in F.qs], 'radius', F.rho, 'betas', F.betas(list(v)))
