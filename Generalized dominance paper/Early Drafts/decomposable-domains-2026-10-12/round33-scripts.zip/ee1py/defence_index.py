# EE1 section 5.2 (NUMERICS): the brief's scaled defence index r = (1-delta) g fails strict guidance for an
# unbalanced two-world improvement of T1 = C_u (posterior family K_p = nu(p . T1)).
# X = C_u (+) t, t: silence -> accept on a small bounded neighbourhood D of h, h just outside facet F_3 of D_T1.
# Exact facts used (EE1 Prop 5.2): h_1(X) = h_2(X) = 1/3 (strict-guidance lower bounds), g_3(X) = 1/3.
# g_j(X) = inf{ p_j : C_p pointwise weakly j-better than C_u and C_p accepts h }  (D -> h), computed on a grid
# with the fibre criterion (DD1 Lemma 2.2).   Run: python3 -I defence_index.py
import itertools, math
eps = 0.3
T1 = [[(1 - eps) / 3 + (eps if i == k else 0) for i in range(3)] for k in range(3)]
E = [[1.0 if i == j else 0.0 for i in range(3)] for j in range(3)]

def post(p):
    out = []
    for v in T1:
        w = [p[i] * v[i] for i in range(3)]; s = sum(w); out.append([x / s for x in w])
    return out

def bary(P, A, B, C):  # barycentric coords of P in triangle ABC (in the plane sum=1)
    # use coordinates 0,1
    x, y = P[0], P[1]; x1, y1 = A[0], A[1]; x2, y2 = B[0], B[1]; x3, y3 = C[0], C[1]
    d = (y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3)
    l1 = ((y2 - y3) * (x - x3) + (x3 - x2) * (y - y3)) / d
    l2 = ((y3 - y1) * (x - x3) + (x1 - x3) * (y - y3)) / d
    return l1, l2, 1 - l1 - l2

def in_hull(P, pts, tol=1e-12):
    # pts: list of points (convex position not assumed); test via triangle fan over all triples
    for A, B, C in itertools.combinations(pts, 3):
        try:
            l = bary(P, A, B, C)
        except ZeroDivisionError:
            continue
        if min(l) >= -tol: return True
    return False

def seg_meets_tri(a, b, tri, tol=1e-12):
    # does segment [a,b] meet triangle tri (2-d, plane sum=1)?  sample-free exact-ish test
    if in_hull(a, tri, tol) or in_hull(b, tri, tol): return True
    def cross(o, p, q): return (p[0]-o[0])*(q[1]-o[1]) - (p[1]-o[1])*(q[0]-o[0])
    def inter(p1, p2, p3, p4):
        d1 = cross(p3, p4, p1); d2 = cross(p3, p4, p2); d3 = cross(p1, p2, p3); d4 = cross(p1, p2, p4)
        return (d1 * d2 <= tol) and (d3 * d4 <= tol)
    for k in range(3):
        if inter(a, b, tri[k], tri[(k + 1) % 3]): return True
    return False

def pw_better(K, L, i):
    """D_K pointwise weakly i-better than D_L (DD1 Lemma 2.2): (A) K in co(L u {e_i}); (B) each [l,e_i] meets K."""
    hullL = L + [E[i]]
    if not all(in_hull(k, hullL) for k in K): return False
    return all(seg_meets_tri(l, E[i], K) for l in L)

def accepts(K, h): return all(sum(m[i] * h[i] for i in range(3)) > 0 for m in K)

def g_index(h, j, N=1200):
    best = None
    for a in range(N + 1):
        for b in range(N + 1 - a):
            p = [a / N, b / N, (N - a - b) / N]
            if min(p) <= 0: continue
            if best is not None and p[j] >= best: continue
            K = post(p)
            if not accepts(K, h): continue
            if pw_better(K, T1, j): best = p[j]
    return best

if __name__ == '__main__':
    u = [1/3]*3
    print('sanity: C_u pointwise 1-better than itself:', pw_better(T1, T1, 0))
    for x in (0.02, 0.05, 0.1, 0.3, 1.0):
        y = (7/16) * (1 + x) * 1.02            # just outside facet F_3 (v_3.h < 0), v_1.h, v_2.h > 0
        h = [1.0, x, -y]
        vals = [sum(T1[k][i] * h[i] for i in range(3)) for k in range(3)]
        g1 = g_index(h, 0); g2 = g_index(h, 1)
        S = g1 + g2 + 1/3
        fail1 = g1 / S <= 1/3; fail2 = g2 / S <= 1/3
        print(f'h=(1,{x},-{y:.4f})  v.h={["%.4f" % v for v in vals]}  g1={g1:.4f} g2={g2:.4f} g3=1/3  sum g={S:.4f}'
              f'  scaled-index forces F2 at world 1: {fail1}, at world 2: {fail2}')
