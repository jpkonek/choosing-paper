# EE1 toy: finite record calculus on n cells (full four-advice domain restricted to cell-constant models).
# Advice: 0 '+', 1 '0', 2 '-', 3 'x'.  World-i rank at a cell with sign s_i: s=+1: +<0<-<x ; s=-1: -<0<+<x.
# Records: per cell either identity (code 0) or an arrow (a->b), a!=b (codes 1..12).
# Used to CHECK: (i) the closure process = greatest fixed point below r0 (Thm 1.1/1.2 of EE1);
#                (ii) up-closure of success;  (iii) whether generator-wise (pairwise) monotonicity of r
#                     implies cap-exactness of the closure (it does NOT: two-cap loops, EE1 Thm 4.2).
import itertools, random
ADV = 4
ARROWS = [(a, b) for a in range(ADV) for b in range(ADV) if a != b]
CODE = {ab: k + 1 for k, ab in enumerate(ARROWS)}       # 1..12
DEC = {k + 1: ab for k, ab in enumerate(ARROWS)}

def rank(s, a):
    if a == 3: return 3
    if s > 0: return a                 # + 0 - -> 0 1 2
    return {0: 2, 1: 1, 2: 0}[a]       # - 0 + -> 0 1 2

# entrywise composition table: comp[e1][e2] = code or -1 (not composable)
COMP = [[-1] * 13 for _ in range(13)]
for e1 in range(13):
    for e2 in range(13):
        if e1 == 0: COMP[e1][e2] = e2; continue
        if e2 == 0: COMP[e1][e2] = e1; continue
        a, b = DEC[e1]; b2, c = DEC[e2]
        if b != b2: continue
        COMP[e1][e2] = 0 if a == c else CODE[(a, c)]

class Toy:
    def __init__(self, signs):
        self.signs = signs; self.n = len(signs)
        self.models = list(itertools.product(range(ADV), repeat=self.n))
    def rec(self, X, Y):
        return tuple(0 if X[c] == Y[c] else CODE[(X[c], Y[c])] for c in range(self.n))
    def apply(self, X, d):
        Y = list(X)
        for c, e in enumerate(d):
            if e:
                a, b = DEC[e]
                if X[c] != a: return None
                Y[c] = b
        return tuple(Y)
    def realizations(self, d):
        out = []
        for X in self.models:
            Y = self.apply(X, d)
            if Y is not None: out.append((X, Y))
        return out
    def worsening(self, i, d):   # weakly i-worsening (guidance) record
        for c, e in enumerate(d):
            if e:
                a, b = DEC[e]
                if rank(self.signs[c][i], b) < rank(self.signs[c][i], a): return False
        return True
    def strict_improving(self, i, d):
        nz = False
        for c, e in enumerate(d):
            if e:
                nz = True
                a, b = DEC[e]
                if rank(self.signs[c][i], b) > rank(self.signs[c][i], a): return False
        return nz
    def compose(self, d1, d2):
        out = []
        for e1, e2 in zip(d1, d2):
            e = COMP[e1][e2]
            if e < 0: return None
            out.append(e)
        return tuple(out)
    def closure(self, gens):
        A = set(gens); work = list(A)
        while work:
            d = work.pop(); new = []
            for e in list(A):
                for x in (self.compose(d, e), self.compose(e, d)):
                    if x is not None and x not in A:
                        A.add(x); new.append(x)
            work.extend(new)
        return A

class Inst:
    """selected: list of (model, p) with p a 3-tuple (index in the simplex; only coordinates are used)."""
    def __init__(self, toy, selected):
        self.t = toy; self.sel = selected; self.selmodels = {m: p for m, p in selected}
        self.guid = [[d for d in itertools.product(range(13), repeat=toy.n) if toy.worsening(i, d)] for i in range(3)]
    def caps(self, r, i):
        out = set()
        for m, p in self.sel:
            for X in self.t.models:
                if p[i] >= r[X][i]: out.add(self.t.rec(m, X))
        return out
    def closures(self, r):
        return [self.t.closure(set(self.guid[i]) | self.caps(r, i)) for i in range(3)]
    def F(self, r, A):
        """forced infima over the finite selected set; returns new r and F1 flag"""
        nr = {}; F1 = False
        for X in self.t.models:
            v = list(r[X])
            for i in range(3):
                forced = [p[i] for m, p in self.sel if self.t.rec(m, X) in A[i]]
                if forced:
                    v[i] = min(v[i], min(forced))
            nr[X] = tuple(v)
            if X in self.selmodels and tuple(v) != tuple(self.selmodels[X]): F1 = True
        return nr, F1
    def F2(self, A):
        return any(self.t.strict_improving(i, d) for i in range(3) for d in A[i])
    def process(self, r0, maxit=50, stopF2=True):
        r = dict(r0)
        for it in range(maxit):
            A = self.closures(r)
            nr, F1 = self.F(r, A)
            f2 = self.F2(A) if stopF2 else False
            if F1 or f2: return ('fail', 'F1' if F1 else 'F2', r)
            if nr == r: return ('ok', None, r)
            r = nr
        return ('nonterm', None, r)
    def pairwise_monotone(self, r):
        """r_i non-increasing along every realization of every generator (guidance and caps)."""
        for i in range(3):
            gens = set(self.guid[i]) | self.caps(r, i)
            for d in gens:
                for X, Y in self.t.realizations(d):
                    if r[Y][i] > r[X][i]: return False, (i, d, X, Y)
        return True, None
    def cap_exact(self, r, A):
        for X in self.t.models:
            for m, p in self.sel:
                for i in range(3):
                    if self.t.rec(m, X) in A[i] and p[i] < r[X][i]: return False, (X, m, i)
        return True, None

# ---- guidance saturation of a record at world i: all gamma o g o gamma' with gamma, gamma' i-worsening ----
def sat_entries(toy, i, c, e):
    s = toy.signs[c][i]
    out = set()
    if e == 0:
        out.add(0)
        for (a, b) in ARROWS:
            if rank(s, b) >= rank(s, a): out.add(CODE[(a, b)])
        return out
    a, b = DEC[e]
    for x in range(ADV):
        for zz in range(ADV):
            if rank(s, x) <= rank(s, a) and rank(s, zz) >= rank(s, b):
                out.add(0 if x == zz else CODE[(x, zz)])
    return out
def saturation(toy, i, d):
    opts = [sorted(sat_entries(toy, i, c, e)) for c, e in enumerate(d)]
    return set(itertools.product(*opts))
def som_violation(inst, r):
    """saturated one-step monotonicity: r_i non-increasing along every realisation of every saturated generator."""
    t = inst.t
    for i in range(3):
        gens = set(inst.guid[i]) | inst.caps(r, i)
        seen = set()
        for g in gens:
            for e in saturation(t, i, g):
                if e in seen: continue
                seen.add(e)
                for X, Y in t.realizations(e):
                    if r[Y][i] > r[X][i]: return (i, g, e, X, Y)
    return None
def som_process(inst, r0, maxit=200):
    r = dict(r0); t = inst.t
    for it in range(maxit):
        changed = False
        for i in range(3):
            gens = set(inst.guid[i]) | inst.caps(r, i)
            seen = set()
            for g in gens:
                for e in saturation(t, i, g):
                    if e in seen: continue
                    seen.add(e)
                    for X, Y in t.realizations(e):
                        if r[Y][i] > r[X][i]:
                            if Y in inst.selmodels: return ('fail', 'F1', r)
                            v = list(r[Y]); v[i] = r[X][i]; r[Y] = tuple(v); changed = True
        if not changed: return ('ok', None, r)
    return ('nonterm', None, r)
