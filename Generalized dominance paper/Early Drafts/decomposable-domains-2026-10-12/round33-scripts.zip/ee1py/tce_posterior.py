# EE1 Prop 4.6 (NUMERICS): two-cap exchange configurations through T1 in the posterior family.
# Want selected s=u (T1), z with z_1 > 1/3, and p, q such that
#   (i)  on Delta(u,z) = {C_u != C_z}:  C_u = C_p or C_u = C_q            (pointwise, a.e.)
#   (ii) C := {C_u = C_z, and C_u, C_p, C_q give three DIFFERENT kinds of advice} is non-null
#        (with only two kinds the chain factorises and single-generator monotonicity already catches it).
# Then D_1 := Delta(u,z) & {C_u = C_p}, D_2 := Delta(u,z) \ D_1, and the cross-splices
#   X = C_p with D_1 -> C_z-advice and C -> C_q-advice,   Y = C_q with C -> C_p-advice and D_2 -> C_z-advice
# satisfy rec(C_u, C_z) = rec(C_p, X) o rec(C_q, Y) up to a context change on C (EE1 Prop 4.6), so a clean
# threshold system must have r_1(X) > p_1 or r_1(Y) > q_1.
# Monte Carlo on directions (advice of D_K is conic).   Run: python3 -I tce_posterior.py
import math, random
random.seed(7)
eps = 0.3
T1 = [[(1 - eps) / 3 + (eps if i == k else 0) for i in range(3)] for k in range(3)]
def post(p):
    out = []
    for v in T1:
        w = [p[i] * v[i] for i in range(3)]; s = sum(w); out.append([x / s for x in w])
    return out
def advice(K, h):
    vals = [sum(m[i] * h[i] for i in range(3)) for m in K]
    if min(vals) > 0: return '+'
    if max(vals) < 0: return '-'
    return '0'
def sample_dirs(N, K0, frac_near=0.7):
    out = []
    while len(out) < N:
        h = [random.gauss(0, 1) for _ in range(3)]
        if h[0] < 0: h = [-x for x in h]
        if random.random() < frac_near:
            # keep only directions close to the boundary of D_T1 (where the selected models differ)
            vals = [sum(m[i] * h[i] for i in range(3)) / math.sqrt(sum(x * x for x in h)) for m in K0]
            if min(abs(v) for v in vals) > 0.06: continue
        out.append(h)
    return out
H = sample_dirs(60000, T1)
def config(z, p, q):
    Ku, Kz, Kp, Kq = T1, post(z), post(p), post(q)
    viol = 0; nD = 0; nC = 0; nD1 = 0
    for h in H:
        au, az, ap, aq = advice(Ku, h), advice(Kz, h), advice(Kp, h), advice(Kq, h)
        if au != az:
            nD += 1
            if au == ap: nD1 += 1
            elif au != aq: viol += 1
        elif len({au, ap, aq}) == 3:
            nC += 1
    return viol, nD, nD1, nC
def rp(center, rad):
    while True:
        d = [random.gauss(0, 1) for _ in range(3)]; m = sum(d) / 3; d = [x - m for x in d]
        nd = math.sqrt(sum(x * x for x in d)); t = rad * random.random()
        p = [center[i] + t * d[i] / nd for i in range(3)]
        if min(p) > 0.02: return p
u = [1/3] * 3
best = []
for trial in range(20000):
    z = rp(u, 0.04)
    if z[0] <= 1/3 + 0.005: continue
    p = rp(u, 0.45); q = rp(u, 0.45)
    viol, nD, nD1, nC = config(z, p, q)
    if viol == 0 and nC > 0 and 0 < nD1 < nD:
        best.append((nC, z, p, q, nD, nD1))
        if len(best) >= 5: break
print('configurations found (viol=0 on %d sampled directions, C non-null, D_1, D_2 non-null):' % len(H), len(best))
for nC, z, p, q, nD, nD1 in best:
    print('  z=(%.4f,%.4f,%.4f) p=(%.3f,%.3f,%.3f) q=(%.3f,%.3f,%.3f)  #Delta(u,z)=%d  #D1=%d  #D2=%d  #C=%d' %
          (*z, *p, *q, nD, nD1, nD - nD1, nC))
