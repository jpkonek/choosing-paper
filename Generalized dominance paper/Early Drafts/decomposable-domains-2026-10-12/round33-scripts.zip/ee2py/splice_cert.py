# EE2: exact certificates.
#  (1) T1 = C_u is a.e. a splice of two other selected models C_s, C_p of the patched family (posterior region).
#  (2) The complementary splice X gets assignment-independent comparisons to C_s and C_p by (IB)-transport of the
#      selected comparisons; these are not guidance comparisons at the worlds listed.
#  (3) A non-splice certificate (edge-parallel direction) for contrast.
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cells import *
u = [F(1, 3)]*3
def dist2(a, b): return sum((a[i]-b[i])**2 for i in range(3))
R2 = (F(3, 50)-F(1, 40))**2   # points within distance D-rho = 7/200 of u lie outside every bump
def report(name, w, lam):
    s = [u[i]-lam*w[i] for i in range(3)]; p = [u[i]+lam*w[i] for i in range(3)]
    print(f"== {name}: direction w={[str(x) for x in w]}, lambda={lam}")
    print(f"   s={[str(x) for x in s]}  p={[str(x) for x in p]}")
    print(f"   |s-u|^2={float(dist2(s,u)):.6f} < (7/200)^2={float(R2):.6f}: {dist2(s,u) < R2}  (outside all bumps; K_x = posterior)")
    ok, wit = is_splice(post2(s), post2(u), post2(p))
    print(f"   C_u a.e. a splice of C_s and C_p: {ok}" + ("" if ok else f"   witness cell {wit}"))
    if not ok: return
    Ps, Pu, Pp = post2(s), post2(u), post2(p)
    # X := complementary splice: C_s where C_u = C_p != C_s, C_p where C_u = C_s != C_p
    def Xadv(cls):  # cls = (s,u,p)
        if cls[0] == cls[2]: return cls[0]
        return cls[0] if cls[1] == cls[2] else cls[2]
    for i in range(3):
        if s[i] > u[i] > p[i]: better, worse, bname, wname = Ps, Pp, 's', 'p'
        elif s[i] < u[i] < p[i]: better, worse, bname, wname = Pp, Ps, 'p', 's'
        else: print(f"   world {i+1}: coordinate constant"); continue
        # transport: X <=_i C_worse and C_better <=_i X.  Are these guidance comparisons?
        g1 = True; g2 = True
        for cls, sg in cells([Ps, Pu, Pp]):
            x = Xadv(cls)
            cw = cls[2] if wname == 'p' else cls[0]
            cb = cls[0] if bname == 's' else cls[2]
            if rank(x, sg, i) > rank(cw, sg, i): g1 = False
            if rank(cb, sg, i) > rank(x, sg, i): g2 = False
        print(f"   world {i+1}: forced X <=_{i+1} C_{wname} and C_{bname} <=_{i+1} X  (so r_{i+1}(X) in [{wname}_{i+1}, {bname}_{i+1}]"
              f" = [{float(min(s[i],p[i])):.4f}, {float(max(s[i],p[i])):.4f}]);  guidance already gives them? {g1}, {g2}")
report("e_1-axis", [F(2), F(-1), F(-1)], F(1, 100))
report("e_3-axis", [F(-1), F(-1), F(2)], F(1, 100))
report("generic 50-degree direction", [F(214, 1000), F(276, 1000), F(-490, 1000)], F(1, 20))
report("edge-parallel e_2-e_3 (excluded band)", [F(0), F(1), F(-1)], F(1, 100))
# allowed-direction sweep at u, exact, small segments (delta=1/100 in the chart), one degree resolution
import math
print("== sweep of line directions through u (chart angle theta: d = (2X/6, -X/6+Y/2, -X/6-Y/2), X=cos, Y=sin):")
runs = []; prev = None
for k in range(180):
    a = math.radians(k)
    X, Y = F(round(10**4*math.cos(a)), 10**4), F(round(10**4*math.sin(a)), 10**4)
    d = [2*X/6, -X/6 + Y/2, -X/6 - Y/2]
    s = [u[i]-F(1, 100)*d[i] for i in range(3)]; p = [u[i]+F(1, 100)*d[i] for i in range(3)]
    ok = is_splice(post2(s), post2(u), post2(p))[0]
    if ok != prev: runs.append([k, k, ok]); prev = ok
    else: runs[-1][1] = k
print("   " + "; ".join(f"[{a},{b}] {'splice' if ok else 'not splice'}" for a, b, ok in runs))
# predicted boundary rays from the wedge condition: excluded double-sector for k=1 between (eps,1,-1-eps), (-eps,1+eps,-1)
def chart_angle(v):
    X = 3*v[0]; Y = 2*(v[1] + X/6)
    return math.degrees(math.atan2(float(Y), float(X))) % 180
e = eps
rays = []
for perm in ([0, 1, 2], [1, 2, 0], [2, 0, 1]):
    r1 = [None]*3; r2 = [None]*3
    base1 = [e, 1, -1-e]; base2 = [-e, 1+e, -1]
    for j in range(3): r1[perm[j]] = base1[j]; r2[perm[j]] = base2[j]
    rays.append((round(chart_angle(r1), 2), round(chart_angle(r2), 2)))
print("   predicted excluded sectors (chart angles, from the wedge condition):", rays)
