import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cells import *
import splice, random, math
random.seed(3)
u=[F(1,3)]*3
agree=0; tot=0
for k in range(36):
    a=math.radians(5*k)
    X,Y=F(round(1000*math.cos(a)),1000),F(round(1000*math.sin(a)),1000)
    d=[2*X/6,-X/6+Y/2,-X/6-Y/2]
    for delta in (F(1,60),F(1,6)):
        s=[u[i]-delta*d[i] for i in range(3)]; p=[u[i]+delta*d[i] for i in range(3)]
        A=is_splice(post2(s),post2(u),post2(p))[0]
        B=splice.splice_violation(post2(s),post2(u),post2(p)) is None
        tot+=1; agree+=(A==B)
print("cell-test vs support-test agreement:",agree,"/",tot)
# pointwise comparisons on the posterior family: along lines through e_1 (ratio p2/p3 fixed) world-1 better with larger p1
p=[F(1,4),F(3,8),F(3,8)]; q=[F(1,2),F(1,4),F(1,4)]
print("C_q <=_1 C_p pointwise (q on segment p-e1):",pointwise_le(post2(q),post2(p),0))
print("C_p <=_1 C_q pointwise:",pointwise_le(post2(p),post2(q),0))
print("C_q <=_2 C_p pointwise:",pointwise_le(post2(q),post2(p),1), " C_p <=_2 C_q:",pointwise_le(post2(p),post2(q),1))
