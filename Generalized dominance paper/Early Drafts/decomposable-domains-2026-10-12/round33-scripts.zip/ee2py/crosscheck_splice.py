# EE2: independent cross-check of the splice test by direct evaluation of advice on random gambles (exact).
# advice of D_K at g: '+' if m.g>0 for all vertices m of K, '-' if m.g<0 for all, '0' otherwise.
import sys, os, random; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from splice import *
random.seed(7)
def adv(K3, g):
    vals = [sum(m[i]*g[i] for i in range(3)) for m in K3]
    if all(v > 0 for v in vals): return '+'
    if all(v < 0 for v in vals): return '-'
    return '0'
def direct(s, t, p, N=40000):
    Ks, Kt, Kp = post3(s), post3(t), post3(p); bad = 0
    for _ in range(N):
        g = [F(random.randint(-10**6, 10**6), 10**6) for _ in range(3)]
        a, b, c = adv(Ks, g), adv(Kt, g), adv(Kp, g)
        if b != a and b != c: bad += 1
    return bad
u = [F(1, 3)]*3
cases = []
for (X, Y) in [(1, 0), (F(1000, 1000), F(87, 1000)), (F(866, 1000), F(500, 1000)), (0, 1), (F(-707, 1000), F(-707, 1000)),
               (F(940, 1000), F(342, 1000)), (F(-985, 1000), F(174, 1000))]:
    X, Y = F(X), F(Y)
    d = [2*X/6, -X/6 + Y/2, -X/6 - Y/2]
    for delta in (F(1, 15), F(1, 6)):
        s = [u[i]-delta*d[i] for i in range(3)]; p = [u[i]+delta*d[i] for i in range(3)]
        v = splice_violation(post2(s), post2(u), post2(p))
        cases.append(((X, Y), delta, v is None, direct(s, u, p)))
for c in cases:
    print(f"dir(X,Y)={str(c[0][0]):>8},{str(c[0][1]):>8} delta={str(c[1]):>5}: support-test splice={c[2]!s:5}  direct violations in 40000 random g = {c[3]}")
