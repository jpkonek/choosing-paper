# EE2: exact enumeration of the open cells of problem space for a finite list of coherent models D_K.
#
# A problem (pair {g,-g}) <-> (theta,c) up to positive scale, via g3=-c, g1=theta1-c, g2=theta2-c; then for
# m in aff(Delta) (2-D coords (m1,m2)), m.g = theta.m - c.  For a credal polygon K:
#   accept g ('+') iff c < min_K theta.m,  reject ('-') iff c > max_K theta.m,  silent ('0') otherwise.
# The sign pattern of g is sign(theta1-c), sign(theta2-c), sign(-c).
# Cells: open arcs of theta between consecutive critical directions (perpendiculars of all differences of
# points of all polygons and of the vertices of Delta), times open c-intervals between consecutive breakpoints.
# On each open cell, every class and every sign is constant; cells are non-null; their union is conull.
# So an a.e. statement about the advice of the listed models holds iff it holds on every realised cell.
from fractions import Fraction as F
import itertools, functools

def perp(v): return (-v[1], v[0])
def half(d): return 0 if (d[1] > 0 or (d[1] == 0 and d[0] > 0)) else 1
def cross(a, b): return a[0]*b[1] - a[1]*b[0]
def cmpang(a, b):
    ha, hb = half(a), half(b)
    if ha != hb: return -1 if ha < hb else 1
    c = cross(a, b)
    return -1 if c > 0 else (1 if c < 0 else 0)
DELTA2 = [(F(1), F(0)), (F(0), F(1)), (F(0), F(0))]

def arc_reps(points):
    dirs = [(F(1), F(0)), (F(0), F(1)), (F(-1), F(0)), (F(0), F(-1))]
    pts = list(set(points))
    for a, b in itertools.combinations(pts, 2):
        v = (a[0]-b[0], a[1]-b[1])
        q = perp(v); dirs += [q, (-q[0], -q[1])]
    dirs.sort(key=functools.cmp_to_key(cmpang))
    cd = []
    for d in dirs:
        if cd and cmpang(cd[-1], d) == 0: continue
        cd.append(d)
    n = len(cd)
    return [(cd[i][0]+cd[(i+1) % n][0], cd[i][1]+cd[(i+1) % n][1]) for i in range(n)]

def cells(polys):
    """Yield (classes, signs) for a representative of every open cell.  polys: list of lists of 2-D points."""
    pts = [p for P in polys for p in P] + DELTA2
    seen = set()
    for th in arc_reps(pts):
        lo = [min(th[0]*x+th[1]*y for x, y in P) for P in polys]
        hi = [max(th[0]*x+th[1]*y for x, y in P) for P in polys]
        bps = sorted(set(lo + hi + [th[0], th[1], F(0)]))
        reps = [bps[0]-1] + [(bps[k]+bps[k+1])/2 for k in range(len(bps)-1)] + [bps[-1]+1]
        for c in reps:
            cls = tuple('+' if c < lo[k] else ('-' if c > hi[k] else '0') for k in range(len(polys)))
            g = (th[0]-c, th[1]-c, -c)
            sg = tuple(1 if x > 0 else -1 for x in g)
            key = (cls, sg)
            if key not in seen:
                seen.add(key); yield key

# world-i rank of an advice on a problem with sign pattern sg:  good 0 < none 1 < bad 2  (contradictory: 3)
def rank(adv, sg, i):
    if adv == '0': return 1
    if adv == 'x': return 3
    good = (adv == '+') == (sg[i] > 0)
    return 0 if good else 2

# ---------- families ----------
eps = F(3, 10); c0 = (1-eps)/3
T1 = [[c0 + (eps if i == k else 0) for i in range(3)] for k in range(3)]
def post3(p):
    out = []
    for v in T1:
        w = [F(p[i])*v[i] for i in range(3)]; t = sum(w); out.append([x/t for x in w])
    return out
def post2(p): return [(m[0], m[1]) for m in post3(p)]
def mink2(A, B, b):
    b = F(b)
    return [((1-b)*a[0]+b*c[0], (1-b)*a[1]+b*c[1]) for a in A for c in B]
def hull2(P):
    pts = sorted(set(P))
    if len(pts) <= 2: return pts
    def cr(o, a, b): return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    lo = []; up = []
    for p in pts:
        while len(lo) >= 2 and cr(lo[-2], lo[-1], p) <= 0: lo.pop()
        lo.append(p)
    for p in reversed(pts):
        while len(up) >= 2 and cr(up[-2], up[-1], p) <= 0: up.pop()
        up.append(p)
    return lo[:-1]+up[:-1]

# ---------- generic tests ----------
def is_splice(Ps, Pt, Pp):
    """D_t(g) in {D_s(g), D_p(g)} a.e."""
    for cls, sg in cells([Ps, Pt, Pp]):
        if cls[1] != cls[0] and cls[1] != cls[2]: return False, (cls, sg)
    return True, None
def pointwise_le(PX, PY, i):
    """D_X weakly i-better than D_Y a.e.; returns (weak, strict_somewhere)."""
    strict = False
    for cls, sg in cells([PX, PY]):
        a, b = rank(cls[0], sg, i), rank(cls[1], sg, i)
        if a > b: return False, False
        if a < b: strict = True
    return True, strict
