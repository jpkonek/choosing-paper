# EE2: exact splice-triple test for coherent models D_K (K a credal polygon).
#
# Lines in aff(Delta) <-> gambles g (up to positive scale): in 2-D coords m=(m1,m2), m.g = theta.m - c with
# theta=(g1-g3, g2-g3), c=-g3.  D_K accepts g iff c < alpha_K(theta) := -h_K(-theta); rejects iff c > beta_K(theta)
# := h_K(theta); silent iff alpha_K < c < beta_K.  (h_K = support function.)  The map g <-> (theta,c) is linear,
# so null sets correspond.
#
# Splice lemma (EE2 Lemma 2.4): D_{Kt}(g) in {D_{Ks}(g), D_{Kp}(g)} for a.e. g  iff for every theta
#   (i)  h_t(theta) lies in [min(h_s,h_p)(theta), max(h_s,h_p)(theta)]   (betweenness, applied at theta and -theta)
#   (ii) the open interval I_t(theta)=(alpha_t,beta_t) is contained in the closure of I_s(theta) u I_p(theta).
# Everything below is exact rational arithmetic.
from fractions import Fraction as F
import itertools

def to2(m): return (F(m[0]), F(m[1]))
def h(P, th):  # support function of polygon P (list of 2-D points) at direction th
    return max(th[0]*x + th[1]*y for x, y in P)
def perp(v): return (-v[1], v[0])
def half(d): return 0 if (d[1] > 0 or (d[1] == 0 and d[0] > 0)) else 1
def cross(a, b): return a[0]*b[1] - a[1]*b[0]
def ang_key_cmp(a, b):
    ha, hb = half(a), half(b)
    if ha != hb: return -1 if ha < hb else 1
    c = cross(a, b)
    return -1 if c > 0 else (1 if c < 0 else 0)
import functools
def critical_dirs(polys):
    pts = [p for P in polys for p in P]
    dirs = [(F(1), F(0)), (F(0), F(1)), (F(-1), F(0)), (F(0), F(-1))]
    for a, b in itertools.combinations(pts, 2):
        v = (a[0]-b[0], a[1]-b[1])
        if v == (0, 0): continue
        q = perp(v); dirs += [q, (-q[0], -q[1])]
    # dedupe by direction
    dirs.sort(key=functools.cmp_to_key(ang_key_cmp))
    out = []
    for d in dirs:
        if out and ang_key_cmp(out[-1], d) == 0: continue
        out.append(d)
    return out
def test_dirs(polys):
    cd = critical_dirs(polys)
    n = len(cd); T = list(cd)
    for i in range(n):
        a, b = cd[i], cd[(i+1) % n]
        T.append((a[0]+b[0], a[1]+b[1]))   # strictly between (consecutive gap < pi/2)
    return T
def splice_violation(Ps, Pt, Pp):
    """Return None if D_t is a.e. a splice of D_s and D_p; else a witness direction theta and a reason.
    Polygons as lists of 2-D rational points (vertices or any finite generating set)."""
    for th in test_dirs([Ps, Pt, Pp]):
        mth = (-th[0], -th[1])
        bs, bt, bp = h(Ps, th), h(Pt, th), h(Pp, th)
        as_, at, ap = -h(Ps, mth), -h(Pt, mth), -h(Pp, mth)
        if not (min(bs, bp) <= bt <= max(bs, bp)): return (th, 'beta-betweenness', (bs, bt, bp))
        if not (min(as_, ap) <= at <= max(as_, ap)): return (th, 'alpha-betweenness', (as_, at, ap))
        # gap condition: if I_s and I_p are disjoint, I_t must lie in one of them
        if bs < ap or bp < as_:
            lo, hi = (bs, ap) if bs < ap else (bp, as_)   # the gap (lo,hi)
            if at < hi and bt > lo:   # I_t meets the gap
                return (th, 'gap', (lo, hi, at, bt))
    return None

# ---------- the posterior family, exact ----------
eps = F(3, 10); c0 = (1-eps)/3
T1 = [[c0 + (eps if i == k else 0) for i in range(3)] for k in range(3)]
def post3(p):
    out = []
    for v in T1:
        w = [F(p[i])*v[i] for i in range(3)]; t = sum(w); out.append([x/t for x in w])
    return out
def post2(p): return [to2(m) for m in post3(p)]
def mink2(A, B, b):  # generating set of (1-b)A + bB
    b = F(b)
    return [((1-b)*a[0]+b*c[0], (1-b)*a[1]+b*c[1]) for a in A for c in B]
