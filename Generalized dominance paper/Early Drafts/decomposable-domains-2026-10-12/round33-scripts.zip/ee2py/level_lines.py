# EE2: splice lines along which one coordinate is constant (T-ties).  At u these directions are excluded
# (edge-parallel), but the projective symmetry moves the excluded bands; at c=(1/5,3/5,1/5) the level line of the
# first coordinate is a splice line, so C_a ~_1 C_b transports to ties X ~_1 C_s for complementary splices.  Exact.
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cells import *
for c, i in [([F(1,5),F(3,5),F(1,5)],0), ([F(1,3)]*3,0), ([F(1,4),F(1,2),F(1,4)],0), ([F(3,5),F(1,5),F(1,5)],0)]:
    j,l=[k for k in range(3) if k!=i]
    for lam in (F(1,100),F(1,30)):
        d=[F(0)]*3; d[j]=F(1); d[l]=F(-1)
        s=[c[k]-lam*d[k] for k in range(3)]; p=[c[k]+lam*d[k] for k in range(3)]
        ok=is_splice(post2(s),post2(c),post2(p))[0]
        print(f"c={[str(x) for x in c]}  level line x_{i+1}={c[i]}  half-length {lam}: splice={ok}")
