# EE2: are there NON-collinear local splice triples (s,u,p) in the posterior family?  Exact test on a grid of
# direction pairs (s=u+delta*x, p=u+delta*y, x,y unit-ish chart directions, angle step 6 deg, delta=1/100).
import sys, os, math; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cells import *
u=[F(1,3)]*3
def d_of(k):
    a=math.radians(k); X,Y=F(round(10**4*math.cos(a)),10**4),F(round(10**4*math.sin(a)),10**4)
    return [2*X/6,-X/6+Y/2,-X/6-Y/2]
hits=[]; tot=0
for a in range(0,360,6):
    for b in range(a+6,360,6):
        x,y=d_of(a),d_of(b); dl=F(1,100)
        s=[u[i]+dl*x[i] for i in range(3)]; p=[u[i]+dl*y[i] for i in range(3)]
        tot+=1
        if is_splice(post2(s),post2(u),post2(p))[0]: hits.append((a,b))
print("pairs tested:",tot," splice:",len(hits))
print("splice pairs (chart angles of s-u and p-u):",hits)
