# EE2: which posterior triples (s,t,p) are splice triples (D_t a.e. a splice of D_s, D_p)?  Exact.
import sys, os, random; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from splice import *
random.seed(1)
def rnd_interior(den=60, lo=6):
    while True:
        a = random.randint(lo, den-2*lo); b = random.randint(lo, den-a-lo)
        c = den-a-b
        if c >= lo: return [F(a, den), F(b, den), F(c, den)]
def comb(s, p, lam): return [(1-lam)*s[i]+lam*p[i] for i in range(3)]
u = [F(1, 3)]*3
# 1. random non-collinear triples
nc = 0; ncs = 0
for _ in range(300):
    s, t, p = rnd_interior(), rnd_interior(), rnd_interior()
    if len({tuple(s), tuple(t), tuple(p)}) < 3: continue
    nc += 1
    if splice_violation(post2(s), post2(t), post2(p)) is None: ncs += 1
print("random non-collinear triples:", nc, " splice triples among them:", ncs)
# 2. collinear triples through u, short, direction sweep
print("collinear triples s=u-d*delta, t=u, p=u+d*delta (delta=1/60):")
dirs = []
for k in range(36):
    import math
    a = math.radians(5*k)
    # direction in sum-zero plane, rational approximation
    X, Y = F(round(1000*math.cos(a)), 1000), F(round(1000*math.sin(a)), 1000)
    # basis: X along (2,-1,-1)/sqrt6, Y along (0,1,-1)/sqrt2 -> use unnormalised rational basis
    d = [2*X/6, -X/6 + Y/2, -X/6 - Y/2]
    dirs.append((5*k, d))
res = []
for deg, d in dirs:
    for delta in (F(1, 60), F(1, 15)):
        s = [u[i]-delta*d[i] for i in range(3)]; p = [u[i]+delta*d[i] for i in range(3)]
        v = splice_violation(post2(s), post2(u), post2(p))
        res.append((deg, delta, v is None, None if v is None else v[1]))
for deg in range(0, 180, 5):
    r = [x for x in res if x[0] == deg]
    print(f"  angle {deg:3d} deg: " + "  ".join(f"delta={x[1]}: {'SPLICE' if x[2] else 'no ('+x[3]+')'}" for x in r))
