# EE2: exact tests of the shortest assignment-independent F1 chains that use IB-transports of selected comparisons
# (T-links) on the posterior family.
#   GT : C_q <=_i X by guidance,  X <=_i C_p by transport of C_s <=_i C_t   (X = complementary splice of (s,t,p))
#   TG : C_q <=_i X by transport of C_a <=_i C_b,  X <=_i C_p by guidance  (X = C_q (+) R(a,b))
#   NCT: three-world (NC) with T-relaxed targets Y_o <=_o C_{p^o}
# F1 needs q_i < p_i (GT, TG) or sum_o p^o_o >= 1 (NCT).  All checks are exact (cells.py); the sampling is random.
import sys, os, random, math; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cells import *
random.seed(int(sys.argv[1]) if len(sys.argv) > 1 else 11)
u = [F(1, 3)]*3
def phi(x, c):  # projective map of Delta fixing vertices, u -> c  (maps posterior family onto itself)
    w = [x[i]*c[i] for i in range(3)]; t = sum(w); return [y/t for y in w]
def rnd_point(lo=F(1, 6)):
    while True:
        a = F(random.randint(10, 80), 100); b = F(random.randint(10, 80), 100)
        c = 1-a-b
        if min(a, b, c) >= lo: return [a, b, c]
def allowed_dir():
    # directions at u inside every +-Gamma_k (CHECKED in splice sweep); sample angles away from edge bands
    while True:
        ang = random.uniform(0, math.pi)
        X, Y = F(round(1000*math.cos(ang)), 1000), F(round(1000*math.sin(ang)), 1000)
        d = [2*X/6, -X/6 + Y/2, -X/6 - Y/2]
        return d
def splice_triple(c, scale):
    d = allowed_dir()
    a1, a2 = F(random.randint(1, 20), 20)*scale, F(random.randint(1, 20), 20)*scale
    s0 = [u[i]-a1*d[i] for i in range(3)]; p0 = [u[i]+a2*d[i] for i in range(3)]
    s, t, p = phi(s0, c), c, phi(p0, c)
    ok, _ = is_splice(post2(s), post2(t), post2(p))
    return (s, t, p) if ok else None
def ranks_ok_GT(q, s, t, p, i):
    P = [post2(q), post2(s), post2(t), post2(p)]
    for cls, sg in cells(P):
        X = cls[1] if cls[1] != cls[2] else cls[3]
        if rank(cls[0], sg, i) > rank(X, sg, i): return False
    return True
def ranks_ok_TG(q, a, b, p, i):
    P = [post2(q), post2(a), post2(b), post2(p)]
    for cls, sg in cells(P):
        X = cls[2] if cls[1] != cls[2] else cls[0]
        if rank(X, sg, i) > rank(cls[3], sg, i): return False
    return True
def pos(adv, sg, o):
    if adv == '0': return 1
    good = '+' if sg[o] > 0 else '-'
    return 0 if adv == good else 2
def compat(Ys):
    # Ys[o] = (p, a, b) or (p, None, None); Y_o = C_a on {C_a != C_b}, C_p elsewhere
    polys = []; idx = []
    for (p, a, b) in Ys:
        k = len(polys); polys.append(post2(p))
        if a is not None:
            polys.append(post2(a)); polys.append(post2(b)); idx.append((k, k+1, k+2))
        else: idx.append((k, None, None))
    for cls, sg in cells(polys):
        if len(set(sg)) == 1: continue
        o = [k for k in range(3) if sum(1 for m in range(3) if sg[m] == sg[k]) == 1][0]
        Y = []
        for (kp, ka, kb) in idx:
            Y.append(cls[ka] if (ka is not None and cls[ka] != cls[kb]) else cls[kp])
        po = pos(Y[o], sg, o)
        if any(pos(Y[j], sg, o) > po for j in range(3) if j != o): return False
    return True

nGT = nTG = hitGT = hitTG = 0; nsp = 0; tried = 0
while nGT < 300:
    tried += 1
    c = rnd_point(); tr = splice_triple(c, F(1, 10))
    if tr is None: continue
    nsp += 1
    s, t, p = tr
    for i in range(3):
        if s[i] >= t[i] >= p[i]: pass
        elif s[i] <= t[i] <= p[i]: s, p = p, s   # orient so that s_i >= t_i >= p_i
        else: continue
        # candidates q: on the e_i-line through p moved away from e_i, and random near p, all with q_i < p_i
        cands = []
        lam = F(random.randint(1, 10), 200)
        cands.append([p[k] - lam*((1 if k == i else 0) - p[k]) for k in range(3)])
        for _ in range(3):
            dq = [F(random.randint(-30, 30), 1000) for _ in range(2)]
            q = [p[0]+dq[0], p[1]+dq[1], p[2]-dq[0]-dq[1]]
            cands.append(q)
        for q in cands:
            if min(q) <= 0 or q[i] >= p[i]: continue
            nGT += 1; hitGT += ranks_ok_GT(q, s, t, p, i)
            # TG with (q,a,b) := (s,t,p) roles: C_q=C_s base needs q before s on the line: use (s,t,p) as (q,a,b)
        # TG: base = s (as q), a = t, b = p ; target p2 random with p2_i > s_i
        for _ in range(3):
            dq = [F(random.randint(-30, 30), 1000) for _ in range(2)]
            p2 = [s[0]+dq[0], s[1]+dq[1], s[2]-dq[0]-dq[1]]
            if min(p2) <= 0 or p2[i] <= s[i]: continue
            # transport acceptance needs a_i >= b_i i.e. t_i >= p_i : true by orientation
            nTG += 1; hitTG += ranks_ok_TG(s, t, p, p2, i)
print(f"splice triples generated: {nsp} (of {tried} attempts)")
print(f"GT chains tested: {nGT}; F1 chains found (C_q >=_i X pointwise with q_i<p_i): {hitGT}")
print(f"TG chains tested: {nTG}; F1 chains found (X >=_i C_p pointwise with q_i<p_i): {hitTG}")
# NCT: near-diagonal triples with sum_o p^o_o >= 1, random T-relaxations
nN = hitN = plainN = 0
while nN < 200:
    c = rnd_point()
    deltas = []
    for o in range(3):
        dq = [F(random.randint(-20, 20), 1000) for _ in range(2)]
        deltas.append([dq[0], dq[1], -dq[0]-dq[1]])
    ps = [[c[k]+deltas[o][k] for k in range(3)] for o in range(3)]
    if min(min(p) for p in ps) <= 0: continue
    S = sum(ps[o][o] for o in range(3))
    if S < 1: continue
    Ys = []
    for o in range(3):
        if random.random() < 0.7:
            # needle along a splice line through p^o with increasing o-coordinate
            for _ in range(20):
                d = allowed_dir(); dd = [x for x in d]
                q0 = [phi([u[k]+F(1, 50)*dd[k] for k in range(3)], ps[o])[k]-ps[o][k] for k in range(3)]
                if q0[o] < 0: q0 = [-x for x in q0]
                if q0[o] <= 0: continue
                al = F(random.randint(1, 40), 10); be = al*F(random.randint(1, 9), 10)
                a = [ps[o][k]+al*q0[k] for k in range(3)]; b = [ps[o][k]+be*q0[k] for k in range(3)]
                if min(a) <= 0 or min(b) <= 0: continue
                if is_splice(post2(a), post2(b), post2(ps[o]))[0]:
                    Ys.append((ps[o], a, b)); break
            else:
                Ys.append((ps[o], None, None))
        else:
            Ys.append((ps[o], None, None))
    nN += 1
    plainN += compat([(ps[o], None, None) for o in range(3)])
    hitN += compat(Ys)
print(f"NCT: near-diagonal triples with sum>=1 tested: {nN}; plainly compatible: {plainN}; compatible after T-relaxation: {hitN}")
