# GG1 exact checks (Fractions only). Run: python3 -I gg1_checks.py
from fractions import Fraction as F
from itertools import product

def lexneg(x):          # x = (top, second) in R^2 lex
    return x[0] < 0 or (x[0] == 0 and x[1] < 0)
def lexnonneg(x):
    return not lexneg(x)

# ---- Check 1: the Step-5 example (Lemma 2.2) ----
a = ((F(0), F(1)), (F(0), F(-1)))
b = ((F(0), F(-1)), (F(0), F(1)))
c = ((F(1), F(0)), (F(-2), F(0)))
def comb(al, be, ga):
    return tuple(tuple(al*a[w][l] + be*b[w][l] + ga*c[w][l] for l in range(2)) for w in range(2))
grid = [F(k, 12) for k in range(13)]
bad = 0
for al, be, ga in product(grid, grid, grid):
    z = comb(al, be, ga)
    if lexneg(z[0]) and lexneg(z[1]):
        bad += 1
print("check1a zonotope points strictly lex-better at both worlds:", bad, "of", len(grid)**3)
# no real weight w=(w1,w2)>=0, not 0, with w.z >=lex 0 on generators a,b,c
wgrid = [F(k, 20) for k in range(21)]
ok = 0
for w1, w2 in product(wgrid, wgrid):
    if w1 == 0 and w2 == 0:
        continue
    def wz(z):
        return tuple(w1*z[0][l] + w2*z[1][l] for l in range(2))
    if all(lexnonneg(wz(g)) for g in (a, b, c)):
        ok += 1
print("check1b real weights on grid supporting all generators:", ok)
# Hahn weights w_i = x_i + y_i*eps (x_i,y_i rational): products with z = s + t*eps,
# truncated at eps^2 is exact for the sign test of the eps^0, eps^1 coefficients, and
# the eps^2 coefficient only matters if both vanish.
ok2 = 0
hgrid = [F(k, 4) for k in range(-4, 5)]
for x1, y1, x2, y2 in product(wgrid[::4], hgrid, wgrid[::4], hgrid):
    W = ((x1, y1), (x2, y2))
    if (x1, y1) == (0, 0) and (x2, y2) == (0, 0):
        continue
    # positivity of weights in Hahn order
    if any(lexneg(Wi) for Wi in W):
        continue
    def wz(z):
        c0 = W[0][0]*z[0][0] + W[1][0]*z[1][0]
        c1 = W[0][0]*z[0][1] + W[0][1]*z[0][0] + W[1][0]*z[1][1] + W[1][1]*z[1][0]
        c2 = W[0][1]*z[0][1] + W[1][1]*z[1][1]
        return (c0, c1, c2)
    def nonneg3(v):
        for t in v:
            if t != 0:
                return t > 0
        return True
    if all(nonneg3(wz(g)) for g in (a, b, c)):
        ok2 += 1
print("check1c Hahn weights (x+y eps) on grid supporting all generators:", ok2)

# ---- Check 2: geometry used in Theorem 3.3 (eps = 3/10) ----
eps = F(3, 10); c0 = (1-eps)/3
v = [tuple(c0 + (eps if j == k else 0) for j in range(3)) for k in range(3)]
dot = lambda x, y: sum(p*q for p, q in zip(x, y))
kap = (1+2*eps)/(1-eps)
# a point of D_T1 with h_1<0, h_2<0 (near corner r_12), with a ball inside D_T1
h = (F(-1), F(-1), kap + 1 + F(1, 10))
print("check2a v_m.h for h near r12 inside D_T1:", [str(dot(vk, h)) for vk in v],
      "signs (h1,h2,h3) =", tuple(int(x > 0) - int(x < 0) for x in h))
# E_i(B^j) u E_i(B^k) covers every mixed sign pattern (i=1, j=2, k=3)
pats = [s for s in product((1, -1), repeat=3) if 1 in s and -1 in s]
cover = True
for s in pats:
    err_Bj = (s[0] < 0 and s[1] > 0) or (s[0] > 0 and s[1] < 0)
    err_Bk = (s[0] < 0 and s[2] > 0) or (s[0] > 0 and s[2] < 0)
    if not (err_Bj or err_Bk):
        cover = False
print("check2b every mixed pattern is a world-1 error of B^2 or B^3:", cover)
