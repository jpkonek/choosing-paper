"""GG2 NUMERICS: VB's lexicographic field on the U-domain.

Checks, by sampling, the two claims of GG2 Proposition 4.2:
 (1) for random NA-positive lexicographic weights Phi (up to three stages, boundary
     supports included, arbitrary 'free' coefficients on consumed coordinates), the
     set of gambles g in U whose Phi-lex cost of acceptance is <=_lex 0 is
     midpoint-convex (tested on random accepted pairs, margin-filtered);
 (2) at Phi* = (u . vetoes, u . Psi) the accepted set is D_T1 (mod boundary).
No verdict of the note rests on this script.
Run:  python3 -I vb_lex_check.py
"""
import numpy as np

rng = np.random.default_rng(20261018)
eps = 0.3
c0 = (1 - eps) / 3
V = np.array([c0 * np.ones(3) + eps * np.eye(3)[k] for k in range(3)])  # T1 vertices
u = np.ones(3) / 3
s = 0.5
Kp = u + s * (V - u)  # K' vertices

def in_U(g):
    return np.min(Kp @ g) > 0

def dcost(g):
    """accept-minus-silence cost vector: coords (i,1)=veto (v_i.g)^-, (i,2)=Psi -g_i"""
    vet = np.maximum(-(V @ g), 0.0)
    psi = -g
    return np.concatenate([vet, psi])  # index i -> (i,1), 3+i -> (i,2)

def random_phi():
    """random NA-positive lexicographic weight on the 6 coordinates."""
    stages = []
    consumed = set()
    # stage 1: w >= 0 on veto coords, random support
    supp = [i for i in range(3) if rng.random() < 0.6] or [int(rng.integers(3))]
    w = np.zeros(6)
    for i in supp:
        w[i] = rng.random() + 0.05
    stages.append(w); consumed |= set(supp)
    cur = {i: 1 for i in range(3)}  # current layer index per world
    for i in supp:
        cur[i] = 2
    for _ in range(int(rng.integers(1, 3))):
        phi = np.zeros(6)
        for c in consumed:  # free coefficients on consumed coordinates
            phi[c] = rng.normal() * 3
        newc = set()
        for i in range(3):
            if rng.random() < 0.6:
                idx = i if cur[i] == 1 else (3 + i if cur[i] == 2 else None)
                if idx is not None:
                    phi[idx] = rng.random() + 0.05
                    newc.add((i, idx))
        if not newc:
            continue
        stages.append(phi)
        for (i, idx) in newc:
            consumed.add(idx); cur[i] += 1
    return stages

def lexval(stages, g, tol=1e-12):
    d = dcost(g)
    for phi in stages:
        v = phi @ d
        if v < -tol:
            return -1
        if v > tol:
            return 1
    return 0

def margin_ok(stages, g, m=1e-6):
    d = dcost(g)
    for phi in stages:
        v = phi @ d
        if abs(v) > m * np.linalg.norm(g):
            return True
        if abs(v) > 1e-12:
            return False
    return True

def sample_U(n):
    out = []
    while len(out) < n:
        g = rng.normal(size=3) * rng.choice([0.5, 1, 3])
        if in_U(g):
            out.append(g)
    return out

pts = sample_U(4000)
viol = 0; tested = 0
for trial in range(300):
    stages = random_phi()
    acc = [g for g in pts if lexval(stages, g) <= 0 and margin_ok(stages, g)]
    if len(acc) < 2:
        continue
    for _ in range(200):
        a, b = acc[rng.integers(len(acc))], acc[rng.integers(len(acc))]
        mid = 0.5 * (a + b)
        tested += 1
        if lexval(stages, mid, tol=1e-9) > 0:
            viol += 1
print(f"(1) midpoint-convexity: {tested} accepted pairs over 300 random NA weights, {viol} violations")

# (2) Phi* = (u.vetoes, u.Psi) gives D_T1
stages = [np.concatenate([u, np.zeros(3)]), np.concatenate([np.zeros(3), u])]
mism = 0; n = 0
for g in pts:
    PT = np.min(V @ g)
    if abs(PT) < 1e-6 * np.linalg.norm(g):
        continue
    n += 1
    if (lexval(stages, g) < 0) != (PT > 0):
        mism += 1
print(f"(2) T1 at Phi*=(u.veto, u.Psi): {n} gambles of U, {mism} mismatches with D_T1")
