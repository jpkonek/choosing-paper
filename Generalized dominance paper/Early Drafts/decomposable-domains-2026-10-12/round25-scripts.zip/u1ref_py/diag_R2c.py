import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import ref_checks as rc
rng = np.random.default_rng(3)
eps, s = 0.1, 0.9
c0, kap, V, Vp = rc.setup(eps, s)
P = np.vstack([Vp, [0.43007323, 0.56992677, 0.], [0.51798581, 0.48201419, 0.], [0.40990023, 0.30742517, 0.2826746]])
sp_ = rng.uniform(0.56992677/0.43007323, kap, 200000); tp = rng.uniform(0, kap - sp_)
g = np.stack([sp_, -np.ones_like(sp_), tp], 1)
viol = (rc.PK(P, g) > 0) & (rc.PK(V, g) <= 0)
print("trial-87 targeted (b2) witnesses:", int(viol.sum()), "of", len(g))
