"""Diagnose (R2) cases: criterion 'no' but sampling found no violation. Targeted chart sampling."""
import numpy as np
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ref_checks as rc
rng = np.random.default_rng(7)

def chart_test(P, kap, kapU, n=400000):
    # (a1) quad of O1+: (1,-a,-b) ; (a2) quad of O2+: (-a,1,-b): must accept
    a, b = rng.uniform(0, 1/kap, (2, n))
    q = (kap*a + b < 1) & (a + kap*b < 1)
    g1 = np.stack([np.ones(n), -a, -b], 1)[q]; g2 = np.stack([-a, np.ones(n), -b], 1)[q]
    v_a1 = np.sum(rc.PK(P, g1) <= 0); v_a2 = np.sum(rc.PK(P, g2) <= 0)
    # (b1) O1- \ T1: (-1,s,t), kapU < s+t < kap : must reject ; (b2) (s,-1,t)
    s, t = rng.uniform(0, kap, (2, n)); r = (s+t > kapU) & (s+t < kap)
    h1 = np.stack([-np.ones(n), s, t], 1)[r]; h2 = np.stack([s, -np.ones(n), t], 1)[r]
    v_b1 = np.sum(rc.PK(P, h1) > 0); v_b2 = np.sum(rc.PK(P, h2) > 0)
    return v_a1, v_a2, v_b1, v_b2

for eps, s in [(0.1, 0.9), (0.3, 0.9), (0.6, 0.5), (0.9, 0.3)]:
    c0, kap, V, Vp = rc.setup(eps, s)
    ep = s*eps; kapU = (1+2*ep)/(1-ep)
    m0 = np.array([kap,1,0])/(kap+1); m0p = np.array([1,kap,0])/(kap+1)
    rc.rng = np.random.default_rng(161026)  # reproduce R2's trial stream
    c0_, kap_, V_, Vp_ = rc.setup(eps, s)
    g = rc.sample_U(Vp, 150000)
    nbad = 0; ntot = 0
    for _ in range(300):
        k = rc.rng.integers(1, 4); pts = []
        for _ in range(k):
            mode = rc.rng.integers(3)
            if mode == 0:
                r_ = np.exp(rc.rng.uniform(-1.3, 1.3)*np.log(kap)); p = np.array([r_,1,0])/(1+r_)
            elif mode == 1:
                mu = rc.rng.uniform(-0.2, 1.2)
                p = np.array([kap,1,max(mu,0)]) if rc.rng.random() < .5 else np.array([1,kap,max(mu,0)]); p = p/p.sum()
            else:
                p = rc.rng.dirichlet([3,3,3])
            pts.append(p)
        P = np.vstack([Vp]+pts)
        crit = all(rc.in_Pi12(p,kap) for p in P) and rc.meets_segment(P,m0,V[0]) and rc.meets_segment(P,m0p,V[1])
        v = chart_test(P, kap, kapU)
        targ = sum(v) == 0
        ntot += 1
        if crit != targ:
            nbad += 1
            print(f"eps={eps}: crit={crit}, targeted violations (a1,a2,b1,b2)={v}")
    print(f"eps={eps}: {ntot} trials, criterion vs targeted-chart test disagreements: {nbad}")
