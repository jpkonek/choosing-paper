import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import ref_checks as rc
eps, s = 0.1, 0.9
c0, kap, V, Vp = rc.setup(eps, s)
m0 = np.array([kap,1,0])/(kap+1); m0p = np.array([1,kap,0])/(kap+1)
rc.rng = np.random.default_rng(161026)
g = rc.sample_U(Vp, 150000)
for trial in range(300):
    k = rc.rng.integers(1, 4); pts = []
    for _ in range(k):
        mode = rc.rng.integers(3)
        if mode == 0:
            r_ = np.exp(rc.rng.uniform(-1.3, 1.3)*np.log(kap)); p = np.array([r_,1,0])/(1+r_)
        elif mode == 1:
            mu = rc.rng.uniform(-0.2, 1.2)
            p = np.array([kap,1,max(mu,0)]) if rc.rng.random() < .5 else np.array([1,kap,max(mu,0)]); p = p/p.sum()
        else:
            p = rc.rng.dirichlet([3,3,3])
        pts.append(p)
    P = np.vstack([Vp]+pts)
    inPi = [rc.in_Pi12(p,kap) for p in P]
    crit = all(inPi) and rc.meets_segment(P,m0,V[0]) and rc.meets_segment(P,m0p,V[1])
    if not crit:
        D = rc.PK(P, g) > 0
        t1 = rc.PK(V, g) > 0
        W = ((rc.orth(g,(1,-1,-1))&t1)|(rc.orth(g,(-1,1,1))&~t1)|(rc.orth(g,(-1,1,-1))&t1)|(rc.orth(g,(1,-1,1))&~t1))
        if np.all(D[W]==t1[W]):
            print("trial", trial, "pts", pts, "inPi", inPi, "seg1", rc.meets_segment(P,m0,V[0]), "seg2", rc.meets_segment(P,m0p,V[1]))
            for p in pts:
                m1,m2,m3 = p
                print("  slacks", kap*m1-m2, kap*m1-m3, (kap+1)*m1-m2-m3, kap*m2-m1, kap*m2-m3, (kap+1)*m2-m1-m3)
