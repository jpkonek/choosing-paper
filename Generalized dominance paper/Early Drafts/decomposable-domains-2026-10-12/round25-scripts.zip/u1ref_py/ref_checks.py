"""Referee checks for U1_notes.md (independent of u1py/). No verdict rests on this file.

(R1) exact algebra (sympy): h, R+, R-, corner identity, R+ >= R-, Pi12 ∩ R(1) = [m0, v1].
(R2) Lemma U1.2(c) characterisation against sampling, for random K = co(K' ∪ extra points).
(R3) segment models S[a,b] are {i,j}-edge models (= P_i on Q_l) and have the error sets of 6.1.
(R4) Prop. U1.5(c) exactly (Fractions) on rational grids of the two chart types, including the corner (c,c).
(R5) U1.1(i) for the template on all three edges (cyclic), at p = u.
(R6) the x-ranges of (3.1): sup x on O1- \\ T1 -> kappa, inf x on O2- \\ T1 -> 1/kappa.
"""
import numpy as np
import sympy as sp
from fractions import Fraction as Fr
from scipy.optimize import linprog

rng = np.random.default_rng(161026)


def setup(eps, s):
    c0 = (1 - eps) / 3
    kap = (1 + 2 * eps) / (1 - eps)
    V = np.array([c0 * np.ones(3) + eps * np.eye(3)[k] for k in range(3)])
    ep = s * eps
    Vp = np.array([(1 - ep) / 3 * np.ones(3) + ep * np.eye(3)[k] for k in range(3)])
    return c0, kap, V, Vp


def PK(P, g):
    return np.min(g @ P.T, axis=-1)


def sample_U(Vp, n):
    out, tot = [], 0
    while tot < n:
        g = rng.standard_normal((4 * n, 3))
        g = g[(g.max(1) > 0) & (g.min(1) < 0) & (PK(Vp, g) > 0)]
        out.append(g); tot += len(g)
    return np.concatenate(out)[:n]


def orth(g, pat):
    return np.all(np.sign(g) == np.array(pat), axis=1)


# ---------------- (R1) ----------------
def R1():
    k, t, x = sp.symbols('kappa t x', positive=True)
    c = 1 / (k + 1)
    h1 = (k + 1) * t / 2
    h2 = 1 - (k + 1) * (1 - k * t) / 2
    out = {}
    out['h(c) both pieces'] = sp.simplify(h1.subs(t, c) - h2.subs(t, c)) == 0
    out['h(1/k)=1'] = sp.simplify(h2.subs(t, 1 / k) - 1) == 0
    # corner identity h(t) + h(1 - k t) = 1 on [c, 1/k] (second arg in [0,c] -> first piece)
    out['h(t)+h(1-kt)=1'] = sp.simplify(h2 + h1.subs(t, 1 - k * t) - 1) == 0
    # h >= t/k at breakpoints, for k>1: (k+1)/2*c - c/k >= 0 ; 1 - 1/k^2 >= 0
    kk = sp.symbols('kk', positive=True)
    e1 = sp.simplify((h1.subs(t, c) - c / k).subs(k, 1 + kk))
    out['h(c)>=c/k (k>1)'] = bool(sp.simplify(sp.numer(sp.together(e1))).is_positive) or str(sp.factor(e1))
    # Pi12 ∩ R(1): m = (k,1,mu): check all six Pi12 inequalities + R1 for mu in [0,1] symbolically
    mu = sp.symbols('mu', nonnegative=True)
    m1, m2, m3 = k, 1, mu
    ineq = [k * m1 - m2, k * m1 - m3, (k + 1) * m1 - m2 - m3, k * m2 - m1, k * m2 - m3, (k + 1) * m2 - m1 - m3,
            m1 - k * m2, m1 - k * m3]
    out['Pi12∩R1 ineqs at (k,1,mu)'] = [sp.factor(e) for e in ineq]
    # m0 in Pi12
    m = (k, 1, 0)
    ineq0 = [k * m[0] - m[1], k * m[0] - m[2], (k + 1) * m[0] - m[1] - m[2], k * m[1] - m[0], k * m[1] - m[2],
             (k + 1) * m[1] - m[0] - m[2]]
    out['m0 Pi12 slacks'] = [sp.factor(e) for e in ineq0]
    return out


# ---------------- (R2) ----------------
def in_Pi12(m, kap):
    m1, m2, m3 = m
    return (kap * m1 >= m2 - 1e-12 and kap * m1 >= m3 - 1e-12 and (kap + 1) * m1 >= m2 + m3 - 1e-12 and
            kap * m2 >= m1 - 1e-12 and kap * m2 >= m3 - 1e-12 and (kap + 1) * m2 >= m1 + m3 - 1e-12)


def meets_segment(P, A, B):
    """LP: exists convex weights w on rows of P and mu in [0,1] with w@P = (1-mu)A + mu B."""
    n = len(P)
    # variables w (n), mu ; equality: P^T w - mu (B - A) = A ; sum w = 1
    Aeq = np.zeros((4, n + 1))
    Aeq[:3, :n] = P.T
    Aeq[:3, n] = -(B - A)
    Aeq[3, :n] = 1
    beq = np.concatenate([A, [1]])
    res = linprog(np.zeros(n + 1), A_eq=Aeq, b_eq=beq, bounds=[(0, None)] * n + [(0, 1)], method='highs')
    return res.status == 0


def R2(eps, s, ntrial=300, n=150000):
    c0, kap, V, Vp = setup(eps, s)
    g = sample_U(Vp, n)
    t1 = PK(V, g) > 0
    W = ((orth(g, (1, -1, -1)) & t1) | (orth(g, (-1, 1, 1)) & ~t1) |
         (orth(g, (-1, 1, -1)) & t1) | (orth(g, (1, -1, 1)) & ~t1))
    gW, tW = g[W], t1[W]
    m0 = np.array([kap, 1, 0]) / (kap + 1)
    m0p = np.array([1, kap, 0]) / (kap + 1)
    stats = dict(crit_yes=0, crit_yes_samp_no=0, crit_no=0, crit_no_samp_yes=0)
    for _ in range(ntrial):
        k = rng.integers(1, 4)
        pts = []
        for _ in range(k):
            mode = rng.integers(3)
            if mode == 0:   # on the edge [e1,e2], ratio near [1/kap, kap]
                r = np.exp(rng.uniform(-1.3, 1.3) * np.log(kap))
                p = np.array([r, 1, 0]) / (1 + r)
            elif mode == 1:  # on the lines e3 v1 / e3 v2 (the cevian segments, extended slightly)
                mu = rng.uniform(-0.2, 1.2)
                p = np.array([kap, 1, max(mu, 0)]) if rng.random() < .5 else np.array([1, kap, max(mu, 0)])
                p = p / p.sum()
            else:            # random point of the simplex near T1
                p = rng.dirichlet([3, 3, 3])
            pts.append(p)
        P = np.vstack([Vp] + pts)
        crit = all(in_Pi12(p, kap) for p in P) and meets_segment(P, m0, V[0]) and meets_segment(P, m0p, V[1])
        D = PK(P, gW) > 0
        samp = bool(np.all(D == tW))
        if crit:
            stats['crit_yes'] += 1
            stats['crit_yes_samp_no'] += int(not samp)
        else:
            stats['crit_no'] += 1
            stats['crit_no_samp_yes'] += int(samp)
    return stats


# ---------------- (R3) ----------------
def R3(eps, s, n=100000, ntrial=40):
    c0, kap, V, Vp = setup(eps, s)
    g = sample_U(Vp, n)
    bad_edge = bad_err = 0
    for _ in range(ntrial):
        i, j = rng.permutation(3)[:2]
        l = 3 - i - j
        al, be = np.sort(np.exp(rng.uniform(-3, 3, 2)))[::-1]   # alpha >= beta
        a = np.zeros(3); a[i] = al; a[j] = 1; a /= a.sum()
        b = np.zeros(3); b[i] = be; b[j] = 1; b /= b.sum()
        P = np.vstack([Vp, a, b])
        D = PK(P, g) > 0
        Ql = (np.sign(g[:, i]) == np.sign(g[:, j]))
        bad_edge += int(np.any(D[Ql] != (g[Ql, i] > 0)))
        R = ~Ql
        x = np.abs(g[R, j]) / np.abs(g[R, i])
        err = np.where(g[R, i] > 0, ~D[R], D[R])
        pred = np.where(g[R, i] > 0, x >= be, x > al)
        near = (np.abs(x - al) < 1e-9 * al) | (np.abs(x - be) < 1e-9 * be)
        bad_err += int(np.any((err != pred) & ~near))
    return bad_edge, bad_err, ntrial


# ---------------- (R4) exact ----------------
def R4(eps=Fr(3, 10), N=120):
    kap = (1 + 2 * eps) / (1 - eps)
    c = 1 / (kap + 1)

    def h(t):
        return (kap + 1) * t / 2 if t <= c else 1 - (kap + 1) * (1 - kap * t) / 2

    def Rp(x):
        return h(x) if x <= 1 / kap else kap * x

    def Rm(x):
        return 1 / Rp(1 / x)

    bad_plus = bad_minus = ties_off = 0
    tot = 0
    # one-positive chart (1,-a,-b): bracket 1 - Rp(a) - Rp(b); T1 = quad
    grid = [Fr(k, N) * Fr(3, 2) / kap for k in range(1, N + 1)] + [c, 1 / kap, c + Fr(1, 10 ** 6), c - Fr(1, 10 ** 6)]
    for a in grid:
        for b in grid:
            br = 1 - Rp(a) - Rp(b)
            q1, q2 = kap * a + b, a + kap * b
            inq = (q1 < 1) and (q2 < 1)
            onb = (q1 == 1 and q2 <= 1) or (q2 == 1 and q1 <= 1)
            tot += 1
            if onb:
                ties_off += int(br != 0)
            else:
                bad_plus += int((br > 0) != inq)
    # two-positive chart (-1,a,b): bracket -1 + Rm(a) + Rm(b); T1 = {a+b > kap}
    grid2 = [Fr(k, N) * 3 * kap for k in range(1, N + 1)] + [kap, kap / 2]
    for a in grid2:
        for b in grid2:
            br = -1 + Rm(a) + Rm(b)
            tot += 1
            if a + b == kap:
                ties_off += int(br != 0)
            else:
                bad_minus += int((br > 0) != (a + b > kap))
    return bad_plus, bad_minus, ties_off, tot


# ---------------- (R5) ----------------
def R5(eps, s, n=300000):
    c0, kap, V, Vp = setup(eps, s)
    c = 1 / (kap + 1)

    def h(t):
        return np.where(t <= c, t * (kap + 1) / 2, 1 - (1 - kap * t) * (kap + 1) / 2)

    def Rp(x):
        return np.where(x <= 1 / kap, h(np.minimum(x, 1 / kap)), kap * x)

    def Rm(x):
        return 1 / Rp(1 / x)

    g = sample_U(Vp, n)
    t1 = PK(V, g) > 0
    out = []
    for (i, j) in [(0, 1), (1, 2), (0, 2)]:
        R = np.sign(g[:, i]) != np.sign(g[:, j])
        x = np.abs(g[:, j]) / np.abs(g[:, i])
        r = np.where(g[:, i] > 0, Rp(x), Rm(x))
        # W_i: Q_i minus E_i(T1); Q_i: g_i sign differs from both others
        sg = np.sign(g)
        Qi = (sg[:, i] != sg[:, j]) & (sg[:, j] == sg[:, 3 - i - j])
        Qj = (sg[:, j] != sg[:, i]) & (sg[:, i] == sg[:, 3 - i - j])
        Wi = Qi & ((g[:, i] > 0) == t1)
        Wj = Qj & ((g[:, j] > 0) == t1)
        out.append((i + 1, j + 1, bool(np.all(r[Wi] < 1)), bool(np.all(r[Wj] > 1)), int(Wi.sum()), int(Wj.sum())))
    return out


# ---------------- (R6) ----------------
def R6(eps, s, n=400000):
    c0, kap, V, Vp = setup(eps, s)
    g = sample_U(Vp, n)
    t1 = PK(V, g) > 0
    A = orth(g, (-1, 1, 1)) & ~t1
    B = orth(g, (1, -1, 1)) & ~t1
    xA = np.abs(g[A, 1]) / np.abs(g[A, 0])
    xB = np.abs(g[B, 1]) / np.abs(g[B, 0])
    return kap, xA.min(), xA.max(), 1 / kap, xB.min(), xB.max()


if __name__ == "__main__":
    print("(R1)", R1())
    for eps, s in [(0.1, 0.9), (0.3, 0.9), (0.6, 0.5), (0.9, 0.3)]:
        print(f"=== eps={eps}, s={s}")
        print("(R2) U1.2(c) criterion vs sampling:", R2(eps, s))
        print("(R3) segment models: edge-model violations, error-set violations, trials:", R3(eps, s))
        print("(R5) U1.1(i) on all edges (i,j, r<1 on W_i, r>1 on W_j, #W_i, #W_j):", R5(eps, s))
        print("(R6) kappa, x-range on O1-\\T1 ; 1/kappa, x-range on O2-\\T1:", R6(eps, s))
    for e in (Fr(1, 10), Fr(3, 10), Fr(3, 5), Fr(9, 10)):
        print(f"(R4) exact template eps={e}: (bad one-pos, bad two-pos, nonzero bracket on boundary, total):", R4(e))
