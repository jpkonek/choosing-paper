"""V1 NUMERICS (W): interior weights t at which the U1.5 Bayes set B_t is coherent.
Cross-section g = 1 + w, w in 1^perp (all of U lies in u.g > 0); B_t is coherent iff its section is convex.
Test: grid points in the convex hull of the section of B_t that are outside B_t by a margin."""
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v1_common import setup, PK, chat
from scipy.spatial import ConvexHull, Delaunay


def grid(Vp, n):
    e1 = np.array([1, -1, 0]) / np.sqrt(2)
    e2 = np.array([1, 1, -2]) / np.sqrt(6)
    R = 40.0
    xs = np.linspace(-R, R, n)
    X, Y = np.meshgrid(xs, xs)
    W = X.reshape(-1, 1) * e1 + Y.reshape(-1, 1) * e2
    G = 1 + W
    inU = PK(Vp, G) > 0
    return G[inU], np.stack([X.reshape(-1), Y.reshape(-1)], 1)[inU]


def nonconvexity(t, G, P2, C, marg=1e-3):
    val = C @ t / np.linalg.norm(G, axis=1)
    inside = val > 0
    hull = ConvexHull(P2[inside])
    tri = Delaunay(P2[inside][hull.vertices])
    inhull = tri.find_simplex(P2) >= 0
    bad = inhull & (val < -marg)
    return bad.sum() / max(1, inside.sum())


if __name__ == "__main__":
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 20
    for eps, sfac in [(0.3, 0.9), (0.6, 0.5), (0.1, 0.9)]:
        c0, kap, V, Vp = setup(eps, sfac)
        G, P2 = grid(Vp, 700)
        C = chat(G, kap)
        good = []
        tot = 0
        for i in range(1, N):
            for j in range(1, N - i):
                t = np.array([i, j, N - i - j], float) / N
                tot += 1
                f = nonconvexity(t, G, P2, C)
                if f == 0:
                    good.append(t)
        print(f"eps={eps} s={sfac} kappa={kap:.4f}: {tot} interior grid weights (N={N}); convex sections: {len(good)}")
        for t in good:
            print("   ", np.round(t, 4))
        # the centre
        print("    centre u nonconvexity fraction:", nonconvexity(np.ones(3) / 3, G, P2, C))
