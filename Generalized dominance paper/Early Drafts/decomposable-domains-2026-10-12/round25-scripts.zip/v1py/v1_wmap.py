"""V1 NUMERICS (W-map): ASCII map of the incoherence fraction of B_t over the simplex for the U1.5 field.
'.' = section convex at the test resolution (coherent-looking), digits = -log10 of the non-convex fraction."""
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v1_common import setup, chat
from v1_wcoh2 import grid, nonconvexity

eps, sfac = float(sys.argv[1]), float(sys.argv[2])
N = int(sys.argv[3])
c0, kap, V, Vp = setup(eps, sfac)
G, P2 = grid(Vp, 700)
C = chat(G, kap)
print(f"eps={eps} s={sfac} kappa={kap:.3f}; rows: t3 = k/N from top (k=N-1) to bottom (k=1); columns t1")
for k in range(N - 1, 0, -1):
    row = " " * (k)
    for i in range(1, N - k):
        j = N - k - i
        t = np.array([i, j, k], float) / N
        f = nonconvexity(t, G, P2, C)
        row += ("." if f == 0 else str(min(9, int(-np.log10(f))))) + " "
    print(row)
for lam in [1e-3, 3e-3, 1e-2, 2e-2]:
    for tgt in (np.array([1., 0, 0]), np.array([.5, .5, 0])):
        t = (1 - lam) * np.ones(3) / 3 + lam * tgt
        print("near u, lam", lam, "toward", tgt, ":", nonconvexity(t, G, P2, C))
