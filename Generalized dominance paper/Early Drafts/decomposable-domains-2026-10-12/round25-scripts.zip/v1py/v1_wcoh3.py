"""V1 NUMERICS (W'): non-convexity fraction of the section of B_t along rays from u to the vertices and edges."""
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v1_common import setup, chat
from v1_wcoh2 import grid, nonconvexity

for eps, sfac in [(0.3, 0.9), (0.6, 0.5)]:
    c0, kap, V, Vp = setup(eps, sfac)
    G, P2 = grid(Vp, 900)
    C = chat(G, kap)
    u = np.ones(3) / 3
    print(f"eps={eps} s={sfac} kappa={kap:.3f}")
    for name, tgt in [("u->e1", np.array([1., 0, 0])), ("u->mid12", np.array([.5, .5, 0]))]:
        row = []
        for lam in [0.02, 0.05, 0.1, 0.2, 0.3, 0.5, 0.7, 0.8, 0.9, 0.95, 0.98]:
            t = (1 - lam) * u + lam * tgt
            row.append(f"{lam}:{nonconvexity(t, G, P2, C):.2e}")
        print("  ", name, " ".join(row))
