"""V1 common code: U1.5 segment-host template field (copied logic from u1py/u1_checks.py, re-implemented)."""
import numpy as np


def setup(eps, s):
    c0 = (1 - eps) / 3
    kap = (1 + 2 * eps) / (1 - eps)
    V = np.array([c0 * np.ones(3) + eps * np.eye(3)[k] for k in range(3)])
    epsp = s * eps
    c0p = (1 - epsp) / 3
    Vp = np.array([c0p * np.ones(3) + epsp * np.eye(3)[k] for k in range(3)])
    return c0, kap, V, Vp


def PK(K, g):
    return np.min(g @ K.T, axis=-1)


def sample_U(Vp, n, rng):
    out = []
    while sum(len(o) for o in out) < n:
        g = rng.standard_normal((4 * n, 3))
        mixed = (g.max(1) > 0) & (g.min(1) < 0)
        g = g[mixed & (PK(Vp, g) > 0)]
        out.append(g)
    g = np.concatenate(out)[:n]
    return g / np.linalg.norm(g, axis=1, keepdims=True)


def make_R(kap):
    c = 1 / (kap + 1)

    def h(t):
        t = np.asarray(t, float)
        return np.where(t <= c, t * (kap + 1) / 2, 1 - (1 - kap * t) * (kap + 1) / 2)

    def Rp(x):
        x = np.asarray(x, float)
        return np.where(x <= 1 / kap, h(np.minimum(x, 1 / kap)), kap * x)

    def Rm(x):
        x = np.asarray(x, float)
        return 1.0 / Rp(1.0 / np.maximum(x, 1e-300))
    return Rp, Rm


def chat(g, kap):
    """0-homogeneous field c-hat, normalised to |c_odd| = 1 at the odd world."""
    Rp, Rm = make_R(kap)
    sg = np.sign(g)
    n = len(g)
    rho = np.ones((n, 3))
    for l in range(3):
        k, kk = [j for j in range(3) if j != l]
        Q = (sg[:, k] == sg[:, kk]) & (sg[:, l] != sg[:, k])
        for j in (k, kk):
            x = np.abs(g[Q, j]) / np.abs(g[Q, l])
            lpos = g[Q, l] > 0
            # g_l>0>g_j: rho_j/rho_l = R+(|g_j|/|g_l|);  g_j>0>g_l: rho_j/rho_l = 1/R+(|g_l|/|g_j|) = R-(x)
            rho[np.where(Q)[0], j] = np.where(lpos, Rp(x), Rm(x))
    return rho * sg
