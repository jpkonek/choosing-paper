"""V1 NUMERICS: incoherence fraction of B_t on the median t1 = t2 (both directions from u) and just off it."""
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v1_common import setup, chat
from v1_wcoh2 import grid, nonconvexity
for eps, sfac in [(0.3, 0.9), (0.6, 0.5)]:
    c0, kap, V, Vp = setup(eps, sfac)
    G, P2 = grid(Vp, 900)
    C = chat(G, kap)
    print(f"eps={eps} s={sfac}")
    for t3 in [0.02, 0.05, 0.1, 0.2, 0.3, 1/3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95]:
        t = np.array([(1 - t3) / 2, (1 - t3) / 2, t3])
        off = t + np.array([0.01, -0.01, 0])
        print(f"   t3={t3:.3f}: on median {nonconvexity(t, G, P2, C):.2e}   off by 0.01 {nonconvexity(off, G, P2, C):.2e}")
