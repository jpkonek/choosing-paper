"""V1 checks (NUMERICS only; no proof in V1_notes.md rests on this file).
Run from inside v1py/:  python3 -I -B v1_checks.py > v1_checks.out

(A) (UB) and (H_Q) for the U1.5 field: on Q_k near the e_k ray, rho_k/(rho_i+rho_j) is unbounded, and for random
    t with t_k > 0 the Bayes set B_t is k-correct on a sampled non-null part of Q_k.
(B) Deep behaviour on the sheltering cone H_eta (T2n.7) inside Q_2: B_t is 3-correct deep iff t_3 > 0.
(C) Where B_t is coherent (convex section): see v1_wmap.py / v1_median.py (printed here for (eps,s) = (0.3,0.9)).
"""
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v1_common import setup, sample_U, chat, PK

rng = np.random.default_rng(1610)

print("(A) (UB), (H_Q)")
for eps, sfac in [(0.1, 0.9), (0.3, 0.9), (0.6, 0.5), (0.9, 0.3)]:
    c0, kap, V, Vp = setup(eps, sfac)
    out = []
    for k in range(3):
        i, j = [x for x in range(3) if x != k]
        mx = 0.0
        for a in [1e-1, 1e-2, 1e-3, 1e-4]:
            g = np.zeros((1, 3)); g[0, k] = 1; g[0, i] = -a; g[0, j] = -a
            assert PK(Vp, g)[0] > 0
            C = np.abs(chat(g, kap))[0]
            mx = max(mx, C[k] / (C[i] + C[j]))
        # H_Q: random t with t_k>0; sample g = (1 at k, -a, -b) with a, b < d near the e_k ray (proof: R+(0+) = 0)
        frac = []
        for _ in range(200):
            t = rng.dirichlet(np.ones(3))
            d = 0.5 * t[k] / (kap + 1)           # R+(x) <= (kap+1)x/2 on (0, c], so t_i R+(a) + t_j R+(b) < t_k
            G = np.zeros((2000, 3)); G[:, k] = 1
            G[:, i] = -d * rng.uniform(0, 1, 2000); G[:, j] = -d * rng.uniform(0, 1, 2000)
            ok = PK(Vp, G) > 0
            right = (chat(G[ok], kap) @ t) > 0     # accept = k-correct on (+ at k, - elsewhere)
            frac.append(right.mean() if ok.any() else np.nan)
        out.append(f"k={k+1}: max ratio {mx:.1e}, min frac(B_t k-correct near e_k ray) over 200 t = {min(frac):.3f}")
    print(f"  eps={eps}, s={sfac}: " + "; ".join(out))

print("(B) deep behaviour of B_t on H_eta = {r(a,-b,1): b<eta, a<eta*b} (inside Q_2, T1 accepts)")
for eps, sfac in [(0.3, 0.9), (0.6, 0.5)]:
    c0, kap, V, Vp = setup(eps, sfac)
    for eta in [1e-2, 1e-4, 1e-6]:
        b = eta * rng.uniform(0.01, 1, 20000)
        a = eta * b * rng.uniform(0.01, 1, 20000)
        g = np.stack([a, -b, np.ones_like(a)], 1)
        inU = PK(Vp, g) > 0
        C = chat(g[inU], kap)
        res = []
        for t in [np.array([.3, .3, .4]), np.array([.45, .45, .1]), np.array([.49, .5, .01]),
                  np.array([.4, .6, 0.]), np.array([1., 0, 0])]:
            acc = (C @ t > 0).mean()   # accept = correct at worlds 1 and 3 on (+,-,+)
            res.append(f"t={np.round(t,2)}:{acc:.3f}")
        print(f"  eps={eps} eta={eta:.0e} (|H in U|={inU.sum()}): fraction of H_eta where B_t is 3-correct: " + " ".join(res))
