"""PP60 referee: the tie in PP53 Lemma 3.5 (spectator constraints, common-shape fields).  CHECKED (exact).

Finite two-type model at one world w.  Three gated models a, b, c give three different advice values A, B, C at
both point types.  At type g1 the w-ranks are A < B < C; at type g2 they are reversed.  Common-shape fields:
kappa_N * l^N_w = U at every point for N = a, b, c (here kappa = 1).  Triangle X = C_a, Y = C_b, Z = C_c on
g1 u g2 (pattern Q_o of PP49 Lemma 3.4).  With masses matching the ratios, all three gate values are 0, so the
triangle is accepted under (R0) and (H3) fails, as PP53 says.  But every REVERSE link is realised (Y = C_b,
Z = C_c, X = C_a on the supports) and also has value 0, so it is accepted too: the configuration is a set of
single-world ties, and (TC) is NOT violated.  PP53's appeal to PP49 Lemma 3.2 for refused reverses is invalid
here, because common-shape fields make (H2) an equality at these points.
"""
from fractions import Fraction as Fr

# U at each type, indexed by advice value
U = {'g1': {'A': Fr(0), 'B': Fr(1), 'C': Fr(3)},     # alpha = 1, beta = 2
     'g2': {'C': Fr(0), 'B': Fr(2), 'A': Fr(3)}}     # alpha' = 2, beta' = 1  (beta/alpha = alpha'/beta')
mass = {'g1': Fr(1), 'g2': Fr(1)}                   # m1*alpha = m2*beta', m1*beta = m2*alpha'
X = {'g1': 'A', 'g2': 'A'}
Y = {'g1': 'B', 'g2': 'B'}
Z = {'g1': 'C', 'g2': 'C'}


def val(old, new):           # gate value of old -> new under the common field (realiser = old side's model)
    return sum(mass[t] * (U[t][new[t]] - U[t][old[t]]) for t in U)


fwd = {'X->Y (gate a)': val(X, Y), 'Y->Z (gate b)': val(Y, Z), 'Z->X (gate c)': val(Z, X)}
rev = {'Y->X (gate b)': val(Y, X), 'Z->Y (gate c)': val(Z, Y), 'X->Z (gate a)': val(X, Z)}
print('forward link values:', {k: str(v) for k, v in fwd.items()})
print('reverse link values:', {k: str(v) for k, v in rev.items()})
ok = all(v == 0 for v in fwd.values()) and all(v == 0 for v in rev.values())
print('forward triangle accepted under (R0) (so (H3) fails):', all(v >= 0 for v in fwd.values()))
print('all reverses accepted under (R0) (so this triangle satisfies (TC); it consists of single-world ties):',
      all(v >= 0 for v in rev.values()))
print('ALL PASS' if ok else 'FAILURES')
