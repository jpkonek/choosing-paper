"""PP60 referee: Prop 7.3 of PP52 ("designation on shared records cannot remove a strict co-activity").

Question: with N = T = C_u and M = C_B (B the kink index (406,421,373)/1200), is there a posterior index b != B
such that C_b = C_B a.e. on {C_T != C_B}?  If so, EVERY record (D u E : C_B -> C_T) with D u E inside
{C_T != C_B} is also realised by C_b, so no choice of the padding set E makes C_B the sole realiser, and the
written proof of Prop 7.3 cannot be completed by a better E.
Method: a float Monte Carlo filter over a grid of indices b (NUMERICS), then an EXACT confirmation by full cell
enumeration of the arrangement {T, B, b} (CHECKED): no open cell has C_T != C_B and C_b != C_B.
The same is done for M = C_D, and for the reversed roles (N = C_B, M = T).
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import numpy as np
from ref_lib import planes, cell_points, advice, norm

eps = Fr(3, 10)
c = (1 - eps) / 3
u = (Fr(1, 3),) * 3
B = norm((406, 421, 373))
D = norm((406, 373, 421))

rng = np.random.default_rng(60)
G = rng.standard_normal((200000, 3))


def adv_np(a):
    a = np.array([float(x) for x in a])
    V = np.array([[float(c) + (float(eps) if i == j else 0) for i in range(3)] for j in range(3)]) * a
    s = G @ V.T
    return np.where((s > 0).all(1), 1, np.where((s < 0).all(1), -1, 0))


def exact_fail(N, M, b):
    """True iff some open cell has C_N != C_M and C_b != C_M (b then does NOT realise everything)."""
    for g in cell_points(planes(eps, [N, M, b])):
        aN, aM, ab = advice(eps, N, g), advice(eps, M, g), advice(eps, b, g)
        if aN != aM and ab != aM:
            return True
    return False


def search(N, M, label, n=40):
    aN, aM = adv_np(N), adv_np(M)
    mask = aN != aM
    hits = []
    for i in range(1, n):
        for j in range(1, n - i):
            b = (Fr(i, n), Fr(j, n), Fr(n - i - j, n))
            if b == M:
                continue
            ab = adv_np(b)
            if not np.any(mask & (ab != aM)):
                hits.append(b)
    # fine grid around M
    for di in range(-12, 13):
        for dj in range(-12, 13):
            b = (M[0] + Fr(di, 2400), M[1] + Fr(dj, 2400), M[2] - Fr(di + dj, 2400))
            if b == M or min(b) <= 0:
                continue
            ab = adv_np(b)
            if not np.any(mask & (ab != aM)):
                hits.append(b)
    conf = [b for b in hits if not exact_fail(N, M, b)]
    print('%s: MC-filter candidates %d; EXACTLY confirmed realisers b != M of all records in {N != M}: %d' % (label, len(hits), len(conf)))
    for b in conf[:6]:
        print('     b =', tuple(str(x) for x in b))
    return conf


r1 = search(u, B, 'N = T, M = C_B')
r2 = search(u, D, 'N = T, M = C_D')
r3 = search(B, u, 'N = C_B, M = T')
print('Interpretation: a nonempty exact list means Prop 7.3\'s conclusion ("M is the sole realiser") is unattainable '
      'for that pair by any padding E inside {N != M}.')
