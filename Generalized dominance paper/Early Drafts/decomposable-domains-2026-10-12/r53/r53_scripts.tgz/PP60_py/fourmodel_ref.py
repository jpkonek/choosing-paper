"""PP60 referee: independent partial check of PP53 Thm 3.3 (four-model certificate).

CHECKED (exact):
 (1) own cell enumeration (ref_lib) of A = u, B = (11,10,9)/30, C = (11,11,8)/30, D = (10,11,9)/30 at eps = 3/10:
     the realised disagreement types coincide with the 28 types listed in PP53's JSON; no three-valued cell;
 (2) from PP53's magnitudes (exact binary values of exp(phi), as PP53 reads them) the world-1 CG2 intervals are
     recomputed with independent code, and global infeasibility is decided by an exact Bellman-Ford on
     multiplicative constraints (products of Fractions), for both JSON files;
 (3) the triple test with strict slack at every world (both orientations), recomputed.
Own-Bayes is NOT re-verified here (PP53, PP50 and PP51 each verified it with separate code).
Run inside PP60_py:  python3 -I -B fourmodel_ref.py > fourmodel_ref.out
"""
import sys, os, json, math, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from ref_lib import types

OK = True


def check(c, m):
    global OK
    if not c:
        OK = False
        print('FAIL', m)


eps = Fr(3, 10)
here = os.path.dirname(os.path.abspath(__file__))
names = ['A', 'B', 'C', 'D']
idx = [(Fr(1, 3),) * 3, (Fr(11, 30), Fr(10, 30), Fr(9, 30)), (Fr(11, 30), Fr(11, 30), Fr(8, 30)), (Fr(10, 30), Fr(11, 30), Fr(9, 30))]
T = types(eps, idx, names)
three = [k for k in T if k[0] == '3V']
mine = {(tuple(sorted(H)), tuple(w for w in range(3) if w not in Wr)) for (H, Wr) in T if H != '3V'}
print('(1) own enumeration: %d disagreement types, three-valued cells: %d' % (len(mine), len(three)))
check(not three, 'three-valued cell found')

for fn in ('four_model_solution.json', 'four_model_solution_fixlam.json'):
    S = json.load(open(os.path.join(here, '..', 'PP53_py', fn)))
    theirs = {(tuple(P), tuple(R)) for P, R in S['types']}
    check(mine == theirs, 'type sets differ for %s' % fn)
    print('%s: PP53 lists %d types; identical to own enumeration: %s' % (fn, len(theirs), mine == theirs))
    mag = {}
    for key, val in S['phi'].items():
        N, P, R, w = json.loads(key)
        mag[(N, (tuple(P), tuple(R)), w)] = Fr(math.exp(val))
    for w in range(3):
        # constraint on r_XY := c_X / c_Y : lo_XY <= r_XY <= hi_XY ; derived from scratch
        lo = {(X, Y): Fr(0) for X in names for Y in names if X != Y}
        hi = {(X, Y): None for X in names for Y in names if X != Y}
        for t in theirs:
            P, R = t
            for X, Y in lo:
                if (X in P) == (Y in P):
                    continue
                # move X -> Y at world w: Y worse iff (Y answers and h wrong at w) or (Y silent and h right at w)
                Yworse = (w not in R) if Y in P else (w in R)
                rho = mag[(Y, t, w)] / mag[(X, t, w)]
                if Yworse:      # c_X m_X <= c_Y m_Y
                    hi[(X, Y)] = rho if hi[(X, Y)] is None else min(hi[(X, Y)], rho)
                else:           # c_X (-m_X) <= c_Y (-m_Y)
                    lo[(X, Y)] = max(lo[(X, Y)], rho)
        # consistency of the two orientations
        for X, Y in lo:
            hY = hi[(Y, X)]
            check(lo[(X, Y)] == (1 / hY if hY is not None else 0), 'orientation mismatch')
            check(hi[(X, Y)] is None or lo[(X, Y)] < hi[(X, Y)], 'degenerate interval %s%s w%d' % (X, Y, w + 1))
        # triple slack, both orientations
        for a, b, c in itertools.permutations(names, 3):
            pl = lo[(a, b)] * lo[(b, c)] * lo[(c, a)]
            check(pl < 1, 'triple lower %s%s%s w%d' % (a, b, c, w + 1))
        # exact Bellman-Ford on edges x_X - x_Y <= log hi_XY  (multiplicative form; None = no edge)
        dist = {N: Fr(1) for N in names}
        for _ in range(len(names) + 1):
            changed = False
            for (X, Y), h in hi.items():
                if h is None:
                    continue
                # edge Y -> X with weight h : x_X <= x_Y * h
                if dist[Y] * h < dist[X]:
                    dist[X] = dist[Y] * h
                    changed = True
        feasible = not changed
        if w == 0:
            lg = lambda q: '%.4f' % math.log(q) if q else '-inf'
            print('   world 1 intervals log(c_X/c_Y):', {X + Y: (lg(lo[(X, Y)]), lg(hi[(X, Y)]) if hi[(X, Y)] else '+inf')
                                                       for X, Y in itertools.combinations(names, 2)})
        print('   world %d: global constants exist: %s' % (w + 1, feasible))
        if w == 0:
            check(not feasible, 'world 1 should be infeasible')

print('ALL PASS' if OK else 'FAILURES')
