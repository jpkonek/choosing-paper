"""PP60 referee: independent check of the kink certificate (PP51 Thm 5.1 instance; PP50 Prop 6.2 box).

CHECKED parts (exact, Fractions, own cell enumeration from ref_lib):
 (1) the instance A = u, B = (406,421,373)/1200, D = (406,373,421)/1200, eps = 3/10, at scales t = 1 and 1/10
     (B(t) = 1 + t(beta - 1) in unnormalised likelihoods, beta = 3*(406,421,373)/1200): two-valuedness, K1, K3,
     and K2 in BOTH the strict form and the WEAK form (weak Bayes / closed CG2), where the weak per-type pair
     condition is: max_W d > min_R d, or d constant (see report, Lemma R1);
 (2) the box claim of PP50 Prop 6.2 at 40 random exact points of the box x scale (0, 1/5]: same type set as the
     centre at s = 1/10, and the certificate holds;
 (3) at the centre, the type set changes between s = 0.31 and s = 0.33 (PP50: one determinant changes sign at
     s = 400/1259), and t = 1 has a different type set from t = 1/10.
NUMERICS part: (4) LP spot-check of the weak per-type criterion (floats).
"""
import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from itertools import product
from ref_lib import types, norm

OK = True


def check(c, m):
    global OK
    if not c:
        OK = False
        print('FAIL', m)


eps = Fr(3, 10)
beta = [Fr(3 * 406, 1200), Fr(3 * 421, 1200), Fr(3 * 373, 1200)]
delta = [Fr(3 * 406, 1200), Fr(3 * 373, 1200), Fr(3 * 421, 1200)]


def triple(s, x=(0, 0), p=(0, 0), q=(0, 0)):
    a0 = [1 + Fr(x[0]), 1 + Fr(x[1]), Fr(1)]
    pv, qv = [Fr(p[0]), Fr(p[1]), 0], [Fr(q[0]), Fr(q[1]), 0]
    A = a0
    B = [a0[i] * (1 + s * (beta[i] + pv[i] - 1)) for i in range(3)]
    D = [a0[i] * (1 + s * (delta[i] + qv[i] - 1)) for i in range(3)]
    return [norm(A), norm(B), norm(D)]


def pair_W(T, X, Y):
    """set of worse-sets W (worlds where Y's advice is worse than X's) over the disagreement types."""
    out = set()
    for key in T:
        if key[0] == '3V':
            continue
        H, Wr = key
        if (X in H) == (Y in H):
            continue
        out.add(frozenset(Wr) if Y in H else frozenset({0, 1, 2} - set(Wr)))
    return out


WEAK = [d for d in product(range(3), repeat=3) if sorted(set(d)) == list(range(len(set(d))))]


def strict_ok(d, Ws):
    return all(max(d[w] for w in W) > min(d[r] for r in {0, 1, 2} - W) for W in Ws)


def weak_ok(d, Ws):
    return len(set(d)) == 1 or strict_ok(d, Ws)


def certificate(T):
    res = {}
    res['twovalued'] = not any(k[0] == '3V' for k in T)
    res['above'] = (frozenset({'A'}), frozenset({0})) in T      # A alone answers, h wrong only at world 1
    res['below'] = (frozenset({'A'}), frozenset({1, 2})) in T   # A alone answers, h right only at world 1
    WAB, WAD, WBD = pair_W(T, 'A', 'B'), pair_W(T, 'A', 'D'), pair_W(T, 'B', 'D')
    res['K3'] = all(any(w in W for W in Ws) and any(w not in W for W in Ws) for Ws in (WAB, WAD, WBD) for w in range(3))
    sAB = [d for d in WEAK if strict_ok(d, WAB)]
    sAD = [d for d in WEAK if strict_ok(d, WAD)]
    wAB = [d for d in WEAK if weak_ok(d, WAB)]
    wAD = [d for d in WEAK if weak_ok(d, WAD)]
    # d = rank vector of log(nu^A/nu^X); z^X_2 >= z^A_2  <=>  d_2 <= d_1  (worlds indexed 0,1,2)
    res['K2strict'] = all(d[1] <= d[0] for d in sAB) and all(d[1] >= d[0] for d in sAD) and sAB and sAD
    res['K2weak'] = all(d[1] <= d[0] for d in wAB) and all(d[1] >= d[0] for d in wAD)
    res['orders'] = (sAB, sAD, wAB, wAD)
    res['ok'] = res['twovalued'] and res['above'] and res['below'] and res['K3'] and bool(res['K2strict']) and res['K2weak']
    return res


def fmt(d):
    return '>'.join(''.join(str(w + 1) for w in range(3) if d[w] == r) for r in sorted(set(d), reverse=True))


# (1) the instance at t = 1 and t = 1/10
ref = {}
for s in (Fr(1), Fr(1, 10)):
    T = types(eps, triple(s), ['A', 'B', 'D'])
    ref[s] = set(T)
    r = certificate(T)
    sAB, sAD, wAB, wAD = r['orders']
    print('scale %s: disagreement types %d, two-valued %s, above %s, below %s, K3 %s' % (
        s, len(T), r['twovalued'], r['above'], r['below'], r['K3']))
    print('   strict-admissible orders log(nu^A/nu^B): %s ; log(nu^A/nu^D): %s' % ([fmt(d) for d in sAB], [fmt(d) for d in sAD]))
    print('   weak-admissible orders   log(nu^A/nu^B): %s ; log(nu^A/nu^D): %s' % ([fmt(d) for d in wAB], [fmt(d) for d in wAD]))
    print('   K2 strict form: %s ; K2 weak form (ties allowed in the pair conditions): %s' % (bool(r['K2strict']), r['K2weak']))
    check(r['ok'], 'certificate at scale %s' % s)
print('(3) type SETS at t = 1 and t = 1/10 coincide (information; PP50 speaks of the cell structure):', ref[Fr(1)] == ref[Fr(1, 10)])

# (2) random exact points of the box x (0, 1/5]
rng = random.Random(60)
r5 = Fr(1, 100000)
nbad = 0
for k in range(40):
    rv = lambda: Fr(rng.randint(-1000, 1000), 1000) * r5
    s = Fr(rng.randint(1, 10 ** 6), 5 * 10 ** 6) if k % 4 else Fr(1, 5) / 10 ** rng.randint(1, 6)
    T = types(eps, triple(s, (rv(), rv()), (rv(), rv()), (rv(), rv())), ['A', 'B', 'D'])
    same = set(T) == ref[Fr(1, 10)]
    cert = certificate(T)['ok']
    if not (same and cert):
        nbad += 1
        print('   box point %d s=%s: same types %s, certificate %s' % (k, s, same, cert))
check(nbad == 0, 'box sampling')
print('(2) 40 random exact box points (incl. s down to 2e-7): all have the s=1/10 type set and the certificate:', nbad == 0)

# (3) the sign change at the centre near s = 400/1259: count determinant signs that differ from s = 1/10
from itertools import combinations
from ref_lib import normals


def detsigns(s):
    tr = triple(s)
    V = [n for a in tr for n in normals(eps, a)] + [(1, 0, 0), (0, 1, 0), (0, 0, 1)]
    out = []
    for u, v, w in combinations(V, 3):
        d = (u[0] * (v[1] * w[2] - v[2] * w[1]) - u[1] * (v[0] * w[2] - v[2] * w[0]) + u[2] * (v[0] * w[1] - v[1] * w[0]))
        out.append((d > 0) - (d < 0))
    return out


S10 = detsigns(Fr(1, 10))
for s in (Fr(1, 5), Fr(400, 1259) - Fr(1, 10 ** 4), Fr(400, 1259) + Fr(1, 10 ** 4), Fr(1)):
    print('   centre, s = %.5f: determinant signs differing from s = 1/10: %d of %d' % (
        float(s), sum(a != b for a, b in zip(detsigns(s), S10)), len(S10)))
for s in (Fr(31, 100), Fr(400, 1259) - Fr(1, 10 ** 4), Fr(400, 1259) + Fr(1, 10 ** 4), Fr(33, 100)):
    T = set(types(eps, triple(s), ['A', 'B', 'D']))
    print('   centre, s = %.5f: same type set as s = 1/10: %s' % (float(s), T == ref[Fr(1, 10)]))

# (4) NUMERICS: spot-check the weak per-type criterion by LP: for answerer X / silent Y at a type with
#     correct set C and wrong set W, weak feasibility <=> exists y > 0 with sum_C y <= sum_W y and
#     sum_C rho*y >= sum_W rho*y, rho = omega^X/omega^Y.  Claim: <=> max_C rho > min_W rho, or rho constant.
try:
    from scipy.optimize import linprog
    import numpy as np
    bad = 0
    for trial in range(3000):
        C = set(rng.sample([0, 1, 2], rng.randint(1, 2)))
        W = {0, 1, 2} - C
        if trial % 5 == 0:
            rho = [1.0, 1.0, 1.0]
        else:
            rho = [float(rng.choice([1, 2, 3])) for _ in range(3)]
        # maximise t s.t. y >= t, sum y = 1, constraints
        c_obj = [0, 0, 0, -1]
        A_ub, b_ub = [], []
        A_ub.append([(1 if i in C else -1) for i in range(3)] + [0]); b_ub.append(0)
        A_ub.append([(-rho[i] if i in C else rho[i]) for i in range(3)] + [0]); b_ub.append(0)
        for i in range(3):
            row = [0, 0, 0, 1]; row[i] = -1; A_ub.append(row); b_ub.append(0)
        res = linprog(c_obj, A_ub=A_ub, b_ub=b_ub, A_eq=[[1, 1, 1, 0]], b_eq=[1], bounds=[(0, None)] * 3 + [(None, None)], method='highs')
        feas = res.status == 0 and -res.fun > 1e-9
        pred = (len(set(rho)) == 1) or (max(rho[i] for i in C) > min(rho[i] for i in W))
        if feas != pred:
            bad += 1
    print('(4) NUMERICS: weak per-type criterion vs LP on 3000 random cases, disagreements:', bad)
except ImportError:
    print('(4) scipy unavailable; skipped')

print('ALL PASS' if OK else 'FAILURES')
