"""PP60 referee: finite sanity check of AUDIT_section_topology §3 (local construction theorem) and its
3-of-4 strict-vote example.  CHECKED (exact integer arithmetic), exhaustively on a finite model.

Finite analogue.  Problems: 4 points p with integer masses; one world i; at each point a 'correct' answer
(+ or -), giving ranks correct 0 < silent 1 < wrong 2 < contradiction 3.  Models: all 4^4 = 256 advice maps.
Ideal I: all subsets of J = {0, 1, 2} (point 3 plays the part of the non-I, 'conic' part).
Relations:
  Q_vote : reflexive; X Q Y iff at least 3 of 4 strictly guiding additive judges strictly favour X -> Y
           (value of X -> Y = sum_p m_p [f_k(p, Y_p) - f_k(p, X_p)] > 0);
  Q_weak : one additive judge, X Q Y iff value >= 0 (ties allowed; a total preorder);
  Q_bad  : Q_vote with all nontrivial pure-guidance pairs removed (control: violates weak (G)).
  R      : X R Y iff guidance (r(X_p) <= r(Y_p) at every p) or (d(X, Y) subset of J and X Q Y).
Checks for each Q: Q's own reflexivity, weak/strict (G), (IB), (TC); then the same for R.  (IB) is checked by
grouping all pairs by their record (support, X|S, Y|S).  (TC) is the exact implication
A R B, B R C, C R A  =>  B R A, C R B, A R C, over all 256^3 triples (numpy boolean algebra).
Also: an explicit strict 4-cycle for Q_vote (four judges, each disfavouring one edge).
"""
import itertools, random
import numpy as np

rng = random.Random(60)
NP = 4
J = {0, 1, 2}
mass = [3, 5, 2, 7]
corr = [+1, -1, +1, -1]                    # correct answer at each point
ADV = ['+', '0', '-', 'x']


def rank(p, a):
    if a == '0':
        return 1
    if a == 'x':
        return 3
    return 0 if (a == '+') == (corr[p] > 0) else 2


models = list(itertools.product(ADV, repeat=NP))
n = len(models)
Rk = np.array([[rank(p, X[p]) for p in range(NP)] for X in models])          # n x NP
diff = np.array([[[X[p] != Y[p] for p in range(NP)] for Y in models] for X in models])  # n x n x NP
guid = np.all(Rk[:, None, :] <= Rk[None, :, :], axis=2)                      # X no worse than Y everywhere
inJ = ~np.any(diff[:, :, [p for p in range(NP) if p not in J]], axis=2)       # support inside J


def judge():
    inc = [[rng.randint(1, 9) for _ in range(3)] for _ in range(NP)]
    return np.array([[0, inc[p][0], inc[p][0] + inc[p][1], sum(inc[p])] for p in range(NP)])


def value(f):
    lv = np.array([[mass[p] * f[p][Rk[x, p]] for p in range(NP)] for x in range(n)]).sum(1)
    return lv[None, :] - lv[:, None]           # value(X -> Y) = L(Y) - L(X)


judges = [judge() for _ in range(4)]
votes = sum((value(f) > 0).astype(int) for f in judges)
eye = np.eye(n, dtype=bool)
Q_vote = eye | (votes >= 3)
Q_weak = value(judge()) >= 0
pure_guid = guid & ~eye
Q_bad = Q_vote & ~pure_guid | eye

# Q_bad2: minimal control that keeps strict (G), (IB) and (TC) for Q but lacks weak (G):
# Q = reflexive + all common-context copies of two records B -> C and C -> A, where A is a strict
# guidance improvement of B, all supported in J.
def record(x, y):
    S = tuple(p for p in range(NP) if models[x][p] != models[y][p])
    return (S, tuple(models[x][p] for p in S), tuple(models[y][p] for p in S))


strict_better = guid & ~guid.T          # [X, Y]: X pointwise no worse, strictly better somewhere
found = None
for A in range(n):
    if models[A][3] != '0':
        continue
    for B in range(n):
        if not (strict_better[A, B] and inJ[A, B]):
            continue
        for C in range(n):
            if inJ[B, C] and inJ[C, A] and C not in (A, B) and not strict_better[C, B] and not strict_better[A, C] \
                    and not guid[B, C] and not guid[C, A]:
                found = (A, B, C)
                break
        if found:
            break
    if found:
        break
A0, B0, C0 = found
recs = {record(B0, C0), record(C0, A0)}
Q_bad2 = eye.copy()
for x in range(n):
    for y in range(n):
        if record(x, y) in recs:
            Q_bad2[x, y] = True


def props(Rel, name):
    ok = True
    refl = bool(np.all(np.diag(Rel)))
    wG = bool(np.all(Rel[guid]))
    strictimp = guid.T & ~guid                 # Y strictly better than X: X R Y must fail
    sG = not bool(np.any(Rel[strictimp]))
    # (IB): same record => same verdict
    rec = {}
    ib = True
    for x in range(n):
        for y in range(n):
            S = tuple(p for p in range(NP) if models[x][p] != models[y][p])
            key = (S, tuple(models[x][p] for p in S), tuple(models[y][p] for p in S))
            if key in rec and rec[key] != Rel[x, y]:
                ib = False
            rec[key] = Rel[x, y]
    # (TC): for all a,b,c with Rel[a,b] & Rel[b,c] & Rel[c,a], need Rel[b,a] & Rel[c,b] & Rel[a,c]
    R8 = Rel.astype(np.uint8)
    viol = 0
    for a in range(n):
        tri = (Rel[a, :][:, None] & Rel & Rel[:, a][None, :])       # [b, c]: a->b, b->c, c->a
        need = (Rel[:, a][:, None] & Rel.T & Rel[a, :][None, :])     # b->a, c->b, a->c
        viol += int(np.sum(tri & ~need))
    tc = viol == 0
    print('  %-8s reflexive %s | weak (G) %s | strict (G) %s | (IB) %s | (TC) %s (violating ordered triples: %d)' % (
        name, refl, wG, sG, ib, tc, viol))
    return refl and wG and sG and ib and tc


allok = True
for name, Q in (('Q_vote', Q_vote), ('Q_weak', Q_weak), ('Q_bad', Q_bad), ('Q_bad2', Q_bad2)):
    print(name + ':')
    okQ = props(Q, 'Q')
    R = guid | (inJ & Q)
    okR = props(R, 'R')
    if not name.startswith('Q_bad'):
        allok &= okQ and okR
    else:
        print('  (control) %s lacks weak (G); R built from it %s' % (name, 'keeps (TC)' if okR else 'FAILS (TC): the hypothesis "Q contains guidance" is needed'))

# explicit strict 4-cycle for the 3-of-4 rule: 4 regions, edge e improves on region e and worsens on region e-1;
# judge k has magnitude w_k(r) = 4 - ((r - k) mod 4) on region r.  Value of edge e for judge k:
# w_k(e-1) - w_k(e).  Judge k strictly favours every edge except e = k.
four = True
for e in range(4):
    vs = [(4 - ((e - 1 - k) % 4)) - (4 - ((e - k) % 4)) for k in range(4)]
    four &= sum(v > 0 for v in vs) == 3 and vs[e] < 0
print('strict 4-cycle accepted by Q_vote pattern (each edge has exactly 3 strict votes):', four)
allok &= four
print('ALL PASS' if allok else 'FAILURES')
