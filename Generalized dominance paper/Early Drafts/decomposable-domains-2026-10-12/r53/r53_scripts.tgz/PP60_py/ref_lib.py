"""Referee round 52 (PP60): independent exact library.

Written from scratch for this referee report; it does not import PP49-PP53 code.
Posterior model C_a = D_{M_a}, M = c*1 + eps*Delta, c = (1-eps)/3.
C_a accepts g  iff  (m_j o a) . g > 0 for j = 1,2,3   (m_j = c*1 + eps*e_j);
C_a accepts -g iff  all three are < 0;  silent otherwise.   Advice coded +1 / -1 / 0.

Cells of the central arrangement are found by a vertex walk: every open cell of a central
arrangement of >= 2 non-parallel planes in R^3 has a 1-dimensional edge (a line through 0) in its
closure, so it is reached by stepping off such a line into one of the angular sectors around it.
The step is shrunk until it is verified EXACTLY (Fractions) that the point is off every plane and
on the same side as the line for every plane not containing the line.
"""
from fractions import Fraction as Fr
from itertools import combinations
import math


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def sgn(x):
    return (x > 0) - (x < 0)


def verts(eps):
    c = (1 - eps) / 3
    return [tuple(c + (eps if i == j else 0) for i in range(3)) for j in range(3)]


def normals(eps, a):
    return [tuple(m[i] * a[i] for i in range(3)) for m in verts(eps)]


def advice(eps, a, g):
    v = [dot(n, g) for n in normals(eps, a)]
    if all(x > 0 for x in v):
        return 1
    if all(x < 0 for x in v):
        return -1
    return 0


def planes(eps, idxs):
    P = []
    for a in idxs:
        P += normals(eps, a)
    P += [(1, 0, 0), (0, 1, 0), (0, 0, 1)]
    out = []
    for n in P:
        n = tuple(Fr(x) for x in n)
        if all(cross(n, q) != (0, 0, 0) for q in out):
            out.append(n)
    return out


def cell_points(P):
    pts = []
    for n1, n2 in combinations(P, 2):
        v0 = cross(n1, n2)
        if v0 == (0, 0, 0):
            continue
        for s in (1, -1):
            v = tuple(s * x for x in v0)
            thr = [n for n in P if dot(n, v) == 0]
            oth = [n for n in P if dot(n, v) != 0]
            rays = []
            for n in thr:
                d = cross(n, v)
                rays += [d, tuple(-x for x in d)]
            # angular order in the plane orthogonal to v (floats only for ordering)
            e1 = rays[0]
            e2 = cross(v, e1)
            rays.sort(key=lambda d: math.atan2(float(dot(d, e2)), float(dot(d, e1))))
            for i in range(len(rays)):
                t = tuple(rays[i][q] + rays[(i + 1) % len(rays)][q] for q in range(3))
                if t == (0, 0, 0):
                    continue
                dl = Fr(1)
                while True:
                    q = tuple(v[k] + dl * t[k] for k in range(3))
                    if all(sgn(dot(n, q)) == sgn(dot(n, v)) for n in oth) and all(dot(n, q) != 0 for n in thr):
                        break
                    dl /= 3
                pts.append(q)
    return pts


def types(eps, idxs, names=None):
    """Return {type: witness}.  type = ('3V',...) for three-valued cells, else
    (frozenset answering h, frozenset Wr) with h normalised so that some model answers +h."""
    names = names or list(range(len(idxs)))
    P = planes(eps, idxs)
    out = {}
    for g in cell_points(P):
        adv = [advice(eps, a, g) for a in idxs]
        if len(set(adv)) == 1:
            continue
        if 1 in adv and -1 in adv:
            key = ('3V', tuple(adv))
        else:
            if 1 not in adv:
                g = tuple(-x for x in g)
                adv = [-x for x in adv]
            H = frozenset(names[k] for k in range(len(idxs)) if adv[k] == 1)
            Wr = frozenset(w for w in range(3) if g[w] < 0)
            key = (H, Wr)
        out.setdefault(key, g)
    return out


def norm(v):
    s = sum(v)
    return tuple(Fr(x) / s for x in v)
