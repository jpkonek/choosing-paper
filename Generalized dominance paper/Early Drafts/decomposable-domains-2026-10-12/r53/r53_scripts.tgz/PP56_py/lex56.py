"""PP56: the balanced lexicographic relation Lambda (Theorem L of PP56), pointwise data and exact checks.

Level 1 is one field u1(g, x) = |g| * phi(cell, x) (phi integer, cell-constant), with uniform weight lam = (1,1,1):
  * strictly guiding at every world, on all four advice values;
  * on the disagreement region R (cells where A, B, D do not all agree; there they say h or S):
        lam . (phi(h) - phi(S)) = 0           (balanced: h and S exactly lam-indifferent)
        lam . (phi(-h) - phi(S)) > 0,  lam . (phi(C) - phi(S)) > 0;
  * off R, the common advice v of A, B, D is the strict lam-optimum.
Later levels are localisations 1_B * u1 over a fixed countable separating family of sets B
(rational boxes; in finite instances the piece indicators are listed first).
X <=_w Y  iff  the sequence (U^l_w(Y) - U^l_w(X))_l is lexicographically >= 0.
This file: field construction + CHECKED pointwise properties on every cell of the kink arrangement.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from cells56 import all_cells, rank, VALS, MODELS

LAM = (1, 1, 1)


def dotl(v):
    return sum(l * x for l, x in zip(LAM, v))


def phi_cell(g, adv):
    """Integer level-1 field vector for each advice value at cell (ray g, advice tuple of A,B,D)."""
    Pw = [w for w in range(3) if g[w] > 0]
    Nw = [w for w in range(3) if g[w] < 0]
    if not Pw or not Nw:          # unanimous sign: rank field (correct answer strictly best everywhere)
        return {x: tuple(rank(x, g, w) for w in range(3)) for x in VALS}
    vals = set(adv)
    out = {'S': (0, 0, 0)}
    for x in ('P', 'M'):
        cor, wr = (Pw, Nw) if x == 'P' else (Nw, Pw)
        if x in vals and len(vals) > 1:
            kc, kr = len(wr), len(cor)          # tied with S:  lam.phi = |wr||cor| - |cor||wr| = 0
        elif vals == {x}:
            kc, kr = 2 * len(wr), len(cor)      # common value: strictly lam-better than S
        else:
            kc, kr = len(wr), 2 * len(cor)      # not used by the selected models here: strictly lam-worse
        v = [0, 0, 0]
        for w in cor:
            v[w] = -kc
        for w in wr:
            v[w] = kr
        out[x] = tuple(v)
    top = 1 + max(abs(t) for t in out['P'] + out['M'])
    out['C'] = (top, top, top)
    return out


def check_cell(g, adv):
    ph = phi_cell(g, adv)
    ok = True
    # strict guidance: phi_w strictly increasing in rank_w
    for w in range(3):
        order = sorted(VALS, key=lambda x: rank(x, g, w))
        ranks = [rank(x, g, w) for x in order]
        if len(set(ranks)) != 4:
            ok = False
        if not all(ph[order[i]][w] < ph[order[i + 1]][w] for i in range(3)):
            ok = False
    vals = set(adv)
    L = {x: dotl(ph[x]) for x in VALS}
    if len(vals) > 1:   # disagreement: h and S tied, the others strictly worse
        h = (vals - {'S'}).pop()
        other = 'M' if h == 'P' else 'P'
        ok &= L[h] == L['S'] and L[other] > L['S'] and L['C'] > L['S']
    else:
        v = vals.pop()
        ok &= all(L[x] > L[v] for x in VALS if x != v)
    return ok, ph, L


if __name__ == '__main__':
    cells = all_cells()
    allok = True
    nd = 0
    for (sk, adv), g in sorted(cells.items()):
        ok, ph, L = check_cell(g, adv)
        nd += len(set(adv)) > 1
        allok &= ok
        if not ok:
            print('FAIL', sk, adv, ph, L)
    print('cells checked:', len(cells), '(disagreement:', nd, ')')
    print('strict guidance on all four values, balance on R, strict lam-optimality off R:', allok)
    # PP51 gap realised: Lemma 6.1 weak separability with nu^A = nu^B = nu^D = lam, every disagreement type
    gap = True
    for (sk, adv), g in cells.items():
        if len(set(adv)) == 1:
            continue
        ph = phi_cell(g, adv)
        h = (set(adv) - {'S'}).pop()
        wvec = tuple(ph[h][i] - ph['S'][i] for i in range(3))   # orthant vector: >0 exactly where h is wrong
        orth = all((wvec[i] > 0) == (rank(h, g, i) == 2) and wvec[i] != 0 for i in range(3))
        gap &= orth and dotl(wvec) == 0
    print('Lemma 6.1 separability holds weakly (all equalities) with nu = lam for A, B, D on every type:', gap)
    print('ALL PASS' if allok and gap else 'SOME FAIL')
