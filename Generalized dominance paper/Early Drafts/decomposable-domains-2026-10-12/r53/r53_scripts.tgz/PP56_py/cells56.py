"""PP56: exact cells of the kink triple (all cells, agreement cells included).

Uses an unmodified copy of PP50's arrangement enumerator (pp50_lib_copy.py).
Kink triple (PP51 Thm 5.1 instance): A = u, B = (406,421,373)/1200, D = (406,373,421)/1200, eps = 3/10.
For every open cell of the central arrangement we keep one exact interior ray g and:
  adv[N]  in {+1 (accept g), -1 (accept -g), 0 (silent)}  for N in A, B, D.
Advice values used in instances (pointwise, relative to the cell's ray g):
  'P' = accept g, 'M' = accept -g, 'S' = silent, 'C' = contradictory.
Rank at world w (0 correct < 1 silent < 2 wrong < 3 contradictory):
  P: 0 if g_w > 0 else 2;  M: 0 if g_w < 0 else 2;  S: 1;  C: 3.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from pp50_lib_copy import cell_points, advice

EPS = Fr(3, 10)
A = [Fr(1, 3)] * 3
B = [Fr(406, 1200), Fr(421, 1200), Fr(373, 1200)]
D = [Fr(406, 1200), Fr(373, 1200), Fr(421, 1200)]
MODELS = {'A': A, 'B': B, 'D': D}
VALS = ('P', 'M', 'S', 'C')
CODE = {1: 'P', -1: 'M', 0: 'S'}


def rank(val, g, w):
    if val == 'S':
        return 1
    if val == 'C':
        return 3
    s = g[w] if val == 'P' else -g[w]
    return 0 if s > 0 else 2


def sign_key(g):
    return tuple((x > 0) - (x < 0) for x in g)


def all_cells(models=MODELS, eps=EPS):
    """Distinct cells keyed by (sign pattern of g, advice tuple); value = an exact interior ray.
    Cells with a zero coordinate are excluded (they lie on coordinate planes)."""
    seen = {}
    for g in cell_points(eps, models):
        if any(x == 0 for x in g):
            continue
        adv = tuple(CODE[advice(eps, models[k], g)] for k in sorted(models))
        key = (sign_key(g), adv)
        seen.setdefault(key, g)
    return seen


if __name__ == '__main__':
    cells = all_cells()
    dis = {k: g for k, g in cells.items() if len(set(k[1])) > 1}
    print('cell classes (sign pattern x advice of A,B,D):', len(cells), ' with disagreement:', len(dis))
    three = [k for k in dis if set(k[1]) >= {'P', 'M'}]
    print('three-valued / opposite answers:', len(three))
    for k, g in sorted(dis.items()):
        print('  sign', k[0], ' advice(A,B,D)=', k[1], ' ray', [str(x) for x in g])
