"""PP56: the kink certificate's comparisons under Lambda, exact.

(1) Tie case of PP51 Thm 5.1 realised by Lambda's first level; what closed gates do with it (R0: all-world tie;
    R: no defence) and what Lambda does (strict at two worlds, no tie).
(2) A mass path along which Lambda's verdict is not closed (the PP52 Thm 4.1 / Lemma S hypothesis fails).
(3) PP52-style closed, tie-free 'staircase' on the two-cell path: every axiom clause checked on a rational grid.
(4) The R1(ii) triangle translated: all cell triples, random masses, every world.
(5) How many accepted comparisons have no old-side realiser among A, B, D (gate-forbidden acceptances).
"""
import sys, os, random, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from cells56 import rank
from lex56 import phi_cell
from instance56 import DIS, ABOVE, BELOW, Instance

random.seed(5656)
ALL = True
def check(c, msg):
    global ALL
    if not c:
        ALL = False
        print('FAIL', msg)

kp, gp = DIS[ABOVE]; km, gm = DIS[BELOW]
php, phm = phi_cell(gp, kp[1]), phi_cell(gm, km[1])
swap_p = tuple(php['S'][w] - php['P'][w] for w in range(3))   # change A's h -> S on the above cell
swap_m = tuple(phm['S'][w] - phm['P'][w] for w in range(3))   # ... on the below cell
print('(1) level-1 swap vectors (h -> S): above', swap_p, ' below', swap_m)
check(all(swap_p[w] + swap_m[w] == 0 for w in range(3)), 'antiparallel')
# record r = (P+ u P-: h -> S) with equal masses: level-1 value vector 0
inst = Instance([ABOVE, BELOW], ('P', 'S'), [1, 1])
A = inst.base['A']; X = ('S', 'S')
lev1 = [inst.key(X, w)[0] - inst.key(A, w)[0] for w in range(3)]
R0 = [v >= 0 for v in lev1]            # zero-accepting union gate with the common field u1 (A's gate on A -> X)
R0rev = [-v >= 0 for v in lev1]        # B's (= D's) gate on X -> A, same common field
Rs = [v > 0 for v in lev1]
LamF = [inst.leq(A, X, w) for w in range(3)]
LamG = [inst.leq(X, A, w) for w in range(3)]
print('    balanced two-cell rival X1 = A[P+ u P- -> S], equal masses: level-1 difference', lev1)
print('    closed (R0) gates, common field: A<=X at', R0, '; X<=A at', R0rev, '-> all-world tie with incoherent X1')
print('    strict (R) gates: A<=X at', Rs, '-> A undefended')
print('    Lambda: A<=X at', LamF, '; X<=A at', LamG, '-> no tie, A strictly better at 2 worlds')
check(all(R0) and all(R0rev) and not any(Rs), 'gate closures')
check(any(LamF) and not all(LamG) and not any(f and g for f, g in zip(LamF, LamG)), 'Lambda on X1')

print('(2) mass path: masses (t, 1) on (P+, P-), t -> 1 from below; A <=_1 X_t ?')
seq = []
for n in (2, 10, 100, 1000, 10 ** 6):
    t = 1 - Fr(1, n)
    inst_t = Instance([ABOVE, BELOW], ('P', 'S'), [t, Fr(1)])
    seq.append(inst_t.leq(inst_t.base['A'], ('S', 'S'), 0))
lim = Instance([ABOVE, BELOW], ('P', 'S'), [Fr(1), Fr(1)]).leq(A, ('S', 'S'), 0)
print('    t = 1-1/n, n = 2,10,100,1000,1e6:', seq, ';  t = 1:', lim, '-> section of A\'s own verdicts not closed')
check(all(seq) and not lim, 'mass path')

print('(3) closed tie-free staircase on the two-cell path s in [0,2] (leg 1: P+ grows to full, leg 2: P- shrinks)')
c1, d, dl = Fr(1, 2), Fr(3, 2), Fr(1, 8)
def F(w, s):   # A <=_w X_s
    return [s <= c1, s >= c1, s >= d + dl][w]
def G(w, s):   # X_s <=_w A
    return [s >= d, s <= c1 - dl, s <= d][w]
def masses(s):
    return (s, Fr(1)) if s <= 1 else (Fr(1), 2 - s)
grid = [Fr(k, 48) for k in range(97)]
ok = True
for s in grid:
    ok &= any(F(w, s) for w in range(3)) and any(G(w, s) for w in range(3))     # A's and B/D's defences
    ok &= not all(F(w, s) for w in range(3)) and not all(G(w, s) for w in range(3))   # protection + direct (C)
    ok &= not any(F(w, s) and G(w, s) for w in range(3))                      # no single-world tie
# endpoints fixed by strict (G): s = 0 is a pure worsening at 1 / improvement at 2,3; s = 2 the reverse
ok &= [F(w, 0) for w in range(3)] == [True, False, False] and [G(w, 0) for w in range(3)] == [False, True, True]
ok &= [F(w, 2) for w in range(3)] == [False, True, True] and [G(w, 2) for w in range(3)] == [True, False, False]
# (TC) with the guidance links between X_s and X_s' (s < s'): X_s' is strictly better at 1 and strictly worse at 2, 3
def better(s, sp, w):   # X_s strictly better than X_sp at w, by guidance (exact from cell ranks)
    (a1, b1), (a2, b2) = masses(s), masses(sp)
    # X_s' differs from X_s by h->S on extra P+ mass (a2-a1 >= 0) and S->h on P- mass (b1-b2 >= 0)
    up = (a2 - a1, b1 - b2)
    signs = []
    if up[0] > 0:   # h->S on above cell: rank change at w
        signs.append(rank('S', gp, w) - rank('P', gp, w))
    if up[1] > 0:   # S->h on below cell
        signs.append(rank('P', gm, w) - rank('S', gm, w))
    return bool(signs) and all(x > 0 for x in signs)
for s, sp in itertools.combinations(grid, 2):
    for w in range(3):
        for (x, y) in ((s, sp), (sp, s)):
            if better(x, y, w):   # X_x strictly better than X_y at w: X_x <= X_y accepted, reverse refused
                # triangle A -> X_x? no: A <= X_y? ... the two forbidden pairs from (TC):
                # (A, X_x, X_y): A<=X_x, X_x<=X_y, X_y<=A  => reverse X_y<=X_x forbidden
                ok &= not (F(w, x) and G(w, y))
                # (X_y, A, X_x)?  links X_y<=A, A<=X_x, X_x<=X_y: same pair
check(ok, 'staircase')
print('    F_1=[0,1/2], F_2=[1/2,2], F_3=[13/8,2];  G_1=[3/2,2], G_2=[0,3/8], G_3=[0,3/2]: all clauses on a',
      len(grid), 'point grid:', ok)

print('(4) R1(ii) triangle X<=Y<=Z<=X (links realised by A, B, D) over all cell triples, random masses')
cab = [i for i, (k, g) in enumerate(DIS) if k[1][0] != k[1][1]]
cbd = [i for i, (k, g) in enumerate(DIS) if k[1][1] != k[1][2]]
cda = [i for i, (k, g) in enumerate(DIS) if k[1][2] != k[1][0]]
tri = all3 = ties = rev_acc = rev_free = 0
for i, j, l in itertools.product(cab, cbd, cda):
    if len({i, j, l}) < 3:
        continue
    for _ in range(3):
        I = Instance([i, j, l], ('P', 'S'), [random.randint(1, 60) for _ in range(3)])
        a, b, dd = I.base['A'], I.base['B'], I.base['D']
        Xm = (a[0], b[1], a[2]); Ym = (b[0], b[1], dd[2]); Zm = (a[0], dd[1], dd[2])
        for w in range(3):
            tri += 1
            L = [I.leq(Xm, Ym, w), I.leq(Ym, Zm, w), I.leq(Zm, Xm, w)]
            Rv = [I.leq(Ym, Xm, w), I.leq(Zm, Ym, w), I.leq(Xm, Zm, w)]
            all3 += all(L)
            ties += sum(x and y for x, y in zip(L, Rv))
            # reverse Y<=X: old side Y on support {0,2} = (B on cab, D on cda); coherent realiser among A,B,D?
            for (old, new, sup) in ((Ym, Xm, (0, 2)), (Zm, Ym, (0, 1)), (Xm, Zm, (1, 2))):
                if I.leq(old, new, w):
                    rev_acc += 1
                    realised = any(all(I.base[N][p] == old[p] for p in sup if old[p] != new[p]) for N in 'ABD')
                    rev_free += not realised
print('    triangle instances (cell triples x masses x worlds):', tri, ' all three links accepted:', all3,
      ' single-world ties:', ties)
print('    accepted reverse links:', rev_acc, ' of which with no old-side realiser among A, B, D:', rev_free)
check(all3 == 0 and ties == 0, 'R1 triangles')

print('(5) gate-forbidden acceptances in a 6-piece instance (values h,S)')
I = Instance([ABOVE, BELOW] + random.sample([k for k in range(len(DIS)) if k not in (ABOVE, BELOW)], 4),
             ('P', 'S'), [random.randint(1, 60) for _ in range(6)])
mods = I.models()
acc = guid = real = free = 0
for Xm in mods:
    for Ym in mods:
        if Xm == Ym:
            continue
        sup = [p for p in range(6) if Xm[p] != Ym[p]]
        for w in range(3):
            if not I.leq(Xm, Ym, w):
                continue
            acc += 1
            if all(rank(Ym[p], I.g[p], w) >= rank(Xm[p], I.g[p], w) for p in sup):
                guid += 1
            elif any(all(I.base[N][p] == Xm[p] for p in sup) for N in 'ABD'):
                real += 1
            else:
                free += 1
print('    accepted comparisons:', acc, ' guidance:', guid, ' non-guidance with an old-side realiser in {A,B,D}:', real,
      ' non-guidance with none (forbidden in the gate architecture):', free)
print('ALL PASS' if ALL else 'SOME FAIL')
