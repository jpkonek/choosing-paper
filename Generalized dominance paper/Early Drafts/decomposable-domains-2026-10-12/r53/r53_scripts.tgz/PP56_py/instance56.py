"""PP56: exact finite instances on the kink triple's actual cells, verdicts from Lambda, every axiom clause checked.

Instance (exact, IB-faithful):
  * one bounded piece p in each chosen cell (positive measure; m_p := integral of |g| over p, a positive
    integer multiple of a small unit eta -- any positive values are realisable inside a cell, and all
    verdicts of Lambda are invariant under a common rescaling of the masses);
  * models = A outside the pieces, any advice value on each piece;
  * B's and D's obligations enter through exact (IB): B against B[E -> y] has the same record as
    A^B := A[pieces -> B] against A[pieces -> y'], so B's defence/protection/direct-(C) clauses are
    clauses for the proxy A^B (likewise A^D) against every instance model.
Lambda in the instance: level 1 = sum_p m_p phi_p(x_p); then one localised level per piece (piece order fixed).
Checked: reflexivity, strict (G), (IB) (verdict constant on each record class), (TC) on all triples,
defence of A, A^B, A^D at some world, exact undominatedness, direct (C) (no all-world tie), and
absence of single-world ties.
"""
import sys, os, random, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cells56 import all_cells, rank
from lex56 import phi_cell

random.seed(56)
CELLS = all_cells()
# one representative per antipodal pair of disagreement cells: those whose answer is 'P' (accept g)
DIS = sorted([(k, g) for k, g in CELLS.items() if len(set(k[1])) > 1 and 'P' in k[1]])
ABOVE = [i for i, (k, g) in enumerate(DIS) if k[0] == (-1, 1, 1) and k[1] == ('P', 'S', 'S')][0]
BELOW = [i for i, (k, g) in enumerate(DIS) if k[0] == (1, -1, -1) and k[1] == ('P', 'S', 'S')][0]


class Instance:
    def __init__(self, cell_ids, values, masses):
        self.cells = [DIS[i] for i in cell_ids]
        self.m = masses
        self.values = values
        self.phi = [phi_cell(g, k[1]) for k, g in self.cells]
        self.g = [g for k, g in self.cells]
        self.base = {N: tuple(k[1][j] for k, g in self.cells) for j, N in enumerate('ABD')}

    def key(self, X, w):
        lev1 = sum(self.m[p] * self.phi[p][X[p]][w] for p in range(len(X)))
        return (lev1,) + tuple(self.m[p] * self.phi[p][X[p]][w] for p in range(len(X)))

    def leq(self, X, Y, w):        # X no worse than Y at w
        return self.key(X, w) <= self.key(Y, w)

    def models(self):
        return list(itertools.product(*[self.values] * len(self.cells)))


def check_selected(inst, models, out):
    ok = True
    for N, Nx in inst.base.items():
        kn = [inst.key(Nx, w) for w in range(3)]
        for X in models:
            if X == Nx:
                continue
            kx = [inst.key(X, w) for w in range(3)]
            defence = any(kn[w] <= kx[w] for w in range(3))
            strict_somewhere = any(kn[w] < kx[w] for w in range(3))   # N strictly better at some world
            if not (defence and strict_somewhere):
                ok = False
                out.append(('selected', N, X))
    return ok


def check_all_axioms(inst, models):
    ok = True
    W = range(3)
    K = {X: [inst.key(X, w) for w in W] for X in models}
    # reflexivity, ties, strict G
    for X in models:
        ok &= all(K[X][w] <= K[X][w] for w in W)
    for X, Y in itertools.combinations(models, 2):
        for w in W:
            if K[X][w] == K[Y][w]:
                ok = False      # a single-world tie between distinct models
            rx = [rank(X[p], inst.g[p], w) for p in range(len(X))]
            ry = [rank(Y[p], inst.g[p], w) for p in range(len(Y))]
            if all(a <= b for a, b in zip(rx, ry)) and rx != ry:
                ok &= K[X][w] < K[Y][w]
            if all(a >= b for a, b in zip(rx, ry)) and rx != ry:
                ok &= K[Y][w] < K[X][w]
    # IB: verdict depends only on the record (pieces where they differ, old and new values)
    rec = {}
    for X in models:
        for Y in models:
            r = tuple((p, X[p], Y[p]) for p in range(len(X)) if X[p] != Y[p])
            v = tuple(K[X][w] <= K[Y][w] for w in W)
            if rec.setdefault(r, v) != v:
                ok = False
    # TC in implication form, all ordered triples
    for X in models:
        for Y in models:
            for Z in models:
                for w in W:
                    if K[X][w] <= K[Y][w] and K[Y][w] <= K[Z][w] and K[Z][w] <= K[X][w]:
                        ok &= K[Y][w] <= K[X][w] and K[Z][w] <= K[Y][w] and K[X][w] <= K[Z][w]
    return ok, len(rec)


if __name__ == '__main__':
    print('normalised disagreement cells:', len(DIS), ' above =', ABOVE, ' below =', BELOW)
    for i, (k, g) in enumerate(DIS):
        print('  cell %2d  sign %-12s advice(A,B,D) %s' % (i, k[0], k[1]))
    ALL = True
    # (1) all 18 cells, splice values {P,S}: 2^18 rivals; selected obligations
    for trial in range(2):
        masses = [random.randint(1, 50) for _ in DIS]
        inst = Instance(list(range(len(DIS))), ('P', 'S'), masses)
        bad = []
        ok = check_selected(inst, inst.models(), bad)
        print('[I1.%d] 18 pieces, values {h,S}, %d rivals: defence + protection + direct (C) for A, B, D:' % (trial, 2 ** 18), ok)
        ALL &= ok
    # (2) six pieces incl. the two certificate cells, all four values: 4096 rivals
    ids = [ABOVE, BELOW] + random.sample([i for i in range(len(DIS)) if i not in (ABOVE, BELOW)], 4)
    inst = Instance(ids, ('P', 'M', 'S', 'C'), [random.randint(1, 50) for _ in ids])
    bad = []
    ok = check_selected(inst, inst.models(), bad)
    print('[I2] 6 pieces (cells %s), four values, %d rivals: selected obligations:' % (ids, 4 ** 6), ok)
    ALL &= ok
    # (3) exhaustive axiom check on small instances
    for ids, vals in (([ABOVE, BELOW] + ids[2:6], ('P', 'S')), ([ABOVE, BELOW, ids[2]], ('P', 'M', 'S', 'C'))):
        inst = Instance(ids, vals, [random.randint(1, 50) for _ in ids])
        mods = inst.models()
        ok1, nrec = check_all_axioms(inst, mods)
        bad = []
        ok2 = check_selected(inst, mods, bad)
        print('[I3] cells %s values %s: %d models, %d records; reflexivity, strict (G), (IB), (TC), no ties:' %
              (ids, ''.join(vals), len(mods), nrec), ok1, '; selected obligations:', ok2)
        ALL &= ok1 and ok2
    print('ALL PASS' if ALL else 'SOME FAIL')
