"""PP50 library: exact type enumeration for finitely many posterior models C_a.

T = D_M, M = c*1 + eps*Delta, vertices m_j = c*1 + eps*e_j, c = (1-eps)/3.
Posterior model C_a = D_{M_a}, M_a = {a*p/(a.p) : p in M}.  C_a accepts g iff (m_j * a).g > 0 for all j.
Advice of C_a at g: +1 (accept g), -1 (accept -g), 0 (silent).

A *type* is the combinatorial data that every pointwise constraint depends on:
   (frozenset of models answering h, frozenset of models silent, Wr)
where h is the answer given (g or -g, normalised so the answer is +h), and Wr = {v : h_v < 0}
(the worlds at which the answer h is wrong).  Types are constant on the open cells of the central
plane arrangement {n.g = 0}, n in {m_j*a_N} U {e_1,e_2,e_3}; every cell is adjacent to a vertex
(a line where two planes meet), so all cells are found by perturbing around every vertex.
Everything is exact (Fractions).
"""
from fractions import Fraction as Fr
from itertools import combinations


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def cross(a, b):
    return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]


def sgn(x):
    return (x > 0) - (x < 0)


def mverts(eps):
    c = (1 - eps) / 3
    return [[c + (eps if i == j else 0) for j in range(3)] for i in range(3)]


def normals(eps, a):
    return [[m[j] * a[j] for j in range(3)] for m in mverts(eps)]


def advice(eps, a, g):
    vals = [dot(n, g) for n in normals(eps, a)]
    if min(vals) > 0:
        return 1
    if max(vals) < 0:
        return -1
    return 0


def plane_list(eps, models):
    P = []
    for a in models.values():
        P.extend(normals(eps, a))
    P.extend([[1, 0, 0], [0, 1, 0], [0, 0, 1]])
    # remove exact duplicates (up to positive/negative scaling)
    out = []
    for n in P:
        dup = False
        for q in out:
            if cross(n, q) == [0, 0, 0]:
                dup = True
                break
        if not dup:
            out.append(n)
    return out


def cell_points(eps, models):
    """One exact interior point for every open cell of the arrangement (with repetitions)."""
    P = plane_list(eps, models)
    pts = []
    for n1, n2 in combinations(P, 2):
        p = cross(n1, n2)
        if p == [0, 0, 0]:
            continue
        for sp in (1, -1):
            v = [sp * x for x in p]
            through = [n for n in P if dot(n, v) == 0]
            # tangent directions of the circles through v, both orientations
            dirs = []
            for n in through:
                d = cross(n, v)
                dirs.append(d)
                dirs.append([-x for x in d])
            # order dirs by angle in the tangent plane
            e1 = dirs[0]
            e2 = cross(v, e1)
            import math
            def ang(d):
                return math.atan2(float(dot(d, e2)), float(dot(d, e1)))
            dirs.sort(key=ang)
            k = len(dirs)
            for i in range(k):
                t = [dirs[i][q] + dirs[(i + 1) % k][q] for q in range(3)]
                if t == [0, 0, 0]:
                    continue
                # step size small enough to keep the signs of all planes not through v
                delta = Fr(1)
                others = [n for n in P if dot(n, v) != 0]
                while True:
                    q = [v[j] + delta * t[j] for j in range(3)]
                    if all(sgn(dot(n, q)) == sgn(dot(n, v)) for n in others) and \
                            all(dot(n, q) != 0 for n in through):
                        # check it is really strictly inside the sector (between dirs i and i+1)
                        break
                    delta /= 4
                pts.append(q)
    return pts


def type_of(eps, models, g):
    adv = {k: advice(eps, a, g) for k, a in models.items()}
    vals = set(adv.values())
    if 1 not in vals and -1 in vals:
        g = [-x for x in g]
        adv = {k: -v for k, v in adv.items()}
        vals = set(adv.values())
    if vals == {1} or vals == {0} or vals == {-1}:
        return None  # no disagreement
    if 1 in vals and -1 in vals:
        return ('THREE', frozenset(k for k in adv if adv[k] == 1),
                frozenset(k for k in adv if adv[k] == -1), tuple(g))
    H = frozenset(k for k in adv if adv[k] == 1)
    S = frozenset(k for k in adv if adv[k] == 0)
    Wr = frozenset(v for v in range(3) if g[v] < 0)
    return (H, S, Wr)


def enumerate_types(eps, models):
    pts = cell_points(eps, models)
    types = {}
    for g in pts:
        t = type_of(eps, models, g)
        if t is None:
            continue
        types.setdefault(t, g)
    return types


def posterior(a_unnorm):
    s = sum(a_unnorm)
    return [Fr(x) / s for x in a_unnorm]
