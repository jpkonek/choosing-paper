"""PP55 gate-derived constraint system (V3), exactly as in PP51's certificate (Lemma 2.3 / PP50 Lemma 6.1).

Unknowns (Lemma 6.1 substitution, constants absorbed):
   nu[N][w] > 0           effective weights  nu = lambda / c   (one triple -> one constant set)
   mt[N][c][w] > 0        rescaled field magnitude |l^N_w(h) - l^N_w(S)| * c^N_w on cell c
Constraint groups, each tracked for cores:
   BAYES(N,c):  N answers h on c:   sum_{w in Wr} nu_w mt_w  <  sum_{w in Rt} nu_w mt_w
                N silent on c:      reverse  (strict; 'weak' variants use <=)
   CG2(N,M,c,w): N answers, M silent on c:  w in Rt: mt^N_w <= mt^M_w ;  w in Wr: mt^N_w >= mt^M_w
                (closed triangle test with the triple's common constants; strict variants use <,>)
Agreement cells carry no coupling and are always satisfiable (each model's field is free there).
The values for -h and contradiction are completed as in PP51 (verify51.complete) and never bind.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import z3
import geom55 as G


def system(gs, pats, cells, weak_bayes=(), weak_cg2=(), strict_cg2=True, names=('A', 'B', 'D')):
    """weak_bayes: set of (N, c) whose Bayes is weak; weak_cg2: set of cells where CG2 is non-strict
    (when strict_cg2) ; returns solver with tracked groups."""
    s = z3.Solver()
    nu = {N: [z3.Real('nu_%s_%d' % (N, w)) for w in range(3)] for N in names}
    groups = {}
    for N in names:
        s.add(nu[N][0] == 1)
        for w in (1, 2):
            s.add(nu[N][w] > 0)
    mt = {}
    for c in cells:
        g = gs[c]
        cor = [w for w in range(3) if g[w] > 0]
        wr = [w for w in range(3) if g[w] < 0]
        for N in names:
            mt[(N, c)] = [z3.Real('m_%s_%d_%d' % (N, c, w)) for w in range(3)]
            for w in range(3):
                s.add(mt[(N, c)][w] > 0)
        for N in names:
            m = mt[(N, c)]
            lhs = z3.Sum([nu[N][w] * m[w] for w in wr])
            rhs = z3.Sum([nu[N][w] * m[w] for w in cor])
            ans = pats[N][c] == 'P'
            weak = (N, c) in weak_bayes
            if ans:
                con = lhs <= rhs if weak else lhs < rhs
            else:
                con = lhs >= rhs if weak else lhs > rhs
            groups[('BAYES', N, c)] = con
        for N in names:
            for M in names:
                if pats[N][c] == 'P' and pats[M][c] == 'S':
                    for w in range(3):
                        strict = strict_cg2 and c not in weak_cg2
                        a, b = mt[(N, c)][w], mt[(M, c)][w]
                        if w in cor:
                            con = a < b if strict else a <= b
                        else:
                            con = a > b if strict else a >= b
                        groups[('CG2', N, M, c, w)] = con
    return s, groups, nu, mt


def check(s, groups, keys=None):
    keys = list(groups) if keys is None else keys
    s.push()
    trk = {}
    for k in keys:
        b = z3.Bool('t_' + '_'.join(map(str, k)))
        trk[b] = k
        s.assert_and_track(groups[k], b)
    r = s.check()
    core = None
    model = None
    if r == z3.unsat:
        core = [trk[b] for b in s.unsat_core()]
    elif r == z3.sat:
        model = s.model()
    s.pop()
    return r, core, model


def minimise(s, groups, core):
    """deletion-based minimal core (each removal re-checked exactly)."""
    core = list(core)
    i = 0
    while i < len(core):
        trial = core[:i] + core[i + 1:]
        r, c2, _ = check(s, groups, trial)
        if r == z3.unsat:
            core = [k for k in trial if k in set(c2)] if c2 else trial
            i = 0 if c2 else i
        else:
            i += 1
    return core
