"""PP55 finite measurable instances around the kink triple.

Pieces.  Every cell of the arrangement (geom55) is a piece, except the ACTIVE cells, which may
be subdivided:
  * radial split  'r':  cell ∩ {|g| < r*} and cell ∩ {|g| > r*};  r* = Gaussian median radius
    (chi distribution with 3 d.o.f.), so each half has exactly half the cell's mass;
  * angular split 'a':  the two open sub-cones cut out of the cell by the plane n^perp,
    n = g0 x v, where g0 is the cell's exact interior point and v is chosen so that n has
    mixed signs.  Both sides are nonempty (they contain g0 ± delta n for small delta,
    checked exactly).  Both are positive-measure open cones.
All pieces are actual positive-measure measurable sets.

Models.  A model is (active vector, outside label).  On active pieces it takes values in the
piece's alphabet (subset of P,S,N,C); on every non-active cell it equals the advice of the
outside label's model (A, B or D).  Hence the three kink models are in the universe.

Records.  rec(X,Y) = (support, advice of X there, advice of Y there).  Two pairs give the
same record iff the active parts agree piecewise and the outside parts agree; the outside part
is determined by the ordered pair of outside labels (empty when the labels agree).  This is an
exact identification: different outside pairs have different supports (checked below).
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import itertools
from fractions import Fraction as Fr
import numpy as np
import geom55 as G

VAL = {'P': 0, 'S': 1, 'N': 2, 'C': 3}
INV = 'PSNC'
OUTL = ['A', 'B', 'D']


class Instance:
    def __init__(self, active, alph, splits, outside=('A', 'B', 'D'), models=None, extra_models=()):
        """active: list of cell indices; alph: dict cell -> alphabet string;
        splits: dict cell -> list of piece labels (e.g. ['in','out'] or ['in+','in-','out+','out-'])."""
        self.models_idx = models or G.KINK
        self.gs = G.cells(self.models_idx)
        self.ncell = len(self.gs)
        self.pat = {nm: ''.join(G.advice_post(a, g) for g in self.gs) for nm, a in zip(G.NAMES, self.models_idx)}
        self.cat = sorted(G.coherent_catalogue(self.gs, self.models_idx))
        self.catset = set(self.cat)
        # pieces
        self.active = list(active)
        self.pieces = []          # (cell, label)
        for c in self.active:
            for lab in splits.get(c, ['whole']):
                self.pieces.append((c, lab))
        self.np = len(self.pieces)
        self.palph = [alph[c] for (c, lab) in self.pieces]
        self.outside = list(outside)
        # rank tables: rk[w][piece][value]
        self.rk = np.zeros((3, self.np, 4), dtype=np.int8)
        for w in range(3):
            for p, (c, lab) in enumerate(self.pieces):
                for v in range(4):
                    self.rk[w, p, v] = G.rank(INV[v], self.gs[c], w)
        # outside cells
        self.nonact = [c for c in range(self.ncell) if c not in self.active]
        # models
        acts = list(itertools.product(*[[VAL[x] for x in a] for a in self.palph]))
        self.models = []
        for o in self.outside:
            for av in acts:
                self.models.append((av, o))
        for em in extra_models:
            self.models.append(em)
        self.n = len(self.models)
        self.M = np.array([m[0] for m in self.models], dtype=np.int8)       # n x np
        self.O = np.array([OUTL.index(m[1]) for m in self.models], dtype=np.int8)
        self.index = {m: i for i, m in enumerate(self.models)}
        # selected models
        self.sel = {}
        for nm in G.NAMES:
            av = tuple(VAL[self.pat[nm][c]] for (c, lab) in self.pieces)
            self.sel[nm] = self.index[(av, nm)]
        # outside pair data: per (o1,o2): list of cells where they differ, ranks
        self.out_cells = {}
        self.out_cnt = np.zeros((3, 3, 3, 2), dtype=np.int16)   # o1,o2,w,(nworse,nbetter) for o1 -> o2
        for i1, o1 in enumerate(OUTL):
            for i2, o2 in enumerate(OUTL):
                cl = [c for c in self.nonact if self.pat[o1][c] != self.pat[o2][c]]
                self.out_cells[(i1, i2)] = cl
                for w in range(3):
                    nw = sum(1 for c in cl if G.rank(self.pat[o2][c], self.gs[c], w) > G.rank(self.pat[o1][c], self.gs[c], w))
                    nb = sum(1 for c in cl if G.rank(self.pat[o2][c], self.gs[c], w) < G.rank(self.pat[o1][c], self.gs[c], w))
                    self.out_cnt[i1, i2, w] = (nw, nb)
        # exactness of outside identification: distinct ordered outside pairs have distinct records
        sup = {}
        for k, cl in self.out_cells.items():
            if k[0] != k[1]:
                key = tuple((c, self.pat[OUTL[k[0]]][c], self.pat[OUTL[k[1]]][c]) for c in cl)
                assert key and key not in sup, 'outside identification not exact'
                sup[key] = k
        # coherence of every model
        self.coh = np.array([self._coherent(m) for m in self.models], dtype=bool)

    # ---------- coherence ----------
    def full_pattern(self, m):
        """76-cell pattern if the model is a.e. conic (constant on the pieces of each active cell), else None."""
        av, o = m
        pat = list(self.pat[o])
        seen = {}
        for p, (c, lab) in enumerate(self.pieces):
            v = INV[av[p]]
            if c in seen and seen[c] != v:
                return None
            seen[c] = v
            pat[c] = v
        return ''.join(pat)

    def _coherent(self, m):
        fp = self.full_pattern(m)
        if fp is None:
            return False          # not conic: incoherent (coherent models are conic)
        if 'C' in fp:
            return False          # a coherent D_K, K nonempty, is never contradictory
        return fp in self.catset  # exact: complete catalogue of cell-measurable coherent models

    # ---------- records ----------
    def pair_arrays(self, I=None, J=None):
        """For index arrays I (rows) and J (cols): record keys and guidance status per world.
        status: 0 trivial(identical), 1 forced true (weak worsening), -1 forced false (pure
        improvement), 2 free."""
        if I is None:
            I = np.arange(self.n)
        if J is None:
            J = np.arange(self.n)
        X = self.M[I][:, None, :].astype(np.int64)
        Y = self.M[J][None, :, :].astype(np.int64)
        diff = X != Y
        code = np.where(diff, 1 + 4 * X + Y, 0)
        key = np.zeros((len(I), len(J)), dtype=np.int64)
        for p in range(self.np):
            key = key * 17 + code[:, :, p]
        oI = self.O[I][:, None].astype(np.int64)
        oJ = self.O[J][None, :].astype(np.int64)
        ocode = np.where(oI == oJ, 0, 1 + 3 * oI + oJ)
        key = key * 10 + ocode
        status = np.zeros((3, len(I), len(J)), dtype=np.int8)
        for w in range(3):
            rx = self.rk[w][np.arange(self.np)[None, None, :], X]
            ry = self.rk[w][np.arange(self.np)[None, None, :], Y]
            nworse = ((ry > rx) & diff).sum(-1) + self.out_cnt[oI, oJ, w, 0]
            nbet = ((ry < rx) & diff).sum(-1) + self.out_cnt[oI, oJ, w, 1]
            st = np.full(nworse.shape, 2, dtype=np.int8)
            st[(nbet == 0) & (nworse > 0)] = 1
            st[(nworse == 0) & (nbet > 0)] = -1
            st[(nworse == 0) & (nbet == 0)] = 0
            status[w] = st
        return key, status

    def decode(self, i, j):
        """Human-readable record of models i -> j."""
        (ax, ox), (ay, oy) = self.models[i], self.models[j]
        parts = []
        for p, (c, lab) in enumerate(self.pieces):
            if ax[p] != ay[p]:
                parts.append('c%d%s:%s>%s' % (c, '' if lab == 'whole' else '.' + lab, INV[ax[p]], INV[ay[p]]))
        if ox != oy:
            parts.append('outside[%s>%s]' % (ox, oy))
        return '{' + ', '.join(parts) + '}'

    def old_side_realisers(self, i, j):
        """Coherent realisers of the old side of rec(i,j): (exists coherent, list of selected names)."""
        (ax, ox), (ay, oy) = self.models[i], self.models[j]
        cons = {}
        for p, (c, lab) in enumerate(self.pieces):
            if ax[p] != ay[p]:
                v = INV[ax[p]]
                if c in cons and cons[c] != v:
                    return False, []
                cons[c] = v
        if ox != oy:
            for c in self.out_cells[(OUTL.index(ox), OUTL.index(oy))]:
                cons[c] = self.pat[ox][c]
        if any(v == 'C' for v in cons.values()):
            return False, []
        coh = any(all(pt[c] == v for c, v in cons.items()) for pt in self.cat)
        selr = [nm for nm in G.NAMES if all(self.pat[nm][c] == v for c, v in cons.items())]
        return coh, selr

    def name(self, i):
        for nm, k in self.sel.items():
            if k == i:
                return nm
        av, o = self.models[i]
        return '%s[%s]' % (o, ''.join(INV[x] for x in av))


def cell_ids(inst):
    """Locate the certificate cells by type (exact)."""
    pa, pb, pd = inst.pat['A'], inst.pat['B'], inst.pat['D']
    out = {}
    for c, g in enumerate(inst.gs):
        cor = tuple(w for w in range(3) if g[w] > 0)
        t = (pa[c], pb[c], pd[c], cor)
        out.setdefault(t, []).append(c)
    return out
