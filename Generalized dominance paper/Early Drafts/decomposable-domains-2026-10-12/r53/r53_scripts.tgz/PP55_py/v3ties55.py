"""PP55: the PP51 gap (ties on the certificate cells), field level.
(a) extended checker: degenerate chains force z^A = z^B or z^A = z^D (contradicting a strict pair inequality)
    or the 'collinear all-tie' configuration; (b) targeted exact search for the collinear all-tie configuration
    with every other disagreement cell strict."""
import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import numpy as np
import v3core55 as V

inst, dis = V.setup()
U, L = inst.cc['U'], inst.cc['L']
NM = V.NM
allg = {('SEP', N, c) for N in NM for c in dis}

def strict_pair_exists(X):
    """some cell where A and X disagree and at least one of them is strict (here: every cell except U, L)."""
    return [c for c in dis if c not in (U, L) and inst.pat['A'][c] != inst.pat[X][c]]

print('cells giving strict AB inequalities off U, L:', strict_pair_exists('B'))
print('cells giving strict AD inequalities off U, L:', strict_pair_exists('D'))
weakUL = {(N, c) for N in NM for c in (U, L)}
consB = V.pair_constraints(inst, allg, weakUL, 'B')
consD = V.pair_constraints(inst, allg, weakUL, 'D')
print('K2 still forced with all of A,B,D weak on U and L (from the other cells):',
      V.forced(consB, 0, 1) and V.forced(consD, 1, 0), '(coordinate 2: z^B >= z^A >= z^D)')

# (b) targeted search: z^A = theta z^B + (1-theta) z^D, d = z^B - z^D with d2 > 0 > d3
rnd = random.Random(7)
others = [c for c in dis if c not in (U, L)]
found = None
tries = 0
for t in range(20000):
    tries += 1
    zB = (np.exp(rnd.uniform(-1.5, 1.5)), np.exp(rnd.uniform(-1.5, 1.5)))
    zD = (np.exp(rnd.uniform(-1.5, 1.5)), np.exp(rnd.uniform(-1.5, 1.5)))
    if not (zB[0] > zD[0] and zB[1] < zD[1]):
        continue
    th = rnd.uniform(0.05, 0.95)
    zA = (th * zB[0] + (1 - th) * zD[0], th * zB[1] + (1 - th) * zD[1])
    nus = {'A': (1.0,) + zA, 'B': (1.0,) + zB, 'D': (1.0,) + zD}
    ws = {}
    ok = True
    for c in others:
        w = V.cell_lp(inst, c, nus, allg, set())
        if w is None:
            ok = False
            break
        ws[c] = w
    if not ok:
        continue
    # exact: rationalise zB, zD, theta; zA exactly on the segment
    q = lambda x: Fr(float(x)).limit_denominator(10 ** 6)
    zBq, zDq, thq = (q(zB[0]), q(zB[1])), (q(zD[0]), q(zD[1])), q(th)
    zAq = tuple(thq * zBq[k] + (1 - thq) * zDq[k] for k in range(2))
    nq = {'A': (Fr(1),) + zAq, 'B': (Fr(1),) + zBq, 'D': (Fr(1),) + zDq}
    d = (zBq[0] - zDq[0], zBq[1] - zDq[1])
    b, cc = -d[1], d[0]                     # normal to d, both > 0
    a = b * zAq[0] + cc * zAq[1]
    wq = {U: (a, -b, -cc), L: (-a, b, cc)}
    for c in others:
        wq[c] = tuple(q(x) for x in ws[c])
    if all(V.exact_ok(inst, c, nq, wq[c], allg, weakUL) for c in dis):
        found = (nq, wq)
        break
print('targeted search tries', tries)
if found:
    nq, wq = found
    print('COLLINEAR ALL-TIE CONFIGURATION: SAT at the field level (exact witness on all 32 cells)')
    print('  nu =', {N: tuple(str(x) for x in nq[N]) for N in NM})
    for c in (U, L):
        print('  cell', c, 'w =', tuple(str(x) for x in wq[c]),
              ' nu.w =', {N: str(sum(nq[N][v] * wq[c][v] for v in range(3))) for N in NM})
    print('  w_U + w_L =', tuple(str(wq[U][v] + wq[L][v]) for v in range(3)), '(antiparallel)')
else:
    print('no exact witness found for the collinear all-tie configuration')
