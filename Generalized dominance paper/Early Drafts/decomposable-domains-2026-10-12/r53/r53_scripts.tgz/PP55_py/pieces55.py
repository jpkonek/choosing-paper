"""PP55: exact check that every piece used is an actual positive-measure set.
Radial pieces: cell ∩ {|g| < r*}, cell ∩ {|g| > r*}, r* the median of the chi(3) law: each has exactly half
the cell's Gaussian mass (radial and angular parts of the Gaussian are independent).  Nothing to compute.
Angular pieces: the two open sub-cones cell ∩ {±n.g > 0}, n = g0 x v.  We check exactly that n has mixed
signs (so n^perp is not p^perp for any p in the simplex, and models differing across it are incoherent),
and that g0 ± delta*n lie in the cell (same sign vector as g0), on opposite sides of n^perp."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import geom55 as G, levels55
inst = levels55.make(0)
ns = G.normals(G.KINK)
ok = True
for nm in ('U', 'L'):
    c = inst.cc[nm]
    g0 = inst.gs[c]
    for v in [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 2, 0)]:
        n = G.cross(g0, tuple(Fr(x) for x in v))
        if min(n) < 0 < max(n):
            break
    sv = G.signvec(ns, g0)
    d = Fr(1)
    while True:
        p1 = tuple(g0[k] + d * n[k] for k in range(3)); p2 = tuple(g0[k] - d * n[k] for k in range(3))
        if G.signvec(ns, p1) == sv and G.signvec(ns, p2) == sv:
            break
        d /= 2
    s1, s2 = G.sgn(G.dot(n, p1)), G.sgn(G.dot(n, p2))
    good = min(n) < 0 < max(n) and s1 == 1 and s2 == -1
    ok &= good
    print(nm, 'cell', c, 'g0 =', tuple(str(x) for x in g0))
    print('   split normal n =', tuple(str(x) for x in n), 'mixed signs:', min(n) < 0 < max(n))
    print('   g0 + d n and g0 - d n in the cell, sides', s1, s2, 'd =', d, '->', 'PASS' if good else 'FAIL')
print('ALL PASS' if ok else 'FAILURE')
