"""PP55: V1 explores the certificate-cell ties (coordinator's request; PP51's stated gap).
For X = A[E -> v] with E a union of pieces of U and L meeting both, force:
  t1(w): single-world tie  A ~_w X ;
  t2   : A ⪯_w X at every w (the zero-value acceptance a tied gate produces under (R0));
  t3   : t2 plus X ⪯_w A at every w (all-world tie; the F2 of the gate argument);
  t4(w): t2 plus X ⪯_v A at the two worlds v != w.
and, jointly, t1 at a fixed world on every such record at once.
Usage: python3 -B ties55.py LEVEL"""
import sys, os, time, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import levels55, sat55

LEVEL = int(sys.argv[1]) if len(sys.argv) > 1 else 0
T0 = time.time()
inst = levels55.make(LEVEL)
E = sat55.Encoder(inst, ties=True)
E.build_static()
ok, _ = E.solve()
print('LEVEL', LEVEL, 'base V1:', 'SAT' if ok else 'UNSAT', 't=%.0fs' % (time.time() - T0), flush=True)
U, L = inst.cc['U'], inst.cc['L']
sA = inst.sel['A']
avA, oA = inst.models[sA]
upi = [p for p, (c, lab) in enumerate(inst.pieces) if c == U]
lpi = [p for p, (c, lab) in enumerate(inst.pieces) if c == L]
vals = sorted({x for p in upi + lpi for x in inst.palph[p] if x != 'P'})


def rivals():
    out = []
    for ku in range(1, len(upi) + 1):
        for EU in itertools.combinations(upi, ku):
            for kl in range(1, len(lpi) + 1):
                for EL in itertools.combinations(lpi, kl):
                    for v in vals:
                        av = list(avA)
                        for p in EU + EL:
                            av[p] = sat55.np.int8(levels55.I55.VAL[v])
                        x = inst.index[(tuple(int(t) for t in av), oA)]
                        out.append((x, EU, EL, v))
    return out


def test(assume, tag):
    lits = []
    for l in assume:
        if l is False:
            print('   %-60s excluded by strict (G)' % tag, flush=True)
            return 'G'
        if l is True:
            continue
        lits.append(l)
    ok, _ = E.solve(assumptions=lits)
    if ok:
        res = 'SAT'
    else:
        core = E.S.get_core()
        res = 'UNSAT (assumption core size %d)' % len(core)
    print('   %-60s %s' % (tag, res), flush=True)
    return res


R = rivals()
print('rivals X = A[E -> v], E meeting both U and L:', len(R), flush=True)
summary = {}
for (x, EU, EL, v) in R:
    nmx = inst.decode(sA, x)
    fw = [E.lit(sA, x, w) for w in range(3)]
    bw = [E.lit(x, sA, w) for w in range(3)]
    for w in range(3):
        r = test([fw[w], bw[w]], 't1 tie at w%d  %s' % (w + 1, nmx))
        summary[('t1', r)] = summary.get(('t1', r), 0) + 1
    r = test(fw, 't2 A⪯X at all worlds  %s' % nmx)
    summary[('t2', r)] = summary.get(('t2', r), 0) + 1
    r = test(fw + bw, 't3 all-world tie  %s  (X coherent: %s)' % (nmx, bool(inst.coh[x])))
    summary[('t3', r)] = summary.get(('t3', r), 0) + 1
    for w in range(3):
        r = test(fw + [bw[v] for v in range(3) if v != w], 't4 A⪯X all, X⪯A off w%d  %s' % (w + 1, nmx))
        summary[('t4', r)] = summary.get(('t4', r), 0) + 1
for w in range(3):
    lits = []
    for (x, EU, EL, v) in R:
        lits += [E.lit(sA, x, w), E.lit(x, sA, w)]
    summary[('joint t1 w%d' % (w + 1), test(lits, 'joint: every such record tied at w%d' % (w + 1)))] = 1
print('summary:', summary)
print('done t=%.0fs' % (time.time() - T0))
