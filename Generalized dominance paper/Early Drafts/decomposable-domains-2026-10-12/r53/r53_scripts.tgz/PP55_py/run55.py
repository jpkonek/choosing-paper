"""PP55 main runs: V1 (ties allowed), V2 (no single-world ties), realiser-gated variants,
lexicographic witness (Theorem L), pattern extraction.  Usage: python3 -B run55.py LEVEL"""
import sys, os, time, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import levels55, sat55
import geom55 as G

LEVEL = int(sys.argv[1]) if len(sys.argv) > 1 else 0
T0 = time.time()


def log(*a):
    print(*a, flush=True)


def ul_only(inst, i, j):
    """record i->j supported only on pieces of the certificate cells U, L (outside labels equal)."""
    U, L = inst.cc['U'], inst.cc['L']
    if inst.models[i][1] != inst.models[j][1]:
        return False
    for p, (c, lab) in enumerate(inst.pieces):
        if inst.models[i][0][p] != inst.models[j][0][p] and c not in (U, L):
            return False
    return True


def patterns(E, R, tag):
    I = E.I
    n = I.n
    st = E.status
    # ties
    ties = {'all': 0, 'with selected': 0, 'U/L-only': 0}
    ex = []
    for w in range(3):
        T = R[w] & R[w].T
        np.fill_diagonal(T, False)
        xs, ys = np.nonzero(np.triu(T, 1))
        ties['all'] += len(xs)
        for x, y in zip(xs, ys):
            if x in E.sel or y in E.sel:
                ties['with selected'] += 1
                if len(ex) < 6:
                    ex.append('w%d: %s ~ %s  record %s' % (w + 1, I.name(x), I.name(y), I.decode(x, y)))
            if ul_only(I, x, y):
                ties['U/L-only'] += 1
    log('  [%s] single-world ties:' % tag, ties)
    for e in ex:
        log('     ', e)
    # accepted non-guidance records and their realisers
    seen = set()
    cnt = {'accepted non-guidance records': 0, 'no coherent realiser': 0, 'no selected realiser': 0,
           'old side = selected (own records)': 0}
    exn = []
    for w in range(3):
        xs, ys = np.nonzero(R[w] & (st[w] == 2))
        for x, y in zip(xs, ys):
            r = (int(E.rid[x, y]), w)
            if r in seen:
                continue
            seen.add(r)
            cnt['accepted non-guidance records'] += 1
            coh, selr = I.old_side_realisers(x, y)
            if not coh:
                cnt['no coherent realiser'] += 1
                if len(exn) < 4:
                    exn.append('w%d: %s  (pair %s -> %s)' % (w + 1, I.decode(x, y), I.name(x), I.name(y)))
            if not selr:
                cnt['no selected realiser'] += 1
            if x in E.sel:
                cnt['old side = selected (own records)'] += 1
    log('  [%s] acceptances:' % tag, cnt)
    for e in exn:
        log('      e.g.', e)
    # protection
    prot = {}
    forced_only = 0
    free_carried = 0
    for s, nm in zip(E.sel, E.selnames):
        for x in range(n):
            if x == s:
                continue
            ref = [w for w in range(3) if not R[w][x, s]]
            k = len(ref)
            key = (nm, 'coh' if I.coh[x] else 'inc', k)
            prot[key] = prot.get(key, 0) + 1
            if k and all(st[w][x, s] == -1 for w in ref):
                forced_only += 1
            elif k:
                free_carried += 1
    log('  [%s] protection: (selected, rival class, #refusing worlds X ⪯_i C_a) -> count' % tag)
    for k in sorted(prot):
        log('      ', k, prot[k])
    log('  [%s] rivals protected only by strict-(G) refusals: %d ; by at least one non-guidance refusal: %d'
        % (tag, forced_only, free_carried))


def run(tag, ties, real=None):
    log('== %s  (ties %s, realiser gating %s)' % (tag, 'allowed' if ties else 'FORBIDDEN', real))
    E = sat55.Encoder(inst, ties=ties, real=real)
    E.build_static()
    ok, R = E.solve()
    log('  result:', 'SAT' if ok else 'UNSAT', ' clauses by label:', E.stats, ' vars:', E.nv,
        ' t=%.0fs' % (time.time() - T0))
    if ok:
        a = sat55.audit(E, R)
        log('  independent audit of the full relation over the universe:', a)
        patterns(E, R, tag)
    return E, ok


inst = levels55.make(LEVEL)
log('LEVEL', LEVEL, ': pieces', inst.np, inst.pieces)
log('  certificate cells', inst.cc)
log('  universe models', inst.n, ' coherent among them:', int(inst.coh.sum()),
    [inst.name(i) for i in np.nonzero(inst.coh)[0]])
E1, ok1 = run('V1', True)
log('  lexicographic witness (Theorem L), audited:', sat55.audit(E1, sat55.lexicographic(E1)))
E2, ok2 = run('V2', False)
E3, ok3 = run('V2+REAL(coherent)', False, 'coherent')
E4, ok4 = run('V2+REAL(selected)', False, 'selected')
log('done t=%.0fs' % (time.time() - T0))
