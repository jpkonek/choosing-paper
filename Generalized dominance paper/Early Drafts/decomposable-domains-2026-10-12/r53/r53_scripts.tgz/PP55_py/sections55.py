"""PP55: forced verdicts (backbone) in V1/V2, and what section clauses can add.

Proposition F (PROVED in the note): for ANY priority order on all pieces (active pieces and non-active
cells), the lexicographic relation satisfies every V1 and V2 clause.  Hence a non-guidance verdict
[X ⪯_w Y] (record mixed at w) is never forced: putting first a piece of the record where X is better
at w gives a solution that accepts it, and a piece where X is worse gives one that refuses it.
This script CHECKS the ingredients exactly on the level-LEVEL universe:
  (1) audits Proposition F for several priority orders, including outside-cells-first orders;
  (2) for every non-guidance literal on a selected model's record, exhibits both witness orders and
      confirms (directly from the two audited relations' definition) that they disagree on it.
Usage: python3 -B sections55.py LEVEL"""
import sys, os, time, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import levels55, sat55

LEVEL = int(sys.argv[1]) if len(sys.argv) > 1 else 0
T0 = time.time()
inst = levels55.make(LEVEL)
E = sat55.Encoder(inst, ties=True)
allp = [('a', p) for p in range(inst.np)] + [('o', c) for c in inst.nonact]
rnd = random.Random(5)
print('LEVEL', LEVEL, ' pieces in priority orders:', len(allp), flush=True)
for t in range(4):
    pr = list(allp)
    rnd.shuffle(pr)
    if t == 1:   # outside cells first
        pr = [x for x in pr if x[0] == 'o'] + [x for x in pr if x[0] == 'a']
    R = sat55.lexicographic_full(E, pr)
    print('  audit, priority order %d (%s):' % (t, 'outside first' if t == 1 else 'random'), sat55.audit(E, R),
          ' t=%.0fs' % (time.time() - T0), flush=True)
# (2) per-literal witnesses
n = inst.n
cnt = 0
bad = 0
for s in E.sel:
    for x in range(n):
        if x == s:
            continue
        for (i, j) in ((s, x), (x, s)):
            for w in range(3):
                if E.status[w, i, j] != 2:
                    continue
                cnt += 1
                (ai, oi), (aj, oj) = inst.models[i], inst.models[j]
                better = worse = False
                for p in range(inst.np):
                    if ai[p] != aj[p]:
                        b = inst.rk[w, p, ai[p]] < inst.rk[w, p, aj[p]]
                        better |= b
                        worse |= not b
                if oi != oj:
                    k1, k2 = 'ABD'.index(oi), 'ABD'.index(oj)
                    nw, nb = inst.out_cnt[k1, k2, w]
                    better |= nw > 0
                    worse |= nb > 0
                if not (better and worse):
                    bad += 1
print('non-guidance literals on selected models\' records:', cnt,
      '; each has a piece where the old side is better at w and one where it is worse:', bad == 0)
print('=> no such literal is forced in V1 or V2 (Proposition F with the two witness orders).')
print('done t=%.0fs' % (time.time() - T0))
