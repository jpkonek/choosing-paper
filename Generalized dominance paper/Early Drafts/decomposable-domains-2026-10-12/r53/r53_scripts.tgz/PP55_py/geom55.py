"""PP55 geometry (exact, Fractions only).

Kink triple at eps = 3/10:  A = u, B = (406,421,373)/1200, D = (406,373,421)/1200.
Posterior model C_a = D_{M_a}; C_a answers h iff (a o m_v).h > 0, v = 1,2,3.

Cells: open full-dimensional cones of the central arrangement of the 13 planes
   (a o m_v)^perp (9 planes), e_w^perp (3), (1,1,1)^perp (1),
taken modulo sign (representative g with sum(g) > 0).  On each cell every model's
advice and the sign pattern of g are constant.  Each cell is an actual open cone,
hence an actual positive-measure set for the Gaussian measure.

Advice alphabet on a cell with canonical representative g (sum g > 0):
   'P' = answer h = g,  'N' = answer -g,  'S' = silent,  'C' = contradictory.
Ranks at world w: correct 0 < silent 1 < wrong 2 < contradictory 3;
'P' is correct at w iff g_w > 0 (never 0 on an open cell).

Coherent cell-measurable models.  Lemma (PROVED in PP55 section 1): a coherent model D_K
(K nonempty, closed, convex, in the simplex) whose advice is a.e. constant on every cell
has K = conv(S) for a nonempty subset S of the 13 (normalised) plane normals, all of which
are positive vectors.  So the catalogue below is the complete list of coherent models that
are constant on cells.  A model that is not a.e. conic (differs between two radial pieces
of one cell) is incoherent, because coherent models are conic.  A model that differs
between the two sides of an angular split plane with a mixed-sign normal is incoherent,
because that plane is not p^perp for any p in the simplex.
"""
from fractions import Fraction as Fr
import itertools

EPS = Fr(3, 10)
U = (Fr(1, 3),) * 3
B = tuple(Fr(x, 1200) for x in (406, 421, 373))
D = tuple(Fr(x, 1200) for x in (406, 373, 421))
KINK = [U, B, D]
NAMES = ['A', 'B', 'D']


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def sgn(x):
    return (x > 0) - (x < 0)


def had(a, b):
    return tuple(x * y for x, y in zip(a, b))


def mverts(eps=EPS):
    c = (1 - eps) / 3
    return [tuple(c + (eps if i == j else 0) for j in range(3)) for i in range(3)]


def normals(models, eps=EPS):
    ns = [had(a, m) for a in models for m in mverts(eps)]
    ns += [tuple(Fr(int(i == w)) for i in range(3)) for w in range(3)]
    ns.append((Fr(1), Fr(1), Fr(1)))
    return ns


def signvec(ns, g):
    return tuple(sgn(dot(n, g)) for n in ns)


def cells(models, eps=EPS):
    """One exact interior point per cell (canonical: sum > 0). Same method as PP51 post51."""
    ns = normals(models, eps)
    found = {}
    for i, j in itertools.combinations(range(len(ns)), 2):
        r0 = cross(ns[i], ns[j])
        if r0 == (0, 0, 0):
            continue
        for r in (r0, tuple(-x for x in r0)):
            through = [k for k in range(len(ns)) if dot(ns[k], r) == 0]
            ds = [cross(ns[k], r) for k in through]
            ds = [d for d in ds if d != (0, 0, 0)]
            for P, Q in itertools.combinations(range(len(ds)), 2):
                for s1, s2 in itertools.product((1, -1), repeat=2):
                    d = tuple(s1 * ds[P][q] + s2 * ds[Q][q] for q in range(3))
                    if d == (0, 0, 0):
                        continue
                    eta = Fr(1, 8)
                    g = None
                    while eta > Fr(1, 2 ** 60):
                        cand = tuple(r[q] + eta * d[q] for q in range(3))
                        sv = signvec(ns, cand)
                        if 0 not in sv and all(sv[k] == sgn(dot(ns[k], r)) for k in range(len(ns)) if k not in through):
                            g = cand
                            break
                        eta /= 2
                    if g is None:
                        continue
                    if sum(g) < 0:
                        g = tuple(-x for x in g)
                    sv = signvec(ns, g)
                    if sv not in found:
                        found[sv] = g
    # deterministic order
    return [found[k] for k in sorted(found)]


def advice_K(verts, g):
    """Advice of D_K, K = conv(verts), at canonical g: 'P','N','S' (exact)."""
    vals = [dot(p, g) for p in verts]
    if min(vals) > 0:
        return 'P'
    if max(vals) < 0:
        return 'N'
    return 'S'


def advice_post(a, g, eps=EPS):
    return advice_K([had(a, m) for m in mverts(eps)], g)


RANK = {}
for corr in (True, False):
    RANK[corr] = {'P': 0 if corr else 2, 'N': 2 if corr else 0, 'S': 1, 'C': 3}


def rank(adv, g, w):
    """rank at world w of advice adv on the cell with canonical representative g."""
    return RANK[g[w] > 0][adv]


def coherent_catalogue(gs, models, eps=EPS):
    """All advice patterns on the cells of D_conv(S), S a nonempty subset of the normals."""
    ns = normals(models, eps)
    cat = set()
    n = len(ns)
    # precompute dot signs
    sg = [[sgn(dot(p, g)) for g in gs] for p in ns]
    for mask in range(1, 1 << n):
        idx = [k for k in range(n) if mask >> k & 1]
        pat = []
        for c in range(len(gs)):
            vals = [sg[k][c] for k in idx]
            if min(vals) > 0:
                pat.append('P')
            elif max(vals) < 0:
                pat.append('N')
            else:
                pat.append('S')
        cat.add(''.join(pat))
    return cat


if __name__ == '__main__':
    gs = cells(KINK)
    print('cells', len(gs))
