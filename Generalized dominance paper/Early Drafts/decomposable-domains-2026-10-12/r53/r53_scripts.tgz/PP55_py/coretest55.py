"""PP55: clause-level core for 'A ⪯_w A[U∪L -> S] at every world' at level 0 (V1)."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import levels55, sat55
inst = levels55.make(0)
E = sat55.Encoder(inst, ties=True, keep=True); E.build_static(); E.solve()
U, L = inst.cc['U'], inst.cc['L']
sA = inst.sel['A']; avA, oA = inst.models[sA]
av = list(avA)
for p, (c, lab) in enumerate(inst.pieces):
    if c in (U, L):
        av[p] = levels55.I55.VAL['S']
x = inst.index[(tuple(int(t) for t in av), oA)]
lits = [E.lit(sA, x, w) for w in range(3)]
print('X =', inst.name(x), ' record', inst.decode(sA, x))
ok, _ = E.solve(assumptions=lits)
print('V1 with A ⪯_w X at all w:', 'SAT' if ok else 'UNSAT')
core = sat55.clause_core(E, lits)
for cl, lab, info in core:
    desc = info
    if lab in ('DCI', 'UND', 'DEF', 'DCC'):
        desc = (info[0], inst.name(info[1])) + tuple(info[2:])
    print('  core clause', lab, desc, cl)
    if lab == 'DCI':
        y = info[1]; s = inst.sel[info[0]]
        print('     rival', inst.name(y), 'coherent:', bool(inst.coh[y]), ' record', inst.decode(y, s),
              ' same record as A -> X:', E.rid[y, s] == E.rid[sA, x])
