"""PP55: clause-level core for the joint single-world ties at level 1 (ties55_L1: UNSAT, assumption core 2)."""
import sys, os, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import levels55, sat55
inst = levels55.make(1)
E = sat55.Encoder(inst, ties=True, keep=True); E.build_static(); E.solve()
U, L = inst.cc['U'], inst.cc['L']
sA = inst.sel['A']; avA, oA = inst.models[sA]
upi = [p for p, (c, lab) in enumerate(inst.pieces) if c == U]
lpi = [p for p, (c, lab) in enumerate(inst.pieces) if c == L]
for w in range(3):
    lits = []; who = {}
    for ku in range(1, 3):
        for EU in itertools.combinations(upi, ku):
            for kl in range(1, 3):
                for EL in itertools.combinations(lpi, kl):
                    for v in 'SN':
                        av = list(avA)
                        for p in EU + EL:
                            av[p] = levels55.I55.VAL[v]
                        x = inst.index[(tuple(int(t) for t in av), oA)]
                        for (i, j) in ((sA, x), (x, sA)):
                            l = E.lit(i, j, w)
                            if l not in (True, False):
                                lits.append(l); who[l] = (i, j)
    ok, _ = E.solve(assumptions=lits)
    core = E.S.get_core()
    print('w%d joint ties: %s; assumption core:' % (w + 1, 'SAT' if ok else 'UNSAT'))
    for l in core:
        i, j = who[l]
        print('    [%s ⪯_%d %s]  record %s' % (inst.name(i), w + 1, inst.name(j), inst.decode(i, j)))
    cc = sat55.clause_core(E, core)
    for cl, lab, info in cc:
        d = info
        if lab == 'TC':
            x, y, z, ww = info
            d = '%s -> %s -> %s -> (back), w%d; links %s | %s | %s' % (inst.name(x), inst.name(y), inst.name(z), ww + 1,
                                                       inst.decode(x, y), inst.decode(y, z), inst.decode(z, x))
        print('    core clause', lab, d)
