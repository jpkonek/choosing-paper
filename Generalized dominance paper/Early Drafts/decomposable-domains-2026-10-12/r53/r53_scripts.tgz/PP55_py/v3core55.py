"""PP55 V3: exact core of the gate-derived system (PP50 Lemma 6.1 form), and its tie variants.

System (Lemma 6.1, PROVED in PP50; constants absorbed): unknown effective weights nu^N > 0 (N = A,B,D)
and, per disagreement cell c, a vector w_c in the open orthant O_s (w_v > 0 where h is wrong, < 0 where
h is right) with   nu^H . w_c < 0  for answerers H,   nu^Q . w_c > 0  for silent Q.
Group ('SEP', N, c) = the inequality for model N on cell c.  A 'weak' group uses <= / >=.

UNSAT certificates are the Thm 5.1 argument (re-derived in section 3 of the note), checked mechanically:
  (K1) cells U and L with A answering alone, B and D silent, h wrong only at world i (U) / right only at i (L);
  (K2) strict pair inequalities  max_{W} r > min_{R} r  derived from included pair groups (r = log nu^A/nu^X,
       W = worlds where X's advice is worse), which force, over all 13 weak orders, z^B_j >= z^A_j >= z^D_j
       (or the reverse) for some j != i.
  Strictness bookkeeping: the K1 chain needs, on each of U and L, A strict OR (B and D strict);
  each pair inequality needs at least one of its two groups strict.
SAT witnesses: random search over nu, one LP per cell (scipy, proposes), then exact Fraction verification.
"""
import sys, os, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import linprog
import levels55

NM = ('A', 'B', 'D')


def setup():
    inst = levels55.make(0, outside=('A', 'B', 'D'))
    dis = [c for c in range(inst.ncell) if len({inst.pat[n][c] for n in NM}) > 1]
    return inst, dis


# ---------- exact SAT side ----------
def cell_lp(inst, c, nus, groups, weak):
    """find w in O_s satisfying the included groups at cell c for the given float nus; returns w or None."""
    g = inst.gs[c]
    sgn = [1 if g[v] < 0 else -1 for v in range(3)]   # required sign of w_v
    A_ub, b_ub = [], []
    mg = 1e-3
    for v in range(3):          # sgn_v w_v >= mg
        row = [0.0] * 3
        row[v] = -sgn[v]
        A_ub.append(row); b_ub.append(-mg)
    for N in NM:
        if ('SEP', N, c) not in groups:
            continue
        nu = nus[N]
        m = 0.0 if (N, c) in weak else mg
        if inst.pat[N][c] == 'P':     # nu.w <= -m
            A_ub.append(list(nu)); b_ub.append(-m)
        else:                          # nu.w >= m
            A_ub.append([-x for x in nu]); b_ub.append(-m)
    res = linprog([0, 0, 0], A_ub=A_ub, b_ub=b_ub, bounds=[(-10, 10)] * 3, method='highs')
    return res.x if res.status == 0 else None


def exact_ok(inst, c, nus, w, groups, weak):
    g = inst.gs[c]
    if any((w[v] > 0) != (g[v] < 0) or w[v] == 0 for v in range(3)):
        return False
    for N in NM:
        if ('SEP', N, c) not in groups:
            continue
        val = sum(nus[N][v] * w[v] for v in range(3))
        wk = (N, c) in weak
        if inst.pat[N][c] == 'P':
            if not (val <= 0 if wk else val < 0):
                return False
        else:
            if not (val >= 0 if wk else val > 0):
                return False
    return True


def find_sat(inst, cells, groups, weak=(), tries=4000, seed=1):
    rnd = random.Random(seed)
    for t in range(tries):
        nus = {N: (1.0, float(np.exp(rnd.uniform(-3, 3))), float(np.exp(rnd.uniform(-3, 3)))) for N in NM}
        if t % 3 == 0:     # also try near-likelihood weights
            nus = {N: (1.0, float(np.exp(rnd.gauss(0, .3))), float(np.exp(rnd.gauss(0, .3)))) for N in NM}
        ws = {}
        ok = True
        for c in cells:
            w = cell_lp(inst, c, nus, groups, weak)
            if w is None:
                ok = False
                break
            ws[c] = w
        if not ok:
            continue
        nq = {N: tuple(Fr(x).limit_denominator(10 ** 6) for x in nus[N]) for N in NM}
        wq = {c: tuple(Fr(float(x)).limit_denominator(10 ** 6) for x in ws[c]) for c in cells}
        if all(exact_ok(inst, c, nq, wq[c], groups, weak) for c in cells):
            return nq, wq
    return None


# ---------- exact UNSAT side (Thm 5.1 checker) ----------
WORDERS = []
for r in itertools.product(range(3), repeat=3):
    if sorted(set(r)) == list(range(len(set(r)))):
        WORDERS.append(r)          # 13 weak orders as rank vectors (values comparable)


def pair_constraints(inst, groups, weak, X):
    """strict constraints max_W r > min_R r, r = log nu^A/nu^X, from included cells."""
    cons = []
    for (_, N, c) in groups:
        if N != 'A':
            continue
        if ('SEP', X, c) not in groups:
            continue
        pa, px = inst.pat['A'][c], inst.pat[X][c]
        if pa == px:
            continue
        if (('A', c) in weak) and ((X, c) in weak):
            continue      # both weak: no strict inequality
        g = inst.gs[c]
        cor = [v for v in range(3) if g[v] > 0]
        wr = [v for v in range(3) if g[v] < 0]
        W = cor if pa == 'P' else wr      # worlds where X is worse
        R = wr if pa == 'P' else cor
        cons.append((tuple(W), tuple(R), c))
    return cons


def forced(cons, i, j):
    """all weak orders r satisfying cons have r_i >= r_j ?"""
    for r in WORDERS:
        if all(max(r[v] for v in W) > min(r[v] for v in R) for (W, R, c) in cons):
            if not r[i] >= r[j]:
                return False
    return True


def unsat_cert(inst, groups, weak=()):
    """Return a description if the Thm 5.1 argument applies to the included groups, else None."""
    cc = inst.cc
    U, L = cc['U'], cc['L']
    if not all(('SEP', N, c) in groups for N in NM for c in (U, L)):
        return None
    for c in (U, L):
        if ('A', c) in weak and (('B', c) in weak or ('D', c) in weak):
            return None
    i = 0      # lone world 1 (index 0) for this instance (checked: U wrong only at 1, L right only at 1)
    consB = pair_constraints(inst, groups, weak, 'B')
    consD = pair_constraints(inst, groups, weak, 'D')
    for j in (1, 2):
        # z^B_j >= z^A_j  <=>  rAB_i >= rAB_j ;  z^A_j >= z^D_j  <=>  rAD_j >= rAD_i
        if forced(consB, i, j) and forced(consD, j, i):
            return ('betweenness in coordinate %d: z^B >= z^A >= z^D' % (j + 1), consB, consD)
        if forced(consB, j, i) and forced(consD, i, j):
            return ('betweenness in coordinate %d: z^D >= z^A >= z^B' % (j + 1), consB, consD)
    return None


def main():
    inst, dis = setup()
    cc = inst.cc
    print('certificate cells', cc)
    U, L = cc['U'], cc['L']
    g = inst.gs
    print('U: A answers alone, h wrong only at world 1:', [inst.pat[N][U] for N in NM], [g[U][v] > 0 for v in range(3)])
    print('L: A answers alone, h right only at world 1:', [inst.pat[N][L] for N in NM], [g[L][v] > 0 for v in range(3)])
    allg = {('SEP', N, c) for N in NM for c in dis}
    print('\n(1) full V3 system on all %d disagreement cells:' % len(dis))
    cert = unsat_cert(inst, allg)
    print('    Thm 5.1 checker:', 'UNSAT certificate' if cert else 'no certificate', cert[0] if cert else '')
    # deletion-minimal core
    core = sorted(allg)
    for k in list(core):
        trial = [x for x in core if x != k]
        if unsat_cert(inst, set(trial)):
            core = trial
    print('\n(2) deletion-minimal core (every removal re-checked):', len(core), 'groups')
    for k in core:
        c = k[2]
        cor = [v + 1 for v in range(3) if g[c][v] > 0]
        print('    ', k, 'advice A,B,D =', [inst.pat[N][c] for N in NM], 'right at', cor,
              '[%s]' % next((nm for nm, cc_ in cc.items() if cc_ == c), 'other'))
    cert = unsat_cert(inst, set(core))
    print('    certificate:', cert[0])
    print('    derived AB inequalities:', [(W, R) for (W, R, c) in cert[1]])
    print('    derived AD inequalities:', [(W, R) for (W, R, c) in cert[2]])
    print('\n(3) minimality: exact SAT witness for core minus each group')
    cells = sorted({k[2] for k in core})
    allmin = True
    for k in core:
        trial = set(core) - {k}
        sol = find_sat(inst, cells, trial)
        print('    minus', k, ':', 'SAT (exact witness)' if sol else 'no witness found')
        allmin &= bool(sol)
    print('    core is minimal (all removals SAT, exact):', allmin)
    # tie variants (PP51's stated gap)
    print('\n(4) tie variants on the two certificate cells (the PP51 gap)')
    for label, weak in (
            ('T weak on U and L; B, D strict; CG2 non-strict (absorbed)', {('A', U), ('A', L)}),
            ('T and B weak on U and L; D strict', {('A', U), ('A', L), ('B', U), ('B', L)}),
            ('T and D weak on U and L; B strict', {('A', U), ('A', L), ('D', U), ('D', L)}),
            ('A, B, D all weak on U and L', {(N, c) for N in NM for c in (U, L)}),
            ('A, B, D all weak on U only', {(N, U) for N in NM}),
            ('A, B, D all weak on L only', {(N, L) for N in NM}),
    ):
        cert = unsat_cert(inst, allg, weak)
        sol = None if cert else find_sat(inst, dis, allg, weak, tries=3000)
        print('    %-58s: %s' % (label, 'UNSAT (Thm 5.1 certificate)' if cert else
                                   ('SAT (exact witness on all 32 cells)' if sol else 'OPEN (no certificate, no witness)')))
        if sol:
            nus, ws = sol
            print('        nu =', {N: tuple(str(x) for x in nus[N]) for N in NM})
            for c in (U, L):
                vals = {N: sum(nus[N][v] * ws[c][v] for v in range(3)) for N in NM}
                print('        cell', c, 'nu.w =', {N: str(vals[N]) for N in NM})


if __name__ == '__main__':
    main()
