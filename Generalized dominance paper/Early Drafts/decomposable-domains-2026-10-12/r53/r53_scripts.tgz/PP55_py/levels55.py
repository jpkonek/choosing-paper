"""Instance levels for PP55."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import inst55 as I55

def cert_cells(inst):
    ci = I55.cell_ids(inst)
    pick = lambda t: ci[t][0]
    return {
        'U':   pick(('P', 'S', 'S', (1, 2))),   # A alone, wrong only at world 1 ("above")
        'L':   pick(('P', 'S', 'S', (0,))),     # A alone, right only at world 1 ("below")
        'AB3': pick(('P', 'S', 'P', (2,))),     # AB worse-set {3}
        'AB13': pick(('P', 'S', 'P', (0, 2))),  # AB worse-set {1,3}
        'AD2': pick(('P', 'P', 'S', (1,))),     # AD worse-set {2}
        'AD12': pick(('P', 'P', 'S', (0, 1))),  # AD worse-set {1,2}
    }

def make(level, outside=('A', 'B', 'D')):
    base = I55.Instance([], {}, {}, outside=('A', 'B', 'D'))   # geometry only
    cc = cert_cells(base)
    U, L = cc['U'], cc['L']
    others = [cc['AB3'], cc['AB13'], cc['AD2'], cc['AD12']]
    if level == 0:
        act = [U, L] + others
        alph = {c: 'PSN' for c in act}
        spl = {}
    elif level == 1:
        act = [U, L] + others
        alph = {c: ('PSN' if c in (U, L) else 'PS') for c in act}
        spl = {U: ['in', 'out'], L: ['in', 'out']}
    elif level == 2:
        act = [U, L, cc['AB13'], cc['AD12']]          # the cells of the minimal V3 core
        alph = {c: 'PS' for c in act}
        spl = {U: ['in+', 'in-', 'out+', 'out-'], L: ['in+', 'in-', 'out+', 'out-']}
    elif level == 3:
        act = [U, L]
        alph = {c: 'PSN' for c in act}
        spl = {U: ['in+', 'in-', 'out+', 'out-'], L: ['in+', 'in-', 'out+', 'out-']}
    inst = I55.Instance(act, alph, spl, outside=outside)
    inst.cc = cc
    return inst
