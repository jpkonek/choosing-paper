"""PP55 SAT encoding of the axioms on a finite instance, with lazy (TC) and lazy tie bans.

Variables: one boolean per (record, world)  =  [X ⪯_w Y] for every pair with rec(X,Y) = record.
(IB) is therefore built in: a variable is indexed by the record, not by the pair.

Clause families (each clause carries its label):
  G+      weak guidance: a record that is a weak worsening at w is accepted (constant TRUE)
  G-      strict (G): a nontrivial pure improvement at w is refused (constant FALSE)
  TC      (a∧b∧c) ⇒ reverse, for every accepted directed triangle X→Y→Z→X, each reverse
  DEF     support defence of selected C_a against every rival X: OR_{i in supp a} [C_a ⪯_i X]
  UND     undominatedness: (B1∧B2∧B3) ⇒ A_j,  A_i=[C_a ⪯_i X], B_i=[X ⪯_i C_a]
  DCI     direct (C), incoherent X: ¬(B1∧B2∧B3)
  DCC     direct (C), coherent X: (B1∧B2∧B3) ⇒ A_j   (identical to UND; labelled separately)
  TIE     (V2 only) no single-world tie between distinct models: ¬[X⪯_wY] ∨ ¬[Y⪯_wX]
  REAL    (variant only, not an axiom) refuse every non-guidance record with no realiser
          in a stated class
  FORCE   (experiments) unit clauses stated by the experiment
Reflexivity: identical pairs are status 0 and never become variables (accepted).

TC and TIE are generated lazily: solve, build the full relation (variables at their SAT values,
every other record at its guidance verdict, i.e. non-guidance records with no variable are
refused), find every violated triangle / tie in the WHOLE universe, add those clauses, repeat.
On termination the full relation satisfies every clause family over the whole universe.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from pysat.solvers import Solver

CHUNK = 256


class Encoder:
    def __init__(self, inst, selected=('A', 'B', 'D'), ties=True, real=None, solver='glucose4', keep=False):
        self.I = inst
        self.ties = ties
        self.real = real            # None, 'coherent', or 'selected'
        n = inst.n
        # record index per pair, guidance status per pair
        keys = np.zeros((n, n), dtype=np.int64)
        self.status = np.zeros((3, n, n), dtype=np.int8)
        for s in range(0, n, CHUNK):
            I = np.arange(s, min(n, s + CHUNK))
            k, st = inst.pair_arrays(I, None)
            keys[s:s + len(I)] = k
            self.status[:, s:s + len(I)] = st
        uk, inv = np.unique(keys, return_inverse=True)
        self.rid = inv.reshape(n, n).astype(np.int32)
        del keys
        self.nrec = len(uk)
        # one representative pair per record (for decoding)
        flat = np.arange(n * n)
        first = np.full(self.nrec, -1, dtype=np.int64)
        first[self.rid.ravel()[::-1]] = flat[::-1]
        self.rep = first
        self.var = np.zeros(self.nrec, dtype=np.int64)    # base var id (0: none)
        self.nv = 0
        self.clauses = []       # (clause, label)
        self.S = Solver(name=solver)
        self.sel = [inst.sel[s] for s in selected]
        self.selnames = list(selected)
        self.realcache = {}
        self.keep = keep
        self.stats = {}

    # ----- literals -----
    def lit(self, i, j, w):
        """literal for [model i ⪯_w model j]; returns True/False for constants."""
        st = self.status[w, i, j]
        if st == 0 or st == 1:
            return True
        if st == -1:
            return False
        r = self.rid[i, j]
        if self.var[r] == 0:
            self.var[r] = self.nv + 1
            self.nv += 3
            if self.real is not None:
                self._real_clauses(r)
        return int(self.var[r] + w)

    def _real_clauses(self, r):
        p = self.rep[r]
        i, j = divmod(int(p), self.I.n)
        coh, selr = self.I.old_side_realisers(i, j)
        ok = coh if self.real == 'coherent' else bool(selr)
        if not ok:
            for w in range(3):
                if self.status[w, i, j] == 2:
                    self.add([-int(self.var[r] + w)], 'REAL', (i, j, w))

    def add(self, lits, label, info=None):
        cl = []
        for l in lits:
            if l is True:
                return
            if l is False:
                continue
            cl.append(l)
        if not cl:
            raise RuntimeError('empty clause from %s %s' % (label, info))
        cl = sorted(set(cl))
        if self.keep:
            self.clauses.append((cl, label, info))
        self.S.add_clause(cl)
        self.stats[label] = self.stats.get(label, 0) + 1

    @staticmethod
    def neg(l):
        if l is True:
            return False
        if l is False:
            return True
        return -l

    # ----- static clause families -----
    def build_static(self):
        I = self.I
        for a, s in zip(self.selnames, self.sel):
            for x in range(I.n):
                if x == s:
                    continue
                A = [self.lit(s, x, w) for w in range(3)]
                Bv = [self.lit(x, s, w) for w in range(3)]
                self.add(A, 'DEF', (a, x))
                nb = [self.neg(b) for b in Bv]
                if I.coh[x]:
                    for w in range(3):
                        self.add(nb + [A[w]], 'UND', (a, x, w))
                        self.add(nb + [A[w]], 'DCC', (a, x, w))
                else:
                    for w in range(3):
                        self.add(nb + [A[w]], 'UND', (a, x, w))
                    self.add(nb, 'DCI', (a, x))

    # ----- full relation -----
    def relation(self, model):
        vals = np.zeros(self.nv + 1, dtype=bool)
        pos = np.array([l for l in model if 0 < l <= self.nv], dtype=np.int64)
        vals[pos] = True
        R = []
        for w in range(3):
            st = self.status[w]
            vr = self.var[self.rid]
            acc = (st == 0) | (st == 1) | ((st == 2) & (vr > 0) & vals[np.where(vr > 0, vr + w, 0)])
            R.append(acc)
        return R

    def violations(self, R, cap=200000):
        n = self.I.n
        new = 0
        for w in range(3):
            Rw = R[w].copy()
            np.fill_diagonal(Rw, False)
            Rf = Rw.astype(np.float32)
            P = Rf @ Rf                      # P[x,z] = #y with x->y->z
            T = (P > 0) & Rw.T               # and z->x
            xs, zs = np.nonzero(T)
            for x, z in zip(xs, zs):
                ys = np.nonzero(Rw[x] & Rw[:, z])[0]
                for y in ys:
                    if y == x or y == z:
                        continue
                    if R[w][y, x] and R[w][z, y] and R[w][x, z]:
                        continue
                    a, b, c = self.lit(x, y, w), self.lit(y, z, w), self.lit(z, x, w)
                    for r in (self.lit(y, x, w), self.lit(z, y, w), self.lit(x, z, w)):
                        self.add([self.neg(a), self.neg(b), self.neg(c), r], 'TC', (x, y, z, w))
                    new += 1
                    if new >= cap:
                        return new
            if not self.ties:
                tie = Rw & Rw.T
                xs, ys = np.nonzero(np.triu(tie, 1))
                for x, y in zip(xs, ys):
                    self.add([self.neg(self.lit(x, y, w)), self.neg(self.lit(y, x, w))], 'TIE', (x, y, w))
                    new += 1
        return new

    def solve(self, assumptions=(), maxit=200, verbose=False):
        it = 0
        while True:
            ok = self.S.solve(assumptions=list(assumptions))
            if not ok:
                return False, None
            model = self.S.get_model()
            R = self.relation(model)
            nv = self.violations(R)
            it += 1
            if verbose:
                print('   iter', it, 'new clauses', nv, 'vars', self.nv, flush=True)
            if nv == 0:
                self.R = R
                self.model = model
                return True, R
            if it >= maxit:
                raise RuntimeError('no convergence')


def audit(E, R):
    """Independent check of a full relation R (list of 3 boolean n x n arrays) against every
    clause family over the whole universe.  Returns violation counts."""
    I = E.I
    n = I.n
    out = {}
    st = E.status
    # reflexivity / weak guidance / strict (G)
    out['REFL'] = int(sum((~np.diag(R[w])).sum() for w in range(3)))
    out['G+'] = int(sum(((st[w] == 1) & ~R[w]).sum() for w in range(3)))
    out['G-'] = int(sum(((st[w] == -1) & R[w]).sum() for w in range(3)))
    # (IB): verdict is a function of the record
    ib = 0
    for w in range(3):
        acc = np.zeros(E.nrec, dtype=np.int8)
        rej = np.zeros(E.nrec, dtype=np.int8)
        np.maximum.at(acc, E.rid.ravel(), R[w].ravel().astype(np.int8))
        np.maximum.at(rej, E.rid.ravel(), (~R[w]).ravel().astype(np.int8))
        ib += int((acc & rej).sum())
    out['IB'] = ib
    # TC: accepted triangle with a missing reverse
    tc = 0
    for w in range(3):
        Rw = R[w].copy()
        np.fill_diagonal(Rw, False)
        Rf = Rw.astype(np.float32)
        P = Rf @ Rf
        xs, zs = np.nonzero((P > 0) & Rw.T)
        for x, z in zip(xs, zs):
            for y in np.nonzero(Rw[x] & Rw[:, z])[0]:
                if y in (x, z):
                    continue
                if not (R[w][y, x] and R[w][z, y] and R[w][x, z]):
                    tc += 1
    out['TC'] = tc
    d = u = dci = 0
    for s in E.sel:
        for x in range(n):
            if x == s:
                continue
            A = [R[w][s, x] for w in range(3)]
            Bv = [R[w][x, s] for w in range(3)]
            if not any(A):
                d += 1
            if all(Bv) and not all(A):
                u += 1
            if all(Bv) and not I.coh[x]:
                dci += 1
    out['DEF'] = d
    out['UND'] = u
    out['DCI'] = dci
    ties = 0
    for w in range(3):
        T = R[w] & R[w].T
        np.fill_diagonal(T, False)
        ties += int(T.sum() // 2)
    out['single-world ties'] = ties
    return out


def lexicographic(E, order=None):
    """Theorem L relation: X ⪯_w Y iff X = Y, or on the first piece (in a fixed priority order)
    where X and Y differ, X's advice has smaller rank at w.  Pieces: active pieces, then the
    non-active cells (each a single piece)."""
    I = E.I
    n = I.n
    ap = list(range(I.np)) if order is None else list(order)
    R = []
    # top piece among active pieces
    Mx = I.M.astype(np.int64)
    for w in range(3):
        acc = np.zeros((n, n), dtype=bool)
        decided = np.zeros((n, n), dtype=bool)
        for p in ap:
            xv = Mx[:, p][:, None]
            yv = Mx[:, p][None, :]
            dif = (xv != yv) & ~decided
            rx = I.rk[w, p][xv]
            ry = I.rk[w, p][yv]
            acc |= dif & (rx < ry)
            decided |= dif
        # outside part: first non-active cell (in index order) where outside labels differ
        for i1 in range(3):
            for i2 in range(3):
                if i1 == i2:
                    continue
                cl = I.out_cells[(i1, i2)]
                c = cl[0]
                o1, o2 = ['A', 'B', 'D'][i1], ['A', 'B', 'D'][i2]
                better = __import__('geom55').rank(I.pat[o1][c], I.gs[c], w) < __import__('geom55').rank(I.pat[o2][c], I.gs[c], w)
                mask = (~decided) & (I.O[:, None] == i1) & (I.O[None, :] == i2)
                acc |= mask & better
        np.fill_diagonal(acc, True)
        R.append(acc)
    return R


def clause_core(E, assumptions, minimise=True):
    """Clause-level core of an UNSAT-under-assumptions result: every clause gets a selector;
    deletion-minimised.  Returns list of (clause, label, info)."""
    from pysat.solvers import Solver as S2
    base = E.nv + 10
    sels = []
    s = S2(name='glucose4')
    for k, (cl, lab, info) in enumerate(E.clauses):
        sel = base + k
        s.add_clause(cl + [-sel])
        sels.append(sel)
    ok = s.solve(assumptions=list(assumptions) + sels)
    assert not ok
    core = [x for x in s.get_core() if x >= base]
    if minimise:
        i = 0
        while i < len(core):
            trial = core[:i] + core[i + 1:]
            if not s.solve(assumptions=list(assumptions) + trial):
                core = [x for x in s.get_core() if x >= base]
                i = 0 if len(core) < len(trial) else i
                if len(core) >= len(trial):
                    core = trial
            else:
                i += 1
    return [E.clauses[x - base] for x in core]


def lexicographic_full(E, prio):
    """Proposition F relation for an arbitrary priority order over ALL pieces: prio is a list of
    ('a', p) (active piece p) and ('o', c) (non-active cell c).  X ⪯_w Y iff X = Y or, at the first
    piece in prio where X and Y differ, X has the smaller rank at w."""
    import geom55 as G
    I = E.I
    n = I.n
    Mx = I.M.astype(np.int64)
    O = I.O.astype(np.int64)
    pats = [I.pat[o] for o in ('A', 'B', 'D')]
    R = []
    for w in range(3):
        acc = np.zeros((n, n), dtype=bool)
        decided = np.zeros((n, n), dtype=bool)
        for kind, p in prio:
            if kind == 'a':
                xv = Mx[:, p][:, None]
                yv = Mx[:, p][None, :]
                dif = (xv != yv) & ~decided
                better = I.rk[w, p][xv] < I.rk[w, p][yv]
            else:
                c = p
                adv = np.array([pats[k][c] for k in range(3)])
                rk3 = np.array([G.rank(adv[k], I.gs[c], w) for k in range(3)])
                xv = O[:, None]
                yv = O[None, :]
                dif = (adv[xv] != adv[yv]) & ~decided
                better = rk3[xv] < rk3[yv]
            acc |= dif & better
            decided |= dif
        np.fill_diagonal(acc, True)
        R.append(acc)
    return R
