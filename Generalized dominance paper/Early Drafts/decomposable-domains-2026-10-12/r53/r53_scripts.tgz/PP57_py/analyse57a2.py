"""Window-only records of B (rival = B modified on the Ep/Em twins): the world
installed by the clean closure (order 1,2,3), with guidance status."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from space57 import Space57
from search57 import Search, rivals
from engine21 import inv, mk_rec
S = Space57()
W = ['Epa', 'Epb', 'Ema', 'Emb']
riv = rivals(S, W, {a: (0, 1, 2) for a in W})
sr = Search(S, riv, order=(0, 1, 2)); cl = sr.run()
for m in 'AB':
    M = S.sel[m]
    print(f'--- owner {m}, rivals {m}[window] ---')
    for X, nm in riv.items():
        if X == M or not nm.startswith(m + '['): continue
        r = mk_rec(M, X)
        g = ''.join(str(w+1) if cl.guidance(r, w) else ('x' if cl.improvement(r, w) else '.') for w in range(3))
        inst = ''.join(str(w+1) for w in range(3) if r in cl.inst[w])
        rv = ''.join(str(w+1) for w in range(3) if cl.accepted(inv(r), w))
        print(f'  {cl.rstr(r):55s} guid/imp/free={g}  installed@{inst or "-"}  reverse accepted@{rv or "-"}')
