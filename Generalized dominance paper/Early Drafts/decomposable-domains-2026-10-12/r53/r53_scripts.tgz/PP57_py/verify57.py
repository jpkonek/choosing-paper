"""Independent re-verification of a clean closure from the definitions.
Relation at world w := weak guidance  U  installed records (all common-context
copies, i.e. acceptance depends on the record only).
Checks: (G) no installed record is a weak improvement at its world;
(TC): by PP21 Lemma 2.1 a triangle needs >= 2 installed links, which are then
adjacent; for every ordered pair (r, s) of installed records at w whose copies
compose, if inv(comp(r,s)) is accepted then inv r, inv s, comp(r,s) are accepted
(implemented independently with plain Python loops);
defence: every obligation (M, X) accepted at some world;
protection: for every selected M and rival X != M, rec(X, M) accepted at all
three worlds only if X is coherent and rec(M, X) is accepted at all three worlds."""
import itertools

def _deltas(S, r, w):
    return [S.rank[w][k][v % 4] - S.rank[w][k][v // 4] for k, v in enumerate(r) if v >= 0]

def guid(S, r, w): return all(d >= 0 for d in _deltas(S, r, w))
def improv(S, r, w):
    d = _deltas(S, r, w); return len(d) > 0 and all(x <= 0 for x in d)
def inv(r): return tuple(-1 if v < 0 else (v % 4) * 4 + v // 4 for v in r)
def empty(r): return all(v < 0 for v in r)
def rec(X, Y): return tuple(-1 if a == b else a * 4 + b for a, b in zip(X, Y))

def compose(r, s):
    """copies r: X->Y, s: Y->Z compose iff new(r) = old(s) on the common support"""
    out = []
    for x, y in zip(r, s):
        if x >= 0 and y >= 0 and x % 4 != y // 4: return None
        if x < 0 and y < 0: out.append(-1); continue
        a = x // 4 if x >= 0 else y // 4
        b = y % 4 if y >= 0 else x % 4
        out.append(-1 if a == b else a * 4 + b)
    return tuple(out)

def verify(S, inst, obligations, protected, rivals):
    errs = []
    acc = lambda r, w: empty(r) or r in inst[w] or guid(S, r, w)
    for w in range(3):
        for r in inst[w]:
            if improv(S, r, w): errs.append(('G', w, r))
        L = list(inst[w])
        for r in L:
            for s in L:
                c = compose(r, s)
                if c is None or empty(c): continue
                if acc(inv(c), w) and not (acc(inv(r), w) and acc(inv(s), w) and acc(c, w)):
                    errs.append(('TC', w, r, s))
    for (M, X) in obligations:
        if not any(acc(rec(M, X), w) for w in range(3)): errs.append(('defence', M, X))
    for M in protected:
        for X in rivals:
            if X == M: continue
            if all(acc(rec(X, M), w) for w in range(3)):
                if not S.is_coherent(X) or not all(acc(rec(M, X), w) for w in range(3)):
                    errs.append(('protection', M, X))
    return errs
