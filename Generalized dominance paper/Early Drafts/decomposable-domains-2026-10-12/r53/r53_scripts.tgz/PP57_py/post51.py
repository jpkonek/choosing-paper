"""PP51 library: exact geometry of posterior models near u (Fractions only).

M = c*1 + eps*Delta, vertices m_v = c*1 + eps*e_v, c = (1-eps)/3.
Posterior model C_a = D_{M_a},  M_a = {a o p / (a.p) : p in M}.
C_a answers h  iff  (a o m_v).h > 0 for v = 1,2,3   (vertices of M_a are a o m_v up to scale).
If u lies in every M_a (checked), no two models give opposite answers, and the common
answer at g is h = sign(g1+g2+g3) g.  At a problem h is w-correct iff h_w > 0.

Cells: full-dimensional cones of the arrangement of the planes
    (a o m_v)^perp  (models a, v = 1..3),  e_w^perp (w = 1..3),  (1,1,1)^perp.
On a cell the answer set and the sign pattern of h are constant.  Cells are found exactly:
every cell of a central arrangement in R^3 (with >= 2 independent normals) has a vertex ray
r = n_i x n_j; around r the local sectors are hit by r + eta(s1 d_P + s2 d_Q), d_P = n_P x r.
"""
from fractions import Fraction as Fr
import itertools


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def sgn(x):
    return (x > 0) - (x < 0)


def mverts(eps):
    c = (1 - eps) / 3
    return [tuple(c + (eps if i == j else 0) for j in range(3)) for i in range(3)]


def had(a, b):
    return tuple(x * y for x, y in zip(a, b))


def u_in_Ma(eps, a):
    """u in M_a  iff  p = (1/a)/sum(1/a) lies in M  iff  min p_i >= c."""
    c = (1 - eps) / 3
    inv = [1 / x for x in a]
    s = sum(inv)
    return min(x / s for x in inv) >= c


def answers(eps, a, h):
    return all(dot(had(a, m), h) > 0 for m in mverts(eps))


def advice(eps, a, g):
    """+1 answer g, -1 answer -g, 0 silent (exact)."""
    vals = [dot(had(a, m), g) for m in mverts(eps)]
    if min(vals) > 0:
        return 1
    if max(vals) < 0:
        return -1
    return 0


def normals(eps, models):
    ns = []
    for a in models:
        for m in mverts(eps):
            ns.append(had(a, m))
    for w in range(3):
        ns.append(tuple(Fr(int(i == w)) for i in range(3)))
    ns.append((Fr(1), Fr(1), Fr(1)))
    return ns


def signvec(ns, g):
    return tuple(sgn(dot(n, g)) for n in ns)


def cells(eps, models):
    """Return list of exact interior points g (one per cell, canonical S>0)."""
    ns = normals(eps, models)
    found = {}
    for i, j in itertools.combinations(range(len(ns)), 2):
        r0 = cross(ns[i], ns[j])
        if r0 == (0, 0, 0):
            continue
        for r in (r0, tuple(-x for x in r0)):
            through = [k for k in range(len(ns)) if dot(ns[k], r) == 0]
            ds = [cross(ns[k], r) for k in through]
            ds = [d for d in ds if d != (0, 0, 0)]
            for P, Q in itertools.combinations(range(len(ds)), 2):
                for s1, s2 in itertools.product((1, -1), repeat=2):
                    d = tuple(s1 * ds[P][q] + s2 * ds[Q][q] for q in range(3))
                    if d == (0, 0, 0):
                        continue
                    eta = Fr(1, 8)
                    while True:
                        g = tuple(r[q] + eta * d[q] for q in range(3))
                        sv = signvec(ns, g)
                        okk = 0 not in sv and all(sv[k] == sgn(dot(ns[k], r)) for k in range(len(ns)) if k not in through)
                        if okk:
                            break
                        eta /= 2
                        if eta < Fr(1, 2 ** 60):
                            g = None
                            break
                    if g is None:
                        continue
                    if sum(g) < 0:
                        g = tuple(-x for x in g)
                    sv = signvec(ns, g)
                    if sv not in found:
                        # normalise to a small integer vector for readability
                        found[sv] = g
    return list(found.values())


def cell_type(eps, models, g):
    """(answer set as tuple of model indices, Cor tuple, Wr tuple) for canonical g (S>0, h=g)."""
    h = g
    adv = [advice(eps, a, h) for a in models]
    assert all(x in (0, 1) for x in adv), "opposite answers occurred"
    A = tuple(k for k, x in enumerate(adv) if x == 1)
    cor = tuple(w for w in range(3) if h[w] > 0)
    wr = tuple(w for w in range(3) if h[w] < 0)
    return A, cor, wr


def pair_WR(t, a, b):
    """For cell type t and pair (a,b) disagreeing there: worlds where b is worse / better than a."""
    A, cor, wr = t
    if (a in A) == (b in A):
        return None
    if a in A:      # a answers, b silent: b worse where h correct
        return cor, wr
    return wr, cor  # b answers, a silent: b worse where h wrong


def ratio_gt(a, b, i, j):
    """D_i > D_j with D = log(a/b)  iff  a_i b_j > a_j b_i."""
    return a[i] * b[j] > a[j] * b[i]
