"""Extract the rule behind a clean closure: test candidate 'region priority'
statements on every defence record of the rival class.
  P(R, w): a record whose part on region R is non-null and a weak w-worsening is
           accepted at w (whatever the rest of the record does).
Usage: rule57.py [pickle]  (default: recompute run57a's closure, order 1,2,3)"""
import os, sys, pickle
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from space57 import Space57
from search57 import Search, rivals, greedy
from engine21 import inv, mk_rec
S = Space57()
if len(sys.argv) > 1:
    d = pickle.load(open(sys.argv[1], 'rb'))
    inst = d['inst']; W = d['W']; vals = d['vals']
    riv = rivals(S, W, vals)
else:
    W = ['Epa', 'Epb', 'Ema', 'Emb']; vals = {a: (0, 1, 2) for a in W}
    riv = rivals(S, W, vals)
    sr = Search(S, riv, order=(0, 1, 2)); cl = sr.run(); inst = cl.inst

def deltas(r, w, ks):
    return [S.rank[w][k][r[k] % 4] - S.rank[w][k][r[k] // 4] for k in ks if r[k] >= 0]
def accepted(r, w):
    d = deltas(r, w, range(S.n))
    return all(x >= 0 for x in d) or r in inst[w]

regions = {'Em': [S.idx['Ema'], S.idx['Emb']], 'Ep': [S.idx['Epa'], S.idx['Epb']]}
for nm in S.names:
    if nm[:2] not in ('Ep', 'Em') and S.idx[nm] in [S.idx[a] for a in W]:
        regions[nm] = [S.idx[nm]]
recs = set()
for m in 'ABD':
    for X in riv:
        if X != S.sel[m]: recs.add(mk_rec(S.sel[m], X))
print('defence records examined:', len(recs))
for R, ks in regions.items():
    for w in range(3):
        n = viol = 0
        for r in recs:
            d = deltas(r, w, ks)
            if d and all(x >= 0 for x in d):
                n += 1
                if not accepted(r, w): viol += 1
        print(f'  P({R}, world {w+1}): applicable {n:5d}, violations {viol:5d}  ->', 'HOLDS' if viol == 0 else 'fails')
