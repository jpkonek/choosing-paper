"""PP57 geometry: exact cells of the kink triple (PP51 Thm 5.1 instance), eps = 3/10.
Uses PP51's exact cell enumeration (post51.py, copied unchanged).
Each cell: canonical h (sum>0), advice of A,B,D in {answer, silent}, Wr = worlds where h is wrong."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from post51 import cells, advice

EPS = Fr(3, 10)
MOD = {'A': (Fr(1, 3),) * 3, 'B': (Fr(406, 1200), Fr(421, 1200), Fr(373, 1200)),
       'D': (Fr(406, 1200), Fr(373, 1200), Fr(421, 1200))}
NAMES = ['A', 'B', 'D']

def cell_list():
    out = []
    for g in cells(EPS, [MOD[n] for n in NAMES]):
        adv = {n: advice(EPS, MOD[n], g) for n in NAMES}
        assert all(v in (0, 1) for v in adv.values())
        H = ''.join(n for n in NAMES if adv[n] == 1)
        wr = tuple(w + 1 for w in range(3) if g[w] < 0)
        out.append(dict(g=g, H=H, wr=wr))
    return out

if __name__ == '__main__':
    cl = cell_list()
    types = {}
    for c in cl:
        types.setdefault((c['H'], c['wr']), []).append(c['g'])
    print('cells:', len(cl), ' types (H, Wr):', len(types))
    for k in sorted(types, key=lambda k: (len(k[0]), k)):
        dis = 0 < len(k[0]) < 3
        g = types[k][0]
        print(f"  H={k[0] or '-':4s} Wr={str(list(k[1])):10s} cells={len(types[k]):2d} {'DISAGREE' if dis else 'agree'}  rep g ~ ({float(g[0]):+.4f},{float(g[1]):+.4f},{float(g[2]):+.4f})")
