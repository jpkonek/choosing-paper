"""Runs 1/2 (greedy) with pair cells in the window: Ep, Em twins (values P, N, S)
plus pair cells (values P, S).  Usage: run57b.py <cell1,cell2,...>"""
import os, sys, time, pickle
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from space57 import Space57
from search57 import greedy, rivals
from engine21 import inv
from verify57 import verify
S = Space57()
extra = sys.argv[1].split(',')
W = ['Epa', 'Epb', 'Ema', 'Emb'] + extra
vals = {a: (0, 1, 2) for a in W[:4]}
vals.update({a: (0, 2) for a in extra})
riv = rivals(S, W, vals)
print('window:', W, ' rivals:', len(riv), flush=True)
for noties in (False, True):
    for order in ((0, 1, 2),):
        t = time.time()
        cl, stuck, fails, sr = greedy(S, riv, order=order, noties=noties)
        ties = sum(1 for w in range(3) for r in cl.recs[w] if cl.accepted(inv(r), w))
        errs = verify(S, cl.inst, [(S.sel[m], X) for m, X in sr.obl if (m, X) not in stuck], [S.sel[m] for m in 'ABD'], list(riv))
        print(f"noties={noties} order={[w+1 for w in order]}: stuck={len(stuck)} records/world={cl.stats()['records']} |P|={len(cl.P)} ties={ties} failed options={fails} verify-errors={len(errs)} ({time.time()-t:.0f}s)", flush=True)
        if order == (0, 1, 2):
            pickle.dump({'inst': [dict(d) for d in cl.inst], 'W': W, 'vals': vals, 'stuck': stuck},
                        open(f"sol57b_{'_'.join(extra)}_{int(noties)}.pkl", 'wb'))
