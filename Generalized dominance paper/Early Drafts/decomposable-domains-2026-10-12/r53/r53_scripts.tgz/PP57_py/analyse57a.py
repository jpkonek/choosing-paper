"""Extract the rule behind the clean closure of run57a (window = Ep, Em twins).
For each selected owner and each rival, print the record restricted to the window
(per-atom old>new), its guidance status at each world, and the worlds accepting."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from space57 import Space57
from search57 import Search, rivals
from engine21 import inv, mk_rec
S = Space57()
W = ['Epa', 'Epb', 'Ema', 'Emb']
riv = rivals(S, W, {a: (0, 1, 2) for a in W})
for order in ((0, 1, 2), (1, 2, 0)):
    sr = Search(S, riv, order=order)
    cl = sr.run()
    print(f'=== order {[w+1 for w in order]} ===')
    rows = {}
    for m in 'ABD':
        M = S.sel[m]
        for X in riv:
            if X == M: continue
            r = mk_rec(M, X)
            acc = tuple(w + 1 for w in range(3) if cl.accepted(r, w))
            gd = tuple(w + 1 for w in range(3) if cl.guidance(r, w))
            imp = tuple(w + 1 for w in range(3) if cl.improvement(r, w))
            inst = tuple(w + 1 for w in range(3) if r in cl.inst[w])
            # protection side
            rr = inv(r)
            racc = tuple(w + 1 for w in range(3) if cl.accepted(rr, w))
            key = (m, cl.rstr(r))
            rows[key] = (gd, imp, inst, acc, racc)
    # summary: installed (non-guidance) defences by owner and world, with improvement pattern
    from collections import Counter
    cnt = Counter()
    for (m, rs), (gd, imp, inst, acc, racc) in rows.items():
        if inst: cnt[(m, 'imp@' + ''.join(map(str, imp)) if imp else 'imp@-', 'inst@' + ''.join(map(str, inst)))] += 1
    for k, v in sorted(cnt.items()): print('  ', k, v)
    # check: is the installed world always the first world in 'order' that is not a strict improvement?
    bad = 0
    for (m, rs), (gd, imp, inst, acc, racc) in rows.items():
        if inst:
            first = [w + 1 for w in order if (w + 1) not in imp][0]
            if inst != (first,): bad += 1
    print('  installed world == first non-improving world in order (all):', bad == 0, ' exceptions:', bad)
    # protection margins
    full = sum(1 for v in rows.values() if len(v[4]) == 3)
    print('  rivals accepted against an owner at all 3 worlds (should be 0 for incoherent):', full)
