"""PP57 finite exact instance of the kink configuration.

Atoms = one representative cell per (answer set of A,B,D ; Wr) type of the kink
triple (31 types, geom57.py), with the two certificate cells
  Ep = (A alone answers, wrong only at world 1)   ["above"]
  Em = (A alone answers, right only at world 1)   ["below"]
twin-split into non-conic halves Ep_a, Ep_b, Em_a, Em_b (same gamble; coherent
models must agree on twins, by PP21's exact coherence test; a model splitting a
twin is non-conic, hence incoherent, Lemma H).
Advice codes 0=P (answer h), 1=N (answer -h), 2=S, 3=X (contradiction);
ranks: correct 0 < silent 1 < wrong 2 < contradictory 3.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'PP21_py'))
from geom57 import cell_list
from cells import is_coherent as _coh21

ADV = 'PNSX'

class Space57:
    def __init__(self, twins=('Ep', 'Em')):
        cl = cell_list()
        seen = {}
        for c in cl:
            key = (c['H'], c['wr'])
            seen.setdefault(key, c['g'])
        def nm(H, wr):
            if H == 'A' and wr == (1,): return 'Ep'
            if H == 'A' and wr == (2, 3): return 'Em'
            return f"{H or '0'}_{''.join(map(str, wr)) or 'U'}"
        cells = []
        for key in sorted(seen, key=lambda k: (len(k[0]), k)):
            name = nm(*key)
            if name in twins:
                cells += [(name + 'a', seen[key], key), (name + 'b', seen[key], key)]
            else:
                cells.append((name, seen[key], key))
        self.names = [c[0] for c in cells]
        self.g = [c[1] for c in cells]
        self.key = [c[2] for c in cells]
        self.n = len(cells)
        self.idx = {n: k for k, n in enumerate(self.names)}
        self.rank = []
        for w in range(3):
            rw = []
            for g in self.g:
                good = g[w] > 0
                rw.append((0 if good else 2, 2 if good else 0, 1, 3))
            self.rank.append(rw)
        self.sel = {}
        for m in 'ABD':
            self.sel[m] = tuple(0 if m in self.key[k][0] else 2 for k in range(self.n))
        self.T = self.sel['A']
        self._cc = {}

    def is_coherent(self, X):
        if X not in self._cc:
            self._cc[X] = _coh21(X, self.g)
        return self._cc[X]

    def show(self, X):
        return ''.join(ADV[v] for v in X)

if __name__ == '__main__':
    S = Space57()
    print('atoms:', S.n)
    print(' '.join(S.names))
    for m, X in S.sel.items():
        print(m, S.show(X), 'coherent' if S.is_coherent(X) else 'INCOHERENT')
    # sanity: posterior models agree with exact advice; twin-split model incoherent
    X = list(S.sel['A']); X[S.idx['Epa']] = 2
    print('A with Ep_a silenced (twin split):', 'coherent' if S.is_coherent(tuple(X)) else 'incoherent (expected)')
    X = list(S.sel['A']); X[S.idx['Epa']] = 2; X[S.idx['Epb']] = 2
    print('A with whole Ep silenced:', 'coherent' if S.is_coherent(tuple(X)) else 'incoherent')
    X = list(S.sel['A']); X[S.idx['Ema']] = 2; X[S.idx['Emb']] = 2
    print('A with whole Em silenced:', 'coherent' if S.is_coherent(tuple(X)) else 'incoherent')
