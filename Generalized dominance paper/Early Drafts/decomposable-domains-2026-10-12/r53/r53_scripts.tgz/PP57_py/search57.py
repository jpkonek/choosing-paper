"""PP57 search: least closure under audit's rules I-IV (engine21 = PP21 engine)
with DISJUNCTIVE defence obligations for the selected models A, B, D.

Obligation (M, X): some world w with M R_w X (all three worlds allowed: interior
indices).  Options are tried in a given world order; closure after each request;
F1 (strict guidance reversed), F2 (incoherent model protected), and in no-ties
mode F3 (an installed record whose reverse is accepted at the same world) are
failures.  Protection: P starts as {A, B, D}; rule III installs reverses of
all-world weak dominations of a protected model, rule IV registers its
all-world tie partners (F2 if incoherent) -- exactly the audit's encoding of
undominatedness + direct (C) for selected models (coherent rivals may tie).
DFS with chronological backtracking; every clean closure is re-verified from the
definitions by verify57.py.
"""
import os, sys, itertools, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from engine21 import Closure, mk_rec, inv, is_empty, Failure
from space57 import Space57

def rivals(S, window, vals, bases='ABD'):
    out = {}
    for b in bases:
        base = S.sel[b]
        for combo in itertools.product(*[vals[a] for a in window]):
            X = list(base)
            for a, v in zip(window, combo): X[S.idx[a]] = v
            X = tuple(X)
            lab = ','.join(a + ':' + 'PNSX'[v] for a, v in zip(window, combo) if v != base[S.idx[a]])
            out.setdefault(X, b + '[' + lab + ']')
    return out

class Search:
    def __init__(self, S, riv, order=(0, 1, 2), noties=False, max_nodes=200000, sel='ABD'):
        self.S, self.riv, self.order, self.noties = S, riv, order, noties
        self.max_nodes = max_nodes
        self.obl = [(m, X) for m in sel for X in riv if X != S.sel[m]]
        self.nodes = 0
        self.deadends = []

    def base(self):
        cl = Closure(self.S, self.S.is_coherent)
        cl.noties = self.noties
        for m in 'ABD': cl.request(('reg', self.S.sel[m]))
        f = cl.run()
        assert f is None, f.kind
        return cl

    def run(self):
        cl = self.base()
        stack = [(0, cl, None)]
        # iterative DFS
        def advance(i, cl):
            while i < len(self.obl):
                m, X = self.obl[i]
                if cl.defends(self.S.sel[m], X): i += 1; continue
                return i
            return i
        i = advance(0, cl)
        stack = [(i, cl, list(self.order))]
        while stack:
            i, cl, opts = stack[-1]
            if i >= len(self.obl):
                return cl
            if not opts:
                stack.pop(); continue
            w = opts.pop(0)
            self.nodes += 1
            if self.nodes > self.max_nodes: return None
            m, X = self.obl[i]
            c2 = cl.clone()
            try:
                c2.request(('cmp', self.S.sel[m], X, w))
                f = c2.run()
            except Failure as ff:
                f = ff
            if f is not None:
                self.deadends.append((i, w, f.kind, c2))
                continue
            j = advance(i + 1, c2)
            stack.append((j, c2, list(self.order)))
        return None

def greedy(S, riv, order=(0, 1, 2), noties=False, sel='ABD', log=None):
    """Greedy (no backtracking): each unmet obligation takes the first world in
    `order` whose request closes cleanly.  Returns (closure, list of stuck obligations).
    A stuck obligation is NOT an impossibility proof (greedy is incomplete)."""
    sr = Search(S, riv, order=order, noties=noties, sel=sel)
    cl = sr.base()
    stuck = []
    fails = {}
    for i, (m, X) in enumerate(sr.obl):
        if cl.defends(S.sel[m], X): continue
        done = False
        for w in order:
            c2 = cl.clone()
            try:
                c2.request(('cmp', S.sel[m], X, w)); f = c2.run()
            except Failure as ff:
                f = ff
            if f is None:
                cl = c2; done = True; break
            fails[f.kind] = fails.get(f.kind, 0) + 1
        if not done: stuck.append((m, X))
        if log and i % 2000 == 0: print('   progress', i, len(sr.obl), cl.stats(), flush=True)
    return cl, stuck, fails, sr
