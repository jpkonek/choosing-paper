"""Run 1/2 on the certificate cells: window = the four twin atoms of Ep, Em,
values {P, N, S} (N = -h, needed for pads), rivals based on A, B and D."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from space57 import Space57
from search57 import Search, rivals
from engine21 import inv
S = Space57()
W = ['Epa', 'Epb', 'Ema', 'Emb']
riv = rivals(S, W, {a: (0, 1, 2) for a in W})
print('rivals:', len(riv))
for noties in (False, True):
    for order in ((0, 1, 2), (1, 2, 0), (2, 0, 1)):
        t = time.time()
        sr = Search(S, riv, order=order, noties=noties)
        cl = sr.run()
        st = 'CLEAN' if cl is not None else 'NO CLEAN CLOSURE FOUND'
        extra = ''
        if cl is not None:
            ties = sum(1 for w in range(3) for r in cl.recs[w] if cl.accepted(inv(r), w))
            extra = f" records/world={cl.stats()['records']} |P|={len(cl.P)} installed-with-reverse-accepted={ties}"
        print(f"noties={noties} order={[w+1 for w in order]}: {st}; nodes={sr.nodes} deadends={len(sr.deadends)}{extra}  ({time.time()-t:.1f}s)")
# independent verification of every clean closure found above
from verify57 import verify
for noties in (False, True):
    sr = Search(S, riv, order=(0, 1, 2), noties=noties); cl = sr.run()
    errs = verify(S, cl.inst, sr.obl and [(S.sel[m], X) for m, X in sr.obl], [S.sel[m] for m in 'ABD'], list(riv))
    print(f'verify57 (noties={noties}, order 1,2,3): errors =', len(errs))
