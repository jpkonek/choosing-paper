"""Exact ingredients of Theorem Q (PP57 s.4).
(1) Pure shifts: for a in {u, B, D}, w in {1,2,3}, b = a o (1 + t e_w), t = 1/1000.
    On every cell of the joint arrangement, C_b's advice is no worse at w than C_a's,
    and on at least one non-null cell it is strictly better (exact, Fractions).
(2) Lambda's level-0 (PP56 s.4.1) increments of the move h -> S on the two
    certificate cells: Ep (A alone, wrong only at 1) and Em (A alone, right only at 1)
    are exactly opposite multiples of |g|:  (-2, 1, 1)|g|  and  (2, -1, -1)|g|."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from post51 import cells, advice
from geom57 import EPS, MOD, cell_list

def rank(w, g, adv):          # adv: 1 answer g (canonical, sum>0), 0 silent
    if adv == 0: return 1
    return 0 if g[w] > 0 else 2

ok = True
for nm in 'ABD':
    a = MOD[nm]
    for w in range(3):
        t = Fr(1, 1000)
        b = tuple(a[i] * (1 + (t if i == w else 0)) for i in range(3))
        worse = better = 0
        for g in cells(EPS, [a, b]):
            xa, xb = advice(EPS, a, g), advice(EPS, b, g)
            assert xa in (0, 1) and xb in (0, 1)
            ra, rb = rank(w, g, xa), rank(w, g, xb)
            if rb > ra: worse += 1
            if rb < ra: better += 1
        print(f'(1) a={nm} shift toward e_{w+1}: cells where C_b worse at {w+1}: {worse}; strictly better: {better}')
        ok &= worse == 0 and better > 0

def lam0(g, w, answer):
    """PP56 level 0 on R: u(h) = -|Wr| on Cor(h), +|Cor| on Wr(h); u(S) = 0 (per |g|)."""
    if not answer: return Fr(0)
    cor = [v for v in range(3) if g[v] > 0]; wr = [v for v in range(3) if g[v] < 0]
    return Fr(-len(wr)) if w in cor else Fr(len(cor))

cl = cell_list()
Ep = [c['g'] for c in cl if c['H'] == 'A' and c['wr'] == (1,)][0]
Em = [c['g'] for c in cl if c['H'] == 'A' and c['wr'] == (2, 3)][0]
vp = tuple(lam0(Ep, w, False) - lam0(Ep, w, True) for w in range(3))
vm = tuple(lam0(Em, w, False) - lam0(Em, w, True) for w in range(3))
print('(2) level-0 increment of h -> S per |g|: on Ep', vp, ' on Em', vm)
ok &= vp == (-2, 1, 1) and vm == (2, -1, -1) and sum(vp) == 0
print('ALL PASS' if ok else 'FAIL')
