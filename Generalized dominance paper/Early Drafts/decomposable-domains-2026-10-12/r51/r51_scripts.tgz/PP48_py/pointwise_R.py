"""REFEREE round 50, script 3 (NUMERICS; the repair of PP42 Thm 4.3(a) is proved analytically in the
report, this only shows the constants). eps = 0.3, cut vertex v = 3, field l^T of REFEREE_PP32 §3.2
(PP40's implementation field40.py, imported read-only from ../PP42_py).

On sampled points of H_{s0} (cap disagreement cone) we report:
  theta_pt  = max u.d / d_v                     (Lemma 4.1(iv)'s theta: a POINTWISE sup)
  R_pt      = max (|d_w| + |d_w'|) / d_v        (pointwise ratio needed for sigma vs silence)
  R'_pt     = max (|d'_w| + |d'_w'|) / alpha_v  (pointwise ratio needed for silence vs -sigma)
  R_int     = max_w (int_P beta_w + int_Q alpha_w) / Phi_v   (PP42's integral ratio R)
  min d_v/|g| and min alpha_v/|g| on H_{s0}       (bounded below: the key to the repair)
Then, with b = 1/10 and eta = 1/(40 R_pt'), where R_pt' = max(R_pt, R'_pt), we check that under
the humble field the cap answer is the strict u-optimum (against silence, -sigma, contradiction)
at every sampled point of H_s for s in {s0, s0/2, s0/4}.
Run: python3 -I -B pointwise_R.py > pointwise_R.out
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "PP42_py"))
import numpy as np
from field40 import field, pen, T, consts

rng = np.random.default_rng(48)
EPS = 0.3
c, L, d = consts(EPS)
Mv = np.array([[c + (EPS if i == j else 0) for j in range(3)] for i in range(3)])
v = 2
ow = [0, 1]


def cap_verts(delta):
    others = [Mv[i] for i in range(3) if i != v]
    ps = [Mv[v] + (delta / EPS) * (o - Mv[v]) for o in others]
    return np.array(others + ps)


def DK(verts, g):
    vals = g @ verts.T
    return np.where(vals.min(1) > 0, 1, np.where(vals.max(1) < 0, -1, 0))


N = 4_000_000
g = rng.standard_normal((N, 3))
tg = T(g, EPS)
for s0 in (EPS / 5, EPS / 10, EPS / 20, EPS / 40):
    cg = DK(cap_verts(s0), g)
    H = cg != tg
    gh = g[H]
    sig = cg[H]
    fl = field(gh, EPS)
    al = fl[0]
    pS = pen(np.zeros(len(gh), int), gh, fl)
    pG = pen(sig, gh, fl)
    pO = pen(-sig, gh, fl)
    dd = pG - pS            # d
    dp = pO - pS            # d'
    nrm = np.linalg.norm(gh, axis=1)
    dv = dd[:, v]
    theta = (dd.mean(1) / dv).max()
    Rpt = ((np.abs(dd[:, ow])).sum(1) / dv).max()
    Rpt2 = ((np.abs(dp[:, ow])).sum(1) / al[:, v]).max()
    # integral ratio (Monte Carlo over full Gaussian sample)
    Phi_v = (dd[:, v]).sum() / N
    Rint = max(((np.abs(dd[:, w])).sum() / N) / Phi_v for w in ow)
    print(f"s0 = eps/{EPS/s0:.0f}: |H sample| = {H.sum()}, theta_pt = {theta:.4f}, R_pt = {Rpt:.3f}, R'_pt = {Rpt2:.3f}, "
          f"R_int = {Rint:.3f}, min d_v/|g| = {(dv/nrm).min():.3f}, min alpha_v/|g| = {(al[:, v]/nrm).min():.3f}")
    if theta < 1 / 18:
        b = 0.1
        eta = 1 / (40 * max(Rpt, Rpt2))
        allok = True
        for s in (s0, s0 / 2, s0 / 4):
            cs = DK(cap_verts(s), g)
            Hs = cs != tg
            gs = g[Hs]; sg = cs[Hs]
            fl2 = field(gs, EPS)
            corr = sg[:, None] * np.sign(gs) > 0       # sigma w-correct
            scale = np.where(corr, 1 - eta, 1 + eta)
            scale[:, v] = b
            costs = {}
            for name, adv in (("sig", sg), ("S", np.zeros(len(gs), int)), ("neg", -sg), ("con", np.full(len(gs), 2))):
                costs[name] = (pen(adv, gs, fl2) * scale).mean(1)
            margin = min((costs[k] - costs["sig"]).min() for k in ("S", "neg", "con"))
            allok &= margin > 0
            print(f"    humble field b={b}, eta={eta:.4f}: s = s0/{s0/s:.0f}, |H_s sample| = {Hs.sum()}, min u-margin of sigma = {margin:.3e}")
        print(f"    strict u-optimum at all sampled points: {allok}")
print("NUMERICS DONE")
