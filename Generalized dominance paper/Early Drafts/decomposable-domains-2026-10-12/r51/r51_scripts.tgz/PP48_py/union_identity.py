"""REFEREE round 50, script 1 (CHECKED, exact rationals). The union lemma of AUDIT_multicap §1.

M = c*1 + eps*Delta, c = (1-eps)/3.  K_s = M ∩ {m_i <= c+eps-s_i, i=1,2,3}; C_s = D_{K_s}.
D_K(g) = +1 if min_{m in K} m.g > 0, -1 if max < 0, else 0 (strict convention; also rerun with
the non-strict convention: accept g iff min >= 0 and max > 0).
For each s we check, at every test problem g, EXACTLY (no null-set exceptions):
 (U1) C_s(g) != T(g)  iff  g in H_1(s_1) ∪ H_2(s_2) ∪ H_3(s_3), where H_i(t) := {D_{K_i(t)} != T};
 (U2) on that union C_s(g) equals the single-cap answer;
 (U3) the H_i(s_i) are pairwise disjoint;
 (U4) every definite answer of every one of the 8 sub-cut models (coordinates of s switched off)
      has the sign of u.g; no two of them give opposite answers.
Test problems: random rational g; g orthogonal to a vertex of K_s or of M (boundary cases);
g orthogonal to two vertices (planes through an edge or through a cut point).
Cut sizes: random s with s_i <= delta < eps/3; touching corners s_i + s_j = eps with all
s_i <= 2eps/3 (u in K_s); and cuts deeper than 2eps/3 (u not in K_s), where only (U1)-(U3) are
checked (the sign claim (U4) needs u in K_s; a first run without this restriction produced sign
failures, as expected).
Run: python3 -I -B union_identity.py > union_identity.out
"""
from fractions import Fraction as Fr
import itertools, random

random.seed(51)
FAIL = []


def check(cond, msg):
    if not cond:
        FAIL.append(msg)


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def cross(a, b):
    return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]


def verts_M(c, eps):
    return [[c + (eps if i == j else 0) for j in range(3)] for i in range(3)]


def verts_K(c, eps, s):
    M = verts_M(c, eps)
    out = []
    for i in range(3):
        if s[i] == 0:
            out.append(M[i])
        else:
            for j in range(3):
                if j != i:
                    out.append([M[i][t] + (s[i] / eps) * (M[j][t] - M[i][t]) for t in range(3)])
    return out


def D(verts, g, strict=True):
    vals = [dot(m, g) for m in verts]
    if strict:
        if min(vals) > 0:
            return 1
        if max(vals) < 0:
            return -1
        return 0
    if min(vals) >= 0 and max(vals) > 0:
        return 1
    if max(vals) <= 0 and min(vals) < 0:
        return -1
    return 0


def rr(n=60):
    return Fr(random.randint(-n, n), random.randint(1, n))


def test_problems(c, eps, s, n_rand):
    gs = [[rr(), rr(), rr()] for _ in range(n_rand)]
    pts = verts_K(c, eps, s) + verts_M(c, eps)
    # orthogonal to one vertex: g = p x h for random h
    for _ in range(n_rand // 4):
        p = random.choice(pts)
        h = [rr(), rr(), rr()]
        gs.append(cross(p, h))
    # orthogonal to two vertices
    for p, q in itertools.combinations(pts, 2):
        g = cross(p, q)
        if any(g):
            gs.append(g)
            gs.append([-x for x in g])
    return [g for g in gs if any(g)]


n_checks = 0
n_union = 0
n_boundary_union = 0
global_beyond = [0]
for strict in (True, False):
    for eps in (Fr(1, 10), Fr(3, 10), Fr(1, 2), Fr(9, 10)):
        c = (1 - eps) / 3
        Mv = verts_M(c, eps)
        delta = eps / 3 - eps / 300
        cuts = []
        for _ in range(25):
            cuts.append([Fr(random.randint(0, 1000), 1000) * delta for _ in range(3)])
        # extreme range: corners touching (s_i + s_j = eps) with all s_i <= 2eps/3 (so u in K_s)
        for _ in range(10):
            a = eps / 3 + Fr(random.randint(0, 1000), 1000) * eps / 3
            cuts.append([a, eps - a, Fr(random.randint(0, 1000), 1000) * min(eps - a, a)])
        cuts.append([eps / 2, eps / 2, eps / 2])
        # beyond the range: one cut deeper than 2eps/3 (u not in K_s); U1-U3 only
        for _ in range(5):
            a = Fr(2, 3) * eps + Fr(random.randint(1, 999), 1000) * eps / 3
            cuts.append([a, (eps - a) * Fr(random.randint(0, 1000), 1000), Fr(0)])
        cuts = [s for s in cuts if all(s[i] + s[j] <= eps for i in range(3) for j in range(3) if i != j)]
        for s in cuts:
            u_in = all(x <= 2 * eps / 3 for x in s)
            Ks = verts_K(c, eps, s)
            singles = [verts_K(c, eps, [s[k] if k == i else 0 for k in range(3)]) for i in range(3)]
            subs = [verts_K(c, eps, [s[k] if bits[k] else 0 for k in range(3)]) for bits in itertools.product((0, 1), repeat=3)]
            for g in test_problems(c, eps, s, 120):
                n_checks += 1
                t = D(Mv, g, strict)
                cs = D(Ks, g, strict)
                ci = [D(K, g, strict) for K in singles]
                inH = [ci[i] != t for i in range(3)]
                # (U3)
                check(sum(inH) <= 1, f"U3 disjointness eps={eps} s={s} g={g}")
                # (U1)
                check((cs != t) == any(inH), f"U1 eps={eps} s={s} g={g} strict={strict}")
                # (U2)
                if any(inH):
                    n_union += 1
                    i = inH.index(True)
                    check(cs == ci[i], f"U2 eps={eps} s={s} g={g}")
                    if any(dot(m, g) == 0 for m in Mv + Ks):
                        n_boundary_union += 1
                # (U4)
                if not u_in:
                    global_beyond[0] += 1
                    continue
                ug = sum(g)
                for K in subs:
                    a = D(K, g, strict)
                    if a != 0:
                        check(ug != 0 and (a > 0) == (ug > 0), f"U4 sign eps={eps} s={s} g={g}")
                answers = {D(K, g, strict) for K in subs} - {0}
                check(len(answers) <= 1, f"U4 opposite eps={eps} s={s} g={g}")

print(f"problems checked (both conventions, 4 eps values): {n_checks}")
print(f"problems in the union H_1 ∪ H_2 ∪ H_3: {n_union}; of these on a boundary plane of M or K_s: {n_boundary_union}")
print(f"problems with a cut deeper than 2eps/3 (U1-U3 only checked): {global_beyond[0]}")
print("ALL PASS" if not FAIL else f"FAILURES: {len(FAIL)}; first: {FAIL[:5]}")
