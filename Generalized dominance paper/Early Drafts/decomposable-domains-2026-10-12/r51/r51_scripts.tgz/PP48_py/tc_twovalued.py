"""REFEREE round 50, script 2 (CHECKED: every reported witness is verified in exact rationals;
the LPs only propose witnesses). Exact (TC) test for two-valued TWG families, and the repaired
necessity of CG2 (no agreement-region hypothesis).

Discretised model: atoms j with rational masses, divisible (a 'set' is a fraction phi_j of each
atom, standing for a sub-cone of that measure; the Gaussian measure is non-atomic). One world w.
Advice per atom: S (silent), sig (a definite answer), -sig, X (contradiction). At each atom sig is
w-correct or w-wrong. Gated members take values in {S, sig} (two-valued, as in the multicap family).
Fields: per member, per atom, four penalties strictly increasing in the w-rank.
Aggregation (R): a record is accepted iff it is a weak w-worsening (guidance) or some member equal
to the old side on the whole support rates it strictly positive.

(A) Triples. Criterion N(c>=0): there is c in [0,inf)^3, c != 0, with
        c_a d^a(a->b) + c_b d^b(b->a) <= 0 on every atom of D_ab, for the three pairs.
    Criterion P(c>0): the same with c > 0 (= AUDIT_multicap's interval triangle test, closed form).
    Claim (Thm R1): under all-pair conditions, (TC) holds iff N holds for every triple.
    If N fails, an LP proposes fractions for the patterns a, b, c of the referee report; the script
    builds X, Y, Z, recomputes every link and every reverse under the full family's gates in exact
    arithmetic, and confirms: three links accepted, at least one reverse refused (a TC failure).
    If N holds, the dual LP (no positive-orthant point) is confirmed infeasible.
    Counts the instances where N holds but P fails (zero constants needed): there the interval
    test is not necessary.
(B) Pairs, sandwich failure with NO agreement region where the two members are not w-correct.
    Builds X = N, Y = N[D -> M], Z = N[D0 -> w-correct] with D0 inside {f^N < 0} and confirms the
    TC failure exactly.
Run: python3 -I -B tc_twovalued.py > tc_twovalued.out
"""
from fractions import Fraction as Fr
import itertools, random
import numpy as np
from scipy.optimize import linprog

random.seed(4850)
FAIL = []
S, SIG, NEG, CON = 0, 1, 2, 3


def rank(adv, sig_correct):
    if adv == S:
        return 1
    if adv == CON:
        return 3
    corr = (adv == SIG) == sig_correct
    return 0 if corr else 2


class Inst:
    def __init__(self, n_atoms, n_mem, mode):
        self.n = n_atoms
        self.mass = [Fr(random.randint(1, 9), 10) for _ in range(n_atoms)]
        p_wrong = {"mixed": Fr(1, 2), "mostly_wrong": Fr(9, 10)}[mode]
        self.corr = [random.random() > p_wrong for _ in range(n_atoms)]
        # members: nested-ish two-valued answers
        self.val = []
        for k in range(n_mem):
            dens = random.choice([Fr(1, 5), Fr(2, 5), Fr(3, 5)])
            self.val.append([SIG if random.random() < dens else S for _ in range(n_atoms)])
        # fields: strictly increasing in rank; random per member/atom (BR holds)
        self.fld = []
        for k in range(n_mem):
            rows = []
            for j in range(n_atoms):
                inc = [Fr(random.randint(1, 12), random.randint(1, 4)) for _ in range(3)]
                byrank = [Fr(0), inc[0], inc[0] + inc[1], inc[0] + inc[1] + inc[2]]
                rows.append(byrank)
            self.fld.append(rows)

    def ell(self, k, j, adv):
        return self.fld[k][j][rank(adv, self.corr[j])]

    def delta(self, k, j, a, b):
        return self.ell(k, j, b) - self.ell(k, j, a)


def record_accepted(inst, old, new, wts):
    """old/new: per sub-atom advice lists; wts: (atom index, mass) per sub-atom. Exact."""
    supp = [i for i in range(len(old)) if old[i] != new[i]]
    if not supp:
        return True, "trivial"
    # guidance
    if all(rank(new[i], inst.corr[wts[i][0]]) >= rank(old[i], inst.corr[wts[i][0]]) for i in supp):
        return True, "guidance"
    for k in range(len(inst.val)):
        if all(inst.val[k][wts[i][0]] == old[i] for i in supp):
            v = sum(wts[i][1] * inst.delta(k, wts[i][0], old[i], new[i]) for i in supp)
            if v > 0:
                return True, f"gate {k}"
    return False, "refused"


def pair_rows(inst, a, b):
    return [j for j in range(inst.n) if inst.val[a][j] != inst.val[b][j]]


def crit(inst, tri, positive):
    """LP: c >= 0 (or >= 1e-6 scaled), sum c = 1, pairwise inequalities."""
    A, bvec = [], []
    for (x, y) in itertools.combinations(range(3), 2):
        a, b = tri[x], tri[y]
        for j in pair_rows(inst, a, b):
            row = [0.0] * 3
            row[x] = float(inst.delta(a, j, inst.val[a][j], inst.val[b][j]))
            row[y] = float(inst.delta(b, j, inst.val[b][j], inst.val[a][j]))
            A.append(row)
            bvec.append(0.0)
    lb = 1e-7 if positive else 0.0
    res = linprog(np.zeros(3), A_ub=np.array(A) if A else None, b_ub=np.array(bvec) if A else None,
                  A_eq=np.ones((1, 3)), b_eq=[1.0], bounds=[(lb, None)] * 3, method="highs")
    return res.status == 0, (res.x if res.status == 0 else None)


def exact_crit_check(inst, tri, c):
    c = [Fr(x).limit_denominator(10 ** 6) for x in c]
    if min(c) < 0 or sum(c) == 0:
        return False
    for (x, y) in itertools.combinations(range(3), 2):
        a, b = tri[x], tri[y]
        for j in pair_rows(inst, a, b):
            if c[x] * inst.delta(a, j, inst.val[a][j], inst.val[b][j]) + c[y] * inst.delta(b, j, inst.val[b][j], inst.val[a][j]) > 0:
                return False
    return True


def violation_lp(inst, tri):
    """variables phi^p_j for patterns p in (12, 23, 31) on atoms of D_12, D_23, D_31."""
    N1, N2, N3 = tri
    vars_ = []
    for (p, (a, b)) in enumerate([(N1, N2), (N2, N3), (N3, N1)]):
        for j in pair_rows(inst, a, b):
            vars_.append((p, j))
    if not vars_:
        return None
    nv = len(vars_)
    G = np.zeros((3, nv))
    for idx, (p, j) in enumerate(vars_):
        m = float(inst.mass[j])
        v1, v2, v3 = inst.val[N1][j], inst.val[N2][j], inst.val[N3][j]
        if p == 0:  # X=N1, Y=N2, Z=N1
            G[0, idx] = m * float(inst.delta(N1, j, v1, v2))
            G[1, idx] = m * float(inst.delta(N2, j, v2, v1))
        elif p == 1:  # X=Y=N2, Z=N3
            G[1, idx] = m * float(inst.delta(N2, j, v2, v3))
            G[2, idx] = m * float(inst.delta(N3, j, v3, v2))
        else:  # X=N1, Y=Z=N3
            G[0, idx] = m * float(inst.delta(N1, j, v1, v3))
            G[2, idx] = m * float(inst.delta(N3, j, v3, v1))
    # variables (phi, t): maximise t subject to G phi >= t (each world-gate), per-atom budget, t <= 1
    A_ub = [np.append(-G[k], 1.0) for k in range(3)]
    b_ub = [0.0, 0.0, 0.0]
    for j in range(inst.n):  # per-atom budget
        row = np.zeros(nv + 1)
        for idx, (p, jj) in enumerate(vars_):
            if jj == j:
                row[idx] = 1.0
        if row.any():
            A_ub.append(row)
            b_ub.append(1.0)
    obj = np.zeros(nv + 1); obj[-1] = -1.0
    res = linprog(obj, A_ub=np.array(A_ub), b_ub=np.array(b_ub), bounds=[(0, None)] * nv + [(0, 1)], method="highs")
    if res.status != 0 or res.x[-1] <= 1e-9:
        return None
    return vars_, res.x[:-1]


def build_and_verify(inst, tri, vars_, phi):
    N1, N2, N3 = tri
    phi = [Fr(x).limit_denominator(10 ** 7) for x in phi]
    # per atom: split into sub-atoms for each pattern + remainder
    X, Y, Z, W = [], [], [], []
    for j in range(inst.n):
        used = Fr(0)
        for idx, (p, jj) in enumerate(vars_):
            if jj != j or phi[idx] <= 0:
                continue
            f = phi[idx]
            used += f
            v1, v2, v3 = inst.val[N1][j], inst.val[N2][j], inst.val[N3][j]
            x, y, z = [(v1, v2, v1), (v2, v2, v3), (v1, v3, v3)][p]
            X.append(x); Y.append(y); Z.append(z); W.append((j, f * inst.mass[j]))
        if used > 1:
            return False, "budget"
        rest = 1 - used
        if rest > 0:
            v1 = inst.val[N1][j]
            X.append(v1); Y.append(v1); Z.append(v1); W.append((j, rest * inst.mass[j]))
    links = [record_accepted(inst, X, Y, W), record_accepted(inst, Y, Z, W), record_accepted(inst, Z, X, W)]
    revs = [record_accepted(inst, Y, X, W), record_accepted(inst, Z, Y, W), record_accepted(inst, X, Z, W)]
    ok = all(l[0] for l in links) and not all(r[0] for r in revs)
    return ok, (links, revs)


def all_pairs_ok(inst):
    """pairwise nonnegative-constant condition for every pair of members (exact check via LP)."""
    for a, b in itertools.combinations(range(len(inst.val)), 2):
        rows = pair_rows(inst, a, b)
        A = [[float(inst.delta(a, j, inst.val[a][j], inst.val[b][j])), float(inst.delta(b, j, inst.val[b][j], inst.val[a][j]))] for j in rows]
        if not A:
            continue
        res = linprog(np.zeros(2), A_ub=np.array(A), b_ub=np.zeros(len(A)), A_eq=np.ones((1, 2)), b_eq=[1.0], bounds=[(0, None)] * 2, method="highs")
        if res.status != 0:
            return False
        c = [Fr(x).limit_denominator(10 ** 6) for x in res.x]
        for j, row in zip(rows, A):
            if c[0] * inst.delta(a, j, inst.val[a][j], inst.val[b][j]) + c[1] * inst.delta(b, j, inst.val[b][j], inst.val[a][j]) > 0:
                return False
    return True


# ---------- (A) triples ----------
stats = dict(inst=0, pairs_ok=0, N_holds=0, N_fails=0, viol_verified=0, dual_infeasible=0, N_not_P=0, N_not_P_dual=0)
for trial in range(6000):
    mode = "mixed" if trial % 2 else "mostly_wrong"
    inst = Inst(n_atoms=random.randint(4, 9), n_mem=4, mode=mode)
    # make member 0 pointwise w-better where it disagrees in half the cases (one-signed pairs, like T at v)
    if trial % 3 == 0:
        for j in range(inst.n):
            if not inst.corr[j]:
                inst.val[0][j] = S
    stats["inst"] += 1
    if not all_pairs_ok(inst):
        continue
    stats["pairs_ok"] += 1
    for tri in itertools.permutations(range(4), 3):
        if tri[0] > tri[1] or tri[0] > tri[2]:
            continue
        okN, c = crit(inst, tri, positive=False)
        okP, _ = crit(inst, tri, positive=True)
        if okN:
            if not exact_crit_check(inst, tri, c):
                FAIL.append(("exact N check", trial, tri))
            stats["N_holds"] += 1
            v = violation_lp(inst, tri)
            if v is None:
                stats["dual_infeasible"] += 1
            else:
                FAIL.append(("N holds but violation LP feasible", trial, tri))
            if not okP:
                stats["N_not_P"] += 1
                if v is None:
                    stats["N_not_P_dual"] += 1
        else:
            stats["N_fails"] += 1
            v = violation_lp(inst, tri)
            if v is None:
                FAIL.append(("N fails but no violation found", trial, tri))
                continue
            ok, info = build_and_verify(inst, tri, *v)
            if ok:
                stats["viol_verified"] += 1
            else:
                FAIL.append(("violation not verified", trial, tri, info))
print("(A) triples:", stats)

# ---------- (B) pairs: sandwich failure, no agreement region ----------
nb = 0
for trial in range(400):
    inst = Inst(n_atoms=random.randint(3, 8), n_mem=3, mode="mixed")
    N, M = 0, 1
    # make N and M disagree everywhere (so {N = M} is empty): M = opposite of N in {S, sig}
    inst.val[M] = [SIG if x == S else S for x in inst.val[N]]
    rows = pair_rows(inst, N, M)
    fN = [inst.delta(N, j, inst.val[N][j], inst.val[M][j]) for j in rows]
    fM = [inst.delta(M, j, inst.val[N][j], inst.val[M][j]) for j in rows]
    pos = [i for i in range(len(rows)) if fN[i] > 0]
    neg = [i for i in range(len(rows)) if fN[i] < 0]
    if not pos or not neg:
        continue
    sup_neg = max(fM[i] / fN[i] for i in neg)
    inf_pos = min(fM[i] / fN[i] for i in pos)
    if sup_neg <= inf_pos:
        continue  # sandwich holds
    ip = min(pos, key=lambda i: fM[i] / fN[i])
    ineg = max(neg, key=lambda i: fM[i] / fN[i])
    jp, jn = rows[ip], rows[ineg]
    kap1, kap2 = fM[ip] / fN[ip], fM[ineg] / fN[ineg]      # kap1 < kap2
    ap = inst.mass[jp] * fN[ip]                              # full positive-atom value of f^N
    an = -inst.mass[jn] * fN[ineg]                           # full negative-atom |value| of f^N
    r = (1 + kap2 / kap1) / 2                                # want x = r*y with 1 < r < kap2/kap1
    y = min(an, ap / r)
    x = r * y
    phi_p, phi_n = x / ap, y / an
    # integral of f^M over D is kap1*x - kap2*y = -y(kap2-kap1)/2 < 0; integral of f^N is x - y > 0
    d0_frac = Fr(1, 10 ** 6)
    W, X, Y, Z = [], [], [], []
    for j in range(inst.n):
        vN, vM = inst.val[N][j], inst.val[M][j]
        correct = SIG if inst.corr[j] else NEG
        if j == jp and phi_p > 0:
            W.append((j, phi_p * inst.mass[j])); X.append(vN); Y.append(vM); Z.append(vN)
            rest = 1 - phi_p
        elif j == jn:
            # D-part, with a small D0 inside it where Z = w-correct
            W.append((j, (phi_n - d0_frac * phi_n) * inst.mass[j])); X.append(vN); Y.append(vM); Z.append(vN)
            W.append((j, d0_frac * phi_n * inst.mass[j])); X.append(vN); Y.append(vM); Z.append(correct)
            rest = 1 - phi_n
        else:
            rest = Fr(1)
        if rest > 0:
            W.append((j, rest * inst.mass[j])); X.append(vN); Y.append(vN); Z.append(vN)
    links = [record_accepted(inst, X, Y, W), record_accepted(inst, Y, Z, W), record_accepted(inst, Z, X, W)]
    rev = record_accepted(inst, X, Z, W)
    nb += 1
    if not (all(l[0] for l in links) and not rev[0]):
        FAIL.append(("pair repair", trial, links, rev))
print(f"(B) sandwich-failing pairs with {{N = M}} empty: {nb}; TC failure verified exactly in each")
print("ALL PASS" if not FAIL else f"FAILURES {len(FAIL)}: {FAIL[:3]}")
