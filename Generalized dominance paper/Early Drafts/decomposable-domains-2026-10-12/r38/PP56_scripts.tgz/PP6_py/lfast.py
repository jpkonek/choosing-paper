"""closed form of the additive nu-losses (perimeter formula, PP6 Lemma 2):
L_i(C_p) = (2 per(conv(e_i u K_p)) - per(K_p)) / (2 pi)   (spherical perimeters)
         = [th(e_i,v_j) + th(e_i,v_k) + th(v_j,v_k)/2 - th(v_i,v_j)/2 - th(v_i,v_k)/2] / pi"""
import numpy as np
U3 = np.ones(3)/3

def verts(P, eps):
    P = np.atleast_2d(P); m = P.min(1)
    return np.stack([P + 3*eps*m[:, None]*(np.eye(3)[k] - U3) for k in range(3)], 1)  # (n,3,3)

def th(X, Y):
    X = X/np.linalg.norm(X, axis=-1, keepdims=True); Y = Y/np.linalg.norm(Y, axis=-1, keepdims=True)
    return np.arccos(np.clip((X*Y).sum(-1), -1, 1))

def L(P, eps):
    V = verts(P, eps); E = np.eye(3); out = []
    for i in range(3):
        j, k = [x for x in range(3) if x != i]
        val = (th(E[i][None], V[:, j]) + th(E[i][None], V[:, k]) + 0.5*th(V[:, j], V[:, k])
               - 0.5*th(V[:, i], V[:, j]) - 0.5*th(V[:, i], V[:, k]))/np.pi
        out.append(val)
    return np.stack(out, 1)
