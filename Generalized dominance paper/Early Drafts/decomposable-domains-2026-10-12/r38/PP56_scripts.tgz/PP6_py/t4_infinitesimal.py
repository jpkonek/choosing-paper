"""Infinitesimal displacement records rec(C_p, C_{p+tv}).
For records between regular models (PP6 Lemma 1): a_i + b_i = M (world-independent),
a_i - b_i = Delta L_i, Phi_i = (M + 3 Delta L_i)/2.
At first order: Delta L_i = t l_i(v), M = t m(v).
Report, per world, the arcs (degrees, tangent-plane angle) where
   F_i : Phi_i < 0 (ineligible: l_i < -m/3),
   G_i : guidance (b_i = 0, i.e. l_i = m),
   B_i : both directions eligible (|l_i| <= m/3),
   A_i : additive acceptance (l_i >= 0)."""
import sys; sys.path.insert(0, '.')
import numpy as np, math
from geom import record
b1 = np.array([1, -1, 0])/math.sqrt(2); b2 = np.array([1, 1, -2])/math.sqrt(6)
def arcs(mask, deg):
    """runs of True in a circular boolean array -> list of (start,end) degrees"""
    n = len(mask)
    if mask.all(): return 'all'
    if not mask.any(): return 'none'
    out = []; k0 = np.argmin(mask)          # start at a False
    run = None
    for s in range(1, n+1):
        k = (k0+s) % n
        if mask[k] and run is None: run = deg[k]
        if not mask[k] and run is not None:
            out.append((run, deg[(k-1) % n])); run = None
    return out
def scan(p, eps, t=2e-4, n=360):
    p = np.array(p, float)
    deg = np.arange(n)*360/n
    l = np.zeros((n, 3)); m = np.zeros(n); guid = np.zeros((n, 3), bool)
    for k, d in enumerate(deg):
        v = math.cos(math.radians(d))*b1 + math.sin(math.radians(d))*b2
        q = p+t*v
        if q.min() < 0 or (p.min() == 0 and q.min() < 0.05*t):
            l[k] = np.nan; m[k] = np.nan; continue
        R = record(p, q, eps, anchors=False)
        l[k] = (R.a-R.b)/t; m[k] = (R.a+R.b)[0]/t; guid[k] = R.guid
    return deg, l, m, guid
if __name__ == '__main__':
    eps = float(sys.argv[1]) if len(sys.argv) > 1 else 0.3
    pts = {'generic interior': (.5, .3, .2), 'near e1, off the symmetric line': (.9, .07, .03),
           'near e1, on the symmetric line': (.9, .05, .05), 'near u, inside chamber 3': (.35, .33, .32),
           'u': (1/3, 1/3, 1/3), 'edge [e1,e2] interior point': (.7, .3, 0.0)}
    for name, p in pts.items():
        deg, l, m, guid = scan(p, eps)
        ok = ~np.isnan(m); deg, l, m, guid = deg[ok], l[ok], m[ok], guid[ok]
        if not ok.all(): print('   (boundary index: only the', int(ok.sum()), 'directions into the simplex)')
        print(f'== {name} p={p} eps={eps}')
        for i in range(3):
            F = l[:, i] < -m/3 - 1e-9; G = guid[:, i]; B = np.abs(l[:, i]) <= m/3 + 1e-9
            A = l[:, i] >= -1e-9
            print(f'  world {i+1}: F(inelig)={arcs(F,deg)}  G(guidance)={arcs(G,deg)}  B(both ways)={arcs(B,deg)}  A(additive)={arcs(A,deg)}')
        # is there a direction where all worlds lose additively (l<0)?  (coverage of additive rule)
        print('   min_v max_i l_i(v)/m(v) =', round(float((l.max(1)/m).min()), 5),
              '  max_v min_i l_i/m =', round(float((l.min(1)/m).max()), 5),
              '  min_v max_i Phi_i/m =', round(float(((m[:, None]+3*l)/2).max(1).min()/1), 5))
        print('   directions covered by the symmetric bands B_1 u B_2 u B_3:',
              int((np.abs(l) <= m[:, None]/3 + 1e-9).any(1).sum()), 'of', len(deg))
