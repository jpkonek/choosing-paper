"""Is each selected model 'Bayes within the family' for its local normal lambda(p)?
i.e. min_q lambda(p).(L(q)-L(p)) >= 0 ?  (sufficient for (AC))"""
import sys; sys.path.insert(0, '.')
import numpy as np
from lfast import L
for eps in (0.3, 0.1):
    n = 120
    P = np.array([(i/n, j/n, (n-i-j)/n) for i in range(n+1) for j in range(n+1-i)])
    LP = L(P, eps)
    worst = 0; cnt = 0; neg = 0
    for x in range(len(P)):
        p = P[x]
        if p.min() < 1e-9: continue
        h = 1e-6
        d1 = (L(p+h*np.array([1,-1,0]),eps)-L(p-h*np.array([1,-1,0]),eps))[0]/(2*h)
        d2 = (L(p+h*np.array([1,0,-1]),eps)-L(p-h*np.array([1,0,-1]),eps))[0]/(2*h)
        lam = np.cross(d1, d2); lam /= lam.sum()
        if not (lam > 0).all(): neg += 1
        val = (LP - LP[x]) @ lam
        cnt += 1
        if val.min() < worst - 1e-12:
            worst = val.min(); w = (p, P[np.argmin(val)], lam)
    print('eps', eps, 'interior points', cnt, 'non-positive normals', neg, 'min lambda.(L(q)-L(p))', worst)
    if worst < 0: print('   worst', w)
