"""PP6 grid SAT over allocations W(rec(C_p,C_q)) between selected models.

Variables x[i,(p,q)] = "world i accepts rec(C_p,C_q)", i.e. C_p <=_i C_q.
Hard constraints:
  (E)  Phi_i < 0 and not guidance  ->  not x      (eligible pool)
  (G)  guidance (C_q a pointwise weak world-i worsening of C_p)  ->  x
  (F)  for every face I met by A(rec): OR_{i in I} x[i,(p,q)]    (seven face obligations)
  (TC) x[i,pq] & x[i,qr] & x[i,rp] -> x[i,pr]    for all distinct p,q,r, every world
  (U)  not( x[.,qp] at all worlds and not x[j,pq] for some j )   (no selected model dominated)
  (IB) records with identical fingerprints share variables (none occur; checked)
Closedness cannot be imposed on a grid; it is proved separately for the candidate rule.

Run: python3 -I t6_sat.py   (writes t6_sat.out)
"""
import sys, os, itertools, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import numpy as np
from pysat.solvers import Cadical153
from pysat.formula import CNF
from grids import table
from geom import same_record

FACE_NAMES = {(0,): '{1}', (1,): '{2}', (2,): '{3}', (0, 1): '{1,2}', (0, 2): '{1,3}', (1, 2): '{2,3}',
              (0, 1, 2): '{1,2,3}'}


class Inst:
    def __init__(self, D):
        self.D = D; self.pts = D['pts']; self.N = N = len(self.pts); self.T = D['T']
        self.var = {}
        for (x, y) in self.T:
            for i in range(3):
                self.var[(i, x, y)] = len(self.var) + 1
        self.hard = []; self.fixed = {}
        self.build()

    def v(self, i, x, y):
        return self.var[(i, x, y)]

    def build(self):
        T, N = self.T, self.N
        # (IB) fingerprints
        fps = {}
        for k, r in T.items():
            fps.setdefault(r['fp'], []).append(k)
        self.fp_collisions = [ks for ks in fps.values() if len(ks) > 1]
        self.ib_collisions = []
        for ks in self.fp_collisions:      # exact identity test on fingerprint collisions
            for k1, k2 in itertools.combinations(ks, 2):
                if same_record(self.pts[k1[0]], self.pts[k1[1]], self.pts[k2[0]], self.pts[k2[1]], self.D['eps']):
                    self.ib_collisions.append([k1, k2])
        for ks in self.ib_collisions:
            for i in range(3):
                a = self.v(i, *ks[0])
                for k in ks[1:]:
                    b = self.v(i, *k); self.hard += [[-a, b], [a, -b]]
        self.n_elig = self.n_guid = self.n_face = 0
        for (x, y), r in T.items():
            for i in range(3):
                if r['guid'][i]:
                    self.hard.append([self.v(i, x, y)]); self.fixed[(i, x, y)] = True; self.n_guid += 1
                elif r['phi'][i] < 0:
                    self.hard.append([-self.v(i, x, y)]); self.fixed[(i, x, y)] = False
                else:
                    self.n_elig += 1
            for I, hit in r['faces'].items():
                if hit:
                    self.hard.append([self.v(i, x, y) for i in I]); self.n_face += 1
        self.n_tc = 0
        for i in range(3):
            for x, y, z in itertools.permutations(range(N), 3):
                self.hard.append([-self.v(i, x, y), -self.v(i, y, z), -self.v(i, z, x), self.v(i, x, z)])
                self.n_tc += 1
        for (x, y) in T:          # does y dominate x ?  y <= x at all worlds, and not x <= y somewhere
            for j in range(3):
                self.hard.append([-self.v(0, y, x), -self.v(1, y, x), -self.v(2, y, x), self.v(j, x, y)])

    def check(self, assign):
        """assign: dict (i,x,y) -> bool.  returns list of violated hard clauses"""
        bad = []
        for cl in self.hard:
            if not any((assign[self.key(l)] if l > 0 else not assign[self.key(-l)]) for l in cl):
                bad.append(cl)
        return bad

    def key(self, l):
        if not hasattr(self, '_inv'):
            self._inv = {v: k for k, v in self.var.items()}
        return self._inv[abs(l)]


def additive_assign(I):
    return {(i, x, y): bool(r['dL'][i] >= -1e-15 or r['guid'][i]) for (x, y), r in I.T.items() for i in range(3)}


def greedy_assign(I):
    """audit s.6 rule with the source as witness: Phi_i >= 0 and p_i Phi_i maximal; guidance added"""
    A = {}
    for (x, y), r in I.T.items():
        p = np.array([float(c) for c in I.pts[x]]); w = p * r['phi']
        for i in range(3):
            A[(i, x, y)] = bool(r['guid'][i] or (r['phi'][i] >= 0 and w[i] >= w.max() - 1e-15))
    return A


def band_assign(I, kappa):
    """accept iff Delta L_i >= -kappa M (kappa = 1/3 is the whole eligible pool)"""
    return {(i, x, y): bool(r['guid'][i] or r['dL'][i] >= -kappa * r['M'] - 1e-15)
            for (x, y), r in I.T.items() for i in range(3)}


def describe(I, cl):
    out = []
    for l in cl:
        i, x, y = I.key(l)
        out.append(('' if l > 0 else 'not ') + f'W{i+1}({fmt(I.pts[x])}->{fmt(I.pts[y])})')
    return ' OR '.join(out)


def fmt(p):
    return '(' + ','.join(f'{float(c):.3f}' for c in p) + ')'


def run(name, eps, out):
    D = table(name, eps); I = Inst(D)
    T = I.T
    pr = lambda *a: print(*a, file=out, flush=True)
    pr(f'\n=== grid {name}, eps = {eps}: {I.N} indices, {len(T)} ordered pairs, {len(I.var)} variables')
    pr(f'  (IB) fingerprint collisions {len(I.fp_collisions)}; exactly identical records among them: {len(I.ib_collisions)}')
    elig_margin = min(abs(r['phi'][i]) for r in T.values() for i in range(3) if not r['guid'][i])
    pr(f'  guidance-forced acceptances {I.n_guid}; free eligible variables {I.n_elig}; '
       f'face clauses {I.n_face}; TC clauses {I.n_tc}; min |Phi_i| over non-guidance {elig_margin:.2e}')
    nb = sum(1 for r in T.values() if any(r['faces'][f] for f in r['faces'] if len(f) < 3))
    pr(f'  records with a boundary anchor (proper face met by A(d)): {nb}')
    # candidate checks
    for lab, A in [('additive  W_i = {Delta L_i >= 0}', additive_assign(I)),
                   ('audit greedy (source witness)', greedy_assign(I)),
                   ('band kappa = 1/3 (whole pool)', band_assign(I, Fr(1, 3))),
                   ('band kappa = 1/20', band_assign(I, Fr(1, 20)))]:
        bad = I.check(A)
        pr(f'  candidate [{lab}]: violated hard clauses = {len(bad)}')
        for cl in bad[:3]:
            pr('      e.g. ' + describe(I, cl))
    # SAT + backbone
    S = Cadical153(bootstrap_with=I.hard)
    t0 = time.time(); sat = S.solve(); pr(f'  SAT: {sat}  ({time.time()-t0:.2f}s)')
    free = [k for k in I.var if k not in I.fixed]
    can_T = {}; can_F = {}
    for k in free:
        v = I.var[k]
        can_T[k] = S.solve(assumptions=[v]); can_F[k] = S.solve(assumptions=[-v])
    forced_T = [k for k in free if not can_F[k]]; forced_F = [k for k in free if not can_T[k]]
    pr(f'  backbone among free eligible variables: forced accept {len(forced_T)}, forced refuse {len(forced_F)}, '
       f'genuinely free {len(free)-len(forced_T)-len(forced_F)}')
    sticky = [k for k in free if T[k[1:]]['dL'][k[0]] < 0]
    sticky_ok = [k for k in sticky if can_T[k]]
    pos = [k for k in free if T[k[1:]]['dL'][k[0]] > 0]
    pos_refusable = [k for k in pos if can_F[k]]
    pr(f'  eligible records with Delta L_i < 0 (sticky): {len(sticky)}; acceptable in some allocation: {len(sticky_ok)}')
    pr(f'  records with Delta L_i > 0: {len(pos)}; refusable in some allocation: {len(pos_refusable)}')
    if forced_F:
        worst = sorted(forced_F, key=lambda k: -T[k[1:]]['dL'][k[0]] / T[k[1:]]['M'])[:3]
        for k in worst:
            r = T[k[1:]]
            pr(f'      forced refusal with largest Delta L_i/M: world {k[0]+1} {fmt(I.pts[k[1]])}->{fmt(I.pts[k[2]])}'
               f' dL/M = {r["dL"][k[0]]/r["M"]:.3f}')
    S.delete()
    return I, can_T, can_F


if __name__ == '__main__':
    out = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 't6_sat.out'), 'w')
    for name in ('e1', 'u', 'all'):
        for eps in (Fr(3, 10), Fr(1, 10)):
            run(name, eps, out)
    out.close()
