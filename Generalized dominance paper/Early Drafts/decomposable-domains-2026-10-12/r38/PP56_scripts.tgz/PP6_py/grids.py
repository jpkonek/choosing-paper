"""index grids (exact rationals) and record tables"""
import sys, os, pickle, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import numpy as np
from geom import record, losses

def grid_e1(n=6, den=50, extra=True):
    pts = [(1 - Fr(j + k, den), Fr(j, den), Fr(k, den)) for j in range(n + 1) for k in range(n + 1 - j)]
    if extra:   # audit's diagnostic triple
        pts += [(Fr(9, 10), Fr(1, 20), Fr(1, 20)), (Fr(901, 1000), Fr(8, 100), Fr(19, 1000)),
                (Fr(902, 1000), Fr(49, 1000), Fr(49, 1000))]
    return pts

def grid_u(r=3, den=60):
    c = den // 3
    return [(Fr(c + a, den), Fr(c + b, den), Fr(c - a - b, den))
            for a in range(-r, r + 1) for b in range(-r, r + 1) if abs(a + b) <= r]

def grid_all(n=6):
    return [(Fr(i, n), Fr(j, n), Fr(n - i - j, n)) for i in range(n + 1) for j in range(n + 1 - i)]

GRIDS = {'e1': grid_e1, 'u': grid_u, 'all': grid_all}

def table(name, eps, cache=True):
    fn = os.path.join(os.path.dirname(os.path.abspath(__file__)), f'rec_{name}_{eps.numerator}_{eps.denominator}.pkl')
    if cache and os.path.exists(fn):
        return pickle.load(open(fn, 'rb'))
    pts = GRIDS[name]()
    N = len(pts); T = {}
    t0 = time.time()
    for x in range(N):
        for y in range(N):
            if x == y: continue
            R = record(pts[x], pts[y], eps)
            T[(x, y)] = dict(a=R.a, b=R.b, phi=R.phi, guid=R.guid, simp=R.strict_impr, faces=R.faces,
                             M=float((R.a + R.b)[0]), dL=R.a - R.b,
                             fp=tuple(np.round(np.concatenate([R.a, R.b]), 13)))
    Ls = np.array([losses(p, eps) for p in pts])
    out = dict(pts=pts, T=T, L=Ls, eps=eps, secs=time.time() - t0)
    pickle.dump(out, open(fn, 'wb'))
    return out

if __name__ == '__main__':
    for name in ('e1', 'u', 'all'):
        for eps in (Fr(3, 10), Fr(1, 10)):
            D = table(name, eps)
            print(name, eps, len(D['pts']), 'points', len(D['T']), 'records', round(D['secs'], 1), 's')
