"""high-precision closed form of L_i (perimeter formula) with mpmath"""
import mpmath as mp
mp.mp.dps = 50
def verts(p, eps):
    m = min(p); s = 3*eps*m
    return [[p[i] + s*((1 if i == k else 0) - mp.mpf(1)/3) for i in range(3)] for k in range(3)]
def th(x, y):
    nx = mp.sqrt(sum(a*a for a in x)); ny = mp.sqrt(sum(a*a for a in y))
    c = sum(a*b for a, b in zip(x, y))/(nx*ny)
    # robust angle: atan2(|x cross y|, x.y)
    cr = [x[1]*y[2]-x[2]*y[1], x[2]*y[0]-x[0]*y[2], x[0]*y[1]-x[1]*y[0]]
    return mp.atan2(mp.sqrt(sum(a*a for a in cr)), sum(a*b for a, b in zip(x, y)))
def L(p, eps):
    p = [mp.mpf(x) for x in p]; eps = mp.mpf(eps); V = verts(p, eps); out = []
    for i in range(3):
        E = [1 if k == i else 0 for k in range(3)]
        j, k = [x for x in range(3) if x != i]
        out.append((th(E, V[j]) + th(E, V[k]) + th(V[j], V[k])/2 - th(V[i], V[j])/2 - th(V[i], V[k])/2)/mp.pi)
    return out
