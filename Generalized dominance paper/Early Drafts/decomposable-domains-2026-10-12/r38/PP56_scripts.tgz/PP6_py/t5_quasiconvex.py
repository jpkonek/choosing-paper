"""(Q) screen: is each L_i quasi-convex on Delta?  For random segments [x,y] test
L_i(z) <= max(L_i(x), L_i(y)) at interior points z.  Also convexity of L_i."""
import sys; sys.path.insert(0, '.')
import numpy as np
from lfast import L
rng = np.random.default_rng(5)
for eps in (0.3, 0.1, 0.9):
    X = rng.dirichlet([0.7]*3, 20000); Y = rng.dirichlet([0.7]*3, 20000)
    s = np.linspace(0, 1, 41)[1:-1]
    worstq = 0; worstc = 0
    LX, LY = L(X, eps), L(Y, eps)
    for t in s:
        Z = (1-t)*X + t*Y; LZ = L(Z, eps)
        worstq = max(worstq, (LZ - np.maximum(LX, LY)).max())
        worstc = max(worstc, (LZ - ((1-t)*LX + t*LY)).max())
    print(f'eps {eps}: max violation of quasi-convexity {worstq:.3e}; of convexity {worstc:.3e}')
