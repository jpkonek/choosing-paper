"""(AC) screen on fine local grids near e1, near u and near the midpoint of [e2,e3]:
min over grid pairs of max_i (L_i(q)-L_i(p)) / |q-p|."""
import sys; sys.path.insert(0, '.')
import numpy as np
from lfast import L
def local(center, h, n):
    c = np.array(center, float); out = []
    for a in range(-n, n+1):
        for b in range(-n, n+1):
            p = c + h*(a*np.array([1, -1, 0]) + b*np.array([1, 0, -1]))
            if p.min() >= -1e-15: out.append(np.maximum(p, 0)/np.maximum(p, 0).sum())
    return np.array(out)
for eps in (0.3, 0.1):
    for name, c, h in [('e1', (1, 0, 0), 1/4000), ('near e1 (.9,.05,.05)', (.9, .05, .05), 1/4000),
                       ('u', (1/3, 1/3, 1/3), 1/4000), ('mid [e2,e3]', (0, .5, .5), 1/4000)]:
        P = local(c, h, 30); LP = L(P, eps); worst = np.inf
        for x in range(len(P)):
            d = LP - LP[x]; r = np.linalg.norm(P - P[x], axis=1); val = d.max(1)/np.where(r > 0, r, np.inf)
            val[r == 0] = np.inf
            worst = min(worst, val.min())
        print(f'eps {eps} {name}: {len(P)} points, min ratio {worst:.5f}')
