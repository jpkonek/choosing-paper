"""(AC) screen: g(p) = min_{q != p} max_i (L_i(q)-L_i(p)) / |q-p|.  Positive everywhere
means no selected model is weakly additively dominated by another (with margin)."""
import sys; sys.path.insert(0, '.')
import numpy as np
from lfast import L
for eps in (0.3, 0.1, 0.9):
    n = 150
    P = np.array([(i/n, j/n, (n-i-j)/n) for i in range(n+1) for j in range(n+1-i)])
    LP = L(P, eps)
    worst = (np.inf, None)
    for x in range(len(P)):
        d = LP - LP[x]; r = np.linalg.norm(P - P[x], axis=1); r[x] = np.inf
        val = d.max(1)/r; val[x] = np.inf
        y = np.argmin(val)
        if val[y] < worst[0]:
            worst = (val[y], P[x], P[y], d[y])
    print('eps', eps, 'points', len(P), 'min ratio', worst[0], 'at p', worst[1], 'q', worst[2])
