"""Independent checker (no clause list): verifies an allocation against the record table.
Used on (1) the additive allocation, (2) a SAT solution containing a strict 4-cycle at world 1."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import numpy as np
from grids import table

def verify(D, W):
    """W[i] : N x N boolean matrix, W[i][x,y] = world i accepts rec(C_x, C_y); diagonal True"""
    T = D['T']; N = len(D['pts']); errs = []
    for (x, y), r in T.items():
        for i in range(3):
            if r['guid'][i] and not W[i][x, y]: errs.append(('guidance refused', i, x, y))
            if W[i][x, y] and not r['guid'][i] and r['phi'][i] < 0: errs.append(('ineligible accepted', i, x, y))
        for F, h in r['faces'].items():
            if h and not any(W[i][x, y] for i in F): errs.append(('face', F, x, y))
    for i in range(3):
        A = W[i].astype(np.int64)
        two = A @ A                                  # paths x->y->z
        # (TC): x<=y<=z and z<=x  =>  x<=z ; i.e. two[x,z]>0 & A[z,x] & not A[x,z] forbidden
        bad = (two > 0) & (A.T == 1) & (A == 0)
        if bad.any(): errs.append(('TC', i, int(bad.sum())))
    allw = W[0] & W[1] & W[2]
    for x in range(N):
        for y in range(N):
            if x != y and allw[y, x] and not allw[x, y]: errs.append(('dominated', x, 'by', y))
    return errs

def from_assign(D, A):
    N = len(D['pts']); W = [np.eye(N, dtype=bool) for _ in range(3)]
    for (i, x, y), v in A.items(): W[i][x, y] = v
    return W

if __name__ == '__main__':
    from t6_sat import Inst, additive_assign
    from pysat.solvers import Cadical153
    for name in ('e1', 'u', 'all'):
        for eps in (Fr(3, 10), Fr(1, 10)):
            D = table(name, eps); I = Inst(D)
            e1 = verify(D, from_assign(D, additive_assign(I)))
            # a solution with a strict 4-cycle at world 1, found by the solver
            S = Cadical153(bootstrap_with=I.hard); found = None
            rng = np.random.default_rng(3)
            for _ in range(500):
                p, q, r, s = rng.choice(I.N, 4, replace=False)
                lits = sum([[I.v(0, u, v), -I.v(0, v, u)] for u, v in ((p, q), (q, r), (r, s), (s, p))], [])
                if S.solve(assumptions=lits):
                    m = set(l for l in S.get_model() if l > 0)
                    A = {k: (I.var[k] in m) for k in I.var}; found = (p, q, r, s); break
            e2 = verify(D, from_assign(D, A)) if found else None
            W = from_assign(D, A)
            cyc = found and all(W[0][u, v] and not W[0][v, u] for u, v in zip(found, found[1:] + (found[0],)))
            print(f'{name} eps={eps}: additive allocation errors {len(e1)}; '
                  f'4-cycle solution errors {len(e2) if e2 is not None else "n/a"}, strict 4-cycle present: {cyc}')
