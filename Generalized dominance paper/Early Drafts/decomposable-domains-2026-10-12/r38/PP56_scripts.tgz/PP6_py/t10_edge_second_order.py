"""At an edge index p = (0,a,1-a), moving towards e1 is first-order neutral for worlds 2,3
(precise-part derivative b(b v2 - a v3) vanishes on v = e1 - p).  (AC) then rests on the
second-order coefficients c_i = lim (L_i(p+t(e1-p)) - L_i(p))/t^2.  High precision (mpmath)."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mpmath as mp
from lmp import L
for eps in ('0.3', '0.1', '0.9'):
    for a in ('0.02', '0.1', '0.25', '0.5', '0.75', '0.98'):
        a = mp.mpf(a); p = [mp.mpf(0), a, 1 - a]
        row = []
        for t in (mp.mpf('1e-8'), mp.mpf('1e-10')):
            q = [t, (1 - t)*a, (1 - t)*(1 - a)]
            d = [y - x for x, y in zip(L(p, eps), L(q, eps))]
            row.append((d[0]/t, d[1]/t, d[2]/t**2, d[1]/t**2))
        print(f'eps {eps} a={mp.nstr(a,3)}: first order dL1/t = {mp.nstr(row[1][0],8)}, dL2/t = {mp.nstr(row[1][1],3)}; '
              f'second order c2 = {mp.nstr(row[1][3],8)}, c3 = {mp.nstr(row[1][2],8)}  (t=1e-8: c2 {mp.nstr(row[0][3],8)})')
