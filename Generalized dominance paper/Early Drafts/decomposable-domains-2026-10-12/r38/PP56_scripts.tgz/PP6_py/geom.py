"""PP6 geometry layer.

Selected family (audit, AUDIT_anchor_plan.md s.1):
    K_p = p + 3 eps min_j p_j (Delta - u),  C_p = D_{K_p}.
Problems g ~ standard Gaussian on R^3, so the measure of a polyhedral cone is its
solid angle / 4 pi.  All measures below are computed from the exact arrangement of the
planes {g_i = 0} and {g . v = 0} (v a vertex of K_p or K_q): every cell is a convex
spherical polygon whose area is a sum of exact triangle solid angles
(Van Oosterom-Strackee).  Floating point only; the total area is checked against 4 pi.

Advice of D_K at g: accept (0) if g.v > 0 at every vertex v of K, reject (2) if g.v < 0
at every vertex, silent (1) otherwise.  Rank at world i: good 0, silent 1, bad 2, where
accept is good iff g_i > 0 and reject is good iff g_i < 0.  (Coherent models never
contradict, so rank 3 does not occur between selected models.)

Rank-step measure nu = mu x counting on levels j = 1,2,3.  For a record d = rec(X,Y):
    a_i = nu(P_i) = nu(U_i(Y) \\ U_i(X))   (steps Y adds at world i)
    b_i = nu(Q_i) = nu(U_i(X) \\ U_i(Y))   (steps Y removes)
    Phi_i = 2 a_i - b_i.
Accepting d at world i means X <=_i Y.
"""
import itertools, math
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import linprog

U3 = np.ones(3) / 3.0
E = np.eye(3)


def K_vertices(p, eps):
    p = np.asarray(p, float)
    m = p.min()
    return np.array([p + 3 * eps * m * (E[k] - U3) for k in range(3)])


def _fr(x):
    return x if isinstance(x, Fr) else Fr(x)


def K_vertices_exact(p, eps):
    """exact rational vertices (p, eps converted exactly from their binary floats or
    given as Fractions)"""
    p = [_fr(x) for x in p]; eps = _fr(eps); m = min(p)
    return [tuple(p[i] + 3 * eps * m * ((1 if i == k else 0) - Fr(1, 3)) for i in range(3))
            for k in range(3)]


def _intvec(v):
    """primitive integer vector on the same ray"""
    den = 1
    for x in v:
        den = den * x.denominator // math.gcd(den, x.denominator)
    w = [int(x * den) for x in v]
    g = 0
    for x in w:
        g = math.gcd(g, abs(x))
    return tuple(x // g for x in w) if g else tuple(w)


def _cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def _dot(a, b):
    return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]


def _unit(v):
    x = np.array([float(c) for c in v]) if max(abs(c) for c in v) < 2**1000 else None
    if x is None or not np.isfinite(x).all() or np.linalg.norm(x) == 0:
        mx = max(abs(c) for c in v); sh = mx.bit_length() - 900
        x = np.array([float(c >> sh) if c >= 0 else -float((-c) >> sh) for c in v])
    return x / np.linalg.norm(x)


def arrangement_exact(normals):
    """exact combinatorics: normals are integer 3-vectors (planes through 0, distinct up
    to sign).  returns list of (sign tuple, area, float unit vertex array)"""
    M = len(normals)
    verts = {}
    for a in range(M):
        for b in range(a + 1, M):
            x = _cross(normals[a], normals[b])
            if x == (0, 0, 0):
                continue
            g = 0
            for c in x:
                g = math.gcd(g, abs(c))
            x = tuple(c // g for c in x)
            verts[x] = 1; verts[tuple(-c for c in x)] = 1
    verts = list(verts)
    sg = [[(1 if d > 0 else (-1 if d < 0 else 0)) for d in (_dot(n, x) for n in normals)] for x in verts]
    fv = np.array([_unit(x) for x in verts])
    cells = {}
    for vi in range(len(verts)):
        z = [k for k in range(M) if sg[vi][k] == 0]
        for fill in itertools.product((1, -1), repeat=len(z)):
            key = list(sg[vi])
            for k, f in zip(z, fill):
                key[k] = f
            cells.setdefault(tuple(key), []).append(vi)
    out = []
    for key, vs in cells.items():
        if len(vs) < 3:
            continue
        # exact rank test
        full = False
        for i1, i2, i3 in itertools.combinations(vs, 3):
            if _dot(verts[i1], _cross(verts[i2], verts[i3])) != 0:
                full = True; break
        if not full:
            continue
        P = fv[vs]
        out.append((key, _poly_area(P), P))
    tot = sum(c[1] for c in out)
    assert abs(tot - 4 * math.pi) < 1e-9, (tot, len(out))
    return out


def planes_exact(points):
    """integer normals for the planes g.x = 0, x in points (Fraction 3-tuples); dedupe.
    returns (normals, idx): point k -> normals[idx[k]] with the same orientation
    (all points are in the closed positive orthant, so equal planes mean equal rays)"""
    normals, idx, seen = [], [], {}
    for x in points:
        w = _intvec(x)
        if w not in seen:
            seen[w] = len(normals); normals.append(w)
        idx.append(seen[w])
    return normals, idx


def lower_prev(p, eps, g):
    p = np.asarray(p, float); g = np.asarray(g, float)
    return p @ g + eps * p.min() * (3 * g.min() - g.sum())


def _tri_solid(a, b, c):
    num = abs(np.dot(a, np.cross(b, c)))
    den = 1.0 + np.dot(a, b) + np.dot(b, c) + np.dot(c, a)
    return 2.0 * math.atan2(num, den)


def _poly_area(pts):
    """area of a convex spherical polygon given (unordered) unit vertices"""
    c = pts.sum(0); c /= np.linalg.norm(c)
    t1 = np.cross(c, [1.0, 0, 0])
    if np.linalg.norm(t1) < 1e-6:
        t1 = np.cross(c, [0, 1.0, 0])
    t1 /= np.linalg.norm(t1); t2 = np.cross(c, t1)
    ang = np.arctan2(pts @ t2, pts @ t1)
    o = np.argsort(ang); P = pts[o]
    A = 0.0
    for k in range(len(P)):
        A += _tri_solid(c, P[k], P[(k + 1) % len(P)])
    return A


def unique_planes(normals, tol=1e-12):
    """dedupe plane normals (up to positive or negative scaling).
    returns (U, idx, sgn): U unit normals, normal k == sgn[k] * U[idx[k]] (up to scale)"""
    U, idx, sgn = [], [], []
    for n in normals:
        n = np.asarray(n, float); n = n / np.linalg.norm(n)
        hit = None
        for j, u in enumerate(U):
            if np.linalg.norm(n - u) < 1e-10:
                hit = (j, 1); break
            if np.linalg.norm(n + u) < 1e-10:
                hit = (j, -1); break
        if hit is None:
            U.append(n); hit = (len(U) - 1, 1)
        idx.append(hit[0]); sgn.append(hit[1])
    return np.array(U), idx, sgn


def arrangement(U, tol=1e-11):
    """cells of the arrangement of great circles with unit normals U.
    returns list of (sign tuple, area, vertex array)"""
    M = len(U)
    verts = []
    for a in range(M):
        for b in range(a + 1, M):
            x = np.cross(U[a], U[b]); nx = np.linalg.norm(x)
            if nx < 1e-12:
                continue
            x /= nx
            for s in (1.0, -1.0):
                y = s * x
                if all(np.linalg.norm(y - v) > 1e-9 for v in verts):
                    verts.append(y)
    verts = np.array(verts)
    S = verts @ U.T
    sg = np.where(S > tol, 1, np.where(S < -tol, -1, 0))
    cells = {}
    for vi in range(len(verts)):
        z = np.where(sg[vi] == 0)[0]
        for fill in itertools.product((1, -1), repeat=len(z)):
            key = sg[vi].copy(); key[z] = fill
            cells.setdefault(tuple(key), []).append(vi)
    out = []
    for key, vs in cells.items():
        P = verts[vs]
        if len(vs) < 3 or np.linalg.matrix_rank(P, tol=1e-9) < 3:
            continue
        out.append((key, _poly_area(P), P))
    tot = sum(c[1] for c in out)
    assert abs(tot - 4 * math.pi) < 1e-8, (tot, len(out))
    return out


def advice_from_signs(s):
    if all(x > 0 for x in s):
        return 0
    if all(x < 0 for x in s):
        return 2
    return 1


def rank(adv, gs):
    """adv 0 accept, 1 silent, 2 reject; gs = sign of g_i"""
    if adv == 1:
        return 1
    good = (adv == 0 and gs > 0) or (adv == 2 and gs < 0)
    return 0 if good else 2


class Record:
    pass


def record(p, q, eps, anchors=True):
    """exact record data for rec(C_p, C_q)"""
    Vp, Vq = K_vertices_exact(p, eps), K_vertices_exact(q, eps)
    pts = [(Fr(1), Fr(0), Fr(0)), (Fr(0), Fr(1), Fr(0)), (Fr(0), Fr(0), Fr(1))] + Vp + Vq
    normals, idx = planes_exact(pts)
    sgn = [1] * 9
    cells = arrangement_exact(normals)
    R = Record(); R.p = np.array([float(x) for x in p]); R.q = np.array([float(x) for x in q])
    a = np.zeros(3); b = np.zeros(3)
    has_add = [False] * 3; has_rem = [False] * 3
    Dcells = []
    for key, area, P in cells:
        s = [key[idx[k]] * sgn[k] for k in range(9)]
        gs = s[0:3]
        ap = advice_from_signs(s[3:6]); aq = advice_from_signs(s[6:9])
        if ap == aq:
            continue
        mu = area / (4 * math.pi)
        Dcells.append((ap, aq, mu, P, key))
        for i in range(3):
            rp, rq = rank(ap, gs[i]), rank(aq, gs[i])
            if rq > rp:
                a[i] += mu * (rq - rp); has_add[i] = True
            elif rp > rq:
                b[i] += mu * (rp - rq); has_rem[i] = True
    R.a, R.b = a, b
    R.phi = 2 * a - b
    R.guid = [not has_rem[i] for i in range(3)]          # pointwise weak worsening at i
    R.strict_impr = [(not has_add[i]) and has_rem[i] for i in range(3)]
    R.ident = len(Dcells) == 0
    R.D = Dcells
    if anchors:
        R.faces = anchor_faces(R)
    return R


FACES = [(0,), (1,), (2,), (0, 1), (0, 2), (1, 2), (0, 1, 2)]


def anchor_faces(R, tol=1e-12):
    """faces I with A(d) meeting Delta_I.  Proper faces need a precise C_r (r on the
    boundary) agreeing with C_p a.e. on D: C_p determinate on D and r on the right side
    of every changed problem.  The full face always meets A(d) (it contains p)."""
    hit = {(0, 1, 2): True}
    p = R.p
    if R.ident:
        for I in FACES:
            hit[I] = (all(p[j] <= 1e-15 for j in range(3) if j not in I))
        return hit
    if any(ap == 1 for ap, aq, mu, P, key in R.D):
        for I in FACES[:-1]:
            hit[I] = False
        return hit
    rows = []
    for ap, aq, mu, P, key in R.D:
        sgn = 1.0 if ap == 0 else -1.0
        for x in P:
            rows.append(-sgn * x)          # sgn * r.x >= 0   <=>  -sgn x . r <= 0
    A_ub = np.array(rows); b_ub = np.full(len(rows), tol)
    for I in FACES[:-1]:
        bounds = [(0, None) if j in I else (0, 0) for j in range(3)]
        res = linprog(np.zeros(3), A_ub=A_ub, b_ub=b_ub, A_eq=np.ones((1, 3)), b_eq=[1.0],
                      bounds=bounds, method='highs')
        hit[I] = (res.status == 0)
    return hit


def losses(p, eps):
    """additive nu-losses L_i(C_p) = nu(U_i(C_p))"""
    Vp = K_vertices_exact(p, eps)
    normals, idx = planes_exact([(Fr(1), Fr(0), Fr(0)), (Fr(0), Fr(1), Fr(0)), (Fr(0), Fr(0), Fr(1))] + Vp)
    sgn = [1] * 6
    L = np.zeros(3)
    for key, area, P in arrangement_exact(normals):
        s = [key[idx[k]] * sgn[k] for k in range(6)]
        ap = advice_from_signs(s[3:6])
        for i in range(3):
            L[i] += area / (4 * math.pi) * rank(ap, s[i])
    return L


def same_record(p, q, p2, q2, eps):
    """exact test: rec(C_p,C_q) == rec(C_p2,C_q2) a.e. (same changed set, same advice on
    both sides there).  Overlay arrangement of all the planes involved."""
    Vs = [K_vertices_exact(x, eps) for x in (p, q, p2, q2)]
    pts = [(Fr(1), Fr(0), Fr(0)), (Fr(0), Fr(1), Fr(0)), (Fr(0), Fr(0), Fr(1))] + sum(Vs, [])
    normals, idx = planes_exact(pts)
    for key, area, P in arrangement_exact(normals):
        s = [key[idx[k]] for k in range(15)]
        a = [advice_from_signs(s[3 + 3 * j: 6 + 3 * j]) for j in range(4)]
        d1 = a[0] != a[1]; d2 = a[2] != a[3]
        if d1 != d2 or (d1 and (a[0], a[1]) != (a[2], a[3])):
            return False
    return True
