"""Screen: is the image L(Delta) of the additive nu-losses a Pareto antichain?
(if yes, 'accept at i iff L_i(C_p) <= L_i(C_q)' is a candidate allocation)"""
import sys; sys.path.insert(0, '.')
import numpy as np, itertools
from geom import losses
for eps in (0.3, 0.1):
    n = 40
    pts = [(i/n, j/n, (n-i-j)/n) for i in range(n+1) for j in range(n+1-i)]
    L = np.array([losses(p, eps) for p in pts])
    P = np.array(pts)
    bad = 0; worst = None
    for x in range(len(pts)):
        d = L - L[x]                       # L(q) - L(p)
        dom = (d <= 1e-13).all(1) & (d < -1e-13).any(1)
        if dom.any():
            bad += 1
            y = np.where(dom)[0][np.argmin(d[dom].max(1))]
            if worst is None or d[y].max() < worst[0]:
                worst = (d[y].max(), pts[x], pts[y], d[y])
    print('eps', eps, 'grid', len(pts), 'dominated selected (additive):', bad)
    print('  example (max coordinate of L(q)-L(p), p, q, diff):', worst)
    # local normals
    neg = 0; mixed = 0
    for (i, j) in [(i, j) for i in range(1, n) for j in range(1, n-i)]:
        p = np.array([i/n, j/n, (n-i-j)/n]); h = 1e-4
        d1 = (losses(p+h*np.array([1,-1,0]), eps)-losses(p-h*np.array([1,-1,0]), eps))/(2*h)
        d2 = (losses(p+h*np.array([1,0,-1]), eps)-losses(p-h*np.array([1,0,-1]), eps))/(2*h)
        nm = np.cross(d1, d2)
        if not ((nm > 0).all() or (nm < 0).all()):
            mixed += 1
    print('  interior grid points whose local normal is not of one strict sign:', mixed)
