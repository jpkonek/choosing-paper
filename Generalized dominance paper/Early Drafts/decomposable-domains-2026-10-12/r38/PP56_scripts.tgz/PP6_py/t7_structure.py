"""PP6 t7: (a) sanity of the exact record-identity test; (b) why acceptances are forced;
(c) can selected-to-selected allocations carry strict 4-cycles (non-additivity) at a world?
(d) minimal cores for the audit greedy rule's violations (plain description)."""
import sys, os, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
import numpy as np
from pysat.solvers import Cadical153
from pysat.examples.musx import MUSX
from pysat.formula import WCNF
from geom import same_record
from t6_sat import Inst, greedy_assign, fmt
from grids import table

out = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 't7_structure.out'), 'w')
pr = lambda *a: print(*a, file=out, flush=True)
e = Fr(3, 10)
a, b, c = (Fr(9, 10), Fr(1, 20), Fr(1, 20)), (Fr(901, 1000), Fr(8, 100), Fr(19, 1000)), (Fr(902, 1000), Fr(49, 1000), Fr(49, 1000))
pr('(a) same_record(a,b,a,b) =', same_record(a, b, a, b, e), '; same_record(a,b,a,c) =', same_record(a, b, a, c, e),
   '; same_record(a,b,b,a) =', same_record(a, b, b, a, e))

for name in ('e1', 'u', 'all'):
    for eps in (Fr(3, 10), Fr(1, 10)):
        I = Inst(table(name, eps)); T = I.T
        S = Cadical153(bootstrap_with=I.hard)
        free = [k for k in I.var if k not in I.fixed]
        forced = [k for k in free if not S.solve(assumptions=[-I.var[k]])]
        # (b) classify: forced by a face clause whose other worlds are ineligible?
        unit = 0; kinds = {}
        for k in forced:
            i, x, y = k; r = T[(x, y)]
            hit = False
            for F, h in r['faces'].items():
                if h and i in F and all(I.fixed.get((j, x, y)) is False for j in F if j != i):
                    hit = True; kinds[len(F)] = kinds.get(len(F), 0) + 1; break
            unit += hit
        pr(f'\n[{name}, eps={eps}] forced acceptances beyond guidance: {len(forced)}; '
           f'explained by a face obligation whose other worlds are ineligible: {unit} (by face size {kinds})')
        # (c) strict 4-cycles at world 1 (and 2,3)
        random.seed(1); found = {}
        for w in range(3):
            tries = 0
            for _ in range(4000):
                p, q, r_, s = random.sample(range(I.N), 4)
                lits = []
                ok = True
                for u, v in ((p, q), (q, r_), (r_, s), (s, p)):
                    lits += [I.v(w, u, v), -I.v(w, v, u)]
                    if I.fixed.get((w, u, v)) is False or I.fixed.get((w, v, u)) is True: ok = False
                if not ok: continue
                tries += 1
                if S.solve(assumptions=lits):
                    found[w] = (p, q, r_, s); break
            pr(f'   world {w+1}: strict 4-cycle among selected models realizable in some allocation: '
               f'{"YES " + str([fmt(I.pts[t]) for t in found[w]]) if w in found else "none found"} ({tries} candidate cycles tried)')
        S.delete()
        # (d) greedy MUS (e1 grid only)
        if name == 'e1':
            G = greedy_assign(I)
            free_true = [k for k in free if G[k]]
            # cores: hard clauses + greedy acceptances as soft units; find one MUS of the units
            S2 = Cadical153(bootstrap_with=I.hard)
            assum = [I.var[k] for k in free_true]
            sat = S2.solve(assumptions=assum)
            pr(f'   greedy acceptances (non-guidance) {len(free_true)}; jointly consistent with the hard constraints: {sat}')
            if not sat:
                core = S2.get_core()
                # shrink core to a minimal one (deletion-based)
                core = list(core)
                k = 0
                while k < len(core):
                    trial = core[:k] + core[k+1:]
                    if not S2.solve(assumptions=trial):
                        core = list(S2.get_core()) if len(S2.get_core()) < len(trial) else trial
                    else:
                        k += 1
                pr(f'   a minimal core of greedy acceptances ({len(core)} literals):')
                for l in core:
                    i, x, y = I.key(l); r = T[(x, y)]
                    pr(f'      W{i+1}({fmt(I.pts[x])} -> {fmt(I.pts[y])})  Phi={np.round(r["phi"],5)}  dL/M={np.round(r["dL"]/r["M"],3)}')
            S2.delete()
out.close()
