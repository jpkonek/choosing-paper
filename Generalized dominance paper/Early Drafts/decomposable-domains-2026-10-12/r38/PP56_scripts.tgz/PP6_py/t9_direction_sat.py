"""Infinitesimal allocation problem at a chamber base p (direction-dependent rules).
Directions d_k = angle 360k/n in the tangent plane.  S_i = {d : world i accepts
rec(C_p, C_{p+td})} for small t.  Constraints (PP6 s.1):
  eligibility  phi_i(d) < 0 -> d not in S_i;   guidance -> d in S_i
  (TC) for infinitesimal triangles = P-closedness: if d1,d2,d3 in S_i positively span R^2
       then -d1,-d2,-d3 in S_i
  coverage: every d in some S_i   (interior p: the only face met by A(d) for small records)
  undominated: -d in all S_i  ->  d in all S_i
Queries: which (world, direction) memberships are possible / forced; can a world be of
symmetric type; can a world be inactive.  Directions with |phi_i| tiny are flagged."""
import sys, os, math, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from pysat.solvers import Cadical153
from t4_infinitesimal import scan

def build(l, m, guid, n):
    phi = (m[:, None] + 3*l)/2
    var = lambda i, k: 1 + i*n + k
    cl = []
    for k in range(n):
        for i in range(3):
            if guid[k, i]: cl.append([var(i, k)])
            elif phi[k, i] < 0: cl.append([-var(i, k)])
        cl.append([var(i, k) for i in range(3)])
        for j in range(3):
            cl.append([-var(0, (k+n//2) % n), -var(1, (k+n//2) % n), -var(2, (k+n//2) % n), var(j, k)])
    ang = 2*np.pi*np.arange(n)/n
    for a, b, c in itertools.combinations(range(n), 3):
        # positively spanning iff every gap between consecutive angles < pi
        s = sorted([a, b, c]); gaps = [s[1]-s[0], s[2]-s[1], n - s[2] + s[0]]
        if max(gaps) < n//2:
            for i in range(3):
                for t in (a, b, c):
                    cl.append([-var(i, a), -var(i, b), -var(i, c), var(i, (t + n//2) % n)])
    return cl, var, phi

if __name__ == '__main__':
    n = 72
    out = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 't9_direction_sat.out'), 'w')
    pr = lambda *a: print(*a, file=out, flush=True)
    for eps in (0.3, 0.1):
        for name, p in [('generic interior', (.5, .3, .2)), ('near e1, off symmetric line', (.9, .07, .03)),
                        ('near e1, close to symmetric line', (.9, .051, .049)),
                        ('near u, chamber 3', (.35, .33, .32))]:
            deg, l, m, guid = scan(p, eps, n=n)
            cl, var, phi = build(l, m, guid, n)
            S = Cadical153(bootstrap_with=cl)
            pr(f'\n== {name} p={p} eps={eps}: SAT={S.solve()}; min |phi_i|/m over directions = {np.abs(phi/m[:,None]).min():.4f}')
            for i in range(3):
                canT = [S.solve(assumptions=[var(i, k)]) for k in range(n)]
                canF = [S.solve(assumptions=[-var(i, k)]) for k in range(n)]
                sticky = [k for k in range(n) if l[k, i] < 0 and phi[k, i] >= 0]
                pr(f'  world {i+1}: possible directions {sum(canT)}/{n}, forced {sum(not f for f in canF)}; '
                   f'eligible sticky directions (l_i<0<=phi_i) {len(sticky)}, of which acceptable {sum(canT[k] for k in sticky)}')
                # symmetric type possible?  (S_i = -S_i, nonempty)
                sym = [[-var(i, k), var(i, (k+n//2) % n)] for k in range(n)]
                S2 = Cadical153(bootstrap_with=cl + sym + [[var(i, k) for k in range(n)]])
                symok = S2.solve()
                S2.delete()
                S3 = Cadical153(bootstrap_with=cl + [[-var(i, k)] for k in range(n)])
                pr(f'     symmetric nonempty type possible: {symok}; inactive (S_i empty) possible: {S3.solve()}')
                S3.delete()
                # F_i overlaps
            F = (phi < 0)
            for i, j in itertools.combinations(range(3), 2):
                pr(f'  F_{i+1} and F_{j+1} share {int((F[:, i] & F[:, j]).sum())} directions')
            S.delete()
    out.close()
