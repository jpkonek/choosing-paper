"""Expected-rank vector L(C_p) = (L_1,L_2,L_3), L_i = 1 - mu(good_i) + mu(bad_i).
add_i(rec(C_x,C_y)) = L_i(C_y) - L_i(C_x), so a record between selected models has every
additive balance <= 0 iff L(C_y) <= L(C_x) componentwise ('additive Pareto domination').
Locally this happens iff the normal of the surface p -> L(C_p) has mixed signs (NUMERICS)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fast import Model
import math

def L(p):
    M = Model(p)
    return [1 - 2*M.g[i] + 2*M.h[i] for i in range(3)]

def normal(p, h=1e-4):
    p = list(p)
    d1 = [(a-b)/(2*h) for a, b in zip(L((p[0], p[1]+h, p[2]-h)), L((p[0], p[1]-h, p[2]+h)))]
    d2 = [(a-b)/(2*h) for a, b in zip(L((p[0]-h, p[1]+h/2, p[2]+h/2)), L((p[0]+h, p[1]-h/2, p[2]-h/2)))]
    n = [d1[1]*d2[2]-d1[2]*d2[1], d1[2]*d2[0]-d1[0]*d2[2], d1[0]*d2[1]-d1[1]*d2[0]]
    s = math.sqrt(sum(t*t for t in n)); return [t/s for t in n]

out = []
for p in [(.9, .05, .05), (.901, .08, .019), (.902, .049, .049)]:
    out.append('L(C_%s) = %s   normal %s' % (p, [round(t, 6) for t in L(p)], [round(t, 4) for t in normal(p)]))
mixed = 0; tot = 0; rows = []; mins = []
for i2 in range(1, 40):
    for i3 in range(1, 40):
        p2, p3 = i2*0.005, i3*0.005
        if p2+p3 > 0.2: continue
        p = (1-p2-p3, p2, p3)
        n = normal(p)
        tot += 1; mins.append(min(abs(t) for t in n))
        if not (all(t > 0 for t in n) or all(t < 0 for t in n)):
            mixed += 1; rows.append((round(p2, 3), round(p3, 3), [round(t, 3) for t in n]))
out.append('grid near e1 (p2,p3 multiples of .005, p2+p3<=.2): %d points, %d with mixed-sign normal' % (tot, mixed))
out.append('smallest |normal component| over the grid: %.4f' % min(mins))
out += [str(r) for r in rows[:40]]
print('\n'.join(out))
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 't2_Lsurface.out'), 'w').write('\n'.join(out)+'\n')
