"""Exact / interval verdicts of the greedy rule G and the additive-first rule AF on records
between selected models.  Every verdict is returned only when certified; otherwise '?'."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
import mpmath
from mpmath import iv
from geom import *
from records import joint_cells, record_data
from anchors import anchor_set, clip2, q3

def lohi(x): return mpmath.mpf(x._mpi_[0]), mpmath.mpf(x._mpi_[1])
def pos(x): return lohi(x)[0] > 0
def negv(x): return lohi(x)[1] < 0
def rat_bounds(x):
    lo, hi = lohi(x)
    return F(mpmath.nstr(lo, 30, min_fixed=-50, max_fixed=50)) - F(1, 10**25), \
           F(mpmath.nstr(hi, 30, min_fixed=-50, max_fixed=50)) + F(1, 10**25)

class Rec:
    def __init__(self, x, y):
        self.x, self.y = x, y
        cells = joint_cells([x, y])
        d = record_data(x, y, True, cells)
        self.P, self.Q, self.Phi, self.add = d['P'], d['Q'], d['Phi'], d['add']
        # exact nullity of Q_i: no cell where y has a lower world-i rank than x
        self.Qnull = []
        for i in range(3):
            self.Qnull.append(all(rank(advice(y, interior(c)), interior(c), i) >= rank(advice(x, interior(c)), interior(c), i) for c in cells))
        self.polys, _ = anchor_set(x, y)

    def greedy(self, i):
        """True/False/None(undecided): i in W_G."""
        if negv(self.Phi[i]): return False
        if not pos(self.Phi[i]): return None
        lo = [rat_bounds(t)[0] for t in self.Phi]; hi = [rat_bounds(t)[1] for t in self.Phi]
        def feasible(strict):
            for k, poly in self.polys.items():
                if not poly: continue
                pl = poly
                for j in range(3):
                    if j == i or not pl: continue
                    # q_i Phi_i - q_j Phi_j >= 0, with Phi_i -> lo/hi, Phi_j -> hi/lo
                    ci, cj = (lo[i], hi[j]) if strict else (hi[i], lo[j])
                    c = [F(0)]*3; c[i] += ci; c[j] -= cj
                    pl = clip2(pl, (c[0]-c[2], c[1]-c[2], c[2]))
                if pl: return True
            return False
        if feasible(True): return True
        if not feasible(False): return False
        return None

    def af(self, i):
        if pos(self.add[i]) or self.Qnull[i]: return True
        if all(negv(t) for t in self.add):
            return True if pos(self.Phi[i]) else (False if negv(self.Phi[i]) else None)
        if negv(self.add[i]) and any(pos(t) for t in self.add): return False
        return None

def related(x, y, i, rule, cache):
    """x <=_i y under rule (identity, guidance, or allocation)."""
    if x == y: return True
    key = (x, y)
    if key not in cache: cache[key] = Rec(x, y)
    r = cache[key]
    if r.Qnull[i]: return True
    return r.greedy(i) if rule == 'G' else r.af(i)

def certify_violation(x, y, z, i, rule, cache=None):
    cache = {} if cache is None else cache
    xy = related(x, y, i, rule, cache); yz = related(y, z, i, rule, cache)
    zx = related(z, x, i, rule, cache); xz = related(x, z, i, rule, cache)
    return dict(xy=xy, yz=yz, zx=zx, xz=xz, violation=(xy is True and yz is True and zx is True and xz is False))
