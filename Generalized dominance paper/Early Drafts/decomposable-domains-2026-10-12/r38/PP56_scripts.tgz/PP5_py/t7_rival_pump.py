"""A forced sticky record and an anchored return record: exact instance (CHECKED).

p = a = (9/10,1/20,1/20), q = (901/1000,51/1000,48/1000).  Regions are cones with exact rational
rays inside cells of the arrangement of K_a, K_q, the diagonal and the coordinate planes, so the
advice of C_a and C_q is constant on each; masses are interval-certified.
  Y = C_a except advice A on S1 (in M1), S2 (in M2), S3 (in M3), all silent for C_a, A for C_q.
  Z = C_a except advice B on T (in M1, silent for both C_a and C_q).
Claims checked:
  (i)  rec(C_a,Y): every additive balance < 0, Phi_1 > 0 > Phi_2, Phi_3; a in A(rec), so every
       allocation from the eligible pool must accept it at world 1 (and AF does);
  (ii) rec(Y,Z): q in A(rec) (C_q = Y on S1,S2,S3,T); add_1 > 0, so AF accepts it at world 1;
       the greedy score at the witness q also picks world 1; add_2, add_3 > 0 (eligible elsewhere);
  (iii) Z is a pointwise strict world-1 improvement of C_a, so Z <_1 C_a strictly.
Hence C_a <=_1 Y <=_1 Z <_1 C_a under AF and under G: (TC) fails at world 1."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
import mpmath
from mpmath import iv
from geom import *
from anchors import DIAG

def lohi(x): return mpmath.mpf(x._mpi_[0]), mpmath.mpf(x._mpi_[1])
def s(x): lo, hi = lohi(x); return '[%s, %s]' % (mpmath.nstr(lo, 8), mpmath.nstr(hi, 8))
def sgn(x):
    lo, hi = lohi(x); return '+' if lo > 0 else ('-' if hi < 0 else '?')

def lab(g, adv):
    sg = [1 if t > 0 else -1 for t in g]
    if abs(sum(sg)) == 3: return 'U', None
    w = [i for i in range(3) if sg[i] != (1 if sum(sg) > 0 else -1)][0]
    maj = tuple(-t if sum(sg) < 0 else t for t in g)
    if adv == '0': return w, 'S'
    acc = g if adv == '+' else tuple(-t for t in g)
    return w, ('A' if acc == maj else 'B')

def rk(w, l, i):
    if i != w: return {'A': 0, 'S': 1, 'B': 2}[l]
    return {'A': 2, 'S': 1, 'B': 0}[l]

a = (F(9,10), F(1,20), F(1,20)); q = (F(901,1000), F(51,1000), F(48,1000))
cells = arrangement(list(dict.fromkeys(normals(a)+normals(q)+DIAG)))
def rep(c):  # one representative per antipodal pair
    g = interior(c)
    for t in g:
        if t != 0: return t > 0
    return True
cand = {}
for c in cells:
    if not rep(c): continue
    g = interior(c)
    w, la = lab(g, advice(a, g)); _, lq = lab(g, advice(q, g))
    cand.setdefault((w, la, lq), []).append(c)

def tris(c):
    return [(c[0], c[j], c[j+1]) for j in range(1, len(c)-1)]

def pmass(tri):  # mu-mass of the problems represented by the cone (cone and its antipode)
    return 2*mass_iv(list(tri))

def carve(cells_, target):
    """sub-cones of the given cells with total mu-mass just above 'target' (float), exact rays."""
    out, tot = [], iv.mpf(0)
    for c in cells_:
        for (r0, r1, r2) in tris(c):
            m = pmass((r0, r1, r2))
            if lohi(tot + m)[1] <= target:
                out.append((r0, r1, r2)); tot += m; continue
            # bisect t in [0,1] for the sub-triangle (r0, r1, (1-t) r1 + t r2)
            lo_t, hi_t = F(0), F(1)
            for _ in range(40):
                mid = (lo_t + hi_t)/2
                v = prim(tuple((1-mid)*r1[k] + mid*r2[k] for k in range(3)))
                mm = pmass((r0, r1, v))
                if lohi(tot + mm)[1] < target: lo_t = mid
                else: hi_t = mid
            v = prim(tuple((1-hi_t)*r1[k] + hi_t*r2[k] for k in range(3)))
            out.append((r0, r1, v)); tot += pmass((r0, r1, v))
            return out, tot
    return out, tot

out = []
pr = lambda *x: (print(*x), out.append(' '.join(str(t) for t in x)))
avail = {k: sum((pmass(t) for c in v for t in tris(c)), iv.mpf(0)) for k, v in cand.items()}
for k in [(0, 'S', 'A'), (1, 'S', 'A'), (2, 'S', 'A'), (0, 'S', 'S')]:
    pr('available', k, s(avail[k]))
m2 = float(lohi(avail[(1, 'S', 'A')])[0]) * 0.9
S2, M2 = carve(cand[(1, 'S', 'A')], m2)
S1, M1 = carve(cand[(0, 'S', 'A')], m2/0.75)        # m2 = m3 = 0.75 m1
S3, M3 = carve(cand[(2, 'S', 'A')], m2)
T, MT = carve(cand[(0, 'S', 'S')], m2*0.05)
pr('masses: m1 =', s(M1), ' m2 =', s(M2), ' m3 =', s(M3), ' tau =', s(MT))
# regions with (class, old, new) labels for the two records
R1 = [(0, 'S', 'A', M1), (1, 'S', 'A', M2), (2, 'S', 'A', M3)]                       # C_a -> Y
R2 = [(0, 'A', 'S', M1), (1, 'A', 'S', M2), (2, 'A', 'S', M3), (0, 'S', 'B', MT)]    # Y -> Z
def verdicts(R):
    P = [iv.mpf(0)]*3; Q = [iv.mpf(0)]*3
    for (w, o, n, m) in R:
        for i in range(3):
            d = rk(w, n, i) - rk(w, o, i)
            if d > 0: P[i] += d*m
            if d < 0: Q[i] += (-d)*m
    return [2*P[i]-Q[i] for i in range(3)], [P[i]-Q[i] for i in range(3)]
Phi1, add1 = verdicts(R1); Phi2, add2 = verdicts(R2)
pr('rec(C_a,Y): Phi =', [s(t) for t in Phi1], [sgn(t) for t in Phi1], ' add =', [sgn(t) for t in add1])
pr('rec(Y,Z):   Phi =', [s(t) for t in Phi2], [sgn(t) for t in Phi2], ' add =', [s(t) for t in add2], [sgn(t) for t in add2])
qi = [iv.mpf(t.numerator)/t.denominator for t in q]
sc = [qi[i]*Phi2[i] for i in range(3)]
pr('greedy scores of rec(Y,Z) at the witness q:', [s(t) for t in sc], ' world 1 maximal:',
   sgn(sc[0]-sc[1]) == '+' and sgn(sc[0]-sc[2]) == '+')
# anchor check: C_q advice on every region of D(Y,Z) equals Y's advice (labels taken from cells)
ok = all(lab(interior(list(t)), advice(q, interior(list(t))))[1] == 'A' for t in S1+S2+S3) and \
     all(lab(interior(list(t)), advice(q, interior(list(t))))[1] == 'S' for t in T)
okC = all(lab(interior(list(t)), advice(a, interior(list(t))))[1] == 'S' for t in S1+S2+S3+T)
pr('C_q agrees with Y on D(Y,Z) (q in A(rec(Y,Z))):', ok, '; C_a silent on all regions:', okC)
pr('Z vs C_a at world 1: Z differs only on T (class M1, S -> B), rank 1 -> 0: strict pointwise improvement')
pr('forced: eligible worlds for rec(C_a,Y) =', [i+1 for i in range(3) if sgn(Phi1[i]) == '+'])
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 't7_rival_pump.out'), 'w').write('\n'.join(out)+'\n')
