"""Certify (exact anchors, interval masses) a few greedy-rule violations from the scans."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from exact_rules import *
from fractions import Fraction as F
trip = [((F(95,100),F(1,100),F(4,100)), (F(96,100),F(3,100),F(1,100)), (F(96,100),F(1,100),F(3,100))),
        ((F(94,100),F(1,100),F(5,100)), (F(95,100),F(4,100),F(1,100)), (F(96,100),F(1,100),F(3,100))),
        ((F(9,10),F(5,100),F(5,100)), (F(901,1000),F(8,100),F(19,1000)), (F(902,1000),F(49,1000),F(49,1000)))]
out = []
cache = {}
for (x, y, z) in trip:
    for rule in ['G', 'AF']:
        r = certify_violation(x, y, z, 0, rule, cache)
        line = 'world 1, rule %s, x=%s y=%s z=%s: x<=y %s, y<=z %s, z<=x %s, x<=z %s -> certified violation: %s' % (
            rule, tuple(map(str, x)), tuple(map(str, y)), tuple(map(str, z)), r['xy'], r['yz'], r['zx'], r['xz'], r['violation'])
        print(line); out.append(line)
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 't4_certify_grid.out'), 'w').write('\n'.join(out)+'\n')
