import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from tc_analyse import *
name = sys.argv[1]
D = dict(np.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'scan_%s.npz' % name)))
pts = D['pts']; N = len(pts)
out = []
pr = lambda *a: (print(*a), out.append(' '.join(str(x) for x in a)))
off = ~np.eye(N, dtype=bool)
pr('scan', name, 'models', N, 'ordered pairs', N*(N-1))
pr('anchor sets: max diameter %.3g, any touching the boundary: %s' % (D['diam'].max(), D['bd'].any()))
pr('pairs whose anchor set is (numerically) the source point: %d' % ((D['diam'] < 1e-9) & off).sum())
sticky = (D['Add'].max(axis=2) <= 0) & off
pr('selected pairs with every additive balance <= 0 (sticky branch): %d' % sticky.sum())
# greedy W statistics
W = D['WG']
pr('greedy: records with W empty (excluding guidance-only at some world): %d' % ((~W.any(axis=2)) & off).sum())
stickyacc = W & (D['Add'] < 0) & (D['Phi'] >= 0)
pr('greedy: (record, world) acceptances that are sticky-only (Phi>=0>add): %d, of which world 1: %d' % (stickyacc.sum(), stickyacc[:, :, 0].sum()))
for rule in ['G', 'AF']:
    R = relations(D, rule)
    V = violations(R)
    pr('rule %s: (TC)-violating (x,z) pairs per world: %s' % (rule, [v[0] for v in V]))
    for i in range(3):
        for (x, y, z) in V[i][1][:3]:
            pr('   world %d: x=%s y=%s z=%s' % (i+1, tuple(pts[x]), tuple(pts[y]), tuple(pts[z])))
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 't3_%s.out' % name), 'w').write('\n'.join(out)+'\n')
