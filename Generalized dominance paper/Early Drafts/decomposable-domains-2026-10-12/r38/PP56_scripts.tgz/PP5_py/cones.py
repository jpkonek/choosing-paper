"""Method 2: nu(P_i), nu(Q_i) as signed sums of Gaussian masses of convex polyhedral cones.
  nu(P_i) = 2[ g(H_i & A_x) - g(H_i & A_x & A_y) ] + 2[ g(H_i & -A_y) - g(H_i & -A_y & -A_x) ]
with H_i = {g_i > 0}, A_p = {V_j(p).g > 0}, g = standard Gaussian probability."""
from geom import *
from mpmath import iv

E = [(1,0,0),(0,1,0),(0,0,1)]

def cone_mass(halfspaces, use_iv):
    pieces = convex_cone(halfspaces)
    if use_iv:
        s = iv.mpf(0)
        for c in pieces: s += mass_iv(c)
    else:
        s = 0.0
        for c in pieces: s += mass_float(c)
    return s

def neg(ns):
    return [tuple(-t for t in n) for n in ns]

def nuPQ(x, y, use_iv=True):
    Nx, Ny = normals(x), normals(y)
    P, Q = [], []
    for i in range(3):
        H = [E[i]]
        gx = cone_mass(H+Nx, use_iv); gy = cone_mass(H+Ny, use_iv)
        gxy = cone_mass(H+Nx+Ny, use_iv)
        hx = cone_mass(H+neg(Nx), use_iv); hy = cone_mass(H+neg(Ny), use_iv)
        hxy = cone_mass(H+neg(Nx)+neg(Ny), use_iv)
        P.append(2*(gx-gxy) + 2*(hy-hxy))
        Q.append(2*(gy-gxy) + 2*(hx-hxy))
    return P, Q

def phi_add(x, y, use_iv=True):
    P, Q = nuPQ(x, y, use_iv)
    return [2*P[i]-Q[i] for i in range(3)], [P[i]-Q[i] for i in range(3)], P, Q
