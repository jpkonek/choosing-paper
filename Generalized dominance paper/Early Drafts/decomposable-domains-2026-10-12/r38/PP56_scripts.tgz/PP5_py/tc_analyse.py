"""(TC) among scanned selected models under several allocation rules (NUMERICS)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np

GTOL = 1e-12

def relations(D, rule, extra=None):
    Phi, Add, Q, WG = D['Phi'], D['Add'], D['Q'], D['WG']
    N = Phi.shape[0]
    eye = np.eye(N, dtype=bool)
    R = []
    for i in range(3):
        guid = (Q[:, :, i] <= GTOL) & ~eye
        if rule == 'G':
            acc = WG[:, :, i].copy()
        elif rule == 'AF':
            sticky = (Add.max(axis=2) <= 0)
            acc = (Add[:, :, i] >= 0) | ((Phi[:, :, i] >= 0) & sticky)
        elif rule == 'G_rep':
            acc = WG[:, :, i].copy()
            for (mask, w) in extra:          # records reassigned to world w only
                acc[mask] = (i == w)
        elif rule == 'src':                  # source-weighted argmax only
            acc = WG[:, :, i].copy()
        else:
            raise ValueError
        R.append(eye | guid | (acc & ~eye))
    return R

def violations(R, limit=10):
    out = []
    for i in range(3):
        A = R[i].astype(np.int64)
        S = R[i] & ~R[i].T
        two = (A @ A) > 0          # x ~> z via some y
        bad = two & S.T            # S[z,x]
        np.fill_diagonal(bad, False)
        xs, zs = np.nonzero(bad)
        ex = []
        for x, z in list(zip(xs, zs))[:limit]:
            ys = np.nonzero(R[i][x] & R[i][:, z])[0]
            ys = [y for y in ys if y != x and y != z]
            if ys: ex.append((x, ys[0], z))
        out.append((len(xs), ex))
    return out
