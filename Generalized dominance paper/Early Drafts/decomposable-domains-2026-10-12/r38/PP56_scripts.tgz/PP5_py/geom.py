"""PP5 shared geometry: the family K_p = p + 3 eps min(p) (Delta - u), C_p = D_{K_p}.

Conventions (as in the r9 notes):
  * a problem is {g,-g}, g in R^3 standard Gaussian; mu = law of {g,-g} (total mass 1);
  * C_p accepts g iff P_p(g) > 0, i.e. iff V_j(p).g > 0 for the three vertices V_j(p) of K_p;
    so the acceptance set A_p is the open simplicial cone with facet normals V_j(p);
  * world-i rank of a model at a problem: orient h = g with h_i > 0; rank 0 if h accepted
    (good), 2 if -h accepted (bad), 1 if silent, 3 if both (never for D_K);
  * rank steps U_i(X) = {(g,j): r_i(g,X) >= j}; nu = mu x counting on j in {1,2,3};
  * for d = rec(X,Y): P_i = U_i(Y)\\U_i(X) (steps Y adds), Q_i = U_i(X)\\U_i(Y);
    Phi_i = 2 nu(P_i) - nu(Q_i);  add_i = nu(P_i) - nu(Q_i) (unweighted additive balance).
Exact objects are integer/Fraction vectors; masses are solid angles / (4 pi), evaluated
either in floating point (scans) or in mpmath interval arithmetic (certificates).
"""
from fractions import Fraction as F
from math import gcd
import math

EPS = F(3, 10)

# ---------------------------------------------------------------- exact vectors
def dot(a, b):
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]

def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])

def det3(a, b, c):
    return dot(a, cross(b, c))

def prim(v):
    """primitive integer vector in the direction of a rational vector v (v != 0)."""
    den = 1
    for x in v:
        x = F(x)
        den = den*x.denominator//gcd(den, x.denominator)
    w = [int(F(x)*den) for x in v]
    g = 0
    for x in w:
        g = gcd(g, abs(x))
    return tuple(x//g for x in w)

def verts(p, eps=EPS):
    """the three vertices of K_p (exact Fractions)."""
    p = [F(x) for x in p]
    m = min(p)
    out = []
    for j in range(3):
        out.append(tuple(p[i] - eps*m + (3*eps*m if i == j else 0) for i in range(3)))
    return out

def normals(p, eps=EPS):
    """integer facet normals of the acceptance cone A_p (directions of the vertices)."""
    return [prim(v) for v in verts(p, eps)]

def lowprev(p, g, eps=EPS):
    p = [F(x) for x in p]
    m = min(p)
    return dot(p, g) + eps*m*(3*min(g) - sum(g))

def advice(p, g, eps=EPS):
    """'+' accept g, '-' accept -g, '0' silent (g need not be normalised; exact)."""
    if min(p) == 0:
        s = dot([F(x) for x in p], g)
        return '+' if s > 0 else ('-' if s < 0 else '0')
    ns = normals(p, eps)
    s = [dot(n, g) for n in ns]
    if all(x > 0 for x in s):
        return '+'
    if all(x < 0 for x in s):
        return '-'
    return '0'

def rank(adv, g, i):
    """world-i rank of advice adv ('+','-','0') at problem g (g_i != 0)."""
    if adv == '0':
        return 1
    good = (adv == '+') == (g[i] > 0)
    return 0 if good else 2

# ---------------------------------------------------------------- cone clipping
def clip(poly, n):
    """split convex cone (cyclic list of integer rays) by the plane n.g = 0.
    returns (positive part, negative part); parts with < 3 rays are None."""
    s = [dot(n, v) for v in poly]
    pos, neg = [], []
    k = len(poly)
    for a in range(k):
        b = (a+1) % k
        va, vb, sa, sb = poly[a], poly[b], s[a], s[b]
        if sa >= 0:
            pos.append(va)
        if sa <= 0:
            neg.append(va)
        if (sa > 0 and sb < 0) or (sa < 0 and sb > 0):
            w = tuple(sa*vb[t] - sb*va[t] for t in range(3))
            if sa < 0:
                w = tuple(-x for x in w)
            w = prim(w)
            pos.append(w)
            neg.append(w)
    return clean(pos), clean(neg)

def clean(poly):
    if len(poly) < 3:
        return None
    out = []
    for v in poly:
        if not out or prim(v) != prim(out[-1]):
            out.append(v)
    if len(out) > 1 and prim(out[0]) == prim(out[-1]):
        out.pop()
    if len(out) < 3:
        return None
    # non-degenerate: some triple with nonzero determinant
    v0 = out[0]
    for a in range(1, len(out)-1):
        if det3(v0, out[a], out[a+1]) != 0:
            return out
    return None

OCTANTS = []
for sx in (1, -1):
    for sy in (1, -1):
        for sz in (1, -1):
            e = [(sx, 0, 0), (0, sy, 0), (0, 0, sz)]
            if sx*sy*sz < 0:
                e = [e[0], e[2], e[1]]
            OCTANTS.append(e)

def arrangement(planes):
    """all full-dimensional cells of the central arrangement of the given planes
    together with the three coordinate planes (exact)."""
    cells = [list(o) for o in OCTANTS]
    for n in planes:
        new = []
        for c in cells:
            a, b = clip(c, n)
            if a is not None:
                new.append(a)
            if b is not None:
                new.append(b)
        cells = new
    return cells

def interior(poly):
    return tuple(sum(v[t] for v in poly) for t in range(3))

def convex_cone(halfspaces, start=None):
    """the cone {g : n.g > 0 for n in halfspaces} intersected with 'start' (a cone),
    as a cyclic ray list, or None if empty/lower-dimensional."""
    cells = [list(o) for o in OCTANTS] if start is None else [list(start)]
    for n in halfspaces:
        new = []
        for c in cells:
            a, _ = clip(c, n)
            if a is not None:
                new.append(a)
        cells = new
        if not cells:
            break
    return cells  # list of convex pieces (one per octant when start is None)

# ---------------------------------------------------------------- solid angles
def tri_angle_float(a, b, c):
    na, nb, nc = (math.sqrt(dot(x, x)) for x in (a, b, c))
    num = abs(det3(a, b, c))
    den = na*nb*nc + dot(a, b)*nc + dot(a, c)*nb + dot(b, c)*na
    return 2*math.atan2(num, den)

def solid_float(poly):
    P = [tuple(float(x) for x in v) for v in poly]
    return sum(tri_angle_float(P[0], P[k], P[k+1]) for k in range(1, len(P)-1))

def mass_float(poly):
    return solid_float(poly)/(4*math.pi)

try:
    import mpmath
    from mpmath import iv
    iv.dps = 40

    def tri_angle_iv(a, b, c):
        num = abs(det3(a, b, c))          # exact integer
        if num == 0:
            return iv.mpf(0)
        na, nb, nc = (iv.sqrt(iv.mpf(dot(x, x))) for x in (a, b, c))
        den = na*nb*nc + dot(a, b)*nc + dot(a, c)*nb + dot(b, c)*na
        # Van Oosterom-Strackee: Omega = 2 atan2(|det|, den), with num > 0 (mpi_atan2)
        return 2*iv.atan2(iv.mpf(num), den)

    def solid_iv(poly):
        s = iv.mpf(0)
        for k in range(1, len(poly)-1):
            s += tri_angle_iv(poly[0], poly[k], poly[k+1])
        return s

    def mass_iv(poly):
        return solid_iv(poly)/(4*iv.pi)
except ImportError:  # pragma: no cover
    pass
