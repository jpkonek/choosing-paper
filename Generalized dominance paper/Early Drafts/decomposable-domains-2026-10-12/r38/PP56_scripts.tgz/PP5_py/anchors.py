"""Exact anchor sets A(d) = {q : a_{C_q} = a_X a.e. on the changed set D} for d = rec(X,Y),
X, Y selected (or any models given by an advice function on cells).

On a cell of the arrangement {V_j(x).g=0, V_j(y).g=0, g_j=g_k, g_i=0}, argmin g and argmax g
are fixed, so P_q(g) = q.g + eps q_k (3 min g - sum g) is linear in g on the closed cell and
linear in q on the q-chamber {q_k = min q}.  Matching X's advice a.e. on the cell is therefore
a finite set of weak linear inequalities in q, one per extreme ray of the cell (PROVED in the
note, section 3).  A(d) is the union over k of the resulting exact polygons."""
from fractions import Fraction as F
from geom import *

DIAG = [(1, -1, 0), (1, 0, -1), (0, 1, -1)]

def lin_lowprev(r, k, sign, eps=EPS):
    """coefficients c (in R^3) with P_q(sign*r) = c.q on chamber k."""
    if sign > 0:
        c = [F(t) for t in r]; c[k] += eps*(3*min(r) - sum(r))
    else:
        c = [F(-t) for t in r]; c[k] += eps*(sum(r) - 3*max(r))
    return c

def to2d(c, rhs=0):
    """c.q >= rhs on the simplex q=(q1,q2,1-q1-q2) -> (A1,A2,B) with A1 q1 + A2 q2 + B >= 0."""
    return (c[0]-c[2], c[1]-c[2], c[2]-rhs)

def clip2(poly, h):
    A1, A2, B = h
    val = [A1*v[0] + A2*v[1] + B for v in poly]
    out = []
    n = len(poly)
    for i in range(n):
        j = (i+1) % n
        vi, vj, si, sj = poly[i], poly[j], val[i], val[j]
        if si >= 0:
            out.append(vi)
        if (si > 0 and sj < 0) or (si < 0 and sj > 0):
            t = si/(si-sj)
            out.append((vi[0]+t*(vj[0]-vi[0]), vi[1]+t*(vj[1]-vi[1])))
    # dedupe
    res = []
    for v in out:
        if not res or v != res[-1]:
            res.append(v)
    if len(res) > 1 and res[0] == res[-1]:
        res.pop()
    return res

def chamber(k):
    poly = [(F(0), F(0)), (F(1), F(0)), (F(0), F(1))]   # simplex in (q1,q2)
    for j in range(3):
        if j != k:
            c = [F(0)]*3; c[j] += 1; c[k] -= 1     # q_j - q_k >= 0
            poly = clip2(poly, to2d(c))
    return poly

def constraints(x, y, cells=None):
    """list over chambers k of the halfplanes defining A(d) in chamber k, d = rec(C_x, C_y)."""
    if cells is None:
        pl = list(dict.fromkeys(normals(x) + normals(y) + DIAG))
        cells = arrangement(pl)
    H = {0: [], 1: [], 2: []}
    nD = 0
    for c in cells:
        g = interior(c)
        ax, ay = advice(x, g), advice(y, g)
        if ax == ay:
            continue
        nD += 1
        for r in c:
            for k in range(3):
                if ax == '+':
                    H[k].append(to2d(lin_lowprev(r, k, +1)))
                elif ax == '-':
                    H[k].append(to2d(lin_lowprev(r, k, -1)))
                else:
                    for s in (+1, -1):
                        cc = lin_lowprev(r, k, s)
                        H[k].append(to2d([-t for t in cc]))      # P_q(s r) <= 0
    for k in H:
        H[k] = list(dict.fromkeys(H[k]))
    return H, nD

def anchor_set(x, y, cells=None):
    H, nD = constraints(x, y, cells)
    polys = {}
    for k in range(3):
        poly = chamber(k)
        for h in H[k]:
            if not poly:
                break
            poly = clip2(poly, h)
        polys[k] = poly
    return polys, H

def q3(v):
    return (v[0], v[1], 1-v[0]-v[1])

def faces_met(polys):
    """nonempty I such that A(d) meets the closed face Delta_I (exact)."""
    pts = [q3(v) for k in polys for v in polys[k]]
    out = []
    for I in [(0,), (1,), (2,), (0, 1), (0, 2), (1, 2), (0, 1, 2)]:
        if any(all(q[j] == 0 for j in range(3) if j not in I) for q in pts):
            out.append(I)
    # a convex polygon meets a closed face iff one of its vertices lies on it, for faces that
    # are vertices/edges of the simplex (supporting sets); the full face is met iff nonempty.
    return out

def eligible_greedy_float(polys, Phi):
    """worlds i accepted by audit's greedy rule: Phi_i >= 0 and some q in A(d) with
    q_i Phi_i >= q_j Phi_j for all j (floating Phi; exact polygons)."""
    W = []
    for i in range(3):
        if Phi[i] < 0:
            continue
        ok = False
        for k in polys:
            poly = [(float(v[0]), float(v[1])) for v in polys[k]]
            if not poly:
                continue
            for j in range(3):
                if j == i:
                    continue
                c = [0.0]*3; c[i] += Phi[i]; c[j] -= Phi[j]
                poly = clip2f(poly, (c[0]-c[2], c[1]-c[2], c[2]))
                if not poly:
                    break
            if poly:
                ok = True; break
        if ok:
            W.append(i)
    return W

def clip2f(poly, h, tol=0.0):
    A1, A2, B = h
    val = [A1*v[0] + A2*v[1] + B for v in poly]
    out = []
    n = len(poly)
    for i in range(n):
        j = (i+1) % n
        vi, vj, si, sj = poly[i], poly[j], val[i], val[j]
        if si >= -tol:
            out.append(vi)
        if (si > tol and sj < -tol) or (si < -tol and sj > tol):
            t = si/(si-sj)
            out.append((vi[0]+t*(vj[0]-vi[0]), vi[1]+t*(vj[1]-vi[1])))
    return out
