"""Records between selected models, by exact cell enumeration (method 1)."""
from fractions import Fraction as F
from geom import *
from mpmath import iv

def joint_cells(models, extra=()):
    planes = []
    for p in models:
        if min(p) > 0:
            planes += normals(p)
        else:
            planes.append(prim([F(x) for x in p]))
    planes += list(extra)
    # remove duplicates
    seen, pl = set(), []
    for n in planes:
        k = prim(n)
        if k not in seen and tuple(-x for x in k) not in seen:
            seen.add(k); pl.append(k)
    return arrangement(pl)

def record_data(x, y, use_iv=True, cells=None):
    """returns dict with transition masses and per-world nu(P), nu(Q), Phi, add."""
    if cells is None:
        cells = joint_cells([x, y])
    M = (lambda c: mass_iv(c)) if use_iv else (lambda c: mass_float(c))
    zero = iv.mpf(0) if use_iv else 0.0
    trans = {}
    P = [zero]*3; Q = [zero]*3
    total = zero
    for c in cells:
        g = interior(c)
        m = M(c)
        total += m
        ax, ay = advice(x, g), advice(y, g)
        if ax != ay:
            # transition label as seen by orientation with g_1>0 (just for reporting)
            key = (ax, ay) if g[0] > 0 else ({'+':'-','-':'+','0':'0'}[ax], {'+':'-','-':'+','0':'0'}[ay])
            trans[key] = trans.get(key, zero) + m
        for i in range(3):
            rx, ry = rank(ax, g, i), rank(ay, g, i)
            if ry > rx:
                P[i] += (ry-rx)*m
            elif rx > ry:
                Q[i] += (rx-ry)*m
    Phi = [2*P[i]-Q[i] for i in range(3)]
    add = [P[i]-Q[i] for i in range(3)]
    return dict(P=P, Q=Q, Phi=Phi, add=add, trans=trans, total=total, ncells=len(cells))
