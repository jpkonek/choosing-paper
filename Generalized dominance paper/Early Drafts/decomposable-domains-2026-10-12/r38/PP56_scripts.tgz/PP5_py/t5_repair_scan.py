"""Audit's local repair: W = {3} on the rho-ball of radius eta around rec(C_a,C_b), W = {2} on the
rho-ball around rec(C_b,C_c); greedy elsewhere.  (TC) among the 226 local selected models.
NUMERICS (exact cones, double-precision masses); violations reported are re-certified in t6."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from fast import Model, rho
from tc_analyse import relations, violations
here = os.path.dirname(os.path.abspath(__file__))
D = dict(np.load(os.path.join(here, 'scan_local.npz')))
pts = [tuple(p) for p in D['pts']]; N = len(pts)
M = [Model(p) for p in pts]
idx = {tuple(round(t, 6) for t in p): k for k, p in enumerate(pts)}
ia, ib, ic = idx[(0.9, 0.05, 0.05)], idx[(0.901, 0.08, 0.019)], idx[(0.902, 0.049, 0.049)]
out = []
pr = lambda *a: (print(*a), out.append(' '.join(str(x) for x in a)))
def near(k, r): return [j for j in range(N) if max(abs(pts[j][t]-pts[k][t]) for t in range(3)) <= r + 1e-12]
balls = {}
for (s, t, w) in [(ia, ib, 2), (ib, ic, 1)]:
    rows = []
    for x in near(s, 0.0091):
        for y in near(t, 0.0091):
            if x != y: rows.append((x, y, rho(M[x], M[y], M[s], M[t])))
    balls[(s, t, w)] = rows
    pr('record (%s,%s): %d nearby selected records examined; rho range %.4g..%.4g' % (pts[s], pts[t], len(rows), min(r[2] for r in rows), max(r[2] for r in rows)))
base = violations(relations(D, 'G'))
pr('greedy G: violating (x,z) pairs per world', [v[0] for v in base])
for eta in [0.001, 0.0025, 0.005]:
    extra = []
    for (s, t, w), rows in balls.items():
        mask = np.zeros((N, N), dtype=bool)
        for (x, y, r) in rows:
            if r <= eta: mask[x, y] = True
        # eligibility on the ball: Phi_w >= 0 required
        ok = all(D['Phi'][x, y, w] >= 0 for x, y in zip(*np.nonzero(mask)))
        extra.append((mask, w))
        pr('  eta=%.4f: ball around (%s->%s) contains %d scanned records, world %d eligible on all: %s' % (eta, s, t, mask.sum(), w+1, ok))
    R = relations(D, 'G_rep', extra)
    V = violations(R, limit=2000)
    pr('  G_rep eta=%.4f: violating (x,z) pairs per world %s' % (eta, [v[0] for v in V]))
    # does the diagnostic triple survive?  new violations at worlds 2,3 involving the balls?
    Rg = relations(D, 'G')
    diag = R[0][ia, ib] and R[0][ib, ic] and (R[0][ic, ia] and not R[0][ia, ic])
    pr('  diagnostic triple still violating at world 1:', bool(diag))
    for i in range(3):
        S = R[i] & ~R[i].T
        A = R[i].astype(np.int64)
        bad = ((A @ A) > 0) & S.T
        Sg = Rg[i] & ~Rg[i].T
        Ag = Rg[i].astype(np.int64)
        badg = ((Ag @ Ag) > 0) & Sg.T
        new = bad & ~badg
        np.fill_diagonal(new, False)
        pr('    world %d: violating (x,z) pairs not present under G: %d' % (i+1, new.sum()))
        for x, z in list(zip(*np.nonzero(new)))[:3]:
            ys = [y for y in np.nonzero(R[i][x] & R[i][:, z])[0] if y not in (x, z)]
            pr('      x=%s y=%s z=%s' % (pts[x], pts[ys[0]], pts[z]))
open(os.path.join(here, 't5_repair_scan.out'), 'w').write('\n'.join(out)+'\n')
