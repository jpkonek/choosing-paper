"""Certify (exact anchors, interval masses) the forbidden triples created by audit's local repair.
Under the repair, world 1 refuses rec(C_a,C_b) and rec(C_b,C_c) (assigned to worlds 3 and 2);
everything else is the greedy rule G.  A refused mixed record makes its reverse strict at world 1."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from exact_rules import *
from fractions import Fraction as F
a = (F(9,10), F(1,20), F(1,20)); b = (F(901,1000), F(8,100), F(19,1000)); c = (F(902,1000), F(49,1000), F(49,1000))
y1 = (F(898,1000), F(47,1000), F(55,1000)); y2 = (F(907,1000), F(44,1000), F(49,1000))
cache = {}
out = []
def pr(*x): print(*x); out.append(' '.join(str(t) for t in x))
for (x, y, z, w) in [(a, y1, b, 2), (b, y2, c, 1)]:
    xy = related(x, y, 0, 'G', cache); yz = related(y, z, 0, 'G', cache); zx = related(z, x, 0, 'G', cache)
    rxz = cache.setdefault((x, z), Rec(x, z))
    pr('x=%s y=%s z=%s' % tuple(tuple(map(str, t)) for t in (x, y, z)))
    pr('  G at world 1: x<=y %s, y<=z %s, z<=x %s' % (xy, yz, zx))
    pr('  rec(x,z) is guidance at world 1: %s; its greedy world-1 verdict %s; repair moves it to world %d (Phi_%d sign %s)'
       % (rxz.Qnull[0], rxz.greedy(0), w+1, w+1, '+' if pos(rxz.Phi[w]) else '?'))
    pr('  -> under the repair x<=_1 y<=_1 z and z <_1 x: certified violation:', xy is True and yz is True and zx is True and not rxz.Qnull[0])
    r = cache[(z, x)]
    pr('  rec(z,x): guidance at world 1 %s, Phi_1 %s, add_1 %s' % (r.Qnull[0], '+' if pos(r.Phi[0]) else '-', '+' if pos(r.add[0]) else '-'))
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 't6_certify_repair.out'), 'w').write('\n'.join(out)+'\n')
