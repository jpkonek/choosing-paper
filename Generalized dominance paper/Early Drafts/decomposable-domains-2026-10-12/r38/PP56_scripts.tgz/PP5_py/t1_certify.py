"""Task A.1: certify audit's diagnostic (AUDIT_anchor_plan.md section 6) at eps = 3/10.
Exact cone geometry (integer rays), interval arithmetic for solid angles (mpmath.iv, 40 digits).
Two independent evaluations of every mass: cell enumeration (records.py) and signed sums of
convex-cone masses (cones.py)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from mpmath import iv, mpf, nstr
from geom import *
from records import record_data, joint_cells
from cones import phi_add
from anchors import anchor_set, faces_met, q3

a = (F(9,10), F(5,100), F(5,100)); b = (F(901,1000), F(8,100), F(19,1000)); c = (F(902,1000), F(49,1000), F(49,1000))
names = {a: 'a', b: 'b', c: 'c'}

import mpmath
def lohi(x):
    return mpmath.mpf(x._mpi_[0]), mpmath.mpf(x._mpi_[1])

def s(x, d=10):
    lo, hi = lohi(x)
    return '[%s, %s]' % (nstr(lo, d), nstr(hi, d))

def sign(x):
    lo, hi = lohi(x)
    if lo > 0: return '+'
    if hi < 0: return '-'
    return '?'

def ivF(q):
    return iv.mpf(q.numerator)/iv.mpf(q.denominator)

def cls_label(g, adv):
    """class M_w of a mixed problem and its regular advice A/S/B; 'U' for unanimous."""
    sg = [1 if t > 0 else -1 for t in g]
    if abs(sum(sg)) == 3: return 'U', None
    w = [i for i in range(3) if sg[i] != (1 if sum(sg) > 0 else -1)][0]
    maj = tuple(-t if sum(sg) < 0 else t for t in g)   # orientation good for the majority
    if adv == '0': lab = 'S'
    else:
        accepted = g if adv == '+' else tuple(-t for t in g)
        lab = 'A' if accepted == maj else 'B'
    return 'M%d' % (w+1), lab

out = []
def pr(*args):
    line = ' '.join(str(x) for x in args); print(line); out.append(line)

pr('eps =', EPS)
for p in (a, b, c):
    pr('K_%s vertices:' % names[p], [tuple(str(t) for t in v) for v in verts(p)])

res = {}
for (x, y) in [(a, b), (b, c), (a, c), (c, a)]:
    nm = 'rec(C_%s,C_%s)' % (names[x], names[y])
    cells = joint_cells([x, y])
    d1 = record_data(x, y, True, cells)
    Phi2, add2, P2, Q2 = phi_add(x, y, True)
    res[(x, y)] = (d1, Phi2, add2, P2, Q2)
    pr('\n==', nm, ' cells:', d1['ncells'], ' total mass', s(d1['total'], 15))
    for i in range(3):
        pr('  world %d: nu(P)=%s nu(Q)=%s' % (i+1, s(d1['P'][i]), s(d1['Q'][i])))
        pr('           Phi =%s (method 2: %s) sign %s' % (s(d1['Phi'][i]), s(Phi2[i]), sign(Phi2[i])))
        pr('           add =%s sign %s' % (s(d1['add'][i]), sign(add2[i])))
        # agreement of the two methods
        lo, hi = lohi(d1['Phi'][i]-Phi2[i]); assert lo <= 0 <= hi
    # transitions by class
    tr = {}
    for cc in cells:
        g = interior(cc)
        ax, ay = advice(x, g), advice(y, g)
        if ax == ay: continue
        k1, l1 = cls_label(g, ax); k2, l2 = cls_label(g, ay)
        key = (k1, l1 + '->' + l2)
        tr[key] = tr.get(key, iv.mpf(0)) + mass_iv(cc)
    for key in sorted(tr):
        pr('    %s %s : mu = %s' % (key[0], key[1], s(tr[key], 8)))
    sil = sum((tr[k] for k in tr if k[1].startswith('S')), iv.mpf(0))
    pr('    mass of changed problems where the old model is silent: %s' % s(sil, 8))
    res[(x, y)] = res[(x, y)] + (sil,)

pr('\n== world-weighted greedy scores, source as witness')
for (x, y) in [(a, b), (b, c)]:
    Phi = res[(x, y)][1]
    sc = [ivF(x[i])*Phi[i] for i in range(3)]
    pr('rec(C_%s,C_%s): source*Phi =' % (names[x], names[y]), [s(t, 8) for t in sc])
    for i in range(3):
        if i != 0:
            pr('   x_1 Phi_1 - x_%d Phi_%d = %s  sign %s' % (i+1, i+1, s(sc[0]-sc[i], 8), sign(sc[0]-sc[i])))

pr('\n== exact anchor sets A(d)')
for (x, y) in [(a, b), (b, c), (a, c), (c, a), (b, a), (c, b)]:
    polys, H = anchor_set(x, y)
    verts_ = sorted(set(q3(v) for k in polys for v in polys[k]))
    pr('A(rec(C_%s,C_%s)) vertices:' % (names[x], names[y]), [tuple(str(t) for t in v) for v in verts_],
       ' faces met:', [tuple(i+1 for i in I) for I in faces_met(polys)])

pr('\n== C_c vs C_a at world 1 (exact, every cell of the joint arrangement)')
cells = joint_cells([a, c])
worse = 0; better = iv.mpf(0)
for cc in cells:
    g = interior(cc)
    ra, rc = rank(advice(a, g), g, 0), rank(advice(c, g), g, 0)
    if rc > ra: worse += 1
    if rc < ra: better += mass_iv(cc)
pr('cells where C_c has a higher world-1 rank than C_a:', worse)
pr('mass where C_c has a lower world-1 rank: %s' % s(better))

with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 't1_certify.out'), 'w') as f:
    f.write('\n'.join(out) + '\n')
