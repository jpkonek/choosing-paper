"""Scans of (TC) among selected models near e1 (NUMERICS; exact cone geometry, double-precision
solid angles).  Usage: python3 -I scan.py <name>  with name in {grid, local}."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fast import *
import numpy as np, time, pickle

name = sys.argv[1]
if name == 'grid':
    pts = [(round(1-i2*0.01-i3*0.01, 6), round(i2*0.01, 6), round(i3*0.01, 6))
           for i2 in range(1, 15) for i3 in range(1, 15) if i2+i3 <= 15]
elif name == 'local':
    pts = [(round(1-(0.044+0.003*i)-(0.013+0.003*j), 6), round(0.044+0.003*i, 6), round(0.013+0.003*j, 6))
           for i in range(15) for j in range(15)]
    pts += [(0.9, 0.05, 0.05), (0.902, 0.049, 0.049)]
else:
    raise SystemExit
M = [Model(p) for p in pts]
N = len(M)
Phi = np.zeros((N, N, 3)); Add = np.zeros((N, N, 3)); Qm = np.zeros((N, N, 3))
WG = np.zeros((N, N, 3), dtype=bool); diam = np.zeros((N, N)); bd = np.zeros((N, N), dtype=bool)
t = time.time()
for x in range(N):
    for y in range(N):
        if x == y: continue
        P, Q = PQ(M[x], M[y])
        ph = [2*P[i]-Q[i] for i in range(3)]
        Phi[x, y] = ph; Add[x, y] = [P[i]-Q[i] for i in range(3)]; Qm[x, y] = Q
        pol = anchor_polys(M[x], M[y])
        diam[x, y] = poly_diam(pol); bd[x, y] = bool(touches_boundary(pol))
        for i in greedy_W(pol, ph, M[x].p):
            WG[x, y, i] = True
    if x % 20 == 0: print(x, N, round(time.time()-t, 1), flush=True)
np.savez(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'scan_%s.npz' % name),
         pts=np.array(pts), Phi=Phi, Add=Add, Q=Qm, WG=WG, diam=diam, bd=bd)
print('done', N, time.time()-t)
