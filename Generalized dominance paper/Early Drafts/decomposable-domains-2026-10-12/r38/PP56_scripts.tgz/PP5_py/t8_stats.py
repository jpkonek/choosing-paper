"""Robustness margins for the AF scan and a structural check on the greedy violations (NUMERICS)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from tc_analyse import relations
here = os.path.dirname(os.path.abspath(__file__))
out = []
pr = lambda *a: (print(*a), out.append(' '.join(str(x) for x in a)))
for name in ['grid', 'local']:
    D = dict(np.load(os.path.join(here, 'scan_%s.npz' % name)))
    N = len(D['pts']); off = ~np.eye(N, dtype=bool)
    A = D['Add']
    mx = A.max(axis=2)[off]; sc = np.abs(A).max(axis=2)[off]
    pr('%s: min over pairs of max_j add_j = %.3e ; min relative margin max_j add_j / max_j |add_j| = %.3f' % (name, mx.min(), (mx/sc).min()))
    # every greedy violation uses a sticky-only link?
    R = relations(D, 'G')[0]
    sticky = D['WG'][:, :, 0] & (A[:, :, 0] < 0) & (D['Q'][:, :, 0] > 1e-12)
    nonsticky = R & ~sticky
    S = R & ~R.T
    Ai = R.astype(np.int64); An = nonsticky.astype(np.int64)
    bad_all = ((Ai @ Ai) > 0) & S.T
    bad_ns = ((An @ An) > 0) & S.T
    np.fill_diagonal(bad_all, False); np.fill_diagonal(bad_ns, False)
    pr('   greedy world-1 violating (x,z) pairs: %d; of these, realisable with two non-sticky links: %d' % (bad_all.sum(), bad_ns.sum()))
    # two-sided sticky acceptance (both directions accepted at world 1, one of them sticky)
    both = R & R.T & off
    pr('   greedy: pairs accepted in both directions at world 1: %d (unordered)' % (both.sum()//2))
    T = N*(N-1)*(N-2)
    pr('   ordered triples of distinct models: %d' % T)
open(os.path.join(here, 't8_stats.out'), 'w').write('\n'.join(out)+'\n')
