"""Floating-point versions for scans (same formulas as cones.py / anchors.py).
Exact cone geometry, double-precision solid angles; scan results are NUMERICS and every
violation reported in the note is re-certified with cones.py/anchors.py in interval/exact form."""
import math
EPSf = 0.3
TOL = 1e-13

def dot(a, b): return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def nrm(v):
    s = math.sqrt(dot(v, v)); return (v[0]/s, v[1]/s, v[2]/s)

def verts(p, eps=EPSf):
    m = min(p)
    return [tuple(p[i]-eps*m+(3*eps*m if i == j else 0.0) for i in range(3)) for j in range(3)]

def rays_of(ns):
    """extreme rays of the simplicial cone {n_j.g > 0}, cyclic."""
    r = []
    for k in range(3):
        i, j = (k+1) % 3, (k+2) % 3
        v = cross(ns[i], ns[j])
        if dot(ns[k], v) < 0: v = (-v[0], -v[1], -v[2])
        r.append(nrm(v))
    return r

def clip(poly, n):
    s = [dot(n, v) for v in poly]
    out = []
    k = len(poly)
    for a in range(k):
        b = (a+1) % k
        sa, sb = s[a], s[b]
        if sa >= -TOL: out.append(poly[a])
        if (sa > TOL and sb < -TOL) or (sa < -TOL and sb > TOL):
            va, vb = poly[a], poly[b]
            w = (sa*vb[0]-sb*va[0], sa*vb[1]-sb*va[1], sa*vb[2]-sb*va[2])
            if sa < 0: w = (-w[0], -w[1], -w[2])
            out.append(nrm(w))
    return out if len(out) >= 3 else None

def tri(a, b, c):
    num = abs(dot(a, cross(b, c)))
    den = 1.0 + dot(a, b) + dot(a, c) + dot(b, c)   # unit vectors
    return 2*math.atan2(num, den)

def mass(poly):
    if poly is None: return 0.0
    return sum(tri(poly[0], poly[k], poly[k+1]) for k in range(1, len(poly)-1))/(4*math.pi)

E = [(1.0, 0, 0), (0, 1.0, 0), (0, 0, 1.0)]

class Model:
    def __init__(self, p):
        self.p = tuple(float(x) for x in p)
        self.V = [nrm(v) for v in verts(self.p)]
        self.nV = [(-v[0], -v[1], -v[2]) for v in self.V]
        self.R = rays_of(self.V)                      # rays of A_p
        self.nR = [(-r[0], -r[1], -r[2]) for r in self.R]  # rays of -A_p
        self.g = [mass(clip(self.R, E[i])) for i in range(3)]    # gamma(H_i & A_p)
        self.h = [mass(clip(self.nR, E[i])) for i in range(3)]   # gamma(H_i & -A_p)

def inter(R, extra):
    poly = R
    for n in extra:
        poly = clip(poly, n)
        if poly is None: return None
    return poly

def PQ(X, Y):
    P, Q = [], []
    for i in range(3):
        gxy = mass(inter(X.R, [E[i]]+Y.V))
        hxy = mass(inter(X.nR, [E[i]]+Y.nV))
        P.append(2*(X.g[i]-gxy) + 2*(Y.h[i]-hxy))
        Q.append(2*(Y.g[i]-gxy) + 2*(X.h[i]-hxy))
    return P, Q

# ---------------------------------------------------------------- float anchors
OCT = []
for sx in (1, -1):
    for sy in (1, -1):
        for sz in (1, -1):
            e = [(float(sx), 0.0, 0.0), (0.0, float(sy), 0.0), (0.0, 0.0, float(sz))]
            if sx*sy*sz < 0: e = [e[0], e[2], e[1]]
            OCT.append(e)
DIAG = [nrm((1.0, -1.0, 0.0)), nrm((1.0, 0.0, -1.0)), nrm((0.0, 1.0, -1.0))]

def clip2(poly, n):
    s = [dot(n, v) for v in poly]
    pos, neg = [], []
    k = len(poly)
    for a in range(k):
        b = (a+1) % k
        sa, sb = s[a], s[b]
        if sa >= -TOL: pos.append(poly[a])
        if sa <= TOL: neg.append(poly[a])
        if (sa > TOL and sb < -TOL) or (sa < -TOL and sb > TOL):
            va, vb = poly[a], poly[b]
            w = (sa*vb[0]-sb*va[0], sa*vb[1]-sb*va[1], sa*vb[2]-sb*va[2])
            if sa < 0: w = (-w[0], -w[1], -w[2])
            w = nrm(w); pos.append(w); neg.append(w)
    return (pos if len(pos) >= 3 and mass(pos) > 1e-15 else None,
            neg if len(neg) >= 3 and mass(neg) > 1e-15 else None)

def arrangement(planes):
    cells = [list(o) for o in OCT]
    for n in planes:
        new = []
        for c in cells:
            a, b = clip2(c, n)
            if a: new.append(a)
            if b: new.append(b)
        cells = new
    return cells

def adv(X, g):
    s = [dot(v, g) for v in X.V]
    if min(s) > 0: return '+'
    if max(s) < 0: return '-'
    return '0'

def lin(r, k, sign, eps=EPSf):
    if sign > 0:
        c = list(r); c[k] += eps*(3*min(r)-sum(r))
    else:
        c = [-t for t in r]; c[k] += eps*(sum(r)-3*max(r))
    return c

def clip2d(poly, h, tol=1e-12):
    A1, A2, B = h
    val = [A1*v[0]+A2*v[1]+B for v in poly]
    out = []
    n = len(poly)
    for i in range(n):
        j = (i+1) % n
        vi, vj, si, sj = poly[i], poly[j], val[i], val[j]
        if si >= -tol: out.append(vi)
        if (si > tol and sj < -tol) or (si < -tol and sj > tol):
            t = si/(si-sj)
            out.append((vi[0]+t*(vj[0]-vi[0]), vi[1]+t*(vj[1]-vi[1])))
    return out

def chamber(k):
    poly = [(0.0, 0.0), (1.0, 0.0), (0.0, 1.0)]
    for j in range(3):
        if j != k:
            c = [0.0]*3; c[j] += 1; c[k] -= 1
            poly = clip2d(poly, (c[0]-c[2], c[1]-c[2], c[2]))
    return poly

def anchor_polys(X, Y):
    cells = arrangement(X.V + Y.V + DIAG)
    H = {0: [], 1: [], 2: []}
    for c in cells:
        g = tuple(sum(v[t] for v in c) for t in range(3))
        ax, ay = adv(X, g), adv(Y, g)
        if ax == ay: continue
        for r in c:
            for k in range(3):
                if ax == '+': cs = [lin(r, k, 1)]
                elif ax == '-': cs = [lin(r, k, -1)]
                else: cs = [[-t for t in lin(r, k, 1)], [-t for t in lin(r, k, -1)]]
                for cc in cs:
                    s = math.sqrt(sum(t*t for t in cc))
                    H[k].append(((cc[0]-cc[2])/s, (cc[1]-cc[2])/s, cc[2]/s))
    polys = {}
    for k in range(3):
        poly = chamber(k)
        for h in H[k]:
            poly = clip2d(poly, h)
            if not poly: break
        polys[k] = poly
    return polys

def greedy_W(polys, Phi, src):
    W = []
    for i in range(3):
        if Phi[i] < 0: continue
        ok = all(src[i]*Phi[i] >= src[j]*Phi[j] - 1e-15 for j in range(3))
        if not ok:
            for k in polys:
                poly = polys[k]
                for j in range(3):
                    if j == i or not poly: continue
                    c = [0.0]*3; c[i] += Phi[i]; c[j] -= Phi[j]
                    poly = clip2d(poly, (c[0]-c[2], c[1]-c[2], c[2]), tol=1e-15)
                if poly: ok = True; break
        if ok: W.append(i)
    return W

def poly_diam(polys):
    pts = [v for k in polys for v in polys[k]]
    if not pts: return 0.0
    return max(math.hypot(u[0]-v[0], u[1]-v[1]) for u in pts for v in pts)

def touches_boundary(polys, tol=1e-9):
    pts = [(v[0], v[1], 1-v[0]-v[1]) for k in polys for v in polys[k]]
    return [i for i in range(3) if any(q[i] < tol for q in pts)]

# ---------------------------------------------------------------- record distance
def rho(X, Y, A, B):
    """mu{ labels of rec(X,Y) != labels of rec(A,B) }, label = (old,new) on the changed set,
    'none' off it; labels are advice of the problem {g,-g} read at the representative g."""
    cells = arrangement(X.V + Y.V + A.V + B.V)
    s = 0.0
    for c in cells:
        g = tuple(sum(v[t] for v in c) for t in range(3))
        l1 = (adv(X, g), adv(Y, g)); l2 = (adv(A, g), adv(B, g))
        l1 = l1 if l1[0] != l1[1] else None
        l2 = l2 if l2[0] != l2[1] else None
        if l1 != l2: s += mass(c)
    return s  # cells cover R^3 and problems are {g,-g}: mass over R^3 = mu-mass
