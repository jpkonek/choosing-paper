# II1 Prop 6.1: in the plain posterior family, for an open set of pairs h, the region of indices p at which C_p
# gives advice O (accept -h) is bordered by the silence region S along pieces of TWO DISTINCT lines of aff(Delta),
# with no M-region nearby.  (Exact rational arithmetic; advice computed from the definition C_p = {g : p.g in D_T1}.)
# Consequence (PROVED in the note): no finite-level additive lexicographic base has C_p(h) lexicographically
# p-optimal (even weakly) for all p in int(Delta) and a.e. h.
from fractions import Fraction as F

def accepts(p, g, eps):
    c0 = (1 - eps) / 3
    q = [p[k] * g[k] for k in range(3)]
    if all(x >= 0 for x in q) and any(x > 0 for x in q):
        return True
    return all(c0 * sum(q) + eps * q[k] > 0 for k in range(3))

def advice(p, h, eps):
    a, b = accepts(p, h, eps), accepts(p, [-x for x in h], eps)
    return 'X' if (a and b) else ('M' if a else ('O' if b else 'S'))

def g(p, h, lam, k):           # g_k(p) = p.h + lam p_k h_k
    return sum(p[i] * h[i] for i in range(3)) + lam * p[k] * h[k]

def point_on_line(h, lam, k, p1):
    # p = (p1, p2, 1-p1-p2) with g_k(p) = 0, solved exactly for p2 (h: odd world index 2)
    # g_k is affine in p2: g_k = A + B p2
    base = [p1, F(0), 1 - p1]
    one = [p1, F(1), -p1]
    A = g(base, h, lam, k)
    B = g(one, h, lam, k) - A
    if B == 0:
        return None
    p2 = -A / B
    p = [p1, p2, 1 - p1 - p2]
    return p if all(x > 0 for x in p) else None

ok = True
for eps in [F(1, 20), F(3, 10), F(1, 2), F(9, 10)]:
    c0 = (1 - eps) / 3
    lam = eps / c0
    found = {}
    for h in [[F(3), F(1), F(-2)], [F(3), F(1), F(-1, 5)], [F(5), F(1), F(-1, 10)], [F(10), F(1), F(-1, 20)]]:
        found = {}
        for k, other in [(0, 1), (1, 0)]:
            for n in range(1, 400):
                p1 = F(n, 400)
                p = point_on_line(h, lam, k, p1)
                if p is None:
                    continue
                if g(p, h, lam, other) < 0 and g(p, h, lam, 2) < 0:   # other O-constraint strict, M false
                    found[k] = p
                    break
        if len(found) == 2:
            break
    if len(found) < 2:
        print(f"eps={eps}: interface pieces not found"); ok = False; continue
    lines_distinct = g(found[0], h, lam, 1) != 0
    print(f"eps={eps}: lam={lam}, h={[str(x) for x in h]}")
    for k in (0, 1):
        p = found[k]
        # normal direction to the line g_k = 0 inside aff(Delta): move along (1,-1,0) or (0,1,-1)
        sides = []
        for d in ([F(1), F(-1), F(0)], [F(0), F(1), F(-1)]):
            eta = F(1, 10**6)
            pa = [p[i] + eta * d[i] for i in range(3)]
            pb = [p[i] - eta * d[i] for i in range(3)]
            sa, sb = advice(pa, h, eps), advice(pb, h, eps)
            if {sa, sb} == {'O', 'S'}:
                sides = [sa, sb]; break
        print(f"   on line g_{k+1}=0 at p={p}: advice on the two sides {sides}; advice at p: {advice(p, h, eps)}")
        ok = ok and sides != []
    print(f"   the two lines are distinct: {lines_distinct}")
    ok = ok and lines_distinct
print("ALL CHECKS PASSED" if ok else "FAILURE")
