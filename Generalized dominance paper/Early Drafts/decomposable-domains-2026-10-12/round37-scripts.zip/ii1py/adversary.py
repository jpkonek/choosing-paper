# II1 Theorem 3.3 / Corollary 3.5: the explicit adversarial family, on an atomic surrogate (exact arithmetic).
#
# Two cells of mixed pairs, both with majority orientation h = (+,+,-) (odd world o = 3), each of mu-mass 1.
# Advice: M (accept h), S (silence), O (accept -h), X (both).  World ranks: worlds 1,2: M < S < O < X;
# world 3: O < S < M < X.  Tables give phi_i(cell, advice) (leading) and psi_i(cell, advice) (lower).
#   cell A: C(h) = S, and the arrow S -> M is Phi-blind at all three worlds (good~silence zeros at 1,2 and a
#           bad~silence zero at 3); at the lower level it improves worlds 1,2 and worsens world 3.
#   cell B: C(h) = M, and the arrow M -> S has leading increment (1,1,-1): C pays an improvable world-3 cost.
# Checks:
#  (1) phi weakly guiding, psi strictly guiding (each world, each cell);
#  (2) C's advice is the a.e.-unique (strict) lexicographic u-Bayes advice in both cells, u = (1/3,1/3,1/3)
#      (so C is undominated in the base and lexicographically competitive);
#  (3) v := (S->M on all of A) has Phi(v) = 0, I(v) = {3}; s := (M->S on B) has Phi_3(s) < 0;
#  (4) the family X_delta := C + v + delta*s has mu(supp) >= 1 and r(u, X_delta) = (1-delta)/delta -> infinity.
from fractions import Fraction as F

ADV = ['M', 'S', 'O', 'X']
RANK = {1: ['M', 'S', 'O', 'X'], 2: ['M', 'S', 'O', 'X'], 3: ['O', 'S', 'M', 'X']}   # best first
phi = {
    'A': {1: dict(M=0, S=0, O=1, X=2), 2: dict(M=0, S=0, O=1, X=2), 3: dict(M=1, S=1, O=0, X=2)},
    'B': {1: dict(M=0, S=1, O=2, X=3), 2: dict(M=0, S=1, O=2, X=3), 3: dict(M=1, S=0, O=-1, X=2)},
}
psi = {
    'A': {1: dict(M=-1, S=0, O=1, X=2), 2: dict(M=-1, S=0, O=1, X=2), 3: dict(M=3, S=0, O=-1, X=4)},
    'B': {1: dict(M=-1, S=0, O=1, X=2), 2: dict(M=-1, S=0, O=1, X=2), 3: dict(M=1, S=0, O=-1, X=2)},
}
C = {'A': 'S', 'B': 'M'}
u = {1: F(1, 3), 2: F(1, 3), 3: F(1, 3)}

# (1) guidance
for c in 'AB':
    for i in (1, 2, 3):
        r = RANK[i]
        for a, b in zip(r, r[1:]):
            assert phi[c][i][a] <= phi[c][i][b], (c, i, a, b)       # weak
            assert psi[c][i][a] < psi[c][i][b], (c, i, a, b)        # strict
print("(1) phi weakly guiding, psi strictly guiding: OK")

# (2) strict lexicographic u-Bayes
for c in 'AB':
    a = C[c]
    for b in ADV:
        if b == a:
            continue
        dphi = sum(u[i] * (phi[c][i][b] - phi[c][i][a]) for i in (1, 2, 3))
        dpsi = sum(u[i] * (psi[c][i][b] - psi[c][i][a]) for i in (1, 2, 3))
        assert dphi > 0 or (dphi == 0 and dpsi > 0), (c, a, b, dphi, dpsi)
        print(f"   cell {c}: {a}->{b}: u.dphi={dphi}, u.dpsi={dpsi}")
print("(2) C is the strict lexicographic u-Bayes advice in both cells: OK")

def inc(level, c, a, b, mass):
    return {i: mass * (level[c][i][b] - level[c][i][a]) for i in (1, 2, 3)}

# (3)
vPhi, vPsi = inc(phi, 'A', 'S', 'M', 1), inc(psi, 'A', 'S', 'M', 1)
sPhi, sPsi = inc(phi, 'B', 'M', 'S', 1), inc(psi, 'B', 'M', 'S', 1)
I = [i for i in (1, 2, 3) if vPhi[i] == 0 and vPsi[i] >= 0]
print("(3) Phi(v) =", vPhi, " Psi(v) =", vPsi, " I(v) =", I, " Phi(s) =", sPhi)
assert all(vPhi[i] == 0 for i in (1, 2, 3)) and I == [3] and sPhi[3] < 0

def r_i(ph, ps):
    if ph == 0 and ps >= 0:
        return F(0)
    if ph > 0:
        return max(F(0), -ps / ph)
    return None   # infinity

# (4)
print("(4) adversarial family X_delta = C + v + delta s:")
prev = F(-1)
for n in range(1, 9):
    d = F(1, 10**n)
    Ph = {i: vPhi[i] + d * sPhi[i] for i in (1, 2, 3)}
    Ps = {i: vPsi[i] + d * sPsi[i] for i in (1, 2, 3)}
    rs = [r_i(Ph[i], Ps[i]) for i in (1, 2, 3)]
    fin = [x for x in rs if x is not None]
    rmin = min(fin) if fin else None
    m = 1 + d
    print(f"   delta=1e-{n}: mu(supp)={m}, r_1={rs[0]}, r_2={rs[1]}, r_3={'inf' if rs[2] is None else rs[2]},"
          f" r=min={rmin}")
    assert rs[2] is None and rmin == (1 - d) / d and rmin > prev and m >= 1
    prev = rmin
print("ALL CHECKS PASSED: r -> infinity at mu(supp) >= 1, so no continuous rate makes C competitive")
