# II1 Part A, Prop 2.1(ii)-(iii): exact arithmetic for the rate rule
#   accept t at world i  iff  Phi(t) >= 0 and Psi(t) + k(m) Phi(t) >= 0,   m = mu(supp t).
# (ii)  a FIXED record, restricted proportionally (Phi, Psi, m all scaled by theta), is judged
#       lexicographically once theta is small: here k(m) = 1/m, record (Phi, Psi) = (a0, 2 a0 - m0).
# (iii) NOT uniformly: at every scale m there is a record with leading increment a = mu(E) > 0 and
#       lower increment 2a - m (worsening on E charged at both levels, blind improvement on F, m = mu(E)+mu(F))
#       that the lexicographic order accepts and the rate rule rejects, whenever 0 < a < m/(k(m)+2).
from fractions import Fraction as F

def k(m):
    return 1 / m

def rate_accepts(phi, psi, m):
    return phi >= 0 and psi + k(m) * phi >= 0

def lex_accepts(phi, psi):
    return phi > 0 or (phi == 0 and psi >= 0)

print("(iii) one bad record at every scale m: a = m/(k(m)+3)")
for m in [F(1), F(1, 2), F(1, 10), F(1, 1000), F(1, 10**6)]:
    a = m / (k(m) + 3)
    phi, psi = a, 2 * a - m
    print(f"  m={m}: a={a}, a/m={a/m}, Phi={phi}, Psi={psi}, Psi+k*Phi={psi + k(m)*phi},"
          f" lex={lex_accepts(phi, psi)}, rate={rate_accepts(phi, psi, m)}")
    assert lex_accepts(phi, psi) and not rate_accepts(phi, psi, m)

print("(ii) a fixed record, proportional restrictions theta: lexicographic verdict for small theta")
a0, m0 = F(1, 100), F(1)
phi0, psi0 = a0, 2 * a0 - m0
thr = None
for n in range(0, 12):
    theta = F(1, 2**n)
    v = rate_accepts(theta * phi0, theta * psi0, theta * m0)
    print(f"  theta=1/2^{n}: rate verdict {v}, lex verdict {lex_accepts(theta*phi0, theta*psi0)}")
    if v and thr is None:
        thr = theta
# exact threshold: k(theta m0) >= (m0 - 2 a0)/a0  <=>  theta <= a0/(m0 (m0 - 2 a0))   for k(m)=1/m
print("  exact threshold theta_0 =", a0 / (m0 * (m0 - 2 * a0)), "; first accepted dyadic theta =", thr)
assert thr is not None and thr <= a0 / (m0 * (m0 - 2 * a0))
print("ALL CHECKS PASSED")
