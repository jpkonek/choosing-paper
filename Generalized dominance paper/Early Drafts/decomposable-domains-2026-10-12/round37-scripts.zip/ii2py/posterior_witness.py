# II2, Corollary 4.3 and Theorem 4.1 step 4: exact inputs for the plain posterior family (Fractions only).
#
# Plain posterior family: C_q = {g : q (.) g in D_T1}, i.e. accept g iff min_k v_k.(q (.) g) > 0, where
# v_k = c0*1 + eps*e_k, c0 = (1-eps)/3.  A pair is indexed by its majority orientation h (two positive coordinates,
# one negative: the odd world).  Advice: M (accept h only), S (neither), O (accept -h only).
#
# Check A (non-null O and S regions inside the near-coordinate cone, for q -> e_j):
#   For every ordered pair (i, j) of distinct worlds, every eps in EPS, and q along several sequences q -> e_j,
#   exhibit i-odd h with h_i = -1 and 0 < h_j, h_l < eta0 = 1/10 such that
#     (O) C_q accepts -h and not h  (strict inequalities), and
#     (S) C_q accepts neither h nor -h (strict inequalities).
#   Strict inequalities of continuous functions hold on an open neighbourhood, so each region is non-null.
#   Advice is computed TWICE: from the definition (min_k v_k.(q(.)g)) and from the closed form
#     M iff q.h + lam q_o h_o > 0,  O iff q.h + lam max(q_j h_j, q_l h_l) < 0,  lam = eps/c0  (HH2 4.1),
#   and the two must agree.
#   The witnesses are the analytic ones of the note:
#     O: h = (-1 at i, eta at j, eta at l), eta = q_i / (2 (q_j + q_l + lam max(q_j,q_l)));
#     S: same shape, eta = midpoint of ( q_i/(q_j+q_l+lam m), min(q_i(1+lam)/(q_j+q_l), eta0) ), m = max(q_j,q_l).
# Check B (the vertex models): every mixed majority orientation h has, for each world i, a vertex model
#   B^k (k != i) whose advice at h is i-worst among {M,S,O}; B^k accepts the orientation with positive k-th
#   coordinate.  Done over all six mixed sign patterns.
from fractions import Fraction as F
from itertools import permutations

EPS = [F(1, 20), F(3, 10), F(1, 2), F(9, 10)]
ETA0 = F(1, 10)

def vk(eps, k):
    c0 = (1 - eps) / 3
    return [c0 + (eps if m == k else 0) for m in range(3)]

def accepts(q, g, eps):
    qg = [q[m] * g[m] for m in range(3)]
    return min(sum(vk(eps, k)[m] * qg[m] for m in range(3)) for k in range(3)) > 0

def strict_margin(q, g, eps):
    qg = [q[m] * g[m] for m in range(3)]
    return min(sum(vk(eps, k)[m] * qg[m] for m in range(3)) for k in range(3))

def advice_def(q, h, eps):
    a, b = accepts(q, h, eps), accepts(q, [-x for x in h], eps)
    assert not (a and b)
    return 'M' if a else ('O' if b else 'S')

def advice_closed(q, h, eps):
    c0 = (1 - eps) / 3
    lam = eps / c0
    o = [k for k in range(3) if h[k] < 0][0]
    j, l = [k for k in range(3) if k != o]
    qh = sum(q[k] * h[k] for k in range(3))
    if qh + lam * q[o] * h[o] > 0:
        return 'M'
    if qh + lam * max(q[j] * h[j], q[l] * h[l]) < 0:
        return 'O'
    return 'S'

def sequences(j, i):
    l = [k for k in range(3) if k not in (i, j)][0]
    out = []
    for n in [10, 100, 1000, 10**4, 10**6]:
        for (a, b) in [(F(1, n), F(1, n)), (F(1, n), F(1, n * n)), (F(1, n * n), F(1, n))]:
            q = [F(0)] * 3
            q[i], q[l] = a, b
            q[j] = 1 - a - b
            out.append(q)
    return out

fails = 0
count = 0
lines = []
for eps in EPS:
    c0 = (1 - eps) / 3
    lam = eps / c0
    for i, j in permutations(range(3), 2):
        l = [k for k in range(3) if k not in (i, j)][0]
        for q in sequences(j, i):
            m = max(q[j], q[l])
            # O witness
            eta = q[i] / (2 * (q[j] + q[l] + lam * m))
            h = [F(0)] * 3
            h[i], h[j], h[l] = F(-1), eta, eta
            okO = (advice_def(q, h, eps) == 'O' == advice_closed(q, h, eps)) and eta < ETA0 * abs(h[i]) \
                and strict_margin(q, [-x for x in h], eps) > 0 and strict_margin(q, h, eps) < 0
            # S witness
            lo = q[i] / (q[j] + q[l] + lam * m)
            hi = q[i] * (1 + lam) / (q[j] + q[l])
            eta2 = (lo + min(hi, ETA0)) / 2
            h2 = [F(0)] * 3
            h2[i], h2[j], h2[l] = F(-1), eta2, eta2
            okS = (lo < min(hi, ETA0)) and (advice_def(q, h2, eps) == 'S' == advice_closed(q, h2, eps)) \
                and eta2 < ETA0 * abs(h2[i]) \
                and strict_margin(q, h2, eps) < 0 and strict_margin(q, [-x for x in h2], eps) < 0
            count += 1
            if not (okO and okS):
                fails += 1
                lines.append(f"FAIL eps={eps} (i,j)=({i+1},{j+1}) q={q} okO={okO} okS={okS}")
        lines.append(f"eps={eps} (i,j)=({i+1},{j+1}): sample q={sequences(j,i)[3]}, "
                     f"O-witness eta={sequences(j,i)[3][i]/(2*(sequences(j,i)[3][j]+sequences(j,i)[3][l]+lam*max(sequences(j,i)[3][j],sequences(j,i)[3][l])))}")
print("Check A: posterior O- and S-regions meet the cone {h_i<0<h_j,h_l, max(h_j,h_l)<|h_i|/10}")
for s in lines:
    print("  ", s)
print(f"Check A: {count} (eps, i, j, q) cases, {fails} failures")

# Check B
patterns = []
for o in range(3):
    h = [F(1)] * 3
    h[o] = F(-1)
    patterns.append(h)
def best(i, h):
    return 'M' if h[i] > 0 else 'O'
def worst(i, h):
    return 'O' if h[i] > 0 else 'M'
def Badv(k, h):
    return 'M' if h[k] > 0 else 'O'
failB = 0
for h in patterns:
    for i in range(3):
        if not any(Badv(k, h) == worst(i, h) for k in range(3) if k != i):
            failB += 1
        ks = [k + 1 for k in range(3) if k != i and Badv(k, h) == worst(i, h)]
        print(f"Check B: h-pattern {['+' if x>0 else '-' for x in h]}, world {i+1}: i-worst advice "
              f"{worst(i,h)} is given by B^k for k in {ks}")
print(f"Check B: {failB} failures")
