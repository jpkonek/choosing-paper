# II2: exact illustrations of Theorem 2.1 / Corollary 2.3 (SLP gives bounded rates), Theorem 3.1 (segment
# competitors), and the audit's counterexample, on finite-dimensional "zonotope" surrogates.
#
# Surrogate: a selected model C and finitely many disjoint regions R_k of measure 1, each carrying one alternative
# advice.  Switching on a fraction alpha_k of R_k (Lyapunov) gives the record value
#     z = sum_k alpha_k g_k,  with size m(z) = sum_k alpha_k,  alpha in [0,1]^K,
# where g_k = (Phi-increments per unit, Psi-increments per unit).  This is exactly the attainable set of the
# note's Lemma 1.1 when the increments are constant on each region.
# r_i, r = min_i r_i are as in AUDIT_HH_rate.md.  Everything is Fractions; "inf" is a string.
from fractions import Fraction as F
from itertools import combinations, product

INF = 'inf'

def r_world(phi, psi):
    if phi == 0 and psi >= 0:
        return F(0)
    if phi > 0:
        return max(F(0), -psi / phi)
    return INF

def rmin(z, J):
    vals = [r_world(z[0][i], z[1][i]) for i in J]
    fin = [v for v in vals if v != INF]
    return INF if len(fin) == 0 else min(fin)

def comb(gens, alphas):
    n = len(gens[0][0])
    phi = [sum(a * g[0][i] for a, g in zip(alphas, gens)) for i in range(n)]
    psi = [sum(a * g[1][i] for a, g in zip(alphas, gens)) for i in range(n)]
    return (phi, psi)

def show(title):
    print("\n" + "=" * 8 + " " + title)

# ---------------------------------------------------------------------------------------------------------
show("(1) GG1 Lemma 2.2 data: lex-competitive, (star) fails, the segment of Theorem 3.1(a) defeats every rate")
a = ((F(0), F(0)), (F(1), F(-1)))     # (Phi_1,Phi_2), (Psi_1,Psi_2)
b = ((F(0), F(0)), (F(-1), F(1)))
c = ((F(1), F(-2)), (F(0), F(0)))
gens = [a, b, c]
# W^Phi: weights w with w.Phi >= 0 on generators: w1*0+w2*0 (a,b) and w1 - 2 w2 >= 0 (c)  ->  w1 >= 2 w2
# z* = b (Phi = 0, Psi = (-1, 1)): I^>= = {2};  (star) needs e_2 in W^Phi: 0 >= 2 is false.
print("W^Phi = {w : w1 >= 2 w2};  e_2 in W^Phi ?", F(0) - 2 * F(1) >= 0)
for s in [F(1, 10), F(1, 100), F(1, 1000), F(1, 10**6)]:
    z = comb(gens, [F(0), 1 - s, s])
    m = (1 - s) + s
    print(f"s={s}: Phi={z[0]}, Psi={z[1]}, size={m}, r_1={r_world(z[0][0], z[1][0])}, "
          f"r_2={r_world(z[0][1], z[1][1])}, r={rmin(z,[0,1])}  [(1-s)/s = {(1-s)/s}]")
# lex-competitiveness on a grid (exact): no grid point lex-better at both worlds
def lexneg(phi, psi):
    return phi < 0 or (phi == 0 and psi < 0)
bad = 0
grid = [F(k, 12) for k in range(13)]
for al in product(grid, repeat=3):
    z = comb(gens, list(al))
    if lexneg(z[0][0], z[1][0]) and lexneg(z[0][1], z[1][1]):
        bad += 1
print("grid points lex-better at both worlds:", bad, "of", 13 ** 3)

# ---------------------------------------------------------------------------------------------------------
show("(2) three-world surrogate of Theorem 4.1: a jointly blind O->S step at world 3 plus a Phi_3-improvement")
g1 = ((F(0), F(0), F(0)), (F(-1), F(-1), F(2)))   # O->S on 3-odd gambles, Phi-blind at all worlds
g2 = ((F(2), F(2), F(-1)), (F(1), F(1), F(-1)))   # some record improving Phi_3
for s in [F(1, 10), F(1, 100), F(1, 1000), F(1, 10**6)]:
    z = comb([g1, g2], [1 - s, s])
    print(f"s={s}: Phi={z[0]}, Psi={z[1]}, size=1, r=(r_1,r_2,r_3)="
          f"{[r_world(z[0][i], z[1][i]) for i in range(3)]}, min={rmin(z,[0,1,2])}")
print("Every point is lexicographically defended (Phi_1 = 2s > 0), yet min_i r_i = (1-2s)/(2s) -> inf.")

# ---------------------------------------------------------------------------------------------------------
show("(3) strict leading protection (SLP): exact c(a) = min{max_i Phi_i : size >= a} > 0, hence bounded rates")
A = ((F(1), F(-1)), (F(-5), F(3)))
B = ((F(-1), F(2)), (F(4), F(-7)))
# SLP: alpha A + beta B with Phi <= 0 componentwise forces alpha=beta=0.
# LP: minimise t s.t. alpha - beta <= t, -alpha + 2 beta <= t, alpha + beta >= a, 0 <= alpha, beta <= 1.
def lp_min(aa):
    # constraints in the form  coef . (alpha, beta, t) <= rhs
    cons = [((1, -1, -1), 0), ((-1, 2, -1), 0), ((-1, -1, 0), -aa),
            ((-1, 0, 0), 0), ((0, -1, 0), 0), ((1, 0, 0), 1), ((0, 1, 0), 1)]
    best = None
    for tri in combinations(cons, 3):
        M = [[F(x) for x in c_[0]] for c_ in tri]
        rhs = [F(c_[1]) for c_ in tri]
        det = (M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1]) - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0])
               + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0]))
        if det == 0:
            continue
        def rep(col):
            N = [row[:] for row in M]
            for k in range(3):
                N[k][col] = rhs[k]
            return (N[0][0] * (N[1][1] * N[2][2] - N[1][2] * N[2][1]) - N[0][1] * (N[1][0] * N[2][2] - N[1][2] * N[2][0])
                    + N[0][2] * (N[1][0] * N[2][1] - N[1][1] * N[2][0]))
        x = [rep(k) / det for k in range(3)]
        if all(sum(F(cc) * xx for cc, xx in zip(c_[0], x)) <= c_[1] for c_ in cons):
            if best is None or x[2] < best[2]:
                best = x
    return best
E = F(5) + F(4)   # max |Psi_i| over the zonotope is at most |Psi(A)|+|Psi(B)| <= 9 at either world (here 9 and 10)
E = F(10)
for aa in [F(1), F(1, 2), F(1, 10), F(1, 100)]:
    x = lp_min(aa)
    bound = E / x[2]
    # exact sup of r over a rational grid of the feasible set (a lower bound for the true sup)
    supr = F(0)
    N = 60
    for i in range(N + 1):
        for j in range(N + 1):
            al, be = F(i, N), F(j, N)
            if al + be < aa:
                continue
            z = comb([A, B], [al, be])
            rv = rmin(z, [0, 1])
            assert rv != INF
            supr = max(supr, rv)
    print(f"a={aa}: c(a)={x[2]} at (alpha,beta)=({x[0]},{x[1]}); bound E/c(a)={bound}; "
          f"max r on the 61x61 grid = {supr} <= bound: {supr <= bound}")
print("c(a) = a/5 exactly, so the a priori bound E/c(a) = 50/a of Corollary 2.3 grows as a -> 0.  In this")
print("polyhedral surrogate the true supremum is bounded uniformly (r is constant along rays from 0 and the")
print("cone of record values is closed).  In a cover of T1 the true supremum must diverge as a -> 0, since a")
print("constant rate K would make Psi + K Phi a real strictly guiding endorser (HH2 6.1(e), FF2 Thm 4.1).")

# ---------------------------------------------------------------------------------------------------------
show("(4) a non-SLP base satisfying the strong form of (star): blind generator unanimously Psi-worse")
Cg = ((F(0), F(0)), (F(2), F(3)))
# W^Phi from A, B: w1 - w2 >= 0 and -w1 + 2 w2 >= 0: interior weights, support {1,2}; Psi(C) > 0 at both.
for aa in [F(1, 2), F(1, 10)]:
    supr = F(0)
    N = 24
    for i in range(N + 1):
        for j in range(N + 1):
            for k in range(N + 1):
                al, be, ga = F(i, N), F(j, N), F(k, N)
                if al + be + ga < aa:
                    continue
                z = comb([A, B, Cg], [al, be, ga])
                rv = rmin(z, [0, 1])
                assert rv != INF
                supr = max(supr, rv)
    print(f"a={aa}: max r on the 25^3 grid = {supr} (finite, as Theorem 3.1(c) predicts)")

# ---------------------------------------------------------------------------------------------------------
show("(5) the audit's counterexample to HH2 6.1(e), in the r-notation")
for m, k in [(F(1), F(10)), (F(1, 100), F(10**4))]:
    aa = m / (k + 2) / 2
    phi, psi = aa, 2 * aa - m
    print(f"m={m}, k(m)={k}, a={aa}: r = {r_world(phi, psi)} > k(m): {r_world(phi, psi) > k}; "
          f"lexicographically accepted: {phi > 0}")
