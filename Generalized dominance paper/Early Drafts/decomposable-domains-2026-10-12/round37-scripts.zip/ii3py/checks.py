# II3 exact checks (fractions only). Run: python3 -I checks.py  (inside ii3py/)
from fractions import Fraction as F
from itertools import product

def grid(n):
    return [(F(a,n),F(b,n),F(n-a-b,n)) for a in range(n+1) for b in range(n+1-a)]

# (1) Vacuity of HH2 Thm 2.1: (M) on worsening records (C_{e_k}, X_all-cross) forces w_i(X)<=0 for i!=k.
#     With w(X) in Delta this is infeasible; record the forced upper bounds.
def forced_bounds():
    ub=[F(1)]*3
    for k in range(3):
        e=[F(int(i==k)) for i in range(3)]
        for i in range(3):
            ub[i]=min(ub[i],e[i])   # w_i(X) <= (e_k)_i  (lex first level; tie allowed via tau)
    return ub
ub=forced_bounds()
print("(1) upper bounds on w(all-cross):",ub,"sum =",sum(ub),"-> w in Delta infeasible:",sum(ub)<1)

# (2) Repaired scheme: Psi_i(X)=(c(X)-wbar_i(X),tau,G). Check (M) at (C_p, all-cross) for all p on a grid
#     with wbar(cross)=u, c(cross)=1 : need (-p_i,0) <lex (1-1/3,1).
u=(F(1,3),)*3
bad=0
for p in grid(24):
    for i in range(3):
        a=(-p[i],0); b=(F(1)-u[i],1)
        if not a<b: bad+=1
print("(2) repaired (M) failures at (C_p, all-cross), grid 1/24:",bad)

# (3) Covering: for p, wbar in Delta (grid), argmax_k (p-wbar)_k meets supp p.
def covering(n):
    fails=0
    G=grid(n)
    for p in G:
        for w in G:
            d=[p[k]-w[k] for k in range(3)]
            m=max(d)
            if not any(d[k]==m and p[k]>0 for k in range(3)): fails+=1
    return fails,len(G)**2
print("(3) covering failures (grid 1/12):",covering(12))

# (4) KKM point of X is wbar(X): p in all three argmax cones iff p-wbar constant iff p=wbar (both in Delta).
fails=0
for w in grid(12):
    for p in grid(12):
        d=[p[k]-w[k] for k in range(3)]
        inall = all(d[i]==max(d) for i in range(3))
        if inall != (p==w): fails+=1
print("(4) KKM-point characterisation failures:",fails)

# (5) Protection inequality: Y <=_i C_p at all i forces c(Y)-wbar_i(Y) <= -p_i, so sum gives 3c(Y)<=0.
#     (algebraic; recorded) and mixedness of t*=rec(C_u,T1) at every world for several eps:
def PT1(g,eps):
    c0=(1-eps)/3
    return min(c0*sum(g)+eps*g[k] for k in range(3))
for eps in [F(1,20),F(3,10),F(1,2),F(9,10)]:
    found={}
    for h in product([F(x,4) for x in range(-12,13)],repeat=3):
        if sum(h)>0 and PT1(h,eps)<0 and PT1(tuple(-x for x in h),eps)<0 and all(x!=0 for x in h):
            for i in range(3):
                found.setdefault((i,h[i]>0),h)
    ok=all((i,s) in found for i in range(3) for s in (True,False))
    print("(5) eps=%s: C_u accepts, T1 silent, both signs of h_i at every world:"%eps, ok,
          {k:tuple(map(str,v)) for k,v in sorted(found.items())})
