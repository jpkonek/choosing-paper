"""PP18 s1: correctness-threshold zones in audit's six-source module (CHECKED, exact cells).

(a) Audit's relation (sources T, C_i, F_i; all 4,095 rivals on the six A/B cells) satisfies the
    threshold-1 invariant on R_i at both worlds w != i: no installed record moves a rank >= 1 to 0 there.
(b) Lemma Z0 on cells: for X = T[R_i -> majority], every one of the seven sources either violates the
    zone at a world j != i if it were to dominate X, or has exposure failure (its record copies into T).
(c) T's defences against Lambda_T, V_{c*} and T[R_1 u R_2 -> majority]: at every world the record from T
    either is refused by strict (G) or lowers a rank to 0 on a zone cell R_i (i != w).
(d) Threshold-2 illustration: T's w-errors on the W cells, per world (clean-world proposition).
Finite cells cannot test (S); this checks record algebra and the advice table only.
"""
from itertools import product
from lib import *

srcs = [('T', T)] + [('C%d' % (i+1), C[i]) for i in range(3)] + [('F%d' % (i+1), Fm[i]) for i in range(3)]
label = {('C%d' % (i+1)): i for i in range(3)}; label.update({('F%d' % (i+1)): i for i in range(3)})
group = {i: [C[i], Fm[i]] for i in range(3)}

print('advice table (cells):', ' '.join(names))
for n, m in srcs + [('c*', cstar)] + [('V%d' % (i+1), V[i]) for i in range(3)]:
    print('%3s' % n, ' '.join('%s' % a for a in m))

six = [idx[n] for n in ['A1', 'A2', 'A3', 'B1', 'B2', 'B3']]
Rs = [set() for _ in range(3)]
for w in range(3):
    for i in range(3):
        for Sm in group[i]:
            if i == w: Rs[w].add(record(T, Sm))
            else:
                Rs[w].add(record(Sm, T))
                for Q in group[w]: Rs[w].add(record(Sm, Q))
        if i != w: Rs[w].add(record(C[i], Fm[i]))
nriv = 0
for vals in product([S, P, N, X], repeat=6):
    Xm = list(T)
    for k, v in zip(six, vals): Xm[k] = v
    Xm = tuple(Xm)
    if Xm == T: continue
    nriv += 1
    elig = False
    for i in range(3):
        for Sm in group[i]:
            if any(rank(Xm[k], k, i) > rank(T[k], k, i) and rank(Sm[k], k, i) <= rank(T[k], k, i) for k in six):
                elig = True
                for w in range(3): Rs[w].add(record(Sm, Xm))
    assert elig
print('\n(a) rivals', nriv, '; records per world', [len(r) for r in Rs])
def zone_violation(r, w):
    """cells R_i (i != w) where r lowers the world-w rank from >=1 to 0"""
    return [names[k] for k, a, b in r if names[k][0] == 'R' and int(names[k][1]) - 1 != w
            and rank(a, k, w) >= 1 and rank(b, k, w) == 0]
for w in range(3):
    bad = [r for r in Rs[w] if zone_violation(r, w)]
    print('    world %d: installed records violating the threshold-1 zone on R_i (i != w): %d' % (w+1, len(bad)))
    assert not bad

print('\n(b) Lemma Z0 on cells: X = T[R_i -> majority]')
for i in range(3):
    Xi = fill(T, ['R%d' % (i+1)])
    for n, Sm in srcs:
        if Sm == Xi: continue
        r = record(Sm, Xi)
        zv = [w + 1 for w in range(3) if w != i and zone_violation(r, w)]
        D = [k for k, a, b in r]
        exposure = any(Xi[k] != T[k] for k in D)
        if zv:
            msg = 'dominating X would violate the zone at worlds %s' % zv
        else:
            assert not exposure
            Y = tuple(Sm[k] if k in D else T[k] for k in range(len(T)))
            assert record(Y, T) == r and Y != T
            msg = 'zone kept, but exposure fails: (S,X) copies to (Y,T), Y != T, so S dominating X makes Y dominate T'
        print('    i=%d %3s: %s' % (i+1, n, msg))

print('\n(c) T against three rivals')
riv = {'Lambda_T': tuple(MAJ if T[k] == S and names[k] != 'U' else T[k] for k in range(len(T))),
       'V_c*': cstar, 'T[R1uR2->maj]': fill(T, ['R1', 'R2'])}
for n, Xm in riv.items():
    r = record(T, Xm)
    out = []
    for w in range(3):
        if guidance(tuple((k, b, a) for k, a, b in r), w) and not guidance(r, w):
            out.append('w%d: refused by strict (G)' % (w+1))
        else:
            zv = zone_violation(r, w)
            assert zv
            out.append('w%d: improves zone cells %s' % (w+1, zv))
    print('    %-14s' % n, '; '.join(out))

print('\n(d) threshold-2 illustration: cells where T gives a world-w wrong answer')
for w in range(3):
    print('    world %d:' % (w+1), [names[k] for k in range(len(T)) if rank(T[k], k, w) == 2],
          ' sources silent there:', {names[k]: [n for n, Sm in srcs[1:] if Sm[k] == S]
                                     for k in range(len(T)) if rank(T[k], k, w) == 2 and names[k][0] == 'W'})
print('\n(e) clean-world rival: X = T with the majority answer (here N) on W23, W13, W12')
Xe = list(T)
for n in ['W23', 'W13', 'W12']: Xe[idx[n]] = N
Xe = tuple(Xe); r = record(T, Xe)
for w in range(3):
    down = [names[k] for k, a, b in r if rank(a, k, w) >= 2 and rank(b, k, w) < 2]
    print('    world %d: T -> X removes world-%d errors on %s' % (w+1, w+1, down))
    assert down
print('\nPASS (cells only; the measurable statements are proved in the note)')
