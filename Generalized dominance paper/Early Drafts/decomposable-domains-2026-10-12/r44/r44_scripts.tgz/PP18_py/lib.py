"""PP18 exact cell geometry (written independently of audit's and the referee's code).

Advice labels: S silence, P accept the listed gamble, N reject it (accept its negation), X contradiction.
Instance: eps = 3/10, c = 7/30, h = 7/60, d = 1/10, L = 5 (the referee's PP17 instance).
"""
from fractions import Fraction as F

S, P, N, X = 'S', 'P', 'N', 'X'
eps = F(3, 10); c = (1 - eps) / 3; h = F(7, 60); d = F(1, 10); L = F(5)

def vec_T():
    return [[c + eps * (k == j) for k in range(3)] for j in range(3)]

def seg(i, a=F(1)):
    """Credal segment K_i (coordinate i = 1/3, others in [h, 2/3-h]), optionally
    rescaled in coordinate i by a and renormalised (a = 1/(1-d) gives F_i)."""
    o = [k for k in range(3) if k != i]
    out = []
    for lo, hi in [(h, F(2, 3) - h), (F(2, 3) - h, h)]:
        v = [F(0)] * 3; v[i] = F(1, 3); v[o[0]] = lo; v[o[1]] = hi
        z = [v[k] * (a if k == i else 1) for k in range(3)]
        s = sum(z); out.append([x / s for x in z])
    return out

def advice(K, g):
    vals = [sum(x * y for x, y in zip(v, g)) for v in K]
    if min(vals) > 0: return P
    if max(vals) < 0: return N
    return S

# cells: name -> gamble. A, B, R cells are oriented so that the majority answer is P;
# on W and H1 cells P is the minority answer (ranks are always computed from the signs).
cells = []
for name, x in [('A', 2 + d), ('B', 2 - d), ('R', 2 - 3 * d)]:
    for i in range(3):
        cells.append((name + str(i + 1), tuple(-x if k == i else F(1) for k in range(3))))
for k in range(3):
    pair = [j for j in range(3) if j != k]
    cells.append(('W' + ''.join(str(j + 1) for j in pair), tuple(L if j == k else F(-1) for j in range(3))))
cells.append(('U', (F(1), F(1), F(1))))
cells.append(('H1', (F(10), F(-1), F(-1))))
cells.append(('H2', (F(1), F(1), F(-10))))
names = [n for n, _ in cells]
G = [g for _, g in cells]
idx = {n: k for k, n in enumerate(names)}

def rank(a, k, w):
    if a == S: return 1
    if a == X: return 3
    corr = P if G[k][w] > 0 else N
    return 0 if a == corr else 2

def model(K):
    return tuple(advice(K, g) for g in G)

T = model(vec_T())
a_F = 1 / (1 - d)
C = [model(seg(i)) for i in range(3)]
Fm = [model(seg(i, a_F)) for i in range(3)]
cstar = model([[F(1, 3)] * 3])
V = [model([[F(int(k == i)) for k in range(3)]]) for i in range(3)]
MAJ = P

def record(x, y):
    return tuple((k, a, b) for k, (a, b) in enumerate(zip(x, y)) if a != b)

def guidance(r, w):
    return all(rank(a, k, w) <= rank(b, k, w) for k, a, b in r)

def fill(base, cellnames, val=MAJ):
    y = list(base)
    for n in cellnames: y[idx[n]] = val
    return tuple(y)
