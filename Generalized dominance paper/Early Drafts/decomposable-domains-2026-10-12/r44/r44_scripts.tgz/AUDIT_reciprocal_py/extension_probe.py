"""Finite counterexample search for adding one new tilted defender.

This can falsify the proposed enlargement. Passing is not a continuum proof.
"""
from fractions import Fraction as F
from itertools import product
import check as q

c=F(7,30); eps=F(3,10); h=F(7,60)
M=[[c+eps*(k==j) for k in range(3)] for j in range(3)]
Ks=[]
for i in range(3):
    other=[k for k in range(3) if k!=i]
    pair=[]
    for flip in [False,True]:
        v=[F(0)]*3; v[i]=F(1,3)
        v[other[0]]=h if not flip else F(2,3)-h
        v[other[1]]=F(2,3)-h if not flip else h
        pair.append(v)
    Ks.append(pair)
new=[]
for v in Ks[0]:
    z=[v[0]*F(8,7),v[1],v[2]]
    new.append([x/sum(z) for x in z])
Ks.append(new)
gambles=[]; names=[]
for name,b in [('A',F(11,5)),('B',F(9,5)),('R',F(3,2))]:
    for i in range(3):
        gambles.append(tuple(-b if k==i else F(1) for k in range(3)))
        names.append(name+str(i+1))
for pair in [(0,1),(0,2),(1,2)]:
    gambles.append(tuple(-F(1) if k in pair else F(4) for k in range(3)))
    names.append('W'+''.join(str(k+1) for k in pair))
def advice(K,g):
    vals=[sum(x*y for x,y in zip(v,g)) for v in K]
    return q.P if min(vals)>0 else q.M if max(vals)<0 else q.S
q.signs=[tuple(1 if z>0 else -1 for z in g) for g in gambles]
T=tuple(advice(M,g) for g in gambles)
Cs=[tuple(advice(K,g) for g in gambles) for K in Ks]
labels=[0,1,2,0]
Rs=[set() for _ in range(3)]
for w in range(3):
    for i,C in enumerate(Cs):
        Rs[w].add(q.record(T,C) if labels[i]==w else q.record(C,T))
    for i,C in enumerate(Cs):
        for j,D in enumerate(Cs):
            if labels[i]!=w and labels[j]==w:
                Rs[w].add(q.record(C,D))
# Reserve the old source's reverse defence against the added own-world tilt.
for w in [1,2]: Rs[w].add(q.record(Cs[0],Cs[3]))
# At world 1 its opposite is guidance in the actual geometry.
work=[0,1,2,3]  # A1,A2,A3,B1
for vals in product(range(4),repeat=len(work)):
    X=list(T)
    for k,a in zip(work,vals): X[k]=a
    X=tuple(X)
    if X==T: continue
    for j,C in enumerate(Cs):
        w=labels[j]
        if any(q.rank(X[k],k,w)>q.rank(T[k],k,w)
               and q.rank(C[k],k,w)<=q.rank(T[k],k,w) for k in work):
            for v in range(3): Rs[v].add(q.record(C,X))
def fmt(r): return [(names[k],a,b) for k,a,b in r]
for w,rel in enumerate(Rs):
    print('Probe world',w+1,'records',len(rel),flush=True)
    for r in rel:
        if q.guidance(q.inverse(r),w) or q.inverse(r) in rel:
            raise SystemExit(('Reverse failure',w+1,fmt(r)))
        for s in rel:
            t=q.compose(r,s)
            if t is None: continue
            if not t or q.guidance(q.inverse(t),w) or q.inverse(t) in rel:
                raise SystemExit(('Cycle failure',w+1,fmt(r),fmt(s),fmt(t)))
print('PASS on this finite signature only; not a proof of extension.')
