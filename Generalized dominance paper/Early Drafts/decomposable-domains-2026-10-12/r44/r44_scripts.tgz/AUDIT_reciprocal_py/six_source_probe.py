"""Exact finite signature test of the six-source enlargement.

Uses all rivals changing at most two of six cells. Supplementary only:
the written proof covers arbitrary measurable changes on all six regions.
"""
from fractions import Fraction as F
from itertools import product
import check as q

c=F(7,30); eps=F(3,10); h=F(7,60); d=F(1,10); a=1/(1-d)
M=[[c+eps*(k==j) for k in range(3)] for j in range(3)]
Ks=[]; labels=[]
for i in range(3):
    other=[k for k in range(3) if k!=i]
    pair=[]
    for flip in [False,True]:
        v=[F(0)]*3; v[i]=F(1,3)
        v[other[0]]=h if not flip else F(2,3)-h
        v[other[1]]=F(2,3)-h if not flip else h
        pair.append(v)
    Ks.append(pair); labels.append(i)
for i in range(3):
    pair=[]
    for v in Ks[i]:
        z=[v[k]*(a if k==i else 1) for k in range(3)]
        pair.append([x/sum(z) for x in z])
    Ks.append(pair); labels.append(i)
gambles=[]; names=[]
for name,b in [('A',2+d),('B',2-d),('R',2-3*d)]:
    for i in range(3):
        gambles.append(tuple(-b if k==i else F(1) for k in range(3)))
        names.append(name+str(i+1))
for pair in [(0,1),(0,2),(1,2)]:
    gambles.append(tuple(-F(1) if k in pair else F(4) for k in range(3)))
    names.append('W'+''.join(str(k+1) for k in pair))
def advice(K,g):
    vals=[sum(x*y for x,y in zip(v,g)) for v in K]
    return q.P if min(vals)>0 else q.M if max(vals)<0 else q.S
q.signs=[tuple(1 if z>0 else -1 for z in g) for g in gambles]
T=tuple(advice(M,g) for g in gambles)
Cs=[tuple(advice(K,g) for g in gambles) for K in Ks]
Rs=[set() for _ in range(3)]
for w in range(3):
    for i,C in enumerate(Cs):
        Rs[w].add(q.record(T,C) if labels[i]==w else q.record(C,T))
    for i,C in enumerate(Cs):
        for j,D in enumerate(Cs):
            if labels[i]!=w and labels[j]==w:
                Rs[w].add(q.record(C,D))
    for i in range(3):
        if i!=w: Rs[w].add(q.record(Cs[i],Cs[i+3]))
for i in range(3):
    assert q.guidance(q.record(Cs[i+3],Cs[i]),i)
    assert not q.guidance(q.record(Cs[i],Cs[i+3]),i)
count=0
for vals in product(range(4),repeat=6):
    if not 0<sum(v!=q.S for v in vals)<=2: continue
    X=vals+T[6:]; count+=1
    eligible=0
    for j,C in enumerate(Cs):
        w=labels[j]
        if any(q.rank(X[k],k,w)>q.rank(T[k],k,w)
               and q.rank(C[k],k,w)<=q.rank(T[k],k,w) for k in range(6)):
            eligible+=1
            for v in range(3): Rs[v].add(q.record(C,X))
    assert eligible
print('Rivals checked:',count,flush=True)
def fmt(r): return [(names[k],a,b) for k,a,b in r]
for w,rel in enumerate(Rs):
    print('Six-source world',w+1,'records',len(rel),flush=True)
    for r in rel:
        if q.guidance(q.inverse(r),w) or q.inverse(r) in rel:
            raise SystemExit(('Reverse failure',w+1,fmt(r)))
        for s in rel:
            t=q.compose(r,s)
            if t is None: continue
            if not t or q.guidance(q.inverse(t),w) or q.inverse(t) in rel:
                raise SystemExit(('Cycle failure',w+1,fmt(r),fmt(s),fmt(t)))
def accepted(x,y,w):
    r=q.record(x,y)
    return q.guidance(r,w) or r in Rs[w]
for n,source in enumerate([T]+Cs):
    incoming=set()
    for rel in Rs:
        for r in rel:
            if all(source[k]==b for k,a,b in r):
                y=list(source)
                for k,a,b in r: y[k]=a
                incoming.add(tuple(y))
    for y in incoming:
        assert not all(accepted(y,source,w) for w in range(3)), ('source dominated',n,y)
    print('Source',n,':',len(incoming),'incoming candidates, none dominates.',flush=True)
print('PASS on finite signatures. The measurable theorem requires the written proof.')
