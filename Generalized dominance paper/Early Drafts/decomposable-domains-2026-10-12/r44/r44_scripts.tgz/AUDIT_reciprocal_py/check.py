"""Exact finite signature check, supplementary to the measurable proof.

Checks record compositions in every common context, not just named models.
Advice labels: 0 silence, 1 plus, 2 minus, 3 contradiction.
"""
from itertools import product

S, P, M, BOTH = range(4)
signs = []
for _ in range(2):
    signs += [tuple(-1 if w == i else 1 for w in range(3)) for i in range(3)]
# W_01, W_02, W_12: target accepts the minority answer at remaining world.
wpairs = [(0, 1), (0, 2), (1, 2)]
signs += [tuple(1 if w not in pair else -1 for w in range(3)) for pair in wpairs]
T = (S,) * 6 + (P,) * 3
C = []
for i in range(3):
    row = [S] * 9
    row[i] = M
    row[3+i] = P
    for j, pair in enumerate(wpairs):
        row[6+j] = S if i in pair else P
    C.append(tuple(row))

def rank(a, cell, world):
    if a == S: return 1
    if a == BOTH: return 3
    correct = P if signs[cell][world] > 0 else M
    return 0 if a == correct else 2

def record(x, y):
    return tuple((k, a, b) for k, (a, b) in enumerate(zip(x, y)) if a != b)

def inverse(r):
    return tuple((k, b, a) for k, a, b in r)

def compose(r, s):
    rr = {k:(a,b) for k,a,b in r}
    ss = {k:(a,b) for k,a,b in s}
    out = []
    for k in sorted(rr.keys() | ss.keys()):
        if k in rr and k in ss:
            a,b = rr[k]; c,d = ss[k]
            if b != c: return None
            if a != d: out.append((k,a,d))
        elif k in rr:
            out.append((k,*rr[k]))
        else:
            out.append((k,*ss[k]))
    return tuple(out)

def guidance(r, w):
    return all(rank(a,k,w) <= rank(b,k,w) for k,a,b in r)

Rs = [set() for _ in range(3)]
for w in range(3):
    Rs[w].add(record(T,C[w]))
    for i in range(3):
        if i != w:
            Rs[w].add(record(C[i],T))
            Rs[w].add(record(C[i],C[w]))
for choices in product(range(4), repeat=3):
    X = choices + T[3:]
    if X == T: continue
    for i in range(3):
        if any(rank(X[k],k,i) > rank(T[k],k,i) for k in range(3)):
            for w in range(3):
                Rs[w].add(record(C[i],X))

for w, rel in enumerate(Rs):
    pairs = 0
    for r in rel:
        assert not guidance(inverse(r), w), ('guidance reverse',w,r)
        assert inverse(r) not in rel, ('reverse record',w,r)
        for s in rel:
            t = compose(r,s)
            if t is None: continue
            pairs += 1
            assert t, ('two-cycle',w,r,s)
            assert not guidance(inverse(t),w), ('two records plus guidance',w,r,s,t)
            assert inverse(t) not in rel, ('three records',w,r,s,t)
    print(f'World {w+1}: {len(rel)} distinct records; {pairs} composable ordered pairs; all cycle checks pass.')

def accepted(x,y,w):
    r=record(x,y)
    return guidance(r,w) or r in Rs[w]

for source in [T]+C:
    incoming=set()
    for rel in Rs:
        for r in rel:
            if all(source[k] == b for k,a,b in r):
                y=list(source)
                for k,a,b in r: y[k]=a
                incoming.add(tuple(y))
    for y in incoming:
        assert not all(accepted(y,source,w) for w in range(3)), ('source dominated',source,y)
    print(f'Source {([T]+C).index(source)}: {len(incoming)} possible new incoming sources; no dominator.')
print('PASS: finite signature checks, including all common-context record compositions.')
