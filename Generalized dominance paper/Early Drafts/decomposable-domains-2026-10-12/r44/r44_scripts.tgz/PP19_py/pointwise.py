"""PP19 pointwise and record-algebra checks (exact, exhaustive over finite cells).

These check ONLY the bookkeeping inside the proofs of PP19 (rank tables, the
pointwise feasibility characterisations, and that the triangles built in the
Kill Lemma and Two-source Kill Lemma are genuine (IB) copies closed by a strict
pointwise improvement).  They are NOT evidence about (S): cells are atoms.

Advice: 'A' majority answer, 'S' silence, 'B' minority answer, 'X' contradiction.
Classes: 'M1','M2','M3' (minority world 1,2,3), 'U' unanimous. Worlds 1,2,3.
Run: python3 -I -B pointwise.py
"""
from itertools import product

ADV = 'ASBX'
CLS = ['M1', 'M2', 'M3', 'U']

def rank(a, cls, w):
    if a == 'X':
        return 3
    if a == 'S':
        return 1
    if cls == 'U':
        return 0 if a == 'A' else 2
    k = int(cls[1])
    good = 'B' if w == k else 'A'
    return 0 if a == good else 2

def lt(a, b, cls, w):  # a strictly better than b at w
    return rank(a, cls, w) < rank(b, cls, w)

def le(a, b, cls, w):
    return rank(a, cls, w) <= rank(b, cls, w)

AW = {'B': 0, 'S': 1, 'A': 2}  # A-ward order, X excluded

# ---------------------------------------------------------------- check 1
def check_compensation_table():
    """bad point: C <_1 T or C <_2 T, and not C <_3 T (point outside E).
    Claim: for T in {A,S,B}, bad iff
      M3: C strictly A-ward of T;  M1: C strictly B-ward of T;
      M2: C strictly B-ward of T;  U: never.  (C = X never bad.)"""
    n = 0
    for cls in CLS:
        for t in 'ASB':
            for c in ADV:
                bad = (lt(c, t, cls, 1) or lt(c, t, cls, 2)) and not lt(c, t, cls, 3)
                if c == 'X' or cls == 'U':
                    claim = False
                elif cls == 'M3':
                    claim = AW[c] > AW[t]
                else:
                    claim = AW[c] < AW[t]
                assert bad == claim, (cls, t, c)
                n += 1
    print('check 1 (compensation table): %d cases OK' % n)

# ---------------------------------------------------------------- check 2
def check_two_source_feasibility():
    """exists y with y<=_1 c, y<=_2 c, y<=_3 c'.  Claim (c, c' not X):
       M3: AW[c] <= AW[c'];  M1, M2: AW[c] >= AW[c'];  U: always.
       If c = X or c' = X: as stated in the note (checked directly)."""
    n = 0
    for cls in CLS:
        for c in ADV:
            for cp in ADV:
                feas = any(le(y, c, cls, 1) and le(y, c, cls, 2) and le(y, cp, cls, 3)
                           for y in ADV)
                if c == 'X' and cp == 'X':
                    claim = True
                elif c == 'X':
                    claim = True            # y = c' works at 3; worlds 1,2 trivial
                elif cp == 'X':
                    claim = True            # y = c works at 1, 2; world 3 trivial
                elif cls == 'U':
                    claim = True
                elif cls == 'M3':
                    claim = AW[c] <= AW[cp]
                else:
                    claim = AW[c] >= AW[cp]
                assert feas == claim, (cls, c, cp, feas)
                n += 1
    print('check 2 (two-source feasibility): %d cases OK' % n)

# ---------------------------------------------------------------- record algebra
def record(x, y):
    return tuple((k, a, b) for k, (a, b) in enumerate(zip(x, y)) if a != b)

def is_copy(pair, rec):
    a0, b0 = pair
    return record(a0, b0) == rec

def strict_improvement(z, a, classes, w):
    """z pointwise weakly better than a at w and strictly somewhere."""
    ok = all(le(z[k], a[k], classes[k], w) for k in range(len(z)))
    st = any(lt(z[k], a[k], classes[k], w) for k in range(len(z)))
    return ok and st

def triangle_kill(C, X, Y, T, classes, w):
    """Build A0 = C on D, T off D; B0 = X on D, T off D; Z0 = B0[DY -> Y].
    Return True if (A0,B0) copies rec(C,X), (B0,Z0) copies rec(T,Y) and
    Z0 strictly better than A0 at w (so T <=_w Y would violate (TC))."""
    n = len(T)
    D = [C[k] != X[k] for k in range(n)]
    DY = [Y[k] != T[k] for k in range(n)]
    A0 = tuple(C[k] if D[k] else T[k] for k in range(n))
    B0 = tuple(X[k] if D[k] else T[k] for k in range(n))
    if any(DY[k] and B0[k] != T[k] for k in range(n)):
        return False
    Z0 = tuple(Y[k] if DY[k] else B0[k] for k in range(n))
    assert is_copy((A0, B0), record(C, X))
    assert is_copy((B0, Z0), record(T, Y))
    return strict_improvement(Z0, A0, classes, w)

# ---------------------------------------------------------------- check 3
def check_kill_lemma(ncells=4):
    """Kill Lemma bookkeeping. For every assignment on ncells cells:
    classes, T in {A,S,B}, C in ADV, E (subset of M3 cells with T != A),
    with X = T[E->A], exposure (C != A somewhere on E) and NO bad point
    outside E: the Y of the proof has T <=_1 Y, T <=_2 Y killed by triangles,
    and Y strictly better than T at 3 (or Y = T and C <=_1 X itself refuted)."""
    count = 0
    for classes in product(CLS, repeat=ncells):
        for T in product('ASB', repeat=ncells):
            if any(classes[k] == 'U' and T[k] != 'A' for k in range(ncells)):
                continue
            cand = [k for k in range(ncells) if classes[k] == 'M3' and T[k] != 'A']
            for C in product(ADV, repeat=ncells):
                for mask in range(1, 1 << len(cand)):
                    E = {cand[i] for i in range(len(cand)) if mask >> i & 1}
                    if not any(C[k] != 'A' for k in E):
                        continue
                    bad = any(k not in E and (lt(C[k], T[k], classes[k], 1) or lt(C[k], T[k], classes[k], 2))
                              and not lt(C[k], T[k], classes[k], 3) for k in range(ncells))
                    if bad:
                        continue
                    X = tuple('A' if k in E else T[k] for k in range(ncells))
                    DY = [k not in E and lt(C[k], T[k], classes[k], 3) for k in range(ncells)]
                    Y = tuple(C[k] if DY[k] else T[k] for k in range(ncells))
                    for w in (1, 2):
                        assert triangle_kill(C, X, Y, T, classes, w), (classes, T, C, E, w)
                    if Y != T:
                        assert strict_improvement(Y, T, classes, 3)
                    count += 1
    print('check 3 (Kill Lemma, %d cells): %d configurations OK' % (ncells, count))

# ---------------------------------------------------------------- check 4
def check_two_source_kill(ncells=3):
    """Two-source Kill Lemma bookkeeping: C <=_{1,2} X_E, C' <=_3 Z_F
    (E, F disjoint subsets of M3 cells, T != A on E, T != B on F, exposure),
    K avoiding E and F, pointwise feasibility on K: the Y built from y kills
    T's defence at all three worlds by triangles."""
    count = 0
    for classes in product(CLS, repeat=ncells):
        for T in product('ASB', repeat=ncells):
            if any(classes[k] == 'U' and T[k] != 'A' for k in range(ncells)):
                continue
            m3 = [k for k in range(ncells) if classes[k] == 'M3']
            for C in product(ADV, repeat=ncells):
                for Cp in product(ADV, repeat=ncells):
                    for lab in product((0, 1, 2), repeat=len(m3)):
                        E = {m3[i] for i in range(len(m3)) if lab[i] == 1}
                        F = {m3[i] for i in range(len(m3)) if lab[i] == 2}
                        if not E or not F:
                            continue
                        if any(T[k] == 'A' for k in E) or any(T[k] == 'B' for k in F):
                            continue
                        if not any(C[k] != 'A' for k in E) or not any(Cp[k] != 'B' for k in F):
                            continue
                        K = [((k not in E) and (lt(C[k], T[k], classes[k], 1) or lt(C[k], T[k], classes[k], 2)))
                             or ((k not in F) and lt(Cp[k], T[k], classes[k], 3)) for k in range(ncells)]
                        if any(K[k] and (k in E or k in F) for k in range(ncells)):
                            continue
                        y = []
                        okfeas = True
                        for k in range(ncells):
                            if not K[k]:
                                y.append(T[k]); continue
                            opts = [v for v in ADV if le(v, C[k], classes[k], 1) and le(v, C[k], classes[k], 2)
                                    and le(v, Cp[k], classes[k], 3)]
                            if not opts:
                                okfeas = False; break
                            y.append(opts[0])
                        if not okfeas:
                            continue
                        Y = tuple(y)
                        X = tuple('A' if k in E else T[k] for k in range(ncells))
                        Z = tuple('B' if k in F else T[k] for k in range(ncells))
                        # triangles: the variant with DY possibly containing points where y == T is fine
                        for w in (1, 2):
                            assert triangle_kill(C, X, Y, T, classes, w), (classes, T, C, Cp, E, F, w)
                        assert triangle_kill(Cp, Z, Y, T, classes, 3), (classes, T, C, Cp, E, F)
                        count += 1
    print('check 4 (two-source kill, %d cells): %d configurations OK' % (ncells, count))

# ---------------------------------------------------------------- check 5
def check_partial_source_copy(ncells=4):
    """Partial-source identity: for D' inside {C != T}, X = T[D'->C],
    rec(T, X) == rec(C[D'->T], C) and rec(X, T) == rec(C, C[D'->T])."""
    count = 0
    for T in product('ASB', repeat=ncells):
        for C in product(ADV, repeat=ncells):
            Dc = [k for k in range(ncells) if C[k] != T[k]]
            for mask in range(1, 1 << len(Dc)):
                Dp = {Dc[i] for i in range(len(Dc)) if mask >> i & 1}
                X = tuple(C[k] if k in Dp else T[k] for k in range(ncells))
                Co = tuple(T[k] if k in Dp else C[k] for k in range(ncells))
                assert record(T, X) == record(Co, C)
                assert record(X, T) == record(C, Co)
                count += 1
    print('check 5 (partial-source copy identity): %d cases OK' % count)

if __name__ == '__main__':
    check_compensation_table()
    check_two_source_feasibility()
    check_kill_lemma(4)
    check_two_source_kill(3)
    check_partial_source_copy(4)
    print('ALL PASS')
