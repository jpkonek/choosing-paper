"""PP17 referee: exact rational verification of the geometry in AUDIT_six_source.md
sections 3, 9 and 13.  Independent of AUDIT_reciprocal_py.

Advice of D_K at gamble g: 'P' (accept g) if min_{m in K} m.g > 0,
'N' (accept -g) if max < 0, 'S' if min < 0 < max (strict silence).
A zero value is reported as 'BOUNDARY' and counts as a failure.
Credal sets are polytopes, so min/max over vertices suffice.
"""
from fractions import Fraction as Fr
import random, sys

def dot(m, g): return sum(a*b for a, b in zip(m, g))

def advice(V, g):
    vals = [dot(m, g) for m in V]
    lo, hi = min(vals), max(vals)
    if lo > 0: return 'P', lo, hi
    if hi < 0: return 'N', lo, hi
    if lo < 0 < hi: return 'S', lo, hi
    return 'BOUNDARY', lo, hi

def models(eps, h, d):
    c = (1 - eps) / 3
    T = [[c + eps*(k == j) for k in range(3)] for j in range(3)]
    C, F = [], []
    a = 1 / (1 - d)
    for i in range(3):
        o = [k for k in range(3) if k != i]
        V = []
        for x in (h, Fr(2, 3) - h):
            v = [Fr(0)]*3; v[i] = Fr(1, 3); v[o[0]] = x; v[o[1]] = Fr(2, 3) - x
            V.append(v)
        C.append(V)
        W = []
        for v in V:
            z = [v[k]*(a if k == i else 1) for k in range(3)]
            s = sum(z); W.append([t/s for t in z])
        F.append(W)
    return c, T, C, F

def gam(i, x):  # other coords 1, coord i = -x
    return tuple(-x if k == i else Fr(1) for k in range(3))

def wgam(i, j, L):
    return tuple(Fr(-1) if k in (i, j) else L for k in range(3))

def check(eps, h, d, L, verbose=False):
    c, T, C, F = models(eps, h, d)
    errs = []
    def want(name, got, exp):
        if got != exp: errs.append((name, got, exp))
    # F_i coordinate i
    for i in range(3):
        for m in F[i]:
            want(f'F{i+1} coord', m[i], 1/(3 - 2*d))
    table = {}
    for i in range(3):
        for nm, x, own_C, own_F in (('A', 2+d, 'N', 'N'), ('B', 2-d, 'P', 'N'), ('R', 2-3*d, 'P', 'P')):
            g = gam(i, x)
            t = advice(T, g)[0]; want(f'T on {nm}{i+1}', t, 'S')
            want(f'C{i+1} on {nm}{i+1}', advice(C[i], g)[0], own_C)
            want(f'F{i+1} on {nm}{i+1}', advice(F[i], g)[0], own_F)
            for j in range(3):
                if j != i:
                    want(f'C{j+1} on {nm}{i+1}', advice(C[j], g)[0], 'S')
                    want(f'F{j+1} on {nm}{i+1}', advice(F[j], g)[0], 'S')
            table[nm+str(i+1)] = (t, advice(C[i], g)[0], advice(F[i], g)[0])
    for (i, j) in ((0, 1), (0, 2), (1, 2)):
        g = wgam(i, j, L)
        want(f'T on W{i+1}{j+1}', advice(T, g)[0], 'P')   # accept g: good only at k
        for s in (i, j):
            want(f'C{s+1} on W{i+1}{j+1}', advice(C[s], g)[0], 'S')
            want(f'F{s+1} on W{i+1}{j+1}', advice(F[s], g)[0], 'S')
    if verbose:
        for k, v in table.items(): print('  ', k, 'T,C_i,F_i =', v)
    return errs

def pointwise_no_worse_test(eps, h, d, trials=4000, seed=1):
    """Random exact test of: F_i is no worse than C_i at world i at every gamble."""
    c, T, C, F = models(eps, h, d)
    rnd = random.Random(seed)
    def rank(adv, gi):
        if adv == 'S': return 1
        good = 'P' if gi > 0 else 'N'
        return 0 if adv == good else 2
    bad = 0
    for _ in range(trials):
        g = tuple(Fr(rnd.randint(-60, 60), rnd.randint(1, 12)) for _ in range(3))
        for i in range(3):
            if g[i] == 0: continue
            ac = advice(C[i], g)[0]; af = advice(F[i], g)[0]
            if 'BOUNDARY' in (ac, af): continue
            if rank(af, g[i]) > rank(ac, g[i]): bad += 1
    return bad

if __name__ == '__main__':
    eps = Fr(3, 10); c = (1-eps)/3
    # Section 3 table, h = 7/60, d = 1/5
    _, T, C, F = models(eps, Fr(7, 60), Fr(1, 5))
    for g in (gam(2, Fr(11, 5)), gam(2, Fr(9, 5))):
        a = advice(T, g); k = advice(C[2], g)
        print('sec3', g, 'T lower/upper', a[1], a[2], ' K value(min,max)', k[1], k[2])
    # K and M non-containment
    print('K_3 has first coordinate h=7/60 <', c, ': not inside M; M has varying 3rd coordinate: not inside K_3')
    for (h, d, L) in ((Fr(7, 60), Fr(1, 10), Fr(5)), (Fr(7, 60), Fr(1, 5), Fr(5)), (Fr(7, 60), Fr(1, 10), Fr(4))):
        e = check(eps, h, d, L, verbose=(d == Fr(1, 10) and L == 5))
        print(f'eps=3/10 h={h} d={d} L={L}:', 'PASS' if not e else e)
    print('pointwise F_i <=_i C_i, random exact test failures:', pointwise_no_worse_test(eps, Fr(7, 60), Fr(1, 10)))
    # General eps: explicit choice h=c/2, L=midpoint, d=min(1/5, eps/(2c), eps/(3(c+eps)))
    bad = 0; n = 0
    eps_list = [Fr(1, 1000), Fr(1, 100), Fr(1, 20)] + [Fr(k, 40) for k in range(1, 40)] + [Fr(99, 100), Fr(999, 1000)]
    for eps in eps_list:
        c = (1-eps)/3; h = c/2
        L = ((1-c)/c + (1-h)/h)/2
        d = min(Fr(1, 5), eps/(2*c), eps/(3*(c+eps)))
        e = check(eps, h, d, L); n += 1
        if e: bad += 1; print('FAIL', eps, e[:3])
    print(f'general-eps explicit choice: {n} values of eps, failures: {bad}')
