"""PP17 referee: independent exact finite check of the record algebra of
AUDIT_six_source.md sections 10-11 (three sources) and 13-14 (seven sources).

Cells (one problem per cell; advice computed exactly from geometry.py-style
credal sets at eps=3/10, h=7/60, d=1/10, L=5):
  A1..A3, B1..B3, R1..R3, W12, W13, W23, U (unanimous), H1, H2 (common mixed).
Advice codes: 0 = accept g ('P'), 1 = accept -g ('N'), 2 = silent, 3 = contradiction.
A record is a tuple of (cell, old, new) with old != new; installing a record means
accepting every common-context copy, and acceptance of a comparison (X,Y) at world w
means rec(X,Y) is guidance at w or an installed record at w.
Finite cells are evidence for the record algebra only, not for (S).
Usage: python3 -I -B records.py [three|six2|six_all|six2_tref]
"""
import sys, itertools
from fractions import Fraction as Fr
import numpy as np

sys.path.insert(0, __file__.rsplit('/', 1)[0])  # only our own folder
from geom import models, advice as gadv, gam, wgam

eps, h, d, L = Fr(3, 10), Fr(7, 60), Fr(1, 10), Fr(5)
c, TV, CV, FV = models(eps, h, d)
names, gambles = [], []
for nm, x in (('A', 2+d), ('B', 2-d), ('R', 2-3*d)):
    for i in range(3):
        names.append(f'{nm}{i+1}'); gambles.append(gam(i, x))
for (i, j) in ((0, 1), (0, 2), (1, 2)):
    names.append(f'W{i+1}{j+1}'); gambles.append(wgam(i, j, L))
names += ['U', 'H1', 'H2']
gambles += [(Fr(1), Fr(2), Fr(3)), (Fr(10), Fr(-1), Fr(-1)), (Fr(1), Fr(1), Fr(-10))]
NC = len(names)
code = {'P': 0, 'N': 1, 'S': 2}
def adv(V):
    out = []
    for g in gambles:
        a = gadv(V, g)[0]
        assert a in code, (a, g)
        out.append(code[a])
    return tuple(out)
T = adv(TV); C = [adv(V) for V in CV]; F = [adv(V) for V in FV]
# rank[w][cell][value]
RANK = np.zeros((3, NC, 4), dtype=np.int8)
for w in range(3):
    for k, g in enumerate(gambles):
        good = 0 if g[w] > 0 else 1
        RANK[w, k] = [0 if good == 0 else 2, 0 if good == 1 else 2, 1, 3]
cell = {n: k for k, n in enumerate(names)}
SIX = [cell[n] for n in ('A1', 'A2', 'A3', 'B1', 'B2', 'B3')]
AONLY = SIX[:3]

def rec(x, y): return tuple((k, a, b) for k, (a, b) in enumerate(zip(x, y)) if a != b)
def inv(r): return tuple((k, b, a) for k, a, b in r)
def delta(r, w): return {k: int(RANK[w, k, b]) - int(RANK[w, k, a]) for k, a, b in r}
def guidance(r, w): return len(r) > 0 and all(v >= 0 for v in delta(r, w).values())
def improvement(r, w): return len(r) > 0 and all(v <= 0 for v in delta(r, w).values())

def build(kind):
    """Return (sources dict name->model, installed[w]: dict record->label, rivals list)."""
    src = {'T': T}
    inst = [dict() for _ in range(3)]
    def add(w, x, y, lab): inst[w].setdefault(rec(x, y), set()).add(lab)
    if kind == 'three':
        for i in range(3): src[f'C{i+1}'] = C[i]
        for w in range(3):
            add(w, T, C[w], f'a:T->C{w+1}')
            for i in range(3):
                if i != w:
                    add(w, C[i], T, f's2:C{i+1}->T'); add(w, C[i], C[w], f's3:C{i+1}->C{w+1}')
        cells = AONLY; group = {f'C{i+1}': i for i in range(3)}
    else:
        for i in range(3): src[f'C{i+1}'] = C[i]; src[f'F{i+1}'] = F[i]
        group = {f'C{i+1}': i for i in range(3)}; group.update({f'F{i+1}': i for i in range(3)})
        for w in range(3):
            for s, i in group.items():
                if i == w: add(w, T, src[s], f'a:T->{s}')
                else:
                    add(w, src[s], T, f's2:{s}->T')
                    for q, j in group.items():
                        if j == w: add(w, src[s], src[q], f's3:{s}->{q}')
            for i in range(3):
                if i != w: add(w, C[i], F[i], f'r:C{i+1}->F{i+1}')
        cells = SIX
    # rivals
    maxchg = {'three': 3, 'six2': 2, 'six_all': 6, 'six2_tref': 2, 'mut_noQ': 2, 'mut_rev': 2, 'six2_tref1': 2, 'six_all_tref1': 6}[kind]
    rivals = []
    for vals in itertools.product(range(4), repeat=len(cells)):
        nchg = sum(v != T[k] for v, k in zip(vals, cells))
        if not 0 < nchg <= maxchg: continue
        X = list(T)
        for v, k in zip(vals, cells): X[k] = v
        rivals.append(tuple(X))
    info = []
    for X in rivals:
        if kind == 'three':
            J = [i for i in range(3) if any(RANK[i, k, X[k]] > RANK[i, k, T[k]] for k in cells)]
            elig = [f'C{i+1}' for i in J]
        else:
            elig = [s for s, i in group.items()
                    if any(RANK[i, k, X[k]] > RANK[i, k, T[k]] and RANK[i, k, src[s][k]] <= RANK[i, k, T[k]]
                           for k in range(NC))]
        if kind == 'mut_noQ': elig = list(group)   # MUTATION: ignore (Q)
        assert elig, ('no eligible source', X)
        for s in elig:
            for w in range(3): add(w, src[s], X, f'b:{s}->X')
        info.append((X, elig))
    if kind == 'mut_rev':   # MUTATION: install C_i <=_i F_i (reverse of strict guidance)
        for i in range(3): add(i, C[i], F[i], 'mut')
    if kind == 'six2_tref':
        # exploratory: target-reference records T ->_w X whenever X is worse than T at w somewhere
        for X, _ in info:
            for w in range(3):
                if any(RANK[w, k, X[k]] > RANK[w, k, T[k]] for k in range(NC)):
                    add(w, T, X, 't:T->X')
    if kind in ('six2_tref1', 'six_all_tref1'):
        # exploratory: T ->_w X only at ONE world, and only when T has no guidance defence at any world
        for X, _ in info:
            if any(guidance(rec(T, X), w) for w in range(3)): continue
            ws = [w for w in range(3) if any(RANK[w, k, X[k]] > RANK[w, k, T[k]] for k in range(NC))]
            add(ws[0], T, X, 't:T->X')
    return src, group, inst, info

def accepted(r, w, inst):
    return len(r) == 0 or guidance(r, w) or r in inst[w]

def enc(records):
    o = np.full((len(records), NC), -1, dtype=np.int8); n = np.full((len(records), NC), -1, dtype=np.int8)
    for t, r in enumerate(records):
        for k, a, b in r: o[t, k] = a; n[t, k] = b
    return o, n

def cycle_check(inst, w):
    """All ordered pairs (r,s) of installed records composable in a common context
    (r's new side = s's old side on D_r & D_s).  The composite is context-free.
    A 3-cycle A->B->C->A with links r,s,t exists iff t = inv(composite) is accepted.
    Together with: every installed record has a strict worsening cell (so no cycle
    new+guidance+guidance) and no installed record has an accepted reverse, this
    covers every 3-cycle through a new record in every rotation."""
    recs = list(inst[w].keys()); o, n = enc(recs)
    inD = n >= 0
    cyc, viol, npairs = [], [], 0
    for t in range(len(recs)):
        both = inD[t][None, :] & inD
        ok = np.all(~both | (n[t][None, :] == o), axis=1)
        for s in np.nonzero(ok)[0]:
            npairs += 1
            r1, r2 = recs[t], recs[s]
            d1 = {k: (a, b) for k, a, b in r1}; d2 = {k: (a, b) for k, a, b in r2}
            comp = []
            for k in sorted(set(d1) | set(d2)):
                a = d1[k][0] if k in d1 else d2[k][0]
                b = d2[k][1] if k in d2 else d1[k][1]
                if a != b: comp.append((k, a, b))
            comp = tuple(comp)
            if len(comp) == 0:
                cyc.append(('2-cycle', r1, r2)); continue
            if accepted(inv(comp), w, inst):
                cyc.append((r1, r2, comp))
                if not accepted(comp, w, inst): viol.append((r1, r2, comp))
    return npairs, cyc, viol

def main(kind):
    src, group, inst, info = build(kind)
    print(f'== {kind}: cells {names}')
    print('T  =', T); [print(f'{s:3}=', m) for s, m in src.items() if s != 'T']
    print('rivals:', len(info), ' records per world:', [len(x) for x in inst])
    ok = True
    for w in range(3):
        g_bad = [r for r in inst[w] if improvement(r, w) or not any(v > 0 for v in delta(r, w).values())]
        rev = [r for r in inst[w] if accepted(inv(r), w, inst)]
        npairs, cyc, viol = cycle_check(inst, w)
        print(f'world {w+1}: no-worsening-witness {len(g_bad)}; accepted reverses (ties/non-strict) {len(rev)}; '
              f'composable ordered pairs {npairs}; accepted 3-cycles {len(cyc)}; (TC) violations {len(viol)}')
        for x in (g_bad + rev)[:3] + cyc[:3]: print('   example', x, [sorted(l) for l in [inst[w].get(x[0] if isinstance(x[0], tuple) and len(x)==3 and isinstance(x[0][0], tuple) else x, set())]])
        ok &= not (g_bad or rev or cyc)
    # (IB) copies ending at named models
    targets = dict(src)
    for tname, M in targets.items():
        ends = set(); ys = set()
        for w in range(3):
            for r, labs in inst[w].items():
                if all(M[k] == b for k, a, b in r):
                    Y = list(M)
                    for k, a, b in r: Y[k] = a
                    Y = tuple(Y); ys.add(Y)
                    yname = [s for s, m in src.items() if m == Y]
                    for lab in labs:
                        ends.add((w+1, lab if not lab.startswith('b:') else lab, yname[0] if yname else 'UNNAMED'))
        rep = [e for e in ends if e[1].startswith('b:') or e[1].startswith('t:')]
        unn = [e for e in ends if e[2] == 'UNNAMED']
        print(f'incoming copies at {tname}: {sorted(ends)}' + (f'  REPAIR-ENDINGS {rep[:3]}' if rep else '') + (f'  UNNAMED {unn[:3]}' if unn else ''))
        if (rep and kind != 'six2_tref') or unn: ok = False
        # domination test among candidates (plus pure guidance, cellwise)
        cands = (set(src.values()) | ys) - {M}
        dom = []
        for Y in cands:
            accs = [accepted(rec(Y, M), w, inst) for w in range(3)]
            stricts = [accs[w] and not accepted(rec(M, Y), w, inst) for w in range(3)]
            if all(accs) and any(stricts): dom.append(Y)
        # a pure-guidance all-world dominator exists iff some cell value is weakly better at all worlds
        gdom = [(names[k], v) for k in range(NC) for v in range(4) if v != M[k]
                and all(RANK[w, k, v] <= RANK[w, k, M[k]] for w in range(3))]
        print(f'   dominators of {tname} among {len(cands)} candidates (named sources + all copy sources): {len(dom)}; cellwise all-world weak improvements: {gdom}')
        if dom or gdom: ok = False
    # rivals strictly dominated at every world by an eligible source
    nd = 0
    for X, elig in info:
        good = any(all(accepted(rec(src[s], X), w, inst) and not accepted(rec(X, src[s]), w, inst) for w in range(3)) for s in elig)
        nd += (not good)
    print('rivals not strictly dominated at all worlds by an eligible source:', nd)
    ok &= nd == 0
    # T's own defence against rivals (not claimed by audit; informative)
    nodef = [X for X, _ in info if not any(accepted(rec(T, X), w, inst) for w in range(3))]
    print('rivals against which T has no defence at any world (not claimed by audit):', len(nodef),
          ('example ' + str(nodef[0])) if nodef else '')
    print('RESULT', kind, 'PASS' if ok else 'FAIL')

if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else 'six2')
