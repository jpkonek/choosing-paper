"""Structured key families.  Each returns keys[w][(c,j)] for regular steps of mixed cells."""
from core import *

def step_present(X, cells, w, c, j):
    return cells.R[w][c][X[c]] >= j

def key_common(cells, perm):
    k = {(c, j): 2*perm[c] + j for c in range(cells.N) for j in (1, 2)}
    return [k, k, k]

def key_from_family(cells, pts_models, mode, phi=None, tieb=None):
    """pts_models: list of (p, model).  mode 'sup_present': k = sup{phi_w(p): step present};
    'inf_absent': k = inf{phi_w(p): step absent}.  phi_w(p) defaults to p_w.
    Ties broken by tieb[w][(c,j)] (small)."""
    if phi is None: phi = lambda p, w: p[w]
    keys = []
    for w in range(3):
        k = {}
        for c in range(cells.N):
            for j in (1, 2):
                vals_p = [phi(p, w) for p, X in pts_models if cells.R[w][c][X[c]] >= j]
                vals_a = [phi(p, w) for p, X in pts_models if cells.R[w][c][X[c]] < j]
                if mode == 'sup_present':
                    v = max(vals_p) if vals_p else F(-1)
                elif mode == 'inf_absent':
                    v = min(vals_a) if vals_a else F(2)
                elif mode == 'mid':
                    a = max(vals_p) if vals_p else F(-1); b = min(vals_a) if vals_a else F(2)
                    v = (a + b)/2
                k[(c, j)] = (v, tieb[w][(c, j)] if tieb else (c, j))
        keys.append(k)
    return keys
