"""SAT search for per-world key orders under the weak gate, gate-only verdict (or sticky for the
competitiveness part).  Competitiveness is exact (every selected cell model, its supports, every
regular rival).  KKM is required with candidate dominators = the selected cell models plus the
split models at grid edges and grid triangles (finite stand-ins for boundary indices, at which a
closed section must contain the limit): a split model has at each atom the set of advices of the
adjacent cells, and every member differing from the rival contributes its changed steps."""
import itertools
from pysat.formula import IDPool
from pysat.solvers import Solver
from core import *

def build(cells, sel, splits, phi='none', use_kkm=True, kkm_selectors=False, use_comp=True, comp_selectors=False, kkm_only=None):
    N = cells.N
    steps = [(c, j) for c in range(N) for j in (1, 2)]
    sid = {s: k for k, s in enumerate(steps)}
    S = len(steps)
    pool = IDPool(); cl = []
    def X(w, a, b):
        if a < b: return pool.id(('x', w, a, b))
        return -pool.id(('x', w, b, a))
    for w in range(3):
        for a, b, c in itertools.permutations(range(S), 3):
            cl.append([-X(w, a, b), -X(w, b, c), X(w, a, c)])
    Hs = set(); Gs = set()
    def H(w, a, off):
        key = ('h', w, a, off); v = pool.id(key)
        if key not in Hs:
            Hs.add(key)
            for b in off: cl.append([-v, X(w, a, b)])
        return v
    def Gv(w, on, off):
        key = ('g', w, on, off); v = pool.id(key)
        if key not in Gs:
            Gs.add(key); cl.append([-v] + [H(w, a, off) for a in on])
        return v
    R = cells.R
    models = [tuple(int(a) for a in row) for row in cells.models]
    def lit_sets(Csets, Xm, w, mass_check=False):
        on = set(); off = set(); mon = moff = 0
        for c in range(N):
            rx = R[w][c][Xm[c]]
            for y in Csets[c]:
                ry = R[w][c][y]
                for j in (1, 2):
                    if ry < j <= rx: on.add(sid[(c, j)])
                    if rx < j <= ry: off.add(sid[(c, j)])
                if mass_check:
                    if rx > ry: mon += cells.mass[c]*(rx-ry)
                    if ry > rx: moff += cells.mass[c]*(ry-rx)
        if not off: return True
        if not on: return False
        if mass_check and 2*mon - moff < 0: return False
        return Gv(w, tuple(sorted(on)), tuple(sorted(off)))
    triv = []
    if use_comp:
        for Cm in sel:
            Cs = [(a,) for a in Cm]
            for Xm in models:
                if Xm == Cm: continue
                L = [lit_sets(Cs, Xm, w, mass_check=(phi == 'sticky')) for w in range(3)]
                for s in sel[Cm][0]:
                    if any(L[w] is True for w in s): continue
                    clause = [L[w] for w in s if L[w] is not False]
                    if not clause: triv.append(('comp', Cm, s, Xm)); continue
                    if comp_selectors:
                        sv = pool.id(('csel', Cm, s, Xm)); cl.append(clause + [-sv])
                    else:
                        cl.append(clause)
    if use_kkm:
        cands = [tuple((a,) for a in Cm) for Cm in sel] + [tuple(tuple(sorted(s)) for s in sp) for sp in splits]
        for Xm in (models if kkm_only is None else kkm_only):
            if Xm in sel: continue
            opts = []; done = False
            for Cs in cands:
                L = [lit_sets(Cs, Xm, w) for w in range(3)]
                if any(l is False for l in L): continue
                req = [l for l in L if l is not True]
                if not req: done = True; break
                v = pool.id(('K', Cs, Xm)); opts.append(v)
                for l in req: cl.append([-v, l])
            if done: continue
            if not opts: triv.append(('kkm', Xm)); continue
            if kkm_selectors:
                sv = pool.id(('sel', Xm)); cl.append(opts + [-sv])
            else:
                cl.append(opts)
    return dict(pool=pool, clauses=cl, steps=steps, X=X, triv=triv, models=models)

def solve(B, name='cadical153', assumptions=()):
    if B['triv']: return None, None
    with Solver(name=name, bootstrap_with=B['clauses']) as s:
        if not s.solve(assumptions=list(assumptions)): return False, None
        m = set(l for l in s.get_model() if l > 0)
    steps = B['steps']; Xf = B['X']
    orders = []
    for w in range(3):
        idx = range(len(steps))
        def lt(a, b):
            l = Xf(w, a, b)
            return (l in m) if l > 0 else (-l not in m)
        cnt = {a: sum(1 for b in idx if b != a and lt(a, b)) for a in idx}
        orders.append([steps[a] for a in sorted(idx, key=lambda a: -cnt[a])])
    return True, orders
