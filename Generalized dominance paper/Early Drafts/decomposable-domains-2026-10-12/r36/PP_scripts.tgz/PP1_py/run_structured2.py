import random, sys
from core import *
from evalkeys import *
from keyfams import *
c = (F(1,3),)*3
def tri(s):
    return [tuple(s*((1 if i == k else 0) - c[i]) for i in range(3)) for k in range(3)]
N = int(sys.argv[1]); nseed = int(sys.argv[2]); D = 60
for seed in range(nseed):
    G = random_lines(N, seed)
    rnd = random.Random(seed+100); mass = [rnd.randint(1, 5) for _ in range(N)]
    cells = Cells(G, mass)
    Kf = fam_hom(tri(F(3, 20)))
    pts = grid_models(Kf, G, D)
    sel = selected_models(Kf, G, D=D)
    nbs = neighbourhoods(pts, D)
    pm = [((F(a, D), F(b, D), F(D-a-b, D)), X) for (a, b), X in pts.items()]
    perm = list(range(N)); rnd.shuffle(perm)
    cands = {'common': key_common(cells, perm)}
    for mode in ('sup_present', 'inf_absent', 'mid'):
        cands[mode] = key_from_family(cells, pm, mode)
    for name, keys in cands.items():
        cells.set_keys(keys)
        r, ex = evaluate(cells, sel, nbs, phi='none')
        ok = kkm_with_splits(cells, sel, local_splits(pts, D))
        r['kkm_split_missing'] = int((~ok).sum())
        print(seed, name, r)
