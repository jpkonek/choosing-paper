"""Ray keys: for world w, walk the median ray from the midpoint of the edge opposite e_w through the
centre to e_w; key of a step = the largest e_w-coordinate on that ray at which the step is present
(the two-world key, read along one ray); steps never present on the ray come first, ordered by the
global sup-present key.  Evaluated with exact cell enumeration (homothetic family)."""
import random, sys
import numpy as np
from core import *
from supkeys import sup_present_keys
from arrangement import hom_lines, enumerate_models
from evalkeys import kkm_with_splits
c = (F(1,3),)*3
def tri(s):
    return [tuple(s*((1 if i == k else 0) - c[i]) for i in range(3)) for k in range(3)]
AD = 'PSMC'
T = tri(F(3, 20)); K = fam_hom(T)
for seed in range(int(sys.argv[1])):
    N = 7
    G = random_lines(N, seed)
    cells = Cells(G, [1]*N)
    sup = sup_present_keys(G, T)
    keys = []
    for w in range(3):
        mid = [F(1, 2)]*3; mid[w] = F(0)
        e = [F(0)]*3; e[w] = F(1)
        M = 1200
        ray = [tuple(mid[i] + F(s, M)*(e[i]-mid[i]) for i in range(3)) for s in range(M+1)]
        models = [(p[w], coherent(K(p), G)) for p in ray]
        kw = {}
        for cc in range(N):
            for j in (1, 2):
                vals = [pw for pw, X in models if cells.R[w][cc][X[cc]] >= j]
                kw[(cc, j)] = (max(vals) if vals else F(-1), sup[w][(cc, j)][0], cc, j)
        keys.append(kw)
    cells.set_keys(keys)
    sel, sp = enumerate_models(K, G, hom_lines(G, T))
    nf = 0; ex = None
    for C, (sups, pts) in sel.items():
        g = cells.gates_from(C); k = cells.index[C]
        for s in sups:
            ok = np.zeros(cells.M, bool)
            for w in s: ok |= g[w][0] | g[w][1]
            ok[k] = True
            if (~ok).any():
                nf += 1
                if ex is None: ex = (C, s, tuple(int(a) for a in cells.models[int(np.argmax(~ok))]), pts[0])
    okk = kkm_with_splits(cells, sel, sp)
    print('seed', seed, 'selected', len(sel), 'non-competitive (model,support) pairs', nf, 'KKM-missing rivals', int((~okk).sum()))
    if ex:
        C, s, X, p = ex
        print('   e.g. base', ''.join(AD[a] for a in C), 'at p', [round(float(x), 3) for x in p], 'supp', s, 'rival', ''.join(AD[a] for a in X))
