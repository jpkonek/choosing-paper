"""Exact 'sup-present' keys for the homothetic family K_p = p + 3 min(p) T:
k_w(l, j) = sup{ p_w : step (l, j) belongs to U_w(C_p) }  (the three-world analogue of the two-world
key l^{-1}(t), u^{-1}(t)).  Computed by exact 2-D linear programming (vertex enumeration)."""
from fractions import Fraction as F
import itertools
from core import dot

def lin_sup(obj, cons):
    """max obj.p over {p: sum p = 1, a.p <= b for (a,b) in cons}; p in R^3.  Returns None if empty."""
    # parametrise p = (x, y, 1-x-y); each constraint a.p<=b -> (a0-a2) x + (a1-a2) y <= b - a2
    L = [((a[0]-a[2], a[1]-a[2]), b - a[2]) for a, b in cons]
    best = None
    for (u1, c1), (u2, c2) in itertools.combinations(L, 2):
        det = u1[0]*u2[1] - u1[1]*u2[0]
        if det == 0: continue
        x = (c1*u2[1] - c2*u1[1]) / det; y = (u1[0]*c2 - u2[0]*c1) / det
        if all(u[0]*x + u[1]*y <= c for u, c in L):
            p = (x, y, 1-x-y)
            val = dot(obj, p)
            if best is None or val > best: best = val
    return best

def sup_present_keys(G, T):
    keys = []
    for w in range(3):
        e = [F(0)]*3; e[w] = F(1)
        kw = {}
        for c, g in enumerate(G):
            gh = g if g[w] > 0 else tuple(-x for x in g)
            vals = {1: None, 2: None}
            for k in range(3):   # region p_k = min
                base = [((-1 if i == m else 0 for i in range(3)), F(0)) for m in range(3)]
                base = [(tuple(-F(1) if i == m else F(0) for i in range(3)), F(0)) for m in range(3)]
                reg = [(tuple((F(1) if i == k else F(0)) - (F(1) if i == m else F(0)) for i in range(3)), F(0)) for m in range(3) if m != k]
                # vertex v_t(p) = p + 3 p_k t ; v.gh = p.gh + 3 p_k (t.gh): linear coefficient vector
                def vcoef(t):
                    tg = dot(t, gh)
                    return tuple(gh[i] + (3*tg if i == k else 0) for i in range(3))
                # j=1: some vertex with v.gh <= 0
                for t in T:
                    v = lin_sup(e, base + reg + [(vcoef(t), F(0))])
                    if v is not None and (vals[1] is None or v > vals[1]): vals[1] = v
                # j=2: all vertices v.gh <= 0
                v = lin_sup(e, base + reg + [(vcoef(t), F(0)) for t in T])
                if v is not None and (vals[2] is None or v > vals[2]): vals[2] = v
            for j in (1, 2):
                kw[(c, j)] = (vals[j] if vals[j] is not None else F(-1), c, j)
        keys.append(kw)
    return keys
