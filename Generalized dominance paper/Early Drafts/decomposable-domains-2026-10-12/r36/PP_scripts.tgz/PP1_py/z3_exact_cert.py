"""Independent z3 re-check (integer keys) of a certificate produced by core_exact.py:
the listed competitiveness constraints and the listed KKM rivals (dominators = exactly enumerated
selected cell models and boundary splits) admit no per-world key orders (weak gate, gate-only)."""
import sys, pickle
import z3
from core import *
from arrangement import *
c = (F(1,3),)*3
def tri(s):
    return [tuple(s*((1 if i == k else 0) - c[i]) for i in range(3)) for k in range(3)]
d = pickle.load(open(sys.argv[1], 'rb'))
G = d['G']; N = len(G); R = rank_table(G)
T = tri(F(3, 20)); beta = F(1, 4)
Kf, Ls = (fam_hom(T), hom_lines(G, T)) if d['fam'] == 'hom' else (fam_mult(beta), mult_lines(G, beta))
sel, sp = enumerate_models(Kf, G, Ls)
k = [{(cc, j): z3.Int('k%d_%d_%d' % (w, cc, j)) for cc in range(N) for j in (1, 2)} for w in range(3)]
S = z3.Solver()
for w in range(3): S.add(z3.Distinct(*k[w].values()))
def accept(Csets, X, w):
    on = {(cc, j) for cc in range(N) for y in Csets[cc] for j in (1, 2) if R[w][cc][y] < j <= R[w][cc][X[cc]]}
    off = {(cc, j) for cc in range(N) for y in Csets[cc] for j in (1, 2) if R[w][cc][X[cc]] < j <= R[w][cc][y]}
    if not off: return z3.BoolVal(True)
    if not on: return z3.BoolVal(False)
    return z3.Or([z3.And([k[w][a] < k[w][b] for b in off]) for a in on])
for Cm, s, Xm in d['comp']:
    assert Cm in sel and s in sel[Cm][0]
    S.add(z3.Or([accept([(a,) for a in Cm], Xm, w) for w in s]))
cands = [tuple((a,) for a in Cm) for Cm in sel] + [tuple(tuple(sorted(x)) for x in t) for t in sp]
for X in d['riv']:
    assert X not in sel
    S.add(z3.Or([z3.And([accept(Cs, X, w) for w in range(3)]) for Cs in cands]))
print(sys.argv[1], 'competitiveness constraints', len(d['comp']), 'KKM rivals', len(d['riv']), 'z3:', S.check())
