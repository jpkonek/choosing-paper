"""Sup-present keys (exact, homothetic family) with problem lines concentrated near the target:
lines through random points within 0.12 of the centre, random directions.  Competitiveness
failures are reported with the index of the failing selected model, to see whether failures
occur near the target or only near the boundary of the simplex."""
import random, sys
import numpy as np
from core import *
from supkeys import sup_present_keys
from arrangement import hom_lines, enumerate_models
c = (F(1,3),)*3
def tri(s):
    return [tuple(s*((1 if i == k else 0) - c[i]) for i in range(3)) for k in range(3)]
AD = 'PSMC'
T = tri(F(3, 20))
def central_lines(N, seed):
    rnd = random.Random(seed); G = []
    while len(G) < N:
        q = [F(1,3) + F(rnd.randint(-12, 12), 100), F(1,3) + F(rnd.randint(-12, 12), 100)]
        q.append(1 - q[0] - q[1])
        d = (F(rnd.randint(-50, 50)), F(rnd.randint(-50, 50))); d = (d[0], d[1], -d[0]-d[1])
        if d == (0, 0, 0): continue
        q2 = tuple(q[i] + d[i]/100 for i in range(3))
        g = cross(tuple(q), q2)
        if all(a != 0 for a in g):
            if g[0] < 0: g = tuple(-a for a in g)
            G.append(g)
    return G
if __name__ == "__main__":
  for seed in range(int(sys.argv[1])):
      N = 7
      G = central_lines(N, seed)
      cells = Cells(G, [1]*N)
      cells.set_keys(sup_present_keys(G, T))
      sel, sp = enumerate_models(fam_hom(T), G, hom_lines(G, T))
      fails = []
      for C, (sups, pts) in sel.items():
          g = cells.gates_from(C); k = cells.index[C]
          for s in sups:
              ok = np.zeros(cells.M, bool)
              for w in s: ok |= g[w][0] | g[w][1]
              ok[k] = True
              if (~ok).any():
                  i = int(np.argmax(~ok))
                  fails.append((C, s, tuple(int(a) for a in cells.models[i]), pts))
      near = [f for f in fails if any(max(abs(float(x) - 1/3) for x in p) < 0.15 for p in f[3])]
      print('seed', seed, 'selected', len(sel), 'failing (model,support) pairs', len(fails), 'of which with an index within 0.15 of the centre:', len(near))
      for C, s, X, pts in near[:2]:
          print('   base', ''.join(AD[a] for a in C), 'p', [str(x) for x in pts[0]], 'supp', s, 'rival', ''.join(AD[a] for a in X))
