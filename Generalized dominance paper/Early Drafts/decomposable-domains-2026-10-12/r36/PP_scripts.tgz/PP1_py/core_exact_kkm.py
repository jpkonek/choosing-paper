"""Minimal KKM-only certificate with exact enumeration (no competitiveness constraint used)."""
import random, sys, pickle
from core import *
from satsplit import build
from arrangement import *
from pysat.solvers import Solver
c = (F(1,3),)*3
def tri(s):
    return [tuple(s*((1 if i == k else 0) - c[i]) for i in range(3)) for k in range(3)]
N, seed, fam = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
AD = 'PSMC'
G = random_lines(N, seed)
cells = Cells(G, [1]*N)
T = tri(F(3, 20)); beta = F(1, 4)
Kf, Ls = (fam_hom(T), hom_lines(G, T)) if fam == 'hom' else (fam_mult(beta), mult_lines(G, beta))
sel, sp = enumerate_models(Kf, G, Ls)
B = build(cells, sel, sp, use_comp=False, kkm_selectors=True)
pool = B['pool']
ks = [v for kk, v in pool.obj2id.items() if kk[0] == 'sel']
with Solver(name='cadical153', bootstrap_with=B['clauses']) as s:
    print('solve', s.solve(assumptions=ks))
    core = list(s.get_core()); i = 0
    while i < len(core):
        trial = core[:i] + core[i+1:]
        if not s.solve(assumptions=trial):
            cc = list(s.get_core()); core = cc if len(cc) < len(trial) else trial
        else: i += 1
riv = [pool.id2obj[v][1] for v in core]
print('KKM-only rivals:', [''.join(AD[a] for a in x) for x in riv])
for k, g in enumerate(G):
    print('line', k, ''.join('+' if a > 0 else '-' for a in g), [str(a) for a in g])
pickle.dump(dict(G=G, riv=riv, fam=fam, seed=seed), open('certkkm_%s_N%d_s%d.pkl' % (fam, N, seed), 'wb'))
