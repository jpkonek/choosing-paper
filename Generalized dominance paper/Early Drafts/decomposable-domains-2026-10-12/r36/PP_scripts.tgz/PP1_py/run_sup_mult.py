"""Sup-present keys on the hexagon family (imprecise on edges): k_w(s) = max{p_w : s in U_w(C_p)}
over a fine grid of indices, ties broken by a secondary key.  Reports competitiveness failures
(with the rival's precise-coherence status) and KKM (cell + split dominators)."""
import random, sys
import numpy as np
from core import *
from evalkeys import evaluate, kkm_with_splits, local_splits
from satrelax import grid_models, neighbourhoods
AD = 'PSMC'
Kf = fam_mult(F(1, 4))
Dk = 180; D = 60
for seed in range(int(sys.argv[1])):
    N = 7
    G = random_lines(N, seed)
    rnd = random.Random(seed+100); mass = [rnd.randint(1, 5) for _ in range(N)]
    cells = Cells(G, mass)
    ptsK = grid_models(Kf, G, Dk)
    R = cells.R
    keys = []
    for w in range(3):
        kw = {}
        for c in range(N):
            for j in (1, 2):
                vals = [F((a, b, Dk-a-b)[w], Dk) for (a, b), X in ptsK.items() if R[w][c][X[c]] >= j]
                kw[(c, j)] = (max(vals) if vals else F(-1), j, c)
        keys.append(kw)
    cells.set_keys(keys)
    pts = grid_models(Kf, G, D); sel = selected_models(Kf, G, D=D)
    r, ex = evaluate(cells, sel, neighbourhoods(pts, D), phi='none')
    ok = kkm_with_splits(cells, sel, local_splits(pts, D))
    prec = {}
    for x in simplex_grid(120):
        if min(x) > 0: prec.setdefault(coherent([x], G), x)
    miss = [tuple(int(a) for a in cells.models[i]) for i in np.nonzero(~ok)[0]]
    print('seed', seed, 'comp_fail', r['comp_fail'], 'in', r['comp_models'], 'models; dominated', r['dom'],
          '; KKM missing (cells+splits)', len(miss), 'of which precise D_x:', sum(1 for m in miss if m in prec))
    for C, s, X, p in ex['comp'][:1]:
        print('   comp-fail: base', ''.join(AD[a] for a in C), 'at p', [str(t) for t in p], 'supp', s, 'rival', ''.join(AD[a] for a in X),
              '(precise D_x)' if X in prec else '')
    for m in miss[:1]:
        print('   KKM-missing rival', ''.join(AD[a] for a in m), '(precise D_x, x=%s)' % [str(t) for t in prec[m]] if m in prec else '')
