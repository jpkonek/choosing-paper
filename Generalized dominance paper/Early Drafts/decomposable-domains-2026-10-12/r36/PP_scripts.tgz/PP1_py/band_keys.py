"""Band keys: k_w(l,1) = sup{p_w : l meets K_p}, k_w(l,2) = inf{p_w : l meets K_p} (over a fine grid
of indices).  These make every selected model a threshold set ON ITS SILENT BAND at every world
(step-2 keys of band lines <= p_w <= step-1 keys), which defeats every rival that changes only
silent advice.  Exact cell enumeration; competitiveness (gate-only) and dominators reported."""
import random, sys
import numpy as np
from core import *
from arrangement import *
from satrelax import grid_models
from evalkeys import kkm_with_splits
c = (F(1,3),)*3
def tri(s):
    return [tuple(s*((1 if i == k else 0) - c[i]) for i in range(3)) for k in range(3)]
AD = 'PSMC'
T = tri(F(3, 20)); beta = F(1, 4)
fam = sys.argv[1]
for seed in range(int(sys.argv[2])):
    N = 7
    G = random_lines(N, seed)
    cells = Cells(G, [1]*N)
    Kf, Ls = (fam_hom(T), hom_lines(G, T)) if fam == 'hom' else (fam_mult(beta), mult_lines(G, beta))
    Dk = 150
    ptsK = grid_models(Kf, G, Dk)
    keys = []
    for w in range(3):
        kw = {}
        for cc in range(N):
            vals = [F((a, b, Dk-a-b)[w], Dk) for (a, b), X in ptsK.items() if X[cc] == 1]
            hi = max(vals) if vals else F(-1); lo = min(vals) if vals else F(-1)
            kw[(cc, 1)] = (hi, 1, cc); kw[(cc, 2)] = (lo, 0, cc)
        keys.append(kw)
    cells.set_keys(keys)
    sel, sp = enumerate_models(Kf, G, Ls)
    nf = 0; ex = None
    for C, (sups, pts) in sel.items():
        g = cells.gates_from(C); k = cells.index[C]
        for s in sups:
            ok = np.zeros(cells.M, bool)
            for w in s: ok |= g[w][0] | g[w][1]
            ok[k] = True
            if (~ok).any():
                nf += 1
                i = int(np.argmax(~ok))
                if ex is None or (len(s) == 3 and len(ex[1]) < 3): ex = (C, s, tuple(int(a) for a in cells.models[i]), pts[0])
    okk = kkm_with_splits(cells, sel, sp)
    print(fam, 'seed', seed, 'selected', len(sel), 'non-competitive (model,support) pairs', nf, '; rivals without dominator', int((~okk).sum()))
    if ex:
        C, s, X, p = ex
        print('   e.g. base', ''.join(AD[a] for a in C), 'p', [round(float(x), 3) for x in p], 'supp', s, 'rival', ''.join(AD[a] for a in X))
