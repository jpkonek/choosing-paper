"""Exact enumeration of the selected cell models and of the boundary split models, for families
whose credal-set vertices are piecewise linear in the index p.  We take a superset of the switching
curves (all lines on which some candidate vertex of K_p meets some problem line, plus the lines
where the vertex formulas change), build the line arrangement in the index simplex exactly, and
sample every face (at a tiny exact offset from each arrangement vertex, inside each angular
sector).  Splits: at each arrangement vertex the advice sets over all faces around it, and along
each arrangement edge the advice sets of its two faces (these are the models at boundary indices of
the blown-up continuum model; a superset is harmless for unsatisfiability claims)."""
from fractions import Fraction as F
import itertools
from core import coherent, dot

def lin2d(alpha, beta0):
    """f(p) = alpha.p + beta0 with p = (x, y, 1-x-y)  ->  (a, b, c) with f = a x + b y + c"""
    return (alpha[0]-alpha[2], alpha[1]-alpha[2], alpha[2] + beta0)

def norm_line(L):
    a, b, c = L
    if a == 0 and b == 0: return None
    s = a if a != 0 else b
    return (a/s, b/s, c/s)

def hom_lines(G, T):
    Ls = set()
    for g in G:
        for t in T:
            tg = dot(t, g)
            for k in range(3):
                alpha = [g[i] + (3*tg if i == k else 0) for i in range(3)]
                Ls.add(norm_line(lin2d(alpha, F(0))))
    for i, j in itertools.combinations(range(3), 2):
        alpha = [F(0)]*3; alpha[i] = F(1); alpha[j] = F(-1)
        Ls.add(norm_line(lin2d(alpha, F(0))))
    return Ls

def mult_lines(G, beta):
    Ls = set()
    def forms(i):  # possible values of a bound on x_i as (alpha, const)
        e = [F(0)]*3
        out = []
        for coef in (1-beta, 1+beta):
            a = list(e); a[i] = coef; out.append((tuple(a), F(0)))
        out.append((tuple(e), F(1)))
        return out
    for i in range(3):
        a = [F(0)]*3; a[i] = 1+beta
        Ls.add(norm_line(lin2d(a, F(-1))))
    for i, j in itertools.permutations(range(3), 2):
        k = 3 - i - j
        for (ai, ci), (aj, cj) in itertools.product(forms(i), forms(j)):
            # x_i = ai.p+ci, x_j = aj.p+cj, x_k = 1 - x_i - x_j
            xi = (ai, ci); xj = (aj, cj)
            xk = (tuple(-ai[m]-aj[m] for m in range(3)), 1 - ci - cj)
            X = {i: xi, j: xj, k: xk}
            for g in G:
                alpha = tuple(sum(g[m]*X[m][0][q] for m in range(3)) for q in range(3))
                c0 = sum(g[m]*X[m][1] for m in range(3))
                L = norm_line(lin2d(alpha, c0))
                if L: Ls.add(L)
            for (ak, ck) in forms(k):   # feasibility of x_k
                alpha = tuple(xk[0][q] - ak[q] for q in range(3)); c0 = xk[1] - ck
                L = norm_line(lin2d(alpha, c0))
                if L: Ls.add(L)
    return Ls

def enumerate_models(Kfun, G, Ls):
    Ls = [L for L in Ls if L is not None]
    sides = [norm_line((F(1), F(0), F(0))), norm_line((F(0), F(1), F(0))), norm_line((F(1), F(1), F(-1)))]
    Ls = list(set(Ls) | set(sides))
    inside = lambda x, y: x >= 0 and y >= 0 and x + y <= 1
    val = lambda L, x, y: L[0]*x + L[1]*y + L[2]
    verts = {}
    for L1, L2 in itertools.combinations(Ls, 2):
        det = L1[0]*L2[1] - L1[1]*L2[0]
        if det == 0: continue
        x = (-L1[2]*L2[1] + L2[2]*L1[1]) / det; y = (-L1[0]*L2[2] + L2[0]*L1[2]) / det
        if inside(x, y): verts.setdefault((x, y), set()).update([L1, L2])
    P = lambda x, y: (x, y, 1-x-y)
    model = lambda x, y: coherent(Kfun(P(x, y)), G)
    def supp_of(x, y):
        return tuple(i for i, v in enumerate(P(x, y)) if v > 0)
    sel = {}
    def add_sel(x, y):
        Xm = model(x, y); s = supp_of(x, y)
        if Xm not in sel: sel[Xm] = [set(), []]
        sel[Xm][0].add(s)
        if len(sel[Xm][1]) < 3: sel[Xm][1].append(P(x, y))
        return Xm
    splits = set()
    for (x, y), through in verts.items():
        dirs = []
        for L in through:
            d = (L[1], -L[0]); dirs += [d, (-d[0], -d[1])]
        import math
        dirs.sort(key=lambda d: math.atan2(float(d[1]), float(d[0])))
        others = [L for L in Ls if L not in through]
        group = set()
        for k in range(len(dirs)):
            d1, d2 = dirs[k], dirs[(k+1) % len(dirs)]
            n1 = abs(d1[0]) + abs(d1[1]); n2 = abs(d2[0]) + abs(d2[1])
            d = (d1[0]/n1 + d2[0]/n2, d1[1]/n1 + d2[1]/n2)
            if d == (0, 0): continue
            eps = F(1, 10**6)
            for L in others:
                v = abs(val(L, x, y)); s = abs(L[0]*d[0]) + abs(L[1]*d[1])
                if s > 0: eps = min(eps, v/(2*s))
            qx, qy = x + eps*d[0], y + eps*d[1]
            if not inside(qx, qy): continue
            on_side = any(val(L, qx, qy) == 0 for L in sides)
            Xm = add_sel(qx, qy)
            group.add(Xm)
            # sample the ray direction itself too (points on an arrangement line, e.g. along a side)
        for d in dirs:
            eps = F(1, 10**6)
            for L in others:
                v = abs(val(L, x, y)); s = abs(L[0]*d[0]) + abs(L[1]*d[1])
                if s > 0: eps = min(eps, v/(2*s))
            qx, qy = x + eps*d[0], y + eps*d[1]
            if inside(qx, qy):
                Xm = add_sel(qx, qy); group.add(Xm)
        add_sel(x, y)
        if len(group) > 1:
            N = len(G)
            splits.add(tuple(frozenset(Y[c] for Y in group) for c in range(N)))
    return sel, splits
