# completeness check of the exact enumeration against a fine grid
import random, sys
from core import *
from arrangement import *
c = (F(1,3),)*3
def tri(s):
    return [tuple(s*((1 if i == k else 0) - c[i]) for i in range(3)) for k in range(3)]
N, seed, fam, D = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3], int(sys.argv[4])
G = random_lines(N, seed)
T = tri(F(3, 20)); beta = F(1, 4)
Kf, Ls = (fam_hom(T), hom_lines(G, T)) if fam == 'hom' else (fam_mult(beta), mult_lines(G, beta))
sel, sp = enumerate_models(Kf, G, Ls)
grid = selected_models(Kf, G, D=D)
missing = [X for X in grid if X not in sel]
supp_missing = [(X, s) for X in grid if X in sel for s in grid[X][0] if s not in sel[X][0]]
print(fam, seed, 'exact', len(sel), 'grid', len(grid), 'grid models missing from exact:', len(missing), 'support pairs missing:', len(supp_missing))
