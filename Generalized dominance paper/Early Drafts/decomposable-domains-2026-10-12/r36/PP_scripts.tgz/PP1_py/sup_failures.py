"""Sup-present keys k_w(s) = sup{p_w : s in U_w(C_p)} (exact, homothetic family).
(1) Lemma check: C_p <=_w X (gate-only) whenever p_w > psi_w(X) := min key over X's world-w steps.
(2) Every competitiveness failure has sum_w psi_w(X) >= 1.
(3) Whether the failing rival is a precise coherent model D_x (search over a grid of x)."""
import random, sys
import numpy as np
from core import *
from supkeys import sup_present_keys
from satrelax import grid_models
c = (F(1,3),)*3
def tri(s):
    return [tuple(s*((1 if i == k else 0) - c[i]) for i in range(3)) for k in range(3)]
AD = 'PSMC'
T = tri(F(3, 20))
for seed in range(int(sys.argv[1])):
    N = 7
    G = random_lines(N, seed)
    cells = Cells(G, [1]*N)
    keys = sup_present_keys(G, T)
    cells.set_keys(keys)
    D = 60
    pts = grid_models(fam_hom(T), G, D)
    sel = selected_models(fam_hom(T), G, D=D)
    # psi_w(X)
    psi = []
    for w in range(3):
        arr = np.full(cells.M, 2.0)
        for cc in range(N):
            for j in (1, 2):
                kv = float(keys[w][(cc, j)][0])
                has = cells.RK[w][:, cc] >= j
                arr = np.where(has, np.minimum(arr, kv), arr)
        psi.append(arr)
    lemma_viol = 0; fails = []
    for (a, b), C in pts.items():
        p = (F(a, D), F(b, D), F(D-a-b, D))
        g = cells.gates_from(C)
        for w in range(3):
            acc = g[w][0] | g[w][1]
            lemma_viol += int(((psi[w] < float(p[w])) & ~acc).sum())
    for C, (sups, sp) in sel.items():
        g = cells.gates_from(C); k = cells.index[C]
        for s in sups:
            ok = np.zeros(cells.M, bool)
            for w in s: ok |= g[w][0] | g[w][1]
            ok[k] = True
            for i in np.nonzero(~ok)[0]:
                fails.append((C, s, tuple(int(x) for x in cells.models[i]), float(psi[0][i] + psi[1][i] + psi[2][i])))
    # precise coherent rivals
    prec = {}
    for x in simplex_grid(120):
        if min(x) == 0: continue
        prec.setdefault(coherent([x], G), x)
    nprec = sum(1 for f in fails if f[2] in prec)
    print('seed', seed, 'lemma violations', lemma_viol, 'comp failures', len(fails),
          'min sum psi over failures', min((f[3] for f in fails), default=None), 'failing rivals that are precise D_x:', nprec)
    for f in fails[:2]:
        if f[2] in prec:
            print('   e.g. base', ''.join(AD[a] for a in f[0]), 'supp', f[1], 'rival', ''.join(AD[a] for a in f[2]), '= D_x for x =', [str(t) for t in prec[f[2]]])
