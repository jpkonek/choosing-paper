"""Direct (non-SAT) evaluation of given keys: exact competitiveness, undominatedness,
strict KKM and closure-relaxed KKM, under the weak gate with a chosen verdict."""
import numpy as np
from core import *
from satrelax import grid_models, neighbourhoods

def acc_from(cells, C, phi):
    g = cells.gates_from(C)
    out = []
    for w in range(3):
        guid, gate = g[w]
        if phi == 'none': out.append(guid | gate)
        else:
            on, off = cells.onoff_mass(C, w)
            out.append(guid | (gate & (phi(on, off, w, C) >= 0)))
    return out

def sticky(on, off, w, C): return 2*on - off

def evaluate(cells, sel, nbs, phi='none', nex=3):
    res = dict(nsel=len(sel), comp_fail=0, comp_models=0, dom=0, kkm_strict_missing=0, kkm_relaxed_missing=0)
    ex = dict(comp=[], kkm=[])
    acc = {}
    for C in set(sel) | set().union(*nbs):
        acc[C] = acc_from(cells, C, phi)
    for C in sel:
        k = cells.index[C]
        notC = np.ones(cells.M, bool); notC[k] = False
        bad_any = False
        for s in sel[C][0]:
            ok = np.zeros(cells.M, bool)
            for w in s: ok |= acc[C][w]
            bad = notC & ~ok
            if bad.any():
                bad_any = True; res['comp_fail'] += int(bad.sum())
                if len(ex['comp']) < nex:
                    ex['comp'].append((C, s, tuple(int(a) for a in cells.models[np.argmax(bad)]), sel[C][1][0]))
        res['comp_models'] += bad_any
    strict = np.zeros(cells.M, bool)
    for C in sel:
        strict |= acc[C][0] & acc[C][1] & acc[C][2]
    relaxed = np.zeros(cells.M, bool)
    for nb in nbs:
        a = np.ones(cells.M, bool)
        for w in range(3):
            o = np.zeros(cells.M, bool)
            for C in nb: o |= acc[C][w]
            a &= o
        relaxed |= a
    for C in sel:
        relaxed[cells.index[C]] = True; strict[cells.index[C]] = True
    res['kkm_strict_missing'] = int((~strict).sum())
    res['kkm_relaxed_missing'] = int((~relaxed).sum())
    ex['kkm'] = [tuple(int(a) for a in cells.models[i]) for i in np.nonzero(~relaxed)[0][:nex]]
    return res, ex

def split_accept(cells, nb):
    """weak-gate acceptance Chat <=_w X (gate-only) for the split model of neighbourhood nb:
    at each atom the advice set is {C(c): C in nb}; vs X every member differing from X(c)
    contributes its changed steps (keys of distinct steps are distinct, so the within-atom
    order is determined by the step keys)."""
    N = cells.N
    sets = [sorted({C[c] for C in nb}) for c in range(N)]
    out = []
    for w in range(3):
        on = np.zeros(cells.M, np.int64); off = np.zeros(cells.M, np.int64)
        for c in range(N):
            tab_on = np.zeros(4, np.int64); tab_off = np.zeros(4, np.int64)
            for x in range(4):
                rx = cells.R[w][c][x]
                for y in sets[c]:
                    ry = cells.R[w][c][y]
                    for j in (1, 2):
                        b = np.int64(1) << np.int64(cells.bitpos[w][(c, j)])
                        if ry < j <= rx: tab_on[x] |= b
                        if rx < j <= ry: tab_off[x] |= b
            xc = cells.models[:, c]
            on |= tab_on[xc]; off |= tab_off[xc]
        lo_on = on & -on; lo_off = off & -off
        out.append((off == 0) | ((on != 0) & (lo_on < lo_off)))
    return out

def kkm_split_missing(cells, sel, nbs):
    ok = np.zeros(cells.M, bool)
    for nb in nbs:
        a = split_accept(cells, nb)
        ok |= a[0] & a[1] & a[2]
    for C in sel: ok[cells.index[C]] = True
    return ok

def local_splits(pts, D):
    """advice-set models at grid edges and grid triangles (finite stand-ins for boundary points)"""
    S = set()
    for (a, b), X in pts.items():
        for nbrs in (((1, 0),), ((0, 1),), ((1, -1),), ((1, 0), (0, 1)), ((1, 0), (1, -1))):
            qs = [(a+da, b+db) for da, db in nbrs]
            if all(q in pts for q in qs):
                group = [X] + [pts[q] for q in qs]
                if len(set(group)) > 1:
                    S.add(tuple(frozenset(Y[c] for Y in group) for c in range(len(X))))
    return S

def split_accept_sets(cells, sets):
    N = cells.N
    out = []
    for w in range(3):
        on = np.zeros(cells.M, np.int64); off = np.zeros(cells.M, np.int64)
        for c in range(N):
            tab_on = np.zeros(4, np.int64); tab_off = np.zeros(4, np.int64)
            for x in range(4):
                rx = cells.R[w][c][x]
                for y in sets[c]:
                    ry = cells.R[w][c][y]
                    for j in (1, 2):
                        b = np.int64(1) << np.int64(cells.bitpos[w][(c, j)])
                        if ry < j <= rx: tab_on[x] |= b
                        if rx < j <= ry: tab_off[x] |= b
            xc = cells.models[:, c]
            on |= tab_on[xc]; off |= tab_off[xc]
        lo_on = on & -on; lo_off = off & -off
        out.append((off == 0) | ((on != 0) & (lo_on < lo_off)))
    return out

def kkm_with_splits(cells, sel, splits):
    ok = np.zeros(cells.M, bool)
    for C in sel:
        a = cells.gates_from(C)
        ok |= np.logical_and.reduce([g[0] | g[1] for g in a])
        ok[cells.index[C]] = True
    for s in splits:
        a = split_accept_sets(cells, s)
        ok |= a[0] & a[1] & a[2]
    return ok
