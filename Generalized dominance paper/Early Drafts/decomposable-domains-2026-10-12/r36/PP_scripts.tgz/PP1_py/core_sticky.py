# minimal set of competitiveness constraints that no key orders can satisfy, sticky verdict
import random, sys
from core import *
from satsplit import *
from satrelax import grid_models
from pysat.solvers import Solver
c = (F(1,3),)*3
def tri(s):
    return [tuple(s*((1 if i == k else 0) - c[i]) for i in range(3)) for k in range(3)]
N = int(sys.argv[1]); seed = int(sys.argv[2]); D = int(sys.argv[3])
AD = 'PSMC'
G = random_lines(N, seed)
rnd = random.Random(seed+100); mass = [rnd.randint(1, 5) for _ in range(N)]
cells = Cells(G, mass)
Kf = fam_hom(tri(F(3, 20)))
sel = selected_models(Kf, G, D=D)
B = build(cells, sel, [], phi='sticky', use_kkm=False, comp_selectors=True)
pool = B['pool']
sels = [v for k, v in pool.obj2id.items() if k[0] == 'csel']
with Solver(name='cadical153', bootstrap_with=B['clauses']) as s:
    print('solve', s.solve(assumptions=sels))
    core = list(s.get_core()); print('core', len(core))
    i = 0
    while i < len(core):
        trial = core[:i] + core[i+1:]
        if not s.solve(assumptions=trial):
            cc = list(s.get_core()); core = cc if len(cc) < len(trial) else trial
        else: i += 1
for k, g in enumerate(G):
    print('line', k, ''.join('+' if a > 0 else '-' for a in g), 'mass', mass[k])
for v in core:
    _, Cm, sup, Xm = pool.id2obj[v]
    print('  C', ''.join(AD[a] for a in Cm), 'supp', sup, 'p', [str(x) for x in sel[Cm][1][0]], ' rival', ''.join(AD[a] for a in Xm))
