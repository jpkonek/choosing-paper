"""Exact instance for Proposition B: two interior selected credal sets of the homothetic family
that are crossed under odd-1 separation (each lies on e_1's side of some odd-1 line that has the
other beyond it).  Under the weak gate with any keys, a mass-sensitive verdict then makes one of
the two selected models non-competitive."""
from core import *
c = (F(1,3),)*3
s = F(3, 20)
T = [tuple(s*((1 if i == k else 0) - c[i]) for i in range(3)) for k in range(3)]
import sys
K = fam_hom(T) if (len(sys.argv) < 2 or sys.argv[1] == 'hom') else fam_mult(F(1, 4))
print('family', 'homothetic triangles' if K.__qualname__.startswith('fam_hom') else 'hexagons |x_i-p_i|<=p_i/4')
d = F(3, 20)
p = (F(1,3), F(1,3)+d, F(1,3)-d)
q = (F(1,3), F(1,3)-d, F(1,3)+d)
Kp, Kq = K(p), K(q)
print('K_p vertices', [[str(x) for x in v] for v in Kp])
print('K_q vertices', [[str(x) for x in v] for v in Kq])
def side(g, Kv):
    vals = [dot(v, g) for v in Kv]
    return 1 if min(vals) > 0 else (-1 if max(vals) < 0 else 0)
def odd1(g):  # e_1 alone on the positive side
    return g[0] > 0 and g[1] < 0 and g[2] < 0
found = {}
# lines through two edge points: on edge e1e2 (x3=0) and edge e1e3 (x2=0): corner lines at e_1
for a in range(1, 40):
    for b in range(1, 40):
        u = (1-F(a, 40), F(a, 40), F(0)); v = (1-F(b, 40), F(0), F(b, 40))
        g = cross(u, v)
        if dot(g, (1, 0, 0)) < 0: g = tuple(-x for x in g)
        if not odd1(g): continue
        sp, sq = side(g, Kp), side(g, Kq)
        if sp == 1 and sq == -1 and 'a' not in found: found['a'] = (a, b, g)
        if sp == -1 and sq == 1 and 'b' not in found: found['b'] = (a, b, g)
for k, (a, b, g) in found.items():
    print('line', k, ': through', [str(1-F(a,40)), str(F(a,40)), '0'], 'and', [str(1-F(b,40)), '0', str(F(b,40))],
          ' g =', [str(x) for x in g], ' side(K_p) =', side(g, Kp), ' side(K_q) =', side(g, Kq))
# the two models
Cp = coherent(Kp, [found['a'][2], found['b'][2]]); Cq = coherent(Kq, [found['a'][2], found['b'][2]])
print('advice of C_p on (l_a, l_b):', Cp, '  advice of C_q:', Cq, '  (0 = accept g, 2 = accept -g)')
