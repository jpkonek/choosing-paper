"""(TC) sanity check: the weak-gated worlds have no cycles (full four-advice domain, contradiction
and a unanimous problem included, exact integer masses), for random keys, gate-only and sticky
verdicts.  Unanimous cell: P correct at every world.  Contradiction steps and unanimous steps get
the lowest keys.  Topological sort of the whole accepted relation of each world."""
import itertools, random
import numpy as np
from core import random_lines, rank_table
def run(Nm, seed, verdict):
    rnd = random.Random(seed)
    G = random_lines(Nm, seed)
    R = rank_table(G)
    for w in range(3): R[w].append((0, 1, 2, 3))          # unanimous cell
    N = Nm + 1
    mass = [rnd.randint(1, 5) for _ in range(N)]
    models = list(itertools.product(range(4), repeat=N))
    ok_all = True
    for w in range(3):
        reg = [(c, j) for c in range(Nm) for j in (1, 2)]; rnd.shuffle(reg)
        low = [(c, 3) for c in range(N)] + [(Nm, j) for j in (1, 2)]; rnd.shuffle(low)
        key = {s: i for i, s in enumerate(low + reg)}
        U = [frozenset((c, j) for c in range(N) for j in (1, 2, 3) if R[w][c][X[c]] >= j) for X in models]
        def acc(a, b):
            if a == b: return True
            on = U[b] - U[a]; off = U[a] - U[b]
            if not off: return True
            if not on: return False
            if min(key[s] for s in on) >= min(key[s] for s in off): return False
            if verdict == 'sticky':
                m = lambda S: sum(mass[c] for c, j in S)
                return 2*m(on) - m(off) >= 0
            return True
        M = len(models)
        indeg = [0]*M; succ = [[] for _ in range(M)]
        for a in range(M):
            for b in range(M):
                if a != b and acc(a, b): succ[a].append(b); indeg[b] += 1
        stack = [a for a in range(M) if indeg[a] == 0]; seen = 0
        while stack:
            a = stack.pop(); seen += 1
            for b in succ[a]:
                indeg[b] -= 1
                if indeg[b] == 0: stack.append(b)
        ok_all &= (seen == M)
    return ok_all
for seed in range(4):
    for v in ('gate-only', 'sticky'):
        print('seed', seed, v, 'acyclic at all three worlds:', run(3, seed, v))
