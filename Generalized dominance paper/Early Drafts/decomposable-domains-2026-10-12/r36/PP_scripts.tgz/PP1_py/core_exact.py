"""Minimal certificate (exact enumeration): first a minimal set of KKM rivals (all competitiveness
constraints kept), then a minimal set of competitiveness constraints for those rivals."""
import random, sys, pickle
from core import *
from satsplit import build
from arrangement import *
from pysat.solvers import Solver
c = (F(1,3),)*3
def tri(s):
    return [tuple(s*((1 if i == k else 0) - c[i]) for i in range(3)) for k in range(3)]
N, seed, fam = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
AD = 'PSMC'
G = random_lines(N, seed)
rnd = random.Random(seed+100); mass = [rnd.randint(1, 5) for _ in range(N)]
cells = Cells(G, mass)
T = tri(F(3, 20)); beta = F(1, 4)
Kf, Ls = (fam_hom(T), hom_lines(G, T)) if fam == 'hom' else (fam_mult(beta), mult_lines(G, beta))
sel, sp = enumerate_models(Kf, G, Ls)
def minimise(clauses, sels):
    with Solver(name='cadical153', bootstrap_with=clauses) as s:
        assert not s.solve(assumptions=sels)
        core = list(s.get_core()); i = 0
        while i < len(core):
            trial = core[:i] + core[i+1:]
            if not s.solve(assumptions=trial):
                cc = list(s.get_core()); core = cc if len(cc) < len(trial) else trial
            else: i += 1
    return core
B = build(cells, sel, sp, kkm_selectors=True)
pool = B['pool']
ks = [v for kk, v in pool.obj2id.items() if kk[0] == 'sel']
core = minimise(B['clauses'], ks)
riv = [pool.id2obj[v][1] for v in core]
print('KKM rivals:', [''.join(AD[a] for a in x) for x in riv], flush=True)
B2 = build(cells, sel, sp, comp_selectors=True, kkm_only=riv)
pool2 = B2['pool']
cs = [v for kk, v in pool2.obj2id.items() if kk[0] == 'csel']
core2 = minimise(B2['clauses'], cs)
comp = [pool2.id2obj[v][1:] for v in core2]
for Cm, s, Xm in comp:
    print('  comp: base', ''.join(AD[a] for a in Cm), 'supp', s, 'p', [str(x) for x in sel[Cm][1][0]], 'rival', ''.join(AD[a] for a in Xm))
for k, g in enumerate(G):
    print('line', k, ''.join('+' if a > 0 else '-' for a in g), [str(a) for a in g])
pickle.dump(dict(G=G, mass=mass, riv=riv, comp=comp, fam=fam, seed=seed), open('cert_%s_N%d_s%d.pkl' % (fam, N, seed), 'wb'))
