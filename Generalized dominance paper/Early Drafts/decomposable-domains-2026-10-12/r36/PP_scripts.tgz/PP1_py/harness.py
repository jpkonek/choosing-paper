import numpy as np
from core import *

def phi_none(cells, C, w):
    return None

def phi_sticky(cells, C, w):
    on, off = cells.onoff_mass(C, w)
    return 2*on - off

def evaluate(cells, sel, phi=phi_none, want_examples=3, kkm=True):
    """sel: dict model -> [supports, sample points].  Returns summary dict."""
    res = dict(n_sel=len(sel), comp_fail=0, comp_fail_models=0, dominated=0, kkm_missing=0)
    ex = dict(comp=[], dom=[], kkm=[])
    selmodels = list(sel.keys())
    # KKM accumulator: rivals that have a dominator
    has_dom = np.zeros(cells.M, dtype=bool)
    for C in selmodels:
        sups = sel[C][0]
        g = cells.gates_from(C)
        acc = []
        for w in range(3):
            guid, gate = g[w]
            if phi is phi_none:
                acc.append(guid | gate)
            else:
                ph = phi(cells, C, w)
                acc.append(guid | (gate & (ph >= 0)))
        k = cells.index[C]
        notC = np.ones(cells.M, dtype=bool); notC[k] = False
        bad_any = False
        for s in sups:
            ok = np.zeros(cells.M, dtype=bool)
            for w in s: ok |= acc[w]
            bad = notC & ~ok
            nb = int(bad.sum())
            if nb:
                bad_any = True
                res['comp_fail'] += nb
                if len(ex['comp']) < want_examples:
                    X = tuple(int(a) for a in cells.models[np.argmax(bad)])
                    ex['comp'].append((C, s, X, sel[C][1][0]))
        res['comp_fail_models'] += bad_any
        # undominated
        gi = cells.gates_into(C)
        dacc = np.ones(cells.M, dtype=bool)
        for w in range(3):
            guid, gate = gi[w]
            if phi is phi_none:
                dacc &= (guid | gate)
            else:
                # verdict on pair (X, C): Phi_w(X,C) = 2*on - off with on = steps C adds over X
                on, off = cells.onoff_mass(C, w)  # on: X adds over C ; off: X removes
                ph = 2*off - on
                dacc &= (guid | (gate & (ph >= 0)))
        dom = dacc & notC
        nd = int(dom.sum())
        res['dominated'] += nd
        if nd and len(ex['dom']) < want_examples:
            ex['dom'].append((C, tuple(int(a) for a in cells.models[np.argmax(dom)])))
        if kkm:
            all3 = acc[0] & acc[1] & acc[2]
            has_dom |= all3
    if kkm:
        miss = ~has_dom
        res['kkm_missing'] = int(miss.sum())
        idx = np.nonzero(miss)[0][:want_examples]
        ex['kkm'] = [tuple(int(a) for a in cells.models[i]) for i in idx]
    return res, ex
