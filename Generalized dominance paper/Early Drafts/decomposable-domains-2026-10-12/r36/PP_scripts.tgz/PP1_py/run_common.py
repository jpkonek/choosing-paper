"""Lead's sketch: one common order of problems at all three worlds (k_w(g,j) = 2*kappa(g) + j).
Exact cell enumeration (homothetic and hexagon families).  Reports: competitiveness failures
(gate-only verdict; on atoms there are no ties), undominatedness failures, and regular rivals with
no dominator among the selected cell models, and among cell models plus boundary splits."""
import random, sys
import numpy as np
from core import *
from arrangement import *
from evalkeys import kkm_with_splits
c = (F(1,3),)*3
def tri(s):
    return [tuple(s*((1 if i == k else 0) - c[i]) for i in range(3)) for k in range(3)]
T = tri(F(3, 20)); beta = F(1, 4)
for fam in ('hom', 'mult'):
    for seed in range(3):
        N = 7
        G = random_lines(N, seed)
        cells = Cells(G, [1]*N)
        rnd = random.Random(seed); perm = list(range(N)); rnd.shuffle(perm)
        k = {(cc, j): 2*perm[cc] + j for cc in range(N) for j in (1, 2)}
        cells.set_keys([k, k, k])
        Kf, Ls = (fam_hom(T), hom_lines(G, T)) if fam == 'hom' else (fam_mult(beta), mult_lines(G, beta))
        sel, sp = enumerate_models(Kf, G, Ls)
        comp = dom = 0
        strict = np.zeros(cells.M, bool)
        for C, (sups, pts) in sel.items():
            g = cells.gates_from(C); gi = cells.gates_into(C); kk = cells.index[C]
            acc = [g[w][0] | g[w][1] for w in range(3)]
            for s in sups:
                ok = np.zeros(cells.M, bool)
                for w in s: ok |= acc[w]
                ok[kk] = True; comp += int((~ok).sum())
            d = np.logical_and.reduce([gi[w][0] | gi[w][1] for w in range(3)]); d[kk] = False; dom += int(d.sum())
            strict |= acc[0] & acc[1] & acc[2]
            strict[kk] = True
        withsplit = kkm_with_splits(cells, sel, sp)
        nonsel = cells.M - len(sel)
        print(fam, 'seed', seed, 'selected', len(sel), 'non-selected regular rivals', nonsel,
              '| competitiveness failures', comp, '| dominated selected', dom,
              '| rivals without a cell dominator', int((~strict).sum()), '| without a cell-or-split dominator', int((~withsplit).sum()))
