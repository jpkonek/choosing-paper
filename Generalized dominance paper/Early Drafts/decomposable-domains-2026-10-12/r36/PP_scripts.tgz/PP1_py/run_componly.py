# Competitiveness alone (no KKM): is there a key order? gate-only and sticky verdicts.
import random, sys, time
from core import *
from satsplit import build, solve
c = (F(1,3),)*3
def tri(s):
    return [tuple(s*((1 if i == k else 0) - c[i]) for i in range(3)) for k in range(3)]
N = int(sys.argv[1]); seeds = [int(a) for a in sys.argv[2].split(',')]; fam = sys.argv[3]
for seed in seeds:
    G = random_lines(N, seed)
    rnd = random.Random(seed+100); mass = [rnd.randint(1, 5) for _ in range(N)]
    cells = Cells(G, mass)
    Kf = {'hom': fam_hom(tri(F(3, 20))), 'mult': fam_mult(F(1, 4))}[fam]
    sel = selected_models(Kf, G, D=60)
    out = []
    for phi in ('none', 'sticky'):
        B = build(cells, sel, [], phi=phi, use_kkm=False)
        ok, _ = solve(B)
        out.append((phi, {True: 'SAT', False: 'UNSAT', None: 'TRIVIAL-FAIL'}[ok]))
    print(fam, 'N', N, 'seed', seed, out, flush=True)
