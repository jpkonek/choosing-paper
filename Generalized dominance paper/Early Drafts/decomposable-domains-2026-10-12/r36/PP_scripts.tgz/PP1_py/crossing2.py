"""Exact crossed pairs (Proposition 2) for both families: two interior indices p, q whose credal
sets are separated by an odd-1 line with K_p on e_1's side, and by another with K_q on e_1's side."""
import sys
from core import *
c = (F(1,3),)*3
s = F(3, 20)
T = [tuple(s*((1 if i == k else 0) - c[i]) for i in range(3)) for k in range(3)]
fams = {'homothetic triangles (s=3/20)': fam_hom(T), 'hexagons |x_i-p_i|<=p_i/4': fam_mult(F(1, 4))}
pairs = [((F(1,3), F(1,3)+F(3,20), F(1,3)-F(3,20)), (F(1,3), F(1,3)-F(3,20), F(1,3)+F(3,20))),
         ((F(3,5), F(3,10), F(1,10)), (F(3,5), F(1,10), F(3,10)))]
def side(g, Kv):
    vals = [dot(v, g) for v in Kv]
    return 1 if min(vals) > 0 else (-1 if max(vals) < 0 else 0)
for name, K in fams.items():
    for p, q in pairs:
        Kp, Kq = K(p), K(q); found = {}
        den = 120
        for a in range(1, den):
            for b in range(1, den):
                u = (1-F(a, den), F(a, den), F(0)); v = (1-F(b, den), F(0), F(b, den))
                g = cross(u, v)
                if g[0] < 0: g = tuple(-x for x in g)
                if not (g[0] > 0 and g[1] < 0 and g[2] < 0): continue
                sp, sq = side(g, Kp), side(g, Kq)
                if sp == 1 and sq == -1: found.setdefault('a', (u, v, g))
                if sp == -1 and sq == 1: found.setdefault('b', (u, v, g))
        print(name, ' p =', [str(x) for x in p], ' q =', [str(x) for x in q])
        for kk in ('a', 'b'):
            if kk in found:
                u, v, g = found[kk]
                print('   line %s through' % kk, [str(x) for x in u], 'and', [str(x) for x in v], ': K_p on', 'e_1 side' if side(g, Kp) == 1 else 'far side',
                      ', K_q on', 'e_1 side' if side(g, Kq) == 1 else 'far side')
            else:
                print('   no line', kk)
