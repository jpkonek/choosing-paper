"""SAT over all key orders with EXACT enumeration of selected cells and boundary splits."""
import random, sys, time
from core import *
from satsplit import build, solve
from arrangement import *
c = (F(1,3),)*3
def tri(s):
    return [tuple(s*((1 if i == k else 0) - c[i]) for i in range(3)) for k in range(3)]
N = int(sys.argv[1]); seeds = [int(a) for a in sys.argv[2].split(',')]; fam = sys.argv[3]
modes = sys.argv[4].split(',') if len(sys.argv) > 4 else ['kkm', 'comp', 'both']
phi = sys.argv[5] if len(sys.argv) > 5 else 'none'
for seed in seeds:
    G = random_lines(N, seed)
    rnd = random.Random(seed+100); mass = [rnd.randint(1, 5) for _ in range(N)]
    cells = Cells(G, mass)
    T = tri(F(3, 20)); beta = F(1, 4)
    if fam == 'hom': Kf, Ls = fam_hom(T), hom_lines(G, T)
    else: Kf, Ls = fam_mult(beta), mult_lines(G, beta)
    t = time.time()
    sel, sp = enumerate_models(Kf, G, Ls)
    out = []
    for m in modes:
        B = build(cells, sel, sp, phi=phi, use_kkm=(m != 'comp'), use_comp=(m != 'kkm'))
        ok, _ = solve(B)
        out.append((m, {True: 'SAT', False: 'UNSAT', None: 'TRIVIAL-FAIL'}[ok]))
    print(fam, 'phi', phi, 'N', N, 'seed', seed, 'lines', len(Ls), 'nsel', len(sel), 'nsplit', len(sp), out, '%.0fs' % (time.time()-t), flush=True)
