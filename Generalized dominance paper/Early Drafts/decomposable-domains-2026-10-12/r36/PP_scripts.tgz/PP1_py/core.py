"""Three-world finite cell models for the weak gate (PP1).
Problems: N mixed cells, each a direction g in Z^3 with mixed signs (a line {x: g.x=0}
through the simplex).  Advice per cell: 0=P (accept g), 1=S, 2=M (accept -g), 3=C.
World-i rank: P -> 0 if g_i>0 else 2; M -> the other; S -> 1; C -> 3.
Rank steps (c,j), j=1,2,3, present iff rank >= j.
Unanimous problems and contradiction steps have the lowest keys at every world; out of a
coherent model any change there is an addition at every world, so under the weak gate such a
rival passes the gate at all three worlds.  Hence the gate-only tests use regular rivals on mixed
cells; the verdict tests add contradiction separately.
All geometry is exact (Fractions)."""
from fractions import Fraction as F
import itertools, random
import numpy as np

# ---------------------------------------------------------------- geometry
def cross(u, v):
    return (u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0])

def dot(u, v):
    return sum(a*b for a, b in zip(u, v))

def edge_point(e, s):
    """point on edge e in {0,1,2} (edge opposite vertex e) at parameter s in (0,1)"""
    i, j = [k for k in range(3) if k != e]
    x = [F(0)]*3; x[i] = 1-s; x[j] = s
    return tuple(x)

def random_lines(N, seed, den=97):
    rnd = random.Random(seed)
    G = []
    while len(G) < N:
        e1, e2 = rnd.sample(range(3), 2)
        u = edge_point(e1, F(rnd.randint(1, den-1), den))
        v = edge_point(e2, F(rnd.randint(1, den-1), den))
        g = cross(u, v)
        g = tuple(F(a) for a in g)
        if all(a != 0 for a in g):
            # normalise sign: first coordinate positive
            if g[0] < 0: g = tuple(-a for a in g)
            G.append(g)
    return G

def lines_through(points_pairs):
    G = []
    for u, v in points_pairs:
        g = cross(u, v)
        if g[0] < 0: g = tuple(-a for a in g)
        G.append(g)
    return G

def coherent(Kverts, G):
    """advice tuple of D_K on lines G (K given by its vertices)"""
    X = []
    for g in G:
        vals = [dot(v, g) for v in Kverts]
        if min(vals) > 0: X.append(0)
        elif max(vals) < 0: X.append(2)
        else: X.append(1)
    return tuple(X)

# ---------------------------------------------------------------- ranks / steps
def rank_table(G):
    """R[w][c][a] rank of advice a at cell c, world w"""
    R = []
    for w in range(3):
        Rw = []
        for g in G:
            if g[w] > 0: Rw.append((0, 1, 2, 3))
            else: Rw.append((2, 1, 0, 3))
        R.append(Rw)
    return R

def simplex_grid(D):
    pts = []
    for a in range(D+1):
        for b in range(D+1-a):
            pts.append((F(a, D), F(b, D), F(D-a-b, D)))
    return pts

def supp(p):
    return tuple(i for i in range(3) if p[i] > 0)

# ---------------------------------------------------------------- families
def fam_hom(T):
    """K_p = p + rho(p) T, rho = 3 min_i p_i, T a list of offset vectors (sum 0)"""
    def K(p):
        rho = 3*min(p)
        return [tuple(p[i]+rho*t[i] for i in range(3)) for t in T]
    return K

def fam_eps(eps_star):
    """epsilon-contamination K_p = (1-e)p + e*Simplex, e = eps_star*3*min p"""
    def K(p):
        e = eps_star*3*min(p)
        return [tuple((1-e)*p[i] + (e if i == k else 0) for i in range(3)) for k in range(3)]
    return K

def fam_precise():
    return lambda p: [p]

def selected_models(Kfun, G, D=60, extra=()):
    """dict model -> (set of supports, list of sample p)"""
    sel = {}
    for p in list(simplex_grid(D)) + list(extra):
        X = coherent(Kfun(p), G)
        s = supp(p)
        if X not in sel: sel[X] = [set(), []]
        sel[X][0].add(s)
        if len(sel[X][1]) < 3: sel[X][1].append(p)
    return sel

# ---------------------------------------------------------------- vectorised rival tables
class Cells:
    def __init__(self, G, mass, regular_only=True):
        self.G = G; self.N = len(G); self.mass = [F(m) for m in mass]
        self.R = rank_table(G)
        A = 3 if regular_only else 4
        self.models = np.array(list(itertools.product(range(A), repeat=self.N)), dtype=np.int64)
        self.M = len(self.models)
        # rank arrays per world: shape (M, N)
        self.RK = []
        for w in range(3):
            tab = np.array([self.R[w][c] for c in range(self.N)], dtype=np.int64)  # (N,4)
            self.RK.append(tab[np.arange(self.N)[None, :], self.models])
        assert all(m.denominator == 1 for m in self.mass)
        self.mass_f = np.array([int(m) for m in self.mass], dtype=np.int64)
        self.index = {tuple(int(a) for a in row): k for k, row in enumerate(self.models)}

    def set_keys(self, keys):
        """keys[w][(c,j)] for j=1,2 (regular steps).  Builds per-world bitmasks with bit
        position = key rank (lowest key = lowest bit)."""
        self.keys = keys
        self.bitpos = []
        for w in range(3):
            steps = sorted(((c, j) for c in range(self.N) for j in (1, 2)), key=lambda s: keys[w][s])
            vals = [keys[w][s] for s in steps]
            assert len(set(vals)) == len(vals) or True
            self.bitpos.append({s: b for b, s in enumerate(steps)})
        self.UM = []
        for w in range(3):
            U = np.zeros(self.M, dtype=np.int64)
            for c in range(self.N):
                r = self.RK[w][:, c]
                for j in (1, 2):
                    U |= np.where(r >= j, np.int64(1) << np.int64(self.bitpos[w][(c, j)]), 0)
            self.UM.append(U)

    def gates_from(self, C):
        """for base C (advice tuple, regular), arrays over all rivals X:
        pass_w (C <=_w X under gate-only rule) for w=0,1,2; also on/off masses"""
        k = self.index[tuple(C)]
        out = []
        for w in range(3):
            UC = self.UM[w][k]; UX = self.UM[w]
            on = UX & ~UC; off = UC & ~UX
            lo_on = on & -on; lo_off = off & -off
            guid = (off == 0)
            gate = (on != 0) & (off != 0) & (lo_on < lo_off)
            out.append((guid, gate))
        return out

    def gates_into(self, C):
        """arrays over X: X <=_w C (gate part / guidance part)"""
        k = self.index[tuple(C)]
        out = []
        for w in range(3):
            UC = self.UM[w][k]; UX = self.UM[w]
            on = UC & ~UX; off = UX & ~UC   # steps C adds relative to X
            lo_on = on & -on; lo_off = off & -off
            guid = (off == 0)
            gate = (on != 0) & (off != 0) & (lo_on < lo_off)
            out.append((guid, gate))
        return out

    def onoff_mass(self, C, w):
        k = self.index[tuple(C)]
        rc = self.RK[w][k][None, :]; rx = self.RK[w]
        on = (np.maximum(rx - rc, 0) * self.mass_f[None, :]).sum(1)
        off = (np.maximum(rc - rx, 0) * self.mass_f[None, :]).sum(1)
        return on, off

def box_vertices(l, u):
    """vertices of {x in simplex: l_i <= x_i <= u_i} (exact)"""
    V = set()
    for i in range(3):
        for j in range(3):
            if i == j: continue
            k = 3 - i - j
            for a in (l[i], u[i]):
                for b in (l[j], u[j]):
                    x = [None]*3; x[i] = a; x[j] = b; x[k] = 1 - a - b
                    if all(l[m] <= x[m] <= u[m] for m in range(3)):
                        V.add(tuple(x))
    return sorted(V)

def fam_mult(beta):
    """K_p = {x in simplex: |x_i - p_i| <= beta p_i}: imprecise on edges (edge intervals),
    precise only at the vertices; a hexagon at the centre for beta < 1/2"""
    def K(p):
        l = [max(F(0), (1-beta)*x) for x in p]; u = [min(F(1), (1+beta)*x) for x in p]
        return box_vertices(l, u)
    return K
