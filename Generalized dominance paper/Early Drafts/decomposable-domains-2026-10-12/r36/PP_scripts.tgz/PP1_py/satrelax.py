"""SAT key search with the closure-relaxed KKM condition (finite analogue of closed sections):
for every regular rival X there is a point p of the simplex such that, for every world w, some
selected model occurring arbitrarily near p (here: at p or a neighbouring grid point) passes
C <=_w X.  Competitiveness is required exactly (every selected model, its support, every
regular rival)."""
import itertools, random
from pysat.formula import IDPool
from pysat.solvers import Solver
from core import *

def grid_models(Kfun, G, D):
    pts = {}
    for a in range(D+1):
        for b in range(D+1-a):
            p = (F(a, D), F(b, D), F(D-a-b, D))
            pts[(a, b)] = coherent(Kfun(p), G)
    return pts

def neighbourhoods(pts, D):
    nb = set()
    for (a, b), X in pts.items():
        S = {X}
        for da, db in ((1,0),(-1,0),(0,1),(0,-1),(1,-1),(-1,1)):
            q = (a+da, b+db)
            if q in pts: S.add(pts[q])
        nb.add(frozenset(S))
    # drop neighbourhoods contained in others
    nb = sorted(nb, key=len, reverse=True)
    keep = []
    for S in nb:
        if not any(S <= T for T in keep): keep.append(S)
    return keep

def build(cells, sel, nbs, phi='none', relaxed=True, comp=True):
    N = cells.N
    steps = [(c, j) for c in range(N) for j in (1, 2)]
    sid = {s: k for k, s in enumerate(steps)}
    S = len(steps)
    pool = IDPool(); cl = []
    def X(w, a, b):
        if a < b: return pool.id(('x', w, a, b))
        return -pool.id(('x', w, b, a))
    for w in range(3):
        for a, b, c in itertools.permutations(range(S), 3):
            cl.append([-X(w, a, b), -X(w, b, c), X(w, a, c)])
    Hs = set(); Gs = set()
    def H(w, a, off):
        key = ('h', w, a, off); v = pool.id(key)
        if key not in Hs:
            Hs.add(key)
            for b in off: cl.append([-v, X(w, a, b)])
        return v
    def Gv(w, on, off):
        key = ('g', w, on, off); v = pool.id(key)
        if key not in Gs:
            Gs.add(key); cl.append([-v] + [H(w, a, off) for a in on])
        return v
    R = cells.R
    models = [tuple(int(a) for a in row) for row in cells.models]
    cache = {}
    def lit(Cm, Xm, w):
        k = (Cm, Xm, w)
        if k in cache: return cache[k]
        on = []; off = []; mon = moff = 0
        for c in range(N):
            rc, rx = R[w][c][Cm[c]], R[w][c][Xm[c]]
            if rx > rc: on += [sid[(c, j)] for j in range(rc+1, rx+1)]; mon += cells.mass[c]*(rx-rc)
            elif rc > rx: off += [sid[(c, j)] for j in range(rx+1, rc+1)]; moff += cells.mass[c]*(rc-rx)
        if not off: r = True
        elif not on: r = False
        elif phi == 'sticky' and 2*mon - moff < 0: r = False
        else: r = Gv(w, tuple(on), tuple(off))
        cache[k] = r
        return r
    triv = []
    if comp:
        for Cm in sel:
            for Xm in models:
                if Xm == Cm: continue
                L = [lit(Cm, Xm, w) for w in range(3)]
                for s in sel[Cm][0]:
                    if any(L[w] is True for w in s): continue
                    clause = [L[w] for w in s if L[w] is not False]
                    if not clause: triv.append(('comp', Cm, s, Xm)); continue
                    cl.append(clause)
    selset = set(sel)
    allC = set().union(*nbs)
    for Xm in models:
        if Xm in selset: continue
        L = {(Cm, w): lit(Cm, Xm, w) for Cm in allC for w in range(3)}
        opts = []
        done = False
        for nb in (nbs if relaxed else [frozenset([Cm]) for Cm in allC]):
            per_w = []
            ok = True
            for w in range(3):
                ls = [L[(Cm, w)] for Cm in nb]
                if True in ls: per_w.append(True); continue
                ls = [l for l in ls if l is not False]
                if not ls: ok = False; break
                per_w.append(ls)
            if not ok: continue
            if all(pw is True for pw in per_w): done = True; break
            v = pool.id(('K', nb, Xm)); opts.append(v)
            for w, pw in enumerate(per_w):
                if pw is True: continue
                if len(pw) == 1: cl.append([-v, pw[0]])
                else:
                    t = pool.id(('T', nb, w, Xm)); cl.append([-v, t]); cl.append([-t] + pw)
        if done: continue
        if not opts: triv.append(('kkm', Xm)); continue
        cl.append(opts)
    return dict(pool=pool, clauses=cl, steps=steps, X=X, triv=triv)

def solve(B, name='cadical153'):
    if B['triv']: return None, None
    with Solver(name=name, bootstrap_with=B['clauses']) as s:
        if not s.solve(): return False, None
        m = set(l for l in s.get_model() if l > 0)
    steps = B['steps']; Xf = B['X']
    orders = []
    for w in range(3):
        idx = range(len(steps))
        def lt(a, b):
            l = Xf(w, a, b)
            return (l in m) if l > 0 else (-l not in m)
        cnt = {a: sum(1 for b in idx if b != a and lt(a, b)) for a in idx}
        orders.append([steps[a] for a in sorted(idx, key=lambda a: -cnt[a])])
    return True, orders
