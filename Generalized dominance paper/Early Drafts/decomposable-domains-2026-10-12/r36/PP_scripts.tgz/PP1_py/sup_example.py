"""Explicit competitiveness failure of the sup-present keys near the target (homothetic family,
lines through points near the centre; seed 1 of sup_central.py)."""
from core import *
from supkeys import sup_present_keys
from sup_central import central_lines, T
AD = 'PSMC'
G = central_lines(7, 1)
keys = sup_present_keys(G, T); R = rank_table(G)
C = [AD.index(a) for a in 'SPSPSMS']; X = [AD.index(a) for a in 'PPMPPMM']
p = (F(184416891800357, 467578956975000), F(22446294958353, 77929826162500), F(3331111507, 10489713000))
assert tuple(C) == coherent(fam_hom(T)(p), G)
print('index p =', [round(float(x), 4) for x in p], ' K_p vertices', [[round(float(x), 4) for x in v] for v in fam_hom(T)(p)])
for k, g in enumerate(G):
    if C[k] != X[k]:
        print('line', k, ''.join('+' if a > 0 else '-' for a in g), [str(a) for a in g], 'C:', AD[C[k]], '-> X:', AD[X[k]],
              ' keys (w,j):', {(w+1, j): round(float(keys[w][(k, j)][0]), 4) for w in range(3) for j in (1, 2)})
for w in range(3):
    on = [(k, j) for k in range(7) for j in (1, 2) if R[w][k][C[k]] < j <= R[w][k][X[k]]]
    off = [(k, j) for k in range(7) for j in (1, 2) if R[w][k][X[k]] < j <= R[w][k][C[k]]]
    mn = lambda S: min((keys[w][s][0] for s in S), default=None)
    print('world', w+1, ': X adds', on, 'lowest key', mn(on) is not None and round(float(mn(on)), 4),
          '; X removes', off, 'lowest key', mn(off) is not None and round(float(mn(off)), 4), '; p_w =', round(float(p[w]), 4))
