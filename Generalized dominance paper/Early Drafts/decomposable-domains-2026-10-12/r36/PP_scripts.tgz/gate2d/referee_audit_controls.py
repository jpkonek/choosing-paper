# Controls: the checker in referee_audit_ext.py must detect deliberate failures.
import referee_audit_ext as R
from fractions import Fraction as F
orig_phi, orig_gate = R.phi, R.gate
# (1) a verdict violating (V3): strict at both worlds
def bad_phi(ctx, kind, w, on, off):
    st, ms = ctx['steps'], ctx['mass']
    return sum(ms[st[b][0]] for b in R.bits(on)) - 3*sum(ms[st[b][0]] for b in R.bits(off))
R.phi = bad_phi
print('V3-violating verdict:', R.run(3, 1, 7, 'coord', True))
R.phi = orig_phi
# (2) no gate at all, sticky verdict: expect cyclic worlds
R.gate = lambda ctx, w, on, off, weak: bool(on)
print('ungated sticky:', R.run(3, 1, 7, 'sticky', False))
# (3) reversed weak gate (min on > min off): expect failures of Lemma 3 / competitiveness
R.gate = lambda ctx, w, on, off, weak: bool(on) and (not off or min(ctx['kr'][(w, ctx['steps'][b])] for b in R.bits(on)) > min(ctx['kr'][(w, ctx['steps'][b])] for b in R.bits(off)))
print('reversed weak gate:', R.run(3, 1, 7, 'coord', True))
R.gate = orig_gate
