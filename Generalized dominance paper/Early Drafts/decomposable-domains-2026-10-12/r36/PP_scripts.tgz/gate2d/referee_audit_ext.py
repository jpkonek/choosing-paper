# Independent referee check of Section "Two extensions found by audit".
# Written from the note's definitions; does not import check.py or weakgate.py.
# Exact integer arithmetic: masses are integers, verdicts are scaled by 2 so that
# alpha in {2, 1/2, 1} becomes {4, 1, 2}.  Keys are exact Fractions, replaced by
# their integer rank in the key order (ties are detected and reported).
import itertools, random, sys
from fractions import Fraction as F
from collections import Counter

# ---------- the note's family through K* = [1/3, 2/3] ----------
def l(p): return F(2,3)*p if p <= F(1,2) else F(1,3) + F(4,3)*(p-F(1,2))
def u(p): return F(4,3)*p if p <= F(1,2) else F(2,3) + F(2,3)*(p-F(1,2))
def linv(t): return F(3,2)*t if t <= F(1,3) else F(1,2) + F(3,4)*(t-F(1,3))
def uinv(t): return F(3,4)*t if t <= F(2,3) else F(1,2) + F(3,2)*(t-F(2,3))

ADV = 'PSMC'   # accept g, silent, accept -g, contradiction
def rank(cell_mixed, a, w):
    if not cell_mixed: return {'P':0,'S':1,'M':2,'C':3}[a]   # P = correct on unanimous
    if w == 1: return {'P':0,'S':1,'M':2,'C':3}[a]
    return {'P':2,'S':1,'M':0,'C':3}[a]

def setup(N, U, seed, tsel=None):
    rnd = random.Random(seed)
    if tsel is None:
        ts = sorted(set(F(rnd.randint(1, 999), 1000) for _ in range(N)))
        while len(ts) < N:
            ts = sorted(set(ts + [F(rnd.randint(1, 999), 1000)]))
    else:
        ts = sorted(tsel)
    N = len(ts)
    mass = [rnd.randint(1, 9) for _ in range(N + U)]
    cells = list(range(N + U))
    steps = [(c, j) for c in cells for j in (1, 2, 3)]
    sidx = {s: n for n, s in enumerate(steps)}
    # keys
    tau = {c: F(c + 1, N + U + 2) for c in cells}
    K = {}
    for w in (1, 2):
        for (c, j) in steps:
            if c < N and j in (1, 2):
                t = ts[c]
                if w == 1: k = linv(t) if j == 1 else uinv(t)
                else:      k = 1 - uinv(t) if j == 1 else 1 - linv(t)
            else:
                k = -1 - F(3*c + j, 3*(N + U) + 5)
            K[(w, (c, j))] = k
    keyrank = {}
    ties = 0
    for w in (1, 2):
        vals = sorted(K[(w, s)] for s in steps)
        ties += len(vals) - len(set(vals))
        order = {v: n for n, v in enumerate(sorted(set(vals)))}
        for s in steps: keyrank[(w, s)] = order[K[(w, s)]]
    # alpha (x2): 4 for t<1/2, 1 for t>1/2, 2 on unanimous
    al2 = [ (4 if ts[c] < F(1,2) else 1) if c < N else 2 for c in cells ]
    return dict(N=N, U=U, ts=ts, mass=mass, cells=cells, steps=steps, sidx=sidx,
                kr=keyrank, al2=al2, ties=ties)

def stepmask(ctx, X, w):
    N = ctx['N']; m = 0
    for c, a in enumerate(X):
        r = rank(c < N, a, w)
        for j in range(1, r + 1): m |= 1 << ctx['sidx'][(c, j)]
    return m

def bits(m):
    while m:
        b = m & -m; yield b.bit_length() - 1; m ^= b

# verdicts, all scaled by 2
def phi(ctx, kind, w, on, off):
    st = ctx['steps']; ms = ctx['mass']; al = ctx['al2']
    if kind == 'sticky':   # 2 on - off
        return 2*(2*sum(ms[st[b][0]] for b in bits(on)) - sum(ms[st[b][0]] for b in bits(off)))
    if kind == 'additive':
        return 2*(sum(ms[st[b][0]] for b in bits(on)) - sum(ms[st[b][0]] for b in bits(off)))
    if kind == 'coord':
        if w == 1:
            return sum(al[st[b][0]]*ms[st[b][0]] for b in bits(on)) - 2*sum(ms[st[b][0]] for b in bits(off))
        return 2*sum(ms[st[b][0]] for b in bits(on)) - sum(al[st[b][0]]*ms[st[b][0]] for b in bits(off))
    raise ValueError

def gate(ctx, w, on, off, weak):
    kr = ctx['kr']; st = ctx['steps']
    if not on: return False
    if not off: return True
    kon = [kr[(w, st[b])] for b in bits(on)]
    koff = [kr[(w, st[b])] for b in bits(off)]
    return (min(kon) < min(koff)) if weak else (max(kon) <= min(koff))

def make_acc(ctx, models, kind, weak):
    M = {w: [stepmask(ctx, X, w) for X in models] for w in (1, 2)}
    def acc(a, b, w):
        if a == b: return True
        UX, UY = M[w][a], M[w][b]
        on, off = UY & ~UX, UX & ~UY
        if not off: return True
        if not gate(ctx, w, on, off, weak): return False
        return phi(ctx, kind, w, on, off) >= 0
    return acc, M

def selected(ctx, p):
    X = []
    for c in range(ctx['N']):
        t = ctx['ts'][c]
        X.append('P' if t < l(p) else ('M' if t > u(p) else 'S'))
    return tuple(X + ['P'] * ctx['U'])

def critical(ctx):
    pts = {F(0), F(1)} | {F(k, 64) for k in range(65)}
    for t in ctx['ts']:
        pts |= {linv(t), uinv(t)}
    pts = sorted(p for p in pts if 0 <= p <= 1)
    mids = [(a + b) / 2 for a, b in zip(pts, pts[1:])]
    return sorted(set(pts) | set(mids))

def acyclic(n, succ):
    indeg = [0]*n
    for a in range(n):
        for b in succ[a]: indeg[b] += 1
    q = [a for a in range(n) if indeg[a] == 0]; seen = 0
    while q:
        a = q.pop(); seen += 1
        for b in succ[a]:
            indeg[b] -= 1
            if indeg[b] == 0: q.append(b)
    return seen == n

def run(N, U, seed, kind, weak, tsel=None):
    ctx = setup(N, U, seed, tsel)
    models = list(itertools.product(ADV, repeat=ctx['N'] + ctx['U']))
    idx = {X: n for n, X in enumerate(models)}
    acc, M = make_acc(ctx, models, kind, weak)
    n = len(models)
    out = Counter(ties=ctx['ties'])
    # full relation, acyclicity, strict (G), weak-contains-strong
    for w in (1, 2):
        succ = [[] for _ in range(n)]
        for a in range(n):
            for b in range(n):
                if a != b and acc(a, b, w): succ[a].append(b)
        if not acyclic(n, succ): out['cyclic_world'] += 1
        for a in range(n):
            for b in range(n):
                if a == b: continue
                Ua, Ub = M[w][a], M[w][b]
                if Ub & ~Ua == 0 and Ua != Ub:      # b strict pointwise improvement of a
                    if not acc(b, a, w) or acc(a, b, w): out['strictG_fail'] += 1
    # selected-model tests
    for p in critical(ctx):
        C = idx[selected(ctx, p)]
        for x in range(n):
            a1, a2 = acc(C, x, 1), acc(C, x, 2)
            ok = a1 if p == 1 else (a2 if p == 0 else (a1 or a2))
            if not ok: out['comp_fail'] += 1
            if x != C and acc(x, C, 1) and acc(x, C, 2): out['dominated_selected'] += 1
            ph = {}
            for w in (1, 2):
                UX, UY = M[w][C], M[w][x]
                on, off = UY & ~UX, UX & ~UY
                ph[w] = phi(ctx, kind, w, on, off)
                # section identity
                if (acc(C, x, w)) != (ph[w] >= 0): out['section_identity_fail'] += 1
                # (V2)
                if (not on) and off and ph[w] >= 0: out['V2_fail'] += 1
                if (not off) and ph[w] < 0: out['V2_fail'] += 1
                # Lemma 3 for the gate in use
                if on and not gate(ctx, w, on, off, weak): out['lemma3_fail'] += 1
            if 0 < p < 1 and ph[1] < 0 and ph[2] < 0: out['V3_fail'] += 1
            if kind == 'coord':
                # Phi1 + Phi2 equals (scaled) contributions of contradiction/unanimous changes,
                # and is zero for purely regular mixed changes
                Cm = models[C]; Xm = models[x]
                regular_only = all((c < ctx['N'] and Xm[c] != 'C') or Xm[c] == Cm[c]
                                   for c in range(len(Cm)))
                if regular_only and ph[1] + ph[2] != 0: out['coord_antisym_fail'] += 1
                if ph[1] + ph[2] < 0: out['coord_sum_neg'] += 1
    # weak gate contains strong gate (as relations), for this verdict
    if weak:
        accS, _ = make_acc(ctx, models, kind, False)
        for w in (1, 2):
            for a in range(0, n, max(1, n // 300)):
                for b in range(n):
                    if accS(a, b, w) and not acc(a, b, w): out['weak_not_superset'] += 1
    return dict(out)

def indispensable(N, U, seed, tsel=None):
    """Rivals out of the target C_{1/2}: count those defended at exactly one world under the
    coordinated verdict, whose additive evaluator at that world refuses; and check whether the
    other world's uniform additive evaluator defends them."""
    ctx = setup(N, U, seed, tsel)
    models = list(itertools.product(ADV, repeat=ctx['N'] + ctx['U']))
    idx = {X: n for n, X in enumerate(models)}
    acc, M = make_acc(ctx, models, 'coord', False)
    C = idx[selected(ctx, F(1, 2))]
    res = Counter()
    for x in range(len(models)):
        if x == C: continue
        a = {w: acc(C, x, w) for w in (1, 2)}
        add = {}
        for w in (1, 2):
            UX, UY = M[w][C], M[w][x]
            add[w] = phi(ctx, 'additive', w, UY & ~UX, UX & ~UY) >= 0
        for w, v in ((1, 2), (2, 1)):
            if a[w] and not a[v] and not add[w]:
                res[f'indisp_w{w}'] += 1
                if add[v]: res[f'indisp_w{w}_other_world_additive_defends'] += 1
    return dict(res)

if __name__ == '__main__':
    layouts = [(3,1),(4,0),(2,2),(1,3),(3,2)]
    seeds = range(5)
    for kind in ('coord', 'sticky'):
        for weak in (False, True):
            tot = Counter(); ncfg = 0
            for (N, U) in layouts:
                for s in seeds:
                    r = run(N, U, 100*s + 7*N + U, kind, weak); tot.update(r); ncfg += 1
            print(kind, 'weak' if weak else 'strong', ncfg, 'configs:', dict(tot), flush=True)
    # layouts with cells straddling the boundaries 1/3, 2/3 and t = 1/2
    for tsel in ([F(30,100), F(36,100), F(64,100)], [F(32,100), F(34,100), F(49,100), F(51,100)],
                 [F(65,100), F(67,100), F(70,100)]):
        for weak in (False, True):
            print('coord', 'weak' if weak else 'strong', [str(t) for t in tsel],
                  run(len(tsel), 1, 3, 'coord', weak, tsel), flush=True)
        print('indispensable', [str(t) for t in tsel], indispensable(len(tsel), 1, 3, tsel), flush=True)
    for (N, U) in layouts:
        for s in seeds:
            print('indispensable', N, U, s, indispensable(N, U, 100*s + 7*N + U), flush=True)
