# For ONE fixed selected model (the target C_{1/2}), the field f = 1 on U_1(C), f = alpha on the
# complement (world 1), and f = alpha on U_2(C), f = 1 on the complement (world 2), is strictly
# positive and endorses every accepted comparison out of C under the coordinated verdict.
# Also: the Lebesgue-type record with mass ratio 2 has Phi_1 = Phi_2 = 0 (both worlds accept),
# while ratio 3/2 gives Phi_1 > 0 > Phi_2.
import itertools
from fractions import Fraction as F
import referee_audit_ext as R
tot = 0; bad = 0
for (N, U) in [(3,1),(4,0),(2,2),(3,2)]:
    for s in range(5):
        ctx = R.setup(N, U, 100*s + 7*N + U)
        models = list(itertools.product(R.ADV, repeat=ctx['N'] + ctx['U']))
        for tsel in [None]:
            for p in [F(1,2)] + [F(k,16) for k in range(1,16)]:
                C = R.selected(ctx, p)
                acc, M = R.make_acc(ctx, models + [C], 'coord', False)
                ci = len(models)
                st, ms, al = ctx['steps'], ctx['mass'], ctx['al2']
                for x in range(len(models)):
                    for w in (1, 2):
                        if not acc(ci, x, w): continue
                        UC, UX = M[w][ci], M[w][x]
                        on, off = UX & ~UC, UC & ~UX
                        # f scaled by 2: world1: 2 on U1(C), al2 off it; world2: al2 on U2(C), 2 off it
                        def f(b):
                            inC = (UC >> b) & 1
                            if w == 1: return 2 if inC else al[st[b][0]]
                            return al[st[b][0]] if inC else 2
                        lhs = sum(f(b)*ms[st[b][0]] for b in R.bits(off))
                        rhs = sum(f(b)*ms[st[b][0]] for b in R.bits(on))
                        tot += 1; bad += lhs > rhs
print('accepted comparisons out of a fixed C_p checked:', tot, 'endorsement failures:', bad)
m = F(1)
for r in (F(2), F(3,2)):
    phi1 = 2*m - r*m           # world 1 near t0=l(p)<1/2: adds (g,1) below (alpha=2), removes r*m above
    phi2 = -phi1               # regular change: exact antisymmetry
    print('ratio', r, 'Phi1 =', phi1, 'Phi2 =', phi2)
