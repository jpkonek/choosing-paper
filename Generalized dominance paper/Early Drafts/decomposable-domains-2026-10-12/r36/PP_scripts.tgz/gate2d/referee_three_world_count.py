# Three-world count: sum_i off_i <= 2 sum_i on_i for changes out of regular advice.
import itertools, random
from fractions import Fraction as F
def r(sign, a):  # world rank of advice a on a problem whose world-i gain has this sign
    return {'P': 0 if sign > 0 else 2, 'S': 1, 'M': 2 if sign > 0 else 0, 'C': 3}[a]
def onoff(sg, A, B):
    on = sum(max(0, r(s, B) - r(s, A)) for s in sg)
    off = sum(max(0, r(s, A) - r(s, B)) for s in sg)
    return on, off
worst = {}
viol = []
for sg in itertools.product((1, -1), repeat=3):
    unan = len(set(sg)) == 1
    correct = 'P' if sg[0] > 0 else 'M'
    for A in 'PSM':
        for B in 'PSMC':
            if A == B: continue
            on, off = onoff(sg, A, B)
            tag = ('unanimous, A correct' if A == correct else 'unanimous, A NOT correct') if unan else 'mixed'
            if off > 2*on: viol.append((sg, A, B, on, off, tag))
            val = F(off, on) if on else (F(10**9) if off else F(0))
            worst[tag] = max(worst.get(tag, F(0)), val)
print('max off/on per class:', {k: str(v) for k, v in worst.items()})
print('violations of off <= 2 on:')
for v in viol: print('  ', v)
# tight cases on mixed problems
print('tight mixed cases:', [(sg, A, B) for sg in itertools.product((1,-1), repeat=3) if len(set(sg)) > 1
       for A in 'PSM' for B in 'PSMC' if A != B and onoff(sg, A, B)[1] == 2*onoff(sg, A, B)[0]])
# random multi-problem check out of coherent models D_K (K = hull of random points in the simplex)
rnd = random.Random(1)
bad = 0; trials = 0; minsum = None
for trial in range(3000):
    verts = []
    for _ in range(rnd.randint(1, 4)):
        x = [rnd.random() for _ in range(3)]; s = sum(x); verts.append([v/s for v in x])
    probs = [[rnd.gauss(0, 1) for _ in range(3)] for _ in range(rnd.randint(1, 6))]
    w = [rnd.randint(1, 9) for _ in probs]
    def coh(g):
        vals = [sum(m[i]*g[i] for i in range(3)) for m in verts]
        return 'P' if min(vals) > 0 else ('M' if max(vals) < 0 else 'S')
    A = [coh(g) for g in probs]
    B = [rnd.choice('PSMC') for _ in probs]
    on = [0]*3; off = [0]*3
    for g, a, b, wt in zip(probs, A, B, w):
        for i in range(3):
            s = 1 if g[i] > 0 else -1
            d = r(s, b) - r(s, a)
            if d > 0: on[i] += wt*d
            else: off[i] += -wt*d
    trials += 1
    if sum(off) > 2*sum(on): bad += 1
    phis = [2*on[i] - off[i] for i in range(3)]
    if max(phis) < 0: bad += 1
print('random coherent multi-problem trials:', trials, 'failures:', bad)
