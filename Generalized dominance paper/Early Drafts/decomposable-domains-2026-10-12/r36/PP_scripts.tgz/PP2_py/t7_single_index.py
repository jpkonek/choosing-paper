# CHECKED (exact finite cells): single-index statements of Section 3.
# (a) C threshold at two worlds  =>  C defensible (every regular X fails to beat C at some world).
# (b) Prop 4: C owns a bottom segment at all three worlds  =>  C not defensible.
# (c) C threshold at world 1: defensible  <=>  no (2,3)-crossing among A-ward changes on M_3, M_2.
import itertools, random
from lexcore import steps, gate

def defensible(C, models, w, K):
    return all(any(gate(C, X, w, K, i) for i in range(3)) for X in models if X != C)

def threshold_keys(C, w, N, i, rnd):
    """Random keys at world i making U_i(C) an up-set (C's steps above all steps it lacks)."""
    U = steps(C, w, i)
    return {(c, j): (1 + rnd.random()) if (c, j) in U else rnd.random() for c in range(N) for j in (1, 2)}

def owns_bottom(C, w, K, N, i):
    U = steps(C, w, i)
    allst = [(c, j) for c in range(N) for j in (1, 2)]
    lowest = min(allst, key=lambda s: K[i][s])
    return lowest in U

def crossing_23(C, w, K, N):
    # A-ward changes (toward the majority-good advice 0) on class 2 (M_3) and class 1 (M_2)
    def changes(cls):
        out = []
        for c in range(N):
            if w[c] != cls: continue
            for b in range(C[c]):            # b < C[c]: toward A
                X = list(C); X[c] = b; X = tuple(X)
                ch = {}
                for i in range(3):
                    UC, UX = steps(C, w, i), steps(X, w, i)
                    off, on = UC - UX, UX - UC
                    ch[i] = ('gain', min(K[i][s] for s in off)) if off else ('loss', min(K[i][s] for s in on))
                out.append(ch)
        return out
    P, Q = changes(2), changes(1)
    for p in P:
        for q in Q:
            # p: gains at worlds 0,1 (1,2), loses at 2 (3); q: gains at worlds 0,2, loses at 1
            if p[1][1] < q[1][1] and q[2][1] < p[2][1]:
                return True
    return False

def main(N=6, trials=300):
    rnd = random.Random(7)
    w = [c % 3 for c in range(N)]
    models = list(itertools.product((0, 1, 2), repeat=N))
    a_fail = b_fail = c_mismatch = c_tests = b_tests = 0
    for t in range(trials):
        C = models[rnd.randrange(len(models))]
        # (a)
        K = [threshold_keys(C, w, N, 0, rnd), threshold_keys(C, w, N, 1, rnd),
             {(c, j): rnd.random() for c in range(N) for j in (1, 2)}]
        if not defensible(C, models, w, K): a_fail += 1
        # (b)
        K = [{(c, j): rnd.random() for c in range(N) for j in (1, 2)} for _ in range(3)]
        if all(owns_bottom(C, w, K, N, i) for i in range(3)):
            b_tests += 1
            if defensible(C, models, w, K): b_fail += 1
        # (c)
        K = [threshold_keys(C, w, N, 0, rnd)] + [{(c, j): rnd.random() for c in range(N) for j in (1, 2)} for _ in range(2)]
        c_tests += 1
        if defensible(C, models, w, K) == crossing_23(C, w, K, N): c_mismatch += 1
    print(dict(N=N, trials=trials, a_two_threshold_not_defensible=a_fail,
               b_tests=b_tests, b_owns_bottom_but_defensible=b_fail,
               c_tests=c_tests, c_criterion_mismatch=c_mismatch))

if __name__ == '__main__':
    main()
