# CHECKED (exact finite cells, LP for coherence): the mechanism of Theorem 3.
# Lines: class M_1 (minority world index 0) contains a crossed pair L, L' (z12(L) < z12(L'),
# z13(L) > z13(L')); class M_3 (index 2) has a line hugging edge [e1,e2]; class M_2 (index 1)
# has a line hugging edge [e1,e3].  For random world-1 keys k_1 we build, for every threshold c,
#   X_c  = A on M_3, world-1 steps on M_1 u M_2 = largest down-closed part of {k_1 >= c},
#   X'_c = A on M_2, world-1 steps on M_1 u M_3 = largest down-closed part of {k_1 >= c},
# and verify (1) no regular C != X_c has C ->_1 X_c and C ->_2 X_c (exhaustive), likewise X'_c with
# worlds 1,3; (2) some X_c or X'_c is incoherent (so it cannot be selected).
import itertools, random, sys
import numpy as np
from geom import coherent
from lexcore import gate, steps

def line_through(P, Q, wc):
    g = np.cross(P, Q)
    if g[wc] > 0: g = -g
    o = [x for x in range(3) if x != wc]
    assert g[wc] < 0 and all(g[x] > 0 for x in o)
    return g / np.linalg.norm(g)

def pt(i, j, z):  # point on edge [e_i, e_j] at distance-parameter z from e_i
    P = np.zeros(3); P[i] = 1 - z; P[j] = z; return P

def arrangement(extra=0, seed=0):
    rnd = random.Random(seed)
    G, w = [], []
    # M_1 crossed pair: (z12, z13) = (0.3, 0.7) and (0.6, 0.35)
    for z12, z13 in [(0.3, 0.7), (0.6, 0.35)]:
        G.append(line_through(pt(0, 1, z12), pt(0, 2, z13), 0)); w.append(0)
    # M_3 line hugging edge [e1,e2]: cuts edges [e3,e1] and [e3,e2] very near e1, e2
    G.append(line_through(pt(2, 0, 0.97), pt(2, 1, 0.97), 2)); w.append(2)
    # M_2 line hugging edge [e1,e3]
    G.append(line_through(pt(1, 0, 0.97), pt(1, 2, 0.97), 1)); w.append(1)
    for _ in range(extra):
        wc = rnd.randrange(3); o = [x for x in range(3) if x != wc]
        G.append(line_through(pt(wc, o[0], rnd.uniform(.1, .9)), pt(wc, o[1], rnd.uniform(.1, .9)), wc)); w.append(wc)
    return np.array(G), w

def threshold_model(N, w, K1, c, cls_pair, cls_A):
    """World-1 rank r on classes cls_pair = largest down-closed part of {k_1 >= c}; A on cls_A."""
    X = []
    for cc in range(N):
        if w[cc] == cls_A: X.append(0); continue
        r = 0
        if K1[(cc, 1)] >= c:
            r = 1
            if K1[(cc, 2)] >= c: r = 2
        # world-1 rank r -> advice: if world 1 (index 0) is the minority at cc, a = 2 - r, else a = r
        X.append(2 - r if w[cc] == 0 else r)
    return tuple(X)

def main(trials=200, extra=2):
    G, w = arrangement(extra)
    N = len(G)
    models = list(itertools.product((0, 1, 2), repeat=N))
    rnd = random.Random(1)
    stats = dict(trials=0, pareto_fail=0, all_coherent=0)
    coh_cache = {}
    def coh(X):
        if X not in coh_cache: coh_cache[X] = coherent(X, G)
        return coh_cache[X]
    for t in range(trials):
        K = [{(c, j): rnd.random() for c in range(N) for j in (1, 2)} for _ in range(3)]
        cuts = sorted({K[0][s] for s in K[0]}) + [2.0]
        found_incoh = False
        for c in cuts:
            for (pair, Acls, other) in [((0, 1), 2, 1), ((0, 2), 1, 2)]:
                X = threshold_model(N, w, K[0], c, pair, Acls)
                # (1) Pareto for worlds {1, other}
                for C in models:
                    if C != X and gate(C, X, w, K, 0) and gate(C, X, w, K, other):
                        stats['pareto_fail'] += 1; break
                if not coh(X): found_incoh = True
        stats['trials'] += 1
        if not found_incoh: stats['all_coherent'] += 1
    print(dict(N=N, classes=w, **stats))

if __name__ == '__main__':
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 100, int(sys.argv[2]) if len(sys.argv) > 2 else 2)
