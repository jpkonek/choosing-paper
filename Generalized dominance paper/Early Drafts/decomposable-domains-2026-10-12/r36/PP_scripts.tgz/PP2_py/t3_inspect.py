# Inspect a minimal-Pareto key configuration: list Pareto models and their world-rank vectors.
import sys
from t2_minpareto import *
N = int(sys.argv[1]); iters = int(sys.argv[2]); seed = int(sys.argv[3])
w = [c % 3 for c in range(N)]
(b, perms), models, S = anneal(N, w, iters, seed)
V = codes(S, perms, N)
P = pareto_size(V, True)
print("min pareto", b, "classes", w)
for i in range(3):
    print("world", i, "order (cell,level):", [(col // 2, col % 2 + 1) for col in perms[i]])
A = 'ASB'
for m in sorted(P, key=lambda m: tuple(models[m])):
    X = models[m]
    print(''.join(A[a] for a in X), ' steps per world:', [int(S[i][m].sum()) for i in range(3)])
