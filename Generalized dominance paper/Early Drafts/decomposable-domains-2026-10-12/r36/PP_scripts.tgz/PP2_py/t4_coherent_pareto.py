# NUMERICS: on finite line cells, search key orders so that (a) a target interior imprecise model
# D_{K*} is lex-Pareto and (b) every lex-Pareto regular model is coherent.  Reports the best
# objective found.  Exact Pareto computation; coherence by LP.
import sys, random, math, pickle, os
import numpy as np
from geom import *
from t2_minpareto import setup, codes, pareto_size

def run(per_class, seed, iters, eps=0.3, pstar=(1/3, 1/3, 1/3)):
    G, w = make_lines(per_class, seed)
    N = len(G)
    models, S = setup(N, w)
    cache = f"coh_{per_class}_{seed}.pkl"
    if os.path.exists(cache):
        coh = pickle.load(open(cache, 'rb'))
    else:
        coh = np.array([coherent(tuple(int(x) for x in m), G) for m in models])
        pickle.dump(coh, open(cache, 'wb'))
    target = advice_of_K(G, contamination(pstar, eps))
    tidx = int(sum(a * 3 ** (N - 1 - c) for c, a in enumerate(target)))
    assert tuple(models[tidx]) == target
    rnd = random.Random(seed)
    def obj(perms):
        P = pareto_size(codes(S, perms, N), True)
        Ps = set(P)
        return int((~coh[P]).sum()) + (25 if tidx not in Ps else 0), P
    perms = [rnd.sample(range(2 * N), 2 * N) for _ in range(3)]
    cur, _ = obj(perms); best = (cur, [p[:] for p in perms])
    for t in range(iters):
        T = 2.0 * (1 - t / iters) + 1e-3
        i = rnd.randrange(3); a = rnd.randrange(2 * N); b = rnd.randrange(2 * N)
        perms[i][a], perms[i][b] = perms[i][b], perms[i][a]
        new, _ = obj(perms)
        if new <= cur or rnd.random() < math.exp((cur - new) / T):
            cur = new
            if cur < best[0]: best = (cur, [p[:] for p in perms])
        else:
            perms[i][a], perms[i][b] = perms[i][b], perms[i][a]
        if best[0] == 0: break
    val, P = obj(best[1])
    return dict(N=N, seed=seed, target=''.join('ASB'[a] for a in target), coherent_models=int(coh.sum()),
                best=val, pareto=len(P), incoherent_pareto=int((~coh[P]).sum()), target_in=(tidx in set(P))), best[1], models, coh, P

if __name__ == '__main__':
    pc = int(sys.argv[1]); iters = int(sys.argv[2])
    for seed in range(int(sys.argv[3])):
        res, perms, models, coh, P = run(pc, seed, iters)
        print(res)
