# Core finite model for the weak gate in three worlds (regular models only).
# Cells c = 0..N-1 are mixed problems; cell c has minority world w[c] in {0,1,2}.
# Regular advice a in {0,1,2} = {A,S,B}: A accepts the majority-good side.
# World-i rank: a if i != w[c], else 2 - a.  Steps (c,1),(c,2) at world i present iff rank >= j.
# Keys: K[i][(c,j)] distinct reals.  Weak gate pass C ->_i X  <=>  first (lowest-key) step on
# which C and X differ at world i is a step of X  <=>  int_i(C) < int_i(X), where int_i encodes
# the step set with the lowest key as the most significant bit.  (Finite cells: no ties.)
import itertools
import numpy as np

def ranks(X, w, i):
    return [ (a if i != w[c] else 2 - a) for c, a in enumerate(X) ]

def steps(X, w, i):
    return {(c, j) for c, r in enumerate(ranks(X, w, i)) for j in (1, 2) if r >= j}

def order(K, i, N):
    st = [(c, j) for c in range(N) for j in (1, 2)]
    st.sort(key=lambda s: K[i][s])
    return st

def encode_all(models, w, K, N):
    """Return array V[m, i] = lex code of model m at world i (smaller = better)."""
    V = np.zeros((len(models), 3), dtype=object)
    for i in range(3):
        st = order(K, i, N)
        pos = {s: (2 * N - 1 - r) for r, s in enumerate(st)}
        for m, X in enumerate(models):
            V[m, i] = sum(1 << pos[s] for s in steps(X, w, i))
    return V

def pareto(V):
    """Indices of models not strictly dominated in all three coordinates."""
    M = len(V)
    r = [None] * 3
    for i in range(3):
        idx = sorted(range(M), key=lambda m: V[m, i])
        rk = [0] * M
        for k, m in enumerate(idx): rk[m] = k
        r[i] = rk
    by1 = sorted(range(M), key=lambda m: r[0][m])
    INF = M + 5
    tree = [INF] * (M + 1)          # Fenwick: prefix min of r3 over r2 positions
    def upd(p, val):
        p += 1
        while p <= M:
            if val < tree[p]: tree[p] = val
            p += p & -p
    def qry(p):                       # min over positions < p
        res = INF
        while p > 0:
            if tree[p] < res: res = tree[p]
            p -= p & -p
        return res
    out = []
    for m in by1:
        if qry(r[1][m]) < r[2][m]:
            pass
        else:
            out.append(m)
        upd(r[1][m], r[2][m])
    return out

def dominators(Xi, V):
    """Indices C with V[C,i] < V[Xi,i] for all i."""
    return [m for m in range(len(V)) if all(V[m, i] < V[Xi, i] for i in range(3))]

def gate(C, X, w, K, i):
    """Weak gate / guidance pass for C ->_i X (finite, exact)."""
    if C == X: return True
    UC, UX = steps(C, w, i), steps(X, w, i)
    off, on = UC - UX, UX - UC
    if not off: return True
    if not on: return False
    return min(K[i][s] for s in on) < min(K[i][s] for s in off)
