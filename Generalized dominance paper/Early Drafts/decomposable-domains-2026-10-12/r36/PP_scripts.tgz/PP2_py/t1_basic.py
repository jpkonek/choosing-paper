# Sanity: lex code <-> weak gate; Pareto set sizes for shared, offset and random keys.
import itertools, random, sys
from lexcore import *

def mk_cells(N, seed):
    rnd = random.Random(seed)
    w = [c % 3 for c in range(N)]
    rnd.shuffle(w)
    kap = rnd.sample(range(1, 10**6), N)
    return w, kap, rnd

def keys_shared_lex(N, w, kap, rnd):
    # problem-lexicographic: kappa first, then an arbitrary within-problem level order per world
    K = []
    for i in range(3):
        d = {}
        for c in range(N):
            flip = rnd.random() < 0.5
            d[(c, 1)] = kap[c] + (0.25 if flip else 0.5)
            d[(c, 2)] = kap[c] + (0.5 if flip else 0.25)
        K.append(d)
    return K

def keys_offset(N, w, kap, o):
    # k_i(c,j) = kap(c) + o[i][j]
    return [{(c, j): kap[c] + o[i][j - 1] + 1e-9 * (3 * c + j) for c in range(N) for j in (1, 2)} for i in range(3)]

def keys_random(N, rnd):
    return [{(c, j): rnd.random() for c in range(N) for j in (1, 2)} for i in range(3)]

if __name__ == '__main__':
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 6
    for seed in range(3):
        w, kap, rnd = mk_cells(N, seed)
        models = list(itertools.product((0, 1, 2), repeat=N))
        for name, K in [('shared-lex', keys_shared_lex(N, w, kap, rnd)),
                        ('random', keys_random(N, rnd))]:
            V = encode_all(models, w, K, N)
            # check equivalence on random pairs
            bad = 0
            for _ in range(3000):
                a, b = rnd.randrange(len(models)), rnd.randrange(len(models))
                for i in range(3):
                    if gate(models[a], models[b], w, K, i) != (V[a, i] <= V[b, i]): bad += 1
            P = pareto(V)
            print(f"N={N} seed={seed} {name:10s} models={len(models)} pareto={len(P)} codecheck_fail={bad}")
