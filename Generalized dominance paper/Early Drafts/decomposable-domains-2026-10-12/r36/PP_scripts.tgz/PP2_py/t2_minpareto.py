# Search over key orders (three permutations of the 2N regular steps) minimising the size of
# the lex-Pareto set of regular models.  NUMERICS (heuristic search), exact evaluation.
import itertools, random, sys, math
import numpy as np

def setup(N, w):
    models = np.array(list(itertools.product((0, 1, 2), repeat=N)), dtype=np.int64)  # M x N
    # step indicator per world: S[i] is M x (2N) boolean, column 2c+j-1 for step (c,j)
    S = []
    for i in range(3):
        r = models.copy()
        for c in range(N):
            if w[c] == i: r[:, c] = 2 - r[:, c]
        cols = np.zeros((len(models), 2 * N), dtype=np.int64)
        for c in range(N):
            cols[:, 2 * c] = (r[:, c] >= 1)
            cols[:, 2 * c + 1] = (r[:, c] >= 2)
        S.append(cols)
    return models, S

def codes(S, perms, N):
    # perms[i]: list of step columns from lowest key to highest
    V = []
    for i in range(3):
        weights = np.zeros(2 * N, dtype=np.int64)
        for rnk, col in enumerate(perms[i]):
            weights[col] = 1 << (2 * N - 1 - rnk)
        V.append(S[i] @ weights)
    return np.stack(V, axis=1)

def pareto_size(V, return_idx=False):
    M = len(V)
    r = np.argsort(np.argsort(V, axis=0), axis=0)
    by1 = np.argsort(r[:, 0])
    INF = M + 5
    tree = [INF] * (M + 1)
    out = []
    r1 = r[:, 1].tolist(); r2 = r[:, 2].tolist()
    for m in by1.tolist():
        p = r1[m]; res = INF
        while p > 0:
            if tree[p] < res: res = tree[p]
            p -= p & -p
        if not res < r2[m]: out.append(m)
        p = r1[m] + 1; val = r2[m]
        while p <= M:
            if val < tree[p]: tree[p] = val
            p += p & -p
    return out if return_idx else len(out)

def anneal(N, w, iters, seed, T0=3.0):
    rnd = random.Random(seed)
    models, S = setup(N, w)
    perms = [rnd.sample(range(2 * N), 2 * N) for _ in range(3)]
    cur = pareto_size(codes(S, perms, N)); best = (cur, [p[:] for p in perms])
    for t in range(iters):
        T = T0 * (1 - t / iters) + 1e-3
        i = rnd.randrange(3); a = rnd.randrange(2 * N); b = rnd.randrange(2 * N)
        perms[i][a], perms[i][b] = perms[i][b], perms[i][a]
        new = pareto_size(codes(S, perms, N))
        if new <= cur or rnd.random() < math.exp((cur - new) / T):
            cur = new
            if cur < best[0]: best = (cur, [p[:] for p in perms])
        else:
            perms[i][a], perms[i][b] = perms[i][b], perms[i][a]
    return best, models, S

if __name__ == '__main__':
    N = int(sys.argv[1]); iters = int(sys.argv[2])
    for seed in range(int(sys.argv[3]) if len(sys.argv) > 3 else 3):
        w = [c % 3 for c in range(N)]
        (b, perms), models, S = anneal(N, w, iters, seed)
        print(f"N={N} classes={w} seed={seed} min pareto found={b}")
