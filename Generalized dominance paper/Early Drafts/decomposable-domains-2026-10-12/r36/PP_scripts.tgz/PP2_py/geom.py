# Finite geometry for three worlds: mixed problems are lines m.g = 0 through the 2-simplex.
# Cell c: vector g_c with g_c[w] < 0 < other coords (w = minority).  Advice A = accept g_c.
import itertools
import numpy as np
from scipy.optimize import linprog

def advice_of_K(G, Kpts):
    """Advice pattern (0=A,1=S,2=B) of D_K, K = conv(Kpts)."""
    out = []
    for g in G:
        v = Kpts @ g
        out.append(0 if v.min() > 0 else (2 if v.max() < 0 else 1))
    return tuple(out)

def coherent(pattern, G):
    """Exact-up-to-LP-tolerance test that a pattern equals D_K for some compact convex K in the simplex."""
    A_rows, b_rows = [], []
    def lp(eq_g):
        # variables m1,m2,m3,t ; maximise t
        c = np.array([0, 0, 0, -1.0])
        Aub, bub = [], []
        for g, a in zip(G, pattern):
            if a == 0: Aub.append([-g[0], -g[1], -g[2], 1.0]); bub.append(0.0)   # m.g >= t
            if a == 2: Aub.append([g[0], g[1], g[2], 1.0]); bub.append(0.0)      # m.g <= -t
        Aeq = [[1, 1, 1, 0]]; beq = [1.0]
        if eq_g is not None: Aeq.append([eq_g[0], eq_g[1], eq_g[2], 0]); beq.append(0.0)
        bounds = [(0, 1)] * 3 + [(None, 1.0)]
        r = linprog(c, A_ub=np.array(Aub) if Aub else None, b_ub=np.array(bub) if bub else None,
                    A_eq=np.array(Aeq), b_eq=np.array(beq), bounds=bounds, method='highs')
        return r.status == 0 and -r.fun > 1e-9
    S_cells = [c for c, a in enumerate(pattern) if a == 1]
    if not S_cells:
        return lp(None)
    return all(lp(G[c]) for c in S_cells)

def make_lines(per_class, seed, spread=True):
    rnd = np.random.default_rng(seed)
    G, w = [], []
    for wc in range(3):
        for k in range(per_class):
            # line separating vertex wc from the other two: pick crossing points on the two edges at wc
            a = rnd.uniform(0.05, 0.95); b = rnd.uniform(0.05, 0.95)
            o = [x for x in range(3) if x != wc]
            P = np.zeros(3); P[wc] = 1 - a; P[o[0]] = a
            Q = np.zeros(3); Q[wc] = 1 - b; Q[o[1]] = b
            # g orthogonal to P and Q (within the plane sum=1 we need g.P = g.Q = 0)
            g = np.cross(P, Q)
            if g[wc] > 0: g = -g
            assert g[wc] < 0 and all(g[x] > 0 for x in o), g
            G.append(g / np.linalg.norm(g)); w.append(wc)
    return np.array(G), w

def contamination(p, eps):
    p = np.asarray(p, float)
    return np.array([(1 - eps) * p + eps * e for e in np.eye(3)])
