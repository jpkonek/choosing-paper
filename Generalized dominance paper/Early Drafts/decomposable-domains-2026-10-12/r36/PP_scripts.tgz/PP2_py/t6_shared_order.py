# CHECKED (exact finite cells): shared problem order with level offsets k_i(c,j) = kappa(c) + o[i][j].
# For each direction pattern (which level is lower at each world) and offset size, list the
# per-class-constant regular rivals X (27 of them) that have NO regular dominator C != X with
# C ->_i X at all three worlds.  Also the refutation example for the lead's sketch.
import itertools, random, sys
from lexcore import encode_all, gate

def run(N_per=3, seed=0, big=10.0):
    rnd = random.Random(seed)
    w = [c % 3 for c in range(3 * N_per)]
    N = len(w)
    kap = [rnd.random() for _ in range(N)]          # kappa in (0,1)
    models = list(itertools.product((0, 1, 2), repeat=N))
    out = {}
    for pattern in itertools.product((1, 2), repeat=3):          # low level at each world
        for size in (0.05, big):
            o = []
            for i in range(3):
                lo = pattern[i]
                o.append({lo: 0.0, 3 - lo: size})
            K = [{(c, j): kap[c] + o[i][j] + 1e-7 * rnd.random() for c in range(N) for j in (1, 2)} for i in range(3)]
            V = encode_all(models, w, K, N)
            undominated = []
            for x in itertools.product((0, 1, 2), repeat=3):      # advice on class 0,1,2
                X = tuple(x[w[c]] for c in range(N))
                m = models.index(X)
                dom = any(all(V[k, i] < V[m, i] for i in range(3)) for k in range(len(models)) if k != m)
                if not dom: undominated.append(''.join('ASB'[a] for a in x))
            out[(pattern, size)] = undominated
    return out, w, kap, models

if __name__ == '__main__':
    out, w, kap, models = run()
    for k, v in out.items():
        print("low levels", k[0], "offset", k[1], "undominated class-constant rivals (M1,M2,M3):", v)
    # Refutation of the sketch under a common offset (level 2 keyed far above level 1):
    rnd = random.Random(5)
    N = len(w)
    K = [{(c, j): kap[c] + (0 if j == 1 else 10.0) for c in range(N) for j in (1, 2)} for i in range(3)]
    hits = 0; tested = 0
    for C in models:
        # X = C silenced on its A-cells of classes M_1 and M_3 (minority index 0 and 2)
        X = tuple(1 if (a == 0 and w[c] in (0, 2)) else a for c, a in enumerate(C))
        if X == C: continue
        if not (any(a == 0 and w[c] == 0 for c, a in enumerate(C)) and any(a == 0 and w[c] == 2 for c, a in enumerate(C))):
            continue   # need a non-empty silenced set in both M_1 and M_3
        tested += 1
        if all(gate(C, X, w, K, i) for i in range(3)): hits += 1
    print(f"common offset o2-o1=10: silencing rivals dominated by the model they silence: {hits}/{tested}")
