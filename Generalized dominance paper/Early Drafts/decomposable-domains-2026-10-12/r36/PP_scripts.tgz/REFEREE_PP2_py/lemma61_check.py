# Independent check (finite cells) of Lemma 6.1, in a strengthened form:
# world 1 only REFUSES pairs (C,X), C != X, T^off non-empty, with min key(T^off) < min key(T^on)
# (min over empty set = +inf); keys may have TIES (atoms). World 2 only strict (G).
# Claim: for every regular C != X_c, either world 1 refuses (C,X_c) or X_c is a strict
# pointwise world-2 improvement of C (so strict (G) refuses).
import itertools, random
INF = float('inf')
def ranks(X, w, i):            # advice 0=A,1=S,2=B on a mixed cell with minority world w
    return [a if wc != i else 2 - a for a, wc in zip(X, w)]
def steps(X, w, i):
    return {(c, j) for c, r in enumerate(ranks(X, w, i)) for j in range(1, r + 1)}
def refused_w1(C, X, w, k):     # strict reverse order => refused
    on = steps(X, w, 0) - steps(C, w, 0); off = steps(C, w, 0) - steps(X, w, 0)
    if not off: return False
    mon = min((k[s] for s in on), default=INF); moff = min(k[s] for s in off)
    return moff < mon
def strict_improve(Y, X, w, i):  # Y strictly better than X pointwise at world i
    ry, rx = ranks(Y, w, i), ranks(X, w, i)
    return all(a <= b for a, b in zip(ry, rx)) and ry != rx
def Xc(w, k, c, Acls):
    X = []
    for cc, wc in enumerate(w):
        if wc == Acls: X.append(0); continue
        r = 0
        if k[(cc, 1)] >= c:
            r = 1
            if k[(cc, 2)] >= c: r = 2
        X.append(2 - r if wc == 0 else r)
    return tuple(X)
rnd = random.Random(7); bad = 0; tests = 0
for trial in range(300):
    N = rnd.choice([4, 5, 6]); w = [rnd.randrange(3) for _ in range(N)]
    vals = [rnd.choice([0.1, 0.5, 0.9]) if trial % 2 else rnd.random() for _ in range(2 * N)]  # ties on odd trials
    k = {(c, j): vals[2 * c + j - 1] for c in range(N) for j in (1, 2)}
    for c in sorted(set(vals)) + [2.0]:
        for Acls, other in [(2, 1), (1, 2)]:
            X = Xc(w, k, c, Acls)
            for C in itertools.product((0, 1, 2), repeat=N):
                if C == X: continue
                tests += 1
                if not (refused_w1(C, X, w, k) or strict_improve(X, C, w, other)):
                    bad += 1
print(dict(tests=tests, failures=bad))
