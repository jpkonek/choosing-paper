"""BB1 NUMERICS (C): two-move routes are almost free for the separable price (Theorem BB1.4).

Brier partners rho_2=|h_2|, rho_3=|h_3| on Q_1^+ (h = r(1,-x,-y)); v = log y - log x = f(x)+g(y) with
f = -log x (nonincreasing), g = log y (nondecreasing).  Price phi = rho_2 e^{f(x)} = rho_3 e^{-g(y)} = |h_1|.
Route a -> c -> b with c = (x_b+e, y_a-e): a 13-move (y drops by e, x free) then a 12-move (x drops by e, y free).
With cells of half-width d < e/2, the worst-case factor phi(target)/phi(source) needed is
   F = (1+tau)^2 * sup_{cell a} e^{g} / inf_{cell c} e^{g} * sup_{cell c} e^{-f} ... computed below exactly,
and F -> 1 as e, d, tau -> 0, uniformly over a, b in the rectangle [0.2,0.4]^2.
"""
import numpy as np
rng = np.random.default_rng(1)
f = lambda x: -np.log(x); g = lambda y: np.log(y)
def factor(a, b, e, d, tau=1e-4):
    c = (b[0]+e, a[1]-e)
    # 13-move a->c: need rho_3(I) > rho_3(S); phi = rho_3 e^{-g}: phi(I)/phi(S) >= e^{g(y_S)-g(y_I)} worst case
    f13 = (1+tau)*np.exp(g(a[1]+d) - g(c[1]-d))
    # 12-move c->b: need rho_2(T) > rho_2(I); phi = rho_2 e^{f}: phi(T)/phi(I) >= e^{f(x_T)-f(x_I)} worst case
    f12 = (1+tau)*np.exp(f(b[0]-d) - f(c[0]+d))
    return f13*f12
for e in (0.02, 0.005, 0.001, 0.0002):
    worst = 0
    for _ in range(20000):
        a = rng.uniform(0.2, 0.4, 2); b = rng.uniform(0.2, 0.4, 2)
        worst = max(worst, factor(a, b, e, e/4))
    print(f"e={e:7.4f}: worst route factor over 20000 random pairs = {worst:.6f}")
