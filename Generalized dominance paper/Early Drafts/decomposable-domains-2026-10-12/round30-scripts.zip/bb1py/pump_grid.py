"""BB1 NUMERICS (A): positive-cycle search in the move graph of the link class.

Points a=(x,y) of a grid in a rectangle Omega of the link class Q_1^+ (h = r(1,-x,-y)).
12-move a->b allowed iff x_b < x_a  (weight 0)
13-move a->b allowed iff y_b < y_a  (weight v(b)-v(a)),  v = log(rho_3/rho_2).
A positive-weight cycle is a pump (Lemma BB1.2).  Separable v = f(x)+g(y) with f nonincreasing,
g nondecreasing has none (Lemma BB1.3).  Longest-path Bellman-Ford with cycle detection.
"""
import numpy as np, itertools, math

def search(v, xs, ys):
    pts = [(x, y) for x in xs for y in ys]
    n = len(pts)
    edges = []
    for i, a in enumerate(pts):
        for j, b in enumerate(pts):
            if i == j: continue
            w = None
            if b[0] < a[0] - 1e-12: w = 0.0
            if b[1] < a[1] - 1e-12:
                w13 = v(*b) - v(*a)
                w = w13 if w is None else max(w, w13)
            if w is not None: edges.append((i, j, w))
    E = np.array(edges)
    src, dst, wt = E[:, 0].astype(int), E[:, 1].astype(int), E[:, 2]
    dist = np.zeros(n); pred = -np.ones(n, dtype=int); last = -1
    for it in range(n + 1):
        cand = dist[src] + wt
        order = np.argsort(cand)
        changed = False
        best = np.full(n, -np.inf); arg = -np.ones(n, dtype=int)
        np.maximum.at(best, dst, cand)
        imp = best > dist + 1e-12
        if not imp.any(): return None, pts
        for j in np.nonzero(imp)[0]:
            k = np.nonzero((dst == j) & (np.abs(cand - best[j]) < 1e-15))[0][0]
            pred[j] = src[k]
        dist = np.where(imp, best, dist); last = int(np.nonzero(imp)[0][0])
    # recover a cycle
    x = last
    for _ in range(n): x = pred[x]
    cyc = [x]; y = pred[x]
    while y != x: cyc.append(y); y = pred[y]
    cyc.reverse()
    return cyc, pts

xs = np.linspace(0.20, 0.40, 21); ys = np.linspace(0.20, 0.40, 21)
kappa = 1.0
cases = {
 "Brier (separable): v=log y-log x": lambda x, y: math.log(y) - math.log(x),
 "Brier*(1+kappa*1{y>x}) (monotone, NOT separable)": lambda x, y: math.log(y) - math.log(x) + (math.log(1+kappa) if y > x else 0.0),
 "Brier*(1+kappa*bump) (NOT separable)": lambda x, y: math.log(y) - math.log(x) + math.log(1 + kappa*math.exp(-((x-.25)**2+(y-.25)**2)/0.004)),
 "separable non-Brier: v=-3x+2y": lambda x, y: -3*x + 2*y,
}
for name, v in cases.items():
    cyc, pts = search(v, xs, ys)
    if cyc is None:
        print(f"{name}: no positive cycle")
        continue
    tot = 0.0; desc = []
    for k in range(len(cyc)):
        a, b = pts[cyc[k]], pts[cyc[(k+1) % len(cyc)]]
        w12 = 0.0 if b[0] < a[0]-1e-12 else None
        w13 = (v(*b) - v(*a)) if b[1] < a[1]-1e-12 else None
        if w13 is not None and (w12 is None or w13 > w12): tot += w13; desc.append(f"13:{a}->{b}")
        else: desc.append(f"12:{a}->{b}")
    print(f"{name}: POSITIVE cycle, length {len(cyc)}, weight {tot:.4f}")
    for d in desc: print("   ", d.replace("np.float64", ""))
