"""BB1 NUMERICS (B): realise the 4-move pump of pump_grid.py (bump case) with genuine sets.

Link class Q_1^+ of U: h = r(1,-x,-y), r>0.  mu = standard Gaussian on R^3.  Partners (Brier type):
rho_2(h)=|h_2|, rho_3(h)=|h_3|*(1+kappa*bump(x,y)).  Pushing mu to (x,y) with all r integrated:
  d mu = (2pi)^{-3/2} r^2 e^{-r^2 A/2} dr dx dy,  A = 1+x^2+y^2,
  rho_2-mass density in (x,y): (2pi)^{-3/2} * x * int r^3 e^{-r^2A/2} dr = (2pi)^{-3/2} * x * 2/A^2.
Each cell is the full cone over an (x,y)-square of half-width eta; a set S inside a cell is a radial
sub-cone (r < R), so all of S's points lie in the cell's square, and its w = rho_3/rho_2 average lies in
[min_cell w, max_cell w].  We track worst-case (largest possible) rho_2 masses and check:
 (i) every required set fits in its cell (required rho_2 mass <= cell rho_2 mass),
 (ii) the final set can be taken strictly inside S_0: worst-case rho_2(S_N) < rho_2(S_0).
Step rules: 12-move needs rho_2(S_{k+1}) = (1+tau) rho_2(S_k); 13-move needs rho_3(S_{k+1}) = (1+tau) rho_3(S_k).
"""
import numpy as np, math
kappa = 1.0
bump = lambda x, y: math.exp(-((x-.25)**2+(y-.25)**2)/0.004)
w = lambda x, y: (y/x)*(1+kappa*bump(x, y))
d2 = lambda x, y: (2*math.pi)**-1.5 * x * 2/(1+x*x+y*y)**2
cyc = [((0.24, 0.40), '13'), ((0.40, 0.39), '12'), ((0.39, 0.26), '13'), ((0.25, 0.25), '12')]
eta, tau = 0.003, 1e-3
def cellstats(c):
    g = np.linspace(-eta, eta, 41)
    X, Y = np.meshgrid(c[0]+g, c[1]+g)
    W = np.vectorize(w)(X, Y); D = np.vectorize(d2)(X, Y)
    return W.min(), W.max(), D.mean()*(2*eta)**2
st = [cellstats(c) for c, _ in cyc]
# check strict separations demanded by the move type (with cell half-widths)
ok = True
for k, (c, t) in enumerate(cyc):
    nxt = cyc[(k+1) % len(cyc)][0]
    sep = (c[0]-nxt[0]) if t == '12' else (c[1]-nxt[1])
    ok &= sep > 2*eta
    print(f"move {k}: {t} {c}->{nxt}, separation {sep:.3f} > 2eta: {sep>2*eta}")
m0 = 0.25*st[0][2]           # rho_2(S_0): a quarter of cell 0
m = m0; fits = True
for k, (c, t) in enumerate(cyc):
    wmin_a, wmax_a, cell_a = st[k]; wmin_b, wmax_b, cell_b = st[(k+1) % len(cyc)]
    if t == '12': m = (1+tau)*m
    else: m = (1+tau)*m*wmax_a/wmin_b       # worst case: rho_3(S_k)<=wmax_a*m, rho_2(S_{k+1})<=rho_3/wmin_b
    fits &= m <= cell_b
    print(f"  after move {k}: worst-case rho_2 mass {m:.3e}, cell mass {cell_b:.3e}")
print(f"separations ok: {ok}; all sets fit: {fits}; worst-case rho_2(S_N)/rho_2(S_0) = {m/m0:.4f} (<1 means pump)")

# (iii) the cells lie in U = D_{K'} for K' = u + s(T1-u), eps=0.3, s=0.1: h=(1,-x,-y) in U iff
#      k_1 - k_2 x - k_3 y > 0 at every vertex k of K'.
eps, s = 0.3, 0.1
c0 = (1-eps)/3; u = np.ones(3)/3
Kp = [u + s*((c0*np.ones(3) + eps*np.eye(3)[k]) - u) for k in range(3)]
inU = all(min(k[0]-k[1]*(c[0]+dx)-k[2]*(c[1]+dy) for k in Kp) > 0
          for c, _ in cyc for dx in (-eta, eta) for dy in (-eta, eta))
print(f"all cells inside U (K' = u + 0.1(T1-u), eps=0.3): {inU}")
