"""BB2 sanity checks (NUMERICS only; no proof in BB2_notes.md rests on them).

Run from inside this folder:  python3 -I bb2_checks.py > bb2_checks.out

(1) Pattern lemma (BB2 Lemma 2.7(a)): for v != v' in Delta and a credal set K
    containing v', the open cone W = {v.g > 0 > v'.g} lies in D_{v} \\ cl D_K and
    meets two open orthants sigma1, sigma2 with sigma2 not in {sigma1, -sigma1}.
(2) Collar balls at the six crossings of T1 (BB2 Lemma 2.7(b)): w - s(1 - e_c)
    lies outside cl D_T1 (in U^-), and the two halves of a small ball around it
    have sign patterns that differ exactly in coordinate c.
(3) Wedge constant (BB2 Lemma 2.6(W1)): min over m in W_v(U) of m.w'/|m - v| > 0
    at every crossing of T1 (sampled).
(4) Robust surround (BB2 Lemma 5.6): wall points perturbed by <= 3*delta still
    have p* in their convex hull when delta/d is small (p* with min coordinate >= 0.15;
    the admissible ratio depends on dist(p*, boundary)); failures appear when it is not.
(5) The (1) test for the vertex pairs of T1 actually used in Theorem 4.2.
"""
import numpy as np

rng = np.random.default_rng(20261017)


def T1_vertices(eps):
    c0 = (1 - eps) / 3
    return [c0 * np.ones(3) + eps * np.eye(3)[k] for k in range(3)]


def P_K(K, g):
    return min(float(m @ g) for m in K)


def pattern(g):
    return tuple(int(s) for s in np.sign(g))


def opposite(s):
    return tuple(-x for x in s)


def check_pattern_lemma(trials=2000, samples=400, fixed_pairs=None):
    fails = 0
    tested = 0
    pairs = fixed_pairs if fixed_pairs is not None else [None] * trials
    for pr in pairs:
        if pr is None:
            v = rng.dirichlet(np.ones(3))
            vp = rng.dirichlet(np.ones(3))
            extra = [rng.dirichlet(np.ones(3)) for _ in range(3)]
        else:
            v, vp = pr
            extra = [rng.dirichlet(np.ones(3)) for _ in range(3)]
        if np.linalg.norm(v - vp) < 1e-6:
            continue
        # K = conv(v', extra points) with v not in K; we only need v' in K.
        K = [vp] + extra
        # sample W = {v.g>0>v'.g}: g = a*alpha - b*beta + s*n
        A = np.vstack([v, vp])
        # alpha, beta in span(v, v') with v.alpha=1, v'.alpha=0, v.beta=0, v'.beta=1
        Mspan = np.vstack([v, vp]).T  # 3x2
        G = A @ Mspan  # 2x2
        coef = np.linalg.solve(G, np.eye(2))
        alpha = Mspan @ coef[:, 0]
        beta = Mspan @ coef[:, 1]
        n = np.cross(v, vp)
        pats = set()
        ok = True
        for _ in range(samples):
            a = rng.exponential()
            b = rng.exponential()
            s = rng.normal() * 10 ** rng.uniform(-2, 6)
            g = a * alpha - b * beta + s * n
            if not (v @ g > 0 and vp @ g < 0):
                ok = False
            if P_K(K, g) >= 0:
                ok = False
            if np.min(np.abs(g)) > 1e-12:
                pats.add(pattern(g))
        two = any(s2 != s1 and s2 != opposite(s1) for s1 in pats for s2 in pats)
        tested += 1
        if not (ok and two and np.linalg.norm(n) > 0):
            fails += 1
    return tested, fails


def check_collar_balls(eps_list=(0.05, 0.2, 0.3, 0.6, 0.9)):
    out = []
    for eps in eps_list:
        V = T1_vertices(eps)
        kappa = (1 + 2 * eps) / (1 - eps)
        # crossings w_{ck}: on facet k, coordinate c = 0  (write-up section 2.3 and cyclic images)
        crossings = []
        base = {  # facet 1: w21 = (-1, 0, kappa), w31 = (-1, kappa, 0)
            (0, 1): np.array([-1.0, 0.0, kappa]),
            (0, 2): np.array([-1.0, kappa, 0.0]),
        }
        for (k, c), w in base.items():
            for shift in range(3):
                perm = [(i - shift) % 3 for i in range(3)]
                ww = w[perm]
                kk = (k + shift) % 3
                cc = (c + shift) % 3
                crossings.append((kk, cc, ww))
        bad = 0
        for kk, cc, w in crossings:
            vk = V[kk]
            others = [V[j] for j in range(3) if j != kk]
            relint = abs(vk @ w) < 1e-12 and all(m @ w > 1e-9 for m in others) and abs(w[cc]) < 1e-12
            s = 1e-2
            x = w - s * (np.ones(3) - np.eye(3)[cc])
            outside = P_K(V, x) < 0
            r = s / 10
            p1 = pattern(x + r * np.eye(3)[cc])
            p2 = pattern(x - r * np.eye(3)[cc])
            differ_only_c = all((p1[i] == p2[i]) == (i != cc) for i in range(3))
            not_opp = p2 != opposite(p1)
            # small ball stays outside cl D_T1
            ball_out = all(P_K(V, x + r * u) < 0 for u in rng.normal(size=(200, 3)) / 3)
            if not (relint and outside and differ_only_c and not_opp and ball_out):
                bad += 1
        out.append((eps, len(crossings), bad))
    return out


def check_wedge_constant(eps_list=(0.05, 0.3, 0.6, 0.9), rad=0.05, nfacet=60, nm=4000):
    out = []
    for eps in eps_list:
        V = T1_vertices(eps)
        kappa = (1 + 2 * eps) / (1 - eps)
        w = np.array([-1.0, 0.0, kappa])  # crossing of coordinate 2 on F_1
        v = V[0]
        # facet points near w: F_1 cap ball, parametrised in v^perp
        Q, _ = np.linalg.qr(np.column_stack([v, rng.normal(size=3), rng.normal(size=3)]))
        basis = Q[:, 1:]
        fac = []
        for _ in range(nfacet):
            z = basis @ rng.normal(size=2)
            z = z / np.linalg.norm(z) * rad * rng.random()
            h = w + z - (v @ (w + z)) / (v @ v) * v
            if np.linalg.norm(h - w) <= rad:
                fac.append(h)
        fac.append(w)
        fac = np.array(fac)
        # sample m in aff Delta near v in the wedge W_v(U) = {m : m.h >= 0 for h in facet patch}
        worst = np.inf
        cnt = 0
        for _ in range(nm):
            d = rng.normal(size=3)
            d -= d.mean()
            m = v + d * rng.random() * 0.3
            if np.min(fac @ m) >= 0 and np.linalg.norm(m - v) > 1e-9:
                cnt += 1
                inner = fac[np.linalg.norm(fac - w, axis=1) <= rad / 2]
                worst = min(worst, np.min(inner @ m) / np.linalg.norm(m - v))
        out.append((eps, cnt, worst))
    return out


def check_surround(trials=3000, ratios=(0.02, 0.05, 0.1, 0.5, 0.9)):
    E = np.eye(3)
    res = {}
    for rho in ratios:
        fails = 0
        for _ in range(trials):
            p = rng.dirichlet(np.ones(3) * 3)
            while p.min() < 0.15:  # the admissible delta/d depends on dist(p*, boundary)
                p = rng.dirichlet(np.ones(3) * 3)
            d = 0.05 + 0.1 * rng.random()
            delta = rho * d
            Qs = []
            for i in range(3):
                t = (d - delta) / 2 + rng.random() * 0.5
                err = rng.normal(size=3)
                err -= err.mean()
                err *= 3 * delta * rng.random() / max(np.linalg.norm(err), 1e-12)
                Qs.append(p + t * (E[i] - p) + err)
            # barycentric coordinates in aff Delta: use two coordinates plus the affine row
            M = np.vstack([np.array(Qs)[:, :2].T, np.ones(3)])
            try:
                lam = np.linalg.solve(M, np.append(p[:2], 1.0))
            except np.linalg.LinAlgError:
                fails += 1
                continue
            if np.min(lam) < -1e-12:
                fails += 1
        res[rho] = fails
    return res


def main():
    print("BB2 checks (NUMERICS). seed 20261017")
    t, f = check_pattern_lemma()
    print(f"(1) pattern lemma, random v != v', K containing v': {t} cases, {f} failures")
    for eps, n, bad in check_collar_balls():
        print(f"(2) eps={eps}: {n} crossings of T1, collar-ball failures = {bad}")
    for eps, cnt, worst in check_wedge_constant():
        print(f"(3) eps={eps}: {cnt} wedge samples, min m.w'/|m-v| = {worst:.4f} (must be > 0)")
    for rho, fails in check_surround().items():
        print(f"(4) surround, delta/d={rho}: {fails} failures out of 3000")
    pairs = []
    for eps in (0.05, 0.3, 0.6, 0.9):
        V = T1_vertices(eps)
        for i in range(3):
            for j in range(3):
                if i != j:
                    pairs.append((V[i], V[j]))
    t, f = check_pattern_lemma(fixed_pairs=pairs * 20)
    print(f"(5) pattern lemma for vertex pairs of T1 (4 eps, 6 ordered pairs, 20 random K each): {t} cases, {f} failures")


if __name__ == "__main__":
    main()
