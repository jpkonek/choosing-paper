"""CHECKED part of Theorem Z1.7: on the star Sigma = S_1 u S_2 u S_3 the Bayes advice of the star field
(c = h + lam h_o e_o, c' from cases A/B) equals the posterior advice; at u it is T1's advice; sign patterns."""
import random, sys
from fractions import Fraction as Fr
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from z1common import *

rng = random.Random(20261017)
EPS = [Fr(1, 20), Fr(1, 10), Fr(3, 10), Fr(1, 2), Fr(4, 5)]
NPAIR = 1500
tot = {}
for eps in EPS:
    eps_, c0, lam, A = params(eps)
    stats = dict(pairs=0, pts=0, mismatch=0, ties=0, pattern_bad=0, endint_bad=0, caseA=0, caseB=0)
    for _ in range(NPAIR):
        h0 = rand_pair(rng)
        h, o = majority(h0)
        c = c_vec(eps, h, o); cp, case = cprime_vec(eps, h, o)
        stats['case' + case[0]] += 1
        # strict sign patterns: c ~ h, c' ~ -h
        if any((c[i] > 0) != (h[i] > 0) for i in range(3)) or any((cp[i] > 0) != (h[i] < 0) or cp[i] == 0 for i in range(3)):
            stats['pattern_bad'] += 1
        stats['pairs'] += 1
        pts = [U] + [E[k] for k in range(3)]
        for k in range(3):
            pts += [seg(k, Fr(rng.randint(1, 999), 1000)) for _ in range(6)]
            for r in Ocross(eps, k, h):           # adversarial: just either side of each crossing
                for dlt in (Fr(1, 10**6), Fr(-1, 10**6), Fr(1, 10**12), Fr(-1, 10**12)):
                    if 0 < r + dlt < 1: pts.append(seg(k, r + dlt))
            # O-set shape on S_k: end interval at u (k != o) or at e_k (k == o)
            rts = Ocross(eps, k, h)
            if len(rts) > 1: stats['endint_bad'] += 1
        for w in pts:
            pa, pt = posterior(eps, w, h)
            fa, ft = field_advice(c, cp, w)
            if pt or ft: stats['ties'] += 1; continue
            stats['pts'] += 1
            if pa != fa:
                stats['mismatch'] += 1
                if stats['mismatch'] < 4: print('MISMATCH', eps, h, o, w, pa, fa, case)
    print('eps =', eps, stats)
    tot[eps] = stats
print('TOTAL mismatches:', sum(s['mismatch'] for s in tot.values()),
      ' pattern failures:', sum(s['pattern_bad'] for s in tot.values()),
      ' non-end-interval O-sets:', sum(s['endint_bad'] for s in tot.values()))
