"""Controls and NUMERICS for Z1.
(1) negative control: the attribution-frozen-at-u O-vector (the X2.6 field at p=u) on the star -> mismatches.
(2) NUMERICS: the star field off the star (random interior weights) -> how often its Bayes advice differs
    from the posterior (expected > 0: the field is not a posterior field on open sets, cf. Y3.8).
(3) NUMERICS: is the posterior on  S_1 u S_2 u S_3 u [e1,e2]  (star plus one full edge) realisable per pair by
    a single O-vector c' with the strict sign pattern of -h?  LP per pair on sampled constraints."""
import random, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from z1common import *
import numpy as np
from scipy.optimize import linprog

rng = random.Random(7)
for eps in [Fr(1, 10), Fr(3, 10), Fr(1, 2)]:
    eps_, c0, lam, A = params(eps)
    # (1)
    mm = tot = 0
    for _ in range(400):
        h, o = majority(rand_pair(rng))
        c = c_vec(eps, h, o)
        a = max((i for i in range(3) if i != o), key=lambda i: h[i])      # attribution frozen at u
        cp = tuple(-h[i] * (1 + lam * (i == a)) for i in range(3))
        for k in range(3):
            for _ in range(5):
                w = seg(k, Fr(rng.randint(1, 999), 1000))
                pa, pt = posterior(eps, w, h); fa, ft = field_advice(c, cp, w)
                if pt or ft: continue
                tot += 1; mm += (pa != fa)
    print(f'eps={eps}: (1) frozen-attribution control on star: {mm} mismatches of {tot}')
    # (2)
    mm = tot = 0
    for _ in range(400):
        h, o = majority(rand_pair(rng))
        c = c_vec(eps, h, o); cp, _ = cprime_vec(eps, h, o)
        for _ in range(5):
            p = [Fr(rng.randint(1, 1000)) for _ in range(3)]; s = sum(p); w = tuple(x / s for x in p)
            pa, pt = posterior(eps, w, h); fa, ft = field_advice(c, cp, w)
            if pt or ft: continue
            tot += 1; mm += (pa != fa)
    print(f'eps={eps}: (2) star field vs posterior at random interior weights: {mm} differ of {tot}')
    # (3)
    bad = 0; N = 300; worst = []
    for _ in range(N):
        h, o = majority(rand_pair(rng))
        rows, rhs = [], []
        pts = [seg(k, Fr(j, 40)) for k in range(3) for j in range(0, 41)]
        pts += [(Fr(1 - j / Fr(40)), Fr(j, 40), Fr(0)) for j in range(41)]
        for k in range(3):
            for r in Ocross(eps, k, h):
                for d in (Fr(1, 10**5), Fr(-1, 10**5)):
                    if 0 < r + d < 1: pts.append(seg(k, r + d))
        # crossings on the edge [e1,e2]: sample finely near them too
        for w in pts:
            pa, pt = posterior(eps, w, h)
            if pt: continue
            sgn_ = 1 if pa == 'O' else -1
            # sgn_*(c'.w) >= t  ->  -sgn_*w.c' + t <= 0
            rows.append([-sgn_ * float(x) for x in w] + [1.0]); rhs.append(0.0)
        for i in range(3):   # pattern: sign c'_i = sign(-h_i), strictly: -s*c'_i + t <= 0
            s = -1 if h[i] > 0 else 1
            row = [0.0, 0.0, 0.0, 1.0]; row[i] = -s; rows.append(row); rhs.append(0.0)
        res = linprog([0, 0, 0, -1], A_ub=np.array(rows), b_ub=np.array(rhs),
                      bounds=[(-1, 1)] * 3 + [(None, 1)], method='highs')
        t = -res.fun
        if t < 1e-9:
            bad += 1
            if len(worst) < 3: worst.append((tuple(float(x) for x in h), o, t))
    print(f'eps={eps}: (3) star + full edge [e1,e2]: {bad} of {N} pairs have NO admissible O-line; e.g. {worst}')

# (4) exact: for case-A pairs with odd world 1 (code 0), the O-line is forced through x_2, x_3 (crossings on S_2, S_3);
# compare where it meets the edge [e1,e2] with the posterior edge O-boundary  w2/w1 = 1/(A t2).
print('(4) exact forced-line test, star + full edge [e1,e2]:')
for eps in [Fr(1, 10), Fr(3, 10), Fr(1, 2)]:
    eps_, c0, lam, A = params(eps)
    shown = 0; nA = 0; ndiff = 0
    rr = random.Random(11)
    while nA < 200:
        h, o = majority(rand_pair(rr))
        if o != 0 or posterior(eps, U, h)[0] != 'O': continue
        nA += 1
        cp, case = cprime_vec(eps, h, o)          # forced: proportional to x_2 x x_3
        # edge point (1-s, s, 0) where cp vanishes:  cp0 (1-s) + cp1 s = 0
        s_star = cp[0] / (cp[0] - cp[1])
        t2 = h[1] / (-h[0])
        s_post = 1 / (1 + A * t2)                  # w2/w1 = 1/(A t2)
        if s_star != s_post:
            ndiff += 1
            if shown < 2:
                print(f'  eps={eps} h={h}: forced line meets edge at s*={float(s_star):.6f}, posterior boundary s={float(s_post):.6f}')
                shown += 1
    print(f'  eps={eps}: {ndiff} of {nA} case-A odd-world-1 pairs have s* != s_post (exact)')
