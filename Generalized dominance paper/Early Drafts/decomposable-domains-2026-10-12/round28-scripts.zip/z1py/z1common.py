"""Exact helpers for note Z1 (star field). Worlds 0,1,2 in code = 1,2,3 in the note."""
from fractions import Fraction as Fr
import random

def params(eps):
    eps = Fr(eps); c0 = (1 - eps) / 3; lam = eps / c0
    return eps, c0, lam, 1 + lam

def dot(a, b): return sum(x * y for x, y in zip(a, b))
def had(a, b): return tuple(x * y for x, y in zip(a, b))
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
U = (Fr(1, 3),) * 3
E = [tuple(Fr(int(i == k)) for i in range(3)) for k in range(3)]

def verts(eps):
    eps, c0, lam, A = params(eps)
    return [tuple(c0 + (eps if j == k else 0) for j in range(3)) for k in range(3)]

def seg(k, s):
    """point (1-s)u + s e_k of the star arm S_k"""
    return tuple((1 - s) * U[i] + s * E[k][i] for i in range(3))

def posterior(eps, w, h):
    """advice of the posterior model D_{nu(w.T1)} on the pair with orientation h:
    'M' accept h, 'O' accept -h, 'S' silence; second value True if on a boundary (tie)"""
    V = verts(eps)
    vals = [dot(had(w, v), h) for v in V]
    if min(vals) > 0: return 'M', False
    if max(vals) < 0: return 'O', False
    return 'S', (min(vals) == 0 or max(vals) == 0)

def majority(h):
    """return the majority orientation (two positive coords) and its odd world"""
    if sum(1 for x in h if x > 0) == 1: h = tuple(-x for x in h)
    o = [i for i in range(3) if h[i] < 0][0]
    return h, o

def Ofun(eps, k, h):
    """the convex piecewise-linear map s -> max_k' (w(s).v_k').h on arm S_k, as list of (a,b): a+b s"""
    V = verts(eps)
    out = []
    for v in V:
        a = dot(had(U, v), h); b = dot(had(E[k], v), h) - a
        out.append((a, b))
    return out

def Ocross(eps, k, h):
    """the unique s in (0,1) where the posterior O-boundary meets S_k (max of pieces = 0), or None"""
    pcs = Ofun(eps, k, h)
    f = lambda s: max(a + b * s for a, b in pcs)
    cands = [-a / b for a, b in pcs if b != 0 and 0 < -a / b < 1]
    roots = sorted(set(s for s in cands if f(s) == 0))
    return roots

def c_vec(eps, h, o):
    eps, c0, lam, A = params(eps)
    return tuple(h[i] * (1 + lam * (i == o)) for i in range(3))

def cprime_vec(eps, h, o):
    """the constructed O-vector c'(h) of the star field (cases A, B of Lemma Z1.6)"""
    adv_u, _ = posterior(eps, U, h)
    if adv_u == 'O':   # case A: line through the crossings x_j, x_l on the two non-odd arms
        j, l = [i for i in range(3) if i != o]
        rj = Ocross(eps, j, h); rl = Ocross(eps, l, h)
        assert len(rj) == 1 and len(rl) == 1, ('caseA crossings', h, rj, rl)
        xj, xl = seg(j, rj[0]), seg(l, rl[0])
        n = cross(xj, xl)
        if dot(n, U) < 0: n = tuple(-x for x in n)
        return n, 'A'
    ro = Ocross(eps, o, h)
    if not ro:         # no O at all on S_o (cannot happen: O at e_o); keep for safety
        return tuple(-Fr(1) if i != o else Fr(1, 10) for i in range(3)), 'B0'
    assert len(ro) == 1, ('caseB crossing', h, ro)
    th = seg(o, ro[0])[o]
    return tuple((1 if i == o else 0) - th for i in range(3)), 'B'

def field_advice(c, cp, w):
    a, b = dot(c, w), dot(cp, w)
    tie = (a == 0 or b == 0)
    if a > 0 and b > 0:
        d = dot(tuple(x - y for x, y in zip(c, cp)), w)
        return ('M' if d > 0 else 'O'), (tie or d == 0)
    if a > 0: return 'M', tie
    if b > 0: return 'O', tie
    return 'S', tie

def rand_pair(rng):
    """random mixed gamble with log-uniform coordinate ratios (exact rationals)"""
    while True:
        h = []
        for _ in range(3):
            m = Fr(rng.randint(1, 4000), 1000) ** rng.choice([1, 1, 2, 3])
            if rng.random() < .5: m = 1 / m
            h.append(m if rng.random() < .5 else -m)
        h = tuple(h)
        if any(x > 0 for x in h) and any(x < 0 for x in h): return h
