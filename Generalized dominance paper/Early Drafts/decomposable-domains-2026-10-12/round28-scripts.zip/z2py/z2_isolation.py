"""Z2 Prop Z2.4 (CHECKED): for the boundary field of z2_boundary.py, the (a.e.-unique) Bayes model
at q = u + delta is not convex for every small delta != 0.  Exact certificate: gambles g+, g-
accepted at q, g+ + g- rejected.  Construction (proof of Prop Z2.4): pick i != j with
0 < q_i - q_j < q_k/2; on the slice g_i = 1, g_j = -y, g_k = -z the acceptance boundary
q_j S(y) + q_k S(z) = q_i has a convex kink at y = 1/A (where S has a concave kink), so the
accepted region below it is not convex."""
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from z2common import *
from z2_boundary import make

def certificate(eps, q, F):
    eps_, c0, lam, A = params(eps); kS = (2 + lam) / 2; b = 1 / (2 + lam); n = F['n']
    for i in range(3):
        for j in range(3):
            if i == j: continue
            k = 3 - i - j
            if not (0 < q[i] - q[j] < q[k] / 2): continue
            zs = (q[i] - q[j]) / (kS * q[k]); h = zs / 2
            zp, zm = zs - h, zs + h
            yp = (q[i] - q[k] * kS * zp) / (A * q[j])                 # branch S(y) = A y  (y > 1/A)
            Dm = (q[i] - q[k] * kS * zm) / q[j]
            ym = (1 - (1 - Dm) / kS) / A                              # branch S(y) = 1 - kS(1 - A y)
            assert yp > 1 / A and b <= ym <= 1 / A and 0 < zm < b
            eta = Fr(1, 10**9)
            def gam(y, z):
                g = [Fr(0)] * 3; g[i] = Fr(1); g[j] = -y * (1 - eta); g[k] = -z * (1 - eta); return tuple(g)
            gp, gm = gam(yp, zp), gam(ym, zm); gs = tuple(x + y for x, y in zip(gp, gm))
            ap, am, asum = advice_field(n, q, gp), advice_field(n, q, gm), advice_field(n, q, gs)
            # margin: value of q.n at the sum, relative
            val = dot(q, n(gs))
            return (i, j, k), ap, am, asum, val
    return None

if __name__ == '__main__':
    out = sys.stdout
    for eps in (Fr(1, 10), Fr(3, 10), Fr(3, 5)):
        F = make(eps); ok = 0; tot = 0
        for r in (Fr(1, 100), Fr(1, 1000), Fr(1, 10**5)):
            for a in range(24):
                ang = 2 * math.pi * a / 24
                ca = Fr(round(math.cos(ang) * 10**6), 10**6); sa = Fr(round(math.sin(ang) * 10**6), 10**6)
                d = (ca - sa / 2, sa - ca / 2, -(ca + sa) / 2)          # a direction in the plane sum = 0
                if all(x == 0 for x in d): continue
                q = tuple(Fr(1, 3) + r * x for x in d)
                c = certificate(eps, q, F); tot += 1
                if c and c[1] == 'M' and c[2] == 'M' and c[3] != 'M' and c[4] < 0: ok += 1
                elif tot - ok <= 3: out.write(f"   no certificate: eps={eps} r={r} angle={15*a}: {c}\n")
        out.write(f"eps={eps}: exact non-convexity certificates found at {ok} of {tot} weights q = u + r d "
                  f"(r in 1e-2, 1e-3, 1e-5; 24 directions)\n")
