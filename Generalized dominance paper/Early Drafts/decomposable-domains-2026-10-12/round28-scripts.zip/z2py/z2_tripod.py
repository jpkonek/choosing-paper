"""Z2 Theorem Z2.2 (additive tripod): one strictly guiding additive field whose Bayes
model along each straight weight leg a -> e_j is the contamination family
K_j(s) = (1-s) T1 + s e_j, for all three j at once.  Exact rational checks."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from z2common import *

def make_field(eps, a=U):
    V = T1_vertices(eps)
    def n(g):
        P0 = P(V, g)
        if P0 == 0: return g          # null set of gambles
        sig = sgn(P0)
        J = [j for j in range(3) if sgn(g[j]) == -sig]
        if not J: return g
        xs = []
        for j in J:
            s = P0 / (P0 - g[j])     # root of (1-s)P0 + s g_j
            assert 0 < s < 1
            xs.append(tuple((1 - s) * a[i] + s * (1 if i == j else 0) for i in range(3)))
        if len(J) == 2:
            v = cross(xs[0], xs[1])
            if sgn(dot(v, a)) != sig: v = tuple(-x for x in v)
        else:
            j = J[0]; k, l = [i for i in range(3) if i != j]
            s = P0 / (P0 - g[j])
            alpha = Fr(1)
            beta = alpha * (1 - s) * (a[k] + a[l]) / ((1 - s) * a[j] + s)
            v = [0, 0, 0]
            v[k] = sig * alpha; v[l] = sig * alpha; v[j] = -sig * beta
            v = tuple(v)
        # normalise to sup-norm of g (integrable envelope |n| <= |g|_inf)
        M = max(abs(x) for x in v); Mg = max(abs(x) for x in g)
        return tuple(x * Mg / M for x in v)
    return n

def run(eps, N, rng, out):
    V = T1_vertices(eps)
    n = make_field(eps)
    bad_sign = 0; bad_leg = 0; ties = 0; checks = 0; bad_end = 0
    for t in range(N):
        mode = t % 3
        g = rand_gamble(rng)
        if mode == 1:   # near T1's boundary: shift g along 1 so that P_T1(g) ~ 0
            P0 = P(V, g); d0 = Fr(rng.choice([-5,-4,-3,-2,-1,1,2,3,4,5]), 10**4)
            g = tuple(x - P0 + d0 for x in g)   # P_T1(g) = d0 != 0 (P_T1(g)=0 is null)
            if any(x == 0 for x in g): continue
        if mode == 2:   # near a coordinate plane
            j = rng.randrange(3); g = tuple(Fr(rng.randint(-9, 9), 10**4) if i == j else g[i] for i in range(3))
            if any(x == 0 for x in g): continue
        for h in (g, tuple(-x for x in g)):
            nh = n(h)
            if any(sgn(nh[i]) != sgn(h[i]) for i in range(3)): bad_sign += 1
        for j in range(3):
            # parameters: random, endpoints, and around this pair's crossing points
            ss = [Fr(0), Fr(1), Fr(rng.randint(1, 999), 1000)]
            for hh in (g, tuple(-x for x in g)):
                P0 = P(V, hh)
                if P0 != 0 and sgn(hh[j]) == -sgn(P0):
                    s0 = P0 / (P0 - hh[j]); d = Fr(1, 10**6)
                    ss += [x for x in (s0 - d, s0 + d) if 0 <= x <= 1]
            for s in ss:
                w = tuple((1 - s) * U[i] + s * (1 if i == j else 0) for i in range(3))
                K = [tuple((1 - s) * v[i] + s * (1 if i == j else 0) for i in range(3)) for v in V]
                af = advice_field(n, w, g); ak = advice_K(K, g)
                checks += 1
                if af == 'TIE': ties += 1
                elif af != ak:
                    bad_leg += 1
                    if bad_leg <= 3: out.write(f"  MISMATCH eps={eps} g={g} leg={j} s={s} field={af} K={ak}\n")
                if s == 0 and af != advice_K(V, g): bad_end += 1
                if s == 1:
                    exp = 'M' if g[j] > 0 else 'O'
                    if af != exp: bad_end += 1
    out.write(f"eps={eps}: pairs={N}, leg checks={checks}, sign-pattern failures={bad_sign}, "
              f"leg mismatches={bad_leg}, Bayes ties hit={ties}, endpoint failures={bad_end}\n")

if __name__ == '__main__':
    rng = random.Random(20261017)
    out = sys.stdout
    for eps in (Fr(1, 20), Fr(1, 10), Fr(3, 10), Fr(1, 2), Fr(4, 5)):
        run(eps, 1500, rng, out)
