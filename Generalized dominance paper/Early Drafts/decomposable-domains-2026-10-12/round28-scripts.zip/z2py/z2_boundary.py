"""Z2 Theorem Z2.3 (boundary field): one strictly guiding additive field on the full
domain whose Bayes model is (i) T1, a.e. uniquely, at u, and (ii) coherent, edge-supported,
a.e. unique at every weight of the boundary of the simplex.  Exact rational checks.

Edge switching function s (the same on every ordered edge (i,j), i positive, j negative):
  S_low(v) = (2+lam) v / 2                    on [0, 1/(2+lam)]
  S(v)     = S_low(v)                          on [0, 1/(2+lam)]
           = 1 - S_low(1 - A v)                on [1/(2+lam), 1/A]
           = A v                               on [1/A, oo)
  s(x)     = 1 / S(1/x)    (so s(x) = x/A on (0, A]).
Field: for mixed g, m_i/m_j = s(g_i/|g_j|) / (g_i/|g_j|) whenever g_i > 0 > g_j; n = m (.) g.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from z2common import *

def make(eps):
    eps, c0, lam, A = params(eps)
    b = 1 / (2 + lam)
    def Slow(v): return (2 + lam) * v / 2
    def S(v):
        if v <= b: return Slow(v)
        if v <= 1 / A: return 1 - Slow(1 - A * v)
        return A * v
    def Sinv(y):
        if y <= Fr(1, 2): return 2 * y / (2 + lam)
        if y <= 1: return (1 - 2 * (1 - y) / (2 + lam)) / A
        return y / A
    def s(x): return 1 / S(1 / x)
    def sinv(r): return 1 / Sinv(1 / r)
    def n(g):
        pos = [i for i in range(3) if g[i] > 0]; neg = [i for i in range(3) if g[i] < 0]
        if not pos or not neg: return g
        m = [None] * 3
        if len(pos) == 1:
            i = pos[0]; m[i] = Fr(1)
            for j in neg:
                x = g[i] / -g[j]; m[j] = x / s(x)        # m_i/m_j = s(x)/x
        else:
            j = neg[0]; m[j] = Fr(1)
            for i in pos:
                x = g[i] / -g[j]; m[i] = s(x) / x
        M = max(m)
        return tuple(m[k] / M * g[k] for k in range(3))
    def edge_K(i, j, wi, wj):
        """credal segment of the edge Bayes model at weight (w_i, w_j) on edge {i,j}"""
        r = wj / wi
        rho_hi = sinv(r); rho_lo = 1 / sinv(1 / r)
        def pt(rho):
            v = [Fr(0)] * 3; v[i] = 1 / (1 + rho); v[j] = rho / (1 + rho); return tuple(v)
        return [pt(rho_lo), pt(rho_hi)], rho_lo, rho_hi
    return dict(S=S, Sinv=Sinv, s=s, sinv=sinv, n=n, edge_K=edge_K, lam=lam, A=A)

def run(eps, N, rng, out):
    F = make(eps); n = F['n']; V = T1_vertices(eps); A = F['A']; lam = F['lam']
    # (0) the switching function: inverse, monotone, and the product condition s(x)s(1/x) <= 1
    badS = 0; badprod = 0
    xs = [Fr(rng.randint(1, 10**4), rng.randint(1, 10**4)) for _ in range(400)]
    xs += [A, 1 / A, 2 + lam, 1 / (2 + lam), Fr(1)]
    for x in xs:
        if F['sinv'](F['s'](x)) != x: badS += 1
        if F['s'](x) * F['s'](1 / x) > 1: badprod += 1
    for x, y in zip(sorted(xs), sorted(xs)[1:]):
        if x < y and not F['s'](x) < F['s'](y): badS += 1
    # (1) sign pattern; (2) u-Bayes = T1
    bad_sign = 0; bad_u = 0; ties_u = 0
    for t in range(N):
        g = rand_gamble(rng)
        if t % 2:
            P0 = P(V, g); d0 = Fr(rng.choice([-3, -2, -1, 1, 2, 3]), 10**5)
            g = tuple(x - P0 + d0 for x in g)
            if any(x == 0 for x in g): continue
        for h in (g, tuple(-x for x in g)):
            if any(sgn(n(h)[i]) != sgn(h[i]) for i in range(3)): bad_sign += 1
        af = advice_field(n, U, g)
        if af == 'TIE': ties_u += 1
        elif af != advice_K(V, g): bad_u += 1
    # (3) edges: Bayes = D_{K(w)} with K(w) the explicit credal segment; vertices = E_k
    bad_edge = 0; ties_e = 0; checks = 0; bad_vertex = 0
    for t in range(N):
        i, j = rng.sample(range(3), 2)
        th = Fr(rng.randint(1, 999), 1000)
        w = [Fr(0)] * 3; w[i] = 1 - th; w[j] = th; w = tuple(w)
        K, lo, hi = F['edge_K'](i, j, w[i], w[j])
        assert lo <= hi
        for k in range(4):
            g = rand_gamble(rng)
            if k >= 2:   # near this edge model's switching ratios
                rho = hi if k == 2 else 1 / lo
                gj = -abs(g[j]); gi = rho * abs(gj) * (1 + Fr(rng.choice([-1, 1]), 10**5))
                g = tuple(gi if q == i else (gj if q == j else g[q]) for q in range(3))
                if rng.random() < 0.5: g = tuple(-x for x in g)
            af = advice_field(n, w, g); checks += 1
            if af == 'TIE': ties_e += 1
            elif af != advice_K(K, g): bad_edge += 1
    for k in range(3):
        for t in range(200):
            g = rand_gamble(rng)
            if advice_field(n, E(k), g) != ('M' if g[k] > 0 else 'O'): bad_vertex += 1
    out.write(f"eps={eps}: s-inverse/monotone failures={badS}, product-condition failures={badprod}; "
              f"sign-pattern failures={bad_sign}; u-Bayes vs T1 mismatches={bad_u} (ties {ties_u}); "
              f"edge checks={checks}, edge mismatches={bad_edge} (ties {ties_e}); vertex failures={bad_vertex}\n")

if __name__ == '__main__':
    rng = random.Random(1017)
    for eps in (Fr(1, 20), Fr(1, 10), Fr(3, 10), Fr(1, 2), Fr(4, 5)):
        run(eps, 3000, rng, sys.stdout)
