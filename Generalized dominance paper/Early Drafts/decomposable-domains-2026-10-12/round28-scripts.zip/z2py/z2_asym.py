"""NUMERICS for Z2 section 5: a non-symmetric boundary field designed so that the first-order
conditions for a leg from u toward e3 hold.  Six edge functions S_ij on [0,b] (pattern (i|j,k)):
  S_12 = S_21 = 1 - (1 - c1 z)^(1/c1)   with S(b) = 1-b      [T=(1-S)/S' affine]
  S_13 = S_23 = z                                             [linear, slope 1]
  S_31 = S_32 = -log(1 - c3 z)/c3        with S(b) = 1/2      [1/S' affine]
extended by E2 on [b,1/A] and by A v on [1/A, oo); s_ij(x) = 1/S_ij(1/x) (= x/A on (0,A]).
Checks: product condition on edges, u-Bayes = T1 (float), coherence along legs."""
import sys, os, numpy as np
from scipy.optimize import brentq
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def build(eps, design='e3'):
    c0 = (1 - eps) / 3; lam = eps / c0; A = 1 + lam; b = 1 / (2 + lam)
    c1 = brentq(lambda c: (1 - c * b) ** (1 / c) - b, 1e-9, 1 / b - 1e-12)
    c3 = brentq(lambda c: -np.log(1 - c * b) / c - 0.5, 1e-9, 1 / b - 1e-12)
    fA = lambda z: 1 - (1 - c1 * np.clip(z, 0, b)) ** (1 / c1)
    fL = lambda z: np.clip(z, 0, b)
    fG = lambda z: -np.log(1 - c3 * np.clip(z, 0, b)) / c3
    if design == 'e3':
        low = {(0, 1): fA, (1, 0): fA, (0, 2): fL, (1, 2): fL, (2, 0): fG, (2, 1): fG}
    else:  # symmetric linear control (the Z2.3 field)
        fS = lambda z: (2 + lam) / 2 * np.clip(z, 0, b)
        low = {k: fS for k in [(0, 1), (1, 0), (0, 2), (1, 2), (2, 0), (2, 1)]}
    def S(i, j, v):
        k = 3 - i - j; v = np.asarray(v, float)
        return np.where(v <= b, low[(i, j)](v), np.where(v <= 1 / A, 1 - low[(i, k)](1 - A * v), A * v))
    def s(i, j, x): return 1.0 / S(i, j, 1.0 / np.asarray(x, float))
    return S, s, A, lam, b, (c1, c3)

def field(G, s):
    G = np.asarray(G, float); N = G.shape[0]; M = np.ones((N, 3)); npos = (G > 0).sum(1)
    for i in range(3):
        for j in range(3):
            if i == j: continue
            mask = (G[:, i] > 0) & (G[:, j] < 0)
            x = np.where(mask, G[:, i] / np.where(mask, -G[:, j], 1), 1.0)
            r = s(i, j, x) / x
            M[mask & (npos == 1), j] = 1 / r[mask & (npos == 1)]
            M[mask & (npos == 2), i] = r[mask & (npos == 2)]
    M = M / M.max(1, keepdims=True)
    return M * G

def make_f(s):
    return lambda w, G: field(G, s) @ np.asarray(w, float) / np.linalg.norm(np.asarray(G, float), axis=1)

def incoherence(w, f, rng, npts=5000, tmin=0.003, tmax=0.12):
    X = rng.normal(size=(4 * npts, 3)); X /= np.linalg.norm(X, axis=1, keepdims=True)
    fx = f(w, X); acc = X[fx > 0]; rej = X[fx <= 0]; m = min(len(acc), len(rej), npts)
    a = acc[:m].copy(); r = rej[rng.permutation(len(rej))[:m]].copy()
    keep = np.einsum('ij,ij->i', a, r) > -0.95; a, r = a[keep], r[keep]
    for _ in range(45):
        mid = a + r; mid /= np.linalg.norm(mid, axis=1, keepdims=True); fm = f(w, mid)
        a = np.where((fm > 0)[:, None], mid, a); r = np.where((fm > 0)[:, None], r, mid)
    B = a[:3000]; C = B @ B.T
    I, J = np.where(np.triu((C < np.cos(tmin)) & (C > np.cos(tmax)), 1))
    if len(I) > 80000:
        sel = rng.choice(len(I), 80000, replace=False); I, J = I[sel], J[sel]
    mid = B[I] + B[J]; mid /= np.linalg.norm(mid, axis=1, keepdims=True); fm = f(w, mid)
    Y = rng.normal(size=(20000, 3)); both = ((f(w, Y) > 0) & (f(w, -Y) > 0)).sum()
    return int((fm < -1e-8).sum()), int(both), float(fm.min())

if __name__ == '__main__':
    rng = np.random.default_rng(17)
    for eps in (0.1, 0.3, 0.6):
        for design in ('e3', 'sym'):
            S, s, A, lam, b, cs = build(eps, design); f = make_f(s)
            # edge product condition s_ij(x) s_ji(1/x) <= 1
            xs = np.exp(np.linspace(-8, 8, 4001)); worst = 0
            for i in range(3):
                for j in range(3):
                    if i != j: worst = max(worst, float((s(i, j, xs) * s(j, i, 1 / xs)).max()))
            # u-Bayes vs T1
            G = rng.normal(size=(200000, 3)); V = np.array([[c + (eps if a == k else 0) for a in range(3)] for k in range(3)]) if False else None
            c0 = (1 - eps) / 3
            Vt = np.array([[c0 + (eps if a == k else 0) for a in range(3)] for k in range(3)])
            PT = (G @ Vt.T).min(1); fu = f([1/3]*3, G)
            mism = int(((PT > 1e-9) != (fu > 1e-12)).sum() - ((np.abs(PT) < 1e-6)).sum() * 0)
            print(f"eps={eps} design={design} (c1,c3)={tuple(round(c,4) for c in cs)}: max edge product={worst:.6f}; "
                  f"u-Bayes vs T1 sign mismatches={mism} / {len(G)}")
            for tn, tg in (("e3", [0, 0, 1.]), ("e1", [1., 0, 0]), ("mid12", [.5, .5, 0])):
                row = []
                for t in (0.001, 0.004, 0.01, 0.03, 0.1, 0.3):
                    w = (1 - t) * np.array([1/3]*3) + t * np.array(tg)
                    v, bo, mn = incoherence(w, f, rng)
                    row.append(f"{t}:{'ok' if v == 0 and bo == 0 else f'X({v},{mn:.1e})'}")
                print(f"     leg -> {tn:5s}: " + "  ".join(row))
