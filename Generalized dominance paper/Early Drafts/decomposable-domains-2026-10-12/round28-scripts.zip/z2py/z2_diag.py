"""NUMERICS: locate the non-convexity of the boundary field's Bayes cone near u."""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from z2_scan import make_s, boundary_points, f
rng = np.random.default_rng(3)
eps = 0.3; s, A, lam = make_s(eps)
for ang in (0, 60, 90, 180, 270):
    a = np.radians(ang); r = 0.01
    d = r * (np.cos(a) * np.array([1, -1, 0]) / np.sqrt(2) + np.sin(a) * np.array([1, 1, -2]) / np.sqrt(6))
    w = np.array([1/3]*3) + d
    B = boundary_points(w, s, rng, 6000); B = B[:3000]
    C = B @ B.T
    I, J = np.where(np.triu((C < np.cos(0.003)) & (C > np.cos(0.1)), 1))
    mid = B[I] + B[J]; mid /= np.linalg.norm(mid, axis=1, keepdims=True)
    fm = f(w, mid, s); bad = fm < -1e-7
    print(f"angle {ang}: w={np.round(w,4)}, violations {bad.sum()} of {len(fm)}")
    if bad.sum():
        V = mid[bad]
        pats = {}
        for v in V:
            key = ''.join('+' if x > 0 else '-' for x in v)
            pats[key] = pats.get(key, 0) + 1
        print("   sign patterns of violating midpoints:", pats)
        # describe ratios for the worst few
        idx = np.argsort(fm[bad])[:4]
        for k in idx:
            v = V[k]; neg = [i for i in range(3) if v[i] < 0]; pos = [i for i in range(3) if v[i] > 0]
            if len(neg) == 1:
                j = neg[0]; print("   two-positive, ratios g_i/|g_j|:", {i: round(v[i]/-v[j], 4) for i in pos}, "f=", fm[bad][k])
            else:
                i = pos[0]; print("   one-positive, ratios |g_j|/g_i:", {j: round(-v[j]/v[i], 4) for j in neg}, "f=", fm[bad][k])
print("A =", A, " 1/A =", 1/A, " 2+lam =", 2+lam)
