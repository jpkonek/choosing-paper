"""NUMERICS: locate the first-order non-convexity of the e3-designed field along the e3 leg."""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from z2_asym import build, make_f
rng = np.random.default_rng(2)
eps = 0.3
S, s, A, lam, b, cs = build(eps, 'e3'); f = make_f(s)
print("A=", A, "1/A=", 1/A, "b=", b)
for t in (0.01, 0.003):
    w = (1-t)*np.array([1/3]*3) + t*np.array([0,0,1.])
    X = rng.normal(size=(40000,3)); X /= np.linalg.norm(X,axis=1,keepdims=True)
    fx = f(w,X); a = X[fx>0][:12000]; r = X[fx<=0][rng.permutation((fx<=0).sum())[:len(X[fx>0][:12000])]]
    keep = np.einsum('ij,ij->i',a,r) > -0.95; a, r = a[keep], r[keep]
    for _ in range(45):
        m = a+r; m/=np.linalg.norm(m,axis=1,keepdims=True); fm=f(w,m)
        a=np.where((fm>0)[:,None],m,a); r=np.where((fm>0)[:,None],r,m)
    B=a[:5000]; C=B@B.T
    I,J=np.where(np.triu((C<np.cos(0.002))&(C>np.cos(0.05)),1))
    mid=B[I]+B[J]; mid/=np.linalg.norm(mid,axis=1,keepdims=True); fm=f(w,mid); bad=fm<-1e-8
    print(f"t={t}: violations {bad.sum()} / {len(fm)}")
    # cluster worst violations by normalized representation
    order=np.argsort(fm)[:400]
    reps={}
    for k in order:
        v=mid[k]; neg=[i for i in range(3) if v[i]<0]; pos=[i for i in range(3) if v[i]>0]
        if len(neg)==1:
            j=neg[0]; key=('two-pos', j, tuple(int(np.round(v[i]/-v[j]*20)) for i in pos))
        else:
            i=pos[0]; key=('one-pos', i, tuple(int(np.round(-v[j]/v[i]*20)) for j in neg))
        reps[key]=reps.get(key,0)+1
    for key,cnt in sorted(reps.items(), key=lambda x:-x[1])[:10]:
        print("   ", key, "(ratios x20)", cnt)
    # also the endpoints of the worst pair
    k=order[0]; print("   worst pair endpoints:", np.round(B[I[k]]/np.abs(B[I[k]]).max(),4), np.round(B[J[k]]/np.abs(B[J[k]]).max(),4), "f(mid)=",fm[k])
