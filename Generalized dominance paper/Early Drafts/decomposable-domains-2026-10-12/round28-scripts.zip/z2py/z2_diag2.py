"""NUMERICS: where and how strongly the C^1-matched boundary field (S_low'(0)=1) fails near u."""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import z2_scan as Z
from z2_leg import make_s_general
rng = np.random.default_rng(8)
eps = 0.3; c0 = (1-eps)/3; lam = eps/c0; b = 1/(2+lam)
for k0 in (1.0, (2+lam)/2):
    beta = (0.5 - k0*b)/b**2
    s, A, _, _ = make_s_general(eps, lambda v: k0*v + beta*v**2)
    print(f"k0={k0:.4f} (beta={beta:.4f})")
    for t in (0.04, 0.02, 0.01, 0.005):
        for tn, tg in (("e3", np.array([0,0,1.])), ("mid12", np.array([.5,.5,0]))):
            w = (1-t)*np.array([1/3]*3) + t*tg
            B = Z.boundary_points(w, s, rng, 8000)[:3500]
            C = B @ B.T
            I, J = np.where(np.triu((C < np.cos(0.002)) & (C > np.cos(0.08)), 1))
            mid = B[I]+B[J]; mid /= np.linalg.norm(mid, axis=1, keepdims=True)
            fm = Z.f(w, mid, s); bad = fm < -1e-9
            pats = {}
            for v in mid[bad]:
                key = ''.join('+' if x > 0 else '-' for x in v); pats[key] = pats.get(key, 0)+1
            k = np.argmin(fm)
            print(f"   t={t:<6} ->{tn:5s}: viol={bad.sum():5d}  min f={fm.min():.2e}  worst midpoint={np.round(mid[k]/np.abs(mid[k]).max(),3)}  pats={pats}")
