"""NUMERICS (support for Thm Z2.6 hypotheses on the boundary field): fraction of sampled pairs on which
the w-Bayes advice differs from T1, over a grid of w; it vanishes only at u."""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from z2_scan import make_s, field
rng = np.random.default_rng(4)
for eps in (0.1, 0.3, 0.6):
    s, A, lam = make_s(eps); c0 = (1-eps)/3
    Vt = np.array([[c0+(eps if a==k else 0) for a in range(3)] for k in range(3)])
    G = rng.normal(size=(60000,3)); T1acc = (G@Vt.T).min(1) > 0
    n = field(G, s); best = []
    step = 30
    for i in range(step+1):
        for j in range(step+1-i):
            w = np.array([i, j, step-i-j])/step
            d = ((n@w > 0) != T1acc).mean()
            best.append((d, tuple(np.round(w,3))))
    best.sort()
    print(f"eps={eps}: smallest disagreement fractions with T1 over a {step}-grid:", [(round(a,5), b) for a,b in best[:3]])
