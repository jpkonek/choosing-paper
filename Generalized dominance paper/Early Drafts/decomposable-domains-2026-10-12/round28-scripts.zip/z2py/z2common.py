"""Common exact-arithmetic helpers for note Z2.
Worlds are indexed 0,1,2 in code (= 1,2,3 in the note)."""
from fractions import Fraction as Fr
import random

def params(eps):
    eps = Fr(eps)
    c0 = (1 - eps) / 3
    lam = eps / c0
    A = 1 + lam
    return eps, c0, lam, A

def dot(a, b): return sum(x * y for x, y in zip(a, b))
def had(a, b): return tuple(x * y for x, y in zip(a, b))
def sgn(x): return (x > 0) - (x < 0)
def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def E(j):
    return tuple(Fr(1) if i == j else Fr(0) for i in range(3))
U = (Fr(1, 3),) * 3

def T1_vertices(eps):
    eps, c0, lam, A = params(eps)
    return [tuple(c0 + (eps if j == k else 0) for j in range(3)) for k in range(3)]

def P(K, g):
    return min(dot(k, g) for k in K)

def advice_K(K, h):
    """advice of D_K on the pair {h,-h}: 'M' (accept h), 'O' (accept -h), 'S'.
    Unanimous gambles: D_K accepts nonnegative nonzero gambles."""
    if all(x >= 0 for x in h) and any(x > 0 for x in h): return 'M'
    if all(x <= 0 for x in h) and any(x < 0 for x in h): return 'O'
    a, b = P(K, h) > 0, P(K, tuple(-x for x in h)) > 0
    assert not (a and b)
    return 'M' if a else ('O' if b else 'S')

def advice_field(n, w, h):
    """Bayes advice at weight w of the additive field with acceptance vectors n(.)
    (loss: S=0, M=-n(h), O=-n(-h), contradictory = large)."""
    a1 = dot(w, n(h)); a2 = dot(w, n(tuple(-x for x in h)))
    if a1 > 0 and a1 > a2: return 'M'
    if a2 > 0 and a2 > a1: return 'O'
    if a1 <= 0 and a2 <= 0: return 'S'
    return 'TIE'

def rand_rat(rng, lo=-1, hi=1, den=997):
    return Fr(rng.randint(int(lo * den), int(hi * den)), den)

def rand_gamble(rng, den=997):
    while True:
        g = tuple(rand_rat(rng, den=den) for _ in range(3))
        if all(x != 0 for x in g): return g

def rand_simplex(rng, den=1000):
    p = [Fr(rng.randint(1, den)) for _ in range(3)]
    s = sum(p)
    return tuple(x / s for x in p)
