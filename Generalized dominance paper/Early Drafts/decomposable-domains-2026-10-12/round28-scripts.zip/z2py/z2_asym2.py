"""NUMERICS for Z2 section 5: second design of a non-symmetric boundary field for a leg u -> e3.
Conditions imposed (first-order analysis of section 5):
 (J0) S_ik'(0) <= 1                         (convex junction kink at 1/A)
 (Kb) S_ij'(b)/S_ik'(b) in [1/A, A]          (T1's corner splits into two convex corners)
 (Curv, direction e3) S_13,S_23: (S/S')'' >= 0;  S_12,S_21: ((1-S)/S')'' >= 0;  S_31,S_32: (1/S')'' <= 0.
Design: S_13 = S_23 = z;  S_12 = S_21 from a convex piecewise-linear T = (1-S)/S' with S(b) = 1-b,
S'(b) = b/T(b) in [1/A, A];  S_31 = S_32 = atanh(sqrt(c) z)/sqrt(c) with S(b) = 1/2."""
import sys, os, numpy as np
from scipy.optimize import brentq
from scipy.integrate import solve_ivp
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from z2_asym import field, make_f, incoherence

def design(eps, Tb_factor=1.5, z1_frac=0.5, slack0=1.0):
    c0 = (1 - eps) / 3; lam = eps / c0; A = 1 + lam; b = 1 / (2 + lam)
    Tb = Tb_factor * b / A; z1 = z1_frac * b; T0 = 1.0 / slack0       # S'(0) = 1/T0 = slack0
    def make_T(tau):
        def T(z):
            z = np.asarray(z, float)
            return np.where(z <= z1, T0 + (tau - T0) * z / z1, tau + (Tb - tau) * (z - z1) / (b - z1))
        return T
    def integral(tau):
        T = make_T(tau); zz = np.linspace(0, b, 20001); return np.trapezoid(1 / T(zz), zz)
    tau = brentq(lambda t: integral(t) + np.log(b), 1e-6, min(T0, Tb) - 1e-9)
    T = make_T(tau)
    zz = np.linspace(0, b, 20001); cum = np.concatenate([[0], np.cumsum((1 / T(zz[1:]) + 1 / T(zz[:-1])) / 2 * np.diff(zz))])
    S12_tab = 1 - np.exp(-cum)                        # 1 - S = exp(-int 1/T)
    fA = lambda z: np.interp(np.clip(z, 0, b), zz, S12_tab)
    fL = lambda z: slack0 * np.clip(z, 0, b) if slack0 * b <= b else np.clip(z, 0, b)
    fL = lambda z: np.clip(z, 0, b)
    c = brentq(lambda c: np.arctanh(np.sqrt(c) * b) / np.sqrt(c) - 0.5, 1e-9, 1 / b**2 - 1e-12)
    fG = lambda z: np.arctanh(np.sqrt(c) * np.clip(z, 0, b)) / np.sqrt(c)
    low = {(0, 1): fA, (1, 0): fA, (0, 2): fL, (1, 2): fL, (2, 0): fG, (2, 1): fG}
    def S(i, j, v):
        k = 3 - i - j; v = np.asarray(v, float)
        return np.where(v <= b, low[(i, j)](v), np.where(v <= 1 / A, 1 - low[(i, k)](1 - A * v), A * v))
    def s(i, j, x): return 1.0 / S(i, j, 1.0 / np.asarray(x, float))
    info = dict(tau=tau, S12b=float(fA(b)), S12pb=float(b / Tb), c=c, A=A, b=b)
    return S, s, info

if __name__ == '__main__':
    rng = np.random.default_rng(23)
    for eps in (0.1, 0.3, 0.6):
        S, s, info = design(eps); f = make_f(s); A = info['A']
        xs = np.exp(np.linspace(-8, 8, 4001)); worst = 0
        for i in range(3):
            for j in range(3):
                if i != j: worst = max(worst, float((s(i, j, xs) * s(j, i, 1 / xs)).max()))
        c0 = (1 - eps) / 3; Vt = np.array([[c0 + (eps if a == k else 0) for a in range(3)] for k in range(3)])
        G = rng.normal(size=(200000, 3)); PT = (G @ Vt.T).min(1); fu = f([1/3]*3, G)
        mism = int(((PT > 0) != (fu > 0)).sum())
        print(f"eps={eps}: info={ {k: round(v, 4) for k, v in info.items()} }; max edge product={worst:.4f}; u-Bayes vs T1 mismatches={mism}")
        for tn, tg in (("e3", [0, 0, 1.]), ("e1", [1., 0, 0]), ("mid12", [.5, .5, 0])):
            row = []
            for t in (0.0005, 0.002, 0.005, 0.01, 0.03, 0.1, 0.3, 0.6):
                w = (1 - t) * np.array([1/3]*3) + t * np.array(tg)
                v, bo, mn = incoherence(w, f, rng)
                row.append(f"{t}:{'ok' if v == 0 and bo == 0 else f'X{v}({mn:.0e})'}")
            print(f"     leg -> {tn:5s}: " + " ".join(row))
