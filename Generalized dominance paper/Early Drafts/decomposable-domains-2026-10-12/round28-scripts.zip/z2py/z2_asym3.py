"""NUMERICS for Z2 section 5: third design (all junction slopes strictly < 1) for a leg u -> e3.
S_13 = S_23 = a13*z (a13<1); S_12 = S_21 from convex piecewise-linear T=(1-S)/S' with T(0)=1/a12 > 1,
S(b) = 1 - a13*b, S'(b) = (a13 b)/T(b) <= A*a13; S_31 = S_32: 1/S' = (1/a3)(1 - c z^2), S(b)=1/2."""
import sys, os, numpy as np
from scipy.optimize import brentq
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from z2_asym import make_f, incoherence

def design3(eps, a12=0.8, a13=0.9, a3=0.9, Tb_factor=1.3, z1_frac=0.5):
    c0 = (1-eps)/3; lam = eps/c0; A = 1+lam; b = 1/(2+lam)
    S13b = a13*b; target = 1 - S13b                     # S_12(b)
    Tb = Tb_factor * S13b / (A*a13)                       # => S_12'(b) = S13b/Tb = A a13 / Tb_factor
    T0 = 1/a12; z1 = z1_frac*b
    def make_T(tau):
        return lambda z: np.where(z <= z1, T0 + (tau-T0)*z/z1, tau + (Tb-tau)*(z-z1)/(b-z1))
    zz = np.linspace(0, b, 40001)
    def integ(tau):
        T = make_T(tau); return np.trapezoid(1/T(zz), zz)
    tau = brentq(lambda t: integ(t) + np.log(1-target), 1e-7, min(T0, Tb)-1e-9)
    T = make_T(tau); g = 1/T(zz)
    cum = np.concatenate([[0], np.cumsum((g[1:]+g[:-1])/2*np.diff(zz))]); S12 = 1-np.exp(-cum)
    fA = lambda z: np.interp(np.clip(z, 0, b), zz, S12)
    fL = lambda z: a13*np.clip(z, 0, b)
    # 1/S' = (1/a3)(1 - c z^2)  =>  S = a3 * atanh(sqrt(c) z)/sqrt(c)
    c = brentq(lambda c: a3*np.arctanh(np.sqrt(c)*b)/np.sqrt(c) - 0.5, 1e-9, 1/b**2 - 1e-12)
    fG = lambda z: a3*np.arctanh(np.sqrt(c)*np.clip(z, 0, b))/np.sqrt(c)
    low = {(0,1): fA, (1,0): fA, (0,2): fL, (1,2): fL, (2,0): fG, (2,1): fG}
    def S(i, j, v):
        k = 3-i-j; v = np.asarray(v, float)
        return np.where(v <= b, low[(i,j)](v), np.where(v <= 1/A, 1 - low[(i,k)](1-A*v), A*v))
    def s(i, j, x): return 1.0/S(i, j, 1.0/np.asarray(x, float))
    return s, dict(tau=tau, c=c, S12pb=S13b/Tb, A=A, b=b, slopeKb=(S13b/Tb)/a13)

if __name__ == '__main__':
    rng = np.random.default_rng(31)
    for eps in (0.1, 0.3):
        for pars in (dict(), dict(a12=0.6, a13=0.8, a3=0.8), dict(a12=0.9, a13=0.97, a3=0.97, Tb_factor=1.1)):
            try:
                s, info = design3(eps, **pars)
            except ValueError as e:
                print(f"eps={eps} {pars}: infeasible parameters ({e})"); continue
            f = make_f(s)
            xs = np.exp(np.linspace(-8, 8, 4001)); worst = max(float((s(i,j,xs)*s(j,i,1/xs)).max()) for i in range(3) for j in range(3) if i != j)
            c0=(1-eps)/3; Vt=np.array([[c0+(eps if a==k else 0) for a in range(3)] for k in range(3)])
            G=rng.normal(size=(100000,3)); mism=int((((G@Vt.T).min(1)>0)!=(f([1/3]*3,G)>0)).sum())
            print(f"eps={eps} {pars}: info={ {k: round(v,4) for k,v in info.items()} } edge-product={worst:.3f} T1-mismatch={mism}")
            row=[]
            for t in (0.0005, 0.002, 0.005, 0.01, 0.03):
                w=(1-t)*np.array([1/3]*3)+t*np.array([0,0,1.])
                v,bo,mn=incoherence(w,f,rng); row.append(f"{t}:{'ok' if v==0 and bo==0 else f'X{v}({mn:.0e})'}")
            print("     leg -> e3: "+" ".join(row))
