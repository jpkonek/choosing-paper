"""NUMERICS: coherence of the boundary field's Bayes models on small circles around u."""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from z2_scan import make_s, incoherence
rng = np.random.default_rng(11)
for eps in (0.1, 0.3, 0.6):
    s, A, lam = make_s(eps)
    print(f"eps={eps}")
    for r in (0.05, 0.01, 0.002):
        row = []
        for k in range(24):
            ang = 2 * np.pi * k / 24
            d = r * (np.cos(ang) * np.array([1, -1, 0]) / np.sqrt(2) + np.sin(ang) * np.array([1, 1, -2]) / np.sqrt(6))
            w = np.array([1/3, 1/3, 1/3]) + d
            v, b, m = incoherence(w, s, rng)
            row.append("." if v == 0 and b == 0 else "X")
        print(f"  r={r}: directions 0..345 deg step 15: {''.join(row)}")
