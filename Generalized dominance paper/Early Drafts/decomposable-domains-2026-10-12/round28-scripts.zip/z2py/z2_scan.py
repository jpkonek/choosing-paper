"""NUMERICS for Z2 section 5: coherence map of the Bayes models of the boundary field
of z2_boundary.py (and of variants) at interior weights.  Float arithmetic.
A weight w is flagged incoherent if the accepted cone A_w = {g : w.n(g) > 0} is not convex
(midpoint of two nearby boundary points strictly outside) or contains some g and -g."""
import sys, numpy as np

def make_s(eps, Slow_slope=None):
    c0 = (1 - eps) / 3; lam = eps / c0; A = 1 + lam
    b = 1 / (2 + lam); k = (2 + lam) / 2 if Slow_slope is None else Slow_slope
    def S(v):
        v = np.asarray(v, float)
        out = np.where(v <= b, k * v, np.where(v <= 1 / A, 1 - k * (1 - A * v), A * v))
        return out
    def s(x): return 1.0 / S(1.0 / x)
    return s, A, lam

def field(G, s, sym=True):
    """vectorised acceptance vectors n(g) for rows of G (mixed or not)"""
    G = np.asarray(G, float); N = G.shape[0]
    M = np.ones((N, 3))
    pos = G > 0; npos = pos.sum(1)
    for i in range(3):
        for j in range(3):
            if i == j: continue
            mask = (G[:, i] > 0) & (G[:, j] < 0)
            x = np.where(mask, G[:, i] / np.where(mask, -G[:, j], 1), 1.0)
            r = s(x) / x                                  # m_i / m_j
            one_pos = mask & (npos == 1)                  # i is the single positive: m_i=1, m_j = 1/r
            M[one_pos, j] = 1 / r[one_pos]
            two_pos = mask & (npos == 2)                  # j is the single negative: m_j=1, m_i = r
            M[two_pos, i] = r[two_pos]
    M = M / M.max(1, keepdims=True)
    return M * G

def f(w, G, s):
    G = np.asarray(G, float)
    return field(G, s) @ np.asarray(w, float) / np.linalg.norm(G, axis=1)

def boundary_points(w, s, rng, n=6000, iters=45):
    X = rng.normal(size=(4 * n, 3)); X /= np.linalg.norm(X, axis=1, keepdims=True)
    fx = f(w, X, s)
    acc = X[fx > 0]; rej = X[fx <= 0]
    m = min(len(acc), len(rej), n)
    a = acc[:m].copy(); r = rej[rng.permutation(len(rej))[:m]].copy()
    # avoid antipodal pairs
    keep = np.einsum('ij,ij->i', a, r) > -0.95; a, r = a[keep], r[keep]
    for _ in range(iters):
        mid = a + r; mid /= np.linalg.norm(mid, axis=1, keepdims=True)
        fm = f(w, mid, s)
        a = np.where((fm > 0)[:, None], mid, a); r = np.where((fm > 0)[:, None], r, mid)
    return a   # accepted side, within ~1e-13 of the boundary

def incoherence(w, s, rng, npts=4000, tmin=0.005, tmax=0.15):
    B = boundary_points(w, s, rng, npts)
    B = B[rng.permutation(len(B))[:2500]]
    C = B @ B.T
    I, J = np.where(np.triu((C < np.cos(tmin)) & (C > np.cos(tmax)), 1))
    if len(I) > 60000:
        sel = rng.choice(len(I), 60000, replace=False); I, J = I[sel], J[sel]
    mid = B[I] + B[J]; mid /= np.linalg.norm(mid, axis=1, keepdims=True)
    fm = f(w, mid, s)
    viol = (fm < -1e-7).sum()
    # two-sidedness: g and -g both accepted
    X = rng.normal(size=(20000, 3))
    both = ((f(w, X, s) > 0) & (f(w, -X, s) > 0)).sum()
    return int(viol), int(both), float(fm.min()) if len(fm) else 0.0

if __name__ == '__main__':
    rng = np.random.default_rng(7)
    eps = float(sys.argv[1]) if len(sys.argv) > 1 else 0.3
    step = int(sys.argv[2]) if len(sys.argv) > 2 else 12
    s, A, lam = make_s(eps)
    print(f"eps={eps}, A={A:.4f}: coherence map of Bayes models of the boundary field")
    print("controls: u, edge points, vertex")
    for w in ([1/3, 1/3, 1/3], [0.5, 0.5, 0.0], [0.2, 0.0, 0.8], [1, 0, 0]):
        print("  w=", w, "viol, both, min f(mid) =", incoherence(np.array(w), s, rng))
    print(f"grid (rows: w1 = i/{step}, cols: w2 = j/{step}); '.' coherent, 'X' incoherent, 'u' center")
    for i in range(step, -1, -1):
        row = ""
        for j in range(0, step - i + 1):
            w = np.array([i, j, step - i - j], float) / step
            v, bth, _ = incoherence(w, s, rng)
            row += ("." if v == 0 and bth == 0 else "X")
        print(f"  w1={i:2d}/{step}: " + " " * (step - i) + " ".join(row))
