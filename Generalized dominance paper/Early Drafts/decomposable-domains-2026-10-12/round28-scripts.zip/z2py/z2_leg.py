"""NUMERICS: legs from u for the boundary field family with general S_low.
s(x) = x/A on (0,A] (forced choice up to the antisymmetric freedom), S_low free on [0,b],
b = 1/(2+lam), S_low(0)=0, S_low(b)=1/2 (E2 on the diagonal)."""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import z2_scan as Z

def make_s_general(eps, Slow):
    c0 = (1 - eps) / 3; lam = eps / c0; A = 1 + lam; b = 1 / (2 + lam)
    def S(v):
        v = np.asarray(v, float)
        lo = Slow(np.clip(v, 0, b)); mid = 1 - Slow(np.clip(1 - A * v, 0, b))
        return np.where(v <= b, lo, np.where(v <= 1 / A, mid, A * v))
    def s(x): return 1.0 / S(1.0 / x)
    return s, A, lam, b

if __name__ == '__main__':
    rng = np.random.default_rng(5)
    eps = float(sys.argv[1]) if len(sys.argv) > 1 else 0.3
    c0 = (1 - eps) / 3; lam = eps / c0; b = 1 / (2 + lam)
    fams = {}
    for k0 in (1.5, 1.0, 0.7, 0.4):
        if k0 * b >= 0.5: continue
        beta = (0.5 - k0 * b) / b**2
        fams[f"quad k0={k0}"] = (lambda k0, beta: (lambda v: k0 * v + beta * v**2))(k0, beta)
    fams["linear (2+lam)/2"] = lambda v: (2 + lam) / 2 * v
    targets = {"e3": np.array([0, 0, 1.]), "mid12": np.array([.5, .5, 0]), "e1": np.array([1., 0, 0]),
               "mid23": np.array([0, .5, .5])}
    print(f"eps={eps}; leg points w = (1-t)u + t*target; '.' coherent, 'X' not")
    ts = [0.002, 0.01, 0.03, 0.1, 0.2, 0.4, 0.6, 0.8, 0.95]
    print("   t =", ts)
    for name, Sl in fams.items():
        s, A, lam_, bb = make_s_general(eps, Sl)
        for tn, tg in targets.items():
            row = ""
            for t in ts:
                w = (1 - t) * np.array([1/3]*3) + t * tg
                v, bo, _ = Z.incoherence(w, s, rng)
                row += "." if v == 0 and bo == 0 else "X"
            print(f"  {name:20s} -> {tn:6s}: {row}")
