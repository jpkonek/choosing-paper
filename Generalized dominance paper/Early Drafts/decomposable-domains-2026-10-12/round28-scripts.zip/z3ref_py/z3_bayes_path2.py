"""Z3 referee (NUMERICS): coherence of Bayes(w) for Y3's field Psi^(1), by 2-plane sections.
A cone C is convex iff C ∩ P is convex for every 2-dim linear subspace P.  For random P = span{a,b}
(orthonormal), scan theta on a fine grid; C ∩ P convex iff the accepted angles form one arc of length <= pi.
Report the number of planes (of n) whose section is not convex.  Float arithmetic; grid 7200 angles."""
import numpy as np
rng = np.random.default_rng(3)
def setup(eps):
    c0 = (1-eps)/3; lam = eps/c0; A = 1+lam
    eta = 1/(2*(A+1)); return lam, A, eta
def m_field(G, lam, A, eta):
    # G: (N,3) array of gambles; returns (N,3) m-values
    M = np.maximum(abs(G[:,1]), abs(G[:,2]))
    inwedge = abs(G[:,0]) <= eta*M
    corner = np.ones_like(G); corner[:,1] = np.where(G[:,1] > 0, 1, A); corner[:,2] = np.where(G[:,2] > 0, 1, A)
    k = np.argmin(G, axis=1)       # argmin_k v_k.g = argmin_k g_k
    off = np.ones_like(G); off[np.arange(len(G)), k] += lam
    return np.where(inwedge[:,None], corner, off)
def accepted(w, G, lam, A, eta):
    return (np.all(G >= 0, axis=1)) | ((m_field(G, lam, A, eta)*G) @ w > 0)
def nonconvex_planes(w, lam, A, eta, n=400, grid=7200):
    th = np.linspace(0, 2*np.pi, grid, endpoint=False)
    bad = 0
    for _ in range(n):
        a = rng.normal(size=3); a /= np.linalg.norm(a)
        b = rng.normal(size=3); b -= (b@a)*a; b /= np.linalg.norm(b)
        G = np.cos(th)[:,None]*a + np.sin(th)[:,None]*b
        acc = accepted(w, G, lam, A, eta)
        if acc.all() or not acc.any(): 
            bad += acc.all(); continue
        # count arcs (circular)
        trans = np.sum(acc != np.roll(acc, 1))
        arcs = trans//2
        if arcs > 1 or acc.sum() > grid/2 + 2: bad += 1
    return bad
if __name__ == '__main__':
    for eps in [0.1, 0.5]:
        lam, A, eta = setup(eps); etap = eta/2; s = etap/A
        p0 = np.array([1, s/2, s/2])/(1+s); u = np.ones(3)/3
        print(f"eps={eps}")
        for t in [0, 0.25, 0.5, 0.75, 0.9, 0.99, 1.0]:
            w = (1-t)*p0 + t*u
            print(f"  t={t}: non-convex sections {nonconvex_planes(w, lam, A, eta)} / 400")
        for w in [np.array([.05,.9,.05]), np.array([.25,.5,.25]), np.array([.4,.3,.3]), np.array([.3,.4,.3])]:
            print(f"  w={w}: non-convex sections {nonconvex_planes(w, lam, A, eta)} / 400")
