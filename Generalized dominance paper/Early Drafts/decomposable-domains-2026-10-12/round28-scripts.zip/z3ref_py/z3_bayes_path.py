"""Z3 referee (NUMERICS, exact sign tests): where is the Bayes model of Y3's field Psi^(1) coherent?
Bayes(w) accepts g iff w.(m(g)*g) > 0 (unique a.e. for every w; see Z3 report).  Coherent iff the
accepted set is a.e. a convex cone.  We search for robust midpoint-convexity violations:
g, g' accepted, (g+g')/2 rejected, with margins.  Weights: segment from p0 in N to u, and near e2."""
import sys, os, random
from fractions import Fraction as Fr
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'y3py'))
from y3common import params, dot, had, T1_vertices, box_corner
def field_m(g, eps, eta):
    eps_, c0, lam, A = params(eps)
    M = max(abs(g[1]), abs(g[2]))
    if abs(g[0]) <= eta*M:
        return box_corner([(Fr(1),Fr(1)),(Fr(1),A),(Fr(1),A)], g)
    V = T1_vertices(eps); k = min(range(3), key=lambda k: dot(V[k], g))
    return tuple(1 + (lam if j == k else 0) for j in range(3))
def val(w, g, eps, eta): return dot(w, had(field_m(g, eps, eta), g))
def acc(w, g, eps, eta):
    if all(x >= 0 for x in g): return True
    return val(w, g, eps, eta) > 0
def search(w, eps, eta, rng, n=20000):
    found = 0
    for _ in range(n):
        g = tuple(Fr(rng.randint(-1000,1000),1000) for _ in range(3))
        h = tuple(Fr(rng.randint(-1000,1000),1000) for _ in range(3))
        if acc(w,g,eps,eta) and acc(w,h,eps,eta):
            mid = tuple((a+b)/2 for a,b in zip(g,h))
            if not all(x >= 0 for x in mid) and val(w, mid, eps, eta) < 0:
                found += 1
    return found
rng = random.Random(17)
for eps in [Fr(1,10), Fr(1,2)]:
    _, c0, lam, A = params(eps); eta = 1/(2*(A+1)); etap = eta/2
    s = etap/A                     # boundary of N: (w2+w3)/w1 = eta'/A
    p0 = tuple(x/(1+s) for x in (Fr(1), s/2, s/2))
    u = (Fr(1,3),)*3
    print(f"eps={eps}")
    for t in [Fr(0), Fr(1,4), Fr(1,2), Fr(3,4), Fr(9,10), Fr(99,100), Fr(1)]:
        w = tuple((1-t)*a + t*b for a,b in zip(p0,u))
        print(f"  w = (1-t) p0 + t u, t={t}: convexity violations {search(w,eps,eta,rng)}")
    for w in [(Fr(1,20), Fr(9,10), Fr(1,20)), (Fr(1,100), Fr(98,100), Fr(1,100)), (Fr(1,4), Fr(1,2), Fr(1,4))]:
        print(f"  w = {tuple(map(str,w))}: convexity violations {search(w,eps,eta,rng)}")
