"""Z3 referee (NUMERICS + exact witnesses): audit's counterexample to Y1.1'(i).
p = u, q = (1/2,1/3,1/6): at every world i, C_q is strictly better than C_p on a non-null set and
strictly worse on another (posterior family, X2.6 advice).  Then the reweighting w_i of AUDIT_Y123 §2
gives L_i(C_q) = L_i(C_p) at every world with strictly guiding bounded penalties.
We exhibit exact rational witness gambles (open conditions) for both signs at each world, and Monte-Carlo
estimates of a_i, b_i."""
import sys, os, random
from fractions import Fraction as F
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'y1py'))
from post import lam, advice, rank
import numpy as np
for eps in [F(1,10), F(1,2)]:
    L = lam(eps); p = [F(1,3)]*3; q = [F(1,2), F(1,3), F(1,6)]
    rng = random.Random(5)
    wit = {(i,s): None for i in range(3) for s in (1,-1)}
    a = np.zeros(3); b = np.zeros(3); N = 0
    for _ in range(60000):
        h = [F(rng.randint(-1000,1000), 1000) for _ in range(3)]
        if 0 in h: continue
        neg = [k for k in range(3) if h[k] < 0]
        if len(neg) == 0 or len(neg) == 3: N += 1; continue
        if len(neg) == 2: h = [-x for x in h]
        ap, aq = advice(p, h, L), advice(q, h, L)
        N += 1
        for i in range(3):
            d = rank(i, h, aq) - rank(i, h, ap)
            nrm = float(sum(x*x for x in h))**.5
            if d > 0: a[i] += d*nrm; wit[(i,1)] = wit[(i,1)] or h
            if d < 0: b[i] -= d*nrm; wit[(i,-1)] = wit[(i,-1)] or h
    print(f"eps={eps}: MC (uniform cube, |h|-weighted) a_i = {np.round(a/N,4)}, b_i = {np.round(b/N,4)}")
    for i in range(3):
        print(f"   world {i+1}: C_q worse at h={tuple(map(str,wit[(i,1)]))}; better at h={tuple(map(str,wit[(i,-1)]))}")
    assert all(wit.values())
print("crossing at every world confirmed; the audit's reweighting then ties C_p and C_q at every world")
