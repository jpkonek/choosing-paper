"""Z3 referee: the bound eta < 1/(A+1) of Lemma Y3.3a is sharp (exact rationals).
For every eta > 1/(A+1) there is g in Gamma_eta with sign(corner_B1(g).g) != sign(P_T1(g)).
Witness family: g = (-x, 1, -y), x = 1/(A+1) + d, y = 1 - A x + d^2 (so y < x), small d."""
from fractions import Fraction as Fr
def params(eps):
    eps = Fr(eps); c0 = (1-eps)/3; lam = eps/c0; return eps, c0, lam, 1+lam
for eps in [Fr(1,20), Fr(1,10), Fr(3,10), Fr(1,2), Fr(4,5)]:
    _, c0, lam, A = params(eps)
    for d in [Fr(1,10**3), Fr(1,10**6), Fr(1,10**9)]:
        x = 1/(A+1) + d; y = 1 - A*x + d*d
        g = (-x, Fr(1), -y)
        assert 0 < y < x
        M = max(abs(g[1]), abs(g[2]))
        etaneeded = abs(g[0])/M          # g in Gamma_eta iff eta >= this
        corner = (1, 1, A)               # g2>0>g3
        b = sum(c*t for c, t in zip(corner, g))
        tau = [sum(g) + lam*g[k] for k in range(3)]
        print(f"eps={eps} d={d}: g in Gamma_eta for eta>={float(etaneeded):.12f} (1/(A+1)={float(1/(A+1)):.12f}); "
              f"corner value sign {(b>0)-(b<0)}, T1 sign {(min(tau)>0)-(min(tau)<0)}")
        assert b > 0 and min(tau) < 0
print("sharp: mismatches exist in Gamma_eta for every eta > 1/(A+1)")
