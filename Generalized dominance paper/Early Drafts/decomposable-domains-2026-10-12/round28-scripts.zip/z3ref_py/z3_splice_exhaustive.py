"""Z3 referee (CHECKED, exhaustive): audit's splice Propositions 1-3 and the algebraic core of Prop 5,
over ALL preorders on the 2-problem x 2-advice product domain {0,1}^2 that satisfy (IB).
Models: A=(0,0), B=(1,1), E = problem 1: Z = B on E, A off E = (1,0); W = (0,1).
(IB) on a product domain: (x,y) <= (x',y) iff (x,z) <= (x',z), and the same in the second coordinate.
No guidance is imposed (the propositions use only IB and transitivity)."""
import itertools
M = [(0,0),(0,1),(1,0),(1,1)]
idx = {m:i for i,m in enumerate(M)}
pairs = [(i,j) for i in range(4) for j in range(4) if i != j]
pre = []
for bits in itertools.product([0,1], repeat=len(pairs)):
    R = [[i == j for j in range(4)] for i in range(4)]
    for (i,j), b in zip(pairs, bits): R[i][j] = bool(b)
    if any(R[i][j] and R[j][k] and not R[i][k] for i in range(4) for j in range(4) for k in range(4)): continue
    ok = True
    for x, xp, y, z in itertools.product([0,1], repeat=4):
        if R[idx[(x,y)]][idx[(xp,y)]] != R[idx[(x,z)]][idx[(xp,z)]]: ok = False
        if R[idx[(y,x)]][idx[(y,xp)]] != R[idx[(z,x)]][idx[(z,xp)]]: ok = False
    if ok: pre.append(R)
A, B, Z, W = idx[(0,0)], idx[(1,1)], idx[(1,0)], idx[(0,1)]
le = lambda R,x,y: R[x][y]
lt = lambda R,x,y: R[x][y] and not R[y][x]
eq = lambda R,x,y: R[x][y] and R[y][x]
print("preorders on 4 models satisfying IB:", len(pre))
c1 = c2 = c5 = 0
for R in pre:
    # Prop 1: A<=Z, A<=W, one strict  =>  A<B
    if le(R,A,Z) and le(R,A,W) and (lt(R,A,Z) or lt(R,A,W)):
        c1 += 1; assert lt(R,A,B)
    # Prop 2 consequence: A~B and A<Z  =>  W<A ; and the pattern itself occurs
    if eq(R,A,B) and lt(R,A,Z):
        c2 += 1; assert lt(R,W,A)
    # Prop 5 core: A~B, A<=Z, A<=W  =>  A~B~Z~W
    if eq(R,A,B) and le(R,A,Z) and le(R,A,W):
        c5 += 1; assert eq(R,A,Z) and eq(R,A,W)
print(f"Prop 1 instances {c1}: all pass;  Prop 2 pattern (A~B, A<Z) instances {c2}: all give W<A;  Prop 5 core instances {c5}: all tie")
# Prop 3: two worlds (and three worlds) of IB preorders
c3 = 0
for k in (2, 3):
    for Rs in itertools.product(pre, repeat=k):
        if all(eq(R,A,B) for R in Rs) and all(le(R,A,Z) for R in Rs) and any(lt(R,A,Z) for R in Rs):
            c3 += 1
            assert all(le(R,W,A) for R in Rs) and any(lt(R,W,A) for R in Rs)   # W dominates A
print(f"Prop 3 instances (2 and 3 worlds) {c3}: in every one W dominates A, so A is not undominated")
print("ALL OK")
