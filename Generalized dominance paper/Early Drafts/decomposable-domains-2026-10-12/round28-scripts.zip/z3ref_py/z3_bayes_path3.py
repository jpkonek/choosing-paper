"""Z3 referee (CHECKED, exact rationals): Bayes(w) of Y3's field Psi^(1) is incoherent at intermediate
weights w on the segment p0 -> u (p0 on the boundary of N, w1 > w2 = w3).  Mechanism: off Gamma_eta the
field freezes the attribution k(g) = argmin_k g_k (correct only at w = u), so the acceptance functional
F_w(g) = w.g + lam*w_k g_k jumps across {g1 = g2 < g3}.  Witness: accepted ga (side g2 < g1), accepted gb,
rejected midpoint gr (side g1 < g2), all strict inequalities, hence robust (open sets of witnesses)."""
import sys, os
from fractions import Fraction as Fr
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'y3py'))
from y3common import params, dot, had, T1_vertices, box_corner

def m_exact(g, eps, eta):
    _, c0, lam, A = params(eps)
    M = max(abs(g[1]), abs(g[2]))
    if abs(g[0]) <= eta * M:
        return box_corner([(Fr(1), Fr(1)), (Fr(1), A), (Fr(1), A)], g)
    V = T1_vertices(eps)
    k = min(range(3), key=lambda k: dot(V[k], g))
    return tuple(1 + (lam if j == k else 0) for j in range(3))

def F(w, g, eps, eta):
    return dot(w, had(m_exact(g, eps, eta), g))

for eps in [Fr(1, 10), Fr(3, 10), Fr(1, 2), Fr(4, 5)]:
    _, c0, lam, A = params(eps)
    eta = 1 / (2 * (A + 1)); s = eta / 2 / A
    p0 = tuple(x / (1 + s) for x in (Fr(1), s / 2, s / 2)); u = (Fr(1, 3),) * 3
    for t in [Fr(1, 4), Fr(1, 2), Fr(3, 4), Fr(9, 10), Fr(99, 100), Fr(999, 1000)]:
        w = tuple((1 - t) * a + t * b for a, b in zip(p0, u))
        assert w[0] > w[1] == w[2]
        c = Fr(1); X = lam * c * (w[0] + w[1]) / 2      # lam w2 c < X < lam w1 c
        g3 = (X + (w[0] + w[1]) * c) / w[2]
        d = Fr(1, 10**4)
        ga = (-c + d, -c - d, g3)                        # argmin = coordinate 2
        D = 10 * d; FBa = X - lam * w[0] * c            # side-B functional at the crossing (< 0)
        Delta = (abs(FBa) / 2 - FBa - D * (w[1] - w[0] - lam * w[0])) / w[2]
        gb = (-c - D, -c + D, g3 + Delta)                # argmin = coordinate 1, F_B(gb) ~ |FBa|/2 > 0
        gr = tuple((x + y) / 2 for x, y in zip(ga, gb))  # midpoint, on side g1 < g2
        assert gr[0] < gr[1] < 0 < gr[2] and ga[1] < ga[0] < 0 and gb[0] < gb[1] < 0
        if any(abs(g[0]) <= eta * max(abs(g[1]), abs(g[2])) for g in (ga, gr, gb)):
            print(f"eps={eps} t={t}: this witness family lies in Gamma_eta (w3 too small); not applicable")
            continue
        va, vr, vb = F(w, ga, eps, eta), F(w, gr, eps, eta), F(w, gb, eps, eta)
        ok = va > 0 and vb > 0 and vr < 0
        print(f"eps={eps} t={t}: F(ga)={float(va):+.4e} F(gb)={float(vb):+.4e} F(midpoint)={float(vr):+.4e}"
              f" -> incoherent: {ok}")
        assert ok
print("done")
