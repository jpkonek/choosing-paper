"""U1 checks (NUMERICS only; no proof in U1_notes.md rests on this file).

Run from inside u1py/:  python3 -I -B u1_checks.py  > u1_checks.out

(A) Lemma U1.2 for linear-host edge models L_m = U ∩ {m·g > 0}, m on [e1,e2]:
    no m makes L_m reject both (-,+,+)∩U∖T1 and (+,-,+)∩U∖T1 (witnesses found for every m on a grid).
(B) The two explicit T1-separating 12-edge models of Lemma U1.2(c):
    K_a = co(K' ∪ [m0, m0']),  K_b = co(K' ∪ {v1, v2, (1/2,1/2,0)}):
    agree with T1 on W1 ∪ W2 and equal P1 on Q3 (random samples).
(C) The segment-host template field of Prop. U1.5: T1 = B_u exactly (sign test on random g ∈ U, all six orthants).
(D) Its ratio functions are monotone, satisfy R+ >= R- on each edge, and every superlevel set {r_ij > s}
    equals (on random samples of R_ij) the world-i error set of the segment model co(K' ∪ [a(s), b(s)]).
(E) Lemma U1.1(i) on the template: r12 < 1 on W1, r12 > 1 on W2 (theta* = 1 at p = u).
(F) Control: the same field with one-sided ratios (R+ on both sides, or R- on both sides, as a linear host
    forces) is NOT T1-Bayes at u (mismatches > 0).
"""
import numpy as np

rng = np.random.default_rng(20261016)


def setup(eps, s):
    c0 = (1 - eps) / 3
    kap = (1 + 2 * eps) / (1 - eps)
    V = np.array([c0 * np.ones(3) + eps * np.eye(3)[k] for k in range(3)])  # T1 vertices
    epsp = s * eps
    c0p = (1 - epsp) / 3
    Vp = np.array([c0p * np.ones(3) + epsp * np.eye(3)[k] for k in range(3)])  # K' vertices
    return c0, kap, V, Vp


def PK(Kpts, g):
    return np.min(g @ Kpts.T, axis=-1)


def sample_U(Vp, n):
    """random mixed gambles in U = D_{K'} (Gaussian directions)."""
    out = []
    while sum(len(o) for o in out) < n:
        g = rng.standard_normal((4 * n, 3))
        mixed = (g.max(1) > 0) & (g.min(1) < 0)
        g = g[mixed & (PK(Vp, g) > 0)]
        out.append(g)
    return np.concatenate(out)[:n]


def inT1(V, g):
    return PK(V, g) > 0


def orth(g, pat):
    return np.all(np.sign(g) == np.array(pat), axis=1)


# ---------- (A) linear host never separates ----------
def check_A(eps, s, ngrid=400, n=200000):
    c0, kap, V, Vp = setup(eps, s)
    g = sample_U(Vp, n)
    t1 = inT1(V, g)
    reg1 = orth(g, (-1, 1, 1)) & ~t1     # (-,+,+)∩U∖T1 : separating model must reject
    reg2 = orth(g, (1, -1, 1)) & ~t1     # (+,-,+)∩U∖T1 : separating model must reject
    bad = 0
    for th in np.exp(np.linspace(np.log(1e-3), np.log(1e3), ngrid)):  # theta0 = m1/m2
        m = np.array([th, 1.0, 0.0]) / (1 + th)
        acc = g @ m > 0
        w1 = np.any(acc & reg1)
        w2 = np.any(acc & reg2)
        if not (w1 or w2):
            bad += 1
    # vertex models: P1 accepts (+,-,+) (reg2 non-empty), P2 accepts (-,+,+)
    v1 = np.any(reg2)  # P1 accepts every g with g1>0
    v2 = np.any(reg1)  # P2 accepts every g with g2>0
    return ngrid - bad, ngrid, v1 and v2


# ---------- (B) explicit separating models ----------
def check_B(eps, s, n=200000):
    c0, kap, V, Vp = setup(eps, s)
    g = sample_U(Vp, n)
    t1 = inT1(V, g)
    m0 = np.array([kap, 1, 0]) / (kap + 1)
    m0p = np.array([1, kap, 0]) / (kap + 1)
    Ka = np.vstack([Vp, m0, m0p])            # co(K' ∪ [m0,m0']): P_K is min over these extreme points
    Kb = np.vstack([Vp, V[0], V[1], [0.5, 0.5, 0.0]])
    res = []
    W1 = (orth(g, (1, -1, -1)) & t1) | (orth(g, (-1, 1, 1)) & ~t1)   # Q1 ∖ E1(T1)
    W2 = (orth(g, (-1, 1, -1)) & t1) | (orth(g, (1, -1, 1)) & ~t1)   # Q2 ∖ E2(T1)
    Q3 = orth(g, (1, 1, -1)) | orth(g, (-1, -1, 1))
    P1 = g[:, 0] > 0
    for K in (Ka, Kb):
        D = PK(K, g) > 0
        agree = np.all(D[W1 | W2] == t1[W1 | W2])
        edge = np.all(D[Q3] == P1[Q3])
        res.append((bool(agree), bool(edge), int((W1 | W2).sum()), int(Q3.sum())))
    return res


# ---------- template field (Prop. U1.5) ----------
def make_h(kap):
    c = 1 / (kap + 1)

    def h(t):
        t = np.asarray(t, float)
        return np.where(t <= c, t * (kap + 1) / 2, 1 - (1 - kap * t) * (kap + 1) / 2)
    return h


def Rplus(x, kap, h):
    x = np.asarray(x, float)
    return np.where(x <= 1 / kap, h(np.minimum(x, 1 / kap)), kap * x)


def Rminus(x, kap, h):
    x = np.asarray(x, float)
    return np.where(x <= kap, x / kap, 1 / h(np.minimum(1 / np.maximum(x, 1e-300), 1 / kap)))


def ratio(g, i, j, kap, h):
    """r_ij = rho_j/rho_i on R_ij, x = |g_j|/|g_i|; '+' side g_i>0>g_j uses R+, '-' side uses R-."""
    x = np.abs(g[:, j]) / np.abs(g[:, i])
    plus = (g[:, i] > 0) & (g[:, j] < 0)
    return np.where(plus, Rplus(x, kap, h), Rminus(x, kap, h))


def densities(g, kap, h):
    r12 = ratio(g, 0, 1, kap, h)
    r13 = ratio(g, 0, 2, kap, h)
    r23 = ratio(g, 1, 2, kap, h)
    sg = np.sign(g)
    rho = np.ones_like(g)
    Q1 = (sg[:, 1] == sg[:, 2]) & (sg[:, 0] != sg[:, 1])
    Q2 = (sg[:, 0] == sg[:, 2]) & (sg[:, 1] != sg[:, 0])
    Q3 = (sg[:, 0] == sg[:, 1]) & (sg[:, 2] != sg[:, 0])
    rho[Q1] = np.stack([np.ones(Q1.sum()), r12[Q1], r13[Q1]], 1)
    rho[Q2] = np.stack([1 / r12[Q2], np.ones(Q2.sum()), r23[Q2]], 1)
    rho[Q3] = np.stack([1 / r13[Q3], 1 / r23[Q3], np.ones(Q3.sum())], 1)
    return rho, (Q1, Q2, Q3), (r12, r13, r23)


def check_C(eps, s, n=400000, tol=1e-9):
    c0, kap, V, Vp = setup(eps, s)
    h = make_h(kap)
    g = sample_U(Vp, n)
    rho, Q, _ = densities(g, kap, h)
    val = np.sum(rho * np.sign(g), axis=1)  # u·c up to the factor 1/3
    t1 = inT1(V, g)
    margin = np.abs(PK(V, g)) / np.linalg.norm(g, axis=1)
    far = margin > 1e-7
    mism = far & ((val > tol) != t1)
    ties = far & (np.abs(val) <= tol)
    per = {}
    for pat in [(1, -1, -1), (-1, 1, 1), (-1, 1, -1), (1, -1, 1), (-1, -1, 1), (1, 1, -1)]:
        o = orth(g, pat)
        per[pat] = (int(o.sum()), int((mism & o).sum()))
    return int(mism.sum()), int(ties.sum()), int(far.sum()), per


def check_D(eps, s, n=200000, nlev=60):
    c0, kap, V, Vp = setup(eps, s)
    h = make_h(kap)
    xs = np.exp(np.linspace(np.log(1e-4), np.log(1e4), 20001))
    Rp, Rm = Rplus(xs, kap, h), Rminus(xs, kap, h)
    mono = bool(np.all(np.diff(Rp) >= -1e-12) and np.all(np.diff(Rm) >= -1e-12))
    order = bool(np.all(Rp >= Rm - 1e-12))
    g = sample_U(Vp, n)
    ok = 0
    tot = 0
    for (i, j) in [(0, 1), (0, 2), (1, 2)]:
        k = 3 - i - j
        R = np.sign(g[:, i]) != np.sign(g[:, j])
        gg = g[R]
        r = ratio(gg, i, j, kap, h)
        for lev in np.exp(rng.uniform(np.log(0.05), np.log(20), nlev)):
            # thresholds: '+' side error {x >= beta}, '-' side error {x > alpha}
            beta = xs[np.argmax(Rp > lev)]
            alpha = xs[np.argmax(Rm > lev)]
            # segment endpoints on [e_i,e_j]: a_i/a_j = alpha, b_i/b_j = beta  (alpha >= beta)
            a = np.zeros(3); a[i] = alpha; a[j] = 1; a /= a.sum()
            b = np.zeros(3); b[i] = beta; b[j] = 1; b /= b.sum()
            K = np.vstack([Vp, a, b])
            acc = PK(K, gg) > 0
            err_i = np.where(gg[:, i] > 0, ~acc, acc)          # world-i error of the segment model
            x = np.abs(gg[:, j]) / np.abs(gg[:, i])
            near = (np.abs(x - alpha) < 1e-3 * alpha) | (np.abs(x - beta) < 1e-3 * beta)
            agree = (err_i == (r > lev)) | near
            tot += 1
            ok += int(np.all(agree) and alpha >= beta - 1e-12)
            # edge-model property: P_i on Q_k
            Qk = (np.sign(g[:, i]) == np.sign(g[:, j])) & (np.sign(g[:, k]) != np.sign(g[:, i]))
            accQ = PK(K, g[Qk]) > 0
    return mono, order, ok, tot


def check_E(eps, s, n=300000):
    c0, kap, V, Vp = setup(eps, s)
    h = make_h(kap)
    g = sample_U(Vp, n)
    t1 = inT1(V, g)
    W1 = (orth(g, (1, -1, -1)) & t1) | (orth(g, (-1, 1, 1)) & ~t1)
    W2 = (orth(g, (-1, 1, -1)) & t1) | (orth(g, (1, -1, 1)) & ~t1)
    r12 = ratio(g, 0, 1, kap, h)
    return bool(np.all(r12[W1] < 1)), bool(np.all(r12[W2] > 1)), int(W1.sum()), int(W2.sum())


if __name__ == "__main__":
    for eps, s in [(0.1, 0.9), (0.3, 0.9), (0.6, 0.5), (0.9, 0.3)]:
        print(f"=== eps={eps}, s={s}, kappa={(1+2*eps)/(1-eps):.4f}")
        a = check_A(eps, s)
        print(f"(A) linear host: witnesses against separation for {a[0]}/{a[1]} grid values of m1/m2;"
              f" vertex models fail: {a[2]}")
        for name, r in zip(("co(K'u[m0,m0'])", "co(K'u{v1,v2,(.5,.5,0)})"), check_B(eps, s)):
            print(f"(B) {name}: agrees with T1 on W1uW2: {r[0]} ({r[2]} pts); equals P1 on Q3: {r[1]} ({r[3]} pts)")
        mism, ties, far, per = check_C(eps, s)
        print(f"(C) template: mismatches sign(u.c) vs T1 = {mism} / {far} sampled (ties {ties}); per orthant (n, mism):")
        print("    ", per)
        mono, order, ok, tot = check_D(eps, s)
        print(f"(D) R+,R- nondecreasing: {mono}; R+ >= R-: {order}; superlevel sets = segment-model errors: {ok}/{tot}")
        e = check_E(eps, s)
        print(f"(E) r12<1 on W1: {e[0]} ({e[2]} pts); r12>1 on W2: {e[1]} ({e[3]} pts)")


# ---------- control: force R+ = R- (one-sided ratios, as a linear host forces) ----------
def check_control(eps, s, n=200000):
    c0, kap, V, Vp = setup(eps, s)
    h = make_h(kap)
    g = sample_U(Vp, n)
    t1 = inT1(V, g)
    out = []
    for name, F in (("R+ on both sides", Rplus), ("R- on both sides", Rminus)):
        def rat(g, i, j):
            x = np.abs(g[:, j]) / np.abs(g[:, i])
            return F(x, kap, h)
        r12, r13, r23 = rat(g, 0, 1), rat(g, 0, 2), rat(g, 1, 2)
        sg = np.sign(g)
        rho = np.ones_like(g)
        Q1 = (sg[:, 1] == sg[:, 2]) & (sg[:, 0] != sg[:, 1])
        Q2 = (sg[:, 0] == sg[:, 2]) & (sg[:, 1] != sg[:, 0])
        Q3 = (sg[:, 0] == sg[:, 1]) & (sg[:, 2] != sg[:, 0])
        rho[Q1] = np.stack([np.ones(Q1.sum()), r12[Q1], r13[Q1]], 1)
        rho[Q2] = np.stack([1 / r12[Q2], np.ones(Q2.sum()), r23[Q2]], 1)
        rho[Q3] = np.stack([1 / r13[Q3], 1 / r23[Q3], np.ones(Q3.sum())], 1)
        val = np.sum(rho * np.sign(g), axis=1)
        out.append((name, int(((val > 0) != t1).sum())))
    return out


if __name__ == "__main__":
    print("=== control (expected: mismatches > 0)")
    for eps, s in [(0.1, 0.9), (0.3, 0.9), (0.6, 0.5)]:
        print(f"eps={eps}, s={s}:", check_control(eps, s))
