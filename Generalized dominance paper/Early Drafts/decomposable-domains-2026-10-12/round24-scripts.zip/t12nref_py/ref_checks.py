"""Referee checks for T1n / T2n (T12n_referee.md).  Run: python3 -I -B ref_checks.py  (from inside t12nref_py/).
No verdict rests on this file.  Imports nothing from the authors' folders.

(R1) Lemma T1n.1(b): the two-case constant (4/9) min(1-t, kappa)/y0, brute force over random data.
(R2) T2n.4(c): Bayes regimes of c = (0, s2*1_{M\\L0}, s3) on sampled gambles of U; B_q = C^23_{s0} cap P3 on q2 = q3;
     A(c) = {e1} (T1 not Bayes at random p != e1); Lambda0 cap Q2 cap U non-empty.
(R3) T2n.4(b): B_t = P1 for t1 > 0; T1 not Bayes at p with p1 > 0.
(R4) T2n.5(b): (1,1,-c) in U \\ cl D_T1 for c in (2c0/(c0+eps), 2c'/(c'+eps')).
(R5) T1n §7.3: z = (c', c'+e', c'+e')/(1+e') lies in co(K' u {e2}) and co(K' u {e3}); some g in (+,-,-) cap U has z.g < 0.
(R6) T2n.7(b): W_eta with the full range c in (kappa, kappa+1) (the authors' script samples (kappa+0.1, kappa+1)).
(R7) T1n.2 Step 4 bookkeeping: random multi-round climbs with omega in two value bands; composite w2-ratio vs the bound.
"""
import numpy as np

rng = np.random.default_rng(2026)
out = []


def say(s):
    print(s, flush=True)
    out.append(s)


def geo(eps, s):
    c0 = (1 - eps) / 3
    u = np.ones(3) / 3
    V = np.array([c0 * np.ones(3) + eps * np.eye(3)[k] for k in range(3)])
    Vp = np.array([u + s * (V[k] - u) for k in range(3)])
    return c0, V, Vp


# (R1)
bad = 0
N = 200000
for _ in range(N):
    y0 = rng.uniform(0.01, 0.98)
    t = rng.uniform(y0 + 1e-3, 0.999)
    kap = rng.uniform(1e-4, 1.0)
    lp = rng.uniform(1e-6, y0 / 2)
    m = int(np.ceil(y0 / lp))
    lq = rng.uniform(1e-9, 1.0)
    room = 1.5 * m * lq <= 1 - t
    if room and kap > 1.5 * m * lq:
        continue  # this (kappa, lq) pair is excluded by the room case (kappa <= 1.5 m lq); not a valid instance
    c = (4.0 / 9.0) * min(1 - t, kap) / y0
    if lq < c * lp * (1 - 1e-12):
        bad += 1
say('(R1) T1n.1(b) constant: violations among valid random instances: %d' % bad)

# (R2), (R3)
for (eps, s) in [(0.1, 0.9), (0.3, 0.9), (0.6, 0.5)]:
    c0, V, Vp = geo(eps, s)
    g = rng.standard_normal((400000, 3))
    g = g[np.min(g @ Vp.T, axis=1) > 0]
    sg = np.sign(g)
    mixed = ~(np.all(sg > 0, axis=1))
    g, sg = g[mixed], sg[mixed]
    T1 = np.min(g @ V.T, axis=1) > 0
    R23 = sg[:, 1] != sg[:, 2]
    sig = np.abs(g[:, 1]) / (np.abs(g[:, 1]) + np.abs(g[:, 2]))
    s0 = 0.4
    L0 = R23 & (sig < s0)
    C23 = (g @ np.array([0, 1 - s0, s0])) > 0
    P2 = g[:, 1] > 0
    P3 = g[:, 2] > 0
    c2 = sg[:, 1] * (~L0)
    c3 = sg[:, 2]
    errs = 0
    for _ in range(300):
        tt = rng.dirichlet([1, 1, 1])
        val = tt[1] * c2 + tt[2] * c3
        B = val > 0
        Z = val == 0
        if tt[2] > tt[1]:
            errs += np.sum(B != P3)
        else:
            errs += np.sum((B != C23) & ~Z)
    # q2 = q3
    q = np.array([0.2, 0.4, 0.4])
    Bq = (q[1] * c2 + q[2] * c3) > 0
    eq = np.sum(Bq != (C23 & P3))
    # A(c) = {e1}
    notbayes = 0
    for _ in range(200):
        p = rng.dirichlet([1, 1, 1])
        val = p[1] * c2 + p[2] * c3
        viol = np.sum((val > 0) & ~T1) + np.sum((val < 0) & T1)
        notbayes += viol > 0
    Q2 = (sg[:, 1] != sg[:, 0]) & (sg[:, 1] != sg[:, 2])
    nL0Q2 = np.sum(L0 & Q2)
    # (R3) field (rho s1, 0, 0)
    P1 = g[:, 0] > 0
    viol3 = np.sum(P1 != T1)
    say('(R2) eps=%.1f s=%.1f: n=%d; Bayes-regime mismatches %d; B_q vs C23 cap P3 mismatches %d; '
        'T1 not Bayes at %d/200 random p; |L0 cap Q2| = %d  (R3) |T1 != P1| = %d'
        % (eps, s, len(g), errs, eq, notbayes, nL0Q2, viol3))

# (R4)
for (eps, s) in [(0.1, 0.9), (0.3, 0.9), (0.6, 0.5)]:
    c0, V, Vp = geo(eps, s)
    ep = s * eps
    cp = (1 - ep) / 3
    lo, hi = 2 * c0 / (c0 + eps), 2 * cp / (cp + ep)
    cs = np.linspace(lo, hi, 52)[1:-1]
    G = np.stack([np.ones_like(cs), np.ones_like(cs), -cs], axis=1)
    inU = np.all(G @ Vp.T > 0, axis=1).mean()
    outT = (np.min(G @ V.T, axis=1) < 0).mean()
    say('(R4) eps=%.1f s=%.1f: interval (%.4f, %.4f); (1,1,-c) in U: %.2f, outside cl D_T1: %.2f' % (eps, s, lo, hi, inU, outT))

# (R5)
for (eps, s) in [(0.1, 0.9), (0.3, 0.9), (0.6, 0.5)]:
    c0, V, Vp = geo(eps, s)
    ep = s * eps
    cp = (1 - ep) / 3
    z = np.array([cp, cp + ep, cp + ep]) / (1 + ep)
    z2 = (Vp[2] + ep * np.eye(3)[1]) / (1 + ep)
    z3 = (Vp[1] + ep * np.eye(3)[2]) / (1 + ep)
    g = rng.standard_normal((400000, 3))
    g = g[(g[:, 0] > 0) & (g[:, 1] < 0) & (g[:, 2] < 0)]
    g = g[np.min(g @ Vp.T, axis=1) > 0]
    neg = np.sum(g @ z < 0)
    say('(R5) eps=%.1f s=%.1f: |z - (v3\'+e\' e2)/(1+e\')| = %.1e, |z - (v2\'+e\' e3)/(1+e\')| = %.1e; '
        '#(+,-,-) cap U samples %d, with z.g<0: %d' % (eps, s, np.abs(z - z2).max(), np.abs(z - z3).max(), len(g), neg))

# (R6)
for (eps, s) in [(0.1, 0.9), (0.3, 0.9), (0.6, 0.5)]:
    c0, V, Vp = geo(eps, s)
    kap = 1 + eps / c0
    n = 200000
    for eta in [0.1, 0.01]:
        a = rng.uniform(0, eta, n)
        cc = rng.uniform(kap, kap + 1, n)
        W = np.stack([a, -np.ones(n), cc], axis=1)
        say('(R6) eps=%.1f s=%.1f eta=%.2f: W_eta (c in (kappa,kappa+1)) in U %.4f, in D_T1 %.4f'
            % (eps, s, eta, (np.min(W @ Vp.T, axis=1) > 0).mean(), (np.min(W @ V.T, axis=1) > 0).mean()))

# (R7) T1n.2 Step 4: alternate A (omega in (alpha, alpha(1+d))) and B (omega in (beta(1-d), beta)) pieces.
worst = 0.0
for _ in range(20000):
    alpha = rng.uniform(1.1, 5.0)
    beta = rng.uniform(0.1, alpha / 1.05)
    eta = rng.uniform(0, 0.5) * ((alpha / beta) ** 0.5 - 1)
    k = rng.integers(1, 12)
    w2 = 1.0
    for _r in range(k):
        omA = rng.uniform(alpha, alpha * 1.5)       # source A piece, pointwise omega > alpha
        omB = rng.uniform(beta * 0.5, beta)         # target B piece, omega < beta
        w3 = w2 / omA                               # (homogeneous pieces: omega constant on each)
        w3 *= (1 + eta)                             # 13-cut
        w2 = w3 * omB
        w2 *= (1 + eta)                             # 12-cut back into an A piece
    bound = ((1 + eta) ** 2 * beta / alpha) ** k
    worst = max(worst, w2 / bound)
say('(R7) Step 4 bookkeeping: max (composite w2-ratio)/(((1+eta)^2 beta/alpha)^k) = %.6f (must be < 1)' % worst)

with open('ref_checks.out', 'w') as fh:
    fh.write('\n'.join(out) + '\n')
