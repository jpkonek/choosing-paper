"""T1n NUMERICS (illustration only; no proof rests on it).

Cell model of world 1's edge cut moves on the link class Q_1 (worlds 2, 3 (CA+)).
A cell is (x2-level index, x3-level index, omega = w2/w3).  Moves (Q1.20):
  12-move: from cell a to cell b if lev2(b) > lev2(a); w2-mass multiplied by (1+eta)
  13-move: from cell a to cell b if lev3(b) > lev3(a); w3-mass multiplied by (1+eta)
Bookkeeping in w2 units: a 13-move multiplies w2-mass by (1+eta)*omega(b)/omega(a).
We compute, by DP over the DAG of strictly NE-ordered cells (or Bellman-Ford when
cycles exist), the minimal achievable w2-ratio of a composite move from a source cell
to a target cell.  A ratio -> 0 inside a fixed window contradicts the window bound
(Lemma T1n.1); a closed cycle with ratio < 1 contradicts strict (G).
"""
import math, itertools

ETA = 1e-3

def min_log_ratio(cells, src, dst, max_steps):
    # Bellman-Ford style relaxation, at most max_steps moves
    INF = float('inf')
    best = {c: INF for c in range(len(cells))}
    best[src] = 0.0
    for _ in range(max_steps):
        new = dict(best)
        for a in range(len(cells)):
            if best[a] == INF:
                continue
            la2, la3, wa = cells[a]
            for b in range(len(cells)):
                if b == a:
                    continue
                lb2, lb3, wb = cells[b]
                if lb2 > la2:   # 12-move
                    new[b] = min(new[b], best[a] + math.log(1 + ETA))
                if lb3 > la3:   # 13-move
                    new[b] = min(new[b], best[a] + math.log(1 + ETA) + math.log(wb / wa))
        best = new
    return best[dst]

out = []
# (A) anti-diagonal pair at a cut point z: B-cell NW (omega=beta), A-cell SE (omega=alpha>beta)
alpha, beta = 2.0, 1.0
cells = [(0, 1, beta), (1, 0, alpha)]          # NW then SE
# cycle NW ->12 SE ->13 NW, ratio in w2 units at NW:
r = (1 + ETA) * (1 + ETA) * cells[0][2] / cells[1][2]
out.append("(A) anti-diagonal 2-cycle NW->12 SE->13 NW: w2-ratio back into source = %.6f (<1: strict (G) fails)" % r)
cells_ok = [(0, 1, alpha), (1, 0, beta)]
r2 = (1 + ETA) ** 2 * cells_ok[0][2] / cells_ok[1][2]
out.append("    reversed values (omega_NW >= omega_SE): ratio = %.6f (>=1: allowed, product form)" % r2)

# (B) comonotone band, two cells per level (omega alpha and beta), levels 0..L, x3 = x2
for L in (2, 4, 8, 16, 32):
    cells = []
    for i in range(L + 1):
        cells.append((i, i, alpha))   # A-cell at level i
        cells.append((i, i, beta))    # B-cell at level i
    v = min_log_ratio(cells, 0, 2 * L, 2 * L + 2)
    out.append("(B) comonotone band, omega not a function of the level, L=%2d levels: min w2-ratio = %.3e  (beta/alpha)^(L/2) = %.3e"
               % (L, math.exp(v), (beta / alpha) ** (L // 2)))

# (C) comonotone band, omega = Omega(level) (a function of the common level), oscillating
for L in (8, 32, 128):
    cells = [(i, i, 1.5 + 0.5 * math.sin(3 * math.pi * i / L)) for i in range(L + 1)]
    v = min_log_ratio(cells, 0, L, L + 2)
    lo = [math.log(c[2]) for c in cells]
    vneg = sum(max(lo[i - 1] - lo[i], 0.0) for i in range(1, L + 1))
    out.append("(C) omega = Omega(level), L=%3d: min w2-ratio = %.6f, exp(-V^-(log Omega)) = %.6f (bounded below: BV)"
               % (L, math.exp(v), math.exp(-vneg)))

# (D) comonotone band with Omega of unbounded variation in a window: Omega alternating 2,1,2,1,...
for L in (8, 32, 128):
    cells = [(i, i, 2.0 if i % 2 == 0 else 1.0) for i in range(L + 1)]
    v = min_log_ratio(cells, 0, L, L + 2)
    out.append("(D) Omega alternating on L=%3d levels inside one window: min w2-ratio = %.3e (-> 0: window bound violated)"
               % (L, math.exp(v)))

txt = "\n".join(out)
print(txt)
open("t1n_band_chain.out", "w").write(txt + "\n")
