"""NUMERICS for T2n_notes.md (round 22/23).  Run:  python3 -I -B t2n_checks.py   (from inside t2npy/).

No proof in T2n rests on this file.

(A) Lemma T2n.0 (self-protection of P1's world 1), LP relaxation on the finite cell model of P1
    (p1_cell_copy.py = verbatim copy of p1py/q_n2_common.py).  For every selector F and every cut breakpoint j:
        maximise lambda(Q)   over fractional P <= 1 on cells < j, Q <= 1 on cells >= j,
        subject to  (1_P - 1_Q) - g_F  in T  (tail dominance),
    i.e. over all regular X with X <=_1 C_b (b = breakpoint j).  T2n.0 predicts max = 0.
    The relaxation contains every set-valued (P, Q), so max = 0 for the LP implies it for sets.
    Tail rows are scaled by 1 - x_i (cell sizes span 5^-24; see p1ref_py/ref_checks.py, "Caution").
(B) Strictness of the design (needed for the mirrored world 2): no fractional delta in [-1,0], delta != 0, with
    delta - g_F in T.  (World 2 of T2n.1 is the mirror image, so the same LP certifies it.)
(C) Competitiveness of C_b in the doubly blind system, exactly (rationals), on random cut pairs (P, Q):
    1_Q - 1_P in T (world 1 accepts)  or  1_P - 1_Q in T' (mirrored head-dominance cone of world 2).
(D) Geometry of edge-chain ends for the linear host (T2n §4), for three (eps, s): sampled points of the cones
    H_eta  = (+,-,+) with g1 < eta*|g2|, |g2| < eta*g3       (world 2's 12-end  meets world 3's 23-end)
    W_eta  = (+,-,+) with g1 < eta*|g2|, g3 in (kappa+0.1, kappa+1)*|g2|   (world 2's 12-end, unsheltered)
    lie in U and in D_T1 (T1 accepts, so T1 errs at world 2 only).
"""
import os
import random
import sys
from fractions import Fraction as Fr

import numpy as np
from scipy.optimize import linprog

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from p1_cell_copy import Model  # noqa: E402

out = []


def say(*a):
    s = ' '.join(str(x) for x in a)
    print(s, flush=True)
    out.append(s)


M = Model()
nc = M.ncell
L = np.array([float(x) for x in M.len])
Tmat = np.zeros((nc, nc))
for i in range(nc):
    Tmat[i, i:] = L[i:] / float(1 - M.bps[i])
G = {sel: np.array([float(x) for x in M.gF(sel)]) for sel in M.selectors}

# ---------------- (A) self-protection ----------------
worstA = 0.0
nA = 0
featA = 0
ctrl = 0.0
for sel in M.selectors:
    g = G[sel]
    b1 = -(Tmat @ g)
    for j in range(1, nc):
        sgn = np.array([1.0 if c < j else -1.0 for c in range(nc)])
        A1 = -Tmat * sgn[None, :]          # -T(sgn * x) <= -T g
        cost = np.array([0.0 if c < j else -L[c] for c in range(nc)]) / float(1 - M.bps[j])
        res = linprog(c=cost, A_ub=A1, b_ub=b1, bounds=[(0, 1)] * nc, method='highs')
        nA += 1
        if res.status == 0:
            featA += 1
            worstA = max(worstA, -res.fun)
        elif res.status != 2:
            say('(A) LP status', res.status, 'at', sel, j)
        # positive control: the opposite comparison C_b <=_1 X (vector 1_Q - 1_P) admits lambda(Q) > 0
        res2 = linprog(c=cost, A_ub=-A1, b_ub=b1, bounds=[(0, 1)] * nc, method='highs')
        if res2.status == 0:
            ctrl = max(ctrl, -res2.fun)
say('(A) T2n.0 LP over', nA, 'selector/cut pairs (', featA, 'feasible): max lambda(Q)/(1-b) with X <=_1 C_b :', worstA)
say('(A) positive control (C_b <=_1 X instead): max lambda(Q)/(1-b) =', round(ctrl, 6))

# ---------------- (B) strictness ----------------
worstB = 0.0
for sel in M.selectors:
    g = G[sel]
    res = linprog(c=np.ones(nc), A_ub=-Tmat, b_ub=-(Tmat @ g), bounds=[(-1, 0)] * nc, method='highs')
    if res.status == 0:
        worstB = max(worstB, -res.fun)
say('(B) strictness LP over', len(M.selectors), 'selectors: max total density of accepted delta <= 0 :', worstB)

# ---------------- (C) competitiveness, exact ----------------
random.seed(23)
okC = 0
nC = 0
lens = M.len
for _ in range(3000):
    j = random.randrange(1, nc)
    P = [c for c in range(j) if random.random() < 0.3]
    Q = [c for c in range(j, nc) if random.random() < 0.3]
    f1 = [Fr(0)] * nc
    for c in Q:
        f1[c] = Fr(1)
    for c in P:
        f1[c] = Fr(-1)
    tail_ok = all(t >= 0 for t in M.tails(f1))           # 1_Q - 1_P in T
    f2 = [-x for x in f1]                                  # world-2 vector 1_P - 1_Q
    head = Fr(0)
    head_ok = True
    for c in range(nc):                                    # head integrals int_{x < t} f2
        head += f2[c] * lens[c]
        if head < 0:
            head_ok = False
            break
    nC += 1
    okC += (tail_ok or head_ok)
say('(C) competitiveness of C_b, random cut pairs: world 1 (T) or world 2 (T\') accepts in', okC, '/', nC)

# ---------------- (D) geometry of chain ends ----------------
def geo(eps, s):
    c0 = (1 - eps) / 3
    u = np.ones(3) / 3
    V = np.array([c0 * np.ones(3) + eps * np.eye(3)[k] for k in range(3)])
    Vp = np.array([u + s * (V[k] - u) for k in range(3)])
    return V, Vp, (1 + 2 * eps) / (1 - eps)


rng = np.random.default_rng(23)
for (eps, s) in [(0.1, 0.9), (0.3, 0.9), (0.6, 0.5)]:
    V, Vp, kap = geo(eps, s)
    for eta in [0.1, 0.03, 0.01, 0.003]:
        n = 20000
        # H_eta: g = (a, -b, 1), 0 < b < eta, 0 < a < eta*b
        b = rng.uniform(0, eta, n)
        a = rng.uniform(0, 1, n) * eta * b
        H = np.stack([a, -b, np.ones(n)], axis=1)
        inU = (np.min(H @ Vp.T, axis=1) > 0).mean()
        inT = (np.min(H @ V.T, axis=1) > 0).mean()
        s12 = np.abs(H[:, 0]) / (np.abs(H[:, 0]) + np.abs(H[:, 1]))
        s23 = np.abs(H[:, 1]) / (np.abs(H[:, 1]) + np.abs(H[:, 2]))
        # W_eta: g = (a, -1, c), 0 < a < eta, c in (kappa + 0.1, kappa + 1)
        a2 = rng.uniform(0, eta, n)
        c2 = rng.uniform(kap + 0.1, kap + 1, n)
        W = np.stack([a2, -np.ones(n), c2], axis=1)
        wU = (np.min(W @ Vp.T, axis=1) > 0).mean()
        wT = (np.min(W @ V.T, axis=1) > 0).mean()
        w23 = (np.abs(W[:, 1]) / (np.abs(W[:, 1]) + np.abs(W[:, 2]))).min()
        say('(D) eps=%.1f s=%.1f eta=%.3f | H: in U %.4f, in D_T1 %.4f, max s12 %.4f, max s23 %.4f'
            ' | W: in U %.4f, in D_T1 %.4f, min s23 %.3f'
            % (eps, s, eta, inU, inT, s12.max(), s23.max(), wU, wT, w23))

with open(os.path.join(HERE, 't2n_checks.out'), 'w') as fh:
    fh.write('\n'.join(out) + '\n')
