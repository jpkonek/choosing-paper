"""Q4 checks (NUMERICS / exact algebra; no proof rests on them).

(1) Box witnesses for T1 at p* = u, x = x_+, every failing pair (a,b) in {(1,2),(2,3),(3,1)}:
    A in relint F_a, B in relint F_c (c the third index), q0 = (1-s)e_b + s e_a. Checks: membership,
    sign pattern, chart values c_a(A).q0 > 0, c_c(B).q0 > 0, ratio A_b B_a < |A_a||B_b|, and that A, B
    converge to the two b-crossings as s -> 0.  (Exact in sympy for (1,2); cyclic images numerically.)
(2) Test-gamble LP (Theorem Q4.1 step 7): for each b-crossing w*, max_{m in Delta} (1 - m_b) subject to
    m.w* <= 0 and m.h >= 0, h = w* - delta*1 + eta*e_b.  The proof's bound is 1 - m_b <= 1 - delta/eta.
(3) (LF) alone leaves the vertex set fat; one cut cell collapses it.  W_b(rho) := {m : m.h >= 0 for all
    sampled h in the rho-tube of the facet arcs of dD_T1 with h_b > 0}.  Report the extent of W_b(rho)
    and of W_b(rho) ∩ {m.w* <= 0} (both crossings).
(4) Step 5 geometry: random strict-sign penalty data (c, c') for gambles in the witness sign classes, edge
    prior q0 with c.q0 > 0 >= d.q0: an interior prior of the open cell R(-g) = {c'.q > 0, d.q < 0} exists
    within distance 1e-6 of q0.
(5) Layout search (R10a Cor V2 parametrisation of layouts with coherent vertex models: Av ~ U_i D_{V_i},
    compatible tuples): random compatible tuples of polygonal V_i containing e_i and satisfying (LF) at
    T1; count tuples that survive the conclusion of Thm Q4.1 at every b (V_b ⊆ {m.w* <= 0} for some
    b-crossing w*).  Prediction: only V_b = {e_b} survives, i.e. only (Av) layouts.
"""
import numpy as np, sympy as sp
from scipy.optimize import linprog
rng = np.random.default_rng(4)
E3 = np.eye(3)
out = []
def say(s):
    print(s); out.append(s)

def t1(eps):
    u = np.ones(3) / 3
    return [(1 - eps) * u + eps * E3[k] for k in range(3)]

def crossings(eps):
    """b-crossings: for each facet k and coordinate b != k, w in F_k with w_b = 0 (orientation: in D_T)."""
    V = t1(eps); res = {}
    for k in range(3):
        for b in range(3):
            if b == k: continue
            w = np.cross(V[k], E3[b])
            j = 3 - k - b
            if w @ V[j] < 0: w = -w
            res[(k, b)] = w / np.linalg.norm(w)
    return res

# ---------------- (1) box witnesses -----------------------------------------------------------
say("(1) box witnesses, p* = u, x = x_+")
s_, th, eta, zeta, x, kap = sp.symbols('s theta eta zeta x kappa', positive=True)
beta = 1 / kap
A = sp.Matrix([-beta * (1 + eta), eta, 1]); B = sp.Matrix([1, -zeta, -beta * (1 - zeta)])
q0 = sp.Matrix([s_, 1 - s_, 0])
c1 = lambda h: sp.Matrix([-(x * h[1] + h[2]), x * h[1], h[2]])
c3 = lambda h: sp.Matrix([x * h[0], h[1], -(x * h[0] + h[1])])
say(f"   exact: c1(A).q0 = {sp.simplify((c1(A).T * q0)[0])},  c3(B).q0 = {sp.simplify((c3(B).T * q0)[0])}")
for eps in [0.05, 0.3, 0.6, 0.9]:
    k_ = (1 + 2 * eps) / (1 - eps); xp = ((k_ + 1) + np.sqrt((k_ + 1) ** 2 - 4)) / 2
    V = t1(eps); cr = crossings(eps)
    def C(k, h):
        h = np.asarray(h, float)
        if k == 0: return np.array([-(xp * h[1] + h[2]), xp * h[1], h[2]])
        if k == 1: return np.array([h[0], -(h[0] + xp * h[2]), xp * h[2]])
        return np.array([xp * h[0], h[1], -(xp * h[0] + h[1])])
    P = np.array([[0, 0, 1], [1, 0, 0], [0, 1, 0]])  # cyclic shift: (Ph)_i = h_{i-1}
    rows = []
    for shift in range(3):
        Pk = np.linalg.matrix_power(P, shift)
        a, b, c = (0 + shift) % 3, (1 + shift) % 3, (2 + shift) % 3
        dists = []; okall = True
        for s in ([1e-2, 1e-3, 1e-4] if eps < 0.8 else [1e-4, 1e-5, 1e-6]):
            th_ = 0.995
            ze = th_ * s * xp / (1 - s); et = s / (th_ * xp * (1 - 2 * s))
            A0 = np.array([-(1 / k_) * (1 + et), et, 1.0]); B0 = np.array([1.0, -ze, -(1 / k_) * (1 - ze)])
            q00 = np.array([s, 1 - s, 0.0])
            Aw, Bw, q = Pk @ A0, Pk @ B0, Pk @ q00
            memA = abs(Aw @ V[a]) < 1e-12 and all(Aw @ V[j] > 0 for j in range(3) if j != a)
            memB = abs(Bw @ V[c]) < 1e-12 and all(Bw @ V[j] > 0 for j in range(3) if j != c)
            sg = Aw[a] < 0 < Aw[b] and Bw[b] < 0 < Bw[a]
            ch = C(a, Aw) @ q > 0 and C(c, Bw) @ q > 0
            ratio = Aw[b] * Bw[a] < abs(Aw[a]) * abs(Bw[b])
            okall &= bool(memA and memB and sg and ch and ratio)
            wA = cr[(a, b)]; wB = cr[(c, b)]
            dA = np.linalg.norm(Aw / np.linalg.norm(Aw) - wA); dB = np.linalg.norm(Bw / np.linalg.norm(Bw) - wB)
            dists.append(max(dA, dB))
        rows.append(f"(a,b)=({a+1},{b+1}): all conditions {okall}; dist to b-crossings at s={'1e-2,1e-3,1e-4' if eps < 0.8 else '1e-4,1e-5,1e-6'}: "
                    + ", ".join(f"{d:.1e}" for d in dists))
    say(f"   eps={eps}: x+^2/kappa={xp**2/k_:.3f}");
    for r in rows: say("     " + r)

# ---------------- (2) test-gamble LP ----------------------------------------------------------
say("(2) LP: max (1 - m_b) s.t. m in Delta, m.w* <= 0, m.(w* - delta 1 + eta e_b) >= 0")
for eps in [0.05, 0.3, 0.9]:
    cr = crossings(eps); worst = 0.0
    for (k, b), w in cr.items():
        for delta in [1e-2, 1e-3, 1e-4]:
            for tau in [1e-1, 1e-3]:
                et = delta * (1 + tau); h = w - delta * np.ones(3) + et * E3[b]
                # variables m (3); maximise -m_b+1 -> minimise m_b
                res = linprog(c=E3[b], A_ub=np.vstack([w, -h]), b_ub=[0, 0], A_eq=[np.ones(3)], b_eq=[1],
                              bounds=[(0, 1)] * 3, method='highs')
                val = 1 - res.fun; bound = 1 - delta / et
                worst = max(worst, val - bound)
    say(f"   eps={eps}: max over 6 crossings x 6 (delta,tau) of [LP value - (1 - delta/eta)] = {worst:.2e}  (<= 0 expected)")

# ---------------- (3) W_b fat, cut cell collapses ---------------------------------------------
def facet_samples(eps, rho, n=400):
    V = t1(eps); H = []
    for k in range(3):
        i, j = [t for t in range(3) if t != k]
        r1 = np.cross(V[k], V[i]); r2 = np.cross(V[k], V[j])  # corner rays of F_k (orient into F_k)
        if r1 @ V[j] < 0: r1 = -r1
        if r2 @ V[i] < 0: r2 = -r2
        for t in np.linspace(0, 1, n):
            h = (1 - t) * r1 / np.linalg.norm(r1) + t * r2 / np.linalg.norm(r2)
            h /= np.linalg.norm(h)
            for _ in range(3):
                H.append(h + rho * rng.uniform(-1, 1, 3) / np.sqrt(3))
    return np.array(H)

def extent(cons, b):
    """max distance from e_b over {m in Delta : cons @ m >= 0} (vertex enumeration by LP in 24 directions)."""
    best = 0.0
    for ang in np.linspace(0, 2 * np.pi, 24, endpoint=False):
        dvec = np.cos(ang) * np.array([1, -1, 0]) / np.sqrt(2) + np.sin(ang) * np.array([1, 1, -2]) / np.sqrt(6)
        res = linprog(c=-dvec, A_ub=-cons, b_ub=np.zeros(len(cons)), A_eq=[np.ones(3)], b_eq=[1],
                      bounds=[(0, 1)] * 3, method='highs')
        if res.status == 0:
            best = max(best, np.linalg.norm(res.x - E3[b]))
    return best

say("(3) extent from e_b of W_b(rho) [(LF) only] and of W_b(rho) ∩ {m.w* <= 0} [plus one cut cell]")
for eps in [0.3]:
    cr = crossings(eps)
    for rho in [0.05, 0.01]:
        H = facet_samples(eps, rho)
        for b in range(3):
            Hb = H[H[:, b] > 0]
            ext0 = extent(Hb, b)
            # test gambles inside the tube near each b-crossing
            exts = []
            for (k, bb), w in cr.items():
                if bb != b: continue
                tg = [w - d * np.ones(3) + d * (1 + 1e-3) * E3[b] for d in [rho / 4, rho / 8]]
                cons = np.vstack([Hb, -w[None, :], np.array(tg)])
                exts.append(extent(cons, b))
            say(f"   eps={eps} rho={rho} b={b+1}: extent W_b = {ext0:.3f};  with cut cell at either crossing: "
                + ", ".join(f"{e:.1e}" for e in exts))

# ---------------- (4) step 5 geometry ----------------------------------------------------------
bad = tested = 0
for _ in range(20000):
    # witness sign classes for (a,b) = (1,2): A-family (-,+,+), B-family (+,-,-)
    pat = np.array([-1, 1, 1]) if rng.random() < 0.5 else np.array([1, -1, -1])
    c = pat * rng.uniform(0.05, 3, 3); cp = -pat * rng.uniform(0.05, 3, 3); d = c - cp
    s = rng.uniform(1e-4, 0.2); q0 = np.array([s, 1 - s, 0.0])
    if rng.random() < 0.2:      # force the boundary case d.q0 = 0 by adjusting cp_2
        # solve for cp so that d.q0 = 0 while keeping signs: d1 s + d2 (1-s) = 0
        pass
    if not (c @ q0 > 0 and d @ q0 <= 0): continue
    tested += 1
    found = False
    for r in [1e-7, 1e-6]:
        for _ in range(200):
            dq = rng.normal(size=3); dq -= dq.mean(); dq *= r / np.linalg.norm(dq)
            q = q0 + dq
            if (q > 0).all() and cp @ q > 0 and d @ q < 0: found = True; break
        if found: break
    if not found:
        # boundary case d.q0 = 0: move along the edge first
        for t in [1e-7, -1e-7]:
            q1 = q0 + t * np.array([1, -1, 0])
            for _ in range(200):
                dq = rng.normal(size=3); dq -= dq.mean(); dq *= 1e-8 / np.linalg.norm(dq)
                q = q1 + dq
                if (q > 0).all() and cp @ q > 0 and d @ q < 0: found = True; break
            if found: break
    bad += not found
say(f"(4) step 5: instances with c.q0>0>=d.q0: {tested}; no interior R(-g) point within 1e-6: {bad}")

# ---------------- (5) layout search ------------------------------------------------------------
# Per vertex b: a layout with coherent vertex model is Av ∩ {h_b>0} = D_{V_b}, e_b in V_b (R10a Thm V,
# Cor V2(a)); (LF) at T1 with N = rho-tube means V_b ⊆ W_b(rho).  Sample imprecise V_b inside W_b(rho)
# (polygons spanned by e_b and 1-3 points of W_b(rho) at distance >= 1e-3 from e_b) and test Q4.1's
# step-6 conclusion V_b ⊆ {m.w* <= 0} for the b-crossings w*.  (Compatibility across vertices, Cor V2(b),
# is not imposed: the conclusion is per vertex.)
eps = 0.3; cr = crossings(eps)
for rho in [0.05, 0.01]:
    H = facet_samples(eps, rho, n=300)
    tot = surv = 0
    for b in range(3):
        Hb = H[H[:, b] > 0]
        tgs = [w - d * np.ones(3) + d * (1 + 1e-4) * E3[b] for (k, bb), w in cr.items() if bb == b
               for d in [rho / 4, rho / 16, rho / 64]]          # test gambles inside the rho-tube
        Hb = np.vstack([Hb, np.array(tgs)])
        pts_ok = []
        while len(pts_ok) < 600:
            t = rng.uniform(1e-3, 0.7); m = (1 - t) * E3[b] + t * rng.dirichlet(np.ones(3))
            if (Hb @ m).min() >= 0 and np.linalg.norm(m - E3[b]) >= 1e-3: pts_ok.append(m)
        pts_ok = np.array(pts_ok)
        for trial in range(300):
            Vb = pts_ok[rng.choice(len(pts_ok), size=rng.integers(1, 4), replace=False)]
            tot += 1
            surv += any((Vb @ w).max() <= 0 for (k, bb), w in cr.items() if bb == b)
    say(f"(5) rho={rho}: imprecise LF-compatible vertex models sampled: {tot}; satisfying V_b ⊆ {{m.w*<=0}} "
        f"for some b-crossing: {surv}  (Q4.1 predicts 0; precise V_b = {{e_b}} satisfies it trivially)")

open(__file__.replace('.py', '.out'), 'w').write("\n".join(out) + "\n")
