"""Referee sanity check for Q2.15' (NUMERICS; the referee's argument in Q24_referee.md does not rest on it).

Claim checked: on a part of the blind link class Q_1 = (+,-,-) u (-,+,+) where world 1's two edge chains cross
transversally, a partner ratio omega = w_2/w_3 that is NOT 0-homogeneous yields, by two edge cut moves (Q1.20 = Q2.18's
"cut moves", which need only competitiveness of the edge selection and (RL-2) at the partner), an accepted world-1
vector 1_{T2} - 1_{S0} with T2 a proper subset of S0: strict (G) fails at world 1.  No world-1 density is used, so
world-1 blindness on (+,-,-) is irrelevant.

Chains: the linear-host chains of Q1.26, x_2 = |g1|/|g2|, x_3 = |g1|/|g3| (any nondecreasing reparametrisation gives
the same cut sets).  World-1 error sets of the j-chain are {x_j < b} (Q1 convention).
Partners: w_2 = |g2| (1 + |g|) (radial factor), w_3 = |g3|.  omega(2g)/omega(g) = (1+2|g|)/(1+|g|) > 1.
Degenerate cycle of Q1.22(a): g0 = 2*gstar, g1 = gstar (same chi value), first a 13-step then a 12-step.
"""
import numpy as np
rng = np.random.default_rng(7)

def gauss(G):
    return np.exp(-0.5 * (G ** 2).sum(1)) / (2 * np.pi) ** 1.5

def x2(G): return np.abs(G[:, 0]) / np.abs(G[:, 1])
def x3(G): return np.abs(G[:, 0]) / np.abs(G[:, 2])
def w2(G): return np.abs(G[:, 1]) * (1 + np.linalg.norm(G, axis=1))
def w3(G): return np.abs(G[:, 2])

gstar = np.array([1.0, -0.25, -0.2])          # in (+,-,-); u.g > 0, so in U for K' near u
eps, s = 0.3, 0.9
T1 = [(1 - eps) / 3 * np.ones(3) + eps * np.eye(3)[k] for k in range(3)]
Kp = [np.ones(3) / 3 + s * (v - np.ones(3) / 3) for v in T1]
for g in (gstar, 2 * gstar):
    assert min(q @ g for q in Kp) > 0, "point not in U"
z1, z2 = gstar[0] / abs(gstar[1]), gstar[0] / abs(gstar[2])   # chi(gstar) = chi(2 gstar)

def cell(center, r, n):
    G = center + r * rng.uniform(-1, 1, (n, 3))
    return G, (2 * r) ** 3 / n * gauss(G)     # sample points and their mu-weights

r, n = 0.01, 400000
G0, m0 = cell(2 * gstar, 2 * r, n)            # V^0 around g0 = 2 gstar (scaled ball keeps chi-image comparable)
G1, m1 = cell(gstar, r, n)                    # V^1 around g1 = gstar
# corner sets (anti-diagonal corners: these are non-null iff the chains cross transversally here)
S0 = (x3(G0) < z2) & (x2(G0) >= z1)           # source side of the 13-cut at b = z2, target side of the 12-cut at z1
C1 = (x3(G1) >= z2) & (x2(G1) < z1)           # target side of the 13-cut, source side of the 12-cut
print(f"corner masses: mu(S0)={m0[S0].sum():.3e}, mu(C1)={m1[C1].sum():.3e}  (both > 0: transverse)")

eta = 1e-3
f0 = 0.1   # S0 is taken as a 10% proportional slice of the corner set (small mass, as Q1.22 requires)
W3_S0 = f0 * (w3(G0) * m0)[S0].sum()
# step 1 (13-cut move S0 => T1): T1 subset of C1 with w3(T1) = (1+eta) w3(S0); take a fraction of C1
frac1 = (1 + eta) * W3_S0 / (w3(G1) * m1)[C1].sum()
assert frac1 < 1, "C1 too small; shrink S0"
W2_T1 = frac1 * (w2(G1) * m1)[C1].sum()       # T1 = a w3-proportional slice of C1; its w2 mass, up to O(r) oscillation
# step 2 (12-cut move T1 => T2): T2 subset of S0 with w2(T2) = (1+eta) w2(T1)
W2_T2 = (1 + eta) * W2_T1
W2_S0 = f0 * (w2(G0) * m0)[S0].sum()
print(f"w2(S0) = {W2_S0:.4e},  deposit w2(T2) = {W2_T2:.4e},  ratio = {W2_T2 / W2_S0:.4f}")
om0 = (w2(G0) / w3(G0))[S0].mean(); om1 = (w2(G1) / w3(G1))[C1].mean()
print(f"omega near g0 = {om0:.4f}, near g1 = {om1:.4f}; predicted ratio ~ (1+eta)^2 * omega(g1)/omega(g0) = "
      f"{(1 + eta) ** 2 * om1 / om0:.4f}")
print("T2 fits strictly inside S0 (w2-mass smaller): accepted vector 1_T2 - 1_S0 <= 0, nonzero -> strict (G) fails"
      if W2_T2 < W2_S0 else "no contradiction")
