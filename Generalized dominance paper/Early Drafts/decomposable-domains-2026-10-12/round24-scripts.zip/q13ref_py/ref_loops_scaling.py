"""Q13 referee check: rook-loop ratios of q1_loops.py as the cell thickness DEL shrinks.
Product-form omega should tend to 1 in both orientations; non-product omega should keep one orientation < 1.
Run: python3 -I ref_loops_scaling.py (imports ../q1py read-only)."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'q1py'))
import q1_loops as L
for DEL in (0.004, 0.002, 0.001, 0.0005):
    L.DEL = DEL
    row = []
    for beta in (0.0, 0.5):
        row.append((beta, L.loop(beta, (2.0, 2.0), 6.0, 6.0, '+'), L.loop(beta, (2.0, 2.0), 6.0, 6.0, '-')))
    print(f"DEL={DEL:.4f}  " + "  ".join(f"beta={b:+.1f}: (+){p:.5f} (-){m:.5f}" for b, p, m in row))
