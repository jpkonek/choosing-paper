"""X3 additive restriction: the same finite search with complete ADDITIVE world orders
(MILP, lazily generated constraints; NUMERICS tooling).

World i: L_i(X) = sum_c l_i(c, X_c); l_i(c, good) = 0, l_i(c, silent) = s >= 1,
l_i(c, bad) = b >= s + 1 (strict guidance; additive constants per cell cancel).  0 <= l <= LMAX.
X <=_i Y iff L_i(X) <= L_i(Y); a rejected comparison is required with margin 1 (wlog by scaling,
since all constraints are homogeneous and finitely many; LMAX large).
Constraints mirror satx.py: K (competitiveness), P+C (protection; incoherent X strictly worse
somewhere), CL (closed-section proxies ring / ring-bd / ring-vx).  Ties are allowed where the
axioms allow them.
"""
import time, numpy as np, scipy.sparse as sp
from scipy.optimize import milp, LinearConstraint, Bounds
from cells import rank

LMAX = 200.0


class Additive:
    def __init__(self, W, grd, cands, opts, verbose=True):
        self.W = W; self.grd = grd; self.opts = opts; self.verbose = verbose
        self.cand = [[W.idx[c] for c in cs] for cs in cands]
        N = W.N
        # rank table: rk[i, c, a] for a in 0,1,2 = '+','0','-'
        self.rk = np.zeros((3, N, 3), int)
        for i in range(3):
            for c in range(N):
                for a in range(3): self.rk[i, c, a] = rank('+0-'[a], W.G[c], i)
        # variables: l[i,c,rank] for rank 1,2  -> index
        self.n = 0
        self.lv = {}
        for i in range(3):
            for c in range(N):
                for r in (1, 2): self.lv[(i, c, r)] = self.n; self.n += 1
        self.nl = self.n
        self.integ = [0] * self.n
        self.rows = []
        for i in range(3):
            for c in range(N):
                self.rows.append(({self.lv[(i, c, 1)]: 1}, 1, np.inf))
                self.rows.append(({self.lv[(i, c, 2)]: 1, self.lv[(i, c, 1)]: -1}, 1, np.inf))
        self.selv = {}
        for v, cs in enumerate(self.cand):
            if len(cs) > 1:
                for C in cs: self.selv[(v, C)] = self.newbin()
                self.rows.append(({self.selv[(v, C)]: 1 for C in cs}, 1, 1))
        self.M = 2 * LMAX * N + 10
        self.inst = set()

    def newbin(self):
        self.integ.append(1); self.n += 1
        return self.n - 1

    def coef(self, i, X):
        """coefficient dict of L_i(X)"""
        d = {}
        for c in range(self.W.N):
            r = self.rk[i, c, self.W.dig[X, c]]
            if r: d[self.lv[(i, c, r)]] = d.get(self.lv[(i, c, r)], 0) + 1
        return d

    def diff(self, i, A, B):
        """L_i(A) - L_i(B)"""
        d = dict(self.coef(i, A))
        for k, v in self.coef(i, B).items(): d[k] = d.get(k, 0) - v
        return {k: v for k, v in d.items() if v}

    def guard(self, d, lb, ub, bins):
        """row d <= ub (or >= lb) relaxed by M for each binary in bins being 0: list of (var, sense)
        sense +1: active when var=1; -1: active when var=0."""
        d = dict(d)
        if ub < np.inf:
            for (z, s) in bins:
                if s > 0: d[z] = d.get(z, 0) + self.M; ub += self.M     # d + M z <= ub + M
                else: d[z] = d.get(z, 0) - self.M                        # d - M z <= ub
            self.rows.append((d, -np.inf, ub))
        else:
            for (z, s) in bins:
                if s > 0: d[z] = d.get(z, 0) - self.M; lb -= self.M
                else: d[z] = d.get(z, 0) + self.M
            self.rows.append((d, lb, np.inf))

    def selbins(self, v, C):
        return [(self.selv[(v, C)], 1)] if (v, C) in self.selv else []

    # lazily added instances
    def add_K(self, v, X):
        if ('K', v, X) in self.inst: return
        self.inst.add(('K', v, X))
        ks = []
        for i in self.grd['supp'][v]:
            k = self.newbin(); ks.append(k)
            for C in self.cand[v]:
                self.guard(self.diff(i, C, X), -np.inf, 0.0, [(k, 1)] + self.selbins(v, C))
        self.rows.append(({k: 1 for k in ks}, 1, np.inf))

    def add_PC(self, v, C, X):
        if ('P', v, C, X) in self.inst: return
        self.inst.add(('P', v, C, X))
        ys = []
        for i in range(3):          # branch i: L_i(X) - L_i(C) >= 1
            y = self.newbin(); ys.append(y)
            self.guard(self.diff(i, X, C), 1.0, np.inf, [(y, 1)] + self.selbins(v, C))
        if self.W.coh[X]:           # branch 'C weakly dominates X'
            y = self.newbin(); ys.append(y)
            for i in range(3):
                self.guard(self.diff(i, X, C), 0.0, np.inf, [(y, 1)] + self.selbins(v, C))
        self.rows.append(({y: 1 for y in ys}, 1, np.inf))

    def add_CL(self, v, X, i):
        if ('CL', v, X, i) in self.inst: return
        self.inst.add(('CL', v, X, i))
        # accepted at v:  L_i(C_v) - L_i(X) <= 0 ;  or rejected at some neighbour w: L_i(C_w) - L_i(X) >= 1
        ys = []
        y = self.newbin(); ys.append(y)
        for C in self.cand[v]: self.guard(self.diff(i, C, X), -np.inf, 0.0, [(y, 1)] + self.selbins(v, C))
        for w in self.grd['nbr'][v]:
            y = self.newbin(); ys.append(y)
            for C in self.cand[w]: self.guard(self.diff(i, C, X), 1.0, np.inf, [(y, 1)] + self.selbins(w, C))
        self.rows.append(({y: 1 for y in ys}, 1, np.inf))

    def solve_once(self, tlim=900):
        r, ci, va, lb, ub = [], [], [], [], []
        for k, (d, l, u) in enumerate(self.rows):
            for j, x in d.items(): r.append(k); ci.append(j); va.append(x)
            lb.append(l); ub.append(u)
        A = sp.csr_matrix((va, (r, ci)), shape=(len(self.rows), self.n))
        lo = np.zeros(self.n); hi = np.ones(self.n); hi[:self.nl] = LMAX
        c = np.zeros(self.n); c[:self.nl] = 1e-3
        return milp(c, constraints=LinearConstraint(A, lb, ub), bounds=Bounds(lo, hi),
                    integrality=np.array(self.integ), options={'time_limit': tlim, 'disp': False})

    def losses(self, x):
        W = self.W
        L = np.zeros((3, W.nF))
        for i in range(3):
            tab = np.zeros((W.N, 3))
            for c in range(W.N):
                for a in range(3):
                    rr = self.rk[i, c, a]
                    tab[c, a] = x[self.lv[(i, c, rr)]] if rr else 0.0
            L[i] = tab[np.arange(W.N)[None, :], W.dig].sum(1)
        return L

    def run(self, maxit=80, cap=400, tol=1e-6):
        t0 = time.time(); W, g, o = self.W, self.grd, self.opts
        for it in range(maxit):
            res = self.solve_once()
            if res.x is None:
                if self.verbose: print(f'  additive: status={res.status} ({res.message}) it={it} inst={len(self.inst)} {time.time()-t0:.1f}s', flush=True)
                return (False if res.status == 2 else None), None
            x = res.x; L = self.losses(x)
            sel = [cs[0] if len(cs) == 1 else max(cs, key=lambda C: x[self.selv[(v, C)]]) for v, cs in enumerate(self.cand)]
            acc = lambda i, C: L[i][C] <= L[i] + tol          # vector over X: C <=_i X
            nadd = 0
            if o.get('K', True):
                for v in range(len(self.cand)):
                    if g['pts'][v].count(0) == 2: continue
                    ok = np.zeros(W.nF, bool)
                    for i in g['supp'][v]: ok |= acc(i, sel[v])
                    for X in np.where(~ok)[0][:cap]: self.add_K(v, int(X)); nadd += 1
            for v in range(len(self.cand)):
                C = sel[v]
                dom = np.ones(W.nF, bool); strict = np.zeros(W.nF, bool); tie = np.ones(W.nF, bool)
                for i in range(3):
                    dom &= L[i] <= L[i][C] + tol; strict |= L[i] < L[i][C] - tol
                    tie &= np.abs(L[i] - L[i][C]) <= tol
                bad = (dom & strict) | (tie & ~W.coh)
                bad[C] = False
                for X in np.where(bad)[0][:cap]: self.add_PC(v, C, int(X)); nadd += 1
            cl = o.get('CL')
            if cl:
                for v in range(len(self.cand)):
                    ns = len(g['supp'][v])
                    if not (cl == 'ring' or (cl == 'ring-bd' and ns < 3) or (cl == 'ring-vx' and ns == 1)): continue
                    for i in range(3):
                        allw = np.ones(W.nF, bool)
                        for w in g['nbr'][v]: allw &= acc(i, sel[w])
                        for X in np.where(allw & ~acc(i, sel[v]))[0][:cap]: self.add_CL(v, int(X), i); nadd += 1
            if self.verbose: print(f'  additive it {it}: +{nadd} inst={len(self.inst)} {time.time()-t0:.1f}s', flush=True)
            if nadd == 0: return True, (x, L, sel)
        return None, None
