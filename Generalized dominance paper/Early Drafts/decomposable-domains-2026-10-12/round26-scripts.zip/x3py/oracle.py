"""X3: exact competitor oracle for ADDITIVE finite solutions (NUMERICS tooling, exact up to LP
tolerance).  For an additive system (per-world tables tab[i][c][a]) and a selection, search ALL
3^N models of the finite world for a violation of K, P, C or the CL proxy, by small MILPs
(one-hot advice per cell).  Violators are returned so that the caller can add them to F and
re-solve (competitor generation), making the final additive solution valid against every
model of the finite world, not only against F.
"""
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from cells import coherent

TOL = 1e-7


class LiteWorld:
    def __init__(self, G, F, coh):
        self.G = [np.asarray(g, float) for g in G]; self.N = len(G)
        self.F = list(F); self.coh = np.asarray(coh, bool)
        self.idx = {x: n for n, x in enumerate(F)}
        self.dig = np.array([['+0-'.index(a) for a in x] for x in F], np.int8)
        self.nF = len(F)

    def add(self, x):
        if x in self.idx: return self.idx[x]
        self.idx[x] = len(self.F); self.F.append(x)
        self.coh = np.append(self.coh, coherent(x, self.G))
        self.dig = np.vstack([self.dig, np.array([['+0-'.index(a) for a in x]], np.int8)])
        self.nF = len(self.F)
        return self.idx[x]


def _cut(pat, N):
    r = np.zeros(3 * N + 1)
    for c, a in enumerate(pat): r[3 * c + '+0-'.index(a)] = 1
    return (r, -np.inf, N - 1)


def _multi(obj, rows, N, k, test):
    out, cuts = [], []
    for _ in range(k):
        pat, t = _solve(obj, rows + cuts, N)
        if pat is None or not test(pat, t): break
        out.append(pat); cuts.append(_cut(pat, N))
    return out


def _solve(obj, rows, N):
    """binary x[c,a] one-hot per cell (3N vars) plus one free continuous t (last)."""
    n = 3 * N + 1
    A, lb, ub = [], [], []
    for c in range(N):
        r = np.zeros(n); r[3 * c:3 * c + 3] = 1; A.append(r); lb.append(1); ub.append(1)
    for r, l, u in rows: A.append(r); lb.append(l); ub.append(u)
    integ = np.ones(n); integ[-1] = 0
    lo = np.zeros(n); hi = np.ones(n); lo[-1] = -1e6; hi[-1] = 1e6
    res = milp(obj, constraints=LinearConstraint(np.array(A), lb, ub), bounds=Bounds(lo, hi),
               integrality=integ, options={'disp': False, 'time_limit': 120})
    if res.x is None: return None, None
    x = res.x
    pat = ''.join('+0-'[int(np.argmax(x[3 * c:3 * c + 3]))] for c in range(N))
    return pat, -res.fun


def lvec(tab, i):
    """row vector r with r . x = L_i(X)"""
    return np.concatenate([tab[i].reshape(-1), [0.0]])


def L_of(tab, i, pat):
    return sum(tab[i][c]['+0-'.index(a)] for c, a in enumerate(pat))


def violations(tab, G, grd, sel_pats, opts, max_per=4):
    """tab: array (3, N, 3) of penalties; sel_pats: selected pattern per grid point."""
    N = len(G); out = []
    tvec = np.zeros(3 * N + 1); tvec[-1] = 1
    obj = -tvec                                          # maximise t
    for v, C in enumerate(sel_pats):
        supp = grd['supp'][v]
        LC = [L_of(tab, i, C) for i in range(3)]
        if opts.get('K', True) and len(supp) > 1:
            rows = [(lvec(tab, i) + tvec, -np.inf, LC[i]) for i in supp]     # L_i(X) + t <= L_i(C)
            for pat in _multi(obj, rows, N, max_per, lambda p, t: t > TOL): out.append(('K', v, pat))
        # P: X with L_i(X) <= L_i(C) all i and sum of gains >= t
        rows = [(lvec(tab, i), -np.inf, LC[i]) for i in range(3)]
        s = sum(lvec(tab, i) for i in range(3)); rows.append((s + tvec, -np.inf, sum(LC)))
        rows.append(_cut(C, N))
        for pat in _multi(obj, rows, N, max_per, lambda p, t: t > TOL): out.append(('P', v, pat))
        # C: incoherent exact ties (enumerate a few ties by no-good cuts)
        rows = [(lvec(tab, i), LC[i] - TOL, LC[i] + TOL) for i in range(3)]
        cuts = []
        for _ in range(6):
            pat, t = _solve(np.zeros(3 * N + 1), rows + cuts, N)
            if pat is None: break
            if pat != C and not coherent(pat, G): out.append(('C', v, pat)); break
            r = np.zeros(3 * N + 1)
            for c, a in enumerate(pat): r[3 * c + '+0-'.index(a)] = 1
            cuts.append((r, -np.inf, N - 1))
        cl = opts.get('CL')
        if cl:
            ns = len(supp)
            if cl == 'ring' or (cl == 'ring-bd' and ns < 3) or (cl == 'ring-vx' and ns == 1):
                for i in range(3):
                    lo = max(L_of(tab, i, sel_pats[w]) for w in grd['nbr'][v])
                    rows = [(lvec(tab, i), lo, np.inf), (lvec(tab, i) + tvec, -np.inf, LC[i])]
                    for pat in _multi(obj, rows, N, max_per, lambda p, t: t > TOL): out.append(('CL', v, pat))
    return out
