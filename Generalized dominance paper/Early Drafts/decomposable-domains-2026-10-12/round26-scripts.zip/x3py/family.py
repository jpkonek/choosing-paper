"""X3: selection candidates and competitor family (NUMERICS tooling)."""
import itertools, numpy as np
from cells import advice_of, coherent, ADV

FLIP = {'+': '0-', '0': '+-', '-': '+0'}


def vertex_pattern(G, j):
    return ''.join('+' if g[j] > 0 else '-' for g in G)


def candidates(V, G, grd, kinds=('VB', 'prec', 'edge'), target_at='u', t1_plateau=False,
               pool='local'):
    """candidate coherent patterns per grid point.
    vertex e_j: the world-j-best model B^j (forced by strict (G) and competitiveness on {j}).
    target point (u, or nearest interior grid point): T1 only.
    other points p, kinds: 'VB' D_{co(T1 u {p})}; 'prec' D_{p}; 'edge' D_{co({p} u {v_k: k in supp p})}.
    pool='global': every candidate pattern produced anywhere (vertices and T1 excluded) is
    offered at every non-vertex, non-target point."""
    pts, P_ = grd['pts'], grd['P']
    m = grd['m']
    if target_at == 'u':
        dist = [np.abs(p - 1 / 3).sum() if min(q) > 0 else 9 for p, q in zip(P_, pts)]
        tgt = int(np.argmin(dist))
    else:
        tgt = None
    T1 = ''.join(advice_of(V, g) for g in G)
    cands = []
    for n, (q, p) in enumerate(zip(pts, P_)):
        if q.count(0) == 2:
            cands.append([vertex_pattern(G, q.index(m))]); continue
        if n == tgt:
            cands.append([T1]); continue
        cs = []
        supp = [i for i in range(3) if q[i] > 0]
        if 'VB' in kinds and len(supp) == 3: cs.append(''.join(advice_of(list(V) + [p], g) for g in G))
        if 'prec' in kinds: cs.append(''.join(advice_of([p], g) for g in G))
        if 'edge' in kinds and len(supp) == 3: cs.append(''.join(advice_of([p] + [V[k] for k in supp], g) for g in G))
        if len(supp) == 2:
            i, j = supp; h = 1.0 / (2 * m)
            e = np.zeros(3); e[i] = 1; e[j] = -1        # direction along the edge
            for kd, (lo, hi) in (('seg', (-h, h)), ('segL', (-h, 0)), ('segR', (0, h)),
                                 ('seg2', (-2 * h, 2 * h))):
                if kd in kinds:
                    a_, b_ = p + lo * e, p + hi * e
                    if a_.min() < -1e-12 or b_.min() < -1e-12: continue
                    cs.append(''.join(advice_of([a_, b_], g) for g in G))
        if t1_plateau and len(supp) == 3: cs.append(T1)
        cs = list(dict.fromkeys(cs))
        cands.append(cs)
    if pool == 'global':
        allc = list(dict.fromkeys(c for n, cs in enumerate(cands) for c in cs
                                  if len(cs) > 1 or (n != tgt and pts[n].count(0) != 2)))
        for n in range(len(cands)):
            if pts[n].count(0) != 2 and n != tgt:
                cands[n] = list(allc)
    for cs in cands:
        for c in cs: assert coherent(c, G), c
    return cands, tgt, T1


def hamming(pat, r):
    out = set()
    N = len(pat)
    for cells in itertools.combinations(range(N), r):
        for repl in itertools.product(*[FLIP[pat[c]] for c in cells]):
            s = list(pat)
            for c, a in zip(cells, repl): s[c] = a
            out.add(''.join(s))
    return out


def family(cands, T1, G, r_sel=1, r_t1=2, extra=(), r_vx=0):
    base = list(dict.fromkeys([c for cs in cands for c in cs] + [T1]))
    F = set(base)
    for b in base:
        for r in range(1, r_sel + 1): F |= hamming(b, r)
    for r in range(1, r_t1 + 1): F |= hamming(T1, r)
    for j in range(3):
        for r in range(1, r_vx + 1): F |= hamming(vertex_pattern(G, j), r)
    F |= set(extra)
    F = base + sorted(F - set(base))
    coh = np.array([coherent(x, G) for x in F])
    return F, coh
