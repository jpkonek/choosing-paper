"""X3 additive search with competitor generation: z3 on the family F, then the exact MILP oracle
over ALL 3^N models; violators join F; repeat.  A final 'FULL-OK' means: an additive ranking on the
whole finite world (all 3^N models) with strict (G), (IB), transitivity, grid competitiveness (K),
protection (P), (C) for selected models, and the stated CL proxy.  NUMERICS (exact rational z3
model, oracle exact up to MILP tolerance 1e-7)."""
import argparse, time, json, numpy as np, z3
from cells import make_cells, grid, rank
from family import candidates, family
from oracle import LiteWorld, violations
from addz import AdditiveZ

ap = argparse.ArgumentParser()
ap.add_argument('--eps', type=float, default=0.3); ap.add_argument('--m', type=int, default=3)
ap.add_argument('--ntau', type=int, default=1); ap.add_argument('--delta', type=float, default=0.05)
ap.add_argument('--kinds', default='prec,seg,segL,segR'); ap.add_argument('--plateau', action='store_true')
ap.add_argument('--rsel', type=int, default=0); ap.add_argument('--rt1', type=int, default=1)
ap.add_argument('--rvx', type=int, default=0)
ap.add_argument('--cl', default=''); ap.add_argument('--rounds', type=int, default=150)
ap.add_argument('--out', default='')
a = ap.parse_args()
V, G, tags = make_cells(a.eps, a.ntau, a.delta)
grd = grid(a.m)
cands, tgt, T1 = candidates(V, G, grd, kinds=a.kinds.split(','), t1_plateau=a.plateau)
F, coh = family(cands, T1, G, r_sel=a.rsel, r_t1=a.rt1, r_vx=a.rvx)
W = LiteWorld(G, F, coh)
opts = dict(K=True, P=True, C=True)
if a.cl: opts['CL'] = a.cl
AD = AdditiveZ(W, grd, cands, opts, verbose=False)
t0 = time.time(); status = None
for rnd in range(a.rounds):
    ok, sol = AD.run(maxit=300)
    if not ok:
        status = 'UNSAT-on-F' if ok is False else 'UNKNOWN'; break
    L, sel = sol
    m = AD.S.model()
    tab = np.zeros((3, W.N, 3))
    for i in range(3):
        for c in range(W.N):
            for k in range(3):
                r = AD.rk[i, c, k]
                if r:
                    val = m.eval(AD.l[(i, c, r)], model_completion=True)
                    tab[i, c, k] = val.numerator_as_long() / val.denominator_as_long()
    selp = [W.F[C] for C in sel]
    viol = violations(tab, G, grd, selp, opts)
    print(f'round {rnd}: |F|={W.nF} oracle violations={len(viol)} {[(k, v) for k, v, _ in viol][:8]} {time.time()-t0:.1f}s', flush=True)
    if not viol:
        status = 'FULL-OK'; break
    for _, _, x in viol: W.add(x)
    if a.out: json.dump(dict(F=W.F), open(a.out.replace('.json', '_F.json'), 'w'))
print('ADDFULL', status, vars(a), f'{time.time()-t0:.1f}s')
if status == 'FULL-OK':
    for v, s in enumerate(selp): print('  sel', grd['pts'][v], s)
    if a.out:
        json.dump(dict(args=vars(a), tab=tab.tolist(), sel=selp, tags=tags, G=[list(g) for g in G]), open(a.out, 'w'))
