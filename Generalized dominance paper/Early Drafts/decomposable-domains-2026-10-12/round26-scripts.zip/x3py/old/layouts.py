import numpy as np
from geom import t1_vertices, facet_point, advice_of

def facet_cells(V, taus, delta, sides=('in', 'out')):
    """cells h(tau) +/- delta*1 on each facet of D_conv(V) (cells are oriented gambles)."""
    G = []; tags = []
    for k in range(3):
        for tau in taus:
            h, _ = facet_point(V, k, tau)
            for s in sides:
                g = h + (delta if s == 'in' else -delta) * np.ones(3)
                G.append(g); tags.append(f'F{k}t{tau}{s}')
    return G, tags

def target_pattern(K, G):
    return ''.join(advice_of(K, g) for g in G)
