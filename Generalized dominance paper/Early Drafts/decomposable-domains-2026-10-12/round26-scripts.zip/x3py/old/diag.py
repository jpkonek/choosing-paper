"""Item (c): additive-endorsement diagnostic applied AFTER a SAT solution (NUMERICS).

For world i and a set of accepted trade records r (records that are neither pure worsenings nor
pure improvements at world i), ask for penalties l(c,a), strictly increasing in world-i rank
(increments >= 1), with sum_{c in supp r} l(c,y_c) - l(c,x_c) >= 0 for every accepted r.
This is the finite analogue of 'world i adds up' (a strictly positive endorsing weight).
If infeasible, a deletion filter extracts a minimal infeasible set of accepted comparisons
(a finite (M1)-type certificate).
"""
import numpy as np
from scipy.optimize import linprog
from geom import rank


def trade_rows(fm, i, recs):
    idx = {}; n = 0
    for c in range(fm.N):
        for a in range(fm.k[c]):
            idx[(c, a)] = n; n += 1
    rows = []
    for r in recs:
        row = np.zeros(n)
        for c in range(fm.N):
            pr = fm.pair_of[c][fm.codes[r, c]]
            if pr is not None:
                row[idx[(c, pr[1])]] += 1; row[idx[(c, pr[0])]] -= 1
        rows.append(row)
    inc = []
    for c in range(fm.N):
        order = sorted(range(fm.k[c]), key=lambda a: rank(fm.A[c][a], fm.G[c], i))
        for a, b in zip(order, order[1:]):
            row = np.zeros(n); row[idx[(c, b)]] = 1; row[idx[(c, a)]] = -1; inc.append(row)
    return np.array(rows).reshape(-1, n), np.array(inc), n


def endorsable(fm, i, recs):
    rows, inc, n = trade_rows(fm, i, recs)
    A = np.vstack([-rows, -inc]) if len(rows) else -inc
    b = np.concatenate([np.zeros(len(rows)), -np.ones(len(inc))])
    res = linprog(np.zeros(n), A_ub=A, b_ub=b, bounds=[(0, 1e4)] * n, method='highs')
    return res.status == 0


def minimal_obstruction(fm, i, recs):
    cur = list(recs)
    if endorsable(fm, i, cur): return None
    k = 0
    while k < len(cur):
        trial = cur[:k] + cur[k + 1:]
        if not endorsable(fm, i, trial): cur = trial
        else: k += 1
    return cur


def accepted_trades(S, vals, i, only=None):
    fm = S.fm
    free = (fm.fixed[i] == 0) & vals[i]
    recs = np.where(free)[0]
    if only is not None:
        recs = np.intersect1d(recs, only)
    return recs
