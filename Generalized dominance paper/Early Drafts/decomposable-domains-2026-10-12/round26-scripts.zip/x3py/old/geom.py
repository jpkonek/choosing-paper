"""X3 finite model: geometry, cells, coherence (NUMERICS tooling).

Finite model FM: worlds 0,1,2; finitely many binary problems ("cells"), each a
representative mixed gamble g_c in R^3 (orientation fixed); advice range A(c) a
subset of '+0-x'.  '+' = accept g_c only, '-' = accept -g_c only, '0' = neither,
'x' = both.  Unanimous problems are omitted (every evaluable model gives the
correct advice there; they never distinguish models).
"""
import itertools, numpy as np
from scipy.optimize import linprog

ADV = '+0-x'

def t1_vertices(eps):
    c0 = (1 - eps) / 3
    return [c0 * np.ones(3) + eps * np.eye(3)[k] for k in range(3)]

def P(K, g):
    return min(float(np.dot(m, g)) for m in K)

def advice_of(K, g, tol=1e-12):
    a, b = P(K, g), P(K, -np.asarray(g))
    if a > tol and b > tol: return 'x'
    if a > tol: return '+'
    if b > tol: return '-'
    return '0'

def rank(adv, g, i):
    """world-i rank: 0 good, 1 silence, 2 bad, 3 contradictory"""
    if adv == '0': return 1
    if adv == 'x': return 3
    s = g[i] if adv == '+' else -g[i]
    return 0 if s > 0 else 2

def facet_point(V, k, tau):
    """point on facet F_k of D_T (T = conv V) at parameter tau in [0,1] between its corner rays."""
    others = [j for j in range(3) if j != k]
    r = [np.cross(V[k], V[j]) for j in others]
    out = []
    for idx, j in enumerate(others):
        rr = r[idx]
        l = [m for m in others if m != j][0]
        if np.dot(rr, V[l]) < 0: rr = -rr
        out.append(rr / np.abs(rr).max())
    return (1 - tau) * out[0] + tau * out[1], out

def coherent(pattern, G, delta=1e-7):
    """Is the advice pattern (list over cells) realisable as D_K restricted to cells, K a credal set?
    Acc = {g: '+'} u {-g: '-'}; rejected = {g,-g : '0'}.  Coherent iff for each rejected h some
    m in Delta has m.x >= delta (x in Acc) and m.h <= 0 (witness form; Prop 1.1 of C2 notes), and
    the acceptance region is nonempty."""
    if 'x' in pattern: return False
    acc, rej = [], []
    for a, g in zip(pattern, G):
        g = np.asarray(g, float)
        if a == '+': acc.append(g)
        elif a == '-': acc.append(-g)
        else: rej += [g, -g]
    A = np.array(acc) if acc else np.zeros((0, 3))
    tests = rej if rej else [None]
    for h in tests:
        # maximise t s.t. m in Delta, m.x >= t, m.h <= 0 ; variables (m1,m2,m3,t)
        Aub, bub = [], []
        for x in A: Aub.append([-x[0], -x[1], -x[2], 1.0]); bub.append(0.0)
        if h is not None: Aub.append([h[0], h[1], h[2], 0.0]); bub.append(0.0)
        if not Aub: return True
        res = linprog([0, 0, 0, -1], A_ub=Aub, b_ub=bub, A_eq=[[1, 1, 1, 0]], b_eq=[1],
                      bounds=[(0, 1)] * 3 + [(None, 1)], method='highs')
        if res.status != 0: return False
        if len(A) and -res.fun < delta: return False
    return True

def grid(m):
    """vertices of the m-th triangulation of Delta, and all faces (vertex tuples) with supports."""
    pts = [(a, b, m - a - b) for a in range(m + 1) for b in range(m + 1 - a)]
    idx = {p: n for n, p in enumerate(pts)}
    tris = []
    for a in range(m):
        for b in range(m - a):
            c = m - a - b
            tris.append((idx[(a + 1, b, c - 1)], idx[(a, b + 1, c - 1)], idx[(a, b, c)]))
            if c - 1 >= 1 and a + 1 + b + 1 <= m:
                tris.append((idx[(a + 1, b, c - 1)], idx[(a, b + 1, c - 1)], idx[(a + 1, b + 1, c - 2)]))
    faces = set()
    for t in tris:
        for r in (1, 2, 3):
            for f in itertools.combinations(sorted(t), r):
                faces.add(f)
    P_ = [np.array(p, float) / m for p in pts]
    def supp(f):
        s = set()
        for v in f: s |= {i for i in range(3) if pts[v][i] > 0}
        return tuple(sorted(s))
    faces = sorted(faces, key=lambda f: (len(f), f))
    return P_, pts, [(f, supp(f)) for f in faces]
