import sys, time, argparse, numpy as np
from geom import *
from targets import *
from engine import FM
from additive import Additive
ap = argparse.ArgumentParser()
ap.add_argument('--target', default='T1'); ap.add_argument('--eps', type=float, default=0.3)
ap.add_argument('--mode', default='vertex'); ap.add_argument('--m', type=int, default=3)
ap.add_argument('--n', type=int, default=6); ap.add_argument('--delta', type=float, default=0.05)
ap.add_argument('--maxit', type=int, default=60)
a = ap.parse_args()
K = target(a.target, a.eps)
G, tags = boundary_cells(K, a.n // 2, a.delta)
fm = FM(G, ['+0-'] * len(G))
tp = ''.join(advice_of(K, g) for g in G)
grid_ = grid(a.m); P_, pts, faces = grid_
coh = list(np.where(fm.coh)[0])
cands = [[fm.vertex_model(p.index(a.m))] if p.count(0) == 2 else ([fm.index[tp]] if p[0]==p[1]==p[2] else coh) for p in pts]
AD = Additive(fm, grid_, cands, mode=a.mode)
ok, sol = AD.run(maxit=a.maxit)
print('ADDITIVE RESULT', a.target, a.mode, 'm', a.m, ok)
if ok:
    x, L, sel = sol
    print('selection', [(pts[v], fm.adv[sel[v]]) for v in range(len(pts))])
