import sys, numpy as np
from geom import *
from layouts import *
from engine import FM, Search, core_keys, minimize_core
eps=0.3; V=t1_vertices(eps)
G, tags = facet_cells(V, [0.5], 0.05)
fm = FM(G, ['+0-']*6)
tp = target_pattern(V, G)
grid_ = grid(3); P_, pts, faces = grid_
coh = list(np.where(fm.coh)[0])
cands = [[fm.vertex_model(p.index(3))] if p.count(0)==2 else ([fm.index[tp]] if p==(1,1,1) else coh) for p in pts]
S = Search(fm, grid_, cands, mode=sys.argv[1], use_activation=True)
ok, model = S.run(maxit=400)
print('RESULT', ok)
if ok is False:
    keys = core_keys(S); print('core size', len(keys))
    mus = minimize_core(S, keys)
    print('MUS size', len(mus))
    for k in mus:
        if k[0]=='K':
            f,supp = S.kfaces[k[1]]; print('K face', [pts[v] for v in f], 'supp', supp, 'X=', fm.adv[k[2]], 'coh' if fm.coh[k[2]] else 'incoh')
        else:
            print(k[0], 'C=', fm.adv[k[1]], 'X=', fm.adv[k[2]])
