"""X3 finite search engine for joint three-world comparison systems (NUMERICS tooling).

Variables: le[i][r] = "transition record r is accepted at world i" (X <=_i Y iff le[i][d(X,Y)]).
(IB) is built in (acceptance depends on the record only).  Strict (G): records that only worsen
at world i are fixed TRUE, records that only improve are fixed FALSE, identity TRUE.
Lazily generated (CEGAR) axiom instances, every one sound for the finite model:
  (T)  transitivity  le(d(X,Y)) & le(d(Y,Z)) -> le(d(X,Z))       [realizable composition]
  (K)  competitiveness surrogate (vertex or simplicial form, see X3_notes.md)
  (P)  protection of selected models
  (C)  incoherent models never tie a selected model at every world
Selection: sel[v][C] for grid vertex v and candidate coherent model C (at least one per vertex).
"""
import itertools, time, numpy as np
from pysat.solvers import Solver
from geom import ADV, rank, coherent

T = 2 ** 30


class FM:
    def __init__(self, G, A, verbose=True):
        self.G = [np.asarray(g, float) for g in G]
        self.A = list(A)
        self.N = len(G)
        self.k = [len(a) for a in A]
        # models
        self.digits = np.array(list(itertools.product(*[range(k) for k in self.k])), dtype=np.int64)
        self.nM = len(self.digits)
        self.adv = [''.join(self.A[c][d] for c, d in enumerate(row)) for row in self.digits]
        self.index = {a: n for n, a in enumerate(self.adv)}
        # records: per-cell codes, 0 = identity, else ordered pair (x,y), x != y
        self.ncode = [k * (k - 1) + 1 for k in self.k]
        self.base = np.cumprod([1] + self.ncode[:-1]).astype(np.int64)
        self.R = int(np.prod(self.ncode))
        self.pair_of = []   # per cell: code -> (x,y) or None
        self.code_tab = []  # per cell: k x k table
        for c, k in enumerate(self.k):
            tab = np.zeros((k, k), np.int64); po = [None]; n = 1
            for x in range(k):
                for y in range(k):
                    if x != y: tab[x, y] = n; po.append((x, y)); n += 1
            self.code_tab.append(tab); self.pair_of.append(po)
        rec = np.zeros((self.nM, self.nM), np.int64)
        for c in range(self.N):
            d = self.digits[:, c]
            rec += self.code_tab[c][d[:, None], d[None, :]] * self.base[c]
        self.rec = rec
        # per world per cell per code: direction +1 worse, -1 better, 0 id
        codes = (np.arange(self.R)[:, None] // self.base[None, :]) % np.array(self.ncode)[None, :]
        self.codes = codes
        self.fixed = []
        for i in range(3):
            up = np.zeros(self.R, np.int64); dn = np.zeros(self.R, np.int64)
            for c in range(self.N):
                dirs = np.zeros(self.ncode[c], np.int64)
                for code, pr in enumerate(self.pair_of[c]):
                    if pr is None: continue
                    rx = rank(self.A[c][pr[0]], self.G[c], i); ry = rank(self.A[c][pr[1]], self.G[c], i)
                    dirs[code] = 1 if ry > rx else -1
                dc = dirs[codes[:, c]]
                up += dc > 0; dn += dc < 0
            f = np.zeros(self.R, np.int8)
            f[(dn == 0)] = 1            # identity or worsening: accepted
            f[(up == 0) & (dn > 0)] = -1  # strict improvement: forbidden
            self.fixed.append(f)
        self.nvar = 0
        self.lit = []
        for i in range(3):
            l = np.where(self.fixed[i] == 1, T, np.where(self.fixed[i] == -1, -T, 0)).astype(np.int64)
            free = np.where(self.fixed[i] == 0)[0]
            l[free] = np.arange(self.nvar + 1, self.nvar + 1 + len(free))
            self.nvar += len(free)
            self.lit.append(l)
        # coherence of all models
        self.coh = np.array([coherent(a, self.G) for a in self.adv])
        if verbose:
            print(f'FM: N={self.N} |M|={self.nM} R={self.R} free record vars={self.nvar} coherent={self.coh.sum()}')

    def newvar(self):
        self.nvar += 1
        return self.nvar

    def describe_record(self, r):
        out = []
        for c in range(self.N):
            pr = self.pair_of[c][self.codes[r, c]]
            if pr is not None:
                out.append(f'c{c}:{self.A[c][pr[0]]}>{self.A[c][pr[1]]}')
        return ' '.join(out) if out else 'id'

    def vertex_model(self, i):
        a = ''
        for c in range(self.N):
            g = self.G[c]
            a += '+' if g[i] > 0 else '-'
        return self.index[a]


def simp(clause):
    """drop FALSE literals, return None if some literal TRUE"""
    out = []
    for l in clause:
        if l == T: return None
        if l == -T: continue
        out.append(int(l))
    return out


class Search:
    def __init__(self, fm, grid, cand, mode='simplicial', solver='g4', phases_false=True,
                 use_activation=False, verbose=True):
        """grid = (P_, pts, faces); cand[v] = list of model indices (len 1 = fixed)."""
        self.fm = fm; self.P_, self.pts, self.faces = grid
        self.cand = cand; self.mode = mode; self.verbose = verbose
        self.S = Solver(name=solver)
        self.use_act = use_activation
        self.act = {}            # instance key -> activation literal
        self.sel = {}
        for v, cs in enumerate(cand):
            if len(cs) == 1:
                self.sel[(v, cs[0])] = T
            else:
                lits = []
                for C in cs:
                    x = fm.newvar(); self.sel[(v, C)] = x; lits.append(x)
                self.S.add_clause(lits)
        self.selany = {}
        for (v, C), x in self.sel.items():
            if C not in self.selany:
                self.selany[C] = T if x == T else fm.newvar()
            if x != T and self.selany[C] != T:
                self.S.add_clause([-x, self.selany[C]])
        self.added = set()
        self.ntrans = 0; self.ninst = 0
        if phases_false:
            self.S.set_phases([-v for v in range(1, fm.nvar + 1)])
        self.phases_false = phases_false
        self.disabled = set()
        self.ucache = {}
        if mode == 'simplicial':
            self.kfaces = self.faces
        else:
            self.kfaces = [(f, s) for f, s in self.faces if len(f) == 1]

    # ---- literal helpers
    def L(self, i, X, Y):
        return int(self.fm.lit[i][self.fm.rec[X, Y]])

    def actlit(self, key):
        if not self.use_act: return None
        if key not in self.act:
            self.act[key] = self.fm.newvar()
        return self.act[key]

    def add(self, clause, key=None):
        c = simp(clause)
        if c is None: return
        if key is not None and self.use_act:
            c = c + [-self.actlit(key)]
        if len(c) == 0:
            c = [self.fm.newvar()]; self.S.add_clause(c); self.S.add_clause([-c[0]])  # empty clause
            return
        self.S.add_clause(c)

    # ---- instance generators
    def add_K(self, fidx, X):
        key = ('K', fidx, X)
        if key in self.added: return
        self.added.add(key); self.ninst += 1
        f, supp = self.kfaces[fidx]
        ws = []
        for i in supp:
            w = self.fm.newvar(); ws.append(w)
            for v in f:
                u = self.ulit(v, X, i)
                if u == T: continue
                if u == -T: self.add([-w]); break
                self.add([-w, u])
        self.add(ws, key)

    def ulit(self, v, X, i):
        """literal u[v,X,i] implying 'C_v <=_i X' (shared by all faces containing v)."""
        key = (v, X, i)
        if key in self.ucache: return self.ucache[key]
        cs = self.cand[v]
        if len(cs) == 1:
            u = self.L(i, cs[0], X)
        else:
            u = self.fm.newvar()
            for C in cs:
                self.add([-u, -self.sel[(v, C)], self.L(i, C, X)])
        self.ucache[key] = u
        return u

    def add_P(self, C, X):
        key = ('P', C, X)
        if key in self.added: return
        self.added.add(key); self.ninst += 1
        sa = self.selany[C]
        pre = [-sa if sa != T else -T] + [-self.L(i, X, C) for i in range(3)]
        for j in range(3):
            self.add(pre + [self.L(j, C, X)], key)

    def add_C(self, C, X):
        key = ('C', C, X)
        if key in self.added: return
        self.added.add(key); self.ninst += 1
        sa = self.selany[C]
        cl = [-sa if sa != T else -T] + [-self.L(i, X, C) for i in range(3)] + [-self.L(i, C, X) for i in range(3)]
        self.add(cl, key)

    # ---- model evaluation
    def values(self, model):
        mv = np.zeros(self.fm.nvar + 2, bool)
        pos = [l for l in model if l > 0]
        mv[np.array(pos, dtype=np.int64)] = True
        vals = []
        for i in range(3):
            l = self.fm.lit[i]
            v = np.where(l == T, True, np.where(l == -T, False, mv[np.clip(l, 0, len(mv) - 1)]))
            vals.append(v)
        return vals, mv

    def selection(self, mv):
        selv = []
        for v, cs in enumerate(self.cand):
            ch = [C for C in cs if self.sel[(v, C)] == T or mv[self.sel[(v, C)]]]
            selv.append(ch)
        return selv

    def check(self, model, cap=4000):
        fm = self.fm
        vals, mv = self.values(model)
        Adj = [vals[i][fm.rec] for i in range(3)]
        nadd = 0
        # (T) transitivity
        for i in range(3):
            A = Adj[i].astype(np.float32)
            two = (A @ A) > 0.5
            viol = np.argwhere(two & ~Adj[i])
            if len(viol):
                np.random.shuffle(viol)
                for X, Z in viol[:cap]:
                    Ys = np.where(Adj[i][X, :] & Adj[i][:, Z])[0]
                    Y = Ys[np.random.randint(len(Ys))]
                    key = ('T', i, fm.rec[X, Y], fm.rec[Y, Z], fm.rec[X, Z])
                    if key in self.added: continue
                    self.added.add(key); self.ntrans += 1
                    self.add([-self.L(i, X, Y), -self.L(i, Y, Z), self.L(i, X, Z)])
                    nadd += 1
        if nadd:
            return nadd, 'T'
        selv = self.selection(mv)
        # (K)
        for fidx, (f, supp) in enumerate(self.kfaces):
            ok = np.zeros(fm.nM, bool)
            for i in supp:
                a = np.ones(fm.nM, bool)
                for v in f:
                    for C in selv[v]:
                        a &= Adj[i][C, :]
                ok |= a
            bad = np.where(~ok)[0]
            for X in bad[:cap]:
                self.add_K(fidx, X); nadd += 1
        # (P) and (C)
        selected = sorted({C for ch in selv for C in ch})
        for C in selected:
            le_XC = Adj[0][:, C] & Adj[1][:, C] & Adj[2][:, C]
            le_CX = Adj[0][C, :] & Adj[1][C, :] & Adj[2][C, :]
            for X in np.where(le_XC & ~le_CX)[0][:cap]:
                self.add_P(C, X); nadd += 1
            for X in np.where(le_XC & le_CX & ~fm.coh)[0][:cap]:
                self.add_C(C, X); nadd += 1
        return nadd, 'KPC'

    def solve_fixed(self, asm, maxit=300):
        """solve with the given activation assumptions, adding only transitivity clauses lazily.
        Returns False (UNSAT), True (SAT with transitive orders), None (undecided)."""
        for it in range(maxit):
            if not self.S.solve(assumptions=asm):
                return False
            model = self.S.get_model()
            nadd = self.check_T(model)
            if nadd == 0:
                return True
        return None

    def check_T(self, model, cap=4000):
        fm = self.fm
        vals, mv = self.values(model)
        nadd = 0
        for i in range(3):
            Adj = vals[i][fm.rec]
            A = Adj.astype(np.float32)
            two = (A @ A) > 0.5
            viol = np.argwhere(two & ~Adj)
            np.random.shuffle(viol)
            for X, Z in viol[:cap]:
                Ys = np.where(Adj[X, :] & Adj[:, Z])[0]
                Y = Ys[np.random.randint(len(Ys))]
                key = ('T', i, fm.rec[X, Y], fm.rec[Y, Z], fm.rec[X, Z])
                if key in self.added: continue
                self.added.add(key); self.ntrans += 1
                self.add([-self.L(i, X, Y), -self.L(i, Y, Z), self.L(i, X, Z)])
                nadd += 1
        return nadd

    def run(self, maxit=500, assumptions=None, tlimit=1e9):
        t0 = time.time(); it = 0
        while it < maxit and time.time() - t0 < tlimit:
            it += 1
            asm = list(assumptions or [])
            if self.use_act and assumptions is None:
                asm = [a for k, a in self.act.items() if k not in self.disabled]
            ok = self.S.solve(assumptions=asm)
            if not ok:
                if self.verbose: print(f'  UNSAT at it {it}  trans={self.ntrans} inst={self.ninst}  {time.time()-t0:.1f}s')
                return False, None
            model = self.S.get_model()
            nadd, kind = self.check(model)
            if self.verbose and (it % 10 == 0 or nadd == 0):
                print(f'  it {it}: added {nadd} ({kind}) trans={self.ntrans} inst={self.ninst} {time.time()-t0:.1f}s')
            if nadd == 0:
                return True, model
        return None, None


def core_keys(S):
    """keys of the activation literals in the final conflict (needs use_activation=True)."""
    core = S.S.get_core() or []
    inv = {a: k for k, a in S.act.items()}
    return [inv[a] for a in core if a in inv]


def minimize_core(S, keys, maxit=300):
    """deletion-based MUS over instance keys: drop a key, re-run CEGAR (transitivity clauses are
    global axioms and stay); keep the drop if still UNSAT.  Instances are disabled, not deleted.
    Note: while minimising, the generator still adds *new* instances only via check(); we freeze
    instance generation by disabling every key outside the current candidate set."""
    cur = list(keys)
    i = 0
    while i < len(cur):
        trial = cur[:i] + cur[i + 1:]
        asm = [S.act[k] for k in trial]
        res = S.solve_fixed(asm, maxit=maxit)
        if res is False:
            core = set(core_keys(S)); cur = [k for k in trial if k in core] or trial
        else:
            i += 1
    return cur
