"""Additive restriction of the X3 finite problem (item (d)); MILP with lazy constraints (NUMERICS).

World i: L_i(X) = sum_c l_i(c, X(c)), l_i(c,.) strictly increasing in world-i rank (increments >= 1),
0 <= l <= LMAX.  Complete orders X <=_i Y iff L_i(X) <= L_i(Y).  Same selection candidates and the
same competitiveness surrogate as the SAT engine.  Protection is imposed in the slightly stronger
form 'every X != C is strictly worse than C at some world by >= DELTA' (exact everywhere-ties are
excluded; for complete additive orders they are non-generic).  (C) is then automatic.
"""
import numpy as np, time
from scipy.optimize import milp, LinearConstraint, Bounds
from geom import rank

LMAX = 20.0; DELTA = 0.5


class Additive:
    def __init__(self, fm, grid, cand, mode='simplicial', verbose=True):
        self.fm = fm; self.P_, self.pts, self.faces = grid; self.cand = cand
        self.kfaces = self.faces if mode == 'simplicial' else [(f, s) for f, s in self.faces if len(f) == 1]
        self.verbose = verbose
        # variable layout: l[i][c][a]
        self.lidx = {}; n = 0
        for i in range(3):
            for c in range(fm.N):
                for a in range(fm.k[c]):
                    self.lidx[(i, c, a)] = n; n += 1
        self.nl = n
        self.selidx = {}
        for v, cs in enumerate(cand):
            if len(cs) > 1:
                for C in cs:
                    self.selidx[(v, C)] = n; n += 1
        self.n = n
        self.rows = []  # (dict coeffs, lb, ub)
        self.integrality = [0] * self.nl + [1] * (n - self.nl)
        # strict guidance increments
        for i in range(3):
            for c in range(fm.N):
                order = sorted(range(fm.k[c]), key=lambda a: rank(fm.A[c][a], fm.G[c], i))
                for a, b in zip(order, order[1:]):
                    self.rows.append(({self.lidx[(i, c, b)]: 1, self.lidx[(i, c, a)]: -1}, 1.0, np.inf))
        for v, cs in enumerate(cand):
            if len(cs) > 1:
                self.rows.append(({self.selidx[(v, C)]: 1 for C in cs}, 1.0, 1.0))
        self.Mbig = LMAX * fm.N + 1
        self.inst = set()

    def newbin(self):
        self.integrality.append(1); self.n += 1
        return self.n - 1

    def Ldiff(self, i, C, X):
        """coefficients of L_i(C) - L_i(X)"""
        d = {}
        for c in range(self.fm.N):
            a, b = self.fm.digits[C, c], self.fm.digits[X, c]
            if a != b:
                d[self.lidx[(i, c, a)]] = d.get(self.lidx[(i, c, a)], 0) + 1
                d[self.lidx[(i, c, b)]] = d.get(self.lidx[(i, c, b)], 0) - 1
        return d

    def add_K(self, fidx, X):
        if ('K', fidx, X) in self.inst: return
        self.inst.add(('K', fidx, X))
        f, supp = self.kfaces[fidx]; zs = []
        for i in supp:
            z = self.newbin(); zs.append(z)
            for v in f:
                for C in self.cand[v]:
                    d = self.Ldiff(i, C, X)
                    # L_i(C)-L_i(X) <= M(2 - z - s)
                    d = dict(d); d[z] = d.get(z, 0) + self.Mbig
                    ub = 2 * self.Mbig
                    if (v, C) in self.selidx:
                        d[self.selidx[(v, C)]] = self.Mbig
                    else:
                        ub = self.Mbig
                    self.rows.append((d, -np.inf, ub))
        self.rows.append(({z: 1 for z in zs}, 1.0, np.inf))

    def add_P(self, v, C, X):
        if ('P', v, C, X) in self.inst: return
        self.inst.add(('P', v, C, X))
        ys = []
        for i in range(3):
            y = self.newbin(); ys.append(y)
            d = {k: -val for k, val in self.Ldiff(i, C, X).items()}  # L_i(X)-L_i(C)
            d[y] = d.get(y, 0) - self.Mbig                             # >= DELTA - M(1-y)
            self.rows.append((d, DELTA - self.Mbig, np.inf))
        d = {y: 1 for y in ys}
        if (v, C) in self.selidx:
            d[self.selidx[(v, C)]] = -1
            self.rows.append((d, 0.0, np.inf))
        else:
            self.rows.append((d, 1.0, np.inf))

    def solve_once(self, tlim=600):
        import scipy.sparse as sp
        r, cidx, vals, lb, ub = [], [], [], [], []
        for k, (d, l, u) in enumerate(self.rows):
            for j, val in d.items():
                r.append(k); cidx.append(j); vals.append(val)
            lb.append(l); ub.append(u)
        A = sp.csr_matrix((vals, (r, cidx)), shape=(len(self.rows), self.n))
        lo = np.zeros(self.n); hi = np.ones(self.n); hi[:self.nl] = LMAX
        c = np.zeros(self.n); c[:self.nl] = 1e-3  # mild preference for small penalties
        res = milp(c, constraints=LinearConstraint(A, lb, ub), bounds=Bounds(lo, hi),
                   integrality=np.array(self.integrality), options={'time_limit': tlim, 'disp': False})
        return res

    def losses(self, x):
        fm = self.fm
        L = np.zeros((3, fm.nM))
        for i in range(3):
            for c in range(fm.N):
                tab = np.array([x[self.lidx[(i, c, a)]] for a in range(fm.k[c])])
                L[i] += tab[fm.digits[:, c]]
        return L

    def run(self, maxit=60, cap=300, tol=1e-6):
        t0 = time.time()
        for it in range(maxit):
            res = self.solve_once()
            if res.status == 2 or res.x is None:
                if self.verbose: print(f'  additive: infeasible/none at it {it} status={res.status} inst={len(self.inst)} {time.time()-t0:.1f}s')
                return False if res.status == 2 else None, None
            x = res.x; L = self.losses(x)
            sel = []
            for v, cs in enumerate(self.cand):
                sel.append(cs[0] if len(cs) == 1 else max(cs, key=lambda C: x[self.selidx[(v, C)]]))
            nadd = 0
            for fidx, (f, supp) in enumerate(self.kfaces):
                ok = np.zeros(self.fm.nM, bool)
                for i in supp:
                    a = np.ones(self.fm.nM, bool)
                    for v in f: a &= L[i][sel[v]] <= L[i] + tol
                    ok |= a
                for X in np.where(~ok)[0][:cap]:
                    self.add_K(fidx, X); nadd += 1
            for v in range(len(self.cand)):
                C = sel[v]
                worse = np.zeros(self.fm.nM, bool)
                for i in range(3): worse |= L[i] >= L[i][C] + DELTA - tol
                bad = np.where(~worse)[0]; bad = bad[bad != C]
                for X in bad[:cap]:
                    self.add_P(v, C, X); nadd += 1
            if self.verbose: print(f'  additive it {it}: added {nadd}, inst={len(self.inst)} {time.time()-t0:.1f}s')
            if nadd == 0:
                return True, (x, L, sel)
        return None, None
