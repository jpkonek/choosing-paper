import numpy as np
from geom import t1_vertices

def box_vertices(e):
    """normalised box at u (Neutral Abstention Thm 1): M_e = {m: m_i >= e m_j}; a hexagon, covered."""
    V = []
    for k in range(3):
        v = np.full(3, e); v[k] = 1; V.append(v / v.sum())
        w = np.ones(3); w[k] = e; V.append(w / w.sum())
    return V

def target(name, eps=0.3):
    if name == 'T1': return t1_vertices(eps)
    if name == 'precise': return [np.ones(3) / 3]
    if name.startswith('box'): return box_vertices(float(name[3:]))
    raise ValueError(name)

def boundary_cells(K, nper, delta, seed=0, kind='facet'):
    """cells g +/- delta*1 with g on the boundary of D_K (P_K(g)=0), sampled at evenly spaced
    directions of the boundary cone.  Boundary of D_K: {g: min_m m.g = 0}.  Parametrise directions
    in 1-perp by angle phi, g = d(phi) + t*1 with t = -min_m m.d."""
    o = np.ones(3) / np.sqrt(3)
    a = np.array([1, -1, 0]) / np.sqrt(2); b = np.cross(o, a)
    G, tags = [], []
    phis = np.linspace(0, 2 * np.pi, nper, endpoint=False) + 0.5 * 2 * np.pi / nper
    for phi in phis:
        d = np.cos(phi) * a + np.sin(phi) * b
        t = -min(float(np.dot(m, d)) for m in K)
        g = d + t * np.ones(3)
        g = g / np.abs(g).max()
        for s, sg in (('in', 1), ('out', -1)):
            G.append(g + sg * delta * np.ones(3)); tags.append(f'phi{phi:.2f}{s}')
    return G, tags
