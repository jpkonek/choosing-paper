import sys, time, argparse, numpy as np
from geom import *
from targets import *
from engine import FM, Search, core_keys, minimize_core
ap = argparse.ArgumentParser()
ap.add_argument('--target', default='T1'); ap.add_argument('--eps', type=float, default=0.3)
ap.add_argument('--mode', default='simplicial'); ap.add_argument('--m', type=int, default=3)
ap.add_argument('--n', type=int, default=6); ap.add_argument('--delta', type=float, default=0.05)
ap.add_argument('--range', default='+0-'); ap.add_argument('--core', action='store_true')
ap.add_argument('--maxit', type=int, default=400)
a = ap.parse_args()
K = target(a.target, a.eps)
G, tags = boundary_cells(K, a.n // 2, a.delta)
G = [g for g in G if (g > 0).any() and (g < 0).any()]
fm = FM(G, [a.range] * len(G))
tp = ''.join(advice_of(K, g) for g in G)
print('target', a.target, 'pattern', tp, 'cells', [tuple(np.round(g, 2)) for g in G])
grid_ = grid(a.m); P_, pts, faces = grid_
coh = list(np.where(fm.coh)[0])
cands = []
for p in pts:
    if p.count(0) == 2: cands.append([fm.vertex_model(p.index(a.m))])
    elif p[0] == p[1] == p[2]: cands.append([fm.index[tp]])
    else: cands.append(coh)
S = Search(fm, grid_, cands, mode=a.mode, use_activation=a.core)
t0 = time.time()
ok, model = S.run(maxit=a.maxit)
print('RESULT', a.target, a.mode, 'm', a.m, 'N', len(G), ok, f'{time.time()-t0:.1f}s')
if ok is False and a.core:
    keys = core_keys(S); mus = minimize_core(S, keys)
    print('MUS size', len(mus))
    for k in mus:
        if k[0] == 'K':
            f, supp = S.kfaces[k[1]]
            print('  K face', [pts[v] for v in f], 'supp', supp, 'X=', fm.adv[k[2]], 'coh' if fm.coh[k[2]] else 'incoh')
        else:
            print(' ', k[0], 'C=', fm.adv[k[1]], 'X=', fm.adv[k[2]])
if ok:
    vals, mv = S.values(model); selv = S.selection(mv)
    print('selection:', [(pts[v], [fm.adv[C] for C in selv[v]]) for v in range(len(pts))])
