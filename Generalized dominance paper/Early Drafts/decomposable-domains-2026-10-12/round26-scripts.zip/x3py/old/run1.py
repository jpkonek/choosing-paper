import sys, time, numpy as np
from geom import *
from layouts import *
from engine import FM, Search

eps = float(sys.argv[1]) if len(sys.argv) > 1 else 0.3
mode = sys.argv[2] if len(sys.argv) > 2 else 'simplicial'
m = int(sys.argv[3]) if len(sys.argv) > 3 else 3
taus = [float(t) for t in (sys.argv[4].split(',') if len(sys.argv) > 4 else ['0.5'])]
delta = float(sys.argv[5]) if len(sys.argv) > 5 else 0.05
V = t1_vertices(eps)
G, tags = facet_cells(V, taus, delta)
A = ['+0-'] * len(G)
fm = FM(G, A)
tp = target_pattern(V, G); print('T1 pattern', tp, tags)
grid_ = grid(m)
P_, pts, faces = grid_
cands = []
cohidx = list(np.where(fm.coh)[0])
for v, p in enumerate(pts):
    if p.count(0) == 2:
        cands.append([fm.vertex_model(p.index(m))])
    elif p[0] == p[1] == p[2]:
        cands.append([fm.index[tp]])
    else:
        cands.append(cohidx)
S = Search(fm, grid_, cands, mode=mode)
ok, model = S.run(maxit=400)
print('RESULT', ok)
