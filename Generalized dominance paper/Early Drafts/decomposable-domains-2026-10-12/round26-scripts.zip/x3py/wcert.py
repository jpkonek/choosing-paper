"""Instance-level certificate for the (P,C,W) core: which X cannot be weakly dominated by any
protected coherent member of F (NUMERICS)."""
import sys, time, numpy as np
from cells import make_cells, grid
from family import candidates, family
from satx import World, Search
eps = float(sys.argv[1]) if len(sys.argv) > 1 else 0.3
V, G, tags = make_cells(eps, 1, 0.05)
grd = grid(3)
cands, tgt, T1 = candidates(V, G, grd, kinds=['prec'])
F, coh = family(cands, T1, G, r_sel=1, r_t1=1)
W = World(G, F, coh)
S = Search(W, grd, cands, tgt, dict(K=False, P=True, C=True, W=True, W_fine=True))
ok, _ = S.run(maxit=400)
print('RESULT', ok)
if ok is False:
    core = S.core(); wk = [k for k in core if k[0] == 'W']
    print('core size', len(core), 'W keys', len(wk))
    # singletons
    others = [S.act[k] for k in S.act if k[0] != 'W']
    sing = []
    for k in wk[:0]:
        r, _ = S.run(assumptions=others + [S.act[k]], maxit=400)
        if r is False: sing.append(k); print('  singleton certificate X =', F[k[1]], 'coherent' if coh[k[1]] else 'incoherent', flush=True)
        if len(sing) >= 3: break
    print('singletons found', len(sing))
    for k in sing[:1]:
        X = k[1]; print('X', F[X])
        for j in range(3):
            print('  B^%d' % (j + 1), F[cands[[0, 3, 9][j]][0] and W.idx[cands[[0,9,3][j]][0]]] if False else '')
    mus = S.minimize(core, maxit=400)
    print('MUS', len(mus))
    for k in mus:
        if k[0] == 'W': print('  W  X =', F[k[1]], 'coh' if coh[k[1]] else 'incoh')
        else: print(' ', k[0], k[1] if k[1] == 'z' else F[k[1]])
    print('cells', tags)
