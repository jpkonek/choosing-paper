"""Re-check the Farkas (M1)-type certificates of a saved SAT solution for compositionality
(composition modulo worsening glue).  NUMERICS/CHECKED."""
import sys, pickle, itertools, numpy as np
from scipy.optimize import linprog
from diag import ladder_rows
from satx import PAIR, CODE
from cells import rank
D = pickle.load(open(sys.argv[1], 'rb'))
G, rec, rcodes, fixed, vals = D['G'], D['rec'], D['rcodes'], D['fixed'], D['vals']
N = len(G)
def compose(r, s, i):
    out = np.zeros(N, np.int8)
    for c in range(N):
        a, b = int(r[c]), int(s[c])
        if a == 0: out[c] = b; continue
        if b == 0: out[c] = a; continue
        x, y = PAIR[a]; y2, z = PAIR[b]
        if y != y2 and rank('+0-'[y2], G[c], i) < rank('+0-'[y], G[c], i): return None
        out[c] = 0 if x == z else CODE[x, z]
    return out
def dirs(code, i):
    d = np.zeros(N, int)
    for c in range(N):
        if code[c]:
            x, y = PAIR[code[c]]; d[c] = 1 if rank('+0-'[y], G[c], i) > rank('+0-'[x], G[c], i) else -1
    return d
used = np.unique(rec)
for i in range(3):
    acc = used[(fixed[i][used] == 0) & vals[i][used]]
    R = ladder_rows(G, rcodes, acc, i).astype(float); n = R.shape[1]
    res = linprog(np.ones(len(acc)), A_ub=np.vstack([R.T, R.sum(1)[None, :]]), b_ub=np.concatenate([np.zeros(n), [-1.0]]),
                  bounds=[(0, None)] * len(acc), method='highs')
    if res.status != 0: print('world', i + 1, 'endorsable'); continue
    sup = [int(acc[k]) for k in np.where(res.x > 1e-9)[0]]
    print('world', i + 1, 'Farkas support', len(sup), 'weights', np.round(res.x[res.x > 1e-9], 3))
    from fractions import Fraction
    w = res.x[res.x > 1e-9]; fr = [Fraction(x / w.min()).limit_denominator(12) for x in w]
    import math
    den = 1
    for f in fr: den = den * f.denominator // math.gcd(den, f.denominator)
    mult = [int(f * den) for f in fr]
    multiset = [r for r, k in zip(sup, mult) for _ in range(k)]
    print('   integer multiplicities', mult)
    hit = None
    perms = set(itertools.permutations(multiset)) if len(multiset) <= 8 else []
    for perm in perms:
        cur = rcodes[perm[0]].copy()
        for r in perm[1:]:
            cur = compose(cur, rcodes[r], i)
            if cur is None: break
        if cur is None: continue
        d = dirs(cur, i)
        if (d < 0).any() and not (d > 0).any(): hit = perm; break
    print('   compositional (chain with worsening glue gives a pure improvement):', hit is not None)
    if hit is not None:
        tags = D['tags']
        def desc(code):
            return ' '.join(f'{tags[c]}:{"+0-"[PAIR[code[c]][0]]}>{"+0-"[PAIR[code[c]][1]]}' for c in range(N) if code[c])
        uniq = list(dict.fromkeys(hit)); name = {r: f'r{k+1}' for k, r in enumerate(uniq)}
        for r in uniq:
            d = dirs(rcodes[r], i)
            print(f'   {name[r]} (accepted at world {i+1}; better on {int((d<0).sum())} cells, worse on {int((d>0).sum())}):', desc(rcodes[r]))
        print('   chain:', ' then '.join(name[r] for r in hit))
        cur = rcodes[hit[0]].copy()
        for r in hit[1:]: cur = compose(cur, rcodes[r], i)
        print('   composite (pure improvement at world %d):' % (i + 1), desc(cur))
