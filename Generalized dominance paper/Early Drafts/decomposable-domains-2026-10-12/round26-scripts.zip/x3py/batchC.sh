#!/bin/bash
run() { tag=$1; shift; timeout 2400 python3 -u add_full.py "$@" --out out/C_$tag.json > out/C_$tag.log 2>&1; echo "### $tag :: $*"; grep -E "^round|^ADDFULL" out/C_$tag.log | tail -n 2 | sed 's/{.*}//'; [ -f out/C_$tag.json ] && grep -q FULL-OK out/C_$tag.log && timeout 1800 python3 verify_add.py out/C_$tag.json | tail -n 3; }
run m3_e0.3_ring --eps 0.3 --m 3 --cl ring
run m3_e0.1_none --eps 0.1 --m 3
run m3_e0.6_none --eps 0.6 --m 3
run m3_e0.1_ring --eps 0.1 --m 3 --cl ring
run m3_e0.6_ring --eps 0.6 --m 3 --cl ring
run m6_e0.3_none --eps 0.3 --m 6 --kinds VB,prec,seg
run m6_e0.3_ring --eps 0.3 --m 6 --kinds VB,prec,seg --cl ring
run m3_e0.3_ntau2_none --eps 0.3 --m 3 --ntau 2
