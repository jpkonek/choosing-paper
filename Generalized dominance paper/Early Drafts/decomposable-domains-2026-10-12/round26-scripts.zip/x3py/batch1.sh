#!/bin/bash
for cl in ring-vx ring-bd ring simp; do
  timeout 2400 python3 -u run.py --m 3 --rsel 1 --rt1 1 --opts K,P,C --cl $cl --core > out/b1_m3_$cl.log 2>&1
done
