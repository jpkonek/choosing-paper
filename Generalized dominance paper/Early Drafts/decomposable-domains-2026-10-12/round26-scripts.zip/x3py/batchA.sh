#!/bin/bash
# main SAT batch (non-additive joint search); summary lines only
run() { tag=$1; shift; timeout 1800 python3 -u run.py "$@" --core > out/A_$tag.log 2>&1; echo "### $tag :: $*"; grep -E "^World|^RESULT|^MUS|^core" out/A_$tag.log | sed 's/{.*//'; }
for e in 0.1 0.3 0.6; do
  for cl in none ring-vx ring-bd ring; do
    c=$cl; [ $cl = none ] && c=""
    run m3_e${e}_${cl} --eps $e --m 3 --kinds prec,seg,segL,segR ${c:+--cl $c}
  done
done
run m3_e0.3_ntau2_ring --eps 0.3 --m 3 --ntau 2 --kinds prec,seg --cl ring
for cl in none ring-bd ring; do
  c=$cl; [ $cl = none ] && c=""
  run m6_e0.3_${cl} --eps 0.3 --m 6 --kinds VB,prec,seg --rsel 0 --rt1 1 --rvx 1 ${c:+--cl $c} --save out/A_m6_${cl}.pkl
done
