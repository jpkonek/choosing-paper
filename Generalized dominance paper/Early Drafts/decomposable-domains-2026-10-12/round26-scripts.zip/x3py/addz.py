"""X3 additive restriction via SMT (z3, linear real arithmetic; exact, no big-M).  NUMERICS tooling.

World i: L_i(X) = sum_c l_i(c, X_c), l_i(c, good) = 0 <= ... : s_i(c) = l(silent) >= 1,
b_i(c) = l(bad) >= s_i(c) + 1.  X <=_i Y iff L_i(X) <= L_i(Y); a strict comparison is written
with margin 1 (wlog: homogeneous constraints, finitely many, rational scaling).
Constraint families as in satx.py: K, P+C, CL (ring / ring-bd / ring-vx), and optionally a
fixed or free selection among candidates.  Instances generated lazily from counterexamples.
"""
import time, numpy as np, z3
from cells import rank


class AdditiveZ:
    def __init__(self, W, grd, cands, opts, verbose=True):
        self.W = W; self.grd = grd; self.opts = opts; self.verbose = verbose
        self.cand = [[W.idx[c] for c in cs] for cs in cands]
        N = W.N
        self.rk = np.zeros((3, N, 3), int)
        for i in range(3):
            for c in range(N):
                for a in range(3): self.rk[i, c, a] = rank('+0-'[a], W.G[c], i)
        self.S = z3.Solver()
        self.l = {}
        for i in range(3):
            for c in range(N):
                s, b = z3.Real(f's{i}_{c}'), z3.Real(f'b{i}_{c}')
                self.l[(i, c, 1)] = s; self.l[(i, c, 2)] = b
                self.S.add(s >= 1, b >= s + 1)
        self.sel = {}
        for v, cs in enumerate(self.cand):
            if len(cs) > 1:
                bs = [z3.Bool(f'sel{v}_{C}') for C in cs]
                for C, b in zip(cs, bs): self.sel[(v, C)] = b
                self.S.add(z3.PbEq([(b, 1) for b in bs], 1))
        self.inst = set(); self.Lc = {}

    def Lexpr(self, i, X):
        key = (i, X)
        if key not in self.Lc:
            terms = [self.l[(i, c, self.rk[i, c, self.W.dig[X, c]])] for c in range(self.W.N)
                     if self.rk[i, c, self.W.dig[X, c]]]
            self.Lc[key] = z3.Sum(terms) if terms else z3.RealVal(0)
        return self.Lc[key]

    def d(self, i, A, B):
        return self.Lexpr(i, A) - self.Lexpr(i, B)

    def under(self, v, C, f):
        return z3.Implies(self.sel[(v, C)], f) if (v, C) in self.sel else f

    def acc_at(self, v, i, X):        # C_v <=_i X
        return z3.And([self.under(v, C, self.d(i, C, X) <= 0) for C in self.cand[v]])

    def rej_at(self, v, i, X):        # C_v >_i X (margin 1)
        return z3.And([self.under(v, C, self.d(i, C, X) >= 1) for C in self.cand[v]])

    def add_K(self, v, X):
        if ('K', v, X) in self.inst: return
        self.inst.add(('K', v, X))
        self.S.add(z3.And([self.under(v, C, z3.Or([self.d(i, C, X) <= 0 for i in self.grd['supp'][v]]))
                           for C in self.cand[v]]))

    def add_PC(self, v, C, X):
        if ('P', v, C, X) in self.inst: return
        self.inst.add(('P', v, C, X))
        br = [self.d(i, X, C) >= 1 for i in range(3)]
        if self.W.coh[X]: br.append(z3.And([self.d(i, X, C) >= 0 for i in range(3)]))
        self.S.add(self.under(v, C, z3.Or(br)))

    def add_CL(self, v, X, i):
        if ('CL', v, X, i) in self.inst: return
        self.inst.add(('CL', v, X, i))
        self.S.add(z3.Or([self.acc_at(v, i, X)] + [self.rej_at(w, i, X) for w in self.grd['nbr'][v]]))

    def evaluate(self, m):
        W = self.W
        L = np.zeros((3, W.nF))
        for i in range(3):
            tab = np.zeros((W.N, 3))
            for c in range(W.N):
                for a in range(3):
                    rr = self.rk[i, c, a]
                    if rr:
                        val = m.eval(self.l[(i, c, rr)], model_completion=True)
                        tab[c, a] = float(val.numerator_as_long()) / float(val.denominator_as_long())
            L[i] = tab[np.arange(W.N)[None, :], W.dig].sum(1)
        sel = []
        for v, cs in enumerate(self.cand):
            if len(cs) == 1: sel.append(cs[0])
            else: sel.append([C for C in cs if z3.is_true(m.eval(self.sel[(v, C)], model_completion=True))][0])
        return L, sel

    def run(self, maxit=200, cap=300, tol=1e-9, tlimit=3000):
        t0 = time.time(); W, g, o = self.W, self.grd, self.opts
        for it in range(maxit):
            r = self.S.check()
            if r != z3.sat:
                if self.verbose: print(f'  additive(z3): {r} it={it} inst={len(self.inst)} {time.time()-t0:.1f}s', flush=True)
                return (False if r == z3.unsat else None), None
            L, sel = self.evaluate(self.S.model())
            acc = lambda i, C: L[i][C] <= L[i] + tol
            nadd = 0
            if o.get('K', True):
                for v in range(len(self.cand)):
                    if g['pts'][v].count(0) == 2: continue
                    ok = np.zeros(W.nF, bool)
                    for i in g['supp'][v]: ok |= acc(i, sel[v])
                    for X in np.where(~ok)[0][:cap]: self.add_K(v, int(X)); nadd += 1
            for v in range(len(self.cand)):
                C = sel[v]
                dom = np.ones(W.nF, bool); strict = np.zeros(W.nF, bool); tie = np.ones(W.nF, bool)
                for i in range(3):
                    dom &= L[i] <= L[i][C] + tol; strict |= L[i] < L[i][C] - tol
                    tie &= np.abs(L[i] - L[i][C]) <= tol
                bad = (dom & strict) | (tie & ~W.coh); bad[C] = False
                for X in np.where(bad)[0][:cap]: self.add_PC(v, C, int(X)); nadd += 1
            cl = o.get('CL')
            if cl:
                for v in range(len(self.cand)):
                    ns = len(g['supp'][v])
                    if not (cl == 'ring' or (cl == 'ring-bd' and ns < 3) or (cl == 'ring-vx' and ns == 1)): continue
                    for i in range(3):
                        allw = np.ones(W.nF, bool)
                        for w in g['nbr'][v]: allw &= acc(i, sel[w])
                        for X in np.where(allw & ~acc(i, sel[v]))[0][:cap]: self.add_CL(v, int(X), i); nadd += 1
            if self.verbose: print(f'  additive(z3) it {it}: +{nadd} inst={len(self.inst)} {time.time()-t0:.1f}s', flush=True)
            if nadd == 0: return True, (L, sel)
            if time.time() - t0 > tlimit: return None, None
        return None, None
