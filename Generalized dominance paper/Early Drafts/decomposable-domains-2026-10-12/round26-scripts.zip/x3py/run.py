"""X3 driver.  Example:
python3 run.py --eps 0.3 --m 3 --ntau 1 --rsel 1 --rt1 1 --opts K,P,C,W --cl ring-bd --core
"""
import argparse, time, json, pickle, numpy as np
from cells import make_cells, grid, coherent
from family import candidates, family
from satx import World, Search, T

ap = argparse.ArgumentParser()
ap.add_argument('--eps', type=float, default=0.3)
ap.add_argument('--m', type=int, default=3)
ap.add_argument('--ntau', type=int, default=1)
ap.add_argument('--delta', type=float, default=0.05)
ap.add_argument('--nocorners', action='store_true')
ap.add_argument('--deep', action='store_true')
ap.add_argument('--kinds', default='VB,prec,edge')
ap.add_argument('--pool', default='local')
ap.add_argument('--plateau', action='store_true')
ap.add_argument('--rsel', type=int, default=1)
ap.add_argument('--rt1', type=int, default=1); ap.add_argument('--rvx', type=int, default=0)
ap.add_argument('--opts', default='K,P,C')
ap.add_argument('--cl', default='')
ap.add_argument('--core', action='store_true')
ap.add_argument('--save', default='')
ap.add_argument('--solver', default='cadical153')
ap.add_argument('--maxit', type=int, default=3000)
ap.add_argument('--endorse', action='store_true')
a = ap.parse_args()

V, G, tags = make_cells(a.eps, a.ntau, a.delta, corners=not a.nocorners, deep=a.deep)
grd = grid(a.m)
cands, tgt, T1 = candidates(V, G, grd, kinds=a.kinds.split(','), t1_plateau=a.plateau, pool=a.pool)
F, coh = family(cands, T1, G, r_sel=a.rsel, r_t1=a.rt1, r_vx=a.rvx)
print('cells', len(G), 'grid m', a.m, 'target at', grd['pts'][tgt], 'T1', T1)
print('candidates per point:', [len(c) for c in cands])
W = World(G, F, coh)
opts = {k: True for k in a.opts.split(',') if k}
for k in ('K', 'P', 'C'):
    opts.setdefault(k, False)
if a.cl: opts['CL'] = a.cl
if a.endorse: opts['endorse'] = True
S = Search(W, grd, cands, tgt, opts, solver=a.solver)
t0 = time.time()
ok, sol = S.run(maxit=a.maxit)
print('RESULT', ok, f'{time.time()-t0:.1f}s', vars(a))
res = dict(args=vars(a), ok=ok)
if ok is False and a.core:
    keys = S.core(); print('core groups', len(keys), keys[:40])
    mus = S.minimize(keys); print('MUS', mus)
    res['mus'] = [list(map(str, k)) for k in mus]
if ok:
    vals, mv = sol
    sel = S.selection(mv)
    for v, cs in enumerate(sel):
        print('  sel', grd['pts'][v], [F[C] for C in cs])
    res['sel'] = [[F[C] for C in cs] for cs in sel]
if getattr(S, 'noncomp', None):
    print('NON-COMPOSITIONAL obstructions (world: records, weights):')
    for i, (recs, w) in S.noncomp.items():
        print('  world', i + 1, [W.describe(r, i) for r in recs], w)
if a.save:
    with open(a.save, 'wb') as f:
        pickle.dump(dict(res=res, G=G, tags=tags, F=F, coh=coh, cands=cands, tgt=tgt,
                         vals=(sol[0] if ok else None), rcodes=W.rcodes, rec=W.rec,
                         fixed=W.fixed, grd=grd, sel=(res.get('sel'))), f)
