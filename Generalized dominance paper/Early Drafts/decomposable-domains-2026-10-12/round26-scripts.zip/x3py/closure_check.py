"""Bounded record-level closure test of a saved SAT solution at one world (NUMERICS/CHECKED).

Start from the Farkas (M1)-type certificate S of a non-endorsable world (accepted trade records)
and saturate under 'composition modulo worsening glue' (r then s, a junction mismatch y -> y'
allowed when y' is world-i worse than y: a (G)-accepted step), up to a depth bound.  Report
(a) a derived pure improvement (=> the solution violates (T)+(IB)+(G) in the full finite world),
(b) a derived record realised by a pair in F that the solution rejects (=> violates (T) on F's
records), or (c) neither (certificate survives the bounded closure test).
Usage: python3 closure_check.py out/X.pkl world(1-3) [depth] [extra]
  extra = number of additional accepted records (nearest to the certificate) added to the seed.
"""
import sys, pickle, numpy as np
from scipy.optimize import linprog
from diag import ladder_rows
from satx import PAIR, CODE
from cells import rank

D = pickle.load(open(sys.argv[1], 'rb'))
i = int(sys.argv[2]) - 1
depth = int(sys.argv[3]) if len(sys.argv) > 3 else 6
extra = int(sys.argv[4]) if len(sys.argv) > 4 else 0
G, rec, rcodes, fixed, vals, tags = D['G'], D['rec'], D['rcodes'], D['fixed'], D['vals'], D['tags']
N = len(G)
RK = np.array([[[rank('+0-'[a], G[c], w) for a in range(3)] for c in range(N)] for w in range(3)])


def compose(r, s):
    out = np.zeros(N, np.int8)
    for c in range(N):
        a, b = int(r[c]), int(s[c])
        if a == 0: out[c] = b; continue
        if b == 0: out[c] = a; continue
        x, y = PAIR[a]; y2, z = PAIR[b]
        if y != y2 and RK[i, c, y2] < RK[i, c, y]: return None
        out[c] = 0 if x == z else CODE[x, z]
    return out


def dirs(code):
    d = np.zeros(N, int)
    for c in range(N):
        if code[c]:
            x, y = PAIR[code[c]]; d[c] = 1 if RK[i, c, y] > RK[i, c, x] else -1
    return d


def desc(code):
    return ' '.join(f'{tags[c]}:{"+0-"[PAIR[code[c]][0]]}>{"+0-"[PAIR[code[c]][1]]}' for c in range(N) if code[c])


used = np.unique(rec)
lookup = {rcodes[r].tobytes(): int(r) for r in used}
acc = used[(fixed[i][used] == 0) & vals[i][used]]
R = ladder_rows(G, rcodes, acc, i).astype(float); n = R.shape[1]
res = linprog(np.ones(len(acc)), A_ub=np.vstack([R.T, R.sum(1)[None, :]]),
              b_ub=np.concatenate([np.zeros(n), [-1.0]]), bounds=[(0, None)] * len(acc), method='highs')
if res.status != 0:
    print('world', i + 1, 'endorsable; nothing to test'); sys.exit()
sup = [int(acc[k]) for k in np.where(res.x > 1e-9)[0]]
seed = list(sup)
if extra:
    # add accepted records touching the certificate's cells most
    cells = set(np.where(rcodes[sup].any(0))[0])
    score = [(len(cells & set(np.where(rcodes[r])[0])), int(r)) for r in acc if int(r) not in sup]
    seed += [r for _, r in sorted(score, reverse=True)[:extra]]
print(f'world {i+1}: certificate of {len(sup)} accepted records, seed {len(seed)}, depth {depth}')
for r in sup: print('   cert:', desc(rcodes[r]))
gens = [rcodes[r] for r in seed]
frontier = {g.tobytes(): g for g in gens}
seen = dict(frontier)
for d in range(2, depth + 1):
    new = {}
    for key, cur in frontier.items():
        for g in gens:
            for comp in (compose(cur, g), compose(g, cur)):
                if comp is None: continue
                k = comp.tobytes()
                if k in seen or k in new: continue
                dd = dirs(comp)
                if not comp.any(): continue
                if (dd < 0).any() and not (dd > 0).any():
                    print(f'(a) derived pure improvement at depth {d}:', desc(comp)); sys.exit()
                if (dd > 0).any() and not (dd < 0).any():
                    continue                                   # a worsening: accepted anyway
                if k in lookup and not vals[i][lookup[k]] and fixed[i][lookup[k]] == 0:
                    print(f'(b) derived record realised in F but rejected by the solution, depth {d}:', desc(comp)); sys.exit()
                new[k] = comp
    seen.update(new); frontier = new
    print(f'  depth {d}: {len(new)} new composites ({len(seen)} total)', flush=True)
    if not new: break
    if len(seen) > 400000: print('  (stopping: closure too large)'); break
print('(c) no forbidden or rejected composite derived within the bound')
