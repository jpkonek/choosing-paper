import argparse, time, numpy as np
from cells import make_cells, grid
from family import candidates, family
from satx import World
from addx import Additive
from addz import AdditiveZ
ap = argparse.ArgumentParser()
ap.add_argument('--eps', type=float, default=0.3); ap.add_argument('--m', type=int, default=3)
ap.add_argument('--ntau', type=int, default=1); ap.add_argument('--delta', type=float, default=0.05)
ap.add_argument('--nocorners', action='store_true'); ap.add_argument('--kinds', default='VB,prec,edge')
ap.add_argument('--pool', default='local'); ap.add_argument('--plateau', action='store_true')
ap.add_argument('--rsel', type=int, default=1); ap.add_argument('--rt1', type=int, default=1); ap.add_argument('--rvx', type=int, default=0)
ap.add_argument('--opts', default='K,P,C'); ap.add_argument('--cl', default='')
ap.add_argument('--engine', default='z3')
a = ap.parse_args()
V, G, tags = make_cells(a.eps, a.ntau, a.delta, corners=not a.nocorners)
grd = grid(a.m)
cands, tgt, T1 = candidates(V, G, grd, kinds=a.kinds.split(','), t1_plateau=a.plateau, pool=a.pool)
F, coh = family(cands, T1, G, r_sel=a.rsel, r_t1=a.rt1, r_vx=a.rvx)
W = World(G, F, coh)
opts = {k: True for k in a.opts.split(',') if k}
if a.cl: opts['CL'] = a.cl
AD = AdditiveZ(W, grd, cands, opts) if a.engine == 'z3' else Additive(W, grd, cands, opts)
t0 = time.time(); ok, sol = AD.run()
print('ADDITIVE RESULT', ok, f'{time.time()-t0:.1f}s', vars(a))
if ok:
    L, sel = sol[-2], sol[-1]
    for v, C in enumerate(sel): print('  sel', grd['pts'][v], F[C])
