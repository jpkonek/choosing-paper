#!/bin/bash
run() { tag=$1; shift; timeout 1800 python3 -u run.py "$@" --endorse --save out/D_$tag.pkl > out/D_$tag.log 2>&1; echo "### $tag :: $*"; grep -E "^RESULT|\+E|NON-COMP|world " out/D_$tag.log | sed 's/{.*//'; timeout 600 python3 diag.py out/D_$tag.pkl | grep -E "^world"; }
run m6_none --eps 0.3 --m 6 --kinds VB,prec,seg --rsel 0 --rt1 1 --rvx 1
run m6_ring --eps 0.3 --m 6 --kinds VB,prec,seg --rsel 0 --rt1 1 --rvx 1 --cl ring
run m6_ringbd --eps 0.3 --m 6 --kinds VB,prec,seg --rsel 0 --rt1 1 --rvx 1 --cl ring-bd
run m6_ring_rt2 --eps 0.3 --m 6 --kinds VB,prec,seg --rsel 0 --rt1 2 --rvx 1 --cl ring
run m6_e0.1_ring --eps 0.1 --m 6 --kinds VB,prec,seg --rsel 0 --rt1 1 --rvx 1 --cl ring
run m6_e0.6_ring --eps 0.6 --m 6 --kinds VB,prec,seg --rsel 0 --rt1 1 --rvx 1 --cl ring
run m3_e0.3_ring --eps 0.3 --m 3 --kinds prec,seg,segL,segR --cl ring
