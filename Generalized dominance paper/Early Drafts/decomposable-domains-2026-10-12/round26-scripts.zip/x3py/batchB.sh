#!/bin/bash
# additive mirror (z3) of batchA
run() { tag=$1; shift; timeout 1500 python3 -u add_run.py "$@" > out/B_$tag.log 2>&1; echo "### $tag :: $*"; grep -E "^World|RESULT|unsat|unknown" out/B_$tag.log | sed 's/{.*//'; }
for e in 0.1 0.3 0.6; do
  for cl in none ring-vx ring-bd ring; do
    c=$cl; [ $cl = none ] && c=""
    run m3_e${e}_${cl} --eps $e --m 3 --kinds prec,seg,segL,segR ${c:+--cl $c}
  done
done
run m3_e0.3_ntau2_ring --eps 0.3 --m 3 --ntau 2 --kinds prec,seg --cl ring
run m3_e0.3_rt2_ring --eps 0.3 --m 3 --rt1 2 --kinds prec,seg --cl ring
for cl in none ring-bd ring; do
  c=$cl; [ $cl = none ] && c=""
  run m6_e0.3_${cl} --eps 0.3 --m 6 --kinds VB,prec,seg --rsel 0 --rt1 1 --rvx 1 ${c:+--cl $c}
done
