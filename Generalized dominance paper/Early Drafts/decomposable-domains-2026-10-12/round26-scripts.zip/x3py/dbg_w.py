import numpy as np
from cells import make_cells, grid
from family import candidates, family
from satx import World
V,G,tags=make_cells(0.3,1,0.05)
grd=grid(3)
cands,tgt,T1=candidates(V,G,grd)
F,coh=family(cands,T1,G,1,1)
W=World(G,F,coh)
allc=sorted({W.idx[c] for cs in cands for c in cs})
bad=[]
for X in range(W.nF):
    ok=False
    for C in allc:
        if all(W.fixed[i][W.rec[C,X]]!=-1 for i in range(3)): ok=True;break
    if not ok: bad.append(X)
print(len(bad))
for X in bad[:10]:
    print(F[X], coh[X], [ (F[C], [int(W.fixed[i][W.rec[C,X]]) for i in range(3)]) for C in allc][:3])
