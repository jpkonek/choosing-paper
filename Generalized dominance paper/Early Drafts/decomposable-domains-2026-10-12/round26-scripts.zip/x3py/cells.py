"""X3 finite model, geometry layer (NUMERICS tooling).

A *cell* is one binary problem (a +/- pair of directions), represented by one oriented mixed
gamble g_c in R^3.  Advice on a cell: '+' (accept g_c only), '0' (silence), '-' (accept -g_c only).
Contradictory advice 'x' and unanimous cells are dropped: see X3_notes.md, Lemma X3.0.

World-i rank of advice (background order): 0 good, 1 silent, 2 bad.
"""
import numpy as np
from scipy.optimize import linprog

ADV = '+0-'


def t1_vertices(eps):
    c0 = (1 - eps) / 3
    return [c0 * np.ones(3) + eps * np.eye(3)[k] for k in range(3)]


def P(K, g):
    return min(float(np.dot(m, g)) for m in K)


def advice_of(K, g, tol=1e-12):
    """advice of D_K on the pair of g (K given by finitely many points; D_K uses conv K)."""
    a, b = P(K, g), P(K, -np.asarray(g))
    if a > tol: return '+'
    if b > tol: return '-'
    return '0'


def rank(a, g, i):
    if a == '0': return 1
    s = g[i] if a == '+' else -g[i]
    return 0 if s > 0 else 2


def corner_rays(V):
    """r[(k,j)] = corner ray of facets F_k, F_j, oriented so that it is on the boundary of D_T."""
    r = {}
    for k in range(3):
        for j in range(3):
            if j == k: continue
            x = np.cross(V[k], V[j])
            l = 3 - k - j
            if np.dot(x, V[l]) < 0: x = -x
            r[(k, j)] = x / np.abs(x).max()
    return r


def facet_param(V, k):
    """returns (r0, r1) = corner rays of F_k, ordered so that along h(t)=(1-t)r0+t r1 the
    coordinate crossing pattern is as in Lemma lem:signs."""
    others = [j for j in range(3) if j != k]
    r = corner_rays(V)
    return r[(k, others[0])], r[(k, others[1])]


def facet_crossings(V, k):
    r0, r1 = facet_param(V, k)
    ts = []
    for i in range(3):
        if i == k: continue
        if (r0[i] > 0) != (r1[i] > 0):
            ts.append(r0[i] / (r0[i] - r1[i]))
    return sorted(ts)


def coherent(pattern, G, delta=1e-7):
    """point-level coherence: is there a credal set K with D_K giving exactly this advice on the
    representatives?  Largest admissible K is K_d = {m in Delta: m.x >= d, x accepted}; then each
    rejected orientation h needs some m in K_d with m.h <= 0."""
    acc, rej = [], []
    for a, g in zip(pattern, G):
        g = np.asarray(g, float)
        if a == '+': acc.append(g)
        elif a == '-': acc.append(-g)
        else: rej += [g, -g]
    A = np.array(acc) if acc else np.zeros((0, 3))
    for h in (rej if rej else [None]):
        Aub, bub = [], []
        for x in A: Aub.append([-x[0], -x[1], -x[2], 1.0]); bub.append(0.0)
        if h is not None: Aub.append([h[0], h[1], h[2], 0.0]); bub.append(0.0)
        if not Aub: return True
        res = linprog([0, 0, 0, -1], A_ub=Aub, b_ub=bub, A_eq=[[1, 1, 1, 0]], b_eq=[1],
                      bounds=[(0, 1)] * 3 + [(None, 1)], method='highs')
        if res.status != 0: return False
        if len(A) and -res.fun < delta: return False
    return True


def make_cells(eps, ntau=1, delta=0.05, corners=True, deep=False):
    """Symmetric discretisation resolving T1: on each facet F_k, ntau sample points in each of the
    three crossing intervals (sign patterns (-,+), (+,+), (+,-) of the two crossing coordinates),
    each giving an inside cell h+delta*1 (T1 accepts) and an outside cell h-delta*1 (T1 silent);
    optionally the three corner rays (inside/outside); optionally one deep-inside cell per mixed
    sign class.  One cell per +/- pair; orientation = the representative listed."""
    V = t1_vertices(eps)
    G, tags = [], []
    for k in range(3):
        r0, r1 = facet_param(V, k)
        cr = [0.0] + facet_crossings(V, k) + [1.0]
        for iv in range(3):
            a, b = cr[iv], cr[iv + 1]
            for s in range(ntau):
                t = a + (b - a) * (s + 1) / (ntau + 1)
                h = (1 - t) * r0 + t * r1
                h = h / np.abs(h).max()
                for side, sg in (('i', 1), ('o', -1)):
                    G.append(h + sg * delta * np.ones(3)); tags.append(f'F{k+1}.{iv}{s}{side}')
    if corners:
        r = corner_rays(V)
        for (k, j) in [(0, 1), (1, 2), (2, 0)]:
            for side, sg in (('i', 1), ('o', -1)):
                G.append(r[(k, j)] + sg * delta * np.ones(3)); tags.append(f'r{k+1}{j+1}{side}')
    if deep:
        for odd in range(3):
            g = np.ones(3); g[odd] = -0.3
            G.append(g); tags.append(f'deep{odd+1}')
    for g in G:
        assert (g > 0).any() and (g < 0).any() and np.abs(g).min() > 1e-6, g
    return V, G, tags


def grid(m):
    pts = [(a, b, m - a - b) for a in range(m + 1) for b in range(m + 1 - a)]
    idx = {p: n for n, p in enumerate(pts)}
    nbr = {n: [] for n in range(len(pts))}
    steps = [(1, -1, 0), (-1, 1, 0), (1, 0, -1), (-1, 0, 1), (0, 1, -1), (0, -1, 1)]
    for p, n in idx.items():
        for s in steps:
            q = tuple(p[t] + s[t] for t in range(3))
            if q in idx: nbr[n].append(idx[q])
    tris = []
    for (a, b, c), n in idx.items():
        q1, q2 = (a + 1, b, c - 1), (a, b + 1, c - 1)
        if q1 in idx and q2 in idx: tris.append((n, idx[q1], idx[q2]))
        q3 = (a + 1, b + 1, c - 2)
        if q1 in idx and q2 in idx and q3 in idx: tris.append((idx[q1], idx[q2], idx[q3]))
    P_ = [np.array(p, float) / m for p in pts]
    supp = [tuple(i for i in range(3) if p[i] > 0) for p in pts]
    return dict(m=m, pts=pts, P=P_, supp=supp, nbr=nbr, tris=tris, idx=idx)
