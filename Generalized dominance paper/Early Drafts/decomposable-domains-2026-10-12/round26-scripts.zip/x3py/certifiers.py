"""Which worlds certify T1 (and other selected models) against competitors in a SAT solution."""
import sys, pickle, numpy as np, collections
D = pickle.load(open(sys.argv[1], 'rb'))
F, rec, fixed, vals, tags, G = D['F'], D['rec'], D['fixed'], D['vals'], D['tags'], D['G']
idx = {x: n for n, x in enumerate(F)}
T1 = D['cands'][D['tgt']][0]; t = idx[T1]
stat = collections.Counter(); rows = []
for X in range(len(F)):
    r = rec[t, X]
    st = ''.join('F' if fixed[i][r] == 1 else ('x' if fixed[i][r] == -1 else ('a' if vals[i][r] else '.')) for i in range(3))
    stat[st] += 1
    if 'F' not in st:
        diff = [(c, T1[c], F[X][c]) for c in range(len(T1)) if T1[c] != F[X][c]]
        rows.append((st, diff))
print('status of T1 <=_i X over X in F (F forced by G, x forbidden by G, a accepted trade, . rejected):')
for k, v in sorted(stat.items()): print(' ', k, v)
print('competitors certified only through accepted trades:')
for st, diff in rows[:40]:
    print(' ', st, ' '.join(f'{tags[c]}:{a}>{b}' for c, a, b in diff))
