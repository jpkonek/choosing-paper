"""X3 diagnostics applied AFTER a SAT solution (NUMERICS).

(1) Additive endorsement per world (finite 'adds up'): is there a strictly guiding additive penalty
    l_i(c, rank) (0 = good, s >= 1 silent, b >= s+1 bad) with L_i(Y) - L_i(X) >= 0 for every
    accepted comparison X <=_i Y between members of F?  Worsenings are endorsed automatically, so
    only accepted trade records (free variables set TRUE) enter.  Rows are deduplicated by their
    world-i ladder vector.  If infeasible: a deletion filter returns a minimal infeasible set of
    accepted trades, i.e. a finite (M1)-type certificate.
(2) Statistics: how many trades are accepted per world, and which constraint families force them.
Usage: python3 diag.py out/<run>.pkl
"""
import sys, pickle, numpy as np
from scipy.optimize import linprog
from cells import rank
from satx import PAIR


def ladder_rows(G, rcodes, recs, i):
    N = len(G)
    # ladder vector: per cell two steps (silence step, wrong step); +1 = step entered (worse)
    rows = np.zeros((len(recs), 2 * N), np.int8)
    for c in range(N):
        for code in range(1, 7):
            x, y = PAIR[code]
            rx, ry = rank('+0-'[x], G[c], i), rank('+0-'[y], G[c], i)
            vec = np.zeros(2, np.int8)
            for j in (1, 2):
                vec[j - 1] = int(ry >= j) - int(rx >= j)
            sel = rcodes[recs, c] == code
            rows[sel, 2 * c:2 * c + 2] = vec
    return rows


def endorsable(rows):
    """exists rho >= 1 (ladder densities) with rows . rho >= 0 ?  (accepted X<=Y: L(Y)-L(X) >= 0)"""
    if len(rows) == 0: return True
    n = rows.shape[1]
    res = linprog(np.zeros(n), A_ub=-rows.astype(float), b_ub=np.zeros(len(rows)),
                  bounds=[(1, None)] * n, method='highs')
    return res.status == 0


def min_obstruction(rows):
    """Farkas certificate y >= 0 with R^T y <= 0, nonzero; basic solution => small support."""
    R = rows.astype(float); n = R.shape[1]
    res = linprog(np.ones(len(R)), A_ub=np.vstack([R.T, R.sum(1)[None, :]]),
                  b_ub=np.concatenate([np.zeros(n), [-1.0]]), bounds=[(0, None)] * len(R), method='highs')
    if res.status != 0: return None
    return [int(k) for k in np.where(res.x > 1e-9)[0]]


if __name__ == '__main__':
    D = pickle.load(open(sys.argv[1], 'rb'))
    G, F, rec, rcodes, fixed, vals = D['G'], D['F'], D['rec'], D['rcodes'], D['fixed'], D['vals']
    used = np.unique(rec)
    for i in range(3):
        acc = used[(fixed[i][used] == 0) & vals[i][used]]
        rows = ladder_rows(G, rcodes, acc, i)
        u, ix = np.unique(rows, axis=0, return_index=True)
        ok = endorsable(u)
        print(f'world {i+1}: accepted trade records among F-pairs: {len(acc)} (distinct ladder vectors {len(u)}); additively endorsable: {ok}')
        if not ok:
            ob = min_obstruction(u)
            print('  minimal obstruction (ladder vectors):')
            for r in ob:
                print('   ', ' '.join(f'c{c}:{int(u[r][2*c])},{int(u[r][2*c+1])}' for c in range(len(G)) if u[r][2*c] or u[r][2*c+1]))
