#!/bin/bash
# additive sweep (z3); one line per run
run() { echo "### $*"; timeout 1500 python3 -u add_run.py "$@" 2>&1 | grep -E "World|RESULT|unsat|unknown" | sed 's/{.*//' ; }
run --m 6 --kinds VB,prec,seg,segL,segR
run --m 6 --kinds VB,prec,seg,segL,segR --cl ring-bd
run --m 6 --kinds VB,prec,seg,segL,segR --cl ring
run --m 6 --kinds VB,seg,segL,segR --cl ring
run --m 6 --kinds prec --cl ring
run --m 6 --kinds VB,seg --cl ring
