"""Independent exact check (z3, rational arithmetic) of an additive finite solution against ALL
3^N models: (K) grid competitiveness, (P) protection, (C) no incoherent all-world tie with a
selected model (ties enumerated), and the CL proxy if present.  CHECKED (computer-verified)."""
import sys, json, numpy as np, z3
from fractions import Fraction
from cells import coherent, grid
D = json.load(open(sys.argv[1])); sel = D['sel']; G = [np.array(g) for g in D['G']]
tab = [[[Fraction(x).limit_denominator(10**6) for x in row] for row in w] for w in D['tab']]
cl = D['args'].get('cl', ''); grd = grid(D['args']['m']); N = len(tab[0])
def Lp(i, pat): return sum(tab[i][c]['+0-'.index(a)] for c, a in enumerate(pat))
x = [[z3.Bool(f'x{c}_{a}') for a in range(3)] for c in range(N)]
base = [z3.PbEq([(x[c][a], 1) for a in range(3)], 1) for c in range(N)]
def LX(i): return z3.Sum([z3.If(x[c][a], z3.RealVal(tab[i][c][a]), z3.RealVal(0)) for c in range(N) for a in range(3)])
def pat_of(m): return ''.join('+0-'[[z3.is_true(m.eval(x[c][a], model_completion=True)) for a in range(3)].index(True)] for c in range(N))
def notpat(p): return z3.Not(z3.And([x[c]['+0-'.index(a)] for c, a in enumerate(p)]))
def find(conds):
    s = z3.Solver(); s.add(base + conds)
    return pat_of(s.model()) if s.check() == z3.sat else None
ok = True
for v, C in enumerate(sel):
    supp = grd['supp'][v]; LC = [Lp(i, C) for i in range(3)]
    if len(supp) > 1:
        w = find([LX(i) < LC[i] for i in supp])
        if w: print('K violated at', grd['pts'][v], w); ok = False
    w = find([LX(i) <= LC[i] for i in range(3)] + [z3.Or([LX(i) < LC[i] for i in range(3)])])
    if w: print('P violated at', grd['pts'][v], w); ok = False
    s = z3.Solver(); s.add(base + [LX(i) == LC[i] for i in range(3)] + [notpat(C)])
    nt = 0
    while s.check() == z3.sat and nt < 50:
        p = pat_of(s.model()); nt += 1
        if not coherent(p, G): print('C violated at', grd['pts'][v], p); ok = False; break
        s.add(notpat(p))
    if cl and (cl == 'ring' or (cl == 'ring-bd' and len(supp) < 3) or (cl == 'ring-vx' and len(supp) == 1)):
        for i in range(3):
            lo = max(Lp(i, sel[u]) for u in grd['nbr'][v])
            w = find([LX(i) >= lo, LX(i) < LC[i]])
            if w: print('CL violated at', grd['pts'][v], 'world', i + 1, w); ok = False
print('exact check against all 3^%d models:' % N, 'OK' if ok else 'VIOLATED')
