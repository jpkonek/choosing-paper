#!/bin/bash
run() { tag=$1; shift; timeout 1500 python3 -u add_full.py "$@" --out out/C_$tag.json > out/C_$tag.log 2>&1; echo "### $tag :: $*"; grep -E "^round|^ADDFULL" out/C_$tag.log | tail -n 2 | sed 's/{.*}//'; [ -f out/C_$tag.json ] && grep -q FULL-OK out/C_$tag.log && timeout 1800 python3 verify_add.py out/C_$tag.json | tail -n 3; }
run m6_e0.3_none --eps 0.3 --m 6 --kinds VB,prec,seg
run m3_e0.3_ntau2_none --eps 0.3 --m 3 --ntau 2
run m3_e0.6_ring --eps 0.6 --m 3 --cl ring
run m3_e0.3_ringvx --eps 0.3 --m 3 --cl ring-vx
