"""X3 joint three-world SAT search over world-labelled transition records (NUMERICS tooling).

acc[i][r]  <=>  record r is accepted at world i   (X <=_i Y  iff  acc[i][d(X,Y)]).
(IB) is built in: acceptance is a function of the record only.
Strict (G): a record that changes no cell for the better at world i is fixed TRUE (identity and
worsenings); a record that changes some cell and none for the worse is fixed FALSE.
Constraint groups (each guarded by an activation literal so that cores can be read off):
  K[v]   competitiveness of the selection at grid point v, against every X in F, as the
         disjunction over supp v of world-labelled records d(C_v, X).
  P[C]   protection: if C is selected and X <=_i C at all worlds then C <=_i X at all worlds.
  C[C]   (C): an incoherent X is never tied with a selected C at every world.
  W      finite KKM shadow: every X in F is weakly dominated by some selected model.
  CL[v]  closed-section proxies (see X3_notes.md, section 3).
Transitivity (T) is a global axiom, generated lazily (CEGAR) over triples X,Y,Z in F.
"""
import time, numpy as np
from pysat.solvers import Solver
from cells import rank

T = 1 << 40
CODE = np.zeros((3, 3), np.int8)
PAIR = [None]
_n = 1
for _x in range(3):
    for _y in range(3):
        if _x != _y:
            CODE[_x, _y] = _n; PAIR.append((_x, _y)); _n += 1
AIDX = {'+': 0, '0': 1, '-': 2}


class World:
    """finite model: cells G, family F of patterns, records between members of F."""

    def __init__(self, G, F, coh, verbose=True):
        t0 = time.time()
        self.G = [np.asarray(g, float) for g in G]; self.N = len(G)
        self.F = list(F); self.nF = len(F); self.coh = np.asarray(coh)
        self.idx = {x: n for n, x in enumerate(F)}
        self.dig = np.array([[AIDX[a] for a in x] for x in F], np.int8)
        # per world, per cell, per code: +1 worse, -1 better, 0 identity
        self.dirs = np.zeros((3, self.N, 7), np.int8)
        for i in range(3):
            for c in range(self.N):
                for code in range(1, 7):
                    x, y = PAIR[code]
                    rx, ry = rank('+0-'[x], self.G[c], i), rank('+0-'[y], self.G[c], i)
                    self.dirs[i, c, code] = 1 if ry > rx else -1
        # records of all ordered pairs
        nF, N = self.nF, self.N
        codes = CODE[self.dig[:, None, :], self.dig[None, :, :]].reshape(nF * nF, N)
        v = np.ascontiguousarray(codes).view(np.dtype((np.void, N)))
        uniq, inv = np.unique(v, return_inverse=True)
        self.rcodes = uniq.view(np.int8).reshape(-1, N)
        self.R = len(self.rcodes)
        self.rec = inv.reshape(nF, nF).astype(np.int32)
        del codes, v
        self.fixed = np.zeros((3, self.R), np.int8)
        for i in range(3):
            d = self.dirs[i][np.arange(N)[None, :], self.rcodes]
            up = (d > 0).sum(1); dn = (d < 0).sum(1)
            self.fixed[i][dn == 0] = 1
            self.fixed[i][(dn > 0) & (up == 0)] = -1
        self.var = [dict() for _ in range(3)]
        self.nvar = 0
        if verbose:
            print(f'World: N={N} |F|={nF} (coherent {self.coh.sum()}) records={self.R} '
                  f'free={[(self.fixed[i]==0).sum() for i in range(3)]}  {time.time()-t0:.1f}s', flush=True)

    def newvar(self):
        self.nvar += 1
        return self.nvar

    def lit_r(self, i, r):
        f = self.fixed[i][r]
        if f == 1: return T
        if f == -1: return -T
        d = self.var[i]
        if r not in d: d[r] = self.newvar()
        return d[r]

    def L(self, i, X, Y):
        return self.lit_r(i, int(self.rec[X, Y]))

    def describe(self, r, i=None):
        out = []
        for c in range(self.N):
            code = self.rcodes[r, c]
            if code:
                x, y = PAIR[code]
                s = f'c{c}:{"+0-"[x]}>{"+0-"[y]}'
                if i is not None: s += ('(w)' if self.dirs[i, c, code] > 0 else '(b)')
                out.append(s)
        return ' '.join(out) if out else 'id'

    def values(self, mv):
        vals = []
        for i in range(3):
            v = (self.fixed[i] == 1).copy()
            d = self.var[i]
            if d:
                rs = np.fromiter(d.keys(), np.int64, len(d)); ls = np.fromiter(d.values(), np.int64, len(d))
                ok = ls < len(mv)
                v[rs[ok]] = mv[ls[ok]]
            vals.append(v)
        return vals


def simp(cl):
    out = []
    for l in cl:
        if l == T: return None
        if l == -T: continue
        out.append(int(l))
    return out


class Search:
    def __init__(self, W, grd, cands, tgt, opts, solver='cadical153', verbose=True):
        self.W = W; self.grd = grd; self.opts = opts; self.verbose = verbose
        self.S = Solver(name=solver)
        self.act = {}; self.ntrans = 0; self.tkeys = set(); self.nphase = 0
        self.cand = [[W.idx[c] for c in cs] for cs in cands]
        self.tgt = tgt
        self.allc = sorted({C for cs in self.cand for C in cs})
        # selection
        self.sel = {}
        for v, cs in enumerate(self.cand):
            if len(cs) == 1:
                self.sel[(v, cs[0])] = T
            else:
                ls = [W.newvar() for _ in cs]
                for C, l in zip(cs, ls): self.sel[(v, C)] = l
                self.add(ls)
                for a in range(len(ls)):
                    for b in range(a + 1, len(ls)): self.add([-ls[a], -ls[b]])
        self.selany = {}
        for C in self.allc:
            vs = [self.sel[(v, C)] for v in range(len(self.cand)) if (v, C) in self.sel]
            if T in vs: self.selany[C] = T
            else:
                s = W.newvar(); self.selany[C] = s
                for l in vs: self.add([-l, s])
                self.add([-s] + vs)
        self.scache = {}
        self.build()

    # ---------------------------------------------------------------- helpers
    def actlit(self, key):
        if key not in self.act: self.act[key] = self.W.newvar()
        return self.act[key]

    def add(self, cl, key=None):
        c = simp(cl)
        if c is None: return
        if key is not None: c = c + [-self.actlit(key)]
        if not c:
            z = self.W.newvar(); self.S.add_clause([z]); self.S.add_clause([-z]); return
        self.S.add_clause(c)

    def s(self, v, X, i):
        """literal equivalent to C_v <=_i X (exactly one selection per point)."""
        key = (v, X, i)
        if key in self.scache: return self.scache[key]
        cs = self.cand[v]
        if len(cs) == 1:
            l = self.W.L(i, cs[0], X)
        else:
            l = self.W.newvar()
            for C in cs:
                a = self.W.L(i, C, X); sv = self.sel[(v, C)]
                self.add([-sv, -l, a]); self.add([-sv, -a, l])
        self.scache[key] = l
        return l

    # ---------------------------------------------------------------- constraints
    def build(self):
        W, g, o = self.W, self.grd, self.opts
        Xs = range(W.nF)
        t0 = time.time()
        if o.get('K', True):
            for v in range(len(self.cand)):
                if g['pts'][v].count(0) == 2: continue      # vertex: automatic by (G)
                for X in Xs:
                    self.add([self.s(v, X, i) for i in g['supp'][v]], ('K', v))
        # guarded members of C_L: grid-selected candidates always; with 'W' also every coherent
        # model of F may be declared a member (z_C), and then must be protected and obey (C).
        self.z = {}
        for C in self.allc: self.z[C] = self.selany[C]
        if o.get('W', False):
            for C in np.where(W.coh)[0]:
                C = int(C)
                if C in self.z: continue
                self.z[C] = W.newvar()
        if o.get('P', True):
            for C, sa in self.z.items():
                for X in Xs:
                    if X == C: continue
                    pre = [-sa] + [-W.L(i, X, C) for i in range(3)]
                    for j in range(3): self.add(pre + [W.L(j, C, X)], ('P', C if C in self.allc else 'z'))
        if o.get('C', True):
            for C, sa in self.z.items():
                for X in np.where(~W.coh)[0]:
                    self.add([-sa] + [-W.L(i, X, C) for i in range(3)] + [-W.L(i, C, X) for i in range(3)],
                             ('C', C if C in self.allc else 'z'))
        if o.get('W', False) or o.get('Wsel', False):
            pool = self.z if o.get('W', False) else {C: self.selany[C] for C in self.allc}
            for X in Xs:
                ys = []
                for C, zc in pool.items():
                    lits = [W.L(i, C, X) for i in range(3)]
                    if -T in lits: continue
                    y = W.newvar(); ys.append(y)
                    self.add([-y, zc])
                    for l in lits: self.add([-y, l])
                self.add(ys, ('W', X) if o.get('W_fine') else ('W',))
        cl = o.get('CL', None)
        if cl:
            for v in range(len(self.cand)):
                bd = len(g['supp'][v]) < 3
                if cl == 'ring' or (cl == 'ring-bd' and bd) or (cl == 'ring-vx' and len(g['supp'][v]) == 1):
                    for X in Xs:
                        for i in range(3):
                            self.add([-self.s(w, X, i) for w in g['nbr'][v]] + [self.s(v, X, i)], ('CL', v))
            if cl == 'simp':
                faces = [(t,) for t in range(len(self.cand))]
                faces += [tuple(sorted((a, b))) for a in g['nbr'] for b in g['nbr'][a] if a < b]
                faces += [tuple(t) for t in g['tris']]
                for f in faces:
                    if len(f) == 1: continue
                    supp = sorted(set().union(*[g['supp'][v] for v in f]))
                    for X in Xs:
                        zs = []
                        for i in supp:
                            z = W.newvar(); zs.append(z)
                            for v in f: self.add([-z, self.s(v, X, i)])
                        self.add(zs, ('CL', f))
        if self.verbose:
            print(f'  built: vars={W.nvar} act={len(self.act)} {time.time()-t0:.1f}s', flush=True)

    # ---------------------------------------------------------------- CEGAR for transitivity
    def check_T(self, model, cap=400000):
        W = self.W
        mv = np.zeros(W.nvar + 2, bool)
        pos = np.array([l for l in model if l > 0], np.int64)
        mv[pos[pos < len(mv)]] = True
        vals = W.values(mv)
        nadd = 0
        for i in range(3):
            Adj = vals[i][W.rec]
            A = Adj.astype(np.float32)
            two = (A @ A) > 0.5
            viol = np.argwhere(two & ~Adj)
            if not len(viol): continue
            np.random.shuffle(viol)
            for X, Z in viol[:cap]:
                Ys = np.where(Adj[X] & Adj[:, Z])[0]
                Y = Ys[np.random.randint(len(Ys))]
                key = (i, W.rec[X, Y], W.rec[Y, Z])
                if key in self.tkeys: continue
                self.tkeys.add(key); self.ntrans += 1
                self.add([-W.L(i, X, Y), -W.L(i, Y, Z), W.L(i, X, Z)]); nadd += 1
        return nadd, vals, mv

    def run(self, assumptions=None, maxit=2000, tlimit=3600):
        t0 = time.time()
        asm = list(self.act.values()) if assumptions is None else assumptions
        for it in range(1, maxit + 1):
            if self.W.nvar > self.nphase:
                self.S.set_phases([-v for v in range(self.nphase + 1, self.W.nvar + 1)])
                self.nphase = self.W.nvar
            if not self.S.solve(assumptions=asm):
                if self.verbose: print(f'  UNSAT it={it} trans={self.ntrans} {time.time()-t0:.1f}s', flush=True)
                return False, None
            model = self.S.get_model()
            nadd, vals, mv = self.check_T(model)
            if self.verbose and (it % 20 == 0 or nadd == 0):
                print(f'  it={it} +T {nadd} trans={self.ntrans} {time.time()-t0:.1f}s', flush=True)
            if nadd == 0 and self.opts.get('endorse', False):
                nadd = self.check_endorse(vals)
                if nadd: print(f'  it={it} +E {nadd} (composition certificates) {time.time()-t0:.1f}s', flush=True)
            if nadd == 0: return True, (vals, mv)
            if time.time() - t0 > tlimit: break
        return None, None

    # ------------------------------------------------ record-level composition via (M1) certificates
    def compose(self, r, s, i=None):
        """codes of r then s (r = d(X,Y), s = d(Y,Z)); None if not composable.  With world i given,
        a mismatch y -> y2 of the middle advice is bridged when y2 is world-i worse than y (a
        worsening step, accepted by (G)): 'composition modulo worsening glue'."""
        out = np.zeros(self.W.N, np.int8)
        for c in range(self.W.N):
            a, b = int(r[c]), int(s[c])
            if a == 0: out[c] = b; continue
            if b == 0: out[c] = a; continue
            x, y = PAIR[a]; y2, z = PAIR[b]
            if y != y2:
                if i is None: return None
                g = self.W.G[c]
                if rank('+0-'[y2], g, i) < rank('+0-'[y], g, i): return None
            out[c] = 0 if x == z else CODE[x, z]
        return out

    def closure_search(self, i, seed, vals, depth=16, cap=300000):
        """saturate the seed records under composition modulo worsening glue (both orders), with
        provenance; return (records used, None) for a derived pure improvement, (records used,
        r) for a derived record r of R(F) that is currently rejected, or None."""
        W = self.W
        if not hasattr(self, '_lookup'):
            used = np.unique(W.rec); self._lookup = {W.rcodes[r].tobytes(): int(r) for r in used}
        gens = [(W.rcodes[r], frozenset([r])) for r in seed]
        frontier = {g.tobytes(): (g, p) for g, p in gens}
        seen = set(frontier)
        for d in range(2, depth + 1):
            new = {}
            for cur, prov in frontier.values():
                for g, pg in gens:
                    for comp in (self.compose(cur, g, i), self.compose(g, cur, i)):
                        if comp is None or not comp.any(): continue
                        k = comp.tobytes()
                        if k in seen or k in new: continue
                        dd = W.dirs[i][np.arange(W.N), comp]
                        pr = prov | pg
                        if (dd < 0).any() and not (dd > 0).any(): return (sorted(pr), None)
                        if not (dd < 0).any(): continue
                        r = self._lookup.get(k)
                        if r is not None and W.fixed[i][r] == 0 and not vals[i][r]: return (sorted(pr), r)
                        new[k] = (comp, pr)
            seen.update(new); frontier = new
            if not new or len(seen) > cap: break
        return None

    def check_endorse(self, vals, maxk=6):
        """per world: if the accepted trades admit no strictly positive ladder endorsement, take a
        Farkas certificate (small support), and try to realise it as a composition chain whose
        composite is forbidden by strict (G); if found, add the clause 'not all of them'.  A
        certificate that is not a composition is stored in self.noncomp (genuine non-additivity
        candidate under the transition lemma)."""
        from scipy.optimize import linprog
        import itertools
        from diag import ladder_rows
        W = self.W; nadd = 0; self.noncomp = {}
        used = np.unique(W.rec)
        for i in range(3):
            acc = used[(W.fixed[i][used] == 0) & vals[i][used]]
            if not len(acc): continue
            R = ladder_rows(W.G, W.rcodes, acc, i).astype(float)
            n = R.shape[1]
            # Farkas: y >= 0, R^T y <= 0, -1^T R^T y >= 1 ; minimise sum y
            res = linprog(np.ones(len(acc)), A_ub=np.vstack([R.T, R.sum(1)[None, :]]),
                          b_ub=np.concatenate([np.zeros(n), [-1.0]]), bounds=[(0, None)] * len(acc),
                          method='highs')
            if res.status != 0: continue          # endorsable
            sup = np.where(res.x > 1e-9)[0]
            recs = [int(acc[k]) for k in sup]
            hit = self.closure_search(i, recs, vals)
            if hit is not None:
                used_recs, target = hit
                cl = [-W.lit_r(i, r) for r in used_recs]
                if target is not None: cl.append(W.lit_r(i, target))
                self.add(cl); nadd += 1
            else:
                self.noncomp[i] = (recs, res.x[sup].tolist())
        return nadd

    def core(self):
        inv = {a: k for k, a in self.act.items()}
        return [inv[a] for a in (self.S.get_core() or []) if a in inv]

    def minimize(self, keys, maxit=2000):
        """deletion-based minimal unsatisfiable set of constraint groups (T stays global)."""
        cur = list(keys); j = 0
        while j < len(cur):
            trial = cur[:j] + cur[j + 1:]
            ok, _ = self.run(assumptions=[self.act[k] for k in trial], maxit=maxit)
            if ok is False:
                c = set(self.core()); cur = [k for k in trial if k in c] or trial
            else:
                j += 1
        return cur

    def selection(self, mv):
        out = []
        for v, cs in enumerate(self.cand):
            out.append([C for C in cs if self.sel[(v, C)] == T or mv[self.sel[(v, C)]]])
        return out
