"""Theorem A diagnostic: the indifference-lexicographic local rule.
Exhaustive on small cell sets (exact integers). CHECKED as a finite diagnostic only."""
import numpy as np
from common import *

def run(cells, label):
    n = len(cells)
    M = all_models(n)
    R = rank_table(M, cells)
    rho = [indiff_weights(g) for g in cells]
    accs = []
    for w in range(3):
        d = R[w][None, :, :].astype(np.int16) - R[w][:, None, :].astype(np.int16)  # A->B
        acc = lex_accept(d, [rho[c][w] for c in range(n)])
        # strict (G)
        weak_worse = (d >= 0).all(axis=2)
        pure_impr = (d <= 0).all(axis=2) & (d < 0).any(axis=2)
        assert (acc | ~weak_worse).all(), 'weak guidance failed'
        assert not (acc & pure_impr).any(), 'strict guidance failed'
        V = tc_violations(acc)
        accs.append(acc)
        ties = acc & acc.T
        np.fill_diagonal(ties, False)
        print(f'[{label}] world {w+1}: TC violations {int(V.sum())}, single-world ties between distinct models {int(ties.sum())}')
    # models correct on U and never contradictory
    good = np.ones(len(M), bool)
    for c, g in enumerate(cells):
        good &= M[:, c] != 3
        if region(g) == 'U':
            good &= M[:, c] == (0 if g[0] > 0 else 1)
    strict = [accs[w] & ~accs[w].T for w in range(3)]
    comp = (strict[0] | strict[1] | strict[2])
    np.fill_diagonal(comp, True)
    print(f'[{label}] models correct on U, non-contradictory: {int(good.sum())}; '
          f'strictly competitive against every model: {int(comp[good].all(axis=1).sum())}')
    dom = accs[0] & accs[1] & accs[2] & (strict[0] | strict[1] | strict[2]).T  # B dominates A?
    # dominated[A] if exists B: B<=_w A all w, strict at some
    domB = (accs[0].T & accs[1].T & accs[2].T) & ((~accs[0]) | (~accs[1]) | (~accs[2]))
    print(f'[{label}] of these, dominated by some model: {int(domB[good].any(axis=1).sum())}')
    return M, accs

if __name__ == '__main__':
    # three mixed directions (one per M_k), a second radial piece of the M_1 direction, one unanimous cell
    cells = [(-1, 1, 1), (1, -1, 1), (1, 1, -1), (-2, 2, 2), (1, 1, 1)]
    M, accs = run(cells, 'A5')
    # brief point 4 pump at world 1: A -> B departs on {g,h}, B -> C retreats on {g,h,F}
    # g = M_3 cell (majority wrong at world 3, correct at 1); use world 1 with g in M_1, h in M_2, F in M_1
    cells2 = [(-1, 1, 1), (1, -1, 1), (-3, 1, 1), (1, 1, 1)]
    run(cells2, 'pump4')
