"""Decoupling diagnostic (Theorem B, Prop D, Lemma 2 control). Finite cells: diagnostics only.
Cells: three mixed directions, each in an inner piece (index c) and an outer piece (c+3).
'Bounded' record = support inside the inner pieces; its stand-in for 'not essentially bounded' is
support meeting an outer piece. Dominator-type records rec(C,Y): C, N layer-constant (conic stand-ins),
Y = N modified on inner pieces only."""
import sys, itertools, random
import numpy as np
from common import *

DIRS = [(-1, 1, 1), (1, -1, 1), (1, 1, -1)]
CELLS = DIRS + [tuple(2 * x for x in g) for g in DIRS]
NC = 6
INNER = [0, 1, 2]; OUTER = [3, 4, 5]
M = all_models(NC)
R = rank_table(M, CELLS)
RHO = [indiff_weights(g) for g in CELLS]
P17 = (17 ** np.arange(NC)).astype(np.int64)

def idx(model):
    i = 0
    for a in model: i = 4 * i + int(a)
    return i

def rec_code(A, B):
    c = np.where(A != B, 4 * A.astype(np.int64) + B, 16)
    return int((c * P17).sum())

# all-pairs record codes and boundedness
codes = np.where(M[:, None, :] != M[None, :, :], 4 * M[:, None, :].astype(np.int64) + M[None, :, :], 16)
codes = (codes * P17[None, None, :]).sum(axis=2)
bounded = (M[:, None, OUTER] == M[None, :, OUTER]).all(axis=2)

def delta(w):
    return R[w][None, :, :].astype(np.int8) - R[w][:, None, :].astype(np.int8)

DEL = [delta(w) for w in range(3)]
ACC_L = [lex_accept(DEL[w], [RHO[c][w] for c in range(NC)]) for w in range(3)]
GUID = [(DEL[w] >= 0).all(axis=2) for w in range(3)]

layer_const = [m for m in itertools.product(range(3), repeat=3)]  # advice in {acc, rej, sil}

def outer_delta(C, N, w):
    return [rank(N[c], CELLS[c + 3], w) - rank(C[c], CELLS[c + 3], w) for c in range(3)]

def compensated(C, N, w):
    return any(x > 0 for x in outer_delta(C, N, w))

def psi(C, N, w, tau):
    return sum(tau[w][c] * x for c, x in enumerate(outer_delta(C, N, w)))

def make_G(k, rng, mode, tau=None):
    G = []
    tries = 0
    while len(G) < k and tries < 200000:
        tries += 1
        C = rng.choice(layer_const); N = rng.choice(layer_const)
        if C == N: continue
        if mode == 'comp' and not all(compensated(C, N, w) for w in range(3)): continue
        if mode == 'psi' and not all(psi(C, N, w, tau) > 0 for w in range(3)): continue
        if mode == 'nocomp1':  # no compensation at world 1, compensation at 2 and 3
            if compensated(C, N, 0) or not (compensated(C, N, 1) and compensated(C, N, 2)): continue
        Nm = list(N) + list(N); Cm = list(C) + list(C)
        Y = list(Nm)
        E = [c for c in INNER if rng.random() < 0.6] or [rng.choice(INNER)]
        for c in E:
            Y[c] = rng.choice([a for a in range(4) if a != Nm[c]])
        if mode == 'nocomp1':  # keep only records that are not weak improvements at any world (strict (G))
            ok = True
            for w in range(3):
                d = [rank(Y[c], CELLS[c], w) - rank(Cm[c], CELLS[c], w) for c in range(NC)]
                if all(x <= 0 for x in d) and any(x < 0 for x in d): ok = False
            if not ok: continue
        G.append((tuple(Cm), tuple(Y), C, N))
    # NFI filter: drop records whose outer part is inverse of another's
    outer = {}
    keep = []
    for (Cm, Y, C, N) in G:
        key = tuple((C[c], N[c]) for c in range(3) if C[c] != N[c])
        inv = tuple((b, a) for (a, b) in key)
        if inv in outer: continue
        outer[key] = 1; keep.append((Cm, Y, C, N))
    return keep

def classify(acc_w, Gset, w, maxwit=2000):
    V = tc_violations(acc_w)
    pairs = np.argwhere(V)
    kinds = {}
    for (a, z) in pairs[:maxwit]:
        bs = np.nonzero(acc_w[a, :] & acc_w[:, z])[0]
        b = bs[0]
        def kind(x, y):
            if bounded[x, y]: return 'L'
            if codes[x, y] in Gset: return 'G'
            return 'g'
        t = ''.join(sorted([kind(a, b), kind(b, z), kind(z, a)]))
        kinds[t] = kinds.get(t, 0) + 1
    return int(V.sum()), kinds

NAMES = 'ARSX'
def show(i):
    return ''.join(NAMES[a] for a in M[i][:3]) + '|' + ''.join(NAMES[a] for a in M[i][3:])

def witness(acc, Gset, w):
    V = tc_violations(acc)
    a, z = np.argwhere(V)[0]
    b = np.nonzero(acc[a, :] & acc[:, z])[0][0]
    print(f'   witness at world {w+1} (inner|outer; A=accept R=reject S=silent X=contradiction):')
    print(f'   A={show(a)}  B={show(b)}  Z={show(z)}   A<=B, B<=Z, Z<=A accepted; A<=Z refused')

def run(mode, k, seed, tau=None, wit=False):
    rng = random.Random(seed)
    G = make_G(k, rng, mode, tau)
    Gset = set(rec_code(np.array(c), np.array(y)) for (c, y, _, _) in G)
    Gmask = np.isin(codes, np.fromiter(Gset, dtype=np.int64))
    tot = {}
    nviol = 0
    strictG_bad = 0
    for w in range(3):
        acc = np.where(bounded, ACC_L[w], GUID[w] | Gmask)
        pure_impr = (DEL[w] <= 0).all(axis=2) & (DEL[w] < 0).any(axis=2)
        strictG_bad += int((acc & pure_impr).sum())
        n, kinds = classify(acc, Gset, w)
        if wit and n: witness(acc, Gset, w); wit = False
        nviol += n
        for t, v in kinds.items(): tot[t] = tot.get(t, 0) + v
    print(f'mode={mode:8s} seed={seed} |G|={len(G):3d} strict(G) failures={strictG_bad} '
          f'TC-violating (A,Z) pairs={nviol} triangle types (sampled)={tot}')
    return tot

if __name__ == '__main__':
    tau = [[1, 1, 1], [1, 1, 1], [1, 1, 1]]
    for seed in range(4):
        run('comp', 40, seed, wit=(seed == 3))
    for seed in range(4):
        run('psi', 40, seed, tau)
    for seed in range(3):
        run('nocomp1', 10, seed, wit=(seed == 0))
