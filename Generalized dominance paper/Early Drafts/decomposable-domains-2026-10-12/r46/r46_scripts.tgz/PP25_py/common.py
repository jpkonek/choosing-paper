"""Shared cell machinery for PP25 diagnostics (finite cells: diagnostics only).
Advice codes: 0 = accept g, 1 = reject g (accept -g), 2 = silent, 3 = contradiction.
Rank at world w: correct 0, silent 1, wrong 2, contradiction 3."""
import itertools
import numpy as np
from fractions import Fraction as F

def rank(a, g, w):
    if a == 2: return 1
    if a == 3: return 3
    s = g[w]
    if a == 0: return 0 if s > 0 else 2
    return 0 if s < 0 else 2

def region(g):
    """Return 'U' or k (0-based) with world k the minority sign."""
    pos = [x > 0 for x in g]
    if all(pos) or not any(pos): return 'U'
    for k in range(3):
        if sum(pos) == 2 and not pos[k]: return k
        if sum(pos) == 1 and pos[k]: return k

def indiff_weights(g, mass=1):
    """rho_w on a cell: on M_i, rho_i = 2, rho_j = rho_k = 1 (uniform lambda indifference); U: 1."""
    r = region(g)
    if r == 'U': return [mass, mass, mass]
    return [2 * mass if w == r else mass for w in range(3)]

def all_models(ncell):
    return np.array(list(itertools.product(range(4), repeat=ncell)), dtype=np.int8)

def rank_table(models, cells):
    """R[w] : (nmodels, ncell) rank array."""
    out = []
    for w in range(3):
        R = np.zeros(models.shape, dtype=np.int8)
        for c, g in enumerate(cells):
            lut = np.array([rank(a, g, w) for a in range(4)], dtype=np.int8)
            R[:, c] = lut[models[:, c]]
        out.append(R)
    return out

def lex_accept(delta, rho_w):
    """delta: (nA, nB, ncell) rank change A->B at one world (int).
    Level 0: sum rho*delta; levels 1..ncell: single-cell rho*delta (cells as the B_n).
    Accept iff the first nonzero level is > 0 (or all zero)."""
    nA, nB, nc = delta.shape
    wd = delta.astype(np.int32) * np.array(rho_w, dtype=np.int32)[None, None, :]
    lev0 = wd.sum(axis=2)
    acc = lev0 > 0
    undecided = lev0 == 0
    for c in range(nc):
        v = wd[:, :, c]
        acc |= undecided & (v > 0)
        undecided &= (v == 0)
    acc |= undecided  # all levels zero: trivial record
    return acc

def tc_violations(acc):
    """Return boolean matrix V[A,Z]: Z<=A accepted, A<=Z refused, and some B with A<=B<=Z.
    Any (TC) violation A<=B<=Z, Z<A appears here."""
    a = acc.astype(np.float32)
    two = (a @ a) > 0.5
    return two & acc.T & ~acc
