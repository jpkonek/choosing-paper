"""NUMERICS (Monte Carlo on the sphere, tau = uniform): angular score vectors
s_v(X) = E_theta[ r_v(X(theta)) ] for coherent X = D_K, to test the Psi-certificate of Prop D:
is a family member N beaten at all three worlds by coherent models taking each alternative value?"""
import numpy as np
rng = np.random.default_rng(1)
G = rng.normal(size=(400000, 3)); G /= np.linalg.norm(G, axis=1)[:, None]

def advice(K):
    v = G @ np.array(K).T            # values m.g at the vertices of K
    acc = v.min(axis=1) > 0; rej = v.max(axis=1) < 0
    return np.where(acc, 0, np.where(rej, 1, 2))

def score(a):
    s = []
    for w in range(3):
        corr = np.where(G[:, w] > 0, 0, 1)
        r = np.where(a == 2, 1, np.where(a == corr, 0, 2))
        s.append(r.mean())
    return np.array(s)

u = np.ones(3) / 3
def tri(center, rad):
    return [center + rad * (np.eye(3)[i] - u) for i in range(3)]

N = tri(u, 0.15); aN = advice(N); sN = score(aN)
print('member N = D_K, K = u + 0.15(Delta - u): silent fraction %.4f, scores %s' % ((aN == 2).mean(), np.round(sN, 4)))
for name, K in [('precise centre u', [u]), ('vertex 1 of K', [N[0]]), ('vertex 2 of K', [N[1]]),
                ('half-size triangle', tri(u, 0.075)), ('precise e1-tilt 0.4,0.3,0.3', [np.array([.4, .3, .3])]),
                ('precise far e1-tilt 0.7,0.15,0.15', [np.array([.7, .15, .15])]),
                ('loosening u+0.25(Delta-u)', tri(u, 0.25))]:
    a = advice(K); s = score(a)
    d = sN - s
    print('%-36s Psi(C->N) = %s  all positive: %s' % (name, np.round(d, 4), bool((d > 0).all())))
# majority / minority split of precise-centre answers on N's silence
sil = aN == 2
cen = advice([u])
maj = np.sign(np.sign(G).sum(axis=1))
ans = np.where(cen == 0, 1, -1)
print('on Sil(N): precise centre gives majority answer on fraction %.4f' % ((ans == maj)[sil].mean()))
