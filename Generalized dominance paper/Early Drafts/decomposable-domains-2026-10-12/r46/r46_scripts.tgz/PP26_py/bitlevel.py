"""PP26: exact enumeration of mass-blind regional combination rules.

A record that is pure on every mixed region M_1, M_2, M_3 (and trivial on U)
has, at world i, a pattern in {T,W,I}^3 (trivial / pure worsening / pure
improvement for world i on that region).  A mass-blind rule accepts or refuses
by pattern alone.  Guidance: every nontrivial pattern in {T,W}^3 is accepted;
strict (G): every nontrivial pattern in {T,I}^3 is refused.  The free choice
is the set A_i of accepted *mixed* patterns (12 of them).

(TC) at pattern level: a triple of accepted patterns (x,y,z) is realisable as
a 3-cycle X->Y->Z->X iff on every region the three entries are all T or
contain both W and I.  No reverse of an accepted mixed pattern can be accepted
(x and swap(x) give a 2-pump), and reverses of guidance patterns are strict
improvements, so every realisable accepted triangle is a violation.

Rival directions d in {0,A,B}^3 out of an interior coherent model: world i
sees on region r: T if d_r=0; if r==i: I for B, W for A; else W for B, I for A.

Veto conditions of Theorem V:
 (a_ij) world i refuses (own I, M_j W, M_k I) and (own I, M_j W, M_k T)
 (b_i,f) world i refuses (own W, f I, other I) and (own W, f I, other T), f != i
Theorem V: (a_ij) for some i,j, or [for every i some f_i with (b_i,f_i)] => (S) fails.
"""
import itertools as it

T, W, I = 'T', 'W', 'I'
PATS = list(it.product([T, W, I], repeat=3))
def mixed(p): return W in p and I in p
def guid(p): return p != (T, T, T) and I not in p
MIXED = [p for p in PATS if mixed(p)]
GUID = [p for p in PATS if guid(p)]
assert len(MIXED) == 12

def realisable(x, y, z):
    for r in range(3):
        col = (x[r], y[r], z[r])
        if col == (T, T, T):
            continue
        if not (W in col and I in col):
            return False
    return True

def tc_safe(acc):
    E = list(acc) + GUID
    for x in E:
        for y in E:
            for z in E:
                if realisable(x, y, z):
                    return False
    return True

def bits(i, d):
    out = []
    for r in range(3):
        if d[r] == 0: out.append(T)
        elif r == i: out.append(I if d[r] == 'B' else W)
        else: out.append(W if d[r] == 'B' else I)
    return tuple(out)

DIRS = [d for d in it.product([0, 'A', 'B'], repeat=3) if d != (0, 0, 0)]

def covered(d, accs):
    for i in range(3):
        p = bits(i, d)
        if guid(p) or p in accs[i]:
            return True
    return False

# --- enumerate TC-safe accepted sets for one world (world-symmetric list) ---
safe = []
for mask in range(1 << 12):
    acc = frozenset(MIXED[k] for k in range(12) if mask >> k & 1)
    if tc_safe(acc):
        safe.append(acc)
print("TC-safe accepted sets of mixed patterns (per world):", len(safe))
maxsafe = [s for s in safe if not any(s < t for t in safe)]
print("maximal TC-safe sets:", len(maxsafe))
for s in maxsafe:
    print("   ", sorted(''.join(p) for p in s))

def pat(i, own, j, oj, k, ok):
    p = [None] * 3; p[i] = own; p[j] = oj; p[k] = ok; return tuple(p)

def veto_a(i, j, acc):
    k = 3 - i - j
    return pat(i, I, j, W, k, I) not in acc and pat(i, I, j, W, k, T) not in acc

def veto_b(i, f, acc):
    o = 3 - i - f
    return pat(i, W, f, I, o, I) not in acc and pat(i, W, f, I, o, T) not in acc

def theorem_V_applies(accs):
    if any(veto_a(i, j, accs[i]) for i in range(3) for j in range(3) if j != i):
        return 'a'
    if all(any(veto_b(i, f, accs[i]) for f in range(3) if f != i) for i in range(3)):
        return 'b'
    return None

# --- search all triples of maximal sets (monotonicity: covering only improves
#     with larger sets, and the veto conditions only weaken with larger sets,
#     so maximal sets are the hardest case for Theorem V) ---
n_cover = 0; escape = []
for a0 in maxsafe:
    for a1 in maxsafe:
        for a2 in maxsafe:
            accs = (a0, a1, a2)
            if all(covered(d, accs) for d in DIRS):
                n_cover += 1
                if theorem_V_applies(accs) is None:
                    escape.append(accs)
print("covering triples of maximal TC-safe sets:", n_cover)
print("covering triples escaping Theorem V:", len(escape))
for e in escape[:5]:
    print([sorted(''.join(p) for p in s) for s in e])

# --- sanity checks of named rules ---
def lex_acc(order):
    # world accepts iff first nontrivial region (in 'order') shows W
    acc = set()
    for p in MIXED:
        for r in order:
            if p[r] != T:
                if p[r] == W: acc.add(p)
                break
    return frozenset(acc)
def and_acc(): return frozenset()  # AND: any I region refuses -> no mixed pattern
def or_acc(): return frozenset(MIXED)
print("AND tc_safe:", tc_safe(and_acc()), " covers:", all(covered(d, (and_acc(),)*3) for d in DIRS),
      " uncovered:", [d for d in DIRS if not covered(d, (and_acc(),)*3)])
print("OR  tc_safe:", tc_safe(or_acc()))
for orders in [((0,1,2),)*3, ((1,2,0),(2,0,1),(0,1,2)), ((1,0,2),(0,1,2),(0,1,2))]:
    accs = tuple(lex_acc(o) for o in orders)
    print("lex", orders, "tc_safe:", all(tc_safe(a) for a in accs),
          " covers:", all(covered(d, accs) for d in DIRS), " Theorem V case:", theorem_V_applies(accs))

# --- (1) the maximal TC-safe sets are exactly the six lexicographic orders ---
lex_sets = {lex_acc(o) for o in it.permutations(range(3))}
print("maximal TC-safe sets == six lexicographic orders:", set(maxsafe) == lex_sets)
# --- (2) every TC-safe triple (no covering assumed) satisfies Theorem V ---
#     (veto conditions are inherited by subsets, so maximal sets suffice)
bad = [accs for accs in it.product(maxsafe, repeat=3) if theorem_V_applies(accs) is None]
print("triples of maximal TC-safe sets escaping Theorem V (no covering assumed):", len(bad))
# --- (3) direct check over ALL 265^3 triples would be 18.6M; spot-check 200k random ---
import random
random.seed(1)
cnt = 0
for _ in range(200000):
    accs = tuple(random.choice(safe) for _ in range(3))
    if theorem_V_applies(accs) is None: cnt += 1
print("random TC-safe triples escaping Theorem V:", cnt, "of 200000")
# --- (4) the B-ward three-class rival under PP4's Sigma_loc row 5 ---
# Sigma_loc refuses 'foreign adds, own-class removes' = own I with all foreign W/T.
sig = []
for i in range(3):
    acc = set(MIXED)
    for p in MIXED:
        if p[i] == I and all(p[r] in (W, T) for r in range(3) if r != i):
            acc.discard(p)
    sig.append(frozenset(acc))
print("BBB pattern per world:", [''.join(bits(i, ('B','B','B'))) for i in range(3)],
      " covered under Sigma_loc row 5:", covered(('B','B','B'), sig))

# --- (5) single-world form of Theorem V: one world with one veto region suffices.
#     Check: EVERY TC-safe accepted set (for world i) has a veto region (own or majority).
def has_veto(i, acc):
    return any(veto_a(i, j, acc) for j in range(3) if j != i) or \
           any(veto_b(i, f, acc) for f in range(3) if f != i)
print("TC-safe sets without any veto region, per world:",
      [sum(1 for s in safe if not has_veto(i, s)) for i in range(3)])

# --- (6) covering triples of maximal sets: does some world put its own region first?
lex_of = {lex_acc(o): o for o in it.permutations(range(3))}
own_first = 0; ncov = 0
for accs in it.product(maxsafe, repeat=3):
    if all(covered(d, accs) for d in DIRS):
        ncov += 1
        own_first += any(lex_of[accs[i]][0] == i for i in range(3))
print("covering triples:", ncov, " with some world's own region first:", own_first)
