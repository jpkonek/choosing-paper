"""PP26 section 1: regional structure of coherent models (exact where stated).

Problem g in R^3, mixed, minority index k (the coordinate whose sign differs).
Representative with g_k < 0 < g_i, g_j.  Accepting g is good at the majority
worlds i, j: advice 'A'.  Accepting -g: 'B'.  D_K: A if min_K m.g > 0, B if
max_K m.g < 0, S otherwise.  World-w rank: A -> 0 if w majority else 2; B the
reverse; S -> 1.
"""
from fractions import Fraction as Fr
import random, itertools as it

def minority(g):
    s = [x > 0 for x in g]
    for k in range(3):
        if s[k] != s[(k+1) % 3] and s[(k+1) % 3] == s[(k+2) % 3]:
            return k
    return None

def normal(g):  # orient so minority coordinate negative
    k = minority(g)
    return (tuple(-x for x in g) if g[k] > 0 else tuple(g)), k

def advice(K, g):
    g, k = normal(g)
    vals = [sum(a*b for a, b in zip(m, g)) for m in K]
    if min(vals) > 0: return 'A'
    if max(vals) < 0: return 'B'
    return 'S'

def rank(adv, w, k):
    if adv == 'S': return 1
    good = 'B' if w == k else 'A'
    return 0 if adv == good else 2

def bary(*xs):
    t = sum(xs); return tuple(Fr(x) / t for x in xs)

# ---- 1. same edge projections, different M_1 profile (exact) ----
# ratios (m2/m1, m3/m1): K: (1,1)-(2,2); K': (1,2)-(2,1).
K  = [bary(1, 1, 1), bary(1, 2, 2)]
K2 = [bary(1, 1, 2), bary(1, 2, 1)]
def edge_proj(K, j):  # central projection onto [e1,e_j]: ratio m_j/m_1 range
    r = [m[j] / m[0] for m in K]; return (min(r), max(r))
print("edge projections K :", edge_proj(K, 1), edge_proj(K, 2))
print("edge projections K':", edge_proj(K2, 1), edge_proj(K2, 2))
g = (Fr(-7, 2), Fr(1), Fr(1))           # pencil s = 1/2
print("line (-7/2,1,1): D_K =", advice(K, g), "  D_K' =", advice(K2, g))
# a whole open set of lines differs:
diff = 0; tot = 0
for a in [Fr(33, 10) + Fr(i, 100) for i in range(40)]:
    for d in [Fr(9, 10) + Fr(j, 100) for j in range(21)]:
        tot += 1; diff += advice(K, (-a, Fr(1), d)) != advice(K2, (-a, Fr(1), d))
print("lines (-a,1,d), a in [3.3,3.7], d in [0.9,1.1]: differing", diff, "of", tot)

# ---- 2. pencil reduction: on lines (-a, s, 1-s) status depends only on psi_s-interval ----
def psi_interval(K, s):
    v = [(s*m[1] + (1-s)*m[2]) / m[0] for m in K]; return (min(v), max(v))
ok = True
random.seed(3)
for _ in range(2000):
    pts = [bary(*[random.randint(1, 20) for _ in range(3)]) for _ in range(3)]
    s = Fr(random.randint(1, 99), 100); a = Fr(random.randint(1, 400), 100)
    lo, hi = psi_interval(pts, s)
    pred = 'B' if a > hi else ('A' if a < lo else 'S')
    ok &= advice(pts, (-a, s, 1 - s)) == pred
print("pencil reduction (status = position of a against psi_s(K)), 2000 exact cases:", ok)

# ---- 3. precise models: nested on M_k iff delta_k not strictly between the others ----
def nested_on(p, q, k, lines):
    # world-k steps of D_p subset/superset of D_q on sampled M_k lines
    sub = sup = True
    for g in lines:
        rp = rank(advice([p], g), k, k); rq = rank(advice([q], g), k, k)
        sub &= rp <= rq; sup &= rp >= rq
    return sub or sup
import math
def rand_line(k):
    v = [random.uniform(0.01, 1) for _ in range(3)]; v[k] = -random.uniform(0.01, 3); return tuple(v)
random.seed(5)
lines = {k: [rand_line(k) for _ in range(4000)] for k in range(3)}
agree = 0; crossed_count = []; miss = err = 0; predcross = []
for _ in range(300):
    p = [random.uniform(0.05, 1) for _ in range(3)]; s = sum(p); p = [x/s for x in p]
    q = [random.uniform(0.05, 1) for _ in range(3)]; s = sum(q); q = [x/s for x in q]
    d = [math.log(q[r]) - math.log(p[r]) for r in range(3)]
    pred = [not (min(d[(k+1)%3], d[(k+2)%3]) < d[k] < max(d[(k+1)%3], d[(k+2)%3])) for k in range(3)]
    obs = [nested_on(p, q, k, lines[k]) for k in range(3)]
    agree += pred == obs; crossed_count.append(3 - sum(obs))
    miss += sum(1 for k in range(3) if (not pred[k]) and obs[k])   # sampling missed a crossing
    err += sum(1 for k in range(3) if pred[k] and not obs[k])      # would refute the rule
    predcross.append(3 - sum(pred))
print("median rule vs sampled nesting (precise pairs): agree", agree, "of 300;",
      "observed crossing seen where rule says nested (refutations):", err,
      "; crossings the sampler missed:", miss, "; predicted crossed regions per pair:", sorted(set(predcross)))

# ---- 4. T1 = D_M, M = c1 + eps*Delta: no product-max in the e1-ratio order ----
eps = Fr(3, 10); c = (1 - eps) / 3
M = [tuple(c + (eps if r == s else 0) for r in range(3)) for s in range(3)]
rat = [(m[1]/m[0], m[2]/m[0]) for m in M]
print("T1 vertices e1-ratios:", [(str(a), str(b)) for a, b in rat])
# T1 vs model with the same two edge projections but a product max:
x1, y1 = max(r[0] for r in rat), max(r[1] for r in rat)
x0, y0 = min(r[0] for r in rat), min(r[1] for r in rat)
Kbox = [bary(1, x0, y0), bary(1, x1, y1)]
print("same edge projections:", edge_proj(M, 1) == edge_proj(Kbox, 1), edge_proj(M, 2) == edge_proj(Kbox, 2))
g = (-(x1 + y1) * Fr(97, 100), Fr(1), Fr(1))
print("line", tuple(map(str, g)), ": T1 =", advice(M, g), " D_box =", advice(Kbox, g))

# ---- 5. homothety chain toward e1: world-1 rank nonincreasing in t on every problem ----
def homot(M, t, v):
    return [tuple((1 - t) * m[r] + t * (1 if r == v else 0) for r in range(3)) for m in M]
ts = [Fr(i, 20) for i in range(21)]
allg = [rand_line(k) for k in range(3) for _ in range(700)]
mono = True; nestall = True
for g in allg:
    ranks1 = [rank(advice(homot(M, t, 0), g), 0, minority(g)) for t in ts]
    mono &= all(ranks1[i+1] <= ranks1[i] for i in range(len(ts) - 1))
print("homothety toward e1: world-1 rank nonincreasing in t on 2100 problems:", mono)
# per region and world: chain nested
for w in range(3):
    for k in range(3):
        rows = [[rank(advice(homot(M, t, 0), g), w, k) for t in ts] for g in lines[k][:700]]
        inc = all(r[i+1] >= r[i] for r in rows for i in range(len(ts)-1))
        dec = all(r[i+1] <= r[i] for r in rows for i in range(len(ts)-1))
        nestall &= inc or dec
print("homothety chain monotone (hence nested) on every region at every world:", nestall)

# ---- 6. tripod legs toward e1 and e2 cross on M_3 (exact witnesses) ----
s = Fr(1, 2)
L1 = homot(M, s, 0); L2 = homot(M, s, 1)
wit = []
for g in lines[2]:
    gg = tuple(Fr(x).limit_denominator(1000) for x in g)
    if minority(gg) != 2: continue
    r1 = rank(advice(L1, gg), 2, 2); r2 = rank(advice(L2, gg), 2, 2)
    if r1 != r2: wit.append((r1 < r2, gg))
print("M_3 lines where leg1 better at world 3:", sum(1 for b, _ in wit if b),
      "; where leg2 better:", sum(1 for b, _ in wit if not b), " -> crossed on M_3")
for b in (True, False):
    for bb, gg in wit:
        if bb == b:
            print("   witness", tuple(map(str, gg)), "leg1:", advice(L1, gg), "leg2:", advice(L2, gg)); break
