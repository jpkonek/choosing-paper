"""PP26 section 5 (diagnostic only; finite cells have atoms).

Chain lift: common region order (M_1, M_2, M_3); on the first region where a
record is nontrivial, each world uses its side's two-world gated verdict
(strong gate in chain-adapted keys, sticky verdict 2*added - removed >= 0).
Chain: C_t = D_{K_t}, K_t = (1-t)M + t e_1, M = c1 + eps*Delta, eps = 3/10.
Problems: 3 random lines per mixed region, random masses.  All 4^9 models.
Checks: competitiveness and undominatedness of chain members; no 2-/3-cycles
on a sample; Theorem V's X = (B on M_1, B on M_2, A on M_3) and AAA have no
dominator among sampled coherent models; a tripod-leg model (homothety toward
e_2) is not competitive under the chain keys.
"""
import numpy as np, itertools as it, random
rng = np.random.default_rng(2)
random.seed(2)
eps = 0.3; c = (1 - eps) / 3
Mv = np.array([[c + (eps if r == s else 0) for r in range(3)] for s in range(3)])
NPR = 3
probs = []; region = []
for k in range(3):
    for _ in range(NPR):
        g = rng.uniform(0.05, 1, 3); g[k] = -rng.uniform(0.05, 2.5); probs.append(g); region.append(k)
probs = np.array(probs); region = np.array(region); P = len(probs)
mass = rng.uniform(0.5, 1.5, P)

def coh_adv(V):            # advice codes A=0,S=1,B=2 of D_conv(V)
    vals = probs @ V.T     # P x nverts  (minority coordinate negative -> accepting g is A)
    return np.where(vals.min(1) > 0, 0, np.where(vals.max(1) < 0, 2, 1))
def ranks(adv):            # adv: (..., P) codes A0 S1 B2 X3 -> ranks (3, ..., P)
    out = []
    for w in range(3):
        own = (region == w)
        r = np.where(adv == 3, 3, np.where(adv == 1, 1,
             np.where(adv == 0, np.where(own, 2, 0), np.where(own, 0, 2))))
        out.append(r)
    return np.stack(out)
def chain(t, v=0):
    e = np.zeros(3); e[v] = 1
    return (1 - t) * Mv + t * e

# chain-adapted keys per (world-side, problem, level j=1..3)
tgrid = np.linspace(0, 1, 4001)
R_grid = np.stack([ranks(coh_adv(chain(t))) for t in tgrid])        # T x 3 x P
key = np.zeros((3, P, 4))
for w in range(3):
    for p in range(P):
        rr = R_grid[:, w, p]
        dec = (np.diff(rr) <= 0).all(); inc = (np.diff(rr) >= 0).all()
        assert dec or inc
        for j in (1, 2, 3):
            mem = rr >= j
            tau = rng.uniform(0, 0.5)
            if mem.all(): key[w, p, j] = 2 + tau
            elif not mem.any(): key[w, p, j] = (-2 if j == 3 else -1) - tau
            else:
                tstar = tgrid[np.argmax(mem != mem[0])]
                key[w, p, j] = tstar if dec else -tstar
# majority worlds on a region share ranks; make their keys identical
for k in range(3):
    maj = [w for w in range(3) if w != k]
    key[maj[1], region == k] = key[maj[0], region == k]

ALL = np.array(list(it.product(range(4), repeat=P)), dtype=np.int8)    # 262144 x 9
R_all = ranks(ALL)                                                    # 3 x N x P

def accept(rO, rN):
    """rO, rN: (3,N,P) ranks of old and new models (broadcastable). Returns (3,N) bool: old <=_w new."""
    rO, rN = np.broadcast_arrays(rO, rN)
    N = rO.shape[1]
    res = np.zeros((3, N), bool)
    diff = (rO[0] != rN[0])                       # advice differs <=> world-1 rank differs
    regdiff = np.stack([diff[:, region == k].any(1) for k in range(3)], 1)
    ident = ~regdiff.any(1)
    first = np.argmax(regdiff, 1)
    for w in range(3):
        acc = np.zeros(N, bool)
        for k in range(3):
            sel = (first == k) & ~ident
            mx_add = np.full(N, -np.inf); mn_rem = np.full(N, np.inf)
            m_add = np.zeros(N); m_rem = np.zeros(N)
            for p in np.where(region == k)[0]:
                a = rO[w][:, p]; b = rN[w][:, p]
                for j in (1, 2, 3):
                    added = (b >= j) & (a < j); removed = (a >= j) & (b < j)
                    mx_add = np.where(added, np.maximum(mx_add, key[w, p, j]), mx_add)
                    mn_rem = np.where(removed, np.minimum(mn_rem, key[w, p, j]), mn_rem)
                    m_add += added * mass[p]; m_rem += removed * mass[p]
            ok = (m_rem == 0) | ((m_add > 0) & (mx_add <= mn_rem) & (2 * m_add - m_rem >= 0))
            acc |= sel & ok
        res[w] = acc | ident
    return res

def check_model(adv, label):
    rC = ranks(adv)[:, None, :]
    fwd = accept(rC, R_all)                # C <=_w R
    rev = accept(R_all, rC)                # R <=_w C
    isC = (ALL == adv[None, :]).all(1)
    comp_fail = int((~fwd.any(0) & ~isC).sum())
    dominated_by = int((rev.all(0) & ~isC).sum())
    print(f"{label}: rivals refused at every world: {comp_fail};  models weakly better at all worlds: {dominated_by}")
    return comp_fail, dominated_by

members = [0.0] + list(np.linspace(0.0003, 0.9997, 9))
tot = [0, 0]
for t in members:
    cf, db = check_model(coh_adv(chain(t)), f"chain t={t:.4f}")
    tot[0] += cf; tot[1] += db
print("chain members:", len(members), " competitiveness failures:", tot[0], " dominations:", tot[1])

# tripod leg toward e_2 (not regionally nested with the chain)
for sl in (0.2, 0.4):
    check_model(coh_adv(chain(sl, v=1)), f"leg toward e_2, s={sl}")

# acyclicity sample: models within 2 changes of chain members
samp = set()
for t in members:
    base = coh_adv(chain(t))
    for _ in range(40):
        m = base.copy()
        for p in rng.choice(P, size=rng.integers(1, 3), replace=False): m[p] = rng.integers(4)
        samp.add(tuple(m))
samp = np.array(sorted(samp), dtype=np.int8); n = len(samp); Rs = ranks(samp)
cyc = 0
for w in range(3):
    A = np.zeros((n, n), np.int64)
    for i in range(n):
        A[i] = accept(Rs[:, i:i+1, :], Rs)[w]
    np.fill_diagonal(A, 0)
    A2 = A @ A; A3 = A2 @ A
    cyc += int(np.trace(A2) > 0) + int(np.trace(A3) > 0)
print(f"sampled models: {n}; worlds with a 2- or 3-cycle among them: {cyc}")

# Theorem V witnesses: X12 = (B on M_1, B on M_2, A on M_3), AAA
X12 = np.where(region == 2, 0, 2).astype(np.int8); AAA = np.zeros(P, np.int8)
cohs = [coh_adv(chain(t)) for t in np.linspace(0, 1, 41)] + [coh_adv(np.eye(3)[[v]]) for v in range(3)]
for _ in range(3000):
    nv = rng.integers(1, 4); V = rng.dirichlet(np.ones(3) * rng.uniform(0.2, 3), size=nv); cohs.append(coh_adv(V))
cohs = np.unique(np.array(cohs, dtype=np.int8), axis=0)
for X, name in ((X12, "X^(1,2)"), (AAA, "AAA")):
    accd = accept(ranks(cohs), ranks(X)[:, None, :])
    print(f"{name}: distinct sampled coherent profiles {len(cohs)}; dominators at all three worlds: {int(accd.all(0).sum())}")
