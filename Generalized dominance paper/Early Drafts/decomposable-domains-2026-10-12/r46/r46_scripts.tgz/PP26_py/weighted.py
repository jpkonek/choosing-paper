"""PP26 section 3: region-weighted (mass-linear) combination rules.

(a) Sticky region sums (kappa = 2) are pumps: exact instance.
(b) Covering of the A-ward and B-ward three-class rivals vs spreads sigma_i:
    LP decision of 'exists m > 0 uncovered' compared with Perron roots.
(c) The endorsement triangle at sigma = 1: exact instance against a
    within-region sticky record.
"""
from fractions import Fraction as Fr
import numpy as np, random
from scipy.optimize import linprog

# (a) world i, region weights 1, verdict sum_r (2*added_r - removed_r) >= 0 on pure parts
def sticky(added, removed): return 2 * sum(added) - sum(removed) >= 0
# X->Y: removes 2 on R1 (gain), adds 1 on R2.  Y->Z: removes the 1 on R2, adds 1/2 back on R1.
s1 = sticky(added=[Fr(1)], removed=[Fr(2)])
s2 = sticky(added=[Fr(1, 2)], removed=[Fr(1)])
print("(a) X<=Y:", s1, " Y<=Z:", s2, " net X->Z removes 3/2 on R1 and adds nothing: strict improvement,"
      " so Z<X by guidance and X<=Z fails by strict (G): (TC) violated")

# (b) covering vs spreads
def uncovered_exists(Mat):
    # exists m >= 1e-3 componentwise with (Mat m)_i >= m_i + 1e-6 ... scale-free: test strict via LP
    # maximise t s.t. Mat m - m >= t, sum m = 1, m >= 0.01 ; uncovered iff t > 0
    n = Mat.shape[0]
    c = np.zeros(n + 1); c[-1] = -1
    A_ub = np.hstack([-(Mat - np.eye(n)), np.ones((n, 1))]); b_ub = np.zeros(n)
    A_eq = np.hstack([np.ones((1, n)), np.zeros((1, 1))]); b_eq = [1]
    bounds = [(1e-3, None)] * n + [(None, None)]
    r = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq, bounds=bounds)
    return -r.fun > 1e-9
rng = np.random.default_rng(7)
viol = 0; trials = 0; both_cov_at_sigma1 = 0
for _ in range(3000):
    F = rng.uniform(0.1, 3, (3, 3)); np.fill_diagonal(F, 0)
    alpha = rng.uniform(0.1, 3, 3)
    B = F / alpha[:, None]
    sig = np.where(rng.random(3) < 0.5, 1.0, rng.uniform(1.0, 1.5, 3))
    if np.all(sig == 1.0): sig[rng.integers(3)] = rng.uniform(1.0001, 1.5)
    S = np.diag(sig)
    A_unc = uncovered_exists(S @ B)                    # A-ward rival refused everywhere: S B m > m
    B_unc = uncovered_exists(2 * np.eye(3) - np.diag(1/sig) @ B)   # (2I - S^-1 B)m > m  <=>  S^-1 B m < m
    trials += 1; viol += not (A_unc or B_unc)
print("(b) random weights with some sigma_i > 1: cases where both rivals are covered:", viol, "of", trials)
# at sigma = 1 with rho(B) = 1 exactly: both covered; with rho != 1 one fails
cnt = 0
for _ in range(500):
    F = rng.uniform(0.1, 3, (3, 3)); np.fill_diagonal(F, 0); alpha = rng.uniform(0.1, 3, 3)
    B = F / alpha[:, None]; B = B / max(abs(np.linalg.eigvals(B)))
    A_unc = uncovered_exists(B); B_unc = uncovered_exists(2 * np.eye(3) - B)
    cnt += (not A_unc) and (not B_unc)
print("    sigma = 1, rho(B) = 1: both covered in", cnt, "of 500")

# (c) endorsement triangle: within-region sticky record X->Y adds A (mass 1), removes B (mass 2)
fA, fB = Fr(1), Fr(2); fC = Fr(3, 2)       # f(A) <= f(C) < f(B), C on another region
YZ = fC >= fA      # Y->Z removes A, adds C
ZX = fB >= fC      # Z->X adds B, removes C
XZ = fC >= fB      # X->Z removes B, adds C
print("(c) X<=Y (sticky: 2*1-2>=0):", 2*fA - fB >= 0, " Y<=Z:", YZ, " Z<=X:", ZX, " X<=Z:", XZ,
      " -> accepted triangle without its reverse: (TC) violated")
