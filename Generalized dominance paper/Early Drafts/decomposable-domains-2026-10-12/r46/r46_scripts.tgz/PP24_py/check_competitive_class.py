"""PP24 diagnostic for Conjecture 7.3: which coherent cell models are competitive?

Random coherent credal polygons K (1-6 vertices) and random contractions /
coarsenings of M.  For each cell model D_K: is it equal (on cells) to a member
of the family?  Is it competitive against all rivals differing on <= 2 atoms
plus 3,000 random 3-atom rivals?  Cells are coarse: this is a diagnostic only.
"""
import itertools, random, sys
import numpy as np
from fractions import Fraction as F
from geom import *
from cells import Cells, R

rng = random.Random(21)
nr = np.random.default_rng(21)
cl = Cells()
out = []


def log(s):
    print(s); sys.stdout.flush(); out.append(s)


T = cl.coherent(V)
fam = [T]
for u in W:
    for m in range(1, 400):
        fam.append(cl.coherent(chain_K(u, F(m, 400))))
fam = np.unique(np.array(fam), axis=0)


def local_rivals(X, n3=3000):
    rows = []
    for a in range(cl.na):
        for v in range(4):
            if v != X[a]:
                Y = X.copy(); Y[a] = v; rows.append(Y)
    for a, b in itertools.combinations(range(cl.na), 2):
        for v in range(4):
            if v == X[a]:
                continue
            for v2 in range(4):
                if v2 == X[b]:
                    continue
                Y = X.copy(); Y[a] = v; Y[b] = v2; rows.append(Y)
    idx = np.array([nr.choice(cl.na, 3, replace=False) for _ in range(n3)])
    Y3 = np.repeat(X[None, :], n3, axis=0)
    for c in range(3):
        Y3[np.arange(n3), idx[:, c]] = (Y3[np.arange(n3), idx[:, c]] + nr.integers(1, 4, n3)) % 4
    return np.vstack([np.array(rows, dtype=np.int8), Y3])


def competitive(X):
    Ys = local_rivals(X)
    ok = np.zeros(len(Ys), bool)
    for w in W:
        ok |= cl.accept(w, X, Ys)
    return ok.all()


def rand_simplex_pt():
    x = [rng.random() for _ in range(3)]
    s = sum(x)
    a, b = F(int(10000 * x[0] / s), 10000), F(int(10000 * x[1] / s), 10000)
    return (a, b, 1 - a - b)


models = []
for _ in range(300):
    K = [rand_simplex_pt() for _ in range(rng.randint(1, 6))]
    models.append(('random', K))
for _ in range(150):
    th = F(rng.randint(1, 99), 100)
    p = rand_simplex_pt()
    models.append(('contract-to-p', contract(V, 0, F(0)) and [add(scal(1 - th, m), scal(th, p)) for m in V]))
for _ in range(150):
    models.append(('coarsen', V + [rand_simplex_pt()]))

stats = {}
for kind, K in models:
    X = cl.coherent(K)
    in_fam = bool((fam == X[None, :]).all(axis=1).any())
    comp = competitive(X)
    uw = [bool((cl.ranks(w, X)[0] <= cl.ranks(w, T)[0]).all()) for w in W]
    key = (kind, in_fam, comp, any(uw))
    stats[key] = stats.get(key, 0) + 1
for k in sorted(stats, key=str):
    log(f"kind={k[0]:14s} in_family={k[1]!s:5s} competitive={k[2]!s:5s} u-ward_of_T={k[3]!s:5s}: {stats[k]}")
open('check_competitive_class.out', 'w').write('\n'.join(out) + '\n')


# ---- targeted rivals for the survivors: one crossing pair per world --------
def crossing_rival_search(X, tries=20000):
    a = np.arange(cl.na)
    pairs = {}
    for w in W:
        r = cl.rk[w, a, X]
        has = [(cl.key[w, at, j], at, j) for at in range(cl.na) for j in (1, 2, 3) if j <= r[at]]
        lacks = [(cl.key[w, at, j], at, j) for at in range(cl.na) for j in (1, 2, 3) if j > r[at]]
        pairs[w] = [(h, l) for h in has for l in lacks if h[0] < l[0] and h[1] != l[1]]
    if any(not pairs[w] for w in W):
        return None
    for _ in range(tries):
        Y = X.copy()
        used = set()
        okc = True
        for w in W:
            (kh, ah, jh), (kl, al, jl) = pairs[w][rng.randrange(len(pairs[w]))]
            if ah in used or al in used:
                okc = False; break
            used |= {ah, al}
            # lower rank of ah below jh, raise rank of al to >= jl, at world w
            lo = [v for v in range(4) if cl.rk[w, ah, v] < jh]
            hi = [v for v in range(4) if cl.rk[w, al, v] >= jl]
            Y[ah] = rng.choice(lo); Y[al] = rng.choice(hi)
        if not okc:
            continue
        if not any(cl.accept(w, X, Y[None, :])[0] for w in W):
            return Y
    return 'none found'


surv = 0
refuted = 0
for kind, K in models:
    X = cl.coherent(K)
    if (fam == X[None, :]).all(axis=1).any():
        continue
    if not competitive(X):
        continue
    surv += 1
    r = crossing_rival_search(X)
    if r is not None and not isinstance(r, str):
        refuted += 1
log(f"survivors of the local test outside the family: {surv}; refuted by a 6-atom crossing rival: {refuted}")
open('check_competitive_class.out', 'w').write('\n'.join(out) + '\n')
