"""PP24 geometry checks (exact rational arithmetic).

G1  Single-region footprints (Lemma 3.2): for d in (0, d*], wherever T answers
    and D_{conv(M u q_k(d))} is silent, g lies in M_k and T says B (minority).
    Sharpness: for d > d* a witness outside M_k exists.
G2  Footprints are nested in d, and two-point coarsenings have footprint
    F_a u F_b.
G3  Each chain is monotone u-ward: the world-u rank is nonincreasing in t, and
    every change of advice along the chain is regular (no contradiction).
G4  Chain members are u-ward of T: every point where they differ from T moves
    in the u-ward direction on the A-S-B line.
"""
import random
from fractions import Fraction as F
from geom import *

rng = random.Random(24)
out = []


def log(s):
    print(s)
    out.append(s)


T = V
log(f"c = {C}, eps = {EPS}, d* = {DSTAR}")

# ---------- G1 ----------
samples = [rand_g(rng) for _ in range(40000)]
# add near-boundary samples: perturbations of zeros of q.g for random lines
bad = 0
fp_count = {k: 0 for k in W}
for k in W:
    for d in [DSTAR / 7, DSTAR / 2, DSTAR]:
        K = coarsening(k, d)
        for g in samples:
            a_T = advice(T, g)
            a_C = advice(K, g)
            if a_T != 1 and a_C == 1:
                fp_count[k] += 1
                if region(g) != k or a_T != (2 if maj_answer(g) == 0 else 0):
                    bad += 1
log(f"G1: footprint points found per k (3 values of d): {fp_count}; violations: {bad}")

# targeted search near the edge of the footprint: g with q.g ~ 0 and v_i.g ~ 0
viol = 0
tested = 0
for k in W:
    i, j = [x for x in W if x != k]
    for _ in range(20000):
        # random line through a random point near q_k(d*) and near v_i
        K = coarsening(k, DSTAR)
        g = rand_g(rng, -60, 60)
        a_T, a_C = advice(T, g), advice(K, g)
        if a_T != 1 and a_C == 1:
            tested += 1
            if region(g) != k:
                viol += 1
log(f"G1 (wide random): footprint points {tested}, outside M_k: {viol}")

# sharpness witness for d slightly above d*: g = (-a, b, K) pattern from the proof
k = 2
i, j = 0, 1
for d in [DSTAR * F(11, 10), DSTAR * F(3, 2)]:
    K_ = coarsening(k, d)
    alpha = (C - d) / (C + (EPS + d) / 2)
    beta = C / (C + EPS)
    Kc = F(1)
    b = F(0)
    a = (b + alpha * Kc + beta * (Kc + b)) / 2      # strictly between bounds
    g = [F(0)] * 3
    g[k], g[j], g[i] = Kc, b + F(1, 10**6), -a
    g = tuple(g)
    log(f"G1 sharpness d = {d} (> d*): witness g = {tuple(float(x) for x in g)} region {region(g)}, "
        f"T advice {advice(T, g)}, coarsening advice {advice(K_, g)}")

# ---------- G2 ----------
nest_bad = 0
union_bad = 0
for k in W:
    Ks = [coarsening(k, DSTAR * F(m, 6)) for m in range(1, 7)]
    for g in samples[:15000]:
        a_T = advice(T, g)
        if a_T == 1:
            continue
        inside = [advice(K, g) == 1 for K in Ks]
        # nested: once inside, stays inside
        if any(inside[m] and not inside[m + 1] for m in range(5)):
            nest_bad += 1
for a_, b_ in [(0, 1), (1, 2), (2, 0)]:
    K2 = V + [q(a_, DSTAR), q(b_, DSTAR)]
    Ka, Kb = coarsening(a_, DSTAR), coarsening(b_, DSTAR)
    for g in samples[:15000]:
        if advice(T, g) == 1:
            continue
        lhs = advice(K2, g) == 1
        rhs = advice(Ka, g) == 1 or advice(Kb, g) == 1
        if lhs != rhs:
            union_bad += 1
log(f"G2: nesting violations {nest_bad}; two-point footprint != union: {union_bad}")

# ---------- G3, G4 ----------
tgrid = [F(m, 60) for m in range(0, 60)]
mono_bad = 0
uward_bad = 0
contra = 0
for u in W:
    Ks = [chain_K(u, t) for t in tgrid]
    for g in samples[:4000]:
        adv = [advice(K, g) for K in Ks]
        rk = [rank(x, g, u) for x in adv]
        if any(rk[m + 1] > rk[m] for m in range(len(rk) - 1)):
            mono_bad += 1
        if any(x == 3 for x in adv):
            contra += 1
        # u-ward of T: rank_u(member) <= rank_u(T) (T = adv[0])
        if any(r > rk[0] for r in rk):
            uward_bad += 1
log(f"G3/G4: chain monotonicity violations {mono_bad}; members not u-ward of T {uward_bad}; contradictions {contra}")
# phase check: chain_K(u, 0) = T, and the phase-1 members are the coarsenings C_{u-1}(d)
same = all(advice(chain_K(u, F(1, 6)), g) == advice(coarsening((u - 1) % 3, DSTAR / 2), g)
           for u in W for g in samples[:3000])
log(f"G3: phase-1 member of chain u at t=1/6 equals C_(u-1)(d*/2) on samples: {same}")

open('check_geometry.out', 'w').write('\n'.join(out) + '\n')
