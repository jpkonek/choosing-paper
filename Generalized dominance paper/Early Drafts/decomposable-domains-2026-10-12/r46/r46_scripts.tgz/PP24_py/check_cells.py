"""PP24 cell diagnostics for the T-anchored gate system (finite; not evidence for (S)).

C1 threshold property of members (T at every world; chain-u members at u;
   phase-1 members C_k(d) also at world k).
C2 competitiveness and undominatedness of every member against
   (a) every rival differing on 1 or 2 atoms (all advice values, incl. contradiction),
   (b) 60,000 random rivals differing on 3 atoms,
   (c) audit Prop-1 rivals (E_1, E_2, E_3, H on single radial atoms),
   (d) 20,000 fully random models.
   Also Lemma 2.4 as used in the undominatedness proof.
C3 acyclicity: no accepted 2- or 3-cycle, and no longer cycle (SCC test), on a pool.
C4 strict (G) on the pool.
"""
import itertools, random, sys
import numpy as np
from fractions import Fraction as F
from geom import *
from cells import Cells, R

rng = random.Random(1)
np_rng = np.random.default_rng(5)
cl = Cells()
out = []


def log(s):
    print(s)
    sys.stdout.flush()
    out.append(s)


log(f"directions {cl.nd}, atoms {cl.na}; categories: " +
    ', '.join(f"{k}:{sum(1 for c in cl.cat if c == k)}" for k in sorted(set(cl.cat), key=str)))

T = cl.coherent(V)
tgrid = [F(m, 12) for m in range(1, 12)] + [F(97, 100)]
members = [('T', None, None, T)]
for u in W:
    for t in tgrid:
        members.append((f'G{u+1}({t})', u, t, cl.coherent(chain_K(u, t))))
log(f"members: {len(members)}")

# ---------- C1 threshold ----------
def is_threshold(w, X):
    a = np.arange(cl.na)
    r = cl.rk[w, a, X]
    has, lacks = [], []
    for at in range(cl.na):
        for j in (1, 2, 3):
            (has if j <= r[at] else lacks).append(cl.key[w, at, j])
    return (not has) or (not lacks) or max(lacks) < min(has)


bad = []
for name, u, t, X in members:
    worlds = list(W) if u is None else [u]
    if u is not None and t <= F(1, 3):
        worlds.append((u - 1) % 3)      # C_{u-1}(d) is also threshold at world u-1
    for w in worlds:
        if not is_threshold(w, X):
            bad.append((name, w))
log(f"C1 threshold failures: {bad}")

# ---------- C2 ----------
def rivals_local(X, kmax_atoms, n3=60000):
    rows = []
    for a in range(cl.na):
        for v in range(4):
            if v != X[a]:
                Y = X.copy(); Y[a] = v; rows.append(Y)
    for a, b in itertools.combinations(range(cl.na), 2):
        for v in range(4):
            if v == X[a]:
                continue
            for v2 in range(4):
                if v2 == X[b]:
                    continue
                Y = X.copy(); Y[a] = v; Y[b] = v2; rows.append(Y)
    Ys = np.array(rows, dtype=np.int8)
    # random 3-atom rivals
    idx = np.array([np_rng.choice(cl.na, 3, replace=False) for _ in range(n3)])
    Y3 = np.repeat(X[None, :], n3, axis=0)
    for c in range(3):
        cur = Y3[np.arange(n3), idx[:, c]]
        shift = np_rng.integers(1, 4, n3)
        Y3[np.arange(n3), idx[:, c]] = (cur + shift) % 4
    return np.vstack([Ys, Y3])


def prop1_rivals(X, n=3000):
    """audit Prop 1: correct X at world i on E_i (where X not i-correct), change X on H."""
    rows = []
    a = np.arange(cl.na)
    for _ in range(n):
        Y = X.copy()
        used = set()
        ok = True
        for i in W:
            r = cl.rk[i, a, X]
            cand = [at for at in range(cl.na) if r[at] > 0 and at not in used]
            if not cand:
                ok = False; break
            at = rng.choice(cand); used.add(at)
            # i-correct advice at this atom
            g = cl.g[at // R]
            Y[at] = 0 if g[i] > 0 else 2
        cand = [at for at in range(cl.na) if at not in used and X[at] != T[at]]
        if not cand:
            cand = [at for at in range(cl.na) if at not in used]
        at = rng.choice(cand)
        Y[at] = (Y[at] + rng.randint(1, 3)) % 4
        if ok:
            rows.append(Y)
    return np.array(rows, dtype=np.int8).reshape(-1, cl.na)


tot = 0
fails_comp = []
fails_dom = []
fails_strong = []
for name, u, t, X in members:
    Ys = np.vstack([rivals_local(X, 3), prop1_rivals(X),
                    np_rng.integers(0, 4, (20000, cl.na)).astype(np.int8)])
    Ys = Ys[(Ys != X[None, :]).any(axis=1)]
    tot += len(Ys)
    comp = np.zeros(len(Ys), bool)
    allrev = np.ones(len(Ys), bool)
    rev_w, wb_w = {}, {}
    for w in W:
        comp |= cl.accept(w, X, Ys)
        rev = cl.accept_rev(w, Ys, X)
        allrev &= rev
        rY = cl.ranks(w, Ys)
        rX = cl.ranks(w, X)[0]
        rev_w[w] = rev
        wb_w[w] = (rY <= rX[None, :]).all(axis=1)
    # Lemma 2.4 as used in the proof: at a threshold world u of X, Y <=_u X implies
    # Y pointwise no worse at u; and for Y pointwise no worse at u, Y <=_v X (v != u)
    # implies Y pointwise no worse at v.
    tw = list(W) if u is None else [u]
    for uu in tw:
        bad1 = rev_w[uu] & ~wb_w[uu]
        if bad1.any():
            fails_strong.append((name, 'thr', uu, int(bad1.sum())))
        for v in W:
            if v == uu:
                continue
            bad2 = wb_w[uu] & rev_w[v] & ~wb_w[v]
            if bad2.any():
                fails_strong.append((name, 'other', uu, v, int(bad2.sum())))
    if (~comp).any():
        fails_comp.append((name, int((~comp).sum())))
    if allrev.any():
        fails_dom.append((name, int(allrev.sum())))
log(f"C2 rivals tested (all members): {tot}")
log(f"C2 competitiveness failures: {fails_comp}")
log(f"C2 members weakly dominated at all worlds: {fails_dom}")
log(f"C2 Lemma 2.4 failures (threshold world, then other worlds): {fails_strong}")

# ---------- C3, C4 on a pool ----------
pool = [m[3] for m in members]
for name, u, t, X in members[::3]:
    loc = rivals_local(X, 3, n3=200)
    pool.extend(loc[np_rng.choice(len(loc), 60, replace=False)])
pool.extend(np_rng.integers(0, 4, (150, cl.na)).astype(np.int8))
P = np.unique(np.array(pool, dtype=np.int8), axis=0)
n = len(P)
log(f"C3 pool size {n}")
cyc2 = cyc3 = 0
scc_bad = 0
G_bad = 0
for w in W:
    A = np.zeros((n, n), bool)
    for i in range(n):
        A[i] = cl.accept(w, P[i], P)
    np.fill_diagonal(A, False)
    cyc2 += int((A & A.T).sum() // 2)
    A2 = (A.astype(np.int32) @ A.astype(np.int32)) > 0
    cyc3 += int((A2 & A.T).sum())
    # strict (G): guidance pairs accepted; strict improvements never accepted
    rP = cl.ranks(w, P)
    for i in range(n):
        weak_worse = (rP >= rP[i][None, :]).all(axis=1)
        strict_better = (rP <= rP[i][None, :]).all(axis=1) & (rP < rP[i][None, :]).any(axis=1)
        acc = A[i].copy(); acc[i] = True
        if (weak_worse & ~acc).any() or (strict_better & acc).any():
            G_bad += 1
    # longer cycles: transitive closure by repeated squaring (boolean)
    Rch = A.copy()
    for _ in range(int(np.ceil(np.log2(n))) + 1):
        Rch = Rch | ((Rch.astype(np.int32) @ Rch.astype(np.int32)) > 0)
    scc_bad += int(np.diag(Rch).sum())
log(f"C3 accepted 2-cycles {cyc2}, 3-cycles {cyc3}, models on a cycle of any length {scc_bad}")
log(f"C4 strict (G) violations {G_bad}")

open('check_cells.out', 'w').write('\n'.join(out) + '\n')
