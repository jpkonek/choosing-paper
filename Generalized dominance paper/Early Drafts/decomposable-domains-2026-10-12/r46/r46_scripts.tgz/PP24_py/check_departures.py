"""PP24 checks of the lead's observations 3 and 4, and of Prop 2.6 (necessity).

O3  Relation G_w u Dep_w (guidance plus every departure that is not a pure
    improvement at w; a departure has old advice silent on its whole support).
    Check (TC) on a pool: every accepted triangle has all reverses.
O4  The pump: add retreats (answer -> silence, not a pure improvement at w);
    exhibit the (TC) violation of observation 4 on cells.
P26 Prop 2.6: in the T-anchored gate system, a coherent model that is worse
    than T somewhere at every world fails against a rival restoring T on three
    small atoms.  Checked on random coherent polygons K.
"""
import itertools, random, sys
import numpy as np
from fractions import Fraction as F
from geom import *
from cells import Cells, R

rng = random.Random(8)
nr = np.random.default_rng(8)
cl = Cells()
out = []


def log(s):
    print(s); sys.stdout.flush(); out.append(s)


def ranks(w, X):
    return cl.rk[w, np.arange(cl.na), X]


def is_departure(X, Y):
    d = X != Y
    return d.any() and (X[d] == 1).all()


def is_retreat(X, Y):
    d = X != Y
    return d.any() and (Y[d] == 1).all() and (X[d] != 1).all()


def guid(w, X, Y):
    return (ranks(w, Y) >= ranks(w, X)).all()


def pure_impr(w, X, Y):
    rx, ry = ranks(w, X), ranks(w, Y)
    return (ry <= rx).all() and (ry < rx).any()


def acc_dep(w, X, Y):
    return (X == Y).all() or guid(w, X, Y) or (is_departure(X, Y) and not pure_impr(w, X, Y))


def acc_depret(w, X, Y):
    return acc_dep(w, X, Y) or (is_retreat(X, Y) and not pure_impr(w, X, Y))


def tc_violations(acc, pool, w):
    n = len(pool)
    A = np.zeros((n, n), bool)
    for i in range(n):
        for j in range(n):
            A[i, j] = acc(w, pool[i], pool[j])
    viol = 0
    witness = None
    for i in range(n):
        for j in range(n):
            if not A[i, j]:
                continue
            for k in np.nonzero(A[j] & A[:, i])[0]:
                if not A[i, k]:
                    viol += 1
                    if witness is None:
                        witness = (i, j, int(k))
    return viol, witness


# pool: base models with silence, plus departures from them and retreats into them
base = []
T = cl.coherent(V)
for _ in range(25):
    X = nr.integers(0, 4, cl.na).astype(np.int8)
    X[nr.random(cl.na) < 0.5] = 1
    base.append(X)
base.append(T)
pool = list(base)
for X in base[:12]:
    for _ in range(8):
        Y = X.copy()
        sil = np.nonzero(X == 1)[0]
        if len(sil):
            idx = nr.choice(sil, min(len(sil), nr.integers(1, 4)), replace=False)
            Y[idx] = nr.choice([0, 2, 3], len(idx))
            pool.append(Y)
        Z = Y.copy()
        sil2 = np.nonzero(Z == 1)[0]
        if len(sil2):
            idx = nr.choice(sil2, min(len(sil2), 2), replace=False)
            Z[idx] = nr.choice([0, 2], len(idx))
            pool.append(Z)
pool = list(np.unique(np.array(pool), axis=0))
log(f"O3 pool {len(pool)}")
for w in W:
    v, wit = tc_violations(acc_dep, pool, w)
    log(f"O3 world {w+1}: (TC) violations with departures only: {v}")

# O4 pump, explicit on cells: world i = 0
i = 0
a_ = np.arange(cl.na)
# pick atoms g (wrong at 0 under advice 'acc g'), h (correct), F (wrong)
cands = list(range(cl.na))
gA = next(a for a in cands if cl.rk[i, a, 0] == 2)
hA = next(a for a in cands if cl.rk[i, a, 0] == 0 and a != gA)
fA = next(a for a in cands if cl.rk[i, a, 0] == 2 and a not in (gA, hA))
A = np.ones(cl.na, np.int8)          # all silent
A[fA] = 0                            # A wrong at i on F
B = A.copy(); B[gA] = 0; B[hA] = 0   # departure on {g, h}: wrong at g, correct at h
Cm = B.copy(); Cm[[gA, hA, fA]] = 1  # retreat on {g, h, F}
log(f"O4 pump: A<=B departure {acc_depret(i, A, B)}, B<=C retreat {acc_depret(i, B, Cm)}, "
    f"C<=A {acc_depret(i, Cm, A)}, A<=C {acc_depret(i, A, Cm)}, C strictly better than A at i: {pure_impr(i, A, Cm)}")
for w in W:
    v, wit = tc_violations(acc_depret, pool + [A, B, Cm], w)
    log(f"O4 world {w+1}: (TC) violations with departures and retreats: {v}")

# P26: coherent models worse than T somewhere at every world are not competitive
def rand_K():
    pts = []
    for _ in range(rng.randint(1, 5)):
        x = [rng.random() for _ in range(3)]
        s = sum(x)
        pts.append(tuple(F(int(1000 * t / s), 1000) for t in x[:2]) + (None,))
    return [(p[0], p[1], 1 - p[0] - p[1]) for p in pts]


tested = refuted = uward = 0
for _ in range(400):
    K = rand_K()
    Cm = cl.coherent(K)
    if (Cm == T).all():
        continue
    worse = [np.nonzero(ranks(w, Cm) > ranks(w, T))[0] for w in W]
    if any(len(x) == 0 for x in worse):
        uward += 1
        continue
    tested += 1
    Y = Cm.copy()
    for w in W:
        a = worse[w][0] if worse[w][0] % R == 0 else worse[w][0]
        Y[a] = T[a]
    ok = any(cl.accept(w, Cm, Y[None, :])[0] for w in W)
    if not ok:
        refuted += 1
log(f"P26 random coherent K: {tested} worse than T somewhere at every world, "
    f"{refuted} of them defeated by the restore-T rival; {uward} were u-ward of T (skipped)")

open('check_departures.out', 'w').write('\n'.join(out) + '\n')
