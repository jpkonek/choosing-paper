"""PP24 exact geometry (Fractions only).

Setting: three worlds, gambles g in Q^3, credal sets K in the simplex given by
vertex lists.  D_K accepts g iff m.g > 0 for all m in K (vertices suffice),
accepts -g iff m.g < 0 for all m in K, silent otherwise (boundary cases are
null in the continuum; the scripts never evaluate exactly on a boundary).

Advice codes on a representative g: 0 = accept g, 1 = silent,
2 = accept -g, 3 = contradictory.
"""
from fractions import Fraction as F
import itertools, random

EPS = F(3, 10)
C = (1 - EPS) / 3          # 7/30, the T1 instance (3c + eps = 1)
DSTAR = C * EPS / (3 * C + 2 * EPS)   # delta* = c eps / (3c + 2 eps) = 7/130

W = (0, 1, 2)


def e(i):
    v = [F(0)] * 3
    v[i] = F(1)
    return tuple(v)


def add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def scal(s, a):
    return tuple(s * x for x in a)


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


ONE = (F(1), F(1), F(1))
V = [add(scal(C, ONE), scal(EPS, e(i))) for i in W]      # vertices of M


def q(k, d):
    """Midpoint of the edge of M opposite v_k, pushed out by d (away from v_k)."""
    i, j = [x for x in W if x != k]
    mid = scal(F(1, 2), add(V[i], V[j]))
    direction = add(scal(F(1, 2), add(e(i), e(j))), scal(F(-1), e(k)))
    return add(mid, scal(d, direction))


def contract(Kverts, u, th):
    return [add(scal(1 - th, m), scal(th, e(u))) for m in Kverts]


def advice(Kverts, g):
    vals = [dot(m, g) for m in Kverts]
    lo, hi = min(vals), max(vals)
    if lo > 0:
        return 0
    if hi < 0:
        return 2
    return 1


def rank(adv, g, w):
    """World-w rank of advice code adv at representative g (g_w != 0)."""
    if adv == 1:
        return 1
    if adv == 3:
        return 3
    good = 0 if g[w] > 0 else 2
    return 0 if adv == good else 2


def region(g):
    """'U' for unanimous, else the minority world k (problem in M_k)."""
    pos = [x > 0 for x in g]
    if all(pos) or not any(pos):
        return 'U'
    if sum(pos) == 1:
        return pos.index(True)
    return pos.index(False)


def maj_answer(g):
    """Advice code of the majority answer A on a mixed problem."""
    pos = sum(1 for x in g if x > 0)
    return 0 if pos == 2 else 2


# ---- the three chains ------------------------------------------------------
# chain u: phase 1 grows q_{u-1}(d), d in [0, d*]   (t in [0, 1/3])
#          phase 2 grows q_{u+1}(d), d in [0, d*]   (t in [1/3, 2/3])
#          phase 3 contracts the result toward e_u    (t in [2/3, 1))

def chain_K(u, t):
    a, b = (u - 1) % 3, (u + 1) % 3
    t = F(t)
    if t <= F(1, 3):
        return V + [q(a, 3 * t * DSTAR)]
    if t <= F(2, 3):
        return V + [q(a, DSTAR), q(b, (3 * t - 1) * DSTAR)]
    th = 3 * t - 2
    return contract(V + [q(a, DSTAR), q(b, DSTAR)], u, th)


def coarsening(k, d):
    return V + [q(k, d)]


def rand_g(rng, lo=-20, hi=20):
    while True:
        g = tuple(F(rng.randint(lo, hi), rng.randint(1, 9)) for _ in W)
        if all(x != 0 for x in g):
            return g
