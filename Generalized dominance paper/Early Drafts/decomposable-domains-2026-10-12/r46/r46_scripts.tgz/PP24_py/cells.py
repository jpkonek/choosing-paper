"""PP24 cell model of the T-anchored gate system (diagnostic only).

Directions are chosen to cover every region and every advice type of T,
including points of each footprint F_k(d*) at several entry times.  Each
direction is split into R radial atoms; coherent models give the same advice
on all atoms of a direction, rivals need not.

Keys (world w, level j) at a direction g:
  T-step  (j <= r_w(T,g)):  exit time along chain w, in [0, 1)
  non-T, top subgroup: j = 1, g in M_w, T(g) = B, g in F_w(d*):
                             -1 - e_w(g) / (2 d*)  (e_w = entry time in d)
  other non-T:               -1.5 - 0.5*phi,  phi in (0,1) distinct
plus a radial tie-break of size 1e-9 * radial index (keys on cells must be
distinct, as level sets are null in the continuum).
"""
import random
import numpy as np
from fractions import Fraction as F
from geom import *

R = 2                        # radial atoms per direction
TIE = 1e-9


def pick_directions(seed=7):
    rng = random.Random(seed)
    T = V
    want = {}
    # categories per region k: 'fp' (footprint of q_k at d*), 'Bout', 'S', 'A'
    quota = {'fp': 0, 'Bout': 1, 'S': 3, 'A': 1}
    for k in W:
        for cat in quota:
            want[(k, cat)] = []
    want[('U', 'U')] = []
    Kfp = {k: coarsening(k, DSTAR) for k in W}
    tries = 0
    while True:
        tries += 1
        g = rand_g(rng, -40, 40)
        reg = region(g)
        if reg == 'U':
            if len(want[('U', 'U')]) < 2:
                want[('U', 'U')].append(g)
        else:
            aT = advice(T, g)
            if aT == 1:
                cat = 'S'
            elif aT == maj_answer(g):
                cat = 'A'
            else:
                cat = 'fp' if advice(Kfp[reg], g) == 1 else 'Bout'
            if len(want[(reg, cat)]) < quota[cat]:
                want[(reg, cat)].append(g)
        if all(len(v) >= (2 if key == ('U', 'U') else quota[key[1]]) for key, v in want.items()):
            break
        if tries > 2_000_000:
            raise RuntimeError('direction search failed')
    # footprint directions constructed at entry times d*/6, d*/2, 5d*/6 (Lemma 3.2):
    # g_i = -1, g_j = -1 - eta, g_k = b with q_k(s).g = 0 at s = entry time
    for k in W:
        i, j = [x for x in W if x != k]
        for m, sfrac in enumerate([F(1, 6), F(1, 2), F(5, 6)]):
            s_ = sfrac * DSTAR
            eta = F(1, 50 + 17 * m + 5 * k)
            g = [F(0)] * 3
            g[i], g[j] = F(-1), F(-1) - eta
            # solve q_k(s_).g = 0 for g_k
            qq = q(k, s_)
            g[k] = -(qq[i] * g[i] + qq[j] * g[j]) / qq[k]
            g = tuple(g)
            assert region(g) == k and advice(T, g) != 1
            assert advice(coarsening(k, s_ * F(101, 100)), g) == 1
            assert advice(coarsening(k, s_ * F(99, 100)), g) != 1
            want[(k, 'fp')].append(g)
    dirs = []
    for key, v in want.items():
        for g in v:
            dirs.append((g, key))
    return dirs


def exit_time(u, g, j, iters=40):
    """sup{t in [0,1): rank_u(chain_u(t), g) >= j}; exact predicate, bisection."""
    def ok(t):
        return rank(advice(chain_K(u, t), g), g, u) >= j
    if not ok(F(0)):
        return None
    lo, hi = F(0), F(1)
    if ok(F(999, 1000)):
        return float(F(999, 1000))
    for _ in range(iters):
        mid = (lo + hi) / 2
        if ok(mid):
            lo = mid
        else:
            hi = mid
    return float((lo + hi) / 2)


def entry_d(k, g, iters=40):
    def inside(d):
        return advice(coarsening(k, d), g) == 1
    if not inside(DSTAR):
        return None
    lo, hi = F(0), DSTAR
    for _ in range(iters):
        mid = (lo + hi) / 2
        if inside(mid):
            hi = mid
        else:
            lo = mid
    return float((lo + hi) / 2)


class Cells:
    def __init__(self, seed=7):
        self.dirs = pick_directions(seed)
        self.nd = len(self.dirs)
        self.na = self.nd * R
        self.g = [d[0] for d in self.dirs]
        self.cat = [d[1] for d in self.dirs]
        self.Tdir = [advice(V, g) for g in self.g]
        # key[w, atom, j] for j = 1..3 (index 0 unused)
        key = np.full((3, self.na, 4), np.nan)
        rng = random.Random(99)
        phis = list(range(1, 3 * 3 * self.nd + 1))
        rng.shuffle(phis)
        phi_it = iter(phis)
        nphi = len(phis) + 1
        for w in W:
            for di, g in enumerate(self.g):
                rT = rank(self.Tdir[di], g, w)
                ent = None
                if region(g) == w and rT == 0:
                    ent = entry_d(w, g)
                for j in (1, 2, 3):
                    if j <= rT:
                        kv = exit_time(w, g, j)
                    elif j == 1 and ent is not None:
                        kv = -1 - ent / (2 * float(DSTAR))
                    else:
                        kv = -1.5 - 0.5 * next(phi_it) / nphi
                    for r in range(R):
                        key[w, di * R + r, j] = kv + TIE * r
        self.key = key
        # max / min key over levels lo+1..hi
        self.kmax = np.full((3, self.na, 4, 4), np.nan)
        self.kmin = np.full((3, self.na, 4, 4), np.nan)
        for w in W:
            for a in range(self.na):
                for lo in range(4):
                    for hi in range(lo + 1, 4):
                        ks = key[w, a, lo + 1:hi + 1]
                        self.kmax[w, a, lo, hi] = ks.max()
                        self.kmin[w, a, lo, hi] = ks.min()
        # rank table: rk[w, atom, advice]
        self.rk = np.zeros((3, self.na, 4), dtype=np.int8)
        for w in W:
            for di, g in enumerate(self.g):
                for adv in range(4):
                    for r in range(R):
                        self.rk[w, di * R + r, adv] = rank(adv, g, w)

    def coherent(self, Kverts):
        return np.array([advice(Kverts, g) for g in self.g for _ in range(R)], dtype=np.int8)

    def accept(self, w, X, Ys):
        """Vectorised X <=_w Y for each row Y of Ys (gate with trivial verdict)."""
        Ys = np.atleast_2d(Ys)
        a = np.arange(self.na)
        rX = self.rk[w, a, X]                       # (na,)
        rY = self.rk[w, a[None, :], Ys]             # (n, na)
        up = rY > rX[None, :]
        dn = rY < rX[None, :]
        lo_up = np.broadcast_to(rX[None, :], rY.shape)
        kmax_add = np.where(up, self.kmax[w, a[None, :], lo_up, rY], -np.inf)
        kmin_rem = np.where(dn, self.kmin[w, a[None, :], rY, lo_up], np.inf)
        madd = kmax_add.max(axis=1)
        mrem = kmin_rem.min(axis=1)
        anyup = up.any(axis=1)
        anydn = dn.any(axis=1)
        same = ~(anyup | anydn)
        return same | (~anydn) | (anyup & (madd <= mrem))

    def accept_rev(self, w, Ys, X):
        """Vectorised Y <=_w X for each row Y."""
        Ys = np.atleast_2d(Ys)
        a = np.arange(self.na)
        rX = self.rk[w, a, X]
        rY = self.rk[w, a[None, :], Ys]
        up = rX[None, :] > rY            # X adds relative to Y
        dn = rX[None, :] < rY
        hiX = np.broadcast_to(rX[None, :], rY.shape)
        kmax_add = np.where(up, self.kmax[w, a[None, :], rY, hiX], -np.inf)
        kmin_rem = np.where(dn, self.kmin[w, a[None, :], hiX, rY], np.inf)
        madd = kmax_add.max(axis=1)
        mrem = kmin_rem.min(axis=1)
        anyup = up.any(axis=1)
        anydn = dn.any(axis=1)
        same = ~(anyup | anydn)
        return same | (~anydn) | (anyup & (madd <= mrem))

    def ranks(self, w, Ys):
        a = np.arange(self.na)
        return self.rk[w, a[None, :], np.atleast_2d(Ys)]
