"""PP24 domination diagnostics on cells (finite; not evidence for (S)).

D1 T strictly dominates every rival that is worse than T somewhere at each world.
D2 Every fill X of T's silence is strictly dominated at all three worlds by every
   C_k(d) (d on the grid) with k in W(X)  [Theorem 6.2 / Cor 6.3].
D3 PP20's class: X = T on the three footprints F_k(d*); every C_k(d), k in W(X).
D4 General sufficient condition of Theorem 6.2 on random rivals.
D5 Residual footprint rivals X = C_3(d*)[E -> A]: no member dominates them
   [Prop 6.5].
"""
import itertools, random, sys
import numpy as np
from fractions import Fraction as F
from geom import *
from cells import Cells, R

rng = random.Random(3)
nr = np.random.default_rng(11)
cl = Cells()
out = []


def log(s):
    print(s); sys.stdout.flush(); out.append(s)


T = cl.coherent(V)
a_ = np.arange(cl.na)
dgrid = [F(1, 12), F(1, 6), F(1, 4), F(1, 3)]          # phase-1 t values -> d = 3 t d*
Ck = {k: [cl.coherent(chain_K((k + 1) % 3, t)) for t in dgrid] for k in W}
for k in W:
    for t, X in zip(dgrid, Ck[k]):
        assert (X == cl.coherent(coarsening(k, 3 * t * DSTAR))).all()
members = [T] + [cl.coherent(chain_K(u, t)) for u in W for t in [F(m, 12) for m in range(1, 12)] + [F(97, 100)]]
Mem = np.array(members, dtype=np.int8)


def dominates(N, Xs):
    Xs = np.atleast_2d(Xs)
    ok = np.ones(len(Xs), bool)
    strict = np.zeros(len(Xs), bool)
    for w in W:
        ok &= cl.accept(w, N, Xs)
        strict |= ~cl.accept_rev(w, Xs, N)
    return ok & strict


def worse_somewhere(N, Xs, w):
    return (cl.ranks(w, Xs) > cl.ranks(w, N)[0][None, :]).any(axis=1)


def Wset(Xs):
    return np.stack([worse_somewhere(T, Xs, w) for w in W], axis=1)


# ---------- D1 ----------
Ys = nr.integers(0, 4, (30000, cl.na)).astype(np.int8)
loc = np.repeat(T[None, :], 30000, axis=0)
for i in range(30000):
    idx = nr.choice(cl.na, nr.integers(1, 6), replace=False)
    loc[i, idx] = nr.integers(0, 4, len(idx))
Ys = np.vstack([Ys, loc])
Ys = Ys[(Ys != T[None, :]).any(axis=1)]
Wm = Wset(Ys)
allw = Wm.all(axis=1)
d1 = dominates(T, Ys[allw])
log(f"D1 rivals worse than T at every world: {int(allw.sum())}; dominated by T: {int(d1.sum())}")
# and T dominates nothing else
d1b = dominates(T, Ys[~allw])
log(f"D1 rivals improving T weakly at some world that T dominates (should be 0): {int(d1b.sum())}")

# ---------- D2 fills ----------
sil = [a for a in range(cl.na) if T[a] == 1]
log(f"silent atoms: {len(sil)}")
fills = []
for a in sil:
    for v in (0, 2):
        X = T.copy(); X[a] = v; fills.append(X)
for a, b in itertools.combinations(sil, 2):
    for v in (0, 2):
        for v2 in (0, 2):
            X = T.copy(); X[a] = v; X[b] = v2; fills.append(X)
for _ in range(40000):
    X = T.copy()
    m = nr.random(len(sil)) < nr.random()
    X[np.array(sil)[m]] = nr.choice([0, 2], m.sum())
    fills.append(X)
Fl = np.unique(np.array(fills, dtype=np.int8), axis=0)
Fl = Fl[(Fl != T[None, :]).any(axis=1)]
Wf = Wset(Fl)
miss = 0
tot_pred = 0
for k in W:
    sel = Wf[:, k]
    for C in Ck[k]:
        dm = dominates(C, Fl[sel])
        tot_pred += int(sel.sum())
        miss += int((~dm).sum())
anydom = np.zeros(len(Fl), bool)
for N in Mem:
    anydom |= dominates(N, Fl)
log(f"D2 fills tested {len(Fl)}; predicted (k in W(X), every d) checks {tot_pred}, failures {miss}; "
    f"fills dominated by some member: {int(anydom.sum())}/{len(Fl)}")

# ---------- D3 PP20 class: X = T on footprints ----------
fp_atoms = {k: [a for a in range(cl.na) if cl.cat[a // R] == (k, 'fp')] for k in W}
Fall = sorted(sum(fp_atoms.values(), []))
Xs = nr.integers(0, 4, (30000, cl.na)).astype(np.int8)
Xs[:, Fall] = T[Fall]
# also sparse variants
for i in range(0, 30000, 2):
    keep = nr.random(cl.na) < 0.8
    Xs[i, keep] = T[keep]
Xs[:, Fall] = T[Fall]
Xs = Xs[(Xs != T[None, :]).any(axis=1)]
Wx = Wset(Xs)
miss = 0; tot = 0
for k in W:
    sel = Wx[:, k]
    for C in Ck[k]:
        dm = dominates(C, Xs[sel]); tot += int(sel.sum()); miss += int((~dm).sum())
log(f"D3 PP20-class rivals {len(Xs)}; checks {tot}; failures {miss}")

# ---------- D4 general condition ----------
def entry_t(a, k):
    """phase-1 t at which footprint atom a (of F_k) enters C_k: from key at world k."""
    kv = cl.key[k, a, 1] - 1e-9 * (a % R)
    return (-(kv + 1) * 2) / 3      # d/d* = -2(kv+1); t = d/(3 d*)


tested = fails = 0
for trial in range(30000):
    k = rng.choice(W)
    ti = rng.randrange(len(dgrid))
    C = Ck[k][ti]
    X = C.copy()
    # random changes anywhere
    idx = nr.choice(cl.na, rng.randint(1, 8), replace=False)
    X[idx] = nr.integers(0, 4, len(idx))
    # (d): on F_{k+1}(d*) atoms X in {B (= T there), contradiction}
    for a in fp_atoms[(k + 1) % 3]:
        if X[a] not in (T[a], 3):
            X[a] = T[a] if rng.random() < 0.7 else 3
    # conditions (a)-(c): worse than C at every world
    if not all(worse_somewhere(C, X[None, :], w)[0] for w in W):
        continue
    tested += 1
    if not dominates(C, X[None, :])[0]:
        fails += 1
log(f"D4 random rivals meeting (a)-(d): {tested}; not dominated by the stated C_k(d): {fails}")

# ---------- D5 residual ----------
k = 2
Cfull = cl.coherent(coarsening(k, DSTAR))
silk = [a for a in range(cl.na) if T[a] == 1 and cl.cat[a // R][0] == k]
res = []
for r in range(1, len(silk) + 1):
    for E in itertools.combinations(silk, r):
        X = Cfull.copy()
        for a in E:
            X[a] = maj_answer(cl.g[a // R])
        res.append(X)
Res = np.array(res, dtype=np.int8)
dom_any = np.zeros(len(Res), bool)
for N in Mem:
    dom_any |= dominates(N, Res)
log(f"D5 residual rivals C_3(d*)[E -> A]: {len(Res)}; dominated by some member: {int(dom_any.sum())}")
# sanity: they are dominated if footprint is only partly retreated (X keeps B on one footprint atom)
part = Res.copy()
part[:, fp_atoms[k][0]] = T[fp_atoms[k][0]]
dom_p = np.zeros(len(part), bool)
for N in Mem:
    dom_p |= dominates(N, part)
log(f"D5 control (B restored on the earliest-entry footprint atom): dominated {int(dom_p.sum())}/{len(part)}")

open('check_dominations.out', 'w').write('\n'.join(out) + '\n')
