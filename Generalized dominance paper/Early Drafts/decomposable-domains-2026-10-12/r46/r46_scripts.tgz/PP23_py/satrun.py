"""Build and solve the local-defence SAT on a cell model; report whether local dominations
are compatible with coverage of all coherent old sides plus (TC) and strict (G).
Usage: python3 -B satrun.py <config>"""
import sys, time
import numpy as np
from pysat.solvers import Cadical153
from cellsat import Model, direction

CONFIGS = {
    # two crossing (incomparable) lines in class M_1, two radial pieces each
    'cross1': ([direction(0, .3, .6), direction(0, .6, .3)], [0, 0], 2),
    # two nested (comparable) lines in M_1
    'nest1': ([direction(0, .3, .3), direction(0, .6, .6)], [0, 0], 2),
    # one line in M_1 and one in M_2
    'mix12': ([direction(0, .4, .5), direction(1, .45, .4)], [0, 1], 2),
    # one line, three radial pieces
    'one3': ([direction(0, .4, .5)], [0], 3),
    # three lines, one per class, no radial split (conic changes only; sanity)
    'tri1': ([direction(0, .4, .5), direction(1, .45, .4), direction(2, .5, .45)], [0, 1, 2], 1),
    # cyclic triple in M_1, no radial split
    'cyc1': ([direction(0, .3, .6), direction(0, .6, .3), direction(0, .45, .45)], [0, 0, 0], 1),
    # two classes, radial: M_1 line split 2, M_2 line split 2, plus M_3 line unsplit
    'mix123': ([direction(0, .4, .5), direction(1, .45, .4), direction(2, .5, .45)], [0, 1, 2], [2, 2, 1]),
    'cyc221': ([direction(0, .3, .6), direction(0, .6, .3), direction(0, .45, .45)], [0, 0, 0], [2, 2, 1]),
    'cyc1b': ([direction(0, .3, .6), direction(0, .6, .3), direction(0, .55, .55)], [0, 0, 0], 1),
    'cyc221b': ([direction(0, .3, .6), direction(0, .6, .3), direction(0, .55, .55)], [0, 0, 0], [2, 2, 1]),
}


def build(m, P2=True):
    N = m.N
    var = lambda w, r: int(1 + w * N + r)
    cl = []
    triv = m.idx[tuple([0] * m.n)]
    for w in range(3):
        for r in range(N):
            k = m.kind[w, r]
            if r == triv or k == 1:
                cl.append([var(w, r)])
            elif k == 2:
                cl.append([-var(w, r)])
    ncov = 0
    for r in range(N):
        if m.cohold[r]:
            cl.append([var(w, r) for w in range(3) if m.kind[w, r] != 2]); ncov += 1
    np1 = np2 = 0
    for i1, i2, i12 in m.pairs():
        if i12 == triv:
            continue
        for w in range(3):
            if m.kind[w, i1] != 3 or m.kind[w, i2] != 3:
                continue
            k12 = m.kind[w, i12]
            if k12 == 2:
                cl.append([-var(w, i1), -var(w, i2)]); np1 += 1
            elif k12 == 3 and P2:
                i3 = m.inv[i12]
                base = [-var(w, i1), -var(w, i2), -var(w, i3)]
                for j in (m.inv[i1], m.inv[i2], i12):
                    cl.append(base + [var(w, j)])
                np2 += 1
    return cl, var, ncov, np1, np2


def main(name):
    t0 = time.time()
    dirs, classes, R = CONFIGS[name]
    m = Model(dirs, classes, R)
    print(f'config {name}: pieces={m.n}, records={m.N}, coherent patterns={len(m.pats)}: {m.pats}')
    cl, var, ncov, np1, np2 = build(m)
    print(f'coverage clauses {ncov}, P1 pairs {np1}, P2 triangles {np2}, time {time.time()-t0:.1f}s')
    s = Cadical153(bootstrap_with=cl)
    sat = s.solve()
    print('base system (coverage + TC + strict G) SAT:', sat)
    if not sat:
        return
    # candidate dominations: coherent-old r, accepted at all worlds, inverse refused somewhere
    N = m.N
    cands = [r for r in range(N) if m.cohold[r] and all(m.kind[w, r] != 2 for w in range(3))
             and any(m.kind[w, r] == 3 for w in range(3))]
    ok, bad = [], []
    for r in cands:
        ir = int(m.inv[r])
        # assumption: r at all worlds; inverse refused at some world (needs a selector)
        sel = int(3 * N + 1 + r)
        s.add_clause([-sel] + [-var(w, ir) for w in range(3)])
        res = s.solve(assumptions=[var(w, r) for w in range(3)] + [sel])
        (ok if res else bad).append(r)
    print(f'candidate local dominations (coherent old, nowhere an improvement, mixed somewhere): {len(cands)}')
    print(f'  realisable singly: {len(ok)};  impossible: {len(bad)}')
    def show(r):
        return ' '.join('.' if c == 0 else 'ASB'[[(o, n) for o in range(3) for n in range(3) if o != n][c-1][0]] + '>' +
                        'ASB'[[(o, n) for o in range(3) for n in range(3) if o != n][c-1][1]] for c in m.records[r])
    for r in bad[:12]:
        print('   impossible:', show(r), ' inverse coherent-old:', bool(m.cohold[m.inv[r]]))
    for r in ok[:6]:
        print('   possible:  ', show(r), ' inverse coherent-old:', bool(m.cohold[m.inv[r]]))
    # how many at once?
    sels = []
    for r in ok:
        x = int(4 * N + 1 + r)
        s.add_clause([-x] + [var(w, r) for w in range(3)][:1]); s.add_clause([-x, var(1, r)]); s.add_clause([-x, var(2, r)])
        s.add_clause([-x] + [-var(w, m.inv[r]) for w in range(3)])
        sels.append(x)
    res = s.solve(assumptions=sels)
    print('  all realisable dominations simultaneously:', res)
    print(f'total time {time.time()-t0:.1f}s')


if __name__ == '__main__':
    main(sys.argv[1])
