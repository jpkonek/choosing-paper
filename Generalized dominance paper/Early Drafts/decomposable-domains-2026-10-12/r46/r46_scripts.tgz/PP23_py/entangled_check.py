"""PP23 Lemma 4.3 (P1-safety of entangled departures) on cells (CHECKED).
Entangled departure: old side S on the support; new side A or B; in every class it touches it
puts both A and B, and every line carrying B lies below-or-equal (e_k-triangle inclusion)
every line carrying A in that class.  Claim: for every world i, an entangled departure and
any record with coherent-realizable old side never compose, in either order, to a pure
improvement at i."""
import itertools
import numpy as np
from cellsat import Model, direction, PAIRS

def leq_line(m, d1, d2):
    """line d1 <= line d2 in class order (triangle at e_k of d1 inside that of d2)."""
    g1, g2 = m.dirs[d1], m.dirs[d2]
    k = m.classes[d1]
    z = lambda g: [(-g[k]) / (-g[k] + g[j]) for j in range(3) if j != k]
    return all(a <= b + 1e-12 for a, b in zip(z(g1), z(g2)))

def run(dirs, classes, R):
    m = Model(dirs, classes, R)
    recs = m.records
    def entangled(r):
        if not any(r): return False
        lines = {}
        for p, c in enumerate(r):
            if c:
                o, n = PAIRS[c - 1]
                if o != 1: return False
                d = m.pieces[p][0]
                lines.setdefault(m.classes[d], {0: set(), 2: set()})[n].add(d)
        for k, s in lines.items():
            if not s[0] or not s[2]: return False
            if not all(leq_line(m, b, a) for b in s[2] for a in s[0]): return False
        return True
    E = [i for i, r in enumerate(recs) if entangled(r)]
    Rr = [i for i in range(m.N) if m.cohold[i]]
    bad = 0; pairs = 0
    for e in E:
        for r in Rr:
            for (x, y) in ((e, r), (r, e)):
                out = []
                for c1, c2 in zip(recs[x], recs[y]):
                    c = m.compose_piece(c1, c2)
                    if c is None: out = None; break
                    out.append(c)
                if out is None or not any(out): continue
                pairs += 1
                k = m.idx[tuple(out)]
                for w in range(3):
                    if m.kind[w, e] != 2 and m.kind[w, r] != 2 and m.kind[w, k] == 2:
                        bad += 1
    print(f'pieces {m.n}: entangled departures {len(E)}, realizable-old records {len(Rr)}, '
          f'composable pairs {pairs}, pure-improvement composites at a world accepting d: {bad}')

if __name__ == '__main__':
    run([direction(0, .3, .3), direction(0, .6, .6), direction(1, .45, .4)], [0, 0, 1], [2, 2, 1])
    run([direction(0, .3, .3), direction(0, .6, .6), direction(1, .3, .35), direction(1, .7, .6)],
        [0, 0, 1, 1], 1)
