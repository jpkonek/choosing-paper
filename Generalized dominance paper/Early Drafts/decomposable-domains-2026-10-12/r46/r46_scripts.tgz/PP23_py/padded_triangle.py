"""PP23 Proposition 4.4: the padded triangle (CHECKED exactly).
Entangled departure d in class M_1 (S->B on a low line l1, S->A on a high line l2, l1 <= l2),
padding e = S->B on a line l_e in M_2.  At world 2 (majority for M_1, minority for M_2):
r2 = (l2: A->S) + e and r3 = (l1: B->S) + e^{-1} both have Z_2 > 0 and coherent-realizable
old sides, r2.r3 = d^{-1}, d is accepted (entangled departure), d^{-1} has a non-realizable
old side.  So the triangle P <= Q <= R <= P at world 2 lacks the reverse Q <= P."""
from fractions import Fraction as Fr
from cellsat import direction, coherent_patterns
A, S, B = 0, 1, 2
def rank(w, cls, v): return (2 - v) if w == cls else v
lines = {'l1': (0, direction(0, .2, .2)), 'l2': (0, direction(0, .6, .6)), 'le': (1, direction(1, .9, .9))}
names = list(lines)
pats = coherent_patterns([lines[k][1] for k in names])
def realizable(partial):
    return any(all(p[names.index(k)] == v for k, v in partial.items()) for p in pats)
m = {'l1': Fr(1), 'l2': Fr(3), 'le': Fr(1)}   # masses; m(l2) > m(l1); 2 m(le) = (m1+m2)/2
def Z(w, rec):
    tot = Fr(0)
    for k, (o, n) in rec.items():
        cls = lines[k][0]; wt = 2 if cls == w else 1
        tot += wt * m[k] * (rank(w, cls, n) - rank(w, cls, o))
    return tot
d = {'l1': (S, B), 'l2': (S, A)}
r2 = {'l2': (A, S), 'le': (S, B)}
r3 = {'l1': (B, S), 'le': (B, S)}
dinv = {'l1': (B, S), 'l2': (A, S)}
w = 1  # world 2 (0-based index 1)
print('Z_2(d) =', Z(w, d), '(d is non-improving at every world:', [Z(x, d) for x in range(3)], ')')
print('Z_2(r2) =', Z(w, r2), ' old side realizable:', realizable({k: o for k, (o, n) in r2.items()}))
print('Z_2(r3) =', Z(w, r3), ' old side realizable:', realizable({k: o for k, (o, n) in r3.items()}))
print('old side of d realizable:', realizable({k: o for k, (o, n) in d.items()}),
      '| old side of d^{-1} realizable:', realizable({k: o for k, (o, n) in dinv.items()}))
print('Z_2(d^{-1}) =', Z(w, dinv), ' (d^{-1} is mixed at world 2, so not guidance)')
