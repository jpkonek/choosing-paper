"""PP23 finite diagnostic: record-level SAT for local defence rules on radially split cells.

Model.  A finite set of mixed problem directions (lines in the simplex), each split into R
radial pieces.  Every piece is bounded (the conic remainder is fixed and never changed), so
every record is a bounded record.  Values are regular only: 0=A (majority answer),
1=S (silent), 2=B (minority answer).  Contradiction and unanimous problems are OMITTED
(sub-domain), so (TC) is checked on a sub-domain only.

A record is a tuple over pieces: 0 = not in support, else code 1..6 for (old,new), old!=new.
Coherent-old: the old values on the support agree with some coherent conic pattern D_K
(K interior, closed convex); pieces of one direction share the pattern's value.

Constraints, per world w (variables a[w][r] = record r accepted at w):
  * guidance: r weak worsening at w  -> a[w][r] true; r pure improvement at w -> false.
  * coverage: every coherent-old record accepted at some world.
  * P1: two accepted mixed records never compose to a pure improvement at w.
  * P2: an accepted triangle of mixed records has all three reverses accepted.
By PP20 Lemma 1.3 these are exactly (TC) with guidance on the (sub-)domain.
"""
import itertools, sys
import numpy as np
from scipy.optimize import linprog

PAIRS = [(o, n) for o in range(3) for n in range(3) if o != n]  # code 1..6
CODE = {p: i + 1 for i, p in enumerate(PAIRS)}


def rank(world, cls, v):
    """world-rank of value v (0=A,1=S,2=B) on a problem of class cls."""
    return (2 - v) if world == cls else v


def direction(cls, z1, z2):
    """mixed g in class cls; its line meets the two edges at e_cls at distances z1, z2
    (measured from e_cls, along the edges to the other two vertices in increasing order)."""
    others = [w for w in range(3) if w != cls]
    g = np.zeros(3)
    g[cls] = -1.0
    g[others[0]] = (1 - z1) / z1
    g[others[1]] = (1 - z2) / z2
    return g  # accept g (m.g>0) is correct at the two majority worlds: value A


def coherent_patterns(dirs, eps=1e-7):
    """all patterns p in {A,S,B}^len(dirs) realised by some interior closed convex K."""
    out = []
    d = len(dirs)
    for p in itertools.product(range(3), repeat=d):
        # P = {m in int simplex: m.g>0 for A, m.g<0 for B}; need P nonempty and P meets each S line
        A_ub, b_ub = [], []
        for v, g in zip(p, dirs):
            if v == 0:
                A_ub.append(-g); b_ub.append(-eps)
            elif v == 2:
                A_ub.append(g); b_ub.append(-eps)
        for j in range(3):
            row = np.zeros(3); row[j] = -1; A_ub.append(row); b_ub.append(-eps)
        ok = True
        S = [g for v, g in zip(p, dirs) if v == 1]
        targets = S if S else [None]
        for s in targets:
            A_eq = [np.ones(3)]; b_eq = [1.0]
            if s is not None:
                A_eq.append(s); b_eq.append(0.0)
            res = linprog(np.zeros(3), A_ub=np.array(A_ub), b_ub=np.array(b_ub),
                          A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=[(None, None)] * 3,
                          method='highs')
            if res.status != 0:
                ok = False; break
        if ok:
            out.append(p)
    return out


class Model:
    def __init__(self, dirs, classes, R):
        self.dirs, self.classes, self.R = dirs, classes, R
        Rs = R if isinstance(R, (list, tuple)) else [R] * len(dirs)
        self.pieces = [(d, h) for d in range(len(dirs)) for h in range(Rs[d])]
        self.n = len(self.pieces)
        self.pcls = [classes[d] for d, h in self.pieces]
        self.pats = coherent_patterns(dirs)
        self.records = list(itertools.product(range(7), repeat=self.n))
        self.idx = {r: i for i, r in enumerate(self.records)}
        self.N = len(self.records)
        # per-piece per-world sign of change for code c
        self.delta = np.zeros((3, self.n, 7), dtype=int)
        for w in range(3):
            for p in range(self.n):
                for c in range(1, 7):
                    o, nw = PAIRS[c - 1]
                    self.delta[w, p, c] = rank(w, self.pcls[p], nw) - rank(w, self.pcls[p], o)
        self.kind = np.zeros((3, self.N), dtype=int)  # 0 trivial, 1 W, 2 I, 3 M
        arr = np.array(self.records)
        for w in range(3):
            pos = np.zeros(self.N, bool); neg = np.zeros(self.N, bool)
            for p in range(self.n):
                dd = self.delta[w, p][arr[:, p]]
                pos |= dd > 0; neg |= dd < 0
            k = np.where(pos & neg, 3, np.where(pos, 1, np.where(neg, 2, 0)))
            self.kind[w] = k
        self.inv = np.zeros(self.N, dtype=int)
        invcode = [0] + [CODE[(n_, o)] for (o, n_) in PAIRS]
        for i, r in enumerate(self.records):
            self.inv[i] = self.idx[tuple(invcode[c] for c in r)]
        self.cohold = np.array([self.coherent_old(r) for r in self.records])

    def coherent_old(self, r):
        need = {}
        for p, c in enumerate(r):
            if c:
                d = self.pieces[p][0]; o = PAIRS[c - 1][0]
                if need.get(d, o) != o:
                    return False
                need[d] = o
        if not need:
            return False
        return any(all(pat[d] == v for d, v in need.items()) for pat in self.pats)

    def compose_piece(self, c1, c2):
        """composite code at a piece, or None if not composable."""
        if c1 == 0:
            return c2
        if c2 == 0:
            return c1
        o1, n1 = PAIRS[c1 - 1]; o2, n2 = PAIRS[c2 - 1]
        if n1 != o2:
            return None
        return 0 if o1 == n2 else CODE[(o1, n2)]

    def pairs(self):
        """yield (i1,i2,i12) for all composable pairs (all copies are record-level)."""
        opts = []
        for c1 in range(7):
            for c2 in range(7):
                c = self.compose_piece(c1, c2)
                if c is not None:
                    opts.append((c1, c2, c))
        for combo in itertools.product(opts, repeat=self.n):
            r1 = tuple(x[0] for x in combo); r2 = tuple(x[1] for x in combo)
            r12 = tuple(x[2] for x in combo)
            yield self.idx[r1], self.idx[r2], self.idx[r12]
