"""PP23 Section 2 on finite cells (CHECKED).
Rule D: world i accepts guidance at i, plus every departure (old side silent on the whole
support) that is not a pure improvement at i.  Full four-value domain (0=A,1=S,2=B,3=X) on
mixed pieces.  Checks (TC) through P1/P2 over all composable pairs (all copies are
record-level), the pump lemma (no accepted retreat with an i-gain is compatible), and the
point-4 domination and the room (mixed departures dominated)."""
import itertools, sys
VALS = range(4)
def rank(w, cls, v):
    if v == 3: return 3
    return (2 - v) if w == cls else v

def setup(classes):
    n = len(classes)
    codes = [None] + [(o, nw) for o in VALS for nw in VALS if o != nw]
    recs = list(itertools.product(range(len(codes)), repeat=n))
    idx = {r: i for i, r in enumerate(recs)}
    def delta(w, r):
        return [0 if c == 0 else rank(w, classes[p], codes[c][1]) - rank(w, classes[p], codes[c][0])
                for p, c in enumerate(r)]
    def kind(w, r):
        d = delta(w, r); pos = any(x > 0 for x in d); neg = any(x < 0 for x in d)
        return 'T' if not (pos or neg) else ('M' if pos and neg else ('W' if pos else 'I'))
    def compose(r1, r2):
        out = []
        for c1, c2 in zip(r1, r2):
            if c1 == 0: out.append(c2); continue
            if c2 == 0: out.append(c1); continue
            o1, n1 = codes[c1]; o2, n2 = codes[c2]
            if n1 != o2: return None
            out.append(0 if o1 == n2 else codes.index((o1, n2)))
        return tuple(out)
    def inv(r):
        return tuple(0 if c == 0 else codes.index((codes[c][1], codes[c][0])) for c in r)
    def departure(r):
        return any(r) and all(c == 0 or codes[c][0] == 1 for c in r)
    return codes, recs, idx, kind, compose, inv, departure

def check(classes):
    codes, recs, idx, kind, compose, inv, departure = setup(classes)
    acc = {w: {r for r in recs if kind(w, r) == 'W' or (departure(r) and kind(w, r) != 'I')}
           for w in range(3)}
    viol = 0
    for w in range(3):
        A = [r for r in acc[w] if kind(w, r) == 'M']
        Aset = set(A)
        for r1 in A:
            for r2 in A:
                c = compose(r1, r2)
                if c is None or not any(c): continue
                k = kind(w, c)
                if k == 'I': viol += 1
                elif k == 'M' and inv(c) in Aset:
                    if not (inv(r1) in acc[w] and inv(r2) in acc[w] and c in acc[w]): viol += 1
    print(f'classes {classes}: records {len(recs)}; (TC) violations under rule D: {viol}')
    return codes, recs, kind, acc, inv

if __name__ == '__main__':
    codes, recs, kind, acc, inv = check([0, 1, 2])
    # point 4: N = A on all three pieces; Z = silent there
    r = tuple(codes.index((0, 1)) for _ in range(3))
    print('  retreat N(A,A,A) -> Z(S,S,S) accepted at worlds:', [w + 1 for w in range(3) if r in acc[w]],
          '| reverse accepted at:', [w + 1 for w in range(3) if inv(r) in acc[w]], ' (N strictly dominated)')
    codes, recs, kind, acc, inv = check([0, 0, 1])
    # room: mixed departure S->A, S->B in class 1 (pieces 0,1), reverse refused
    r = (codes.index((1, 0)), codes.index((1, 2)), 0)
    print('  mixed departure (S>A, S>B in M_1) accepted at worlds:', [w + 1 for w in range(3) if r in acc[w]],
          '| reverse accepted at:', [w + 1 for w in range(3) if inv(r) in acc[w]], ' (room: strict domination)')
