"""Which type-sets R of a regular mixed record admit a pump split O (PP23 Lemma 4.2)?
Types: P_k = minority-ward change in class k (losses at the two majority worlds),
       Q_k = majority-ward change in class k (loss at world k only).
A split O (nonempty, proper) is a pump split if for every world i:
   O consists of i-losses only, or O contains every i-loss of the record.
O is described per type: 0 = no points, 1 = some but not all, 2 = all points of the type."""
import itertools
TYPES = [('P', k) for k in range(3)] + [('Q', k) for k in range(3)]
def loss(t, i):
    kind, k = t
    return (i != k) if kind == 'P' else (i == k)
def name(t): return f'{t[0]}{t[1]+1}'
res = {}
for mask in range(1, 64):
    R = [TYPES[j] for j in range(6) if mask >> j & 1]
    if not all(any(loss(t, i) for t in R) for i in range(3)):
        continue  # a pure improvement somewhere: cannot be accepted at every world
    splits = []
    for opt in itertools.product(range(3), repeat=len(R)):
        if all(o == 0 for o in opt) or all(o == 2 for o in opt):
            continue
        ok = True
        for i in range(3):
            inside = [t for t, o in zip(R, opt) if o > 0]
            c1 = all(loss(t, i) for t in inside)
            c2 = all(o == 2 for t, o in zip(R, opt) if loss(t, i))
            if not (c1 or c2):
                ok = False; break
        if ok:
            splits.append(opt)
    res[tuple(name(t) for t in R)] = splits
esc = [R for R, s in res.items() if not s]
print('type-sets with a loss at every world:', len(res))
print('escape every pump split (no valid O):', len(esc))
for R in esc: print('   ', R)
print('have a pump split:', len(res) - len(esc))
for R, s in list(res.items())[:60]:
    if s:
        o = s[0]
        print('   ', R, ' e.g. O =', {r: ['none', 'part', 'all'][x] for r, x in zip(R, o)})
