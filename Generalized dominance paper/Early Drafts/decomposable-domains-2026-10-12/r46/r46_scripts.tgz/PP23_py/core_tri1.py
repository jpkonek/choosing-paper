"""Extract a minimal set of record-level facts behind an impossible local domination in tri1."""
import sys
from pysat.solvers import Cadical153
from pysat.examples.musx import MUSX
from pysat.formula import WCNF
from cellsat import Model, direction, PAIRS
from satrun import CONFIGS, build
name = sys.argv[1] if len(sys.argv) > 1 else 'tri1'
target = sys.argv[2] if len(sys.argv) > 2 else 'A>S A>S S>A'
dirs, classes, R = CONFIGS[name]
m = Model(dirs, classes, R)
cl, var, *_ = build(m)
def parse(s):
    out = []
    for t in s.split():
        if t == '.': out.append(0)
        else: out.append(PAIRS.index(('ASB'.index(t[0]), 'ASB'.index(t[2]))) + 1)
    return m.idx[tuple(out)]
def show(r):
    return ' '.join('.' if c == 0 else 'ASB'[PAIRS[c-1][0]] + '>' + 'ASB'[PAIRS[c-1][1]] for c in m.records[r])
r = parse(target); N = m.N
hard = [[var(w, r)] for w in range(3)] + [[-var(w, int(m.inv[r])) for w in range(3)]]
w = WCNF()
for c in hard: w.append(c)
for c in cl: w.append(c, weight=1)
mus = MUSX(w, verbosity=0).compute()
print('target', target, '| core size', len(mus))
def lit(l):
    v = abs(l) - 1; wd, rr = divmod(v, N)
    return ('' if l > 0 else 'not ') + f'acc_{wd+1}[{show(rr)}]'
for i in mus:
    c = cl[i - 1]
    print('  ', ' OR '.join(lit(l) for l in c))
