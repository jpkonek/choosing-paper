"""PP23 Section 5 diagnostic (CHECKED on cells): can a SUBSET of the zero-sum rule Z cover all
coherent-old records while every entangled departure is accepted at every world (room)?
Variables a_w(r).  Forced: guidance true; records with Z_w(r) <_lex 0 false, except entangled
departures, which are forced true at every world.  Constraints: coverage of coherent-old
records; (TC) via P1/P2 over all composable pairs.
Usage: python3 -B sat_zsubset.py <config> <seed>"""
import sys, time, random
import numpy as np
from fractions import Fraction as Fr
from pysat.solvers import Cadical153
from cellsat import Model, direction, PAIRS, rank
from entangled_check import leq_line

CONF = {
    'nest2': ([direction(0, .2, .2), direction(0, .6, .6), direction(1, .9, .9)], [0, 0, 1], [2, 2, 1]),
    'nest3': ([direction(0, .2, .2), direction(0, .6, .6), direction(1, .9, .9), direction(2, .5, .5)],
              [0, 0, 1, 2], [2, 1, 1, 1]),
    'propD': ([direction(0, .2, .2), direction(0, .6, .6), direction(0, .1, .9)], [0, 0, 0], 1),
    'propD2': ([direction(0, .2, .2), direction(0, .6, .6), direction(0, .1, .9), direction(1, .5, .5)], [0, 0, 0, 1], 1),
    'nest1': ([direction(0, .2, .2), direction(0, .6, .6), direction(1, .9, .9), direction(2, .5, .5)],
              [0, 0, 1, 2], 1),
}

def main(name, seed):
    t0 = time.time()
    dirs, classes, R = CONF[name]
    m = Model(dirs, classes, R)
    rnd = random.Random(seed)
    mass = [Fr(rnd.randint(1, 6)) for _ in range(m.n)]
    if name.startswith('propD') and seed < 0:
        mass = [Fr(3), Fr(1), Fr(2)] + [Fr(1)] * (m.n - 3)   # m_B=3 on low l1, m_A=1 on high l2, padding 2
    N = m.N
    # Z vectors: level 0 then piece-by-piece (a separating family on cells)
    def Zvec(w, r):
        per = []
        for p, c in enumerate(r):
            if c == 0: per.append(Fr(0)); continue
            o, nw = PAIRS[c - 1]; cls = m.pcls[p]
            wt = 2 if cls == w else 1
            per.append(wt * mass[p] * (rank(w, cls, nw) - rank(w, cls, o)))
        return (sum(per),) + tuple(per)
    zok = np.zeros((3, N), bool)
    for w in range(3):
        for i, r in enumerate(m.records):
            zok[w, i] = Zvec(w, r) >= tuple([Fr(0)] * (m.n + 1))
    def entangled(r):
        if not any(r): return False
        lines = {}
        for p, c in enumerate(r):
            if c:
                o, n = PAIRS[c - 1]
                if o != 1: return False
                d = m.pieces[p][0]
                lines.setdefault(m.classes[d], {0: set(), 2: set()})[n].add(d)
        for k, s in lines.items():
            if not s[0] or not s[2]: return False
            if not all(leq_line(m, b, a) for b in s[2] for a in s[0]): return False
        return True
    ent = np.array([entangled(r) for r in m.records])
    var = lambda w, r: int(1 + w * N + r)
    s = Cadical153()
    class L:
        def append(self, c): s.add_clause(c)
    cl = L()
    triv = m.idx[tuple([0] * m.n)]
    for w in range(3):
        for r in range(N):
            k = m.kind[w, r]
            if r == triv or k == 1: cl.append([var(w, r)])
            elif k == 2: cl.append([-var(w, r)])
            elif ent[r]: pass  # forced true through assumptions below
            elif not zok[w, r]: cl.append([-var(w, r)])
    for r in range(N):
        if m.cohold[r]:
            cl.append([var(w, r) for w in range(3) if m.kind[w, r] != 2])
    np1 = np2 = 0
    for i1, i2, i12 in m.pairs():
        if i12 == triv: continue
        for w in range(3):
            if m.kind[w, i1] != 3 or m.kind[w, i2] != 3: continue
            k12 = m.kind[w, i12]
            if k12 == 2:
                cl.append([-var(w, i1), -var(w, i2)]); np1 += 1
            elif k12 == 3:
                i3 = int(m.inv[i12])
                base = [-var(w, i1), -var(w, i2), -var(w, i3)]
                for j in (int(m.inv[i1]), int(m.inv[i2]), i12):
                    cl.append(base + [var(w, j)])
                np2 += 1
    allent = [var(w, int(x)) for x in np.nonzero(ent)[0] for w in range(3) if m.kind[w, x] == 3]
    res = s.solve(assumptions=allent)
    print(f'{name} seed {seed}: pieces {m.n}, records {N}, entangled departures {int(ent.sum())}, '
          f'P1 {np1}, P2 {np2}: Z-subset cover with all entangled departures accepted everywhere: '
          f'{"SAT" if res else "UNSAT"}  ({time.time()-t0:.0f}s)')
    if not res:
        # how many entangled departures can be kept? drop forcing, maximise greedily
        pass  # cl2 = [c for c in cl if not (len(c) == 1 and c[0] > 0 and ent[(c[0] - 1) % N] and m.kind[(c[0]-1)//N, (c[0]-1) % N] == 3)]
        s2 = s
        keep = []
        for r in np.nonzero(ent)[0]:
            r = int(r)
            ass = [var(w, x) for x in keep + [r] for w in range(3) if m.kind[w, x] == 3]
            if s2.solve(assumptions=ass): keep.append(r)
            else: print('     cannot be added:', ' '.join('.' if c == 0 else 'ASB'[PAIRS[c-1][0]] + '>' + 'ASB'[PAIRS[c-1][1]] for c in m.records[r]))
        print(f'   greedy: entangled departures that can be accepted at every world together: {len(keep)} of {int(ent.sum())}')

if __name__ == '__main__':
    main(sys.argv[1], int(sys.argv[2]))
