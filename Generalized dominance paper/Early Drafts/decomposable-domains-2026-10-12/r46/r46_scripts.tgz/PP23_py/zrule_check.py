"""PP23 Theorem 3.1 / Prop 3.2 on finite cells (CHECKED, exact rational arithmetic).

Zero-sum lexicographic rule Z: world i compares models X, Y by the vector
   F_i(X) = ( sum_p w_i(p) m(p) r_i(p, X) ,  then  w_i(p) m(p) r_i(p, X) piece by piece )
lexicographically, with w_i = 2 on the class where i is the minority world and 1 elsewhere
(1 on unanimous pieces).  Values: 0=A 1=S 2=B 3=X(contradiction) on mixed pieces;
on unanimous pieces 0=correct 1=S 2=wrong 3=X.
Checks, for random positive masses on a cell set with mixed pieces of every class and one
unanimous piece:
  (a) each world is a linear order (antisymmetric, total) -- no ties;
  (b) strict (G);
  (c) every regular model (A/S/B on mixed, correct on unanimous) is competitive against
      every model of the full four-value domain;
  (d) no regular model is no worse than a different regular model at all three worlds.
"""
import itertools, random
from fractions import Fraction as Fr

def rank(w, cls, v):
    if cls == 'U':
        return v
    if v == 3:
        return 3
    return (2 - v) if w == cls else v

def run(classes, seed):
    rnd = random.Random(seed)
    n = len(classes)
    m = [Fr(rnd.randint(1, 9), rnd.randint(1, 9)) for _ in range(n)]
    wt = lambda i, p: 2 if classes[p] == i else 1
    models = list(itertools.product(range(4), repeat=n))
    def F(i, X):
        per = [wt(i, p) * m[p] * rank(i, classes[p], X[p]) for p in range(n)]
        return (sum(per),) + tuple(per)
    Fs = [{X: F(i, X) for X in models} for i in range(3)]
    leq = lambda i, X, Y: Fs[i][Y] >= Fs[i][X]   # X no worse than Y at i (lex on tuples)
    # (a) linear order: F_i injective
    for i in range(3):
        assert len(set(Fs[i].values())) == len(models), 'tie at a world'
    # (b) strict G
    for X in models:
        for Y in models:
            for i in range(3):
                d = [rank(i, classes[p], Y[p]) - rank(i, classes[p], X[p]) for p in range(n)]
                if all(x >= 0 for x in d):
                    assert leq(i, X, Y)
                if all(x <= 0 for x in d) and any(x < 0 for x in d):
                    assert not leq(i, X, Y)
    regular = [X for X in models if all((X[p] in (0, 1, 2)) if classes[p] != 'U' else X[p] == 0
                                        for p in range(n))]
    # (c) competitiveness of every regular model against every model
    for N in regular:
        for X in models:
            assert any(leq(i, N, X) for i in range(3)), (N, X)
    # (d) no regular all-world weak domination
    cnt = 0
    for N in regular:
        for X in regular:
            if X != N and all(leq(i, N, X) for i in range(3)):
                cnt += 1
    assert cnt == 0
    return len(models), len(regular)

if __name__ == '__main__':
    tot = 0
    for classes in ([0, 1, 2, 'U'], [0, 0, 1, 2, 'U'], [0, 1, 1, 2, 2]):
        for seed in range(6):
            nm, nr = run(classes, seed)
            tot += 1
        print(f'classes {classes}: {nm} models, {nr} regular; 6 random mass draws: ALL PASS')
    print('Z rule: linear orders, strict G, regular models competitive against all models, '
          'no regular all-world domination -- CHECKED on', tot, 'instances')
