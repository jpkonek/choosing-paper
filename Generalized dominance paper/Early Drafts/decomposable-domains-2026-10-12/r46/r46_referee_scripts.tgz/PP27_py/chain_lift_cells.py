"""Independent finite-cell check of PP26 Theorem C (the chain lift Lambda). Diagnostic only.

Cells: one U direction plus n directions in each mixed region M_k (one radial piece each),
random masses. Chain C_t = D_{(1-t)M + t e1}, M = c1 + eps*Delta, eps = 3/10.
Keys: per (region, side, level), switching time theta along the chain (theta for steps that
leave as t grows, -theta for steps that enter); never-switching steps 2+tau (always in) or
-1-tau (never in); level-3 steps -2-tau. Rule at world w: first nontrivial region in the order
(U, M1, M2, M3); accept iff pure worsening for w's side there, or strong gate
(max key added <= min key removed, added non-empty) and Phi = 2 m(added) - m(removed) >= 0.
Checks: competitiveness and undominatedness of chain members against ALL models of the cell
domain; strict (G); 2- and 3-cycles on a pool.
Run: python3 -B chain_lift_cells.py
"""
import itertools
import sys
import numpy as np

SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 11
rng = np.random.default_rng(SEED)
eps, c = 0.3, 0.7 / 3
Mv = np.array([[c + (eps if i == k else 0) for i in range(3)] for k in range(3)])
NPER = int(sys.argv[2]) if len(sys.argv) > 2 else 2

cells = []  # (g, region) region 0 = U, k = 1..3 for M_k
g = np.abs(rng.standard_normal(3)); cells.append((g, 0))
for k in (1, 2, 3):
    n = 0
    while n < NPER:
        g = np.abs(rng.standard_normal(3)); g[k - 1] *= -1
        cells.append((g, k)); n += 1
NC = len(cells)
mass = rng.uniform(0.5, 1.5, NC)


def advice_at(g, t):
    vals = (1 - t) * (Mv @ g) + t * g[0]
    lo, hi = vals.min(), vals.max()
    return 1 if lo > 0 else (-1 if hi < 0 else 0)  # 1 accept g, -1 reject g, 0 silent


def code(g, region, adv):
    """majority-rank code on M_k (A0 S1 B2), or rank on U (correct0 S1 wrong2)."""
    if adv == 0:
        return 1
    if region == 0:
        return 0 if adv == 1 else 2  # g in the positive orthant here: accepting is correct
    good_min = 1 if g[region - 1] > 0 else -1
    return 2 if adv == good_min else 0


def side_rank(cd, region, side):
    if cd == 3:
        return 3
    if region == 0 or side == 'maj':
        return cd
    return 2 - cd


def candidates(g):
    vg = Mv @ g
    ts = [0.0, 1.0]
    for v in vg:
        if v != g[0]:
            t = v / (v - g[0])
            if 0 < t < 1:
                ts.append(t)
    return sorted(set(ts))


def chain_code(i, t):
    g, r = cells[i]
    return code(g, r, advice_at(g, t))


# switching structure and keys
keys = {}
tau = rng.uniform(0, 0.01, (NC, 2, 4))
for i, (g, r) in enumerate(cells):
    ts = candidates(g)
    mids = [0.0] + [(a + b) / 2 for a, b in zip(ts, ts[1:])] + [1.0]
    for si, side in enumerate(('maj', 'min')):
        if r == 0 and side == 'min':
            continue
        for j in (1, 2, 3):
            if j == 3:
                keys[(i, side, j)] = -2 - tau[i, si, j]; continue
            mem = [side_rank(chain_code(i, t), r, side) >= j for t in mids]
            if all(mem):
                keys[(i, side, j)] = 2 + tau[i, si, j]
            elif not any(mem):
                keys[(i, side, j)] = -1 - tau[i, si, j]
            else:
                # monotone: find switching candidate time
                flips = [k for k in range(len(mem) - 1) if mem[k] != mem[k + 1]]
                assert len(flips) == 1, 'non-monotone membership'
                th = ts[flips[0]] if flips[0] < len(ts) else 1.0
                th = ts[min(flips[0], len(ts) - 1)]
                keys[(i, side, j)] = th if mem[0] else -th


def side_of(w, region):
    if region == 0:
        return 'maj'
    return 'min' if w == region else 'maj'


def accepts(w, X, Y):
    if X == Y:
        return True
    for region in (0, 1, 2, 3):
        idx = [i for i in range(NC) if cells[i][1] == region and X[i] != Y[i]]
        if idx:
            break
    side = side_of(w, region)
    add, rem = [], []
    for i in idx:
        a, b = side_rank(X[i], region, side), side_rank(Y[i], region, side)
        if b > a:
            add += [(i, j) for j in range(a + 1, b + 1)]
        else:
            rem += [(i, j) for j in range(b + 1, a + 1)]
    if not rem:
        return True  # pure worsening (add non-empty since X != Y on region)
    if not add:
        return False
    if max(keys[(i, side, j)] for i, j in add) > min(keys[(i, side, j)] for i, j in rem):
        return False
    phi = 2 * sum(mass[i] for i, _ in add) - sum(mass[i] for i, _ in rem)
    return phi >= 0


models = list(itertools.product(range(4), repeat=NC))
print('seed', SEED, 'cells:', NC, ' models:', len(models))
allsw = sorted({abs(v) for v in keys.values() if 0 < abs(v) < 1})
grid = [0.0] + [(a + b) / 2 for a, b in zip([0.0] + allsw, allsw + [1.0])]
members = sorted({tuple(chain_code(i, t) for i in range(NC)) for t in grid})
print('distinct chain members on cells:', len(members))
fail_comp = fail_dom = 0
for N in members:
    for Y in models:
        if Y == N:
            continue
        if not any(accepts(w, N, Y) for w in (1, 2, 3)):
            fail_comp += 1
        if all(accepts(w, Y, N) for w in (1, 2, 3)):
            fail_dom += 1
print('competitiveness failures:', fail_comp, ' models weakly dominating a member:', fail_dom)

# strict (G) and cycles on a pool
pool = list(members)
pool += [models[k] for k in rng.choice(len(models), 300, replace=False)]
for N in members:
    for _ in range(25):
        Y = list(N); i = rng.integers(NC); Y[i] = int(rng.integers(4)); pool.append(tuple(Y))
pool = sorted(set(pool))
P = len(pool)
sg_viol = 0
cyc2 = cyc3 = 0
for w in (1, 2, 3):
    A = np.zeros((P, P), dtype=np.int64)
    for a, X in enumerate(pool):
        for b, Y in enumerate(pool):
            if a != b and accepts(w, X, Y):
                A[a, b] = 1
    # strict (G): Y strict improvement of X at w must be refused
    for a, X in enumerate(pool):
        for b, Y in enumerate(pool):
            if a == b:
                continue
            rx = [side_rank(X[i], cells[i][1], side_of(w, cells[i][1])) for i in range(NC)]
            ry = [side_rank(Y[i], cells[i][1], side_of(w, cells[i][1])) for i in range(NC)]
            if all(q <= p for p, q in zip(rx, ry)) and A[a, b]:
                sg_viol += 1
            if all(q >= p for p, q in zip(rx, ry)) and not A[a, b]:
                sg_viol += 1
    cyc2 += int(np.trace(A @ A))
    cyc3 += int(np.trace(A @ A @ A))
print('pool size:', P, ' strict/weak (G) violations:', sg_viol, ' 2-cycle count:', cyc2, ' 3-cycle count:', cyc3)

# control: a homothety toward e2 (tripod leg) is not competitive under the chain keys
def leg_code(i, t):
    g, r = cells[i]
    vals = (1 - t) * (Mv @ g) + t * g[1]
    lo, hi = vals.min(), vals.max()
    return code(g, r, 1 if lo > 0 else (-1 if hi < 0 else 0))


uncovered = 0
legs = sorted({tuple(leg_code(i, t) for i in range(NC)) for t in (0.3, 0.6, 0.9)} - set(members))
for N in legs:
    uncovered += sum(1 for Y in models if Y != N and not any(accepts(w, N, Y) for w in (1, 2, 3)))
print('control: e2-leg models not in chain:', len(legs), ' rivals refused at every world:', uncovered)
