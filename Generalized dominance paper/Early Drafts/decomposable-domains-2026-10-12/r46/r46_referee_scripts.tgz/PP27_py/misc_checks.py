"""Small referee checks.

(1) PP25 Theorem A item 3 needs the family {B_n} to be a pi-system (rational boxes are one):
    a generating family alone does not make a signed measure vanish. Finite example.
(2) PP26 Theorem R (i)-(ii): Collatz-Wielandt covering test for random weightings
    (NUMERICS): with S >= I, both rivals covered iff S = I and rho(B) = 1.
Run: python3 -B misc_checks.py
"""
import itertools
import numpy as np

print('(1) generating family that is not a pi-system')
pts = [1, 2, 3, 4]
fam = [{1, 2}, {2, 3}, {3, 4}, {4, 1}]
nu = {1: 1, 2: -1, 3: 1, 4: -1}
# sigma-algebra generated contains the singletons (e.g. {1,2} & {4,1} = {1})
gen = set(map(frozenset, fam))
changed = True
while changed:
    changed = False
    for a, b in itertools.product(list(gen), repeat=2):
        for s in (a & b, a | b, frozenset(pts) - a):
            if s not in gen:
                gen.add(s); changed = True
print('  generated algebra has all singletons:', all(frozenset([p]) in gen for p in pts))
print('  nu on family:', [sum(nu[p] for p in s) for s in fam], ' nu(total):', sum(nu.values()),
      ' nu != 0:', any(nu.values()))

print('(2) Theorem R covering test (random weightings)')
rng = np.random.default_rng(2)


def rho(A):
    return max(abs(np.linalg.eigvals(A)))


ok = 0; trials = 3000
for _ in range(trials):
    B = rng.uniform(0.1, 2, (3, 3)); np.fill_diagonal(B, 0)
    B /= rho(B)                       # rho(B) = 1
    S = np.diag(1 + rng.uniform(0, 0.5, 3) * (rng.random(3) < 0.5))
    covA = rho(S @ B) <= 1 + 1e-12    # A-ward rival covered for every mass vector
    covB = rho(np.linalg.inv(S) @ B) >= 1 - 1e-12
    if (covA and covB) == np.allclose(S, np.eye(3)):
        ok += 1
print('  trials where "both covered" == "S = I" (given rho(B) = 1):', ok, 'of', trials)
