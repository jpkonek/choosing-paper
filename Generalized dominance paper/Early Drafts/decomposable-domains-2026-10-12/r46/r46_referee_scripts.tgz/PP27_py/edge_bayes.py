"""Referee check for the 'no continuity' question on PP23 Prop 3.3 / PP25 Theorem A caveat.

FF2 Thm 4.1 Step 1 (Lyapunov + separation; no continuity used) gives: if C_q is competitive
on supp q and every accepted annulus-supported comparison out of C_q at worlds in supp q has
Omega^(0) >= 0, then C_q is a pointwise weak w-Bayes model of the balanced field
l_i = rho_i * r_i for some w in Delta_{supp q}.

Part 1 (exact rationals): for every w on the closed edge [e1,e2], list the Bayes-optimal
advice on M_1, M_2, M_3 and U. Coherence then forces C_q in {V_1, V_2} (PP26 Lemma 0).
Part 2: X := D_[e1,e2] is (S on M_1, S on M_2, A on M_3), coherent; X is a strict world-2
improvement of V_1 and a strict world-1 improvement of V_2, so 1-D KKM on the edge
(closed sections A_1(X), A_2(X)) yields a contradiction with strict (G).
Run: python3 -B edge_bayes.py
"""
from fractions import Fraction as F
import random

ADV = ['A', 'S', 'B', 'X']  # X = contradiction


def ranks(region, adv):
    """world ranks (r1, r2, r3) on M_region (minority world = region), or on U ('U')."""
    if adv == 'X':
        return (3, 3, 3)
    if region == 'U':
        return {'A': (0, 0, 0), 'S': (1, 1, 1), 'B': (2, 2, 2)}[adv]  # A=correct,B=wrong on U
    maj = {'A': 0, 'S': 1, 'B': 2}[adv]
    return tuple(2 - maj if w == region else maj for w in (1, 2, 3))


def rho(region, w):
    return 2 if region == w else 1


def bayes(wt, region):
    vals = {}
    for a in ADV:
        r = ranks(region, a)
        vals[a] = sum(wt[k] * rho(region, k + 1) * r[k] for k in range(3))
    m = min(vals.values())
    return sorted(a for a in ADV if vals[a] == m)


def coherent_completion(opt):
    """Which coherent models are pointwise-optimal? Use Lemma 0: B a.e. on M_a => V_a;
    A a.e. on two regions M_a, M_b => V_c."""
    out = set()
    for v in (1, 2, 3):  # V_v: B on M_v, A elsewhere, correct on U
        if 'B' in opt[v] and all('A' in opt[r] for r in (1, 2, 3) if r != v) and 'A' in opt['U']:
            out.add('V%d' % v)
    forced = {r: opt[r] for r in (1, 2, 3)}
    # any non-vertex coherent model needs non-B somewhere on each region and cannot be
    # A-only on two regions; report whether forced singletons exclude every non-vertex model
    singles = {r: forced[r][0] for r in forced if len(forced[r]) == 1}
    excl = any(v == 'B' for v in singles.values()) or sum(v == 'A' for v in singles.values()) >= 2
    return out, excl


print('Part 1: Bayes-optimal advice for w on the edge [e1,e2] (exact)')
grid = sorted({F(n, 60) for n in range(61)} | {F(1, 3), F(2, 3)})
all_ok = True
for t in grid:
    wt = (1 - t, t, F(0))
    opt = {r: bayes(wt, r) for r in (1, 2, 3, 'U')}
    vert, excl = coherent_completion(opt)
    ok = excl and vert <= {'V1', 'V2'}
    all_ok &= ok
    if t in (0, F(1, 3), F(1, 2), F(2, 3), 1):
        print('  w=(%s,%s,0): M1 %s  M2 %s  M3 %s  U %s  -> coherent optima %s' %
              (wt[0], wt[1], opt[1], opt[2], opt[3], opt['U'], sorted(vert)))
print('  at every grid weight the coherent Bayes models are among {V1, V2} (possibly none):', all_ok)


# Part 2: profile of D_K for K = [e1,e2] on random lines, and strict improvements
def DK_segment(g):
    vals = [g[0], g[1]]  # m.g at e1, e2
    lo, hi = min(vals), max(vals)
    return 'acc' if lo > 0 else ('rej' if hi < 0 else 'S')


def region_of(g):
    pos = [x > 0 for x in g]
    if all(pos) or not any(pos):
        return 'U'
    odd = [k for k in range(3) if pos[k] == (sum(pos) == 1)]
    return odd[0] + 1


def advice_name(g, adv):
    reg = region_of(g)
    if reg == 'U' or adv == 'S':
        return reg, adv
    # accept g is good for world w iff g_w > 0; minority world = reg
    good_for_minority = 'acc' if g[reg - 1] > 0 else 'rej'
    return reg, ('B' if adv == good_for_minority else 'A')


random.seed(1)
prof = {1: set(), 2: set(), 3: set()}
for _ in range(20000):
    g = [random.gauss(0, 1) for _ in range(3)]
    reg, nm = advice_name(g, DK_segment(g))
    if reg != 'U':
        prof[reg].add(nm)
print('Part 2: D_[e1,e2] advice by region on 20000 random lines:', {k: sorted(v) for k, v in prof.items()})
V1 = {1: 'B', 2: 'A', 3: 'A'}
V2 = {1: 'A', 2: 'B', 3: 'A'}
X = {1: 'S', 2: 'S', 3: 'A'}


def better_or_equal(world, new, old):
    """new weakly better than old at world on every region, strictly on some."""
    strict = False
    for r in (1, 2, 3):
        a, b = ranks(r, new[r])[world - 1], ranks(r, old[r])[world - 1]
        if a > b:
            return False
        strict |= a < b
    return strict


print('  X strict world-2 improvement of V1:', better_or_equal(2, X, V1))
print('  X strict world-1 improvement of V2:', better_or_equal(1, X, V2))
