"""Referee geometry checks (independent of the authors' libraries).

(1) PP26 Prop 1.3(a),(c): exact rational evaluation of the pencil formula examples.
(2) PP26 Prop 1.4 (median rule): random precise pairs, exact rationals on random lines.
(3) PP24 Lemma 3.1: single-region coarsenings C_k(delta) of T1 change T only by silence on
    M_k where T = B, for delta <= delta*; failure above delta* (Monte Carlo, NUMERICS).
(4) PP23 Props 4.6/4.7 hidden hypothesis: B-lines hugging the e_k corner are not
    realisable by any K inside int(Delta) (exact bound).
Run: python3 -B geometry_checks.py
"""
from fractions import Fraction as F
import random
import numpy as np


def DK(verts, g):
    vals = [sum(m[i] * g[i] for i in range(3)) for m in verts]
    lo, hi = min(vals), max(vals)
    return 'acc' if lo > 0 else ('rej' if hi < 0 else 'S')


def name(g, adv):
    pos = [x > 0 for x in g]
    if all(pos) or not any(pos):
        return 'U', adv
    reg = [k for k in range(3) if pos[k] == (sum(pos) == 1)][0] + 1
    if adv == 'S':
        return reg, 'S'
    good_min = 'acc' if g[reg - 1] > 0 else 'rej'
    return reg, 'B' if adv == good_min else 'A'


print('(1) PP26 Prop 1.3 examples')
K = [(F(1, 3),) * 3, (F(1, 5), F(2, 5), F(2, 5))]
Kp = [(F(1, 4), F(1, 4), F(2, 4)), (F(1, 4), F(2, 4), F(1, 4))]
g = (F(-7, 2), F(1), F(1))
print('  line (-7/2,1,1): D_K =', name(g, DK(K, g)), ' D_K\' =', name(g, DK(Kp, g)))
for S in (K, Kp):
    print('   ratio ranges m2/m1, m3/m1:', sorted({m[1] / m[0] for m in S}), sorted({m[2] / m[0] for m in S}))
eps = F(3, 10); c = (1 - eps) / 3
M = [tuple(c + (eps if i == k else 0) for i in range(3)) for k in range(3)]
box = [M[0], (F(1), F(16, 7), F(16, 7))]  # lo = v1 ratios, hi* = (16/7,16/7) (unnormalised ok)
g = (F(-776, 175), F(1), F(1))
print('  line (-776/175,1,1): T1 =', name(g, DK(M, g)), ' box model =', name(g, DK(box, g)))

print('(2) PP26 Prop 1.4 median rule (exact on random lines)')
random.seed(3)
bad = 0; pairs = 0; both_seen = 0; crossed_pred = 0; nested_viol = 0
for _ in range(300):
    p = [F(random.randint(1, 50)) for _ in range(3)]; q = [F(random.randint(1, 50)) for _ in range(3)]
    sp, sq = sum(p), sum(q); p = [x / sp for x in p]; q = [x / sq for x in q]
    if p == q:
        continue
    pairs += 1
    lr = [float(np.log(float(q[r])) - np.log(float(p[r]))) for r in range(3)]
    med = sorted(range(3), key=lambda r: lr[r])[1]
    for k in range(3):
        # nested on M_k iff ratio p_j/p_k - q_j/q_k have equal (weak) sign for both j != k
        js = [j for j in range(3) if j != k]
        d = [p[j] / p[k] - q[j] / q[k] for j in js]
        nested = (d[0] >= 0 and d[1] >= 0) or (d[0] <= 0 and d[1] <= 0)
        pred_crossed = (k == med) and len(set(lr)) == 3
        # sample lines to confirm crossing when predicted
        seen = set()
        for _ in range(400):
            gg = [F(random.randint(1, 99), random.randint(1, 99)) for _ in range(3)]
            gg[k] = -gg[k]
            a = name(gg, DK([p], gg))[1]; b = name(gg, DK([q], gg))[1]
            if a != b:
                seen.add((a, b))
        if nested == pred_crossed:
            bad += 1
        if pred_crossed:
            crossed_pred += 1
            both_seen += {('A', 'B'), ('B', 'A')} <= seen
        elif {('A', 'B'), ('B', 'A')} <= seen:
            nested_viol += 1
print('  pairs:', pairs, ' mismatches between ratio test and median prediction:', bad)
print('  predicted crossed regions:', crossed_pred, ' both crossing directions sampled in', both_seen,
      '; predicted nested but both directions sampled:', nested_viol)

print('(3) PP24 Lemma 3.1 (Monte Carlo)')
dstar = c * eps / (3 * c + 2 * eps)
print('  delta* =', dstar)
rng = np.random.default_rng(5)
G = rng.standard_normal((2_000_000, 3))
Mf = np.array([[float(x) for x in m] for m in M])
cf, ef = float(c), float(eps)
for fac in (F(1), F(1, 2), F(11, 10), F(3, 2)):
    d = float(dstar * fac)
    for k in range(3):
        i, j = [x for x in range(3) if x != k]
        q = (Mf[i] + Mf[j]) / 2 + d * ((np.eye(3)[i] + np.eye(3)[j]) / 2 - np.eye(3)[k])
        vT = G @ Mf.T; vq = G @ q
        loT, hiT = vT.min(1), vT.max(1)
        lo, hi = np.minimum(loT, vq), np.maximum(hiT, vq)
        T = np.where(loT > 0, 1, np.where(hiT < 0, -1, 0))
        C = np.where(lo > 0, 1, np.where(hi < 0, -1, 0))
        diff = T != C
        # allowed: g in M_k with only coordinate k of the sign accepted by T positive
        s = np.sign(G) * T[:, None]  # orient so that T's answer is 'accept'
        allowed = (s[:, k] > 0) & (s[:, i] < 0) & (s[:, j] < 0) & (C == 0)
        bad = int((diff & ~allowed).sum())
        if k == 0:
            print('  delta = %s*delta*: changed %d, outside claimed footprint %d' % (fac, int(diff.sum()), bad), end='')
        else:
            print(' | k=%d: %d' % (k + 1, bad), end='')
    print()

print('(4) corner-hugging B-lines in M_k (k=1): best interior margin of a point inside all')
# line in M_1 with edge coordinates z12 (on [e1,e2]) and z13 (on [e1,e3]) from e1.
# e1-corner triangle has vertices e1, (1-z12)e1+z12 e2, (1-z13)e1+z13 e3. A point m lies
# strictly inside iff m2/z12 + m3/z13 < 1. Max over m of min(m1,m2,m3) inside all triangles:
for eta in (F(1, 10), F(1, 100), F(1, 1000)):
    z12, z13 = eta, F(3, 10)  # B-lines with z12 down to eta, z13 = 0.3
    # maximise t with m2,m3 >= t, m1 >= t, m2/z12 + m3/z13 < 1 -> t (1/z12 + 1/z13) < 1
    t = 1 / (1 / z12 + 1 / z13)
    print('  ess inf z12 = %s: best min-coordinate of a realising point < %s' % (eta, t))
