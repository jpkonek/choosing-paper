"""Independent re-check of PP26 Theorem M (mass-blind rules), written from scratch.

Patterns at a fixed world i are triples over {T, W, I}, indexed (own region M_i, M_j, M_k).
Mixed patterns contain both W and I (12 of them). Guidance patterns: only W/T, not all T.

A triple of nontrivial patterns (x, y, z) is realisable as a triangle X->Y->Z->X by
region-pure records iff on each region the entries are all T or contain both W and I.
A set S of accepted mixed patterns (plus all guidance patterns) is (TC)-safe iff
  (a) no x in S has swap(x) in S  (refined 2-step pump closes by guidance), and
  (b) no realisable triangle has all three edges in S or guidance.
(Any accepted realisable triangle then lacks a reverse: guidance reverses are pure
improvements; reverses of mixed patterns are swaps, excluded by (a).)

Veto at world i (PP26 section 2):
  (V-own) for some j: (I, W_j, I_k) and (I, W_j, T_k) both refused;
  (V-maj) for some f: (W, I_f, I_o) and (W, I_f, T_o) both refused.
Run: python3 -B thmM_enum.py
"""
import itertools

V = 'TWI'
pats = [''.join(p) for p in itertools.product(V, repeat=3)]
mixed = [p for p in pats if 'W' in p and 'I' in p]
guid = [p for p in pats if 'I' not in p and p != 'TTT']
swap = lambda p: p.translate(str.maketrans('WI', 'IW'))
assert len(mixed) == 12 and len(guid) == 7


def region_ok(a, b, c):
    s = {a, b, c}
    return s == {'T'} or ('W' in s and 'I' in s)


def realisable(x, y, z):
    return all(region_ok(x[r], y[r], z[r]) for r in range(3))


def safe(S):
    S = set(S)
    if any(swap(x) in S for x in S):
        return False
    acc = list(S) + guid
    for x, y, z in itertools.product(acc, repeat=3):
        if (x in S or y in S or z in S) and realisable(x, y, z):
            return False
    # all-guidance triangles are never realisable (no I anywhere)
    return True


safe_sets = []
for mask in range(1 << 12):
    S = [mixed[b] for b in range(12) if mask >> b & 1]
    if safe(S):
        safe_sets.append(frozenset(S))
print('TC-safe sets of mixed patterns:', len(safe_sets))
maximal = [S for S in safe_sets if not any(S < T for T in safe_sets)]
print('maximal:', len(maximal))


def lex(order):
    out = set()
    for p in mixed:
        first = next(p[r] for r in order if p[r] != 'T')
        if first == 'W':
            out.add(p)
    return frozenset(out)


lexsets = {lex(o) for o in itertools.permutations(range(3))}
print('maximal == the 6 lexicographic orders:', set(maximal) == lexsets)


def has_veto(S):
    # positions: 0 own, 1 and 2 the other regions
    for j, k in ((1, 2), (2, 1)):
        p1 = ['I', '', '']; p1[j] = 'W'; p1[k] = 'I'
        p2 = ['I', '', '']; p2[j] = 'W'; p2[k] = 'T'
        if ''.join(p1) not in S and ''.join(p2) not in S:
            return True
    for f, o in ((1, 2), (2, 1)):
        p1 = ['W', '', '']; p1[f] = 'I'; p1[o] = 'I'
        p2 = ['W', '', '']; p2[f] = 'I'; p2[o] = 'T'
        if ''.join(p1) not in S and ''.join(p2) not in S:
            return True
    return False


print('safe sets without a veto:', sum(not has_veto(S) for S in safe_sets))
# sanity: the full mixed set and its complement structure
print('swap-closed pairs among mixed:', sum(1 for p in mixed if swap(p) in mixed) // 2)
