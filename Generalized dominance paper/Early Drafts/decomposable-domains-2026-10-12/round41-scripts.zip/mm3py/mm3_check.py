# MM3 referee: independent exact re-derivation of LL3 Sec. 3.5 (certificate out of two plain-posterior models),
# LL3 Thm A(e) (Nakamura numbers of quotas), and LL3 Thm B2 / Cor B1' arithmetic for several (n,q,eta).
# Written from the text of LL3, not from LL3's scripts.  All arithmetic in Fractions.
# Run: python3 -I mm3_check.py > mm3_check.out
from fractions import Fraction as F
from itertools import combinations
from math import comb, ceil

OK = True
def check(c, msg):
    global OK
    print(("ok   " if c else "FAIL ") + msg)
    OK &= bool(c)

# ---------------- Part 1: geometry of the two boxes (eps = 3/10, world 1) ----------------
eps = F(3, 10); c0 = (1 - eps) / 3
pA = (F(17, 50), F(33, 100), F(33, 100)); pB = (F(33, 100), F(17, 50), F(33, 100))
check(sum(pA) == 1 and sum(pB) == 1, "pA, pB are probability vectors")
def phi(p, g):  # C_p accepts mixed g iff phi > 0  (p (.) g in D_T1)
    w = [p[j] * g[j] for j in range(3)]
    return c0 * sum(w) + eps * min(w)
def lip(p):     # sup-norm Lipschitz constant of phi_p:  c0*sum p + eps*max p
    return c0 * sum(p) + eps * max(p)
rad = F(59, 300000)
gAB = (F(2393, 9900), F(-529, 2550), F(2393, 9900))
gBA = (F(593, 10200), F(4193, 9900), F(-529, 2475))
neg = lambda g: tuple(-x for x in g)
for name, g, acc, sil in (("R_AB", gAB, pA, pB), ("R_BA", gBA, pB, pA)):
    a1 = phi(acc, g); a2 = phi(acc, neg(g)); s1 = phi(sil, g); s2 = phi(sil, neg(g))
    La, Ls = lip(acc), lip(sil)
    check(g[0] > rad and min(abs(x) for x in g) > rad, f"{name}: centre has g_1>0 and every |g_j| > radius (box mixed, off planes)")
    check(a1 > La * rad and a2 < -La * rad, f"{name}: accepting model accepts g and not -g on the whole box "
          f"(phi={float(a1):.3e}, phi(-g)={float(a2):.3e}, L*r={float(La*rad):.3e})")
    check(s1 < -Ls * rad and s2 < -Ls * rad, f"{name}: other model silent on the whole box "
          f"(phi={float(s1):.3e}, phi(-g)={float(s2):.3e})")
# boxes disjoint
check(max(abs(gAB[j] - gBA[j]) for j in range(3)) > 2 * rad, "the two boxes are disjoint")

# ---------------- Part 1b: the eight records, from scratch ----------------
eta = F(1, 16); n = 4; q = 3; Wset = range(1, 5)
# pieces: (region, w, kind, k) ; Q pieces mass 1 (k != w), R piece mass 1/4
pieces = {}
for X in ("AB", "BA"):
    for w in Wset:
        for k in Wset:
            if k != w: pieces[(X, w, 'Q', k)] = F(1)
        pieces[(X, w, 'R', 0)] = F(1, 4)
sigma = lambda v, piece: F(2) if piece[1] == v else F(1)   # judge v has density 2 on N^X_w iff v == w
# base ranks at world 1: in AB boxes A good(0), B silent(1); in BA boxes A silent(1), B good(0)
base = {('A', 'AB'): 0, ('A', 'BA'): 1, ('B', 'AB'): 1, ('B', 'BA'): 0}
records = {}
for k in Wset:
    # X^A_k: good on P^BA_k = U_{j!=k} Q^BA_{j,k} U R^BA_k ; silence on U_{w!=k} Q^AB_{k,w}
    recA = {}
    for pc in pieces:
        if pc[0] == "BA" and pc[1] == k: recA[pc] = (base[('A', 'BA')], 0)
        if pc[0] == "AB" and pc[2] == 'Q' and pc[3] == k: recA[pc] = (base[('A', 'AB')], 1)
    recB = {}
    for pc in pieces:
        if pc[0] == "AB" and pc[1] == k: recB[pc] = (base[('B', 'AB')], 0)
        if pc[0] == "BA" and pc[2] == 'Q' and pc[3] == k: recB[pc] = (base[('B', 'BA')], 1)
    records[('A', k)] = recA; records[('B', k)] = recB
def IW(rec, v):
    I = sum(pieces[p] * sigma(v, p) * (r0 - r1) for p, (r0, r1) in rec.items() if r1 < r0)
    W = sum(pieces[p] * sigma(v, p) * (r1 - r0) for p, (r0, r1) in rec.items() if r1 > r0)
    return F(I), F(W)
ratios = []
for key, rec in records.items():
    sup = []
    for v in Wset:
        I, W = IW(rec, v)
        if W - I >= eta * (W + I): sup.append(v); ratios.append((W - I) / (W + I))
        if v != key[1]: check(I == F(13, 4) and W == 4, f"record {key}: judge {v} has I=13/4, W=4")
        else: check(I == F(13, 2) and W == 3 and W - I < 0, f"record {key}: judge {v} (=k) has I=13/2, W=3, dissents")
    check(len(sup) >= q, f"record {key}: accepted with supporters {sup}")
    # reverse comparison X R base: supporters
    rev = {p: (r1, r0) for p, (r0, r1) in rec.items()}
    rs = [v for v in Wset if (lambda I, W: W - I >= eta * (W + I))(*IW(rev, v))]
    check(len(rs) < q, f"record {key}: reverse has supporters {rs} (not accepted)")
# net rank change per piece
net = {p: 0 for p in pieces}; touches = {p: 0 for p in pieces}
for rec in records.values():
    for p, (r0, r1) in rec.items(): net[p] += r1 - r0; touches[p] += 1
check(all(net[p] == 0 and touches[p] == 2 for p in pieces if p[2] == 'Q'), "every Q piece: one good->silence and one silence->good move (net 0)")
check(all(net[p] == -1 and touches[p] == 1 for p in pieces if p[2] == 'R'), "every R piece: improved exactly once (net -1)")
check(min(ratios) == F(3, 29), f"supporters' net/gross ratio = {min(ratios)} (so a psi-rule accepts at scale s iff psi((29/4)s) <= (3/4)s)")
# sum of judge-v losses over the 8 records, for each judge: strictly negative
for v in Wset:
    tot = sum(W - I for (I, W) in (IW(rec, v) for rec in records.values()))
    check(tot < 0, f"judge {v}: summed loss change over the 8 records = {tot} < 0")

# ---------------- Part 2: Nakamura numbers of quotas ----------------
for n in range(2, 10):
    for q in range(1, n + 1):
        form = ceil(n / (n - q)) if q < n else float('inf')
        nu = form
        # brute-force confirmation for small n
        if n <= 6 and q < n:
            sets = [frozenset(S) for S in combinations(range(n), q)]
            bf = None
            for k in range(1, 7):
                found = any(len(frozenset.intersection(*fam)) == 0 for fam in combinations(sets * 1, k)) if k <= len(sets) else False
                # allow repetition: repetition never helps empty intersection beyond distinct sets, except k > #sets
                if found: bf = k; break
            if bf is not None: assert bf == form, (n, q, bf, form)
        assert ((nu >= 3) == (2 * q > n)) and ((nu >= 4) == (3 * q > 2 * n)), (n, q)
check(True, "Nakamura number of q-of-n equals ceil(n/(n-q)) by brute force (n<=6); and ceil(n/(n-q))>=3 <=> 2q>n, >=4 <=> 3q>2n (n<=9)")

# ---------------- Part 3: Thm B2 type-level arithmetic, M* of Cor B1' ----------------
def Mstar(n, q, eta): return 1 + 2 * q * eta / ((n - q) * (1 - eta))
for (n, q) in ((4, 3), (5, 4), (7, 5), (5, 3), (6, 5), (9, 7)):
    for eta in (F(1, 16), F(1, 3), F(1, 2), F(9, 10)):
        r = (1 - eta) / (1 + eta)
        for M, expect in ((Mstar(n, q, eta) * F(1001, 1000), True), (Mstar(n, q, eta), False)):
            Ds = [frozenset(D) for D in combinations(range(n), n - q)]
            z = lambda D: [M if v in D else F(1) for v in range(n)]
            Np = comb(q, n - q)
            c = r * (Np + (M - 1) * comb(q - 1, n - q - 1))
            a = c; b = F(1)
            feasible = a > Np   # need a in (N', c]
            if expect:
                good = feasible
                for D in Ds:
                    dis = [D2 for D2 in Ds if not (D2 & D)]
                    assert len(dis) == Np
                    for v in range(n):
                        if v in D: continue
                        I = a * z(D)[v]; W = b * sum(z(D2)[v] for D2 in dis)
                        good &= (I <= r * W)
                check(good, f"B2 (n,q)=({n},{q}) eta={eta}: at M=M*(1+1e-3) every R_D accepted by the q judges outside D, a-N'b>0")
            else:
                check(not feasible, f"B2 (n,q)=({n},{q}) eta={eta}: at M=M*={Mstar(n,q,eta)} the interval (N',c] is empty")

print("ALL CHECKS PASSED" if OK else "SOME CHECK FAILED")
