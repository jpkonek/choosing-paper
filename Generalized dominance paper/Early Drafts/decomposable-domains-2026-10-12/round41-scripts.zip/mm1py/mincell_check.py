"""MM1: exact checks for the min-cell (cellwise-linear) judge class.

Cells M_k = {g : g_k is the strict minimum coordinate}.  A min-cell judge (i,v) has
accept/silence switch value c_iv(g) = kappa_iv[k] * g_i on M_k (kappa_iv in Q^3_{>0}).
A branch mixture has cell normals omega^k_i = sum_v alpha_iv kappa_iv[k].
A lower-probability triangle K = {m >= c}, t = 1 - sum c, has P_K(g) = (c + t e_k).g on M_k.
Weak Bayes in all cells <=> W = (c 1^T + t I) D, i.e. row i of W is Omega_i = A_i d with
A_i = c_i I + t e_i e_i^T, d > 0.  Branch F feasible <=> exists d>0 with A_i d in cone(kappa_{iF_i}).
All arithmetic in Fractions.
"""
from fractions import Fraction as Fr
from itertools import combinations, product
import random

def vec(*a): return [Fr(x) for x in a]
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def cross(a,b): return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]
def add(a,b): return [x+y for x,y in zip(a,b)]
def sc(s,a): return [s*x for x in a]
def det3(r): return dot(r[0], cross(r[1], r[2]))
def A(c, i, d):
    t = 1 - sum(c)
    out = sc(c[i], d)
    out[i] += t*d[i]
    return out

def in_cone2(x, a, b):
    """x in cone(a,b) (x, a, b in Q^3, x != 0)?  exact."""
    n = cross(a, b)
    if any(n):
        if dot(n, x) != 0: return False
        # solve x = s a + u b using a 2x2 minor with nonzero determinant
        for (p,q) in ((0,1),(0,2),(1,2)):
            D = a[p]*b[q]-a[q]*b[p]
            if D != 0:
                s = (x[p]*b[q]-x[q]*b[p])/D
                u = (a[p]*x[q]-a[q]*x[p])/D
                return s >= 0 and u >= 0 and (s > 0 or u > 0)
        return False
    # a, b parallel (same ray since both positive)
    if any(cross(x, a)): return False
    return dot(x, a) > 0

def nullspace(rows):
    """exact basis of {d in Q^3 : r.d = 0 for all rows r}."""
    R = [r[:] for r in rows if any(r)]
    piv = []; m = [r[:] for r in R]; rr = 0
    for col in range(3):
        p = next((j for j in range(rr, len(m)) if m[j][col] != 0), None)
        if p is None: continue
        m[rr], m[p] = m[p], m[rr]
        pv = m[rr][col]; m[rr] = [x/pv for x in m[rr]]
        for j in range(len(m)):
            if j != rr and m[j][col] != 0:
                f = m[j][col]; m[j] = [x - f*y for x, y in zip(m[j], m[rr])]
        piv.append(col); rr += 1
    free = [c for c in range(3) if c not in piv]
    basis = []
    for fcol in free:
        v = [Fr(0)]*3; v[fcol] = Fr(1)
        for j, pc in enumerate(piv): v[pc] = -m[j][fcol]
        basis.append(v)
    return basis

def kernel_rank(M):
    b = nullspace(M)
    return 3 - len(b), (b[0] if len(b) == 1 else None)

def system_rows(c, kap, F):
    rows = []
    t = 1 - sum(c)
    for i in range(3):
        a, b = kap[i][F[i][0]], kap[i][F[i][1]]
        n = cross(a, b)
        normals = [n] if any(n) else [cross(a, e) for e in ([1,0,0],[0,1,0],[0,0,1]) if any(cross(a, e))]
        for nn in normals:
            nn = [Fr(x) for x in nn]
            r = sc(c[i], nn); r[i] += t*nn[i]
            rows.append(r)
    return rows

def branch_feasible(c, kap, F):
    """kap[i][v] in Q^3; F = (pair_1, pair_2, pair_3).  Returns (status, d)."""
    basis = nullspace(system_rows(c, kap, F))
    if len(basis) == 0: return "infeasible(only d=0)", None
    if len(basis) == 1:
        k = basis[0]
        for d in (k, sc(-1, k)):
            if all(x > 0 for x in d) and all(in_cone2(A(c, i, d), kap[i][F[i][0]], kap[i][F[i][1]]) for i in range(3)):
                return "feasible", d
        return "infeasible(unique d fails)", None
    return "kernel dim >= 2 (not decided here)", None

PAIRS = list(combinations(range(4), 2))
BRANCHES = list(product(PAIRS, PAIRS, PAIRS))
assert len(BRANCHES) == 216

def P_T1(g, eps):
    c0 = (1-eps)/3
    return c0*sum(g) + eps*min(g)

def run(eps):
    print("="*70); print("eps =", eps)
    c0 = (1-eps)/3
    cT = [c0, c0, c0]
    # Part 0: T1's support function is min-cell linear: P_T1(g) = v_k . g on M_k
    random.seed(1)
    for _ in range(2000):
        g = [Fr(random.randint(-50,50), random.randint(1,9)) for _ in range(3)]
        if len(set(g)) < 3: continue
        k = g.index(min(g))
        vk = [c0]*3; vk[k] += eps
        assert dot(vk, g) == P_T1(g, eps)
    print("Part 0: P_T1(g) = v_k.g on M_k (2000 exact samples)  OK")

    # Part A: a doubled design certifies T1 in all 216 branches
    delta = c0/2
    kstar = [[c0 + (eps if k == i else 0) for k in range(3)] for i in range(3)]
    tau = []
    for i in range(3):
        tv = [Fr(0)]*3; tv[(i+1)%3] = Fr(1); tv[(i+2)%3] = Fr(-1); tau.append(tv)
    kap = [[add(kstar[i], sc(delta, tau[i])), kstar[i], sc(Fr(2), kstar[i]), add(kstar[i], sc(-delta, tau[i]))] for i in range(3)]
    # judges 1 and 2 (0-based) are proportional (doubled); 0 and 3 straddle
    for i in range(3):
        for v in range(4): assert all(x > 0 for x in kap[i][v])
    ones = vec(1,1,1)
    ok = 0
    for F in BRANCHES:
        # direct check with d = 1 (the unique d, see rank below)
        good = True
        for i in range(3):
            a, b = kap[i][F[i][0]], kap[i][F[i][1]]
            if not in_cone2(A(cT, i, ones), a, b): good = False
        ok += good
    print("Part A: doubled design, T1 (c = c0 1) certified in", ok, "of 216 branches with d = (1,1,1)")
    assert ok == 216
    # rank of the (branch-independent, coplanar) system at T1
    nrm = [cross(kstar[i], tau[i]) for i in range(3)]
    t = 1 - sum(cT)
    M = []
    for i in range(3):
        r = sc(cT[i], nrm[i]); r[i] += t*nrm[i][i]; M.append(r)
    rk, kv = kernel_rank(M)
    print("        coplanar normal system at T1: rank", rk, "kernel", kv)
    assert rk == 2

    # Part B: every other triangle model reachable in the common plane system fails some branch
    random.seed(2)
    tested = 0
    for _ in range(400):
        d = [1 + Fr(random.randint(-20,20), 200) for _ in range(3)]
        if d[0] == d[1] == d[2]: continue
        # solve n_i . A_i(c) d = 0 for c (linear in c): c_i (n_i.d) + (1 - c1-c2-c3) n_ii d_i = 0
        rows, rhs = [], []
        for i in range(3):
            r = [Fr(0)]*3
            r[i] += dot(nrm[i], d)
            for j in range(3): r[j] -= nrm[i][i]*d[i]
            rows.append(r); rhs.append(-nrm[i][i]*d[i])
        D = det3(rows)
        if D == 0: continue
        c = []
        for j in range(3):
            Rj = [row[:] for row in rows]
            for i in range(3): Rj[i][j] = rhs[i]
            c.append(det3(Rj)/D)
        if not (all(x > 0 for x in c) and sum(c) < 1): continue
        # Omega_i = A_i(c) d lies in plane_i; compute its tau-coordinate
        fails = []
        for F in BRANCHES:
            st, _ = branch_feasible(c, kap, F)
            assert not st.startswith("kernel dim")
            if st != "feasible": fails.append(F)
        assert len(fails) > 0, (c, d)
        tested += 1
    print("Part B:", tested, "triangle models c != c0 on the coplanar surface: each fails >= 1 branch (exact)")

    # Part C: generic (non-coplanar) judges: T1 fails some branch
    random.seed(3)
    always = True
    for trial in range(200):
        kp = [[[Fr(random.randint(1,40), random.randint(1,9)) for _ in range(3)] for v in range(4)] for i in range(3)]
        nf = 0
        for F in BRANCHES:
            st, _ = branch_feasible(cT, kp, F)
            if st != "feasible": nf += 1
        if nf == 0: always = False
    print("Part C: 200 random generic judge sets: T1 fails >= 1 branch in every one:", always)
    assert always

    # Part D: the doubled single field kstar has exactly one coherent triangle model, namely T1
    # equations a_i kstar_i[k] = (c_i + t delta_ik) d_k; d from off-diagonal ratios
    ks = kstar
    d2_d3 = ks[0][1]/ks[0][2]; d1_d3 = ks[1][0]/ks[1][2]; d1_d2 = ks[2][0]/ks[2][1]
    assert d1_d3 == d1_d2 * d2_d3   # consistency of the ratio system
    d = [d1_d3, d2_d3, Fr(1)]
    gam = []; bet = []
    for i in range(3):
        k = (i+1) % 3
        g_i = ks[i][k]/d[k]
        gam.append(g_i)
        bet.append(g_i/(ks[i][i]/d[i] - g_i))
    t = 1/(1 + sum(bet)); c = [t*b for b in bet]
    print("Part D: unique coherent triangle model of the doubled field: c =", c, " (c0 =", c0, ")")
    assert c == cT

for eps in (Fr(1,10), Fr(3,10), Fr(1,2)):
    run(eps)
print("ALL CHECKS PASSED")
