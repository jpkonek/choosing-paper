"""MM1: exact checks of the pair-Helly lemma (Lemma 3.1 of MM1_notes).

(1) 1D, exhaustive: for two (and three) worlds with four points each in {0,...,5},
    all pair-intervals of different worlds intersect (all triples share a point)
    iff x(2)=x(3)=y(2)=y(3) (=z(2)=z(3)).
(2) 3D cones, random exact: three worlds, four vectors each; the 216-branch condition
    (every triple of pair-cones has a common nonzero point) holds only for configurations
    that are coplanar per world with a doubled middle ray common to all worlds.
"""
from fractions import Fraction as Fr
from itertools import combinations, product
import random

PAIRS = list(combinations(range(4), 2))

def iv(pts, P): a, b = pts[P[0]], pts[P[1]]; return (min(a,b), max(a,b))

def check1d():
    rng = range(6)
    n2 = n3 = 0
    configs = [c for c in product(rng, repeat=4) if list(c) == sorted(c)]
    for x in configs:
        for y in configs:
            ok = all(max(iv(x,P)[0], iv(y,Q)[0]) <= min(iv(x,P)[1], iv(y,Q)[1]) for P in PAIRS for Q in PAIRS)
            pred = (x[1] == x[2] == y[1] == y[2])
            assert ok == pred, (x, y)
            n2 += 1
    for x in configs[::3]:
        for y in configs[::3]:
            for z in configs[::3]:
                ok = all(max(iv(x,P)[0], iv(y,Q)[0], iv(z,R)[0]) <= min(iv(x,P)[1], iv(y,Q)[1], iv(z,R)[1])
                         for P in PAIRS for Q in PAIRS for R in PAIRS)
                pred = (x[1] == x[2] == y[1] == y[2] == z[1] == z[2])
                assert ok == pred
                n3 += 1
    print("1D: two-world configurations checked:", n2, " three-world:", n3, " OK")

def dot(a,b): return sum(p*q for p,q in zip(a,b))
def cross(a,b): return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]
def sc(s,a): return [s*x for x in a]

def in_cone(x, gens):
    a, b = gens
    n = cross(a, b)
    if any(n):
        if dot(n, x) != 0: return False
        for (p,q) in ((0,1),(0,2),(1,2)):
            D = a[p]*b[q]-a[q]*b[p]
            if D != 0:
                s = (x[p]*b[q]-x[q]*b[p])/D; u = (a[p]*x[q]-a[q]*x[p])/D
                return s >= 0 and u >= 0 and (s > 0 or u > 0)
    if any(cross(x, a)): return False
    return dot(x, a) > 0

def triple_ok(cones):
    # candidate rays: every generator, and pairwise plane intersections (both signs)
    cands = []
    for g in cones:
        cands += [g[0], g[1]]
    for g, h in combinations(cones, 2):
        n1, n2 = cross(*g), cross(*h)
        if any(n1) and any(n2):
            l = cross(n1, n2)
            if any(l): cands += [l, sc(-1, l)]
    return any(all(in_cone(x, c) for c in cones) for x in cands if any(x))

def holds216(kap):
    return all(triple_ok([(kap[i][F[i][0]], kap[i][F[i][1]]) for i in range(3)])
               for F in product(PAIRS, PAIRS, PAIRS))

def rnd(): return Fr(random.randint(1, 30), random.randint(1, 7))

def check3d():
    random.seed(7)
    cnt = {"generic": 0, "coplanar_nodouble": 0, "doubled_common": 0, "doubled_distinct": 0}
    for _ in range(40):
        kap = [[[rnd() for _ in range(3)] for v in range(4)] for i in range(3)]
        assert not holds216(kap); cnt["generic"] += 1
    for _ in range(40):
        kap = []
        for i in range(3):
            a, b = [rnd() for _ in range(3)], [rnd() for _ in range(3)]
            ws = sorted(set(Fr(random.randint(0, 40), 40) for _ in range(8)))[:4]
            if len(ws) < 4: ws = [Fr(0), Fr(1,4), Fr(1,2), Fr(1)]
            kap.append([[w*x + (1-w)*y for x, y in zip(a, b)] for w in ws])
        assert not holds216(kap); cnt["coplanar_nodouble"] += 1
    for _ in range(40):
        z = [rnd() for _ in range(3)]
        kap = []
        for i in range(3):
            tau = [Fr(random.randint(-5, 5)) for _ in range(3)]
            if not any(cross(tau, z)): tau = [Fr(1), Fr(0), Fr(0)]
            s = min(min(abs(zz) for zz in z) / (1 + max(abs(tt) for tt in tau)), Fr(1))
            kap.append([[zz + s*tt for zz, tt in zip(z, tau)], z, sc(Fr(3), z), [zz - s*tt for zz, tt in zip(z, tau)]])
        assert holds216(kap); cnt["doubled_common"] += 1
    for _ in range(40):
        kap = []
        for i in range(3):
            z = [rnd() for _ in range(3)]
            tau = [Fr(random.randint(-5, 5)) for _ in range(3)]
            if not any(cross(tau, z)): tau = [Fr(1), Fr(0), Fr(0)]
            s = min(min(abs(zz) for zz in z) / (1 + max(abs(tt) for tt in tau)), Fr(1))
            kap.append([[zz + s*tt for zz, tt in zip(z, tau)], z, sc(Fr(3), z), [zz - s*tt for zz, tt in zip(z, tau)]])
        assert not holds216(kap); cnt["doubled_distinct"] += 1
    print("3D: configurations tested:", cnt)
    print("    216-branch condition fails for generic, coplanar-undoubled and doubled-with-distinct-rays;")
    print("    holds for doubled-with-common-ray, as Lemma 3.1 predicts.")

check1d()
check3d()
print("ALL CHECKS PASSED")
