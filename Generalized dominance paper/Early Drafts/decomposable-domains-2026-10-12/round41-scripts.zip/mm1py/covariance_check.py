"""MM1: (a) scaling covariance of monomial judges (Lemma 2.4); (b) the kink rays of the plain
posterior family sweep every direction of the open two-negative orthants (Cor 2.3)."""
import sympy as sp
from fractions import Fraction as Fr
import random

g1, g2, g3, p1, p2, p3 = sp.symbols('g1 g2 g3 p1 p2 p3', positive=True)
e = sp.symbols('e1 e2 e3', real=True)
# monomial switch value at world 1 on the orthant where g1>0 (|g_j| written as g_j>0 after sign split)
f = g1**e[0] * g2**e[1] * g3**e[2]
fp = f.subs({g1: p1*g1, g2: p2*g2, g3: p3*g3}, simultaneous=True)
ratio = sp.simplify(sp.powsimp(sp.expand_power_base(fp / f, force=True), force=True))
print("(a) f(p*g)/f(g) =", ratio)
assert sp.simplify(ratio - p1**e[0]*p2**e[1]*p3**e[2]) == 0

# (b) kink rays p^{-1} * r_12 of C_p = {g : p*g in D_T1}; r_12 = (-1,-1,kappa+1)
random.seed(5)
for eps in (Fr(1,10), Fr(3,10), Fr(1,2)):
    kappa = (1 + 2*eps)/(1 - eps)
    for _ in range(500):
        a, b, c = (Fr(random.randint(1, 99), random.randint(1, 9)) for _ in range(3))
        # target direction (-a,-b,c): p proportional to (1/a, 1/b, (kappa+1)/c)
        p = [1/a, 1/b, (kappa + 1)/c]; s = sum(p); p = [x/s for x in p]
        ray = [-1/p[0], -1/p[1], (kappa + 1)/p[2]]
        lam = ray[2]/c
        assert all(x > 0 for x in p)
        assert [ray[0]/lam, ray[1]/lam, ray[2]/lam] == [-a, -b, c]
        # check it is a corner of C_p: p*ray lies on the corner r_12 of D_T1
        c0 = (1 - eps)/3
        y = [p[i]*ray[i] for i in range(3)]
        v = [[c0 + (eps if k == i else 0) for i in range(3)] for k in range(3)]
        vals = [sum(v[k][i]*y[i] for i in range(3)) for k in range(3)]
        assert vals[0] == 0 and vals[1] == 0 and vals[2] > 0
print("(b) every direction (-a,-b,c), a,b,c>0, is the kink ray p^{-1}*r_12 of exactly one interior C_p (1500 exact samples)")
print("ALL CHECKS PASSED")
