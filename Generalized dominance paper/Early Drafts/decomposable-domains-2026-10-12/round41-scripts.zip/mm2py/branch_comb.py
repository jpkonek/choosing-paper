# MM2 Lemma 3.3 (combinatorial part), n = 4, q = 3, three active worlds: 216 branches F = (F1,F2,F3), F_i pairs.
# (a) No single support S is contained in every branch (dim W = 1 impossible).
# (b) For every two supports S1, S2 some branch contains neither (dim W = 2 impossible).
# (c) Three singleton supports at one world cover all branches (the combinatorial bound 3 is tight
#     when sign constraints are ignored).
# (d) With the T1 sign constraint (every support meets all three worlds) record the least number of
#     supports needed to cover all 216 branches: lower bound by counting, and an explicit cover.
# Supports with >= 3 judges at a world lie in no branch and are irrelevant.
import itertools
J = range(4)
pairs = [frozenset(c) for c in itertools.combinations(J, 2)]
branches = list(itertools.product(pairs, repeat=3))
assert len(branches) == 216
small = [frozenset()] + [frozenset([a]) for a in J] + pairs
supports = [s for s in itertools.product(small, repeat=3) if any(s)]

def mask(S):
    m = 0
    for idx, F in enumerate(branches):
        if all(S[i] <= F[i] for i in range(3)):
            m |= 1 << idx
    return m
full = (1 << 216) - 1
masks = {S: mask(S) for S in supports}
ok_a = all(m != full for m in masks.values())
ms = list(masks.values())
ok_b = True
for x in range(len(ms)):
    for y in range(x, len(ms)):
        if ms[x] | ms[y] == full:
            ok_b = False
            break
    if not ok_b:
        break
sing = [(frozenset([a]), frozenset(), frozenset()) for a in range(3)]
ok_c = (masks[sing[0]] | masks[sing[1]] | masks[sing[2]]) == full
# (d) full-world supports; max coverage per support
fw = [S for S in supports if all(S)]
cov = max(bin(masks[S]).count('1') for S in fw)
lb = -(-216 // cov)
T = [0, 1, 2]
cover = [(frozenset([a]), frozenset([b]), frozenset([c])) for a in T for b in T for c in T]
m = 0
for S in cover:
    m |= masks[S]
ok_d = (m == full)
# greedy search for a smaller cover (diagnostic only)
best = None
import random
random.seed(1)
for trial in range(200):
    left = full; chosen = []
    order = fw[:]
    random.shuffle(order)
    while left:
        S = max(order, key=lambda S: bin(masks[S] & left).count('1'))
        chosen.append(S); left &= ~masks[S]
    if best is None or len(chosen) < len(best):
        best = chosen
print(f"(a) no support in every branch: {ok_a}")
print(f"(b) every two supports are avoided by some branch: {ok_b}  (pairs tested: {len(ms)*(len(ms)+1)//2})")
print(f"(c) three world-1 singletons cover all branches: {ok_c}")
print(f"(d) full-world supports: max branches covered by one support = {cov}; counting lower bound = {lb}; "
      f"27 transversals T^3 (|T|=3) cover: {ok_d}; best greedy cover found (diagnostic) = {len(best)}")
print("ALL CHECKS PASSED" if (ok_a and ok_b and ok_c and ok_d) else "FAILURE")
