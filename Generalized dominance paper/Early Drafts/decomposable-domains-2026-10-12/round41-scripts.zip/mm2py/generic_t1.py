# MM2 Theorem 4.2 illustration (CHECKED): for explicit heterogeneous continuous judges, at T1 (eps = 3/10),
# every one of the 216 branches has switch vectors c_F(g) at points g of dD_{T1} spanning R^F (rank 6).
# Hence (Gordan) some combination sum_j lam_j c_F(g^j) is strictly negative on F, and the multi-swap of
# Proposition 4.1 defeats (QS) at T1's index.  We exhibit lam for each branch and verify it exactly.
from fractions import Fraction as Fr
import itertools, sympy as sp

eps = Fr(3, 10); c0 = (1 - eps) / 3; kap = (1 + 2 * eps) / (1 - eps)
r12 = [-1, -1, kap + 1]; r23 = [kap + 1, -1, -1]; r31 = [-1, kap + 1, -1]
rays = [(r12, r31), (r23, r12), (r31, r23)]
v = [[c0 + (eps if j == k else 0) for j in range(3)] for k in range(3)]

# judges: c_iv(g) = sign(g_i) |g_i| (1 + A[i][v] g1^2 + B[i][v] g2^2 + C[i][v] g3^2)  (accept-vs-silence switch)
A = [[1, 2, Fr(1, 3), 5], [Fr(1, 2), 3, 1, Fr(2, 7)], [2, Fr(1, 5), 4, 1]]
B = [[Fr(1, 4), 1, 3, Fr(1, 2)], [2, Fr(1, 3), 1, 6], [1, 3, Fr(1, 2), Fr(5, 2)]]
C = [[3, Fr(1, 2), 1, 2], [1, 4, Fr(2, 3), 1], [Fr(1, 3), 2, 5, Fr(1, 2)]]
def c(i, vv, g):
    return g[i] * (1 + A[i][vv] * g[0] ** 2 + B[i][vv] * g[1] ** 2 + C[i][vv] * g[2] ** 2)

pts = []
for k, (R1, R2) in enumerate(rays):
    for (a, b) in [(Fr(1), Fr(1)), (Fr(3), Fr(1, 2)), (Fr(1, 2), Fr(3)), (Fr(2), Fr(5, 3))]:
        g = [a * R1[j] + b * R2[j] for j in range(3)]
        assert sum(v[k][j] * g[j] for j in range(3)) == 0 and all(x != 0 for x in g)
        # g is on relint F_k: check the other two facet forms are > 0
        assert all(sum(v[m][j] * g[j] for j in range(3)) > 0 for m in range(3) if m != k)
        pts.append(g)
pairs = list(itertools.combinations(range(4), 2))
allok = True
for F in itertools.product(pairs, repeat=3):
    idx = [(i, vv) for i in range(3) for vv in F[i]]
    Y = sp.Matrix([[sp.Rational(c(i, vv, g).numerator, c(i, vv, g).denominator) for g in pts] for (i, vv) in idx])
    if Y.rank() != 6:
        allok = False; print("rank deficient branch", F); continue
    # find 6 columns with full rank and solve Y_sub lam = -1
    for cols in itertools.combinations(range(len(pts)), 6):
        Ys = Y[:, list(cols)]
        if Ys.det() != 0:
            lam = Ys.LUsolve(sp.Matrix([-1] * 6))
            z = Ys * lam
            assert all(zz == -1 for zz in z)
            break
print(f"facet points used: {len(pts)}; all 216 branches have rank-6 switch matrices and a strictly negative combination: {allok}")
print("last branch tested:", F, " lam =", [str(x) for x in lam])
print("ALL CHECKS PASSED" if allok else "FAILURE")
