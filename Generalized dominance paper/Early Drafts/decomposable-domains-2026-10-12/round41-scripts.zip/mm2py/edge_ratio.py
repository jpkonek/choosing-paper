# MM2 §6 checks (exact).
# (1) Edge credal sets: K = {(1-x) e_i + x e_j : x in [al, be]}.  For g with g_i > 0 > g_j:
#     P_K(g) = (1-be) g_i + be g_j and upper = (1-al) g_i + al g_j, independent of g_k.
# (2) Ratio lemma (Lemma 6.3): if every ratio a_iv / a_ju strictly increases from point g to point g',
#     then for every w >= 0 with nonzero parts on both worlds, A_i/A_j strictly increases.
#     Random exact instances, plus the sharpness remark: with one ratio merely constant it can stay equal.
from fractions import Fraction as Fr
import random
random.seed(7)
ok = True
for _ in range(2000):
    al = Fr(random.randint(0, 50), 50); be = al + Fr(random.randint(0, 50), 50) * (1 - al)
    gi = Fr(random.randint(1, 30), 7); gj = -Fr(random.randint(1, 30), 7); gk = Fr(random.randint(-30, 30), 7)
    xs = [al + (be - al) * Fr(t, 20) for t in range(21)]
    vals = [(1 - x) * gi + x * gj for x in xs]
    ok &= (min(vals) == (1 - be) * gi + be * gj) and (max(vals) == (1 - al) * gi + al * gj)
print("(1) segment previsions independent of g_k, endpoints attain min/max:", ok)
ok2 = True
for _ in range(20000):
    a = [Fr(random.randint(1, 40), random.randint(1, 9)) for _ in range(2)]   # world-i judges in F_i at g
    b = [Fr(random.randint(1, 40), random.randint(1, 9)) for _ in range(2)]   # world-j judges in F_j at g
    lam = [Fr(random.randint(1, 30), random.randint(1, 9)) for _ in range(2)] # a_ju'/a_ju
    bp = [b[u] * lam[u] for u in range(2)]
    # every ratio a_iv'/a_ju' > a_iv/a_ju  <=>  a_iv' > a_iv * lam_u for all u
    ap = [a[t] * max(lam) + Fr(random.randint(1, 50), 97) for t in range(2)]
    w = [Fr(random.randint(0, 9)) for _ in range(4)]
    if w[0] + w[1] == 0 or w[2] + w[3] == 0:
        continue
    Ai = w[0] * a[0] + w[1] * a[1]; Aj = w[2] * b[0] + w[3] * b[1]
    Aip = w[0] * ap[0] + w[1] * ap[1]; Ajp = w[2] * bp[0] + w[3] * bp[1]
    ok2 &= (Aip * Aj > Ai * Ajp)
print("(2) ratio lemma on 20000 exact instances:", ok2)
print("ALL CHECKS PASSED" if (ok and ok2) else "FAILURE")
