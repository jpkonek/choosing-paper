# MM2: exact checks for the world-separable obstruction at T1 (MM2 Theorem 5.1).
# 1. Facet pieces of dD_{T1}: on facet F_k (normal v_k = c0*1 + eps*e_k), relint = {a r + b r' : a,b>0}.
#    Determine which open sign patterns occur (exact: the sign of each coordinate is a linear form in (a,b)).
# 2. Slope matching: on a piece of F_k, B_i(x) = lam_k * (v_k)_i * x + b_i.  A half-line (i,sign) used on
#    several facets forces equal slopes.  Show the only solution is lam = 0.
# 3. Constants: each piece sigma gives sum_i beta_i^{sigma_i} = 0.  Show beta_i^+ - beta_i^- is in the row
#    space of these equations for every i (so, with beta^+ >= 0 >= beta^-, all beta vanish).
from fractions import Fraction as Fr
import itertools, sympy as sp

def run(eps):
    c0 = (1 - eps) / 3
    kap = (1 + 2 * eps) / (1 - eps)
    v = [[c0 + (eps if j == k else 0) for j in range(3)] for k in range(3)]
    r = {(0, 1): [-1, -1, kap + 1], (1, 2): [kap + 1, -1, -1], (2, 0): [-1, kap + 1, -1]}
    rays = {0: (r[(0, 1)], r[(2, 0)]), 1: (r[(1, 2)], r[(0, 1)]), 2: (r[(2, 0)], r[(1, 2)])}
    pieces = []
    for k in range(3):
        R1, R2 = rays[k]
        assert all(sum(v[k][j] * R[j] for j in range(3)) == 0 for R in (R1, R2))
        # sample the open cone by a dense exact grid of directions (a,b) = (t, 1-t); the sign changes of each
        # coordinate are at the roots of linear forms, so testing midpoints between consecutive roots is exact.
        roots = set([Fr(0), Fr(1)])
        for j in range(3):
            # coordinate j: t*R1[j] + (1-t)*R2[j] = 0
            den = R1[j] - R2[j]
            if den != 0:
                t = -R2[j] / den
                if 0 < t < 1:
                    roots.add(t)
        roots = sorted(roots)
        for t0, t1 in zip(roots, roots[1:]):
            t = (t0 + t1) / 2
            h = [t * R1[j] + (1 - t) * R2[j] for j in range(3)]
            assert all(x != 0 for x in h)
            sig = tuple(1 if x > 0 else -1 for x in h)
            pieces.append((k, sig))
    # slope matching
    lam = sp.symbols('l0:3')
    eqs = []
    use = {}
    for (k, sig) in pieces:
        for i in range(3):
            use.setdefault((i, sig[i]), set()).add(k)
    for (i, s), ks in use.items():
        ks = sorted(ks)
        for a, b in zip(ks, ks[1:]):
            eqs.append(lam[a] * sp.Rational(v[a][i].numerator, v[a][i].denominator)
                       - lam[b] * sp.Rational(v[b][i].numerator, v[b][i].denominator))
    M = sp.Matrix([[sp.diff(e, l) for l in lam] for e in eqs])
    slope_rank = M.rank()
    # constants
    names = [(i, s) for i in range(3) for s in (1, -1)]
    rows = []
    for (k, sig) in pieces:
        row = [0] * 6
        for i in range(3):
            row[names.index((i, sig[i]))] += 1
        rows.append(row)
    A = sp.Matrix(rows)
    ok_const = True
    for i in range(3):
        target = [0] * 6
        target[names.index((i, 1))] = 1
        target[names.index((i, -1))] = -1
        if sp.Matrix.vstack(A, sp.Matrix([target])).rank() != A.rank():
            ok_const = False
    return pieces, use, slope_rank, ok_const

if __name__ == '__main__':
    allok = True
    for eps in [Fr(1, 100), Fr(1, 10), Fr(3, 10), Fr(1, 2), Fr(9, 10), Fr(99, 100)]:
        pieces, use, rk, okc = run(eps)
        pats = sorted(set(s for _, s in pieces))
        print(f"eps={eps}: pieces={pieces}")
        print(f"   half-lines used on facets: { {k: sorted(v) for k, v in use.items()} }")
        print(f"   distinct patterns: {len(pats)} (all six mixed: {len(pats) == 6 and (1,1,1) not in pats and (-1,-1,-1) not in pats})")
        print(f"   slope system rank = {rk} (3 means lam = 0 forced); beta^+ - beta^- in row space for all i: {okc}")
        allok &= (rk == 3 and okc and len(pats) == 6)
    print("ALL CHECKS PASSED" if allok else "FAILURE")
