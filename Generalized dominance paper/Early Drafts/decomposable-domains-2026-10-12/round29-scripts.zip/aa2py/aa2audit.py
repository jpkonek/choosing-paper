"""The audit's loop field (AUDIT_Z123_loop.md Sec. 2), majority-orientation vectors c, d."""
from aa2common import *

def audit_cd(h, A):
    """h majority orientation with h_o = -1. Returns (c, d): M-acceptance and O-acceptance vectors."""
    o = [i for i in range(3) if h[i] < 0][0]
    others = [j for j in range(3) if j != o]
    D = h[others[0]] + h[others[1]] + (A - 1) * max(h[j] for j in others)
    c = list(h); c[o] = c[o] * A
    d = [None] * 3; d[o] = 1
    if o in (0, 1):
        j = 1 - o; k = 2; t = h[j]; s = h[k]
        d[j] = -A * t
        b = max(s, A * A * s - (A - 1)) if D < 1 else max(s, A * s - (A - 1) * t)
        d[k] = -b
    elif D < 1:
        j, k = others
        r = min((1 - h[k]) / (A * h[j]), (1 - A * h[k]) / h[j])
        z = min((1 - h[j]) / (A * h[k]), (1 - A * h[j]) / h[k])
        d[j] = -(z - 1) / (r * z - 1); d[k] = -(r - 1) / (r * z - 1)
    else:
        for j in others: d[j] = -D / 2
    return tuple(c), tuple(d)
