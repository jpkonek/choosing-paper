"""NUMERICS: from audit-field concavity defects, build candidate certificates g1, g2 accepted,
g1+g2 rejected, and report whether each of the three gambles is FORCED (aa2forced)."""
import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from aa2common import *
from aa2forced import forced_accept, classify_pair
from aa2_concav import make_accept, tstar

def explore(eps, q, n=3000, seed=7, show=5):
    acc = make_accept('audit', eps); rng = random.Random(seed)
    lam = float(params(eps)[2])
    res = []
    for _ in range(n):
        g1 = tuple(rng.gauss(0, 1) for _ in range(3)); g2 = tuple(rng.gauss(0, 1) for _ in range(3))
        m = tuple((a + b) / 2 for a, b in zip(g1, g2))
        t1, t2, tm = tstar(acc, q, g1), tstar(acc, q, g2), tstar(acc, q, m)
        dfc = (t1 + t2) / 2 - tm
        if dfc > 1e-4:
            dl = dfc / 4
            a1 = tuple(x - (t1 - dl) for x in g1); a2 = tuple(x - (t2 - dl) for x in g2)
            s = tuple(x + y for x, y in zip(a1, a2))
            fa = (forced_accept(q, a1, lam), forced_accept(q, a2, lam), forced_accept(q, s, lam))
            au = (acc(q, a1), acc(q, a2), acc(q, s))
            res.append((dfc, fa, au, a1, a2, s))
    res.sort(key=lambda r: -r[0])
    nforced = sum(1 for r in res if r[1] == (True, True, False))
    return res, nforced

if __name__ == '__main__':
    eps = Fr(sys.argv[1])
    for (l1, l2) in [(0.6, 0.2), (0.2, 0.6), (0.3, 0.02), (0.02, 0.3), (0.8, 0.1), (0.1, 0.8)]:
        l0 = 1 - l1 - l2; q = (l0 / 3 + l1, l0 / 3 + l2, l0 / 3)
        res, nf = explore(eps, q)
        print(f"eps={eps} R-bary({l0:.2f},{l1:.2f},{l2:.2f}): {len(res)} defects>1e-4, fully forced certificates: {nf}")
        for r in res[:3]:
            print("   defect %.2e forced=%s audit=%s a1=%s a2=%s" % (r[0], r[1], r[2], tuple(round(x, 4) for x in r[3]), tuple(round(x, 4) for x in r[4])))
