"""Forced q-Bayes advice for every additive field that realises the posterior loop data of
AUDIT_Z123_loop at identity indexing (Lemma AA2.7 in the note).

Works with any number type supporting + - * / and comparisons (Fraction for exact runs,
float for search).  Worlds 0,1,2.
"""
from aa2common import *

def side_interval(alphas, betas, want):
    """{s in [0,1] : for all k, alpha_k + (beta_k - alpha_k) s  <0 (want='neg') or >0 (want='pos')}.
    alpha_k = value at s=0, beta_k = value at s=1.  Returns (lo, hi) or None (open/closed ignored)."""
    lo, hi = 0, 1
    for a, b in zip(alphas, betas):
        if want == 'pos': a, b = -a, -b          # reduce to a + (b-a)s < 0
        d = b - a
        if d == 0:
            if a >= 0: return None
            continue
        r = -a / d                               # root
        if d > 0:   # increasing: need s < r
            hi = min(hi, r)
        else:       # decreasing: need s > r
            lo = max(lo, r)
    if lo >= hi: return None
    return (lo, hi)

def trace(h, lam, want):
    """Trace on the loop of the posterior O-set (want='neg': max_k f_k < 0) or M-set (want='pos':
    min_k f_k > 0).  Returns ('empty', []) | ('full', []) | ('arc', [(pt, side, s, inner_pt)...])
    | ('bad', info).  Endpoints of an arc are reported with an interior point of the arc near them."""
    F = [fvec(h, k, lam) for k in range(3)]
    ivs = []
    for i, (a, b) in enumerate(SIDES):
        iv = side_interval([dot(Fk, a) for Fk in F], [dot(Fk, b) for Fk in F], want)
        ivs.append(iv)
    present = [iv is not None for iv in ivs]
    if not any(present): return ('empty', [])
    full = all(iv is not None and iv[0] == 0 and iv[1] == 1 for iv in ivs)
    if full: return ('full', [])
    # endpoints: interval ends in the open interior of a side, or at a junction not continued
    ends = []
    for i, iv in enumerate(ivs):
        if iv is None: continue
        lo, hi = iv
        prev = ivs[(i - 1) % 3]; nxt = ivs[(i + 1) % 3]
        a, b = SIDES[i]
        if lo > 0:
            ends.append((seg_point(a, b, lo), i, lo, seg_point(a, b, (lo + hi) / 2)))
        elif not (prev is not None and prev[1] == 1):
            return ('bad', ('ends at vertex', i, 'lo'))
        if hi < 1:
            ends.append((seg_point(a, b, hi), i, hi, seg_point(a, b, (lo + hi) / 2)))
        elif not (nxt is not None and nxt[0] == 0):
            return ('bad', ('ends at vertex', i, 'hi'))
    if len(ends) != 2: return ('bad', ('nends', len(ends)))
    return ('arc', ends)

RV = [U, E1, E2]

def max_min_on_R(c, l):
    """max over R of min(c.w, l.w); candidates: vertices of R and the points of the sides of R
    where c.w = l.w."""
    cands = list(RV)
    d = tuple(x - y for x, y in zip(c, l))
    for a, b in SIDES:
        da, db = dot(d, a), dot(d, b)
        if (da > 0) != (db > 0) and da != db:
            s = da / (da - db); cands.append(seg_point(a, b, s))
    return max(min(dot(c, w), dot(l, w)) for w in cands)

def classify_pair(h, lam):
    """For majority orientation h: return a forced chart description or None.
    ('F1', c, l): on R, M iff c.w>0, O iff l.w>0, S otherwise (both charts forced, disjoint on R).
    ('S',), ('M',), ('O',): forced constant advice on R."""
    o = [i for i in range(3) if h[i] < 0][0]
    c = fvec(h, o, lam)
    tm = trace(h, lam, 'pos'); to = trace(h, lam, 'neg')
    if tm[0] == 'bad' or to[0] == 'bad': return None
    if tm[0] == 'empty' and to[0] == 'empty': return ('S',)
    if tm[0] == 'full': return ('M',)
    if to[0] == 'full': return ('O',)
    if tm[0] == 'arc' and to[0] == 'arc':
        (z1, _, _, inner), (z2, _, _, _) = to[1]
        l = cross(z1, z2)
        if dot(l, inner) < 0: l = neg(l)
        if dot(l, inner) == 0: return None
        # sanity: the M-arc endpoints lie on c.w = 0
        for (z, _, _, _) in tm[1]:
            assert abs(dot(c, z)) <= 1e-9 * (1 + sum(abs(x) for x in c)), 'M endpoint off c-line'
        if max_min_on_R(c, l) < 0: return ('F1', c, l)
        return None
    return None

def forced_accept(q, g, lam):
    """Forced acceptance of gamble g by every q-Bayes model (q in R) of every additive field
    realising the loop data at identity.  Returns True/False, or None if not forced (or a tie)."""
    kind, h = majority(g)
    if kind == 'U':
        return all(x > 0 for x in g)
    cl = classify_pair(h, lam)
    if cl is None: return None
    if cl[0] == 'F1':
        _, c, l = cl
        cq, lq = dot(c, q), dot(l, q)
        if cq == 0 or lq == 0: return None
        adv = 'M' if cq > 0 else ('O' if lq > 0 else 'S')
    else:
        adv = cl[0]
    # g = kind * |.| * h : g accepted iff (kind=+1 and adv M) or (kind=-1 and adv O)
    return adv == ('M' if kind == 1 else 'O')
