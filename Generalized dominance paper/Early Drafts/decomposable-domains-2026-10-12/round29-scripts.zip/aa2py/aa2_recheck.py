"""CHECKED (exact), second implementation: re-verify every certificate printed in certify_*.out
using the AUDIT's own vectors (c, d) of AUDIT_Z123_loop Sec. 2 instead of the trace code:
 (1) each of a1, a2, s = a1 + a2 is mixed, with majority orientation h;
 (2) posterior M-set and O-set on the loop: both proper arcs; the M-arc endpoints solve c.w = 0 and
     the O-arc endpoints solve d.w = 0 (so ANY realising field's two acceptance lines are c and d, up
     to positive scale -- Lemma AA2.8);
 (3) {c.w > 0} and {d.w > 0} are disjoint on R (checked at the vertices of R and at the points of
     the sides of R where c.w = d.w);
 (4) the forced advice at q (M iff c.q > 0, O iff d.q > 0, S otherwise) accepts a1, a2 and rejects s.
Endpoints are found by solving each posterior constraint exactly on each side."""
import sys, os, re, glob
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from aa2common import *
from aa2audit import audit_cd

def post_adv(w, h, lam):
    v = [dot(w, fvec(h, k, lam)) for k in range(3)]
    return 'M' if min(v) > 0 else ('O' if max(v) < 0 else 'S')

def arc_endpoints(h, lam, want):
    """exact endpoints on the loop of the posterior M-set (want 'M') or O-set ('O')."""
    F = [fvec(h, k, lam) for k in range(3)]
    pts = []
    for (a, b) in SIDES:
        roots = set()
        for Fk in F:
            fa, fb = dot(Fk, a), dot(Fk, b)
            if fa != fb:
                s = fa / (fa - fb)
                if 0 < s < 1: roots.add(s)
        for s in sorted(roots):
            z = seg_point(a, b, s)
            e = Fr(1, 10**12)
            l, r = post_adv(seg_point(a, b, s - e), h, lam), post_adv(seg_point(a, b, s + e), h, lam)
            if (l == want) != (r == want): pts.append(z)
    return pts

def check(q, g, lam, A):
    pos = sum(1 for x in g if x > 0); ng = sum(1 for x in g if x < 0)
    assert pos + ng == 3 and 0 < pos < 3
    kind, h = majority(g)
    c, d = audit_cd(h, A)
    mz = arc_endpoints(h, lam, 'M'); oz = arc_endpoints(h, lam, 'O')
    assert len(mz) == 2 and len(oz) == 2, (mz, oz)
    assert all(dot(c, z) == 0 for z in mz) and all(dot(d, z) == 0 for z in oz)
    # orientation: the forced O-side is the posterior O side
    for (a, b) in SIDES:
        for k in range(1, 20):
            w = seg_point(a, b, Fr(k, 20)); pa = post_adv(w, h, lam)
            if dot(c, w) != 0 and dot(d, w) != 0:
                fa = 'M' if dot(c, w) > 0 else ('O' if dot(d, w) > 0 else 'S')
                assert fa == pa, ('loop mismatch', w)
    cands = [U, E1, E2]; dd = tuple(x - y for x, y in zip(c, d))
    for (a, b) in SIDES:
        da, db = dot(dd, a), dot(dd, b)
        if (da > 0) != (db > 0): cands.append(seg_point(a, b, da / (da - db)))
    assert max(min(dot(c, w), dot(d, w)) for w in cands) < 0, 'charts overlap on R'
    cq, dq = dot(c, q), dot(d, q); assert cq != 0 and dq != 0
    adv = 'M' if cq > 0 else ('O' if dq > 0 else 'S')
    return adv == ('M' if kind == 1 else 'O')

def parse(fn):
    txt = open(fn).read(); out = []
    for m in re.finditer(r"eps=(\S+) R-bary\S+ q=\(([^)]*)\): CERTIFICATE.*?\n\s+a1=\(([^)]*)\)\n\s+a2=\(([^)]*)\)", txt):
        eps = Fr(m.group(1))
        tup = lambda s: tuple(Fr(x.strip().strip("'")) for x in s.split(','))
        out.append((eps, tup(m.group(2)), tup(m.group(3)), tup(m.group(4))))
    return out

if __name__ == '__main__':
    here = os.path.dirname(os.path.abspath(__file__)); n = 0
    for fn in sorted(glob.glob(os.path.join(here, 'certify_*.out'))):
        for eps, q, a1, a2 in parse(fn):
            _, c0, lam, A = params(eps)
            assert sum(q) == 1 and 0 < q[2] < min(q[0], q[1])
            r = (check(q, a1, lam, A), check(q, a2, lam, A), check(q, add(a1, a2), lam, A))
            assert r == (True, True, False), r
            n += 1
            print(f"eps={eps} q={tuple(str(x) for x in q)}: re-verified (accept, accept, reject) with audit vectors")
    print(f"ALL {n} certificates re-verified exactly.")
