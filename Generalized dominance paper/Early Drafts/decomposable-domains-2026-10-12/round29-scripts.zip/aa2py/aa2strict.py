"""Exact forced classification WITH a strictness audit (Lemma AA2.8 robustness).
Every branch decision of aa2forced is a sign test of a rational function of g (on a neighbourhood
where the branch is fixed).  We record the absolute value of every tested quantity (and every
pairwise difference of competing roots); if all are > 0 at g, the forced advice is constant on a
neighbourhood of g (continuity).  Returns (accept, min_gap, classtag)."""
from aa2common import *
from aa2forced import RV

def side_interval_g(alphas, betas, want, gaps):
    lo, hi = Fr(0), Fr(1); roots = []
    for a, b in zip(alphas, betas):
        if want == 'pos': a, b = -a, -b
        d = b - a
        gaps.append(abs(d))                     # d != 0 (no constant constraint)
        r = -a / d
        roots.append(r)
        gaps.append(abs(r)); gaps.append(abs(r - 1))
        if d > 0: hi = min(hi, r)
        else: lo = max(lo, r)
    for x in range(len(roots)):
        for y in range(x + 1, len(roots)):
            gaps.append(abs(roots[x] - roots[y]))
    gaps.append(abs(lo - hi))
    if lo >= hi: return None
    return (lo, hi)

def trace_g(h, lam, want, gaps):
    F = [fvec(h, k, lam) for k in range(3)]
    ivs = [side_interval_g([dot(Fk, a) for Fk in F], [dot(Fk, b) for Fk in F], want, gaps) for (a, b) in SIDES]
    if all(iv is None for iv in ivs): return ('empty', [])
    if all(iv is not None and iv[0] == 0 and iv[1] == 1 for iv in ivs): return ('full', [])
    ends = []
    for i, iv in enumerate(ivs):
        if iv is None: continue
        lo, hi = iv; prev = ivs[(i - 1) % 3]; nxt = ivs[(i + 1) % 3]; a, b = SIDES[i]
        mid = seg_point(a, b, (lo + hi) / 2)
        if lo > 0: ends.append((seg_point(a, b, lo), mid))
        elif not (prev is not None and prev[1] == 1): return ('bad', None)
        if hi < 1: ends.append((seg_point(a, b, hi), mid))
        elif not (nxt is not None and nxt[0] == 0): return ('bad', None)
    if len(ends) != 2: return ('bad', None)
    return ('arc', ends)

def max_min_on_R_g(c, l, gaps):
    cands = list(RV); d = tuple(x - y for x, y in zip(c, l))
    for a, b in SIDES:
        da, db = dot(d, a), dot(d, b)
        gaps.append(abs(da)); gaps.append(abs(db))
        if (da > 0) != (db > 0):
            cands.append(seg_point(a, b, da / (da - db)))
    return max(min(dot(c, w), dot(l, w)) for w in cands)

def forced_accept_strict(q, g, lam):
    gaps = [abs(x) for x in g]
    kind, h = majority(g)
    if kind == 'U': return (all(x > 0 for x in g), min(gaps), 'U')
    o = [i for i in range(3) if h[i] < 0][0]
    c = fvec(h, o, lam)
    tm = trace_g(h, lam, 'pos', gaps); to = trace_g(h, lam, 'neg', gaps)
    if tm[0] == 'bad' or to[0] == 'bad': return (None, 0, 'bad')
    if tm[0] == 'empty' and to[0] == 'empty': adv, tag = 'S', 'F2'
    elif tm[0] == 'full': adv, tag = 'M', 'F3'
    elif to[0] == 'full': adv, tag = 'O', 'F4'
    elif tm[0] == 'arc' and to[0] == 'arc':
        (z1, inner), (z2, _) = to[1]
        l = cross(z1, z2)
        if dot(l, inner) < 0: l = neg(l)
        gaps.append(abs(dot(l, inner)) / (sum(abs(x) for x in l)))
        for (z, _) in tm[1]: assert dot(c, z) == 0
        mm = max_min_on_R_g(c, l, gaps); gaps.append(abs(mm))
        if not mm < 0: return (None, 0, 'overlap')
        cq, lq = dot(c, q), dot(l, q)
        gaps.append(abs(cq)); gaps.append(abs(lq) / (sum(abs(x) for x in l)))
        adv = 'M' if cq > 0 else ('O' if lq > 0 else 'S'); tag = 'F1'
    else:
        return (None, 0, 'unforced')
    acc = adv == ('M' if kind == 1 else 'O')
    return (acc, min(gaps), tag)
