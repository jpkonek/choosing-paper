"""NUMERICS: map of R = co{u,e1,e2}: at grid points q (R-barycentric (l0,l1,l2), step 1/8), count
float-level fully forced non-convexity certificates found from 1500 random audit-defect pairs."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from aa2common import *
from aa2_cert_explore import explore
eps = Fr(sys.argv[1]); part = int(sys.argv[2]); nparts = int(sys.argv[3])
pts = []
for a in range(1, 8):
    for b in range(1, 8 - a):
        l1, l2 = a / 8, b / 8; l0 = 1 - l1 - l2
        if l0 <= 0: continue
        pts.append((l0, l1, l2))
for idx, (l0, l1, l2) in enumerate(pts):
    if idx % nparts != part: continue
    q = (l0 / 3 + l1, l0 / 3 + l2, l0 / 3)
    res, nf = explore(eps, q, n=1500)
    print(f"eps={eps} R-bary({l0:.3f},{l1:.3f},{l2:.3f}) q=({q[0]:.3f},{q[1]:.3f},{q[2]:.3f}): audit defects>1e-4: {len(res)}, fully forced certs: {nf}", flush=True)
