"""Sanity (CHECKED, exact): for random majority orientations h, the forced O-line l of an F1 pair is
positively proportional to the audit's d (so the audit's field is one realisation and agrees with the
forced charts), and the trace classification never returns 'bad' on random h."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from random import Random
from aa2forced import *
from aa2audit import audit_cd
rng = Random(20261017)
for eps in (Fr(1, 20), Fr(1, 10), Fr(3, 10), Fr(1, 2), Fr(4, 5)):
    _, c0, lam, A = params(eps)
    cnt = {}; prop_ok = 0; prop_bad = 0
    for trial in range(1500):
        o = rng.randrange(3)
        h = [Fr(rng.randrange(1, 2000), rng.randrange(1, 2000)) for _ in range(3)]; h[o] = Fr(-1)
        h = tuple(h)
        cl = classify_pair(h, lam)
        key = 'None' if cl is None else cl[0]
        cnt[key] = cnt.get(key, 0) + 1
        if cl is not None and cl[0] == 'F1':
            c, l = cl[1], cl[2]
            ca, da = audit_cd(h, A)
            assert ca == c
            x = cross(l, da)
            if all(v == 0 for v in x) and dot(l, da) * 1 > 0 or (all(v == 0 for v in x) and sum(l[i]*da[i] for i in range(3)) > 0):
                prop_ok += 1
            else:
                prop_bad += 1
    print(f"eps={eps}: classes {cnt}; F1 pairs with l || audit d (positively): {prop_ok}, not: {prop_bad}")
