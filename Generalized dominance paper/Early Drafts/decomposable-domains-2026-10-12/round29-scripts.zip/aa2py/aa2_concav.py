"""NUMERICS: coherence test of the audit loop field's Bayes model B_q via its 'lower prevision'
t*(g) = sup{ t : g - t 1 accepted by B_q }.  B_q is coherent (a.e. = D_K) iff t* is concave
(superlinear) and B_q = {t* > 0} a.e.; we test midpoint concavity t*((g1+g2)/2) >= (t*(g1)+t*(g2))/2
on random pairs, with float bisection.  mode='audit' uses the audit field, mode='forced' the forced
charts (None treated as reject), mode='post' the posterior itself (control: must pass)."""
import sys, os, random, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from aa2common import *
from aa2audit import audit_cd
from aa2forced import forced_accept

def make_accept(mode, eps):
    _, c0, lam, A = params(eps); lamf, Af = float(lam), float(A)
    def post(q, g):
        kind, h = majority(g)
        if kind == 'U': return all(x > 0 for x in g)
        vals = [dot(q, fvec(h, k, lamf)) for k in range(3)]
        adv = 'M' if min(vals) > 0 else ('O' if max(vals) < 0 else 'S')
        return adv == ('M' if kind == 1 else 'O')
    def aud(q, g):
        kind, h = majority(g)
        if kind == 'U': return all(x > 0 for x in g)
        c, d = audit_cd(h, Af)
        nc = math.sqrt(sum(x * x for x in c)); nd = math.sqrt(sum(x * x for x in d))
        cq, dq = dot(c, q) / nc, dot(d, q) / nd
        adv = 'M' if (cq > 0 and cq > dq) else ('O' if (dq > 0 and dq > cq) else 'S')
        return adv == ('M' if kind == 1 else 'O')
    def forc(q, g):
        r = forced_accept(q, g, lamf)
        return bool(r)
    return {'audit': aud, 'post': post, 'forced': forc}[mode]

def tstar(acc, q, g, it=50):
    lo, hi = min(g) - 1e-9, max(g) + 1e-9   # g - lo 1 >= 0 accepted; g - hi 1 <= 0 rejected
    for _ in range(it):
        mid = (lo + hi) / 2
        gg = tuple(x - mid for x in g)
        try:
            a = acc(q, gg)
        except ValueError:
            a = acc(q, tuple(x + 1e-13 for x in gg))
        if a: lo = mid
        else: hi = mid
    return (lo + hi) / 2

def test(mode, eps, q, n=4000, seed=7):
    acc = make_accept(mode, eps); rng = random.Random(seed)
    worst = 0.0; wit = None
    for _ in range(n):
        g1 = tuple(rng.gauss(0, 1) for _ in range(3)); g2 = tuple(rng.gauss(0, 1) for _ in range(3))
        m = tuple((a + b) / 2 for a, b in zip(g1, g2))
        d = (tstar(acc, q, g1) + tstar(acc, q, g2)) / 2 - tstar(acc, q, m)
        if d > worst: worst, wit = d, (g1, g2)
    return worst, wit

if __name__ == '__main__':
    mode = sys.argv[1]; eps = Fr(sys.argv[2])
    qs = []
    for (l1, l2) in [(0.0, 0.0), (0.1, 0.1), (0.3, 0.3), (0.6, 0.2), (0.2, 0.6), (0.45, 0.45), (0.3, 0.02), (0.02, 0.3), (0.8, 0.1), (0.1, 0.8)]:
        l0 = 1 - l1 - l2; qs.append(((l0 / 3 + l1, l0 / 3 + l2, l0 / 3), f'R-bary({l0:.2f},{l1:.2f},{l2:.2f})'))
    qs += [((0.3, 0.3, 0.4), 'outside R'), ((0.25, 0.25, 0.5), 'outside R')]
    for q, lab in qs:
        w, wit = test(mode, eps, q, n=int(sys.argv[3]) if len(sys.argv) > 3 else 3000)
        print(f"{mode} eps={eps} q=({q[0]:.4f},{q[1]:.4f},{q[2]:.4f}) {lab}: max midpoint concavity defect {w:.3e}", flush=True)
