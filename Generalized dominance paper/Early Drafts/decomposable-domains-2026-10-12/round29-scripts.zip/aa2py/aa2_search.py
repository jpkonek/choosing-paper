"""NUMERICS: search for non-convexity of the FORCED q-Bayes advice at interior q of R.
Slices g_i = +-1, (g_j, g_k) on a grid; a certificate is two forced-accepted grid points whose
midpoint is forced-rejected."""
import sys, os, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from aa2forced import *

def search(eps, q, N=40, Y=3.0, tries=20000, seed=1):
    _, c0, lam, A = params(eps); lam = float(lam)
    rng = random.Random(seed)
    found = []
    for i in range(3):
        for si in (1.0, -1.0):
            j, k = [x for x in range(3) if x != i]
            grid = {}
            for a in range(-N, N + 1):
                for b in range(-N, N + 1):
                    if a == 0 or b == 0: continue
                    g = [0.0] * 3; g[i] = si; g[j] = Y * a / N; g[k] = Y * b / N
                    grid[(a, b)] = forced_accept(q, tuple(g), lam)
            acc = [key for key, v in grid.items() if v is True]
            for _ in range(tries):
                if len(acc) < 2: break
                p1, p2 = rng.choice(acc), rng.choice(acc)
                if (p1[0] - p2[0]) % 2 or (p1[1] - p2[1]) % 2: continue
                m = ((p1[0] + p2[0]) // 2, (p1[1] + p2[1]) // 2)
                if m in grid and grid[m] is False:
                    found.append((i, si, p1, p2, m))
                    if len(found) > 3: return found
    return found

if __name__ == '__main__':
    eps = Fr(sys.argv[1]) if len(sys.argv) > 1 else Fr(3, 10)
    pts = []
    for a in range(1, 8):
        for b in range(1, 8):
            # q = u + a/8 (e1-u) * ... barycentric in R: q = x u + y e1 + z e2
            x = 1 - a / 8.0 - b / 8.0 * (1 - a / 8.0)
            pass
    # interior points of R: q = l0 u + l1 e1 + l2 e2 with l's positive
    for (l1, l2) in [(0.1, 0.1), (0.2, 0.1), (0.1, 0.2), (0.3, 0.3), (0.05, 0.05), (0.4, 0.2), (0.2, 0.4), (0.6, 0.2), (0.2, 0.6), (0.45, 0.45), (0.02, 0.3), (0.3, 0.02)]:
        l0 = 1 - l1 - l2
        q = (l0 / 3 + l1, l0 / 3 + l2, l0 / 3)
        f = search(eps, q)
        print(f"eps={eps} q=({q[0]:.4f},{q[1]:.4f},{q[2]:.4f}) [R-bary {l0:.2f},{l1:.2f},{l2:.2f}]: "
              f"{'CERT ' + str(f[0]) if f else 'none found'}", flush=True)
