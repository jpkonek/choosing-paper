"""Common helpers for note AA2 (exact rational arithmetic).
Worlds 0,1,2 in code = 1,2,3 in the note.  R = co{u, e1, e2}; loop L12 = [u,e1] u [e1,e2] u [e2,u].
Posterior family K_w = normalize(w (.) T1); its advice on the pair with majority orientation h
(exactly one negative coordinate o):
    M (accept h)  iff  min_k f_k(w) > 0,      O (accept -h) iff max_k f_k(w) < 0,
    f_k(w) = w.h + lam * w_k h_k   ( = (w (.) v_k).h / c0 ).
"""
from fractions import Fraction as Fr

def params(eps):
    eps = Fr(eps); c0 = (1 - eps) / 3; lam = eps / c0; A = 1 + lam
    return eps, c0, lam, A

def dot(a, b): return sum(x * y for x, y in zip(a, b))
def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def neg(a): return tuple(-x for x in a)
def add(a, b): return tuple(x + y for x, y in zip(a, b))
def E(j): return tuple(Fr(1) if i == j else Fr(0) for i in range(3))
U = (Fr(1, 3),) * 3
E1, E2 = E(0), E(1)
# loop sides, each an affine segment (start, end); loop parameter t in [0,3)
SIDES = [(U, E1), (E1, E2), (E2, U)]

def seg_point(a, b, s): return tuple((1 - s) * x + s * y for x, y in zip(a, b))

def fvec(h, k, lam):
    """f_k(w) = w . (h + lam h_k e_k): the linear functional of the k-th T1 vertex."""
    v = list(h); v[k] = v[k] + lam * h[k]; return tuple(v)

def majority(g):
    """Return (sign, h) with g = sign * |g_o| * h, h the majority orientation (one negative coordinate,
    normalised h_o = -1); or ('U', None) for unanimous g (all coordinates same strict sign)."""
    pos = sum(1 for x in g if x > 0); negc = sum(1 for x in g if x < 0)
    if pos == 3 or negc == 3: return ('U', None)
    if pos == 2 and negc == 1:
        o = [i for i in range(3) if g[i] < 0][0]; sc = -g[o]; return (1, tuple(x / sc for x in g))
    if pos == 1 and negc == 2:
        gg = neg(g); o = [i for i in range(3) if gg[i] < 0][0]; sc = -gg[o]; return (-1, tuple(x / sc for x in gg))
    raise ValueError('zero coordinate')
