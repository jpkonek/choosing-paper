"""CHECKED (exact): incoherence certificates for the FORCED q-Bayes advice at interior q of R.
For each eps and several rational q in int R: rational gambles a1, a2 (forced accepted), s = a1 + a2
(forced rejected), every branch strict (min gap > 0), so the forced advice is constant on balls
B1, B2, Bs around them; with B1 + B2 inside Bs this contradicts coherence of every q-Bayes model of
every additive field realising the loop data at identity (Thm AA2.9).
Candidates are found by float search (aa2_cert_explore), then rationalised and re-verified exactly.
A second, independent check: 300 exact random perturbations of relative size 1e-7 of each gamble
keep the same forced advice (NUMERICS supplement to the gap argument)."""
import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from aa2common import *
from aa2strict import forced_accept_strict
from aa2_cert_explore import explore

def rat(x, den=10**6): return Fr(round(x * den), den)

def certify(eps, qf, qlab, rng):
    _, c0, lam, A = params(eps)
    q = tuple(rat(x) for x in qf[:2]); q = (q[0], q[1], 1 - q[0] - q[1])
    assert q[2] < q[0] and q[2] < q[1] and q[2] > 0, 'q not in int R'
    res, nf = explore(eps, tuple(float(x) for x in q), n=2500)
    for r in res:
        if r[1] != (True, True, False): continue
        a1 = tuple(rat(x) for x in r[3]); a2 = tuple(rat(x) for x in r[4]); s = add(a1, a2)
        out = [forced_accept_strict(q, g, lam) for g in (a1, a2, s)]
        if [o[0] for o in out] != [True, True, False] or min(o[1] for o in out) <= 0: continue
        # perturbation supplement
        bad = 0
        for _ in range(300):
            pert = []
            for g in (a1, a2):
                pert.append(tuple(x * (1 + Fr(rng.randint(-10**6, 10**6), 10**13)) for x in g))
            ss = add(pert[0], pert[1])
            o2 = [forced_accept_strict(q, g, lam)[0] for g in (pert[0], pert[1], ss)]
            if o2 != [True, True, False]: bad += 1
        return dict(q=q, a1=a1, a2=a2, s=s, tags=[o[2] for o in out], gap=float(min(o[1] for o in out)), pert_bad=bad)
    return None

if __name__ == '__main__':
    rng = random.Random(99)
    epss = [Fr(x) for x in sys.argv[1:]] or [Fr(1, 10), Fr(3, 10), Fr(1, 2), Fr(4, 5)]
    for eps in epss:
        for (l1, l2) in [(0.6, 0.2), (0.2, 0.6), (0.8, 0.1), (0.1, 0.8), (0.3, 0.02), (0.4, 0.1)]:
            l0 = 1 - l1 - l2; qf = (l0 / 3 + l1, l0 / 3 + l2, l0 / 3)
            c = certify(eps, qf, None, rng)
            lab = f"R-bary({l0:.2f},{l1:.2f},{l2:.2f})"
            if c is None:
                print(f"eps={eps} {lab}: no exact certificate from this search", flush=True)
            else:
                print(f"eps={eps} {lab} q={tuple(str(x) for x in c['q'])}: CERTIFICATE classes {c['tags']} "
                      f"min gap {c['gap']:.2e}, perturbation failures {c['pert_bad']}/300\n"
                      f"    a1={tuple(str(x) for x in c['a1'])}\n    a2={tuple(str(x) for x in c['a2'])}", flush=True)
