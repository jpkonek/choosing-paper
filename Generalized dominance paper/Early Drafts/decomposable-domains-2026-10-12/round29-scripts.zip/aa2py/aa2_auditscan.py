"""NUMERICS: is the audit loop field's own Bayes model coherent at interior weights q of R (and elsewhere)?
Slice-grid convexity search as in aa2_search, but with the audit field's actual Bayes advice
(c, d each normalised to unit Euclidean norm; no radial modification)."""
import sys, os, random, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from aa2common import *
from aa2audit import audit_cd

def audit_accept(q, g, A):
    kind, h = majority(g)
    if kind == 'U': return all(x > 0 for x in g)
    c, d = audit_cd(h, A)
    nc = math.sqrt(sum(x * x for x in c)); nd = math.sqrt(sum(x * x for x in d))
    cq, dq = dot(c, q) / nc, dot(d, q) / nd
    adv = 'M' if (cq > 0 and cq > dq) else ('O' if (dq > 0 and dq > cq) else 'S')
    return adv == ('M' if kind == 1 else 'O')

def search(eps, q, N=40, Y=3.0, tries=20000, seed=1):
    _, c0, lam, A = params(eps); A = float(A)
    rng = random.Random(seed); found = []
    for i in range(3):
        for si in (1.0, -1.0):
            j, k = [x for x in range(3) if x != i]
            grid = {}
            for a in range(-N, N + 1):
                for b in range(-N, N + 1):
                    if a == 0 or b == 0: continue
                    g = [0.0] * 3; g[i] = si; g[j] = Y * a / N; g[k] = Y * b / N
                    grid[(a, b)] = audit_accept(q, tuple(g), A)
            acc = [key for key, v in grid.items() if v]
            for _ in range(tries):
                if len(acc) < 2: break
                p1, p2 = rng.choice(acc), rng.choice(acc)
                if (p1[0] - p2[0]) % 2 or (p1[1] - p2[1]) % 2: continue
                m = ((p1[0] + p2[0]) // 2, (p1[1] + p2[1]) // 2)
                if m in grid and not grid[m]:
                    found.append((i, si, p1, p2, m))
                    if len(found) > 2: return found
    return found

if __name__ == '__main__':
    eps = Fr(sys.argv[1]) if len(sys.argv) > 1 else Fr(3, 10)
    for (l1, l2) in [(0.0, 0.0), (0.1, 0.1), (0.3, 0.3), (0.05, 0.05), (0.6, 0.2), (0.2, 0.6), (0.45, 0.45), (0.3, 0.02), (0.02, 0.3)]:
        l0 = 1 - l1 - l2
        q = (l0 / 3 + l1, l0 / 3 + l2, l0 / 3)
        f = search(eps, q)
        print(f"eps={eps} q=({q[0]:.4f},{q[1]:.4f},{q[2]:.4f}) [R-bary {l0:.2f},{l1:.2f},{l2:.2f}]: "
              f"{'NONCONVEX ' + str(f[0]) if f else 'convex on grid'}", flush=True)
    # outside R, for contrast
    for q in [(0.3, 0.3, 0.4), (0.2, 0.3, 0.5), (0.25, 0.25, 0.5)]:
        f = search(eps, q)
        print(f"eps={eps} q={q} (outside R): {'NONCONVEX ' + str(f[0]) if f else 'convex on grid'}", flush=True)
