"""Vectorised boundary-pinned additive field (floats), parametrised by facets.
Worlds 0,1,2.  s[i,j](x): switching odds w_j/w_i for g_i>0>g_j, x=g_i/|g_j|.
Facet F_o (target o, others p<q) owns s[p,o], s[q,o] on (0,A+1]:
   on (0,A):  s[q,o]=f_o(x),  s[p,o]=1-f_o(A-x)       (E1: T1's M-part at u)
   on [A,A+1]: s[p,o]=gp_o, s[q,o]=gq_o  (increasing from 1)
corner c (others p<q): s[c,p](A+1)=1/alpha_c, s[c,q](A+1)=1/(1-alpha_c)   (E2 corner)
beyond A+1 (v=1/x<bs): S[i,j](v)=1-S[i,k]((1-v)/A)    (E2 reflection)
"""
import numpy as np
from math import pi
class VField:
    def __init__(self, eps, f, g):
        """f[o]=(xs,ys) on [0,A] with ys 0->1 ; g[(i,o)]=(xs,ys) on [A,A+1], ys from 1 to s[i,o](A+1)."""
        self.eps=eps; c0=(1-eps)/3; self.lam=eps/c0; A=self.A=1+self.lam; self.bs=1/(A+1)
        self.f=f; self.g=g
    def s(self,i,j,x):
        A=self.A; x=np.asarray(x,float); out=np.empty_like(x)
        p,q=sorted({0,1,2}-{j})
        m1=x<A; m2=(x>=A)&(x<=A+1); m3=x>A+1
        fx,fy=self.f[j]
        if i==q: out[m1]=np.interp(x[m1],fx,fy)
        else: out[m1]=1-np.interp(A-x[m1],fx,fy)
        gx,gy=self.g[(i,j)]
        out[m2]=np.interp(x[m2],gx,gy)
        if m3.any():
            v=1/x[m3]; k=3-i-j
            out[m3]=1/(1-self.S(i,k,(1-v)/A))
        return out
    def S(self,i,j,v):
        v=np.asarray(v,float)
        with np.errstate(divide='ignore'):
            return 1/self.s(i,j,1/np.maximum(v,1e-300))
    def accept(self,w,G):
        """G: n x 3 array. returns bool array (Bayes acceptance of g)."""
        n=G.shape[0]; acc=np.zeros(n,bool)
        pos=G>0; neg=G<0; npos=pos.sum(1); nneg=neg.sum(1)
        acc[nneg==0]=npos[nneg==0]>0
        for b in range(3):            # two positives, negative b
            m=(nneg==1)&neg[:,b]&(npos==2)
            if m.any():
                tot=np.zeros(m.sum())
                for a in range(3):
                    if a==b: continue
                    tot+=w[a]*self.s(a,b,G[m,a]/(-G[m,b]))
                acc[m]=tot>w[b]
            m=(nneg==1)&neg[:,b]&(npos==1)   # one zero coordinate: edge gamble
            if m.any():
                a=[a for a in range(3) if a!=b and True]
                Gm=G[m]; tot=np.zeros(m.sum())
                for a in range(3):
                    if a==b: continue
                    xa=np.where(Gm[:,a]>0,Gm[:,a]/(-Gm[:,b]),0.0)
                    sa=np.where(Gm[:,a]>0,self.s(a,b,np.maximum(xa,1e-12)),0.0)
                    tot+=w[a]*sa
                acc[m]=tot>w[b]
        for a in range(3):            # one positive a
            m=(npos==1)&pos[:,a]&(nneg>=1)
            if m.any():
                Gm=G[m]; tot=np.zeros(m.sum())
                for b in range(3):
                    if b==a: continue
                    yb=np.where(Gm[:,b]<0,-Gm[:,b]/Gm[:,a],0.0)
                    Sb=np.where(Gm[:,b]<0,self.S(a,b,np.maximum(yb,1e-300)),0.0)
                    tot+=w[b]*Sb
                acc[m]=w[a]>tot
        return acc
E1=np.array([1,-1,0])/np.sqrt(2); E2=np.array([1,1,-2])/np.sqrt(6)
def thresholds(F,w,n=1440,R=4.0,it=48):
    th=np.arange(n)*2*pi/n
    Ed=np.outer(np.cos(th),E1)+np.outer(np.sin(th),E2)
    lo=np.full(n,-R); hi=np.full(n,R)
    for _ in range(it):
        m=(lo+hi)/2; a=F.accept(w,Ed+m[:,None])
        hi=np.where(a,m,hi); lo=np.where(a,lo,m)
    return th,(lo+hi)/2
def curv(th,H):
    d=th[1]-th[0]
    return (np.roll(H,1)+np.roll(H,-1)-2*np.cos(d)*H)/d**2
def mono_check(F,w,th,H,R=4.0,k=60):
    Ed=np.outer(np.cos(th),E1)+np.outer(np.sin(th),E2); bad=0
    for r in np.linspace(-R,R,k):
        a=F.accept(w,Ed+r); exp=r>H; ok=np.abs(r-H)<1e-6
        bad+=int(((a!=exp)&~ok).sum())
    return bad
def T1H(eps,th):
    c0=(1-eps)/3; T=[c0*np.ones(3)+eps*np.eye(3)[k] for k in range(3)]
    Ed=np.outer(np.cos(th),E1)+np.outer(np.sin(th),E2)
    return np.max(np.stack([-(Ed@m) for m in T]),0)
def lin_field(eps):
    c0=(1-eps)/3; A=1+eps/c0
    f={o:(np.array([0,A]),np.array([0,1.])) for o in range(3)}
    g={(i,o):(np.array([A,A+1]),np.array([1,(A+1)/A])) for o in range(3) for i in range(3) if i!=o}
    return VField(eps,f,g)
