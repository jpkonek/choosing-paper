import numpy as np
from fw import *
def diag(F,w,n=1440,top=4):
    th,H=thresholds(F,w,n)
    d=th[1]-th[0]; v=(np.roll(H,1)+np.roll(H,-1)-2*cos(d)*H)/d**2
    idx=np.argsort(v)[:top]; out=[]
    for i in idx:
        g=cos(th[i])*E1+sin(th[i])*E2+H[i]*ONE
        out.append((round(v[i],3),np.round(g/np.abs(g).max(),4)))
    return out
