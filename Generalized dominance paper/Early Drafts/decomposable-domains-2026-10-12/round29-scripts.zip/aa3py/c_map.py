"""NUMERICS: coherence of Bayes models of the class-C example on a grid of Delta and on small circles round u."""
import sys,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np; from vf import *; from c_example import make
F,A,kap=make(); u=np.ones(3)/3
def negmass(w):
    th,H=thresholds(F,w,n=1440); c=curv(th,H); return np.clip(-c,0,None).sum()*(th[1]-th[0])
N=12; coh=[]; tot=0
for i in range(1,N):
    for j in range(1,N-i):
        w=np.array([i,j,N-i-j])/N; tot+=1
        if negmass(w)<1e-6: coh.append(tuple(np.round(w,3)))
print('grid 1/12 interior points',tot,'coherent:',coh)
for r in [0.05,0.01,0.002]:
    dirs=[u+r*(np.cos(a)*np.array([1,-1,0])/np.sqrt(2)+np.sin(a)*np.array([1,1,-2])/np.sqrt(6)) for a in np.linspace(0,2*np.pi,24,endpoint=False)]
    k=sum(negmass(w)<1e-6 for w in dirs)
    print('circle r',r,'coherent directions',k,'/24')
