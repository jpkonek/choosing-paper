import numpy as np, sys
sys.path.insert(0,'.')
from fw import *
eps=0.3; c0=(1-eps)/3; lam=eps/c0; A=1+lam; bs=1/(A+1)
f={o:PL([0,A],[0,1]) for o in range(3)}
vs=np.linspace(bs,1/A,50)
rho={(i,j):PL(vs,1-(A+1)*(1-A*vs)/2) for i in range(3) for j in range(3) if i!=j}
F=Field(eps,f,rho)
u=np.ones(3)/3
th,H=thresholds(F,u)
T1=[c0*np.ones(3)+eps*np.eye(3)[k] for k in range(3)]
Ht=np.array([max(-(m@(np.cos(t)*E1+np.sin(t)*E2)) for m in T1) for t in th])
print('T1 at u max|H-HT1|',np.abs(H-Ht).max(),'defect',sf_defect(th,H),'mono',monotone_violations(F,u,th,H))
for d in [np.array([-1,-1,2]),np.array([1,-1,0]),np.array([2,-1,-1])]:
    for t in [0.003,0.01,0.03]:
        w=u+t*d/np.abs(d).max()
        print(d,t,round(coherent_defect(F,w),4))
