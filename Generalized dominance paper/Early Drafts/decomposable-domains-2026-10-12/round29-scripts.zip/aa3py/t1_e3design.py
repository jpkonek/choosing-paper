import numpy as np, sys
sys.path.insert(0,'.')
from fw import *
from scipy.optimize import brentq
eps=0.3; c0=(1-eps)/3; lam=eps/c0; A=1+lam; bs=1/(A+1); ell=bs/A
z=brentq(lambda z: bs*np.log(1/z)/(1-z)-0.5,1e-9,1-1e-9); r0=z/A
vs=np.linspace(bs,1/A,400)
r=r0+(1/A-r0)*(vs-bs)/ell
# rho(v)=1-int_v^{1/A} 1/r
inv=1/r; cum=np.concatenate([[0],np.cumsum((inv[1:]+inv[:-1])/2*np.diff(vs))])
rho3=1-(cum[-1]-cum)
print('rho3(bs)',rho3[0],'slope end',1/r[-1])
f={o:PL([0,A],[0,1]) for o in range(3)}
rho={(0,1):PL(vs,bs+A*A*(vs-bs)),(0,2):PL(vs,A*vs),(1,0):PL(vs,bs+A*A*(vs-bs)),(1,2):PL(vs,A*vs),
     (2,0):PL(vs,rho3),(2,1):PL(vs,rho3)}
F=Field(eps,f,rho)
u=np.ones(3)/3
for t in [0.0,0.002,0.005,0.01,0.02,0.04,0.06,0.08,0.1]:
    w=u+t*np.array([-1,-1,2])
    th,H=thresholds(F,w)
    print(t,'beta',round(w[2]/w[0],3),'defect',round(sf_defect(th,H),4),'mono',monotone_violations(F,w,th,H))
from diag import diag
for t in [0.005,0.01,0.04]:
    print(t,diag(F,u+t*np.array([-1,-1,2])))
