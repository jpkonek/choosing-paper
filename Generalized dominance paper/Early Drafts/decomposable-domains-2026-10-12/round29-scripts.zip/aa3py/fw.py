"""AA3 framework (floats). Worlds 0,1,2.
A boundary-pinned additive field is given by six edge functions s[i,j] (x>0):
switching odds w_j/w_i for gambles g_i>0>g_j with x=g_i/|g_j|.  S[i,j](v)=1/s[i,j](1/v).
Parametrisation enforcing T1 at u (E1,E2):
  f[o] on [0,A] increasing 0->1;  for target o with others (p,q) (p<q):
     s[q,o](x)=f[o](x), s[p,o](x)=1-f[o](A-x)   (x<A)
  rho[i,j] on [bs,1/A] increasing, rho[i,j](1/A)=1, rho[i,j](bs)+rho[i,k](bs)=1:
     S[i,j](v)=rho[i,j](v) on [bs,1/A];  S[i,j](v)=1-rho[i,k]((1-v)/A) on [0,bs]
"""
import numpy as np
from math import cos, sin, pi, sqrt

class PL:
    def __init__(s, xs, ys): s.xs=np.asarray(xs,float); s.ys=np.asarray(ys,float)
    def __call__(s, x): return float(np.interp(x, s.xs, s.ys))

class Field:
    def __init__(self, eps, f, rho):
        self.eps=eps; c0=(1-eps)/3; self.lam=eps/c0; self.A=1+self.lam; self.bs=1/(self.A+1)
        self.f=f; self.rho=rho
    def s(self,i,j,x):
        A=self.A
        if x<A:
            p,q=sorted({0,1,2}-{j})
            return self.f[j](x) if i==q else 1-self.f[j](A-x)
        return 1.0/self.S(i,j,1.0/x)
    def S(self,i,j,v):
        A,bs=self.A,self.bs
        if v>1/A: return 1.0/self.s(i,j,1.0/v)
        if v>=bs: return self.rho[(i,j)](v)
        k=3-i-j
        return 1-self.rho[(i,k)]((1-v)/A)
    def accept(self,w,g):
        P=[i for i in range(3) if g[i]>0]; N=[i for i in range(3) if g[i]<0]
        if not N: return len(P)>0
        if not P: return False
        if len(P)==2:
            b=N[0]; tot=0.0
            for a in P: tot+=w[a]*self.s(a,b,g[a]/(-g[b]))
            if len(P)+len(N)==2: pass
            return tot>w[b]
        a=P[0]; tot=0.0
        for b in N: tot+=w[b]*self.S(a,b,(-g[b])/g[a])
        return w[a]>tot

E1=np.array([1,-1,0])/sqrt(2); E2=np.array([1,1,-2])/sqrt(6); ONE=np.ones(3)
def thresholds(F,w,n=720,R=3.0,it=50):
    th=np.arange(n)*2*pi/n; H=np.empty(n)
    for t in range(n):
        e=cos(th[t])*E1+sin(th[t])*E2
        lo,hi=-R,R
        for _ in range(it):
            m=(lo+hi)/2
            if F.accept(w,e+m*ONE): hi=m
            else: lo=m
        H[t]=(lo+hi)/2
    return th,H
def monotone_violations(F,w,th,H,R=3.0,k=40):
    bad=0
    for t in range(0,len(th),max(1,len(th)//90)):
        e=cos(th[t])*E1+sin(th[t])*E2
        for r in np.linspace(-R,R,k):
            if abs(r-H[t])<1e-6: continue
            if F.accept(w,e+r*ONE)!=(r>H[t]): bad+=1
    return bad
def sf_defect(th,H):
    d=th[1]-th[0]
    v=np.roll(H,1)+np.roll(H,-1)-2*cos(d)*H
    return v.min()/d**2   # ~ min of (H''+H); negative => not a support function
def coherent_defect(F,w,n=720):
    th,H=thresholds(F,w,n)
    return sf_defect(th,H)
