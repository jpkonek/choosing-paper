import sys,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np; from vf import *
eps=0.3; c0=(1-eps)/3; A=1+eps/c0; bs=1/(A+1)
# Z2 boundary field: s=x/A on (0,A]; S on [bs,1/A] = 1-(A+1)(1-Av)/2 -> s on [A,A+1]=1/S(1/x); corner alpha=1/2
xs=np.linspace(A,A+1,200); gy=1/(1-(A+1)*(1-A/xs)/2)
f={o:(np.array([0,A]),np.array([0,1.])) for o in range(3)}
g={(i,o):(xs,gy) for o in range(3) for i in range(3) if i!=o}
F=VField(eps,f,g); u=np.ones(3)/3
th,H=thresholds(F,u); print('Z2 field: T1 err',np.abs(H-T1H(eps,th)).max(),'mono',mono_check(F,u,th,H),'curvmin',curv(th,H).min())
for t in [0.003,0.01]:
    w=u+t*np.array([-1,-1,2]); th,H=thresholds(F,w); print(t,curv(th,H).min())
