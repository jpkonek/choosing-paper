"""A field in class C (edge functions C^1 with positive derivative off x=A+1), T1 at u, coherent boundary.
s_ij(x)=x/A on (0,A]; S_ij on [bs,1/A] = rho(v)=1+A(v-1/A)+kap(v-1/A)^2 with rho(bs)=1/2."""
import sys,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np; from vf import *
def make(eps=0.3):
    c0=(1-eps)/3; A=1+eps/c0; bs=1/(A+1); ell=1/A-bs
    kap=(bs-0.5)/ell**2
    xm=np.linspace(0,A,4001); xr=np.linspace(A,A+1,4001)
    rho=lambda v: 1+A*(v-1/A)+kap*(v-1/A)**2
    f={o:(xm,xm/A) for o in range(3)}
    g={(i,o):(xr,1/rho(1/xr)) for o in range(3) for i in range(3) if i!=o}
    return VField(eps,f,g),A,kap
if __name__=='__main__':
    F,A,kap=make(); u=np.ones(3)/3
    th,H=thresholds(F,u); print('kap',kap,'T1 err',np.abs(H-T1H(0.3,th)).max(),'mono',mono_check(F,u,th,H))
    xs=np.exp(np.linspace(-8,8,4001)); print('max product',max((F.s(i,j,xs)*F.s(j,i,1/xs)).max() for i in range(3) for j in range(3) if i!=j))
    v=np.linspace(1/(A+1),1/A,1000); print('min rho slope',(np.diff(F.S(0,1,v))/np.diff(v)).min())
    worst=0
    for t in np.linspace(0.02,0.98,25):
        for (i,j) in [(0,1),(0,2),(1,2)]:
            w=np.zeros(3); w[i]=1-t; w[j]=t; th,H=thresholds(F,w,n=720); worst=min(worst,curv(th,H).min())
    print('edge curvature min',round(worst,6))
