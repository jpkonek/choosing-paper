"""Referee AA4: Remark Z1.9 (modified cube field), not checked by Z1.
(a) exact: u-Bayes advice = T1 (posterior at u) on random pairs, incl. pairs near T1's boundary;
(b) exact: Bayes advice on the edge [e1,e2] = posterior edge model;
(c) exact: Bayes advice on edges [e1,e3], [e2,e3] at ratios w3/w1, w3/w2 < 1/(2A) = posterior;
(d) NUMERICS: interior weights near e1, e2, and on the arms: how often the modified field's sign-advice
    differs from the cube (posterior-box) field, and a midpoint non-convexity scan of the accepted cone.
Sign-based advice: M iff c.w>0, O iff d.w>0 (both positive is reported separately)."""
from fractions import Fraction as F
from random import Random
import numpy as np
rng = Random(1917)

def dot(a, b): return sum(x*y for x, y in zip(a, b))

def vectors(A, g):
    """majority orientation h, odd o; returns (sign s, c, d) where h = s*g; normalised h_o = -1."""
    pos = [i for i in range(3) if g[i] > 0]
    s = 1 if len(pos) == 2 else -1
    h = [s*x for x in g]; o = [i for i in range(3) if h[i] < 0][0]
    sc = -h[o]; h = [x/sc for x in h]
    lam = A-1
    c = list(h); c[o] = -A
    d = [-A*h[j] for j in range(3)]; d[o] = 1
    dcube = list(d)
    others = [j for j in range(3) if j != o]
    t = {j: h[j] for j in others}
    D = sum(t.values()) + lam*max(t.values())
    inD = D < 1 <= A*sum(t.values())
    if inD:
        if o in (0, 1):
            j = 1-o; k = 2
            d = [None]*3; d[o] = 1; d[j] = -A*t[j]; d[k] = -(t[k] + lam*max(t[k]-t[j], 0))
        else:
            t1, t2 = t[0], t[1]
            if t2 >= t1: b = (A*t1, A*t2-lam*t1)
            else: b = (A*t1-lam*t2, A*t2)
            d = [-b[0], -b[1], 1]
    return s, c, d, inD, dcube

def post(A, w, g):
    vals = [dot(w, g) + (A-1)*w[i]*g[i] for i in range(3)]
    return 'M' if min(vals) > 0 else ('O' if max(vals) < 0 else 'S')

def field(A, w, g, cube=False):
    if all(x > 0 for x in g): return 'M'
    if all(x < 0 for x in g): return 'O'
    s, c, d, inD, dcube = vectors(A, g)
    if cube: d = dcube
    a, b = dot(c, w), dot(d, w)
    if a > 0 and b > 0: return 'BOTH'
    adv = 'M' if a > 0 else ('O' if b > 0 else 'S')
    if s == -1: adv = {'M': 'O', 'O': 'M', 'S': 'S'}[adv]
    return adv

def rgamble():
    while True:
        g = [F(rng.randrange(-3000, 3001), rng.randrange(1, 3000)) for _ in range(3)]
        if any(x > 0 for x in g) and any(x < 0 for x in g) and all(x != 0 for x in g): return g

U = (F(1, 3),)*3
for eps in [F(1, 10), F(3, 10), F(1, 2)]:
    A = (1+2*eps)/(1-eps)
    badu = badD = nD = 0
    for _ in range(4000):
        g = rgamble()
        if rng.random() < .5:   # push towards T1's O-boundary via small coordinates
            g = [x/F(rng.randrange(1, 20)) if x > 0 else x for x in g]
        _, _, _, inD, _ = vectors(A, g); nD += inD
        if field(A, U, g) != post(A, U, g): badu += 1
    bade = bado = 0
    for _ in range(3000):
        g = rgamble()
        a = F(rng.randrange(1, 1000), 1000)
        w = (a, 1-a, F(0))
        if field(A, w, g) != post(A, w, g): bade += 1
        r = F(rng.randrange(1, 1000), 1000)/(2*A)          # ratio < 1/(2A)
        for w in [(1/(1+r), F(0), r/(1+r)), (F(0), 1/(1+r), r/(1+r))]:
            if field(A, w, g) != post(A, w, g): bado += 1
    print(f'eps={eps}: (a) u-Bayes vs T1 mismatches {badu}/4000 (D_o pairs {nD}); '
          f'(b) edge [e1,e2] mismatches {bade}/3000; (c) other edges, ratio<1/(2A): {bado}/6000')

# (d) NUMERICS near vertices (float)
def advice_float(A, w, g, cube=False):
    return field(A, tuple(w), list(g), cube)

nprng = np.random.default_rng(3)
for eps in [0.1, 0.3]:
    A = (1+2*eps)/(1-eps)
    for name, w in [('near e1', (0.9, 0.06, 0.04)), ('near e1b', (0.95, 0.02, 0.03)),
                    ('near e2', (0.05, 0.9, 0.05)), ('mid arm1', (0.6, 0.2, 0.2))]:
        G = nprng.normal(size=(20000, 3))
        G = G[(G > 0).any(1) & (G < 0).any(1)]
        diff = both = 0
        for g in G[:6000]:
            a1 = advice_float(A, w, g); a2 = advice_float(A, w, g, cube=True)
            diff += (a1 != a2); both += (a1 == 'BOTH')
        # midpoint non-convexity of accepted cone {g: advice M}
        acc = np.array([g for g in G[:6000] if advice_float(A, w, g) == 'M'])
        viol = 0; tests = 0
        for _ in range(20000):
            i, j = nprng.integers(len(acc), size=2)
            if acc[i] @ acc[j] < 0.9*np.linalg.norm(acc[i])*np.linalg.norm(acc[j]): continue
            tests += 1
            if advice_float(A, w, acc[i]+acc[j]) not in ('M',): viol += 1
        print(f'eps={eps} {name} w={w}: modified vs cube differ on {diff}/6000 pairs; BOTH {both}; '
              f'midpoint tests {tests}, violations {viol}')

# (e) exact non-convexity certificate for the modified field at interior weights near e1:
# gambles g=(-a,1,-b) (majority orientation h=(a,-1,b), odd world 2) in the D_2 strip.
print('(e) exact certificates (g+, g- accepted, g+ + g- not accepted) at interior weights near e1:')
for eps in [F(1, 10), F(3, 10)]:
    A = (1+2*eps)/(1-eps)
    for w in [(F(9, 10), F(6, 100), F(4, 100)), (F(95, 100), F(3, 100), F(2, 100)), (F(8, 10), F(15, 100), F(5, 100))]:
        found = None
        for ia in range(1, 4000):
            a = F(ia, 40000)
            # b just inside the D_2 strip: 1/A - a <= b < (1-a)/A, b >= a
            for jb in range(1, 20):
                b = (1/A - a) + ((1-a)/A - (1/A - a))*F(jb, 20)
                if b < a: continue
                g = (-a, F(1), -b)
                if field(A, w, list(g)) == 'M' and field(A, w, list(g), cube=True) != 'M':
                    # partner: same direction shifted along the cube line, outside the strip
                    for kb in range(1, 60):
                        b2 = b + F(kb, 200)
                        a2 = (w[1] - A*b2*w[2])/(A*w[0]) - F(1, 10**6)   # just inside H_cube
                        if a2 <= 0: break
                        g2 = (-a2, F(1), -b2)
                        if field(A, w, list(g2)) != 'M': continue
                        sm = tuple(x+y for x, y in zip(g, g2))
                        if field(A, w, list(sm)) != 'M':
                            found = (g, g2, field(A, w, list(sm))); break
                if found: break
            if found: break
        print(f'  eps={eps} w={tuple(str(x) for x in w)}: certificate {"FOUND" if found else "not found"}'
              + (f': g+={tuple(str(x) for x in found[0])}, g-={tuple(str(x) for x in found[1])}, sum advice {found[2]}' if found else ''))
