"""Referee AA4: independent exact check of the audit's loop field (AUDIT_Z123_loop.md, Sec. 2).
Instead of a grid, compare EXACT crossing points of the field's O-functional d with the posterior's
O-interval endpoints on each of the three legs of L12, for stratified samples that include
D close to 1 (both sides), t or s close to 1/(A+1), and small/large coordinates.
Also: (i) the alternative (ii) of a missing arm: compare with the posterior on the third arm [u,e3]
(expected to FAIL sometimes: the loop field is not posterior there);
(ii) Case II polynomial identity of Sec. 2a."""
from fractions import Fraction as F
from random import Random
rng = Random(20261017)

def dot(a, b): return sum(x*y for x, y in zip(a, b))
U = (F(1, 3),)*3
E = [tuple(F(int(i == k)) for i in range(3)) for k in range(3)]
def lerp(a, b, s): return tuple((1-s)*x + s*y for x, y in zip(a, b))

def post(A, w, h):
    vals = [dot(w, h) + (A-1)*w[i]*h[i] for i in range(3)]
    return 'M' if min(vals) > 0 else ('O' if max(vals) < 0 else 'S')

def build(A, h, odd):
    others = [j for j in range(3) if j != odd]
    D = h[others[0]] + h[others[1]] + (A-1)*max(h[j] for j in others)
    c = list(h); c[odd] *= A
    d = [None]*3; d[odd] = F(1)
    if odd in (0, 1):
        j = 1-odd; k = 2; t = h[j]; s = h[k]
        d[j] = -A*t
        d[k] = -(max(s, A*A*s-(A-1)) if D < 1 else max(s, A*s-(A-1)*t))
        case = 'I<' if D < 1 else 'I>='
    elif D < 1:
        j, k = others
        r = min((1-h[k])/(A*h[j]), (1-A*h[k])/h[j]); z = min((1-h[j])/(A*h[k]), (1-A*h[j])/h[k])
        assert r > 1 and z > 1
        d[j] = -(z-1)/(r*z-1); d[k] = -(r-1)/(r*z-1); case = 'II'
    else:
        for j in others: d[j] = -D/2
        case = 'III'
    return c, d, D, case

def post_O_interval(A, h, P, Q):
    """exact set {s in [0,1]: posterior O at (1-s)P+sQ}: intersection of two half-lines (or empty/all)."""
    lo, hi = F(0), F(1); lo_open = hi_open = False
    o = [i for i in range(3) if h[i] < 0][0]
    for i in range(3):
        if i == o: continue
        f = lambda w: dot(w, h) + (A-1)*w[i]*h[i]   # need f < 0
        a0, a1 = f(P), f(Q)                           # affine: a0 + (a1-a0) s
        if a1 == a0:
            if a0 >= 0: return None
            continue
        root = a0/(a0-a1)
        if a1 > a0:   # increasing: need s < root
            if root <= hi: hi, hi_open = root, True
        else:
            if root >= lo: lo, lo_open = root, True
    if lo > hi or (lo == hi and (lo_open or hi_open)): return None
    return (lo, lo_open, hi, hi_open)

def lin_pos_interval(d, P, Q):
    a0, a1 = dot(d, P), dot(d, Q)
    if a1 == a0: return (F(0), False, F(1), False) if a0 > 0 else None
    root = a0/(a0-a1)
    if a1 > a0:   # pos for s > root
        if root >= 1: return None
        return (max(root, F(0)), root >= 0, F(1), False)
    if root <= 0: return None
    return (F(0), False, min(root, F(1)), root <= 1)

def norm_iv(iv):
    if iv is None: return None
    lo, lo_open, hi, hi_open = iv
    if lo <= 0: lo, lo_open = F(0), (lo == 0 and lo_open)
    if hi >= 1: hi, hi_open = F(1), (hi == 1 and hi_open)
    return (lo, hi)    # endpoints only (openness differs only on null sets)

def sample_h(A, odd, mode):
    others = [j for j in range(3) if j != odd]
    h = [None]*3; h[odd] = F(-1)
    if mode == 'generic':
        for j in others: h[j] = F(rng.randrange(1, 3000), rng.randrange(1, 3000))
    elif mode == 'small':   # likely D<1
        for j in others: h[j] = F(rng.randrange(1, 1000), 1000)/(A+1)
    elif mode == 'D~1':
        t = F(rng.randrange(1, 999), 1000)/(A+1); eps = F(rng.choice([1, -1]), 10**rng.randrange(3, 9))
        # choose s with D = 1+eps, under s <= t or s >= t branch
        j, k = others
        if rng.random() < .5:
            s = (1+eps - A*t)  # if t>=s: D = A t + s
            if not (0 < s <= t): s = (1+eps - t)/A
        else:
            s = (1+eps - t)/A
        if s <= 0: s = F(1, 10**6)
        h[j], h[k] = t, s
        if rng.random() < .5: h[j], h[k] = h[k], h[j]
    elif mode == 'kink':   # coordinate near 1/(A+1)
        b = 1/(A+1)
        for j in others: h[j] = F(rng.randrange(1, 1000), 1000)/(A+1)
        h[rng.choice(others)] = b*(1 + F(rng.choice([1, -1]), 10**rng.randrange(2, 8)))
    return tuple(h)

legs = [(U, E[0]), (U, E[1]), (E[0], E[1])]
third = (U, E[2])
stats = {}; bad = 0; third_mis = 0; tot = 0
for A in [F(1001, 1000), F(11, 10), F(3, 2), F(2), F(7, 2), F(10), F(1000)]:
    for odd in range(3):
        for mode in ['generic', 'small', 'D~1', 'kink']:
            for _ in range(60):
                h = sample_h(A, odd, mode)
                c, d, D, case = build(A, h, odd)
                stats[case] = stats.get(case, 0) + 1
                assert all(c[i]*h[i] > 0 and d[i]*h[i] < 0 for i in range(3))
                for (P, Q) in legs:
                    tot += 1
                    a = norm_iv(post_O_interval(A, h, P, Q)); b = norm_iv(lin_pos_interval(d, P, Q))
                    if a != b:
                        bad += 1
                        if bad < 5: print('MISMATCH', A, h, case, P, Q, a, b)
                    # M part: c.w>0 vs min>0 at the endpoints and a random interior point
                    for s in (F(0), F(1), F(rng.randrange(1, 999), 1000)):
                        w = lerp(P, Q, s)
                        pa = post(A, w, h)
                        assert (dot(c, w) > 0) == (pa == 'M')
                P, Q = third
                a = norm_iv(post_O_interval(A, h, P, Q)); b = norm_iv(lin_pos_interval(d, P, Q))
                third_mis += (a != b)
print('case counts', stats)
print(f'loop legs: {tot} exact interval comparisons, {bad} mismatches')
print(f'third arm [u,e3] (not in L12): {third_mis} of {tot//3} pairs where the loop field is NOT posterior (expected > 0)')

# Sec. 2a, Case II polynomial identity (branch t,s <= 1/(A+1)): A^2 t s (w.d)*(rz-1)/(A^2ts) ...
bad2 = 0
for _ in range(2000):
    A = F(rng.randrange(1001, 5000), 1000)
    t = F(rng.randrange(1, 999), 1000)/(A+1); s = F(rng.randrange(1, 999), 1000)/(A+1)
    if t+s+(A-1)*max(t, s) >= 1: continue
    h = (t, s, F(-1))
    c, d, D, case = build(A, h, 2)
    w = [F(rng.randrange(0, 100)) for _ in range(3)]
    r = (1-s)/(A*t); z = (1-t)/(A*s)
    lhs = dot(w, d)*(r*z-1)*A*A*t*s
    rhs = w[2]*((1-s)*(1-t)-A*A*t*s) - w[0]*A*t*(1-t-A*s) - w[1]*A*s*(1-s-A*t)
    bad2 += (lhs != rhs)
print('Sec 2a Case II polynomial identity failures:', bad2)
