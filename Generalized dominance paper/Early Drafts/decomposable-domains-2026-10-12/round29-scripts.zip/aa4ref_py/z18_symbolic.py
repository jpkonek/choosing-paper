"""Referee AA4: Prop Z1.8 for ALL epsilon.
For a case-A pair with odd world 1 (code 0), h = (-1, t2, t3), the three forced O-S points are
  x2 = (1, r2, 1), x3 = (1, 1, r3)   (homogeneous coordinates on the arms S2, S3)
  z  = (A t2, 1, 0)                  (edge [e1,e2])
with r2 = min((1-t3)/(A t2), (1-A t3)/t2), r3 = min((1-t2)/(A t3), (1-A t2)/t3).
Claim: det[x2; x3; z] = (1 - A t2) - r3 (1 - A t2 r2), and
  on the branch t2, t3 <= 1/(A+1):  det = (A-1)(1-(A+1) t2)/A > 0  (for t2 < 1/(A+1)),
  collinear  <=>  t2 >= 1/(A+1)  (then x2, x3, z all lie on {w1 = A t2 w2 + t3 w3}).
Checked here exactly against z1common's crossings (independent root-finding) and the z1 forced-line test."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'z1py'))
from fractions import Fraction as Fr
import random
from z1common import params, posterior, U, Ocross, seg, majority, rand_pair

def det3(a, b, c):
    return (a[0]*(b[1]*c[2]-b[2]*c[1]) - a[1]*(b[0]*c[2]-b[2]*c[0]) + a[2]*(b[0]*c[1]-b[1]*c[0]))

rr = random.Random(5)
for eps in [Fr(1, 1000), Fr(1, 20), Fr(3, 10), Fr(1, 2), Fr(4, 5), Fr(99, 100)]:
    _, c0, lam, A = params(eps); b = 1/(A+1)
    n = coll = pred_bad = formula_bad = 0
    tries = 0
    while n < 150 and tries < 200000:
        tries += 1
        # stratified: half from the small branch, half generic
        if rr.random() < .5:
            t2 = Fr(rr.randrange(1, 1000), 1000)*b; t3 = Fr(rr.randrange(1, 1000), 1000)*b
            h = (Fr(-1), t2, t3)
        else:
            h, o = majority(rand_pair(rr))
            if o != 0: continue
            h = tuple(x/(-h[0]) for x in h)
        if posterior(eps, U, h)[0] != 'O': continue
        n += 1
        t2, t3 = h[1], h[2]
        s2 = Ocross(eps, 1, h); s3 = Ocross(eps, 2, h)
        assert len(s2) == 1 and len(s3) == 1
        x2 = seg(1, s2[0]); x3 = seg(2, s3[0]); z = (A*t2, Fr(1), Fr(0))
        dt = det3(x2, x3, z)
        r2 = min((1-t3)/(A*t2), (1-A*t3)/t2); r3 = min((1-t2)/(A*t3), (1-A*t2)/t3)
        dform = (1-A*t2) - r3*(1-A*t2*r2)
        # sign/zero agreement between independent det and formula (they differ by positive scaling)
        if (dt == 0) != (dform == 0) or (dt > 0) != (dform > 0) and dt != 0:
            formula_bad += 1
        if t2 <= b and t3 <= b and dform != (A-1)*(1-(A+1)*t2)/A: formula_bad += 1
        coll += (dt == 0)
        pred_bad += ((dt == 0) != (t2 >= b))
    print(f'eps={eps}: {n} case-A pairs (odd world 1): collinear {coll}; '
          f'classification "collinear iff t2>=1/(A+1)" failures {pred_bad}; formula failures {formula_bad}')
