# AA1: illustrations for Theorem AA1.2 (retained primaries on an edge).
# (1) CHECKED (exact): every edge credal model K=[a,b] subset of [e1,e2] with K != {e1}
#     errs at world 1 on gambles h with h1>0>h2 and h1/|h2| < eta, eta = (1-b)/b... we check
#     the elementary inequality on exact rational samples.
# (2) NUMERICS: f(t)=F(C_t) along the posterior edge family nu(q*T1) on [e1,e2], for a
#     world-1 primary F blind on the wedge W={0<h1<eta|h2|}; f is continuous, f(0)=0<f(1)=P,
#     so the hypotheses of AA1.2 hold and (Imp) holds automatically (edge models err on W).
from fractions import Fraction as Fr
import random, math
random.seed(1)
# (1) exact
bad=0; n=0
for _ in range(4000):
    b=Fr(random.randint(1,999),1000)          # upper end of K's world-2 mass: K=[ (1-b,b) .. ]
    eta=b/(1-b) if b<1 else Fr(10**6)
    x=Fr(random.randint(1,999),1000)*eta       # h1/|h2| = x < eta
    h1,h2=x,Fr(-1)
    # P_K(h) = min over m in K of m1 h1 + m2 h2 <= (1-b) h1 + b h2
    val=(1-b)*h1+b*h2
    n+=1
    if not val<0: bad+=1
print("(1) exact samples",n,"edge models accepting a wedge gamble:",bad)
# (2) numerics
eps=0.3; c0=(1-eps)/3; lam=eps/c0
V=[[c0*(1+lam*(k==j)) for j in range(3)] for k in range(3)]
def edge_K(t):
    q=(1-t,t,0.0)
    pts=[]
    for v in V:
        w=[q[j]*v[j] for j in range(3)]; s=sum(w)
        pts.append((w[0]/s,w[1]/s))
    return pts
def advice(K,h):
    lo=min(m[0]*h[0]+m[1]*h[1] for m in K); hi=max(m[0]*h[0]+m[1]*h[1] for m in K)
    if lo>0: return 'M'
    if hi<0: return 'O'
    return 'S'
eta=0.5
H=[(random.gauss(0,1),random.gauss(0,1)) for _ in range(40000)]
def F(t):
    if t==0: K=[(1.0,0.0)]
    elif t==1: K=[(0.0,1.0)]
    else: K=edge_K(t)
    tot=0.0
    for h in H:
        h1,h2=h
        if (h1>0)==(h2>0): continue
        # world-1 ladder rank: good 0, silence 1, bad 2
        a=advice(K,h)
        good='M' if h1>0 else 'O'
        r=0 if a==good else (1 if a=='S' else 2)
        blind = (h1>0>h2 and h1<eta*(-h2)) or (h2>0>h1 and -h1<eta*h2)
        if not blind: tot+=r
    return tot/len(H)
for t in [0,0.01,0.05,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95,0.99,1]:
    print("(2) t=%.2f  F(C_t)=%.4f"%(t,F(t)))
