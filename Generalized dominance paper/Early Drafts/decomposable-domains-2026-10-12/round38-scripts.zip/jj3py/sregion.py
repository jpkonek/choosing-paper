# CHECK of Lemma 3.1 (shape of the silence region of a pair) on random exact instances.
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
random.seed(20261018)
perms = list(itertools.permutations(range(3)))
stats = {}
fail = 0
for trial in range(6000):
    j, l, o = random.choice(perms)
    zeros = random.choice([(), (j,), (l,), (o,), (j, l), (j, o), (l, o), (j, l, o)])
    phi = make_pair(j, l, o, set(zeros))
    c  = tuple(phi[i]['S'] - phi[i]['M'] for i in range(3))   # S - M
    cp = tuple(phi[i]['S'] - phi[i]['O'] for i in range(3))   # S - O
    # S weakly beats M iff c.w <= 0 ; S weakly beats O iff cp.w <= 0 ; X never competes
    R = clip(clip(simplex(), c), cp)
    key = (tuple(sorted(zeros, key=lambda z: (z != o, z))), )
    kind = 'o' if o in zeros else ('jl' if (j in zeros and l in zeros) else ('single' if zeros else 'none'))
    if kind in ('o', 'jl'):
        ok = (len(R) == 0)
        stats.setdefault(kind, [0, 0]); stats[kind][0] += 1; stats[kind][1] += ok
        if not ok: fail += 1
        continue
    if kind == 'single':
        z = zeros[0]  # the positive world carrying the zero; the other positive world:
        other = l if z == j else j
        A = area2(R) if len(R) >= 3 else F(0)
        if A > 0:
            # triangle, two vertices on the edge w_z = 0, third interior, and e_z, t, s collinear
            ok = len(R) == 3
            onedge = [p for p in R if p[z] == 0]
            inner = [p for p in R if p[z] != 0]
            ok = ok and len(onedge) == 2 and len(inner) == 1
            if ok:
                t = inner[0]
                ez = tuple(F(int(i == z)) for i in range(3))
                # s = the edge vertex lying on {cp.w = 0}; m = the one on {c.w = 0}
                s = [p for p in onedge if dot(cp, p) == 0]
                m = [p for p in onedge if dot(c, p) == 0]
                ok = ok and len(s) == 1 and len(m) == 1 and dot(cp, t) == 0 and dot(c, t) == 0
                if ok:
                    # collinearity of e_z, t, s[0] in aff(simplex): cp vanishes at all three
                    ok = ok and dot(cp, ez) == 0 and dot(cp, s[0]) == 0
                    # t interior, s on the open edge between e_other and e_o, m strictly closer to e_other
                    ok = ok and all(x > 0 for x in t) and s[0][other] > 0 and s[0][o] > 0
                    ok = ok and m[0][o] < s[0][o]
            stats.setdefault('single_essential', [0, 0]); stats['single_essential'][0] += 1
            stats['single_essential'][1] += ok
            if not ok: fail += 1
        else:
            ok = all(p[z] == 0 for p in R)   # any weak S-points lie on the edge w_z = 0
            stats.setdefault('single_nonessential', [0, 0]); stats['single_nonessential'][0] += 1
            stats['single_nonessential'][1] += ok
            if not ok: fail += 1
    else:
        A = area2(R) if len(R) >= 3 else F(0)
        stats.setdefault('none', [0, 0]); stats['none'][0] += 1; stats['none'][1] += 1
        if A > 0:
            stats.setdefault('none_with_S_area', 0); stats['none_with_S_area'] += 1
            # control: in the strictly signed case the S/O line does not pass through e_j or e_l
            if dot(cp, tuple(F(int(i == j)) for i in range(3))) == 0: fail += 1
for k, v in sorted(stats.items()):
    print(k, v)
print('failures', fail)
