# Exact helpers (fractions only). Weights w in the closed simplex of R^3.
from fractions import Fraction as F
import random, itertools

ADV = ['M', 'S', 'O', 'X']   # accept majority h, silence, accept -h, both

def dot(a, b):
    return sum(x*y for x, y in zip(a, b))

def simplex():
    return [(F(1),F(0),F(0)), (F(0),F(1),F(0)), (F(0),F(0),F(1))]

def clip(poly, a):
    """Clip a convex polygon (list of points, in order) to {w : a.w <= 0}."""
    out = []
    n = len(poly)
    for k in range(n):
        P, Q = poly[k], poly[(k+1) % n]
        fP, fQ = dot(a, P), dot(a, Q)
        if fP <= 0:
            out.append(P)
        if (fP < 0 < fQ) or (fQ < 0 < fP):
            t = fP / (fP - fQ)
            out.append(tuple(P[i] + t*(Q[i]-P[i]) for i in range(3)))
    # remove duplicates while keeping order
    res = []
    for p in out:
        if not res or res[-1] != p:
            res.append(p)
    if len(res) > 1 and res[0] == res[-1]:
        res.pop()
    return res

def area2(poly):
    """Twice the area of a polygon in aff(simplex), via coordinates (w1,w2)."""
    s = F(0)
    n = len(poly)
    for k in range(n):
        x1, y1 = poly[k][0], poly[k][1]
        x2, y2 = poly[(k+1) % n][0], poly[(k+1) % n][1]
        s += x1*y2 - x2*y1
    return abs(s)

def rnd(lo=1, hi=9, den=7):
    return F(random.randint(lo, hi*den), den)

def make_pair(j, l, o, zeros):
    """Penalties phi[i][a] for a pair with majority orientation h, h_j,h_l>0>h_o,
    weakly guiding, strict-best, x strictly worst, zeros only bad~silence as listed
    (subset of {j,l,o}). Positive world i in {j,l}: M < S <= O < X (zero: S=O).
    Odd world o: O < S <= M < X (zero: S=M)."""
    phi = [dict() for _ in range(3)]
    for i in (j, l):
        m = rnd(0, 3); s = m + rnd(); o_ = s if i in zeros else s + rnd()
        phi[i] = {'M': m, 'S': s, 'O': o_, 'X': o_ + rnd()}
    i = o
    oo = rnd(0, 3); s = oo + rnd(); mm = s if o in zeros else s + rnd()
    phi[i] = {'O': oo, 'S': s, 'M': mm, 'X': mm + rnd()}
    return phi

def fvec(phi, a):
    return tuple(phi[i][a] for i in range(3))

def argmin_set(phi, w):
    vals = {a: dot(w, fvec(phi, a)) for a in ADV}
    mn = min(vals.values())
    return frozenset(a for a in ADV if vals[a] == mn)

def grid(den):
    pts = []
    for a in range(den+1):
        for b in range(den+1-a):
            pts.append((F(a, den), F(b, den), F(den-a-b, den)))
    return pts
