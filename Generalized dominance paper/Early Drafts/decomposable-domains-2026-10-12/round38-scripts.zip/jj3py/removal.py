# CHECK of Lemma 3.2 (removal of non-essential zeros without changing any argmin set on the closed simplex).
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
random.seed(7)
perms = list(itertools.permutations(range(3)))

def cells(phi):
    """Vertices of the two cells of the closed simplex on which G = min(f_M,f_O) - f_S is linear."""
    dmo = tuple(phi[i]['M'] - phi[i]['O'] for i in range(3))
    A = clip(simplex(), dmo)                      # f_M <= f_O
    B = clip(simplex(), tuple(-x for x in dmo))   # f_O <= f_M
    return A + B

def G(phi, w):
    fM, fS, fO = (dot(w, fvec(phi, a)) for a in 'MSO')
    return min(fM, fO) - fS

def removable_delta(phi, worlds):
    """Largest-safe delta (halved) such that G + 2*delta*sum_{i in worlds} w_i <= 0 at every cell vertex
    with sum w_i > 0, also below half of every strict-order gap touched."""
    cand = []
    for v in cells(phi):
        sw = sum(v[i] for i in worlds)
        g = G(phi, v)
        if sw > 0:
            if g >= 0:
                return None
            cand.append(-g / (2*sw))
    for i in worlds:
        best = min(phi[i][a] for a in 'MO')   # the world-i best of M,O is strictly below S
        cand.append((phi[i]['S'] - best) / 2)
    return min(cand) / 2

def lower(phi, worlds, d):
    new = [dict(p) for p in phi]
    for i in worlds:
        new[i]['S'] = new[i]['S'] - d
    return new

def strictly_guiding(phi, j, l, o):
    okp = all(phi[i]['M'] < phi[i]['S'] < phi[i]['O'] < phi[i]['X'] for i in (j, l))
    return okp and phi[o]['O'] < phi[o]['S'] < phi[o]['M'] < phi[o]['X']

pts = grid(24)
tested = {}
fail = 0
for trial in range(3000):
    j, l, o = random.choice(perms)
    zeros = random.choice([(j,), (l,), (o,), (j, l), (j, o), (l, o), (j, l, o)])
    phi = make_pair(j, l, o, set(zeros))
    c  = tuple(phi[i]['S'] - phi[i]['M'] for i in range(3))
    cp = tuple(phi[i]['S'] - phi[i]['O'] for i in range(3))
    R = clip(clip(simplex(), c), cp)
    essential = len(R) >= 3 and area2(R) > 0
    if essential:
        tested.setdefault('essential (skipped; must be a single positive-world zero)', [0, 0])
        rec = tested['essential (skipped; must be a single positive-world zero)']
        rec[0] += 1; rec[1] += (len(zeros) == 1 and zeros[0] != o)
        if not (len(zeros) == 1 and zeros[0] != o): fail += 1
        continue
    d = removable_delta(phi, zeros)
    key = 'removable pattern size %d%s' % (len(zeros), ' with odd zero' if o in zeros else '')
    tested.setdefault(key, [0, 0]); tested[key][0] += 1
    if d is None or d <= 0:
        fail += 1; continue
    new = lower(phi, zeros, d)
    ok = strictly_guiding(new, j, l, o)
    for w in pts + cells(phi):
        if argmin_set(phi, w) != argmin_set(new, w):
            ok = False; break
    tested[key][1] += ok
    if not ok: fail += 1
for k, v in sorted(tested.items()):
    print(k, v)
print('grid points per instance', len(pts), '(denominator 24, boundary included) plus all cell vertices')
print('failures', fail)
