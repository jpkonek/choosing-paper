# CHECK of the algebra of Lemma 4.3 (Steps E-F): two facts about a credal polytope K = co(points).
# Coordinates (j,l,o) = (0,1,2). hbar(rho) = (rho, pi, -(1-pi)), y(a) = (a, -pi, 1-pi), P = (0, 1-pi, pi).
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
random.seed(11)

def rpoint(den=40):
    a = random.randint(0, den); b = random.randint(0, den - a)
    return (F(a, den), F(b, den), F(den - a - b, den))

fail = 0; n1 = n2 = n3 = 0
for trial in range(4000):
    pi = F(random.randint(1, 19), 20)
    r1 = F(random.randint(1, 30), 10); r2 = r1 + F(random.randint(1, 30), 10)
    h1 = (r1, pi, -(1 - pi)); h2 = (r2, pi, -(1 - pi)); P = (F(0), 1 - pi, pi)
    # (i) K = co(P, points with m.h2 <= 0): then max_K m.h1 = max_K m.h2 = 0 and min_K m.y(a) = 0 for all a > 0
    pts = [P]
    while len(pts) < 5:
        m = rpoint()
        if dot(m, h2) <= 0:
            pts.append(m)
    ok = max(dot(m, h1) for m in pts) == 0 and max(dot(m, h2) for m in pts) == 0
    for a in (F(1, 100), F(1), F(7, 2), F(50)):
        y = (a, -pi, 1 - pi)
        ok = ok and min(dot(m, y) for m in pts) == 0
        # the bound m.y(a) >= m_j (a + rho) whenever m.hbar(rho) <= 0
        ok = ok and all(dot(m, y) >= m[0] * (a + r1) for m in pts if dot(m, h1) <= 0)
    n1 += 1; fail += (not ok)
    # (ii) control: if K misses the edge {m_j = 0}, then max_K m.h1 = 0 forces max_K m.h2 > 0 (convex slope argument)
    pts = []
    while len(pts) < 5:
        m = rpoint()
        if m[0] > 0:
            pts.append(m)
    mx = max(dot(m, h1) for m in pts)
    # shift: impose max m.h1 = 0 by adding the vector needed to the l,o part is not linear in K; instead test the claim
    # f(r2) - f(r1) >= (r2 - r1) * min{ m_j : m in argmax at r1 } > 0
    arg = [m for m in pts if dot(m, h1) == mx]
    ok2 = max(dot(m, h2) for m in pts) - mx >= (r2 - r1) * min(m[0] for m in arg) > 0
    n2 += 1; fail += (not ok2)
    # (iii) P . y(a) = 0 and P . hbar(rho) = 0 identically
    ok3 = dot(P, (F(3), -pi, 1 - pi)) == 0 and dot(P, h1) == 0 and dot(P, h2) == 0
    n3 += 1; fail += (not ok3)
print('(i) polytopes through P inside {m.h2<=0}:', n1, ' (ii) edge-free controls:', n2, ' (iii) identities:', n3)
print('failures', fail)
