# CHECK of Lemma 4.4 inputs: T1 accepts y(a; pi0) = (a, -pi0, 1-pi0) (coordinates j,l,o) whenever a > 1 + eps/c0,
# for every placement of (j,l,o); and the two Jacobians used for the measure statements (symbolic).
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
import itertools, sympy as sp
fail = 0; n = 0
for eps in [F(1, 100), F(1, 20), F(3, 10), F(1, 2), F(9, 10), F(99, 100)]:
    c0 = (1 - eps) / 3
    A0 = 1 + eps / c0
    V = [tuple(c0 + (eps if i == k else 0) for i in range(3)) for k in range(3)]
    for (j, l, o) in itertools.permutations(range(3)):
        for p in range(1, 40):
            pi0 = F(p, 40)
            for a in [A0 + F(1, 10**6), A0 + F(1, 3), 2 * A0, 10 * A0]:
                y = [F(0)] * 3; y[j] = a; y[l] = -pi0; y[o] = 1 - pi0
                P = min(sum(v[i] * y[i] for i in range(3)) for v in V)
                n += 1
                if not P > 0: fail += 1
print('T1-acceptance cases', n, 'failures', fail)
pi, rho, lam, a = sp.symbols('pi rho lam a', positive=True)
h = sp.Matrix([lam * rho, lam * pi, -lam * (1 - pi)])
J1 = sp.simplify(h.jacobian([pi, rho, lam]).det())
y = sp.Matrix([lam * a, -lam * pi, lam * (1 - pi)])
J2 = sp.simplify(y.jacobian([pi, a, lam]).det())
print('det d h/d(pi,rho,lam) =', J1, ';  det d y/d(pi,a,lam) =', J2)
