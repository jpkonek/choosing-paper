# JJ1 exact checks (fractions only). Run: python3 -I checks.py  (inside jj1py/)
# (1) Rate-world algebra of HH2 Prop 6.1(a)-(c) on random rational record values.
# (2) The dyadic majorant of AUDIT_HH_rate and the averaged majorant k(m)=(2/m)int_{m/2}^m g
#     for a nonincreasing step bound g, checked at many rational points.
# (3) A planar instance showing (NT) does not imply a unique Bayes weight (segment K).
from fractions import Fraction as F
import random
random.seed(20261018)

def k_rate(m):            # a sample continuous positive rate, k(m) = 1 + 1/m
    return 1 + 1/m

def acc(phi, psi, m, ident=False):
    if ident: return True
    return phi >= 0 and psi + k_rate(m)*phi >= 0

def lex(phi, psi):
    return phi > 0 or (phi == 0 and psi >= 0)

bad = 0; N = 0
vals = [F(n, d) for n in range(-6, 7) for d in (1, 2, 3, 7)] + [F(0)]
for _ in range(200000):
    phi = random.choice(vals); psi = random.choice(vals); m = F(random.randint(1, 50), 100)
    N += 1
    a, ai = acc(phi, psi, m), acc(-phi, -psi, m)
    if a and not lex(phi, psi): bad += 1                     # A^k subset of L
    if a and not ai and lex(-phi, -psi): bad += 1             # strict in A^k => strict in L
    if (a and ai) != (phi == 0 and psi == 0): bad += 1        # ties = lex ties
    if phi >= 0 and psi > 0 and not (a and not ai): bad += 1  # worsening: accepted and strict
print("(1) rate-world algebra: records tested", N, "failures", bad)

# (2) g nonincreasing on (0, M], M = 1/2: a step function with jumps (finite everywhere).
M = F(1, 2)
def g(a):                 # bound sup{r : size >= a}; nonincreasing, discontinuous
    n = 0
    while a <= M / 2**(n+1): n += 1
    return F(n*n + 3) + (1 if a < F(1, 7) else 0)
# dyadic construction: beta_n >= g(M/2^{n+1}) + n + 1, nondecreasing; linear interpolation
beta = []
for n in range(40):
    b = g(M / 2**(n+1)) + n + 1
    if beta and b < beta[-1]: b = beta[-1]
    beta.append(b)
def k_dyadic(m):
    n = 0
    while m <= M / 2**(n+1): n += 1
    lo, hi = M / 2**(n+1), M / 2**n
    t = (m - lo) / (hi - lo)
    return beta[n+1]*(1 - t) + beta[n]*t
fail = 0; T = 0
for d in range(3, 4000):
    for num in (1, 2, 3, 5):
        m = F(num, d)
        if 0 < m <= M and m > M / 2**38:
            T += 1
            if k_dyadic(m) < g(m): fail += 1
print("(2a) dyadic majorant: points", T, "failures", fail)
# averaged majorant of a nonincreasing g: (2/m) * int_{m/2}^{m} g >= g(m); integral of step fn exact
def breakpoints(lo, hi):
    pts = {lo, hi}
    n = 0
    while M / 2**n > lo / 4 and n < 60:
        x = M / 2**n
        if lo < x < hi: pts.add(x)
        n += 1
    if lo < F(1, 7) < hi: pts.add(F(1, 7))
    return sorted(pts)
def integral_g(lo, hi):
    s = F(0); p = breakpoints(lo, hi)
    for x, y in zip(p, p[1:]):
        s += g((x + y) / 2) * (y - x)   # g constant on (x, y]; value at midpoint = value on interval
    return s
fail = 0; T = 0
for d in range(3, 600):
    m = F(1, d)
    T += 1
    if (2/m) * integral_g(m/2, m) < g(m): fail += 1
print("(2b) averaged majorant: points", T, "failures", fail)

# (3) K = segment from (1,-1) to (-1,1) in R^2 (two active worlds). K meets the closed
# nonpositive quadrant only at 0, but every supporting weight w in the simplex has face K.
pts = [(F(1), F(-1)), (F(-1), F(1))]
seg = [(t*pts[0][0] + (1-t)*pts[1][0], t*pts[0][1] + (1-t)*pts[1][1]) for t in [F(i, 200) for i in range(201)]]
meet = [z for z in seg if z[0] <= 0 and z[1] <= 0]
sup_w = [F(i, 100) for i in range(101) if all(F(i,100)*z[0] + (1-F(i,100))*z[1] >= 0 for z in seg)]
print("(3) segment K: points of K in closed nonpositive quadrant:", meet,
      "; supporting weights w1:", sup_w, "; face at w1=1/2 is all of K:",
      all(F(1,2)*z[0] + F(1,2)*z[1] == 0 for z in seg))
