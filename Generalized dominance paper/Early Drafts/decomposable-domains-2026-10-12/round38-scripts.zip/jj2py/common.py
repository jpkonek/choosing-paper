"""Common exact-arithmetic helpers for JJ2 (fractions.Fraction only)."""
from fractions import Fraction as F
import itertools
import random

E = [(F(1), F(0), F(0)), (F(0), F(1), F(0)), (F(0), F(0), F(1))]
ONE = (F(1), F(1), F(1))


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def sub(a, b):
    return tuple(x - y for x, y in zip(a, b))


def add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def scal(t, a):
    return tuple(t * x for x in a)


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def in_simplex(q):
    return all(x >= 0 for x in q) and sum(q) == 1


def line_meet(n1, n2):
    """Point of aff(Delta) on both lines {q.n1=0}, {q.n2=0}; None if parallel/coincident in aff(Delta)."""
    x = cross(n1, n2)
    s = sum(x)
    if s == 0:
        return None
    return tuple(c / s for c in x)


def argmin_set(phi, alpha):
    """phi: dict advice -> penalty vector. Returns the set of weak minimisers of alpha.phi(.)."""
    vals = {a: dot(alpha, phi[a]) for a in phi}
    m = min(vals.values())
    return frozenset(a for a in vals if vals[a] == m)


def arrangement_points(lines):
    """Complete test-point set for comparing piecewise-constant functions on the closed simplex
    whose pieces are the faces of the arrangement cut by `lines` (coefficient vectors n, line {q.n=0}).
    Returns the arrangement vertices, all midpoints of pairs of vertices and all centroids of triples.
    Every open face (a convex polygon with >= 3 vertices in the vertex set) contains the centroid of
    three of its vertices; every open edge contains the midpoint of its endpoints."""
    all_lines = list(lines) + [E[0], E[1], E[2]]  # the edges {q_k = 0}
    V = set()
    for n1, n2 in itertools.combinations(all_lines, 2):
        p = line_meet(n1, n2)
        if p is not None and in_simplex(p):
            V.add(p)
    V = sorted(V)
    pts = set(V)
    for a, b in itertools.combinations(V, 2):
        pts.add(tuple((x + y) / 2 for x, y in zip(a, b)))
    for a, b, c in itertools.combinations(V, 3):
        pts.add(tuple((x + y + z) / 3 for x, y, z in zip(a, b, c)))
    return V, sorted(pts)


def rnd(lo, hi, den=60):
    """Random rational in (lo, hi) with denominator den (lo, hi integers or Fractions)."""
    lo, hi = F(lo), F(hi)
    k = random.randint(1, den - 1)
    return lo + (hi - lo) * F(k, den)


def pair_field(o, zeros, rng=random):
    """Random strict-best weakly guiding penalties on one mixed pair with majority orientation h
    (odd world o, positive worlds j,l). zeros: subset of {'o','j','l'}:
      'o' : c_o = 0   (phi_o(S) = phi_o(M), M = accept h, bad at o)
      'j' : c'_j = 0  (phi_j(S) = phi_j(O), O = accept -h, bad at j), likewise 'l'.
    Returns (j, l, c, cp, phi) with phi[S] = 0, phi[M] = -c, phi[O] = -cp."""
    j, l = [k for k in range(3) if k != o]
    c = [F(0)] * 3
    cp = [F(0)] * 3
    c[j] = rnd(0, 3)
    c[l] = rnd(0, 3)
    c[o] = F(0) if 'o' in zeros else -rnd(0, 3)
    cp[o] = rnd(0, 3)
    cp[j] = F(0) if 'j' in zeros else -rnd(0, 3)
    cp[l] = F(0) if 'l' in zeros else -rnd(0, 3)
    c, cp = tuple(c), tuple(cp)
    phi = {'S': (F(0), F(0), F(0)), 'M': scal(-1, c), 'O': scal(-1, cp)}
    return j, l, c, cp, phi


def phi_from(c, cp):
    return {'S': (F(0), F(0), F(0)), 'M': scal(-1, c), 'O': scal(-1, cp)}


def segment_in_simplex(n):
    """Endpoints of {q.n = 0} cut with the closed simplex (list of distinct points)."""
    pts = set()
    for k in range(3):
        p = line_meet(n, E[k])
        if p is not None and in_simplex(p):
            pts.add(p)
    return sorted(pts)
