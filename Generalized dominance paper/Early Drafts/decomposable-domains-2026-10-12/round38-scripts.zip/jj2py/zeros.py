"""JJ2 §3-§5 checks on single pairs (exact rational arithmetic).

Notation: a mixed pair is indexed by its majority orientation h (odd world o, positive worlds j,l).
Advices M = accept h, S = silence, O = accept -h.  c = phi(S)-phi(M), cp = phi(S)-phi(O), d = c-cp.
For an oriented gamble g in {h,-h}: c^g = c (g=h) or cp (g=-h); acc g = 'M' or 'O'.
A zero at world i for acceptance of g means g_i < 0 and c^g_i = 0.

Part A  (Lemma 3.3): on the open edge (e_i,e_m), m a positive world of g, silence is never a weak
        minimiser; the d-line meets the open edge at P_d, where exactly acc g and acc -g tie and beat S.
Part B  (Def. 5.1 / Lemma 5.2): activity. A zero is ACTIVE iff I(g) = {a in Delta : a.c^g = 0 > a.c^{-g}}
        is non-empty.  Odd and double zeros are never active; a single zero is active iff silence is the
        unique minimiser at some interior weight; I(g) is then a non-degenerate segment on a line through e_i.
Part C  (Prop. 5.3): every inactive zero is removed by the rotation  c^g -> c^g - t c^{-g},
        c^{-g} -> (1-t) c^{-g}  (d fixed), for small t>0, with the weak-minimiser correspondence unchanged
        on the CLOSED simplex; verified exactly on the complete arrangement test set.
Part D  (Prop. 5.4): an active zero survives every such rotation (exact witness point in I(g)).
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import random
from fractions import Fraction as F
from common import (E, dot, sub, scal, line_meet, in_simplex, argmin_set, arrangement_points,
                    pair_field, phi_from, segment_in_simplex, rnd)

random.seed(20261018)


def orient(c, cp, g_is_h):
    return (c, cp, 'M', 'O') if g_is_h else (cp, c, 'O', 'M')


def zeros_of(o, j, l, c, cp):
    """list of (g_is_h, world) zeros."""
    out = []
    if c[o] == 0:
        out.append((True, o))
    for k in (j, l):
        if cp[k] == 0:
            out.append((False, k))
    return out


def gamble_sign(o, g_is_h, k):
    # sign of h_k is + at j,l and - at o; g = h or -h
    s = -1 if k == o else 1
    return s if g_is_h else -s


def active(cg, cmg):
    seg = segment_in_simplex(cg)
    return any(dot(p, cmg) < 0 for p in seg), seg


def strictly_guiding(o, c, cp):
    j, l = [k for k in range(3) if k != o]
    return c[j] > 0 and c[l] > 0 and c[o] < 0 and cp[o] > 0 and cp[j] < 0 and cp[l] < 0


def same_correspondence(phi1, phi2, lines):
    V, pts = arrangement_points(lines)
    for q in pts:
        if argmin_set(phi1, q) != argmin_set(phi2, q):
            return False, q
    return True, None


def rotate(c, cp, g_is_h, t):
    cg, cmg, _, _ = orient(c, cp, g_is_h)
    cg2 = sub(cg, scal(t, cmg))
    cmg2 = scal(1 - t, cmg)
    return (cg2, cmg2) if g_is_h else (cmg2, cg2)


patterns = [{'o'}, {'j'}, {'l'}, {'j', 'l'}, {'o', 'j'}, {'o', 'l'}, {'o', 'j', 'l'}]
stats = dict(A_checked=0, A_fail=0, B_odd_double_active=0, B_single=0, B_single_active=0,
             B_mismatch=0, B_seg_fail=0, C_removed=0, C_fail=0, C_min_t=F(1), D_active=0, D_removed=0,
             borderline=0, borderline_removed=0)

N = 1500
instances = []
for it in range(N):
    o = random.randrange(3)
    z = random.choice(patterns)
    j, l, c, cp, phi = pair_field(o, z)
    instances.append((o, j, l, c, cp, False))
# deliberately borderline instances: single zero at j with concurrency point on the open edge (e_l,e_o)
for it in range(200):
    o = random.randrange(3)
    j, l, c, cp, phi = pair_field(o, {'j'})
    cp = list(cp)
    cp[l] = -cp[o] * c[l] / (-c[o])
    instances.append((o, j, l, c, tuple(cp), True))

for (o, j, l, c, cp, border) in instances:
    phi = phi_from(c, cp)
    d = sub(c, cp)
    zs = zeros_of(o, j, l, c, cp)
    # ---------- Part A ----------
    for (g_is_h, i) in zs:
        cg, cmg, accg, accmg = orient(c, cp, g_is_h)
        dg = sub(cg, cmg)
        for m in range(3):
            if m == i or gamble_sign(o, g_is_h, m) < 0:
                continue
            stats['A_checked'] += 1
            ok = True
            # c^g on the open edge (e_i, e_m): c^g_i = 0, c^g_m > 0
            ok &= (cg[i] == 0 and cg[m] > 0)
            # d-line point on the edge
            k = 3 - i - m
            Pd = line_meet(dg, E[k])
            ok &= Pd is not None and in_simplex(Pd) and Pd[i] > 0 and Pd[m] > 0
            if ok:
                ok &= argmin_set(phi, Pd) == frozenset({accg, accmg})
                for t in (F(1, 7), F(1, 2), F(5, 6)):
                    a = tuple((1 - t) * x + t * y for x, y in zip(E[m], Pd))   # between e_m and Pd
                    b = tuple((1 - t) * x + t * y for x, y in zip(Pd, E[i]))   # between Pd and e_i
                    ok &= argmin_set(phi, a) == frozenset({accg})
                    ok &= argmin_set(phi, b) == frozenset({accmg})
            if not ok:
                stats['A_fail'] += 1
    # ---------- Part B ----------
    S_interior_unique = False
    V, pts = arrangement_points([c, cp, d])
    for q in pts:
        if all(x > 0 for x in q) and argmin_set(phi, q) == frozenset({'S'}):
            S_interior_unique = True
            break
    single = (len(zs) == 1 and not zs[0][0])
    acts = []
    for (g_is_h, i) in zs:
        cg, cmg, _, _ = orient(c, cp, g_is_h)
        a, seg = active(cg, cmg)
        acts.append((g_is_h, i, a, seg))
        if a and not single:
            stats['B_odd_double_active'] += 1
    if single:
        stats['B_single'] += 1
        a = acts[0][2]
        if a:
            stats['B_single_active'] += 1
        if a != S_interior_unique:
            stats['B_mismatch'] += 1
        if a:
            g_is_h, i, _, seg = acts[0]
            cg, cmg, _, _ = orient(c, cp, g_is_h)
            # I(g) is the part of seg where cmg < 0: a non-degenerate interior segment on a line through e_i
            p0, p1 = seg
            ok = dot(E[i], cg) == 0
            f0, f1 = dot(p0, cmg), dot(p1, cmg)
            # pick two distinct interior points of I(g)
            pts_I = []
            for s in (F(1, 3), F(2, 3)):
                # parametrise the sub-segment where cmg<0
                if f0 < 0 and f1 < 0:
                    a0, a1 = p0, p1
                else:
                    t0 = f0 / (f0 - f1)
                    X = tuple((1 - t0) * x + t0 * y for x, y in zip(p0, p1))
                    a0, a1 = (X, p1) if f1 < 0 else (p0, X)
                pts_I.append(tuple((1 - s) * x + s * y for x, y in zip(a0, a1)))
            for q in pts_I:
                ok &= all(x > 0 for x in q) and dot(q, cg) == 0 and dot(q, cmg) < 0
                ok &= argmin_set(phi, q) == frozenset({'S', 'M' if g_is_h else 'O'})
            ok &= pts_I[0] != pts_I[1]
            if not ok:
                stats['B_seg_fail'] += 1
    if border:
        stats['borderline'] += 1
    # ---------- Parts C, D ----------
    any_active = any(a for (_, _, a, _) in acts)
    if not zs:
        continue
    if any_active:
        stats['D_active'] += 1
        g_is_h, i = [(gh, ii) for (gh, ii, a, _) in acts if a][0]
        removed = False
        for e in range(1, 21):
            t = F(1, 2 ** e)
            c2, cp2 = rotate(c, cp, g_is_h, t)
            ok, _ = same_correspondence(phi, phi_from(c2, cp2), [c, cp, d, c2, cp2, sub(c2, cp2)])
            if ok:
                removed = True
                break
        if removed:
            stats['D_removed'] += 1
        continue
    # all zeros inactive: rotate each orientation that carries a zero
    done = False
    for e in range(1, 25):
        t = F(1, 2 ** e)
        c2, cp2 = c, cp
        for g_is_h in sorted({gh for (gh, _, _, _) in acts}, reverse=True):
            c2, cp2 = rotate(c2, cp2, g_is_h, t)
        if not strictly_guiding(o, c2, cp2):
            continue
        ok, _ = same_correspondence(phi, phi_from(c2, cp2), [c, cp, d, c2, cp2, sub(c2, cp2)])
        if ok:
            done = True
            stats['C_removed'] += 1
            stats['C_min_t'] = min(stats['C_min_t'], t)
            if border:
                stats['borderline_removed'] += 1
            break
    if not done:
        stats['C_fail'] += 1

for k, v in stats.items():
    print(k, '=', v)
