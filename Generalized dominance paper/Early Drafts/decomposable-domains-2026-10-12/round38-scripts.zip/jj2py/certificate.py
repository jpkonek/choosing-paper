"""JJ2 §2-§3 checks (exact).

(1) Lemma 2.1 sanity: on random finite cell models, a base model that is the strict pointwise w-minimiser,
    with supp w contained in J (vertices, edges and interior weights all tested), admits no non-trivial record
    (pure or relaxed) with Phi_i <= 0 at every i in J.
(2) Lemma 2.2: the certificate is not necessary in the abstract cell setting: Example A has ties at w = u and
    still satisfies (NT) (and is a strict w'-minimiser at a nearby interior w'); Example B has opposed ties and fails
    (NT) through an exact record with Phi = 0.
(3) Lemma 3.1 (BRIEF30's elementary condition), exhaustively: on a T1-silent pair of pattern (+,-,-), for every
    support J and every bad~silence zero pattern, the silent model is protected against the two switches
    S -> accept g and S -> accept -g iff the stated condition holds.
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import itertools
import random
from fractions import Fraction as F
from common import dot, sub

random.seed(38)

# ---------------- (1) ----------------
def rand_vec():
    return tuple(F(random.randint(-9, 9), random.randint(1, 4)) for _ in range(3))

weights = [(F(1), F(0), F(0)), (F(0), F(1), F(0)), (F(0), F(0), F(1)),
           (F(1, 2), F(1, 2), F(0)), (F(0), F(2, 5), F(3, 5)), (F(1, 3), F(0), F(2, 3)),
           (F(1, 3), F(1, 3), F(1, 3)), (F(1, 6), F(1, 2), F(1, 3))]
viol = 0
tests = 0
for trial in range(400):
    w = random.choice(weights)
    suppw = {i for i in range(3) if w[i] > 0}
    extra = [i for i in range(3) if i not in suppw]
    J = set(suppw) | set(random.sample(extra, random.randint(0, len(extra))))
    ncell = 4
    cells = []
    for _ in range(ncell):
        while True:
            pen = [rand_vec() for _ in range(3)]
            vals = [dot(w, p) for p in pen]
            m = min(vals)
            if vals.count(m) == 1:
                break
        base = vals.index(m)
        mu = F(random.randint(1, 5))
        cells.append((mu, pen, base))
    # pure records
    for choice in itertools.product(range(3), repeat=ncell):
        if all(choice[k] == cells[k][2] for k in range(ncell)):
            continue
        Phi = [F(0)] * 3
        for k, (mu, pen, base) in enumerate(cells):
            dlt = sub(pen[choice[k]], pen[base])
            for i in range(3):
                Phi[i] += mu * dlt[i]
        tests += 1
        if all(Phi[i] <= 0 for i in J):
            viol += 1
    # relaxed records with random rational weights
    for _ in range(50):
        Phi = [F(0)] * 3
        nontriv = False
        for (mu, pen, base) in cells:
            xs = [F(random.randint(0, 3), 3) for _ in range(3)]
            xs[base] = F(0)
            if sum(xs) > 1:
                xs = [x / sum(xs) for x in xs]
            for b in range(3):
                if xs[b] > 0:
                    nontriv = True
                    dlt = sub(pen[b], pen[base])
                    for i in range(3):
                        Phi[i] += mu * xs[b] * dlt[i]
        if nontriv:
            tests += 1
            if all(Phi[i] <= 0 for i in J):
                viol += 1
print("(1) certificate => (NT): records tested =", tests, " violations =", viol)

# ---------------- (2) ----------------
u = (F(1, 3),) * 3
# Example A: two cells, base advice tied at u with one alternative each; other alternatives strictly worse.
zA = [(F(1), F(-1), F(0)), (F(1), F(0), F(-1))]
other = (F(1), F(1), F(1))
print("(2A) w=u ties:", [dot(u, z) for z in zA], " other alternative w.inc:", dot(u, other))
# any relaxed record: Phi = x1 zA1 + x2 zA2 + y1*other + y2*other ; first coordinate = x1+x2+y1+y2 >= 0, =0 iff trivial
ok = True
for x1, x2, y1, y2 in itertools.product([F(k, 4) for k in range(5)], repeat=4):
    if x1 + y1 > 1 or x2 + y2 > 1:
        continue
    Phi = [x1 * zA[0][i] + x2 * zA[1][i] + (y1 + y2) * other[i] for i in range(3)]
    if (x1, x2, y1, y2) != (0, 0, 0, 0) and all(p <= 0 for p in Phi):
        ok = False
print("(2A) (NT) on the grid of relaxed records:", ok)
eta = F(1, 100)
wp = (F(1, 3) + 2 * eta, F(1, 3) - eta, F(1, 3) - eta)
print("(2A) strict minimiser at the interior w' =", wp, ":", [dot(wp, z) > 0 for z in zA], dot(wp, other) > 0)
zB = [(F(1), F(-1), F(0)), (F(-1), F(1), F(0))]
PhiB = [zB[0][i] + zB[1][i] for i in range(3)]
print("(2B) opposed ties: record x1=x2=1 has Phi =", PhiB, " (non-trivial, Phi=0: (NT) fails)")

# ---------------- (3) ----------------
eps = F(1, 7)
c0 = (1 - eps) / 3
T1v = [tuple(c0 + (eps if i == k else 0) for i in range(3)) for k in range(3)]
g = (F(1), F(-1, 2), F(-1, 2))
mn = min(dot(v, g) for v in T1v)
mx = max(dot(v, g) for v in T1v)
print("(3) g =", g, " T1 silent:", mn < 0 < mx, " (min, max) =", (mn, mx))
# penalties: cg = phi(S)-phi(acc g), cmg = phi(S)-phi(acc -g).  g positive at 0, negative at 1,2.
# strict-best: cg_0 > 0, cmg_1 > 0, cmg_2 > 0.  zeros allowed: cg_1, cg_2 (acc g bad at 1,2), cmg_0 (acc -g bad at 0).
rows = []
agree = True
for z_g1, z_g2, z_mg0 in itertools.product([0, 1], repeat=3):
    cg = (F(2), F(0) if z_g1 else F(-1), F(0) if z_g2 else F(-3))
    cmg = (F(0) if z_mg0 else F(-2), F(1), F(5, 2))
    for r in range(1, 4):
        for J in itertools.combinations(range(3), r):
            inc_acc = [-cg[i] for i in range(3)]     # increments of S -> accept g
            inc_rej = [-cmg[i] for i in range(3)]    # increments of S -> accept -g
            prot_acc = any(inc_acc[i] > 0 for i in J)
            prot_rej = any(inc_rej[i] > 0 for i in J)
            # stated condition: some i in J negative for g without a zero; some i in J positive for g without zero for -g
            cond_acc = any(i in J and not z for i, z in ((1, z_g1), (2, z_g2)))
            cond_rej = (0 in J) and not z_mg0
            agree &= (prot_acc == cond_acc) and (prot_rej == cond_rej)
            if r == 3:
                rows.append(((z_g1, z_g2, z_mg0), prot_acc, prot_rej))
print("(3) condition of Lemma 3.1 agrees with the switches for all 7 supports x 8 zero patterns:", agree)
for zp, pa, pr in rows:
    print("    J = Omega, zeros (acc g at 2, acc g at 3, acc -g at 1) =", zp,
          ": protected vs accept g:", pa, ", vs reject:", pr)
