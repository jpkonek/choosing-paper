"""JJ2 §7: the T1 algebra used in the transfer of Theorem gm to weak signs (exact).

We use the values of eps for which x_+ is rational: x_+ = t > 1, kappa = t + 1/t - 1, eps = (kappa-1)/(kappa+2).
Facet data of the write-up (normalised p* = u, x = x_+):
   c_k(h)_k = -(x h_{k+1} + h_{k+2}),  c_k(h)_{k+1} = x h_{k+1},  c_k(h)_{k+2} = h_{k+2}   (indices mod 3).
Checks:
 (1) corner equation x + 1/x = kappa + 1 and x^2 > kappa;
 (2) the corner rays and crossings lie on the right facets; c_k(h).u = 0;
 (3) on the closed facet segment, c_k(h)_k < 0 (so no zero at world k for gambles near relint F_k), and for l != k,
     c_k(h)_l = 0 exactly at the l-crossing (so zeros at world l near relint F_k accumulate only at that crossing);
 (4) at the b-crossing w' of F_a (failing pair (a,b)): c_a(w')_a < 0 (A-case of N21.6: no zero at a nearby);
     at the b-crossing w of F_c: c_c(w)_b = 0 (B-case: zeros at b allowed, sigma may equal e_b);
 (5) the box certificate of Prop T1 (input of Theorem collar): exact rational A in relint F_a, B in relint F_c with
     A_a<0<A_b, B_b<0<B_a, A_b B_a < |A_a||B_b|, c_a(A).q0 > 0, c_c(B).q0 > 0 at q0=(1-s)e_b + s e_a, for
     s in {1/100, 1/1000} (s = 1/10 reported for information), all three failing pairs (a,b) = (1,2),(2,3),(3,1) (0-based (0,1),(1,2),(2,0)).
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from common import E, dot

TS = [F(3, 2), F(2), F(3), F(5)]


def data(t):
    x = t
    kappa = t + 1 / t - 1
    eps = (kappa - 1) / (kappa + 2)
    c0 = (1 - eps) / 3
    v = [tuple(c0 + (eps if i == k else 0) for i in range(3)) for k in range(3)]
    return x, kappa, eps, c0, v


def ck(k, h, x):
    k1, k2 = (k + 1) % 3, (k + 2) % 3
    c = [F(0)] * 3
    c[k] = -(x * h[k1] + h[k2])
    c[k1] = x * h[k1]
    c[k2] = h[k2]
    return tuple(c)


def corner(a, b, kappa):
    """corner ray between F_a and F_b: -1 at a and b, kappa+1 at the third."""
    r = [F(-1)] * 3
    r[3 - a - b] = kappa + 1
    return tuple(r)


def facet_param(k, kappa):
    """F_k between r_{k+2,k} (tau=0) and r_{k,k+1} (tau=1)."""
    r0 = corner((k + 2) % 3, k, kappa)
    r1 = corner(k, (k + 1) % 3, kappa)
    return lambda tau: tuple((1 - tau) * p + tau * q for p, q in zip(r0, r1))


fails = 0
u = (F(1, 3),) * 3
for t in TS:
    x, kappa, eps, c0, v = data(t)
    ok = (x + 1 / x == kappa + 1) and x * x > kappa and 0 < eps < 1
    for k in range(3):
        h = facet_param(k, kappa)
        for tau in [F(0), F(1)] + [F(i, 97) for i in range(1, 97)]:
            g = h(tau)
            ok &= dot(g, v[k]) == 0
            ok &= all(dot(g, v[j]) >= 0 for j in range(3) if j != k)
            if 0 < tau < 1:
                ok &= all(dot(g, v[j]) > 0 for j in range(3) if j != k)
            cc = ck(k, g, x)
            ok &= dot(cc, u) == 0
            ok &= cc[k] < 0                      # (3): strict, on the CLOSED facet segment
            for l in range(3):
                if l != k:
                    ok &= (cc[l] == 0) == (g[l] == 0)   # (3): zero exactly at the l-crossing
                    ok &= (cc[l] > 0) == (g[l] > 0)
    # (4) and (5): failing pairs (a,b), c the third
    for (a, b) in [(0, 1), (1, 2), (2, 0)]:
        c = 3 - a - b
        ha, hc = facet_param(a, kappa), facet_param(c, kappa)
        # b-crossings: parameter where coordinate b vanishes (affine in tau)
        def root(hf):
            g0, g1 = hf(F(0)), hf(F(1))
            return g0[b] / (g0[b] - g1[b])
        ta, tc = root(ha), root(hc)
        wp, w = ha(ta), hc(tc)
        ok &= wp[b] == 0 and wp[a] < 0 < wp[c] and 0 < ta < 1
        ok &= w[b] == 0 and w[c] < 0 < w[a] and 0 < tc < 1
        ok &= ck(a, wp, x)[a] < 0                # A-case: strictly negative at e_a
        ok &= ck(c, w, x)[b] == 0                # B-case: crossing row at e_b
        # explicit witnesses: A on the segment [w', r_{c,a}] of F_a, B on the segment [w, r_{b,c}] of F_c
        rca, rbc = corner(c, a, kappa), corner(b, c, kappa)
        for s in [F(1, 10), F(1, 100), F(1, 1000)]:
            q0 = tuple(s * E[a][i] + (1 - s) * E[b][i] for i in range(3))
            alpha0 = s * kappa / (x * (kappa + 1))      # first-order threshold for c_a(A).q0 > 0
            beta0 = s * x * kappa                       # first-order threshold for c_c(B).q0 > 0
            found = None
            for k1 in range(1, 60):
                if found:
                    break
                for k2 in range(1, 60):
                    al = alpha0 * (1 + F(1, k1))
                    be = beta0 * (1 - F(1, k2 + 1))
                    A = tuple((1 - al) * p + al * q for p, q in zip(wp, rca))
                    B = tuple((1 - be) * p + be * q for p, q in zip(w, rbc))
                    cond = (A[a] < 0 < A[b] and B[b] < 0 < B[a]
                            and dot(A, v[a]) == 0 and all(dot(A, v[j]) > 0 for j in range(3) if j != a)
                            and dot(B, v[c]) == 0 and all(dot(B, v[j]) > 0 for j in range(3) if j != c)
                            and A[b] * B[a] < abs(A[a]) * abs(B[b])
                            and dot(ck(a, A, x), q0) > 0 and dot(ck(c, B, x), q0) > 0)
                    if cond:
                        found = (al, be)
                        break
            if found is None:
                if s <= F(1, 100):
                    ok = False
                print(f"t={t} (a,b)=({a+1},{b+1}) s={s}: no witness at this s"
                      + (" (FAIL)" if s <= F(1, 100) else " (s not small enough; the certificate is claimed for small s only)"))
            else:
                print(f"t={t} eps={eps} (a,b)=({a+1},{b+1}) s={s}: witness alpha={found[0]}, beta={found[1]}")
    print(f"t={t}: x={x}, kappa={kappa}, eps={eps}: all facet checks", "OK" if ok else "FAIL")
    fails += 0 if ok else 1
print("failures:", fails)
