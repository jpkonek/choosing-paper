# FF3 (NUMERICS, cross-check of Lemma 2.2): second zeta-derivative of the six ray forms, quadrature vs kink formula.
import numpy as np
from scipy.integrate import quad
K=16/7; kp=9/7
def forms(r2,r3,c,s):
    M1=r2*c+r3*s+kp*max(r2*c,r3*s)
    N=(r2*c+r3*s)/K
    P3a=max(K*r3*s-r2*c,0.0)
    if r3*s>=(K+1)*r2*c: P3r=(r3*s-r2*c)/K
    elif r3*s>K*r2*c: P3r=r3*s-K*r2*c
    else: P3r=0.0
    P2a=max(K*r2*c-r3*s,0.0)
    if r2*c>=(K+1)*r3*s: P2r=(r2*c-r3*s)/K
    elif r2*c>K*r3*s: P2r=r2*c-K*r3*s
    else: P2r=0.0
    return [M1,N,P3a,P3r,P2a,P2r]
names=['A1','B1','A3','B3','A2','B2']
Wf=[lambda p,j=j: 1+0.5*np.sin(3*p+j) for j in range(6)]
# kinks: (form index, lambda, coef) ; contribution W*coef*s*lambda/(zeta^2+lambda^2) at phi0=arctan(lambda/zeta)
kinks=[(0,1,kp),(2,1/K,K),(3,K,1),(3,K+1,-(K-1)/K),(4,K,1),(5,1/(K+1),-(K*K-1)/K),(5,1/K,K)]
def Phi(j,zeta):
    f=lambda p: Wf[j](p)*forms(1.0,zeta,np.cos(p),np.sin(p))[j]
    pts=[np.arctan(l/zeta) for (jj,l,c) in kinks if jj==j]
    return quad(f,0,np.pi/2,points=pts or None,limit=400,epsabs=1e-13,epsrel=1e-13)[0]
def kink2(j,zeta):
    tot=0.0
    for jj,l,c in kinks:
        if jj!=j: continue
        p0=np.arctan(l/zeta)
        tot+=Wf[j](p0)*c*np.sin(p0)*l/(zeta**2+l**2)
    return tot
maxerr=0
for j in range(6):
    for zeta in [0.2,0.5,0.9,1.3,2.0,3.7]:
        h=1e-3
        fd=(Phi(j,zeta+h)-2*Phi(j,zeta)+Phi(j,zeta-h))/h**2
        kf=kink2(j,zeta)
        maxerr=max(maxerr,abs(fd-kf))
        print('%s zeta=%.2f  finite-diff=%.6f  kink-formula=%.6f'%(names[j],zeta,fd,kf))
print('max abs discrepancy',maxerr)
