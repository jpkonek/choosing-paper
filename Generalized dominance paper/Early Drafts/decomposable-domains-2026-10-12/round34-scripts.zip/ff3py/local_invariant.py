# FF3 (NUMERICS cross-check of Theorem 3.1): the explicit sector invariant Phi_Z is constant on world-1 level
# segments inside the sector 1/Z <= x3/x2 <= Z, strictly guiding, and NOT level-constant outside the sector.
import numpy as np
from scipy.integrate import quad
K=16/7; kp=9/7; c2=(K+1)**2*(K-1)/K; eta=0.5
Z=3.0; Y=(K+1)*Z
cA1=(c2-K*K-eta/K)/kp            # = 47/96
def B3h(y):
    if y<1/Y: return (1/Y)**3*(y*Y)**3.5      # y^3*(yY)^(1/2) continuous at 1/Y
    if y>Y: return Y**3*(Y/y)**0.5
    return y**3
def B2h(t): return t**3*B3h(1/t)
hats={'A1':lambda t: cA1*(B3h(t)+B2h(t)),'B1':lambda t: B3h(t)+B2h(t),
      'A3':lambda t: eta*B3h(t),'B3':B3h,'A2':lambda t: eta*B2h(t),'B2':B2h}
def W(name,phi):
    t=np.tan(phi); return hats[name](t)*(1+t*t)**1.5/t**3
def forms(r2,r3,c,s):
    M1=r2*c+r3*s+kp*max(r2*c,r3*s); N=(r2*c+r3*s)/K
    P3a=max(K*r3*s-r2*c,0.0)
    P3r=(r3*s-r2*c)/K if r3*s>=(K+1)*r2*c else (r3*s-K*r2*c if r3*s>K*r2*c else 0.0)
    P2a=max(K*r2*c-r3*s,0.0)
    P2r=(r2*c-r3*s)/K if r2*c>=(K+1)*r3*s else (r2*c-K*r3*s if r2*c>K*r3*s else 0.0)
    return {'A1':M1,'B1':N,'A3':P3a,'B3':P3r,'A2':P2a,'B2':P2r}
# Phi(r) = sum over forms of +int W*form  (acceptance weights -A on rho<1/f give +A f; rejection +B on rho>1/f give +B f)
def Phi(r2,r3):
    tot=0.0
    br=sorted(set([np.arctan(l*r2/r3) for l in [1,1/K,K,K+1,1/(K+1)]]+[np.arctan(1/Y),np.arctan(Y)]))
    for n in hats:
        f=lambda p: W(n,p)*forms(r2,r3,np.cos(p),np.sin(p))[n]
        tot+=quad(f,0,np.pi/2,points=br,limit=500,epsabs=1e-12,epsrel=1e-12)[0]
    return tot
print('integrability: int W dphi =',{n:round(quad(lambda p:W(n,p),0,np.pi/2,limit=400,points=[np.arctan(1/Y),np.arctan(Y)])[0],4) for n in hats})
for S in [0.5,2.0,7.0]:
    vals_in=[]; vals_out=[]
    for frac in np.linspace(0.05,0.95,19):
        r2,r3=S*(1-frac),S*frac; zeta=r3/r2
        v=Phi(r2,r3)/S
        (vals_in if 1/Z<=zeta<=Z else vals_out).append((round(zeta,3),v))
    vi=[v for _,v in vals_in]
    print('S=%.2f  inside sector: Phi/S range [%.9f, %.9f] (spread %.2e) over %d points'%(S,min(vi),max(vi),max(vi)-min(vi),len(vi)))
    print('        outside sector Phi/S:',[(z,round(v,6)) for z,v in vals_out])
# guidance along lines through e1 (fixed zeta, S varies): Phi strictly increasing in S
print('Phi along a line through e1 (zeta=1):',[round(Phi(S/2,S/2),6) for S in [0.5,1,2,4]])
