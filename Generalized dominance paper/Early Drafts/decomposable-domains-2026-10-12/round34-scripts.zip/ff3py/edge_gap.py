# FF3 (NUMERICS): for the explicit sector weights (Z=3), the edge value g(0)=Phi(1,0) differs from alpha,
# so the edge correction of Theorem 3.3 (Step 2) is genuinely needed.
exec(open('local_invariant.py').read().split("print('integrability")[0])
alpha=Phi(1.0,1.0)/2
print('alpha = %.6f   g(0)=Phi(1,0) = %.6f   g(0)-alpha = %.6f'%(alpha,Phi(1.0,1e-12),Phi(1.0,1e-12)-alpha))
