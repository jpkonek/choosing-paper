# FF3 (NUMERICS): end-to-end check of Theorem 3.1 with the DIRECT acceptance test of D_{K_x} (no closed forms):
# W(rec(C_p,C_q)) = sum over pairs g=(1,+-t2,+-t3) of weight(g,advice_q)-weight(g,advice_p), weights rho^-3 W_class(phi).
import numpy as np
exec(open('local_invariant.py').read().split("print('integrability")[0])   # reuse hats, W, constants (no output)
eps=0.3; c0=(1-eps)/3
V=np.array([[c0+(eps if i==k else 0) for i in range(3)] for k in range(3)])
def advice(x,g):  # g: (...,3)
    vals=np.einsum('ki,i,...i->...k',V,x,g)
    return np.where(vals.min(-1)>0,1,np.where(vals.max(-1)<0,-1,0))
cls={'P1':((-1,-1),'A1','B1'),'P3':((1,-1),'A3','B3'),'P2':((-1,1),'A2','B2')}
nph,nl=3000,3000
ph=(np.arange(nph)+0.5)*(np.pi/2)/nph; dph=(np.pi/2)/nph
lr=np.linspace(np.log(1e-3),np.log(1e4),nl); dl=lr[1]-lr[0]; rho=np.exp(lr)
P,R=np.meshgrid(ph,rho,indexing='ij')
def Wrec(p,q):
    p=np.array(p,float); q=np.array(q,float); tot=0.0
    for c,((s2,s3),a,b) in cls.items():
        g=np.stack([np.ones_like(P),s2*R*np.cos(P),s3*R*np.sin(P)],-1)
        ap,aq=advice(p,g),advice(q,g)
        Wa=np.array([W(a,t) for t in ph])[:,None]; Wb=np.array([W(b,t) for t in ph])[:,None]
        wq=np.where(aq==1,-Wa,np.where(aq==-1,Wb,0.0)); wp=np.where(ap==1,-Wa,np.where(ap==-1,Wb,0.0))
        # area element rho drho dphi = rho^2 dlogrho dphi; density rho^-3 -> rho^-1
        tot+=np.sum((wq-wp)/R)*dl*dph
    return tot
def pt(x1,ratio):  # x3/x2=ratio
    x2=(1-x1)/(1+ratio); return (x1,x2,x2*ratio)
for x1 in [0.3,1/3]:
    a,b=pt(x1,0.6),pt(x1,2.2)
    print('level pair inside sector  x1=%.4f: W=%.5f'%(x1,Wrec(a,b)))
def pred(a,b): return Phi(b[1]/b[0],b[2]/b[0])-Phi(a[1]/a[0],a[2]/a[0])
for a,b,lab in [(pt(0.3,0.1),pt(0.3,1.0),'level pair leaving sector (x3/x2 0.1 -> 1)'),(pt(1/3,1.0),pt(0.3,1.0),'pair on line through e1 (x1 1/3 -> 0.3)')]:
    print('%s: W=%.4f  closed-form prediction %.4f'%(lab,Wrec(a,b),pred(a,b)))
print('scale: Phi at x=u is %.3f'%Phi(1.0,1.0))
