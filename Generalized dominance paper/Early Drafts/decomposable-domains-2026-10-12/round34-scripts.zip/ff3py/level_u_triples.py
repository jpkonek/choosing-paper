# FF3: exact search for splice triples (u, a, b) on the world-1 level line {x1=1/3} through u, a strictly between u and b
# (C_a a.e. a splice of T1=C_u and C_b), plain posterior family.  Uses EE2's exact support-function test.
import sys; sys.path.insert(0,'../ee2py')
from fractions import Fraction as F
from splice import splice_violation, post2
u=(F(1,3),F(1,3),F(1,3))
def L(y): return (F(1,3),y,F(2,3)-y)     # level line x1=1/3, parameter y=x2
found=[]; tested=0
ys=[F(k,240) for k in range(1,160)]
for yb in ys:
    for ya in ys:
        if not (min(F(1,3),yb)<ya<max(F(1,3),yb)): continue
        tested+=1
        if splice_violation(post2(u),post2(L(ya)),post2(L(yb))) is None:
            found.append((ya,yb))
print('tested',tested,'triples (u,a,b) on {x1=1/3} with a strictly between; splice triples found:',len(found))
for ya,yb in found[:20]: print('  a=',L(ya),' b=',L(yb))
