# FF3: exact checks of the boundary-model advice used in Theorem 3.3:
#  (a) edge x3=0 (and x2=0): the chart formulas of Lemma 1.1 hold with r3=0 (r2=0);
#  (b) edge x1=0 (models with K on edge e2e3), a=x2/(K x3):
#      P1: always reject;  P3 (g=(1,t2,-t3)): + iff t3/t2<a, - iff t3/t2>K^2 a;  P2 (g=(1,-t2,t3)): + iff t3/t2>K^2 a, - iff t3/t2<a.
from fractions import Fraction as F
import random
random.seed(7)
exec(open('regions_check.py').read().split('bad=0; n=0')[0])
bad=0;n=0
for _ in range(30000):
    a,b=random.randint(1,300),random.randint(1,300)
    for x in ([F(a,a+b),F(b,a+b),F(0)],[F(a,a+b),F(0),F(b,a+b)]):
        r=(x[1]/x[0],x[2]/x[0]); cls=random.choice(['P1','P2','P3']); t=(rnd(),rnd())
        g=(F(1),sg[cls][0]*t[0],sg[cls][1]*t[1]); n+=1
        if direct(x,g)!=closed(r,cls,t): bad+=1
print('(a) edges x3=0 / x2=0: %d cases, %d mismatches'%(n,bad))
bad=0;n=0
for _ in range(30000):
    p,q=random.randint(1,300),random.randint(1,300); x=[F(0),F(p,p+q),F(q,p+q)]; A=x[1]/(K*x[2])
    cls=random.choice(['P1','P2','P3']); t=(rnd(),rnd()); g=(F(1),sg[cls][0]*t[0],sg[cls][1]*t[1]); ratio=t[1]/t[0]
    if cls=='P1': pred='-'
    elif cls=='P3': pred='+' if ratio<A else ('-' if ratio>K*K*A else '0')
    else: pred='+' if ratio>K*K*A else ('-' if ratio<A else '0')
    n+=1
    if direct(x,g)!=pred: bad+=1
print('(b) edge x1=0: %d cases, %d mismatches'%(n,bad))
