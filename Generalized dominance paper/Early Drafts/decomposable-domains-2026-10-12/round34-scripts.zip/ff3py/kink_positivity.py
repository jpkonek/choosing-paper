# FF3: exact positivity of the kink residual R(z) for b(z)=z^3/(1+z)^3, and of the A1 profile with eta=1/100.
import sympy as sp
z=sp.symbols('z',positive=True)
K=sp.Rational(16,7); kp=sp.Rational(9,7)
c3=(K-1)/(K*(K+1)); c2=(K+1)**2*(K-1)/K
b=lambda w: w**3/(1+w)**3
R=c3*b((K+1)*z)-b(K*z)/K+c2*b(z/(K+1))-K**2*b(z/K)
eta=sp.Rational(1,100)
A1hat=sp.together((R-eta*(K**2*b(z/K)+b(K*z)/K))/kp)
def report(name,expr):
    num,den=sp.fraction(sp.together(expr))
    num=sp.Poly(sp.expand(num),z); den=sp.Poly(sp.expand(den),z)
    # factor out z^3
    q,rm=sp.div(num,sp.Poly(z**3,z)); assert rm.is_zero
    coeffs=q.all_coeffs()
    print(name,': numerator = z^3 * q(z), deg q =',q.degree())
    print('   q coefficients all >0:',all(c>0 for c in coeffs),' min coeff',min(coeffs))
    print('   denominator coefficients all >0:',all(c>0 for c in den.all_coeffs()) or all(c<0 for c in den.all_coeffs()))
    print('   real roots of q in (0,oo):',sp.Poly(q,z).count_roots(0,sp.oo))
    print('   limits z->0 of expr/z^3:',sp.limit(expr/z**3,z,0),'  z->oo:',sp.limit(expr,z,sp.oo))
report('R',R)
report('A1hat (eta=1/100)',A1hat)
print('c2 =',c2,' K^2 =',K**2,' c3 =',c3,' c3*(K+1)^3 == c2:',sp.simplify(c3*(K+1)**3-c2)==0)
# symmetry z^3 R(1/z) = R(z)
print('symmetry z^3 R(1/z) - R(z) =',sp.simplify(z**3*R.subs(z,1/z)-R))
print('symmetry of A1hat:',sp.simplify(z**3*A1hat.subs(z,1/z)-A1hat))
