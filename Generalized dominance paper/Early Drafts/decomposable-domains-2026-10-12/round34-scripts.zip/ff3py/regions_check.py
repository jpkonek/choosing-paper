# FF3: exact check of the chart description of the plain posterior family.
# Pair {g,-g} indexed by g=(1, s2*t2, s3*t3), t>0.  C_x accepts g iff min_k (x*v_k).g>0, rejects iff max_k (x*v_k).g<0.
# Claimed closed forms (r=(x2/x1,x3/x1), s=r*t componentwise, K=1+kappa', kappa'=eps/c0=9/7):
#  P1 (s2=-,s3=-): acc iff 1-s2-s3-k'max(s2,s3)>0 ; rej iff s2+s3>K
#  P3 (s2=+,s3=-): acc iff 1+s2>K s3 ; rej iff s3>1+s2+k'max(1,s2)
#  P2 (s2=-,s3=+): acc iff 1+s3>K s2 ; rej iff s2>1+s3+k'max(1,s3)
# and the ray forms: along t=rho*(c,s), the accepted/rejected rho-sets are as in FF3 Lemma 1.2.
from fractions import Fraction as F
import random
random.seed(26)
eps=F(3,10); c0=(1-eps)/3; kp=eps/c0; K=1+kp
assert kp==F(9,7) and K==F(16,7)
V=[[c0+(eps if i==k else 0) for i in range(3)] for k in range(3)]
def direct(x,g):
    vals=[sum(x[i]*V[k][i]*g[i] for i in range(3)) for k in range(3)]
    if min(vals)>0: return '+'
    if max(vals)<0: return '-'
    return '0'
def closed(r,cls,t):
    s2,s3=r[0]*t[0],r[1]*t[1]
    if cls=='P1':
        if 1-s2-s3-kp*max(s2,s3)>0: return '+'
        if s2+s3>K: return '-'
        return '0'
    if cls=='P3':
        if 1+s2>K*s3: return '+'
        if s3>1+s2+kp*max(1,s2): return '-'
        return '0'
    if cls=='P2':
        if 1+s3>K*s2: return '+'
        if s2>1+s3+kp*max(1,s3): return '-'
        return '0'
sg={'P1':(-1,-1),'P2':(-1,1),'P3':(1,-1)}
def rnd(): return F(random.randint(1,400),random.randint(1,400))
bad=0; n=0; tally={}
for _ in range(60000):
    a,b,c=random.randint(1,300),random.randint(1,300),random.randint(1,300)
    x=[F(a,a+b+c),F(b,a+b+c),F(c,a+b+c)]
    r=(x[1]/x[0],x[2]/x[0])
    cls=random.choice(['P1','P2','P3'])
    t=(rnd(),rnd())
    g=(F(1),sg[cls][0]*t[0],sg[cls][1]*t[1])
    d=direct(x,g); e=closed(r,cls,t)
    n+=1; tally[(cls,d)]=tally.get((cls,d),0)+1
    if d!=e: bad+=1
print('closed forms vs direct test: %d cases, %d mismatches'%(n,bad))
print('advice tally', sorted(tally.items()))
# ray forms: f_R(r,phi) := integral of rho^-2 over the rho-set (regularised at rho->0 by dropping 1/eps).
# Claimed: P1acc: M1=r2c+r3s+k'max(r2c,r3s) [contribution +A*M1]; P1rej: (r2c+r3s)/K;
# P3acc: (K r3 s - r2 c)_+ ; P3rej: piecewise (0 | r3s-K r2c | (r3s-r2c)/K) ; P2 symmetric.
# Check the rho-sets themselves: P3rej set is (rho_min,inf) with rho_min = 1/f.
def p3rej_f(r2,r3,c,s):
    if r3*s>=(K+1)*r2*c: return (r3*s-r2*c)/K
    if r3*s>K*r2*c: return r3*s-K*r2*c
    return F(0)
bad2=0
for _ in range(20000):
    r2,r3=rnd(),rnd(); c,s=rnd(),rnd()   # (c,s) any positive direction (homogeneity)
    f=p3rej_f(r2,r3,c,s)
    for rho in [rnd()*F(1,7) for _ in range(6)]:
        rej = closed((r2,r3),'P3',(rho*c,rho*s))=='-'
        pred = (f>0 and rho>1/f)
        if rej!=pred: bad2+=1
print('P3 rejection ray form: mismatches', bad2)
bad3=0
for _ in range(20000):
    r2,r3=rnd(),rnd(); c,s=rnd(),rnd()
    M1=r2*c+r3*s+kp*max(r2*c,r3*s); N=r2*c+r3*s; P=K*r3*s-r2*c
    for rho in [rnd()*F(1,7) for _ in range(6)]:
        a1=closed((r2,r3),'P1',(rho*c,rho*s)); a3=closed((r2,r3),'P3',(rho*c,rho*s))
        if (a1=='+')!=(rho<1/M1): bad3+=1
        if (a1=='-')!=(rho>K/N): bad3+=1
        if (a3=='+')!=(P<=0 or rho<1/P): bad3+=1
print('P1 acc/rej and P3 acc ray forms: mismatches', bad3)
