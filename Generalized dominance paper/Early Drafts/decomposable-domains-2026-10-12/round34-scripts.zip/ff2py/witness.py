"""FF2 (C4'): exact Gordan witnesses showing that a posterior model C_p (p != u) is the F-Bayes model at NO weight,
for the body field F of ff2_checks.py (X2.6 field with attribution frozen at its u-value).

Method (all exact):
 - candidate problems: points just inside / just outside C_p's M-boundary plane (p + lam p_o e_o).h = 0 on Q_o,
   and points of the 'attribution mismatch' set where C_p is at S but p.F(h,O) < 0;
 - each candidate (h, b) gives delta = F(h,b) - F(h,C_p(h));
 - a certificate is a set of <= 3 vectors g_j from {e_1,e_2,e_3} u {delta_k} and mu_j >= 0 with sum mu_j g_j = -(1,1,1);
   by Helly (dimension 2) and Farkas this exists iff no q in Delta has q.delta_k >= 0 for all k.
 - the final witness keeps only the delta-terms: sum lam_k delta_k <= -(1,1,1) componentwise.
"""
from fractions import Fraction as Fr
import itertools, random, sys
sys.path.insert(0, '.')
from ff2_checks import EPS, C0, LAM, U, POS, dot, posterior_pts, position, odd, attribution, F

def solve3(cols, b):
    M = [[cols[k][i] for k in range(3)] + [b[i]] for i in range(3)]
    for c in range(3):
        piv = next((r for r in range(c, 3) if M[r][c] != 0), None)
        if piv is None:
            return None
        M[c], M[piv] = M[piv], M[c]
        for r in range(3):
            if r != c and M[r][c] != 0:
                f = M[r][c] / M[c][c]
                M[r] = [x - f * y for x, y in zip(M[r], M[c])]
    return [M[i][3] / M[i][i] for i in range(3)]

E = [tuple(Fr(int(i == j)) for i in range(3)) for j in range(3)]

def certificate(deltas):
    G = [('e', j, E[j]) for j in range(3)] + [('d', k, d) for k, d in enumerate(deltas)]
    for tri in itertools.combinations(range(len(G)), 3):
        cols = [G[t][2] for t in tri]
        mu = solve3(cols, (Fr(-1),) * 3)
        if mu is not None and all(m >= 0 for m in mu):
            lam = {G[t][1]: m for t, m in zip(tri, mu) if G[t][0] == 'd' and m > 0}
            if lam:
                comb = tuple(sum(l * deltas[k][i] for k, l in lam.items()) for i in range(3))
                if all(c <= -1 for c in comb):
                    return lam, comb
    return None

def candidates(p, rng, n_side=6, eta=Fr(1, 10**4)):
    K = posterior_pts(p)
    out = []
    for o in range(3):
        nrm = tuple(p[i] + (LAM * p[o] if i == o else 0) for i in range(3))   # M-boundary normal on Q_o
        j, l = [i for i in range(3) if i != o]
        cnt = 0; tries = 0
        while cnt < n_side and tries < 5000:
            tries += 1
            hj = Fr(rng.randint(1, 50), rng.randint(1, 20)); hl = Fr(rng.randint(1, 50), rng.randint(1, 20))
            # solve nrm.h = 0 for h_o (negative)
            ho = -(nrm[j] * hj + nrm[l] * hl) / nrm[o]
            h0 = [None] * 3; h0[o] = ho; h0[j] = hj; h0[l] = hl
            for s in (+1, -1):
                h = tuple(h0[i] + s * eta * nrm[i] * (abs(ho) + hj + hl) for i in range(3))
                try:
                    pos, marg = position(K, h); attribution(h)
                except (ValueError, AssertionError):
                    continue
                for b in POS:
                    if b != pos:
                        out.append((h, pos, b))
            cnt += 1
    # mismatch points: C_p at S, p.F(h,O) < 0
    tries = 0; mm = 0
    while mm < 12 and tries < 200000:
        tries += 1
        o = rng.randrange(3)
        h = [Fr(rng.randint(1, 60), rng.randint(1, 30)) for _ in range(3)]; h[o] = -h[o]; h = tuple(h)
        try:
            pos, marg = position(K, h); attribution(h)
        except (ValueError, AssertionError):
            continue
        if pos == 'S' and dot(p, F(h, 'O')) < 0:
            out.append((h, pos, 'O')); mm += 1
    return out, K

def run(p, seed):
    rng = random.Random(seed)
    cand, K = candidates(p, rng)
    deltas = [tuple(x - y for x, y in zip(F(h, b), F(h, pos))) for (h, pos, b) in cand]
    cert = certificate(deltas)
    return cand, deltas, cert, K

if __name__ == '__main__':
    plist = [(Fr(1, 2), Fr(1, 4), Fr(1, 4)), (Fr(2, 5), Fr(7, 20), Fr(1, 4)), (Fr(1, 5), Fr(2, 5), Fr(2, 5)),
             (Fr(17, 50), Fr(33, 100), Fr(33, 100)), (Fr(101, 300), Fr(67, 200), Fr(197, 600)), U]
    for p in plist:
        cand, deltas, cert, K = run(p, 11)
        tag = tuple(str(x) for x in p)
        if cert is None:
            print(f"p={tag}: {len(deltas)} candidate deltas, no certificate found among nonsingular triples")
            continue
        lam, comb = cert
        ok = all(c < 0 for c in comb)
        for k in lam:
            h, pos, b = cand[k]
            pos2, marg = position(K, h)
            o = odd(h); j, l = [i for i in range(3) if i != o]
            ok &= (pos2 == pos and marg > 0 and h[j] != h[l] and all(x != 0 for x in h))
        print(f"p={tag}: certificate verified={ok}  (terms {len(lam)})")
        for k, l in lam.items():
            h, pos, b = cand[k]
            print(f"   h={tuple(str(x) for x in h)}  C_p:{pos}->{b}  delta={tuple(str(x) for x in deltas[k])}  lam={l}")
        print(f"   sum lam*delta = {tuple(str(x) for x in comb)}")
