"""FF2 exact checks (rational arithmetic only; no floating point is used in any verdict).

Setting: three worlds, eps = 3/10, T1 = co{v_k}, v_k = c0*1 + eps*e_k, c0 = (1-eps)/3, lam = eps/c0 = 9/7.
Posterior family K_p = nu(p (.) T1).  A mixed pair is indexed by its majority orientation h (two positive
coordinates, one negative, the odd world o).  Positions: M (accept h only), S (silence), O (accept -h only).

The body field F (X2.6 with the attribution frozen at its p = u value a(h) = argmax_{j != o} h_j):
   F_i(h,M) = -h_i + lam*[i=o]*|h_o|,   F_i(h,S) = 0,   F_i(h,O) = h_i*(1 + lam*[i=a(h)]).

Checks:
 (C1) F is strictly guiding on mixed pairs (world i != o ranks M<S<O, world o ranks O<S<M).
 (C2) T1's position is the unique pointwise minimiser of u.F(h,.) over {M,S,O}  (T1 = unique u-Bayes model of F).
 (C3) For p = u: u.(F(h,b) - F(h,C_u(h))) >= 0 for every sampled h, b  (no Gordan witness can exist at u).
 (C4) see witness.py / witness_near_u.py: exact Gordan witnesses that C_p (p != u) is F-Bayes at no weight.
 (C5) (US): on Q_o, the odd world's M-vs-S stake over the sum of the majority stakes is unbounded (explicit sequence).
"""
from fractions import Fraction as Fr
import random, itertools, sys

EPS = Fr(3, 10)
C0 = (1 - EPS) / 3
LAM = EPS / C0
assert LAM == Fr(9, 7)
U = (Fr(1, 3),) * 3
POS = ('M', 'S', 'O')

def dot(a, b):
    return sum(x * y for x, y in zip(a, b))

def vert(k):
    return tuple(C0 + (EPS if i == k else 0) for i in range(3))

T1 = [vert(k) for k in range(3)]

def posterior_pts(p):
    pts = []
    for v in T1:
        w = tuple(pi * vi for pi, vi in zip(p, v))
        s = sum(w)
        pts.append(tuple(x / s for x in w))
    return pts

def position(K, h):
    vals = [dot(v, h) for v in K]
    mn, mx = min(vals), max(vals)
    if mn > 0:
        return 'M', mn
    if mx < 0:
        return 'O', -mx
    if mn == 0 or mx == 0:
        raise ValueError('boundary')
    return 'S', min(-mn, mx)          # margin to the two boundary planes

def odd(h):
    neg = [i for i in range(3) if h[i] < 0]
    pos = [i for i in range(3) if h[i] > 0]
    assert len(neg) == 1 and len(pos) == 2
    return neg[0]

def attribution(h):
    o = odd(h)
    j, l = [i for i in range(3) if i != o]
    if h[j] == h[l]:
        raise ValueError('attribution tie')
    return j if h[j] > h[l] else l

def F(h, a):
    o = odd(h); at = attribution(h)
    if a == 'M':
        return tuple(-h[i] + (LAM * abs(h[o]) if i == o else 0) for i in range(3))
    if a == 'S':
        return (Fr(0),) * 3
    if a == 'O':
        return tuple(h[i] * (1 + (LAM if i == at else 0)) for i in range(3))
    raise KeyError(a)

def rand_h(rng, R=60, D=40):
    o = rng.randrange(3)
    h = [Fr(rng.randint(1, R), rng.randint(1, D)) for _ in range(3)]
    h[o] = -h[o]
    return tuple(h)

def solve3(A, b):
    """Exact solve of the 3x3 system A x = b (A given by rows); None if singular."""
    M = [list(A[i]) + [b[i]] for i in range(3)]
    for c in range(3):
        piv = next((r for r in range(c, 3) if M[r][c] != 0), None)
        if piv is None:
            return None
        M[c], M[piv] = M[piv], M[c]
        for r in range(3):
            if r != c and M[r][c] != 0:
                f = M[r][c] / M[c][c]
                M[r] = [x - f * y for x, y in zip(M[r], M[c])]
    return [M[i][3] / M[i][i] for i in range(3)]

def main():
    rng = random.Random(20261017)
    out = []
    # (C1) strict guidance
    bad = 0; n = 0
    for _ in range(20000):
        h = rand_h(rng)
        try:
            o = odd(h); FM, FS, FO = F(h, 'M'), F(h, 'S'), F(h, 'O')
        except ValueError:
            continue
        n += 1
        for i in range(3):
            if i != o:
                bad += not (FM[i] < FS[i] < FO[i])
            else:
                bad += not (FO[i] < FS[i] < FM[i])
    out.append(f"(C1) strict guidance of F: {n} pairs, violations {bad}")
    # (C2) T1 unique u-Bayes
    bad = 0; n = 0
    for _ in range(20000):
        h = rand_h(rng)
        try:
            pos, _ = position(T1, h)
            vals = {a: dot(U, F(h, a)) for a in POS}
        except ValueError:
            continue
        n += 1
        best = min(vals.values())
        arg = [a for a in POS if vals[a] == best]
        bad += (arg != [pos])
    out.append(f"(C2) T1 = unique pointwise u-Bayes of F: {n} pairs, mismatches {bad}")
    # (C3) no witness at u
    bad = 0; n = 0
    for _ in range(20000):
        h = rand_h(rng)
        try:
            pos, _ = position(T1, h); F0 = F(h, pos)
        except ValueError:
            continue
        for b in POS:
            if b == pos:
                continue
            d = tuple(x - y for x, y in zip(F(h, b), F0))
            n += 1
            bad += dot(U, d) < 0
    out.append(f"(C3) at p = u: {n} deltas, u.delta < 0 in {bad} cases")
    # (C4) is in witness.py and witness_near_u.py (targeted exact certificates).
    # (C5) unbounded stake ratio on Q_o
    rows = []
    for t in (Fr(10), Fr(100), Fr(10**4)):
        h = (-t, Fr(1), Fr(1, 2))
        oddstake = F(h, 'M')[0] - F(h, 'S')[0]
        majstake = (F(h, 'S')[1] - F(h, 'M')[1]) + (F(h, 'S')[2] - F(h, 'M')[2])
        rows.append(str(oddstake / majstake))
    out.append("(C5) (US) ratio along h=(-t,1,1/2), t=10,100,10^4: " + ", ".join(rows))
    print("\n".join(out))

if __name__ == '__main__':
    main()
