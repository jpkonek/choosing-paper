"""FF2 (C4''): exact Gordan witnesses for posterior models C_p with p close to u (same method as witness.py, with
targeted 'attribution-mismatch' problems and boundary offsets eta = 10^-8)."""
from fractions import Fraction as Fr
import random, sys
sys.path.insert(0, '.')
from ff2_checks import LAM, U, POS, dot, posterior_pts, position, odd, attribution, F
from witness import certificate

def mismatch_points(p, K):
    out = []
    for o in range(3):
        j, l = [i for i in range(3) if i != o]
        if p[j] == p[l]:
            continue
        if p[j] > p[l]:
            j, l = l, j                      # now p_l > p_j
        for t in (Fr(1, 4), Fr(1, 2), Fr(3, 4)):
            hl = Fr(1); hj = hl * (1 + t * (p[l] / p[j] - 1))     # h_l < h_j < (p_l/p_j) h_l
            # p.h + lam p_j h_j < 0 <= p.h + lam p_l h_l  ->  solve for h_o (negative)
            base_lo = p[j] * hj + p[l] * hl + LAM * p[j] * hj
            base_hi = p[j] * hj + p[l] * hl + LAM * p[l] * hl
            ho = -(base_lo + base_hi) / (2 * p[o])                 # midpoint, |h_o| between the two roots
            h = [None] * 3; h[o] = ho; h[j] = hj; h[l] = hl; h = tuple(h)
            try:
                pos, marg = position(K, h); attribution(h)
            except (ValueError, AssertionError):
                continue
            if pos == 'S' and dot(p, F(h, 'O')) < 0:
                out.append((h, pos, 'O'))
    return out

def boundary_points(p, K, rng, n_side=8, eta=Fr(1, 10**8)):
    out = []
    for o in range(3):
        nrm = tuple(p[i] + (LAM * p[o] if i == o else 0) for i in range(3))
        j, l = [i for i in range(3) if i != o]
        for _ in range(n_side):
            hj = Fr(rng.randint(1, 50), rng.randint(1, 20)); hl = Fr(rng.randint(1, 50), rng.randint(1, 20))
            ho = -(nrm[j] * hj + nrm[l] * hl) / nrm[o]
            h0 = [None] * 3; h0[o] = ho; h0[j] = hj; h0[l] = hl
            for s in (+1, -1):
                h = tuple(h0[i] + s * eta * nrm[i] * (abs(ho) + hj + hl) for i in range(3))
                try:
                    pos, marg = position(K, h); attribution(h)
                except (ValueError, AssertionError):
                    continue
                for b in POS:
                    if b != pos:
                        out.append((h, pos, b))
    return out

if __name__ == '__main__':
    plist = [(Fr(17, 50), Fr(33, 100), Fr(33, 100)), (Fr(101, 300), Fr(67, 200), Fr(197, 600)),
             (Fr(1, 3) + Fr(2, 3000), Fr(1, 3) - Fr(1, 3000), Fr(1, 3) - Fr(1, 3000))]
    for p in plist:
        assert sum(p) == 1
        K = posterior_pts(p)
        rng = random.Random(3)
        cand = mismatch_points(p, K) + boundary_points(p, K, rng)
        deltas = [tuple(x - y for x, y in zip(F(h, b), F(h, pos))) for (h, pos, b) in cand]
        cert = certificate(deltas)
        tag = tuple(str(x) for x in p)
        if cert is None:
            print(f"p={tag}: {len(deltas)} deltas, NO certificate"); continue
        lam, comb = cert
        ok = all(c < 0 for c in comb)
        for k in lam:
            h, pos, b = cand[k]
            pos2, marg = position(K, h)
            o = odd(h); j, l = [i for i in range(3) if i != o]
            ok &= (pos2 == pos and marg > 0 and h[j] != h[l])
        print(f"p={tag}: certificate verified={ok}  (terms {len(lam)}, from {len(deltas)} deltas)")
        for k, l in lam.items():
            h, pos, b = cand[k]
            print(f"   h={tuple(str(x) for x in h)}  C_p:{pos}->{b}  delta={tuple(str(x) for x in deltas[k])}  lam={l}")
        print(f"   sum lam*delta = {tuple(str(x) for x in comb)}")
