# FF1: exact (IB)+transitivity closure of selected ties on a binary cell arrangement.
#
# On a binary arrangement (every active cell has acting advice a_c in {+,-} and the listed models give a_c or
# silence there), a transition record between such models is a vector x in {-1,0,1}^cells (x_c = +1:
# silence -> a_c, -1: a_c -> silence, 0: identity, context free).  Two records compose when their arrows match at
# the middle advice wherever both are nontrivial; for such vectors this is exactly "x + y in {-1,0,1}^cells", and
# the composite is x + y.  Where x_c = -y_c != 0 the composite is the identity, so (IB) transports it to EVERY
# common advice on c (cancelled changes).  Hence the record set of the least (IB)-closed equivalence containing
# the generators is the closure T of {0} U {+-g} under partial addition inside the cube.  Computed exactly
# (integer arithmetic) by saturation over all pairs.
import numpy as np

def ternary_closure(gens, limit=2_000_000):
    gens = [np.array(g, dtype=np.int8) for g in gens]
    n = len(gens[0])
    T = {}
    def add(v):
        k = v.tobytes()
        if k in T: return False
        T[k] = v; return True
    add(np.zeros(n, dtype=np.int8))
    frontier = []
    for g in gens:
        for s in (g, -g):
            if add(s.copy()): frontier.append(s.copy())
    allel = list(T.values())
    while frontier:
        M = np.array(allel)
        new = []
        for x in frontier:
            S = M + x
            ok = np.all((S >= -1) & (S <= 1), axis=1)
            for row in S[ok]:
                if add(row): new.append(row)
            if len(T) > limit: return None
        allel.extend(new)
        frontier = new
    return T

def sequential_closure(gens, limit=2_000_000):
    """closure under adding single generators only (no composite of composites): the realizable chains of
    generator transports from a fixed record; differs from T exactly when cancelled-change composites matter"""
    gens = [np.array(g, dtype=np.int8) for g in gens]
    G = np.array([s for g in gens for s in (g, -g)])
    n = len(gens[0])
    T = {}
    z = np.zeros(n, dtype=np.int8); T[z.tobytes()] = z
    frontier = [z]
    while frontier:
        new = []
        for x in frontier:
            S = G + x
            ok = np.all((S >= -1) & (S <= 1), axis=1)
            for row in S[ok]:
                k = row.tobytes()
                if k not in T: T[k] = row; new.append(row)
        if len(T) > limit: return None
        frontier = new
    return T
