# FF1: additive invariants on a cell arrangement (exact rational certificates).
#
# Cells may carry any of +, 0, - for the listed (coherent) models.  An additive world-i loss is fixed by
# psi_c(0) = 0, psi_c(+) = -a_c, psi_c(-) = -b_c on each cell (psi_c(x) any value above the bad advice), and
# L(X) = sum_c psi_c(X(c)) on cell-measurable models; with the per-cell penalty psi_c / mu(c) it is a bounded,
# strictly guiding additive ranking on the FULL domain (mu(c) > 0: merged cells are finite unions of non-null
# open cones).  Strict guidance at world i:  tau_c a_c > 0 and tau_c b_c < 0, tau_c = sign(h_i) on cell c.
from fractions import Fraction as F
import numpy as np
from scipy.optimize import linprog

VAL = {'+': (1, 0), '0': (0, 0), '-': (0, 1)}

def act_state(A, c):
    s = set(A.cls[c]) - {'0'}
    assert len(s) == 1, "cell is not binary"
    return s.pop()

def s_sign(A, c, i):
    """binary cells: +1 iff the acting advice of cell c is good at world i"""
    a = act_state(A, c)
    return 1 if ((a == '+') == (A.sg[c][i] > 0)) else -1

def vec(A, a, b, cells=None):
    """binary cells: record vector of rec(C_a, C_b) in {-1,0,1} (+1: silence -> acting advice)"""
    cells = A.active if cells is None else cells
    out = []
    for c in cells:
        x, y = A.cls[c][a], A.cls[c][b]
        out.append(0 if x == y else (1 if x == '0' else -1))
    return out

def vec2(A, a, b, cells=None):
    """general cells: (Delta+, Delta-) per cell, flattened [d+_c0, d-_c0, d+_c1, ...]"""
    cells = A.active if cells is None else cells
    out = []
    for c in cells:
        x, y = VAL[A.cls[c][a]], VAL[A.cls[c][b]]
        out += [y[0]-x[0], y[1]-x[1]]
    return out

def independent_rows(rows):
    basis = []; keep = []
    for idx, r in enumerate(rows):
        v = [F(x) for x in r]
        for piv, b in basis:
            if v[piv] != 0:
                f = v[piv] / b[piv]
                v = [vi - f*bi for vi, bi in zip(v, b)]
        nz = [k for k, x in enumerate(v) if x != 0]
        if nz:
            basis.append((nz[0], v)); keep.append(idx)
    return keep

def solve_exact(Mat, rhs):
    n = len(Mat)
    M = [[F(x) for x in row] + [F(r)] for row, r in zip(Mat, rhs)]
    for col in range(n):
        piv = next(r for r in range(col, n) if M[r][col] != 0)
        M[col], M[piv] = M[piv], M[col]
        pv = M[col][col]
        M[col] = [x/pv for x in M[col]]
        for r in range(n):
            if r != col and M[r][col] != 0:
                f = M[r][col]
                M[r] = [a - f*b for a, b in zip(M[r], M[col])]
    return [M[r][n] for r in range(n)]

def project_exact(G, w):
    if not G: return w
    GGt = [[sum(F(a)*F(b) for a, b in zip(r1, r2) if a and b) for r2 in G] for r1 in G]
    Gw = [sum(F(a)*x for a, x in zip(r, w) if a) for r in G]
    lam = solve_exact(GGt, Gw)
    return [w[k] - sum(lam[j]*G[j][k] for j in range(len(G)) if G[j][k]) for k in range(len(w))]

def invariant(A, i, strict_tier=False, margin=1.0):
    """Exact rational additive world-i loss on arrangement A with
         strict guidance;  L(C_p) = L(C_q) whenever p_i = q_i (listed models);
         (strict_tier) L(C_p) < L(C_q) whenever p_i > q_i.
       Returns (ell, report); ell = [a_c0, b_c0, a_c1, b_c1, ...] or None."""
    cells = A.active; N = len(cells)
    tau = [A.sg[c][i] for c in cells]
    sgnvec = []
    for t in tau: sgnvec += [t, -t]          # required sign of a_c and of b_c
    # loss change of record vector d = (d+, d-):  sum_c -(a_c d+_c + b_c d-_c)
    ties = A.ties(i)
    G = [vec2(A, a, b) for a, b in ties]
    keep = independent_rows(G) if G else []
    G = [G[k] for k in keep]
    A_ub = []; b_ub = []
    for k in range(2*N):
        row = np.zeros(2*N); row[k] = -sgnvec[k]; A_ub.append(row); b_ub.append(-margin)
    S = []
    if strict_tier:
        for a, b in A.strict_pairs(i):     # p_a[i] > p_b[i]:  L(C_b) - L(C_a) = -<ell, d(a->b)> >= margin
            d = vec2(A, a, b); S.append(d)
            A_ub.append(np.array(d, dtype=float)); b_ub.append(-margin)
    res = linprog(np.zeros(2*N), A_ub=np.array(A_ub), b_ub=np.array(b_ub),
                  A_eq=np.array(G, dtype=float) if G else None, b_eq=np.zeros(len(G)) if G else None,
                  bounds=[(None, None)]*(2*N), method='highs')
    if res.status != 0:
        return None, f"LP infeasible/failed (status {res.status})"
    w = [F(round(x*10**6), 10**6) for x in res.x]
    w = project_exact(G, w)
    ok_sign = all(w[k]*sgnvec[k] > 0 for k in range(2*N))
    ok_eq = all(sum(F(a)*x for a, x in zip(r, w) if a) == 0 for r in G)
    ok_strict = all(sum(F(a)*x for a, x in zip(r, w) if a) < 0 for r in S)
    good = ok_sign and ok_eq and ok_strict
    return (w if good else None), \
        f"exact: guidance-signs {ok_sign}, ties exact {ok_eq}, strict monotone {ok_strict} " \
        f"[{N} cells, {len(ties)} tie pairs (rank {len(G)}), {len(S)} strict pairs]"
