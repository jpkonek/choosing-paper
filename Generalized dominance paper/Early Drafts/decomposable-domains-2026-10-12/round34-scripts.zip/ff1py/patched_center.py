# FF1: patched family near the bump centre q2, where K_p = K_2 + O(|p-q2|^2) and the leading deviation is radial
# (beta = (1-s^2)^2 is stationary at q2).  Hexagonal fragments at q2 with small steps; exact witnesses for all worlds.
import sys, os, time; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from patched import PatchedArrangement, beta, q2, F
from arr import tri_grid
from lin import invariant
for name, pts in [("hexagon R=2 at q2, step 1/400", tri_grid(q2, F(1,400), 2)),
                  ("hexagon R=3 at q2, step 1/600", tri_grid(q2, F(1,600), 3))]:
    t = time.time(); A = PatchedArrangement(pts)
    print(f"== {name}: {len(A.pts)} models (all in the bump, min beta {float(min(beta(p) for p in A.pts)):.4f}), "
          f"{len(A.active)} active cells ({time.time()-t:.0f}s)")
    for i in range(3):
        for st in (False, True):
            w, rep = invariant(A, i, strict_tier=st)
            print(f"   world {i+1} {'stronger tier' if st else 'tie tier    '}: witness {'FOUND' if w else 'NOT found'}; {rep}")
    sys.stdout.flush()
