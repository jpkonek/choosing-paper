# FF1: exact additive witnesses for the tie tier and the stronger tier on finite fragments of the plain posterior
# family.  For each fragment and world i, an exact rational strictly guiding additive loss with
#   L_i(C_p) = L_i(C_q) when p_i = q_i   and   L_i(C_p) < L_i(C_q) when p_i > q_i   (listed models).
# By the argument of FF1 section 3 such a loss exists for EVERY finite fragment; this script checks instances.
import sys, os, time; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from arr import *; from lin import *
u = (F(1,3),)*3
def grid(n):
    return [(F(a,n),F(b,n),F(n-a-b,n)) for a in range(n+1) for b in range(n+1-a)]
frags = [
  ("hexagon R=2 at u, step 1/100", tri_grid(u, F(1,100), 2), F(3,10)),
  ("hexagon R=3 at u, step 1/200", tri_grid(u, F(1,200), 3), F(3,10)),
  ("hexagon R=2 at (1/5,3/5,1/5), step 1/100", tri_grid((F(1,5),F(3,5),F(1,5)), F(1,100), 2), F(3,10)),
  ("whole simplex grid (1/6)Z^3, boundary and vertices included", grid(6), F(3,10)),
  ("hexagon R=2 at u, step 1/100, eps=1/10", tri_grid(u, F(1,100), 2), F(1,10)),
  ("hexagon R=2 at u, step 1/50, eps=1/2", tri_grid(u, F(1,50), 2), F(1,2)),
  ("whole simplex grid (1/5)Z^3, eps=1/20", grid(5), F(1,20)),
]
for name, pts, eps in frags:
    t = time.time(); A = Arrangement(pts, eps)
    kinds = sorted({''.join(sorted(set(A.cls[c]))) for c in A.active})
    print(f"== {name}; eps={eps}: {len(A.pts)} selected models, {len(A.active)} active cells, cell kinds {kinds} "
          f"({time.time()-t:.0f}s)")
    for i in range(3):
        for st in (False, True):
            w, rep = invariant(A, i, strict_tier=st)
            print(f"   world {i+1} {'stronger tier' if st else 'tie tier    '}: witness {'FOUND' if w else 'NOT found'}; {rep}")
    sys.stdout.flush()
