# FF1: the tie test on fragments of a PATCHED family (DD1 design, with the irrational bump centre q_2 replaced by the
# rational point q2 = (1/3, 1/3 + 53/1250, 1/3 - 53/1250), |q2 - q_2| < 3e-5; bump radius rho = 1/40; beta = (1-s^2)^2).
# K_p = (1-beta(p)) K_p^0 + beta(p) K_2 inside bump 2 (K_2 = DD1 seed set), K_p = K_p^0 outside.  Exact rationals.
# Only bump-2 and posterior points are used, so the other two bumps play no role in these fragments.
#   (1) exact additive witnesses (tie tier and stronger tier) per world;
#   (2) exact closures T_i of the ties on binary fragments, searching (G)- and (C)-certificates directly.
import sys, os, time; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from arr import *; from lin import *; from closure import *
eps = F(3,10); T = make_T(eps)
K2 = [(F(1,5),F(11,60)), (F(19,30),F(3,20)), (F(17,60),F(8,15)), (F(73,300),F(77,150))]   # DD1 K_2 (2-D coords)
q2 = (F(1,3), F(1,3)+F(53,1250), F(1,3)-F(53,1250)); rho = F(1,40)
def hull2(P):
    pts = sorted(set(P))
    if len(pts) <= 2: return pts
    def cr(o,a,b): return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    lo=[]; up=[]
    for p in pts:
        while len(lo)>=2 and cr(lo[-2],lo[-1],p)<=0: lo.pop()
        lo.append(p)
    for p in reversed(pts):
        while len(up)>=2 and cr(up[-2],up[-1],p)<=0: up.pop()
        up.append(p)
    return lo[:-1]+up[:-1]
def beta(p):
    s2 = sum((p[i]-q2[i])**2 for i in range(3))/rho**2
    return (1-s2)**2 if s2 < 1 else F(0)
def Kpatched(p):
    P0 = post2(p, T); b = beta(p)
    if b == 0: return P0
    return hull2([((1-b)*a[0]+b*c[0], (1-b)*a[1]+b*c[1]) for a in P0 for c in K2])
class PatchedArrangement(Arrangement):
    def __init__(self, pts):
        self.eps = eps; self.T = T
        self.pts = [tuple(F(x) for x in p) for p in pts]
        self.polys = [Kpatched(p) for p in self.pts]
        cd = cells(self.polys)
        self.keys = sorted(cd.keys()); self.reps = [cd[k] for k in self.keys]
        self.cls = [k[0] for k in self.keys]; self.sg = [k[1] for k in self.keys]; self.N = len(self.keys)
        self.active = [c for c in range(self.N) if len(set(self.cls[c])) > 1]
if __name__ == '__main__':
    u = (F(1,3),)*3
    frags = [
      ("level line p_1=1/3 through u and q2, 9 points (6 in the bump)",
         [u] + [(F(1,3), F(1,3)+F(k,200), F(1,3)-F(k,200)) for k in (2,4,6,7,8,9,10,11)]),
      ("hexagon R=2 at q2, step 1/200 (all in the bump) + u", [u] + tri_grid(q2, F(1,200), 2)),
      ("hexagon R=1 at q2 step 1/100, hexagon R=1 at u step 1/100, plus level-line points", 
         tri_grid(q2, F(1,100), 1) + tri_grid(u, F(1,100), 1) + [(F(1,3), F(1,3)+F(k,200), F(1,3)-F(k,200)) for k in (3,5,7,9,11)]),
    ]
    for name, pts in frags:
        pts = list(dict.fromkeys(pts))
        t = time.time(); A = PatchedArrangement(pts)
        inb = sum(1 for p in A.pts if beta(p) > 0)
        kinds = sorted({''.join(sorted(set(A.cls[c]))) for c in A.active})
        print(f"== {name}: {len(A.pts)} models ({inb} inside the bump), {len(A.active)} active cells, kinds {kinds} ({time.time()-t:.0f}s)")
        for i in range(3):
            for st in (False, True):
                w, rep = invariant(A, i, strict_tier=st)
                print(f"   world {i+1} {'stronger tier' if st else 'tie tier    '}: witness {'FOUND' if w else 'NOT found'}; {rep}")
        if kinds and all(len(k) == 2 and '0' in k for k in kinds):
            cells_ = A.active
            sgn = [np.array([s_sign(A,c,i) for c in cells_], dtype=np.int8) for i in range(3)]
            acts = [np.array([1 if A.cls[c][m] != '0' else 0 for c in cells_], dtype=np.int8) for m in range(len(A.pts))]
            Ts = []
            for i in range(3):
                gens = [tuple(vec(A,a,b)) for a,b in A.ties(i)]
                if not gens: Ts.append({np.zeros(len(cells_),dtype=np.int8).tobytes(): None}); print(f"   world {i+1}: no ties"); continue
                Tcl = ternary_closure(gens, limit=1_000_000)
                if Tcl is None: print(f"   world {i+1}: closure too large"); Ts.append(None); continue
                imp = sum(1 for v in Tcl.values() if v.any() and np.all(v*sgn[i] >= 0))
                print(f"   world {i+1}: |T| = {len(Tcl)}, weakly improving nonzero records: {imp}")
                Ts.append(Tcl)
            if all(x is not None for x in Ts):
                common = set(Ts[0]) & set(Ts[1]) & set(Ts[2])
                hits = 0
                for k in common:
                    v = np.frombuffer(k, dtype=np.int8)
                    if not v.any(): continue
                    for m in range(len(A.pts)):
                        if np.all((v == 0) | ((v == 1) & (acts[m] == 0)) | ((v == -1) & (acts[m] == 1))): hits += 1
                print(f"   |T_1&T_2&T_3| = {len(common)}; nonzero ones realisable at a selected model: {hits}")
        sys.stdout.flush()
