# FF1: the decisive tie test computed exactly on finite fragments (binary cell arrangements).
#  Tie tier:  T_i = (IB)+transitivity closure of the selected ties C_p ~_i C_q (p_i = q_i), INCLUDING composites
#             whose changes cancel on cells (transported to every common advice there).
#             (G)-certificate = nonzero record in T_i weakly improving world i everywhere;
#             (C)-certificate = nonzero record in T_1 & T_2 & T_3 realisable at a selected model (then the image is
#             a model tied at all three worlds with that selected model; incoherence is checked if one is found).
#  Stronger tier (selected layer): A_i = closure of {rec(C_a,C_b): a_i >= b_i}; checks (F1), (F2) and that
#             A_i & -A_i = T_i (no strict cycle).  Guidance records are covered by the additive witnesses
#             (invariants.py); this closure is the purely selected part, computed exactly.
import sys, os, time; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from arr import *; from lin import *; from closure import *
u = (F(1,3),)*3
def run(name, pts, eps=F(3,10), ordered=True):
    A = Arrangement(pts, eps)
    cells_ = A.active
    print(f"== {name}: {len(A.pts)} models, {len(cells_)} active cells (all binary)")
    sgn = [np.array([s_sign(A,c,i) for c in cells_], dtype=np.int8) for i in range(3)]
    acts = [np.array([1 if A.cls[c][m] != '0' else 0 for c in cells_], dtype=np.int8) for m in range(len(A.pts))]
    Ts = []
    for i in range(3):
        gens = [tuple(vec(A,a,b)) for a,b in A.ties(i)]
        t = time.time(); T = ternary_closure(gens); S = sequential_closure(gens)
        imp = sum(1 for v in T.values() if v.any() and np.all(v*sgn[i] >= 0))
        print(f"   world {i+1}: {len(gens)} tie generators; |T_{i+1}| = {len(T)}; reachable by single-generator chains: {len(S)};"
              f" obtainable only via cancelled-change composites: {len(set(T)-set(S))}; weakly improving nonzero: {imp} ({time.time()-t:.1f}s)")
        Ts.append(T)
    common = set(Ts[0]) & set(Ts[1]) & set(Ts[2])
    print(f"   |T_1 & T_2 & T_3| = {len(common)} (including the identity)")
    hits = []
    for k in common:
        v = np.frombuffer(k, dtype=np.int8)
        if not v.any(): continue
        for m in range(len(A.pts)):
            if np.all((v == 0) | ((v == 1) & (acts[m] == 0)) | ((v == -1) & (acts[m] == 1))): hits.append((m, v))
    print(f"   nonzero three-world records realisable at some selected model: {len(hits)}")
    if ordered:
        for i in range(3):
            gens = [tuple(vec(A,a,b)) for a,b in A.ties(i)]
            ups = [np.array(vec(A,a,b), dtype=np.int8) for a,b in A.strict_pairs(i)]  # C_a <=_i C_b, a_i > b_i
            t = time.time()
            Acl = ternary_closure_mixed(gens, ups)
            if Acl is None: print(f"   world {i+1} ordered closure: too large"); continue
            F1 = sum(1 for v in ups if (-v).tobytes() in Acl)
            F2 = sum(1 for v in Acl.values() if v.any() and np.all(v*sgn[i] >= 0))
            both = sum(1 for k, v in Acl.items() if (-v).tobytes() in Acl and k not in Ts[i])
            print(f"   world {i+1} ordered closure |A_{i+1}| = {len(Acl)}: (F1) reversed strict pairs: {F1}; (F2) improving: {F2};"
                  f" two-way accepted outside T_{i+1}: {both} ({time.time()-t:.1f}s)")
    sys.stdout.flush()
    return A, Ts

def ternary_closure_mixed(sym, oneway, limit=3_000_000):
    """closure of {0} U {+-g : g in sym} U oneway under partial addition in the cube"""
    gens = []
    for g in sym:
        g = np.array(g, dtype=np.int8); gens += [g, -g]
    gens += [np.array(g, dtype=np.int8) for g in oneway]
    n = len(gens[0]); T = {}
    def add(v):
        k = v.tobytes()
        if k in T: return False
        T[k] = v; return True
    add(np.zeros(n, dtype=np.int8))
    frontier = [g.copy() for g in gens if add(g.copy())]
    allel = list(T.values())
    while frontier:
        M = np.array(allel); new = []
        for x in frontier:
            Ssum = M + x
            ok = np.all((Ssum >= -1) & (Ssum <= 1), axis=1)
            for row in Ssum[ok]:
                if add(row): new.append(row)
            if len(T) > limit: return None
        allel.extend(new); frontier = new
    return T

run("hexagon R=1 at u, step 1/100", tri_grid(u, F(1,100), 1))
run("hexagon R=2 at u, step 1/100", tri_grid(u, F(1,100), 2))
run("hexagon R=2 at (1/5,3/5,1/5) (EE2 splice level line), step 1/100", tri_grid((F(1,5),F(3,5),F(1,5)), F(1,100), 2))
run("hexagon R=2 at u, step 1/50, eps=1/10", tri_grid(u, F(1,50), 2), eps=F(1,10))
