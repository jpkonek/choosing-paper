# FF1: exact check of the structural input of the survival theorem (FF1 Lemma 3.1) for the plain posterior family.
#   C_p accepts the gamble g  iff  (p.g).v_k > 0 for k=1,2,3, or p.g >= 0, p.g != 0     (p.g = coordinatewise product)
# (a) for c in (0,1), g_c = (-gamma, 1, 1), gamma = c0(1-c)/((c0+eps)c):   {p in Delta : C_p accepts g_c} = {p_1 < c};
# (b) tilting about a pivot z on {p_1 = c} (w' = v_1.g_c + t(0, z_3, -z_2), g' = w'/v_1) gives
#     {p_1 < c} U {p on the level with p_2/p_3 > z_2/z_3}  (t > 0)   or   ... < z_2/z_3 (t < 0);  g'_1 < 0 (bad at world 1);
# (c) level c = 0: g' = (-1, eta_2, eta_3) with eta_2 > 0 > eta_3 (or reverse) small accepts exactly the edge points with
#     p_2/p_3 > (c0+eps)rho/c0  (rho = -eta_3/eta_2), resp. (eta_2 < 0 < eta_3) p_2/p_3 < c0 eta_3/((c0+eps)|eta_2|),
#     and no point with p_1 > 0 of the grid.
# Checked on every point of the grid Delta cap (1/n)Z^3 (boundary and vertices included), for several eps and n.
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from arr import make_T
def accepts(p, g, T):
    pg = [p[i]*g[i] for i in range(3)]
    if all(x >= 0 for x in pg) and any(x != 0 for x in pg): return True
    return all(sum(pg[i]*v[i] for i in range(3)) > 0 for v in T)
def grid(n): return [(F(a,n),F(b,n),F(n-a-b,n)) for a in range(n+1) for b in range(n+1-a)]
tot = 0; bad = 0
for eps in (F(1,20), F(3,10), F(1,2), F(9,10)):
    T = make_T(eps); c0 = (1-eps)/3; v1 = T[0]
    for n in (7, 12):
        S = grid(n)
        levels = sorted({p[0] for p in S})
        cs = set(levels) | {(levels[k]+levels[k+1])/2 for k in range(len(levels)-1)}
        for c in sorted(cs):
            if not (0 < c < 1): continue
            gam = c0*(1-c)/((c0+eps)*c); g = (-gam, F(1), F(1))
            acc = {p for p in S if accepts(p, g, T)}
            tot += 1; bad += acc != {p for p in S if p[0] < c}
            lev = sorted([p for p in S if p[0] == c], key=lambda p: (p[1], -p[2]))
            # pivots between consecutive level points
            w = [v1[i]*g[i] for i in range(3)]
            gap = min([abs(c - p[0]) for p in S if p[0] != c] + [F(1)])
            for k in range(len(lev)-1):
                a, b = lev[k], lev[k+1]
                z = ((a[0]+b[0])/2, (a[1]+b[1])/2, (a[2]+b[2])/2)
                for sgn in (1, -1):
                    t = sgn*gap*c0/(1000*(1+gam))
                    wp = [w[0], w[1]+t*z[2], w[2]-t*z[1]]
                    gp = tuple(wp[i]/v1[i] for i in range(3))
                    acc = {p for p in S if accepts(p, gp, T)}
                    side = {p for p in lev if (p[1]*z[2] > p[2]*z[1]) == (sgn > 0)}
                    tot += 1; bad += (acc != ({p for p in S if p[0] < c} | side)) or not (gp[0] < 0)
        # level 0
        edge = sorted([p for p in S if p[0] == 0], key=lambda p: (p[1], -p[2]))
        pos = min(p[0] for p in S if p[0] > 0)
        for k in range(len(edge)-1):
            a, b = edge[k], edge[k+1]
            # choose threshold r* strictly between the ratios of a and b
            ra = a[1]/a[2] if a[2] else None; rb = b[1]/b[2] if b[2] else None
            rstar = (ra + rb)/2 if rb is not None else ra + 1
            if ra == 0: rstar = rb/2 if rb is not None else F(1)
            for sgn in (1, -1):
                eta = pos*c0/(100*(c0+eps))
                if sgn > 0:   # p2/p3 > rstar :  (c0+eps) rho / c0 = rstar
                    rho = rstar*c0/(c0+eps); g = (F(-1), eta, -rho*eta)
                    want = {p for p in edge if (p[2] == 0) or p[1]/p[2] > rstar}
                else:         # mirror: eta_2 < 0 < eta_3; binding constraint 2: p2/p3 < c0/((c0+eps) rho) = rstar
                    rho = c0/((c0+eps)*rstar)
                    g = (F(-1), -eta, eta/rho)
                    want = {p for p in edge if p[1] == 0 or (p[2] != 0 and p[1]/p[2] < rstar)}
                acc = {p for p in S if accepts(p, g, T)}
                tot += 1; bad += acc != want
print(f"checked {tot} (problem, grid, eps) instances: {bad} failures")
