# FF1: exact cell arrangement for a finite list of selected models of the plain posterior family
# (copied and adapted from ee2py/cells.py; nothing there is modified).
#
# A problem (pair {g,-g}) is represented by its orientation with g_1 > 0 (the write-up's H).  Problems are
# parametrised up to positive scale by (theta, c):  g = (theta1 - c, theta2 - c, -c);  for m in aff(Delta) with
# 2-D coordinates (m1, m2),  m.g = theta.m - c.  A credal polygon K accepts g iff c < min_K theta.m, rejects g iff
# c > max_K theta.m, and is silent otherwise.  Cells: open arcs of theta between consecutive critical directions,
# times open c-intervals between consecutive breakpoints.  On every open cell all classes and all signs are constant;
# the cells are non-null open cones and their union is conull.  Cells with the same column (classes of all listed
# models, sign pattern) are merged: a merged cell is a finite union of non-null open cones.
from fractions import Fraction as F
import itertools, functools

def perp(v): return (-v[1], v[0])
def half(d): return 0 if (d[1] > 0 or (d[1] == 0 and d[0] > 0)) else 1
def cross(a, b): return a[0]*b[1] - a[1]*b[0]
def cmpang(a, b):
    ha, hb = half(a), half(b)
    if ha != hb: return -1 if ha < hb else 1
    c = cross(a, b)
    return -1 if c > 0 else (1 if c < 0 else 0)
DELTA2 = [(F(1), F(0)), (F(0), F(1)), (F(0), F(0))]

def arc_reps(points):
    dirs = [(F(1), F(0)), (F(0), F(1)), (F(-1), F(0)), (F(0), F(-1))]
    pts = list(set(points))
    for a, b in itertools.combinations(pts, 2):
        v = (a[0]-b[0], a[1]-b[1])
        q = perp(v); dirs += [q, (-q[0], -q[1])]
    dirs.sort(key=functools.cmp_to_key(cmpang))
    cd = []
    for d in dirs:
        if cd and cmpang(cd[-1], d) == 0: continue
        cd.append(d)
    n = len(cd)
    return [(cd[i][0]+cd[(i+1) % n][0], cd[i][1]+cd[(i+1) % n][1]) for i in range(n)]

def cells(polys, keep_rep=False):
    """Return dict key=(classes, signs) -> a representative (theta, c), over problems with g_1 > 0."""
    pts = [p for P in polys for p in P] + DELTA2
    out = {}
    for th in arc_reps(pts):
        lo = [min(th[0]*x+th[1]*y for x, y in P) for P in polys]
        hi = [max(th[0]*x+th[1]*y for x, y in P) for P in polys]
        bps = sorted(set(lo + hi + [th[0], th[1], F(0)]))
        reps = [bps[0]-1] + [(bps[k]+bps[k+1])/2 for k in range(len(bps)-1)] + [bps[-1]+1]
        for c in reps:
            g = (th[0]-c, th[1]-c, -c)
            if g[0] < 0: continue          # index each pair once, by its orientation with g_1 > 0
            sg = tuple(1 if x > 0 else -1 for x in g)
            cls = tuple('+' if c < lo[k] else ('-' if c > hi[k] else '0') for k in range(len(polys)))
            key = (cls, sg)
            if key not in out: out[key] = (th, c)
    return out

def rank(adv, sg, i):
    """world-i rank of an advice on a problem with sign pattern sg: good 0 < none 1 < bad 2 < contradictory 3"""
    if adv == '0': return 1
    if adv == 'x': return 3
    return 0 if ((adv == '+') == (sg[i] > 0)) else 2

def make_T(eps):
    c0 = (1-eps)/3
    return [[c0 + (eps if i == k else 0) for i in range(3)] for k in range(3)]

def post3(p, T):
    out = []
    for v in T:
        w = [F(p[i])*v[i] for i in range(3)]; t = sum(w); out.append([x/t for x in w])
    return out
def post2(p, T): return [(m[0], m[1]) for m in post3(p, T)]

class Arrangement:
    """Selected models C_p (p in pts) of the plain posterior family for T = T1(eps); merged cells."""
    def __init__(self, pts, eps=F(3, 10)):
        self.eps = eps; self.T = make_T(eps)
        self.pts = [tuple(F(x) for x in p) for p in pts]
        assert all(sum(p) == 1 and min(p) >= 0 for p in self.pts)
        self.polys = [post2(p, self.T) for p in self.pts]
        cd = cells(self.polys)
        self.keys = sorted(cd.keys())
        self.reps = [cd[k] for k in self.keys]
        self.cls = [k[0] for k in self.keys]      # cls[c][m] = advice of model m on cell c
        self.sg = [k[1] for k in self.keys]
        self.N = len(self.keys)
        # drop cells on which all listed models agree (inert: every generated record is the identity there)
        self.active = [c for c in range(self.N) if len(set(self.cls[c])) > 1]

    def index(self, p):
        return self.pts.index(tuple(F(x) for x in p))

    def record(self, a, b):
        """transition record rec(C_a, C_b) as dict cell -> (from, to) on its support"""
        return {c: (self.cls[c][a], self.cls[c][b]) for c in range(self.N) if self.cls[c][a] != self.cls[c][b]}

    def ties(self, i):
        """unordered selected pairs (a, b), a < b, with p_a[i] == p_b[i]"""
        n = len(self.pts)
        return [(a, b) for a in range(n) for b in range(a+1, n) if self.pts[a][i] == self.pts[b][i]]

    def strict_pairs(self, i):
        """ordered pairs (a, b) with p_a[i] > p_b[i]:  the scheme's C_a <_i C_b"""
        n = len(self.pts)
        return [(a, b) for a in range(n) for b in range(n) if self.pts[a][i] > self.pts[b][i]]

def tri_grid(center, delta, R, hexagon=True):
    """points center + delta*(a, b, -a-b) for integers a, b with hexagonal radius <= R"""
    out = []
    for a in range(-R, R+1):
        for b in range(-R, R+1):
            cc = -a-b
            if hexagon and max(abs(a), abs(b), abs(cc)) > R: continue
            p = (F(center[0]) + delta*a, F(center[1]) + delta*b, F(center[2]) + delta*cc)
            if min(p) < 0: continue
            out.append(p)
    return out
