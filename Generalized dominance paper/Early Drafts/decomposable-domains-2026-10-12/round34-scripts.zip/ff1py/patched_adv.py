# FF1: adversarial fragments of the patched family for world 1: several level lines p_1 = const crossing bump 2,
# with points inside (large beta) and outside the bump.  Exact additive-witness LP (tie tier, stronger tier).
import sys, os, time; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from patched import PatchedArrangement, beta, q2, F
from lin import invariant
designs = {
 "A: levels 1/3-1/100, 1/3, 1/3+1/100; p_2-offsets 0..7/100": 
    [(F(1,3)+a, F(1,3)-a/2+F(k,100), F(1,3)-a/2-F(k,100)) for a in (F(-1,100),F(0),F(1,100)) for k in range(0,8)],
 "B: levels 1/3-1/60 .. 1/3+1/60 (5 levels), offsets 1/40..3/40":
    [(F(1,3)+a, F(1,3)-a/2+F(k,200), F(1,3)-a/2-F(k,200)) for a in (F(-1,60),F(-1,120),F(0),F(1,120),F(1,60)) for k in (0,4,6,8,10,12,14)],
}
for name, pts in designs.items():
    t = time.time(); A = PatchedArrangement(pts)
    inb = sum(1 for p in A.pts if beta(p) > 0)
    print(f"== {name}: {len(A.pts)} models ({inb} in bump), {len(A.active)} active cells ({time.time()-t:.0f}s)")
    for st in (False, True):
        w, rep = invariant(A, 0, strict_tier=st)
        print(f"   world 1 {'stronger tier' if st else 'tie tier    '}: witness {'FOUND' if w else 'NOT found'}; {rep}")
    sys.stdout.flush()
