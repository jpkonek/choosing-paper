# (NC) upper bounds U_i(c) for transition-zone sets K_c of the patched family against posterior partners,
# compared with c_i.  NUMERICS (grid).  Design: D (centre offset from u), rho (bump radius).
import sys,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import math, geom
from family import *
D=float(sys.argv[1]); rho=float(sys.argv[2]); N=int(sys.argv[3])
Fm=default_family(D,rho)
R=1.6; g=[-R+2*R*t/(N-1) for t in range(N)]
def pt(a,b):
    p=[1.0,math.exp(a),math.exp(b)]; s=sum(p); return [x/s for x in p]
pts=[pt(a,b) for a in g for b in g]
pts=[p for p in pts if max(Fm.betas(p))==0]           # unpatched partners only
Ps=[postf(p) for p in pts]
def tang(a,r): return [r*math.cos(a)*math.sqrt(2/3), r*math.cos(a-2*math.pi/3)*math.sqrt(2/3), r*math.cos(a+2*math.pi/3)*math.sqrt(2/3)]
le=geom.le_o_fast
worst=9
for k,q in enumerate(Fm.qs):
    for f,a in ((0.0,0),(0.5,0.5),(0.5,2.6),(0.5,4.7),(0.85,1.5),(0.85,3.6),(0.85,5.7)):
        c=[q[i]+tang(a,f*rho)[i] for i in range(3)]; Kc=Fm.K(c)
        for i in range(3):
            j,l=[x for x in range(3) if x!=i]
            Aj=[(p,P) for p,P in zip(pts,Ps) if le(Kc,P,i) and le(P,Kc,j)]
            Al=[(p,P) for p,P in zip(pts,Ps) if le(Kc,P,i) and le(P,Kc,l)]
            best=-1
            for pj,_ in Aj:
                for pl,_ in Al:
                    v=pj[j]+pl[l]
                    if v>best and pj[j]/pj[i]<=pl[j]/pl[i] and pj[j]/pj[l]<=pl[j]/pl[l] and pl[l]/pl[i]<=pj[l]/pj[i] and pl[l]/pl[j]<=pj[l]/pj[j]:
                        best=v
            U=1-best if best>=0 else float('inf')
            worst=min(worst,U-c[i])
            print(f"bump {k+2} r/rho={f} slot {i+1}: c_i={c[i]:.4f} U={U:.4f} margin={U-c[i]:+.4f}",flush=True)
print("minimum margin U_i(c)-c_i over tested transition points:",worst)
