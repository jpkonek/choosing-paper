# Exact certificates for the (NC) windows of the designated indices.
# For K_k in slot i and posterior sets K_{p^j}, K_{p^l} in the other slots, an exactly compatible triple
# certifies (Theorem NC)  (q_k)_i < 1 - p^j_j - p^l_l.  We refine the float optimum on a rational grid.
import sys,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from geom import *
import itertools
def rat(x,d=2000): return F(round(x*d),d)
def ptz(z):  # p ∝ (1,e^a,e^b) approximated rationally
    import math
    p=[1.0,math.exp(z[0]),math.exp(z[1])]; s=sum(p); p=[x/s for x in p]
    q=[rat(p[0]),rat(p[1])]; q.append(1-q[0]-q[1]); return q
float_opt={ (1,0):((0.4518,0.2134,0.3347),(0.5488,0.2592,0.192)),
            (1,1):((0.2397,0.4368,0.3236),(0.3445,0.4003,0.2552)),
            (1,2):((0.2802,0.2802,0.4395),(0.3543,0.1674,0.4783)),
            (2,0):((0.3844,0.2848,0.3308),(0.3649,0.3649,0.2703)),
            (2,1):((0.2681,0.4204,0.3115),(0.2916,0.4574,0.251)),
            (2,2):((0.2417,0.3791,0.3791),(0.3308,0.2848,0.3844)),
            (3,0):((0.4204,0.2681,0.3115),(0.4204,0.3115,0.2681)),
            (3,1):((0.2134,0.4518,0.3347),(0.3236,0.4368,0.2397)),
            (3,2):((0.2134,0.3347,0.4518),(0.2802,0.2802,0.4395))}
out=[]
for (k,i),(pj0,pl0) in float_opt.items():
    j,l=[x for x in range(3) if x!=i]
    best=None
    # local rational search around the float optimum
    steps=[F(d,400) for d in range(-4,5)]
    base_j=[rat(x,400) for x in pj0]; base_j[2]=1-base_j[0]-base_j[1]
    base_l=[rat(x,400) for x in pl0]; base_l[2]=1-base_l[0]-base_l[1]
    for dj in itertools.product(steps[2:7],repeat=2):
        pj=[base_j[0]+dj[0],base_j[1]+dj[1]]; pj.append(1-pj[0]-pj[1])
        if min(pj)<=0: continue
        Kj=post(pj)
        if not (le_o_fast(K[k],Kj,i) and le_o_fast(Kj,K[k],j)): continue
        for dl in itertools.product(steps[2:7],repeat=2):
            pl=[base_l[0]+dl[0],base_l[1]+dl[1]]; pl.append(1-pl[0]-pl[1])
            if min(pl)<=0: continue
            val=pj[j]+pl[l]
            if best is not None and val<=best[0]: continue
            Kl=post(pl)
            sl=[None]*3; sl[i]=K[k]; sl[j]=Kj; sl[l]=Kl
            if compatible_fast(*sl): best=(val,pj,pl)
    if best is None: print(f"K_{k+1} slot {i+1}: no exact certificate found near float optimum"); continue
    val,pj,pl=best
    print(f"K_{k+1} slot {i+1}: EXACT compatible triple, p^{j+1}={[str(x) for x in pj]}, p^{l+1}={[str(x) for x in pl]};  (q_{k+1})_{i+1} < {1-val} = {float(1-val):.4f}")
    out.append((k,i,pj,pl,1-val))
import json
json.dump([(k,i,[str(x) for x in pj],[str(x) for x in pl],str(U)) for k,i,pj,pl,U in out],open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'nc_window_exact.json'),'w'))
