# Selected-layer (G) for the patched family: pointwise i-comparability of D_K, D_L requires equal central
# projections from e_i (pi_i(K)=pi_i(L), i.e. equal intervals of m_j/m_l).  Compute log-widths of pi_i(K_p)
# across each bump as a function of beta, and search for distinct p,q in a bump with equal pi_i.  NUMERICS.
import sys,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import math
from family import *
D=float(sys.argv[1]); rho=float(sys.argv[2]); N=int(sys.argv[3])
Fm=default_family(D,rho)
def interval(Kv,i):
    j,l=[x for x in range(3) if x!=i]
    r=[math.log(m[j]/m[l]) for m in Kv]; return min(r),max(r)
W=[interval(postf([1/3]*3),i) for i in range(3)]
print("posterior log-width per world:",[round(b-a,6) for a,b in W])
for k in range(1,4): print(f"K_{k+1} log-width per world:",[round(interval(Kf[k],i)[1]-interval(Kf[k],i)[0],6) for i in range(3)])
def tang(a,r): return [r*math.cos(a)*math.sqrt(2/3), r*math.cos(a-2*math.pi/3)*math.sqrt(2/3), r*math.cos(a+2*math.pi/3)*math.sqrt(2/3)]
for k,q in enumerate(Fm.qs):
    # width along a radius, as function of beta
    ws=[]
    for f in [x/20 for x in range(21)]:
        c=[q[i]+tang(0.7,f*rho)[i] for i in range(3)]; Kc=Fm.K(c)
        ws.append([round(interval(Kc,i)[1]-interval(Kc,i)[0]-(W[i][1]-W[i][0]),5) for i in range(3)])
    mono=all(all((ws[t][i]-ws[t+1][i])*(ws[0][i]) >= -1e-12 for t in range(20)) for i in range(3))
    print(f"bump {k+2}: width - posterior width along a radius (r/rho=0..1):",ws[0],ws[5],ws[10],ws[15],ws[20]," monotone & one-signed:",mono)
    # collision search inside the bump: grid, compare intervals
    pts=[]
    for a in range(N):
        for b in range(N):
            x=-rho+2*rho*a/(N-1); y=-rho+2*rho*b/(N-1)
            if x*x+y*y>rho*rho: continue
            c=[q[0]+x*math.sqrt(2/3), q[1]+(-x/2+y*math.sqrt(3)/2)*math.sqrt(2/3), q[2]+(-x/2-y*math.sqrt(3)/2)*math.sqrt(2/3)]
            Kc=Fm.K(c); pts.append((c,[interval(Kc,i) for i in range(3)]))
    for i in range(3):
        best=(9,None)
        for s in range(len(pts)):
            for t in range(s+1,len(pts)):
                c1,I1=pts[s]; c2,I2=pts[t]
                dist=math.dist(c1,c2)
                if dist<2*rho/(N-1)*3: continue  # ignore neighbours
                gap=abs(I1[i][0]-I2[i][0])+abs(I1[i][1]-I2[i][1])
                if gap<best[0]: best=(gap,(c1,c2,dist))
        print(f"   world {i+1}: min interval mismatch between non-neighbouring bump points = {best[0]:.2e} (index distance {best[1][2]:.4f})")
