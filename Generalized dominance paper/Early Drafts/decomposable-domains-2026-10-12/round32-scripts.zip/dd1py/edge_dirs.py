# Edge directions of the seed credal sets K_2..K_4 (exact), for the injectivity argument of the patched family.
import sys,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from geom import *
def dirs(P):
    n=len(P); out=[]
    for a in range(n):
        b=(a+1)%n; d=[P[b][i]-P[a][i] for i in range(3)]
        # normalise direction up to sign: first nonzero coordinate positive, scale so that max |coord| = 1
        s=next(x for x in d if x!=0); d=[x/s for x in d]
        out.append(tuple(d))
    return out
D={k:set(dirs(K[k])) for k in range(4)}
for k in range(4): print("K",k+1,"#vertices",len(K[k]),"edge directions:",[[str(x) for x in d] for d in sorted(D[k])])
for k in range(1,4):
    for l in range(1,4):
        if k<l: print(f"|dir(K_{k+1}) minus dir(K_{l+1})| = {len(D[k]-D[l])}, |dir(K_{l+1}) minus dir(K_{k+1})| = {len(D[l]-D[k])}")
