# Near-diagonal (NC) search in the patched family: triples p^i = c + delta^i around centres c in the transition
# zone of each bump; counts compatible triples and the max of p1_1+p2_2+p3_3 among them.  NUMERICS.
import sys,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import random, math, geom
from family import *
D=float(sys.argv[1]); rho=float(sys.argv[2]); n=int(sys.argv[3]); seed=int(sys.argv[4]) if len(sys.argv)>4 else 1
Fm=default_family(D,rho); random.seed(seed)
def tang(a,r): return [r*math.cos(a)*math.sqrt(2/3), r*math.cos(a-2*math.pi/3)*math.sqrt(2/3), r*math.cos(a+2*math.pi/3)*math.sqrt(2/3)]
stats=[]
for label,cen in [("posterior u+0.15",[1/3+x for x in tang(1.0,0.15)])]+[(f"bump{k+2} r/rho={f}",[q[i]+tang(a,f*rho)[i] for i in range(3)]) for k,q in enumerate(Fm.qs) for f,a in ((0.0,0),(0.4,0.3),(0.4,2.5),(0.7,1.2),(0.7,4.0),(0.9,5.5))]:
    ncomp=0; best=-9; arg=None
    for t in range(n):
        sc=random.choice([0.001,0.003,0.01])
        P=[[cen[j]+d for j,d in enumerate(tang(random.uniform(0,2*math.pi),sc*random.random()))] for _ in range(3)]
        Ks=[Fm.K(p) for p in P]
        if geom.compatible_fast(*Ks):
            ncomp+=1; S=P[0][0]+P[1][1]+P[2][2]
            if S>best: best=S; arg=P
    print(f"{label:22s} beta(c)={max(Fm.betas(cen)):.3f} compatible {ncomp}/{n}  max(sum)-1 = {best-1 if ncomp else float('nan'):+.3e}",flush=True)
