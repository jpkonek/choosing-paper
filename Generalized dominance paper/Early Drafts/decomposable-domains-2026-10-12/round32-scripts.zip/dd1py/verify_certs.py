# Re-verify the (NC) window certificates with the independent cone-membership test (geom.le_o), exact rationals,
# and print the explicit forbidden configuration for a designated index outside the window.
import sys,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from geom import *
import json
C=json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'nc_window_exact.json')))
allok=True
for k,i,pj,pl,U in C:
    pj=[F(x) for x in pj]; pl=[F(x) for x in pl]; U=F(U)
    j,l=[x for x in range(3) if x!=i]
    sl=[None]*3; sl[i]=K[k]; sl[j]=post(pj); sl[l]=post(pl)
    ok=all(le_o(sl[o],sl[m],o) for o in range(3) for m in range(3) if m!=o)
    ok2=all(min(p)>0 for p in (pj,pl))
    allok&=ok and ok2
    print(f"K_{k+1}, slot {i+1}: cone-test compatible={ok}; window (q_{k+1})_{i+1} < {U} ; witnesses interior={ok2}")
print("all certificates re-verified:",allok)
# explicit forbidden configuration (designated index of K_2 with second coordinate >= 99/200)
k,i,pj,pl,U=[c for c in C if c[0]==1 and c[1]==1][0]
pj=[F(x) for x in pj]; pl=[F(x) for x in pl]
print("Forbidden configuration: K^1=post(",[str(x) for x in pj],"), K^2=K_2 at q_2, K^3=post(",[str(x) for x in pl],")")
print("  r_1(X)>",pj[0]," r_2(X)>(q_2)_2, r_3(X)>",pl[2],"  ==> sum>1 iff (q_2)_2 >= ",1-pj[0]-pl[2])
