import sys,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from geom import *
# sanity: posterior translates. p<=_o q for posterior iff (p_o/p_j, p_o/p_l) <= (q_o/q_j, q_o/q_l)
import random
random.seed(1)
bad=0
for t in range(300):
    p=norm([F(random.randint(1,30)) for _ in range(3)]); q=norm([F(random.randint(1,30)) for _ in range(3)])
    for o in range(3):
        j,l=[x for x in range(3) if x!=o]
        pred=(p[o]/p[j]<=q[o]/q[j]) and (p[o]/p[l]<=q[o]/q[l])
        if pred!=le_o(post(p),post(q),o): bad+=1
print("posterior EM-order = coordinate-ratio order; mismatches:",bad)
for k in range(4): print("K",k+1,"vertices",len(K[k]),[[str(x) for x in v] for v in K[k]])
