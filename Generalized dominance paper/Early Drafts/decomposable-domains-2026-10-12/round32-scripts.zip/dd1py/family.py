# DD1 patched posterior family K_p = (1 - sum_k b_k(p)) K_p^0 + sum_k b_k(p) K_k   (Minkowski combination)
# K_p^0 = co{ p.v_k / p.v_k },  K_k = seed credal sets (k=2,3,4), designated indices q_k, bumps of radius rho.
import sys,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import math, geom
from fractions import Fraction as F
T1f=[[float(x) for x in v] for v in geom.T1]
Kf=[[[float(x) for x in v] for v in Kk] for Kk in geom.K]
def postf(p):
    out=[]
    for v in T1f:
        w=[p[i]*v[i] for i in range(3)]; t=sum(w); out.append([x/t for x in w])
    return out
def hullf(P):
    pts=sorted(set((round(p[0],15),round(p[1],15)) for p in P))
    if len(pts)<=2: return [[a,b,1-a-b] for a,b in pts]
    def cr(o,a,b): return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    lo=[];up=[]
    for p in pts:
        while len(lo)>=2 and cr(lo[-2],lo[-1],p)<=1e-15: lo.pop()
        lo.append(p)
    for p in reversed(pts):
        while len(up)>=2 and cr(up[-2],up[-1],p)<=1e-15: up.pop()
        up.append(p)
    return [[a,b,1-a-b] for a,b in lo[:-1]+up[:-1]]
def mink(A,B,t):  # (1-t)A + tB
    if t<=0: return A
    if t>=1: return B
    return hullf([[ (1-t)*a[i]+t*b[i] for i in range(3)] for a in A for b in B])
class Family:
    def __init__(self,qs,rho,shape=lambda s:(1-s*s)**2 if s<1 else 0.0):
        self.qs=qs; self.rho=rho; self.shape=shape
    def betas(self,p):
        return [self.shape(math.dist(p,q)/self.rho) for q in self.qs]
    def K(self,p):
        b=self.betas(p); P=postf(p)
        tot=sum(b)
        if tot==0: return P
        k=max(range(3),key=lambda i:b[i])   # bumps are disjoint: at most one active
        return mink(P,Kf[k+1],b[k])
def default_family(D=0.06,rho=0.025):
    u=[1/3]*3; qs=[]
    for ang in (90,210,330):   # three directions in the plane sum=0
        a=math.radians(ang)
        d=[math.cos(a)*math.sqrt(2/3), math.cos(a-2*math.pi/3)*math.sqrt(2/3), math.cos(a+2*math.pi/3)*math.sqrt(2/3)]
        qs.append([u[i]+D*d[i] for i in range(3)])
    return Family(qs,rho)
