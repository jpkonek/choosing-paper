import sys,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from geom import *
import random
random.seed(2); bad=0; n=0
sets=[post(norm([F(random.randint(1,20)) for _ in range(3)])) for _ in range(12)]+K
for A in sets:
    for B in sets:
        for o in range(3):
            n+=1
            if le_o(A,B,o)!=le_o_fast(A,B,o): bad+=1
print("fast EM test agrees with cone-membership test on",n,"cases; mismatches:",bad)
