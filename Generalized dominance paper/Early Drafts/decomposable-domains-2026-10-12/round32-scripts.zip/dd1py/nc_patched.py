# Search for (NC) violations in the patched family: compatible triples (K_{p1},K_{p2},K_{p3}),
# not all equal, with p1_1+p2_2+p3_3 >= 1.   NUMERICS (random search); hits re-verified exactly elsewhere.
import sys,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import random, math, geom
from family import *
D=float(sys.argv[1]) if len(sys.argv)>1 else 0.06
rho=float(sys.argv[2]) if len(sys.argv)>2 else 0.025
ntr=int(sys.argv[3]) if len(sys.argv)>3 else 4000
Fm=default_family(D,rho)
random.seed(7)
def proj(p):
    s=sum(p); return [x/s for x in p]
best=-1; hits=[]; ncomp=0
for k,q in enumerate(Fm.qs):
    for t in range(ntr):
        # base point in or near bump k
        r=rho*1.3*math.sqrt(random.random()); a=random.uniform(0,2*math.pi)
        c=[q[0]+r*math.cos(a)*math.sqrt(2/3), q[1]+r*math.cos(a-2*math.pi/3)*math.sqrt(2/3), q[2]+r*math.cos(a+2*math.pi/3)*math.sqrt(2/3)]
        sc=random.choice([0.002,0.006,0.015,0.03])
        P=[]
        for i in range(3):
            d=[random.gauss(0,sc) for _ in range(3)]; m=sum(d)/3; d=[x-m for x in d]
            P.append(proj([c[j]+d[j] for j in range(3)]))
        S=P[0][0]+P[1][1]+P[2][2]
        if S<1: 
            # shift to make S>=1 by moving each p^i toward e_i a bit (keeps exploring the boundary)
            need=1-S+1e-4
            for i in range(3):
                e=[0,0,0]; e[i]=1
                P[i]=[(1-need/2)*P[i][j]+need/2*e[j] for j in range(3)]
            S=P[0][0]+P[1][1]+P[2][2]
        Ks=[Fm.K(p) for p in P]
        if geom.compatible_fast(*Ks):
            ncomp+=1
            hits.append((S,k,P))
print("triples tested:",3*ntr," compatible with sum>=1:",ncomp)
hits.sort(reverse=True)
for S,k,P in hits[:10]:
    print(f"  bump {k+2}: sum={S:.6f}  p1={[round(x,5) for x in P[0]]} p2={[round(x,5) for x in P[1]]} p3={[round(x,5) for x in P[2]]}  betas={[ [round(b,3) for b in Fm.betas(p)] for p in P]}")
