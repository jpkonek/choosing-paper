# (NC) window for the designated index of each seed set K_k (k=2,3,4), from triples
# with K_k in ONE slot i and posterior sets in the two others (upper bound U_i on (q_k)_i),
# and K_k in TWO slots, posterior in slot i (lower bound L_i on (q_k)_i).  NUMERICS (grid).
import sys,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import math, numpy as np, geom
Kf=[[[float(x) for x in v] for v in Kk] for Kk in geom.K]
T1f=[[float(x) for x in v] for v in geom.T1]
def postf(p):
    out=[]
    for v in T1f:
        w=[p[i]*v[i] for i in range(3)]; t=sum(w); out.append([x/t for x in w])
    return out
N=int(sys.argv[1]) if len(sys.argv)>1 else 61; R=float(sys.argv[2]) if len(sys.argv)>2 else 3.0
g=np.linspace(-R,R,N)
def pt(a,b):  # p ∝ (1,e^a,e^b)
    p=np.array([1.0,math.exp(a),math.exp(b)]); return p/p.sum()
pts=[(a,b,pt(a,b)) for a in g for b in g]
le=geom.le_o_fast
def window(k):
    KK=Kf[k]; res={}
    for i in range(3):
        j,l=[x for x in range(3) if x!=i]
        # upper bound: slot i = K_k, slots j,l posterior p^j,p^l
        Aj=[(a,b,p) for a,b,p in pts if le(KK,postf(p),i) and le(postf(p),KK,j)]
        Al=[(a,b,p) for a,b,p in pts if le(KK,postf(p),i) and le(postf(p),KK,l)]
        best=-1; arg=None
        for aj,bj,pj in Aj:
            Pj=postf(pj)
            for al,bl,pl in Al:
                v=pj[j]+pl[l]
                if v<=best: continue
                # posterior coupling: p^j <=_j p^l and p^l <=_l p^j  (exact ratio order)
                if pj[j]/pj[i]<=pl[j]/pl[i] and pj[j]/pj[l]<=pl[j]/pl[l] and pl[l]/pl[i]<=pj[l]/pj[i] and pl[l]/pl[j]<=pj[l]/pj[j]:
                    best=v; arg=(pj,pl)
        U=1-best if best>=0 else float('inf')
        # lower bound: slot i posterior p, slots j,l = K_k
        L=-1.0; argL=None
        for a,b,p in pts:
            P=postf(p)
            if p[i]>L and le(P,KK,i) and le(KK,P,j) and le(KK,P,l): L=p[i]; argL=p
        res[i]=(L,U,argL,arg)
        print(f"K_{k+1} slot {i+1}: L={L:.4f}  U={U:.4f}  |Aj|={len(Aj)} |Al|={len(Al)}  argU={None if arg is None else [np.round(x,4) for x in arg]} argL={None if argL is None else np.round(argL,4)}",flush=True)
    Ls=[res[i][0] for i in range(3)]; Us=[res[i][1] for i in range(3)]
    print(f"  K_{k+1}: sum L = {sum(max(x,0) for x in Ls):.4f} (<1 needed), sum U = {sum(Us):.4f} (>1 needed)",flush=True)
for k in (1,2,3): window(k)
