# DD1 geometry: credal polytopes, posterior family, exact cone membership, EM orders.
from fractions import Fraction as F
import itertools
eps=F(3,10); s=F(9,10); u=[F(1,3)]*3
T1=[[(1-eps)*u[i]+eps*(1 if i==k else 0) for i in range(3)] for k in range(3)]
Kp=[[u[i]+s*(T1[k][i]-u[i]) for i in range(3)] for k in range(3)]
Fr=lambda L:[[F(x) for x in v] for v in L]
V=[T1,
   Fr([['19/30','3/20','13/60'],['17/60','8/15','11/60'],['1/5','11/60','37/60']]),
   Fr([['13/30','1/5','11/30'],['11/60','3/5','13/60'],['19/60','13/60','7/15']]),
   Fr([['31/60','3/10','11/60'],['3/20','13/30','5/12'],['1/6','1/3','1/2']])]
E=[[F(1) if i==j else F(0) for i in range(3)] for j in range(3)]
def norm(m):
    t=sum(m); return [x/t for x in m]
def hull2d(P):
    # convex hull of points in the simplex (use coords 0,1); returns vertices ccw, exact
    pts=sorted(set(tuple(p) for p in P),key=lambda p:(p[0],p[1]))
    if len(pts)<=2: return [list(p) for p in pts]
    def cr(o,a,b): return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    lo=[];up=[]
    for p in pts:
        while len(lo)>=2 and cr(lo[-2],lo[-1],p)<=0: lo.pop()
        lo.append(p)
    for p in reversed(pts):
        while len(up)>=2 and cr(up[-2],up[-1],p)<=0: up.pop()
        up.append(p)
    return [list(p) for p in lo[:-1]+up[:-1]]
K=[hull2d(Kp+V[k]) for k in range(4)]   # seed credal sets K_1..K_4 (K_1 = T1)
def post(p,S=T1):
    return hull2d([norm([p[i]*v[i] for i in range(3)]) for v in S])
def det3(a,b,c):
    return (a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0]))
def in_cone(m,G):
    # exact: is m a nonnegative combination of vectors in G (R^3)? Caratheodory over subsets of size<=3
    if all(x==0 for x in m): return True
    G=[g for g in G if any(x!=0 for x in g)]
    for g in G:  # size 1
        # m = t g, t>=0
        idx=[i for i in range(3) if g[i]!=0][0]; t=m[idx]/g[idx]
        if t>=0 and all(m[i]==t*g[i] for i in range(3)): return True
    for a,b in itertools.combinations(G,2):
        # solve m = x a + y b using 2 independent rows
        for r1,r2 in ((0,1),(0,2),(1,2)):
            d=a[r1]*b[r2]-a[r2]*b[r1]
            if d!=0:
                x=(m[r1]*b[r2]-m[r2]*b[r1])/d; y=(a[r1]*m[r2]-a[r2]*m[r1])/d
                if x>=0 and y>=0 and all(m[i]==x*a[i]+y*b[i] for i in range(3)): return True
                break
    for a,b,c in itertools.combinations(G,3):
        d=det3(a,b,c)
        if d==0: continue
        x=det3(m,b,c)/d; y=det3(a,m,c)/d; z=det3(a,b,m)/d
        if x>=0 and y>=0 and z>=0: return True
    return False
def sub(Lv,Kv,extra):
    return all(in_cone(m,Kv+extra) for m in Lv)
def neg(v): return [-x for x in v]
def le_o(L,Kset,o):
    """EM order L <=_o K on Q_o: acc(K) c acc(L) and rej(L) c rej(K) on Q_o.
    (a) L c cone(K u {e_j,e_l,-e_o}); (b) K c cone(L u {e_o,-e_j,-e_l})."""
    j,l=[x for x in range(3) if x!=o]
    return sub(L,Kset,[E[j],E[l],neg(E[o])]) and sub(Kset,L,[E[o],neg(E[j]),neg(E[l])])
def compatible(K1,K2,K3):
    Ks=[K1,K2,K3]
    return all(le_o(Ks[o],Ks[j],o) for o in range(3) for j in range(3) if j!=o)

# ---- fast exact EM test (2-D) ----
# k >=_o m  :<=>  k_o m_j - k_j m_o >= 0  and  k_o m_l - k_l m_o >= 0   ("k is o-heavier than m")
def _seg_meets_quadrant(a,b):
    lo,hi=F(0),F(1)
    for c in (0,1):
        d=b[c]-a[c]
        if d==0:
            if a[c]<0: return False
        else:
            t=-a[c]/d
            if d>0: lo=max(lo,t)
            else: hi=min(hi,t)
    return lo<=hi
def _meets(img):
    if any(x>=0 and y>=0 for x,y in img): return True
    n=len(img)
    for a in range(n):
        for b in range(a+1,n):
            if _seg_meets_quadrant(img[a],img[b]): return True
    return False
def meets_heavier(Kv,m,o):
    """exists k in co(Kv) with k >=_o m"""
    j,l=[x for x in range(3) if x!=o]
    return _meets([(k[o]*m[j]-k[j]*m[o], k[o]*m[l]-k[l]*m[o]) for k in Kv])
def meets_lighter(Lv,k,o):
    """exists m in co(Lv) with k >=_o m"""
    j,l=[x for x in range(3) if x!=o]
    return _meets([(k[o]*m[j]-k[j]*m[o], k[o]*m[l]-k[l]*m[o]) for m in Lv])
def le_o_fast(L,Kv,o):
    return all(meets_heavier(Kv,m,o) for m in L) and all(meets_lighter(L,k,o) for k in Kv)
def compatible_fast(K1,K2,K3):
    Ks=[K1,K2,K3]
    return all(le_o_fast(Ks[o],Ks[j],o) for o in range(3) for j in range(3) if j!=o)
