# Selected-layer strict (G) for the patched family, pairs inside a bump.
# C_K is pointwise weakly i-better than C_L  iff  pi_i(K)=pi_i(L) (same interval of m_j/m_l) and, on every fibre
# {m_j/m_l = theta}, both the max and the min of m_i over K are >= those over L  (fibre criterion, DD1 Lemma 2.1).
# Equal projections is a codimension-2 condition on pairs; we solve it by Newton from "mirror" seeds
# (same e_i-ray, same beta) and test the fibre orientation against the index order.  NUMERICS.
import sys,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import math, random
import numpy as np
from family import *
D=float(sys.argv[1]); rho=float(sys.argv[2]); n=int(sys.argv[3])
Fm=default_family(D,rho); random.seed(3)
def interval(Kv,i):
    j,l=[x for x in range(3) if x!=i]
    r=[math.log(m[j]/m[l]) for m in Kv]; return np.array([min(r),max(r)])
def fibre(Kv,i,theta):
    # range of m_i over K ∩ {log(m_j/m_l)=theta}
    j,l=[x for x in range(3) if x!=i]
    vals=[]
    n_=len(Kv)
    for a in range(n_):
        A=Kv[a]; B=Kv[(a+1)%n_]
        fa=math.log(A[j]/A[l])-theta; fb=math.log(B[j]/B[l])-theta
        if fa==0: vals.append(A[i])
        if fa*fb<0:
            # solve on segment for g(t)= (A_j+t(B_j-A_j)) - e^theta (A_l+t(B_l-A_l)) = 0 (linear in t)
            et=math.exp(theta)
            ga=A[j]-et*A[l]; gb=B[j]-et*B[l]; t=ga/(ga-gb)
            vals.append(A[i]+t*(B[i]-A[i]))
    return (min(vals),max(vals)) if vals else None
def P(x):  # point in bump-local coords x=(x,y) around q
    return None
def tocoord(q,x,y):
    return [q[0]+x*math.sqrt(2/3), q[1]+(-x/2+y*math.sqrt(3)/2)*math.sqrt(2/3), q[2]+(-x/2-y*math.sqrt(3)/2)*math.sqrt(2/3)]
viol=0; tested=0; worst=None
for k,q in enumerate(Fm.qs):
    for i in range(3):
        e=[0,0,0]; e[i]=1
        for t in range(n):
            # random p in bump; mirror seed p' = reflection of p across the foot line (line through e_i and q)
            r=rho*math.sqrt(random.uniform(0.05,0.95)); a=random.uniform(0,2*math.pi)
            p=tocoord(q,r*math.cos(a),r*math.sin(a))
            # reflect p across the line through e_i and q (in the plane sum=1, Euclidean)
            pv=np.array(p); qv=np.array(q); ev=np.array(e,float)
            d=(ev-qv)/np.linalg.norm(ev-qv); w=pv-qv; refl=qv+2*(w@d)*d-w
            x=refl.copy()
            Ip=interval(Fm.K(p),i)
            ok=False
            for it in range(30):
                if min(x)<=1e-6 or math.dist(list(x),q)>3*rho: break
                f=interval(Fm.K(list(x)),i)-Ip
                if np.linalg.norm(f)<1e-12: ok=True; break
                J=np.zeros((2,2)); h=1e-7
                basis=[np.array([math.sqrt(2/3),-math.sqrt(1/6),-math.sqrt(1/6)]),np.array([0,math.sqrt(1/2),-math.sqrt(1/2)])]
                for c in range(2):
                    J[:,c]=(interval(Fm.K(list(x+h*basis[c])),i)-interval(Fm.K(list(x-h*basis[c])),i))/(2*h)
                try: st=np.linalg.solve(J,-f)
                except np.linalg.LinAlgError: break
                x=x+st[0]*basis[0]+st[1]*basis[1]
            if not ok: continue
            p2=list(x)
            if math.dist(p2,p)<1e-6 or max(Fm.betas(p2))==0 and max(Fm.betas(p))==0: continue
            K1=Fm.K(p); K2=Fm.K(p2)
            I=interval(K1,i)
            ths=np.linspace(I[0]+1e-9,I[1]-1e-9,41)
            dmin=[];dmax=[]
            for th in ths:
                f1=fibre(K1,i,th); f2=fibre(K2,i,th)
                if f1 is None or f2 is None: break
                dmin.append(f2[0]-f1[0]); dmax.append(f2[1]-f1[1])
            if len(dmin)<len(ths): continue
            tested+=1
            two_better = min(dmin)>=-1e-9 and min(dmax)>=-1e-9   # K2 (index p2) weakly i-better than K1
            one_better = max(dmin)<=1e-9 and max(dmax)<=1e-9
            if two_better and p2[i]<=p[i]: viol+=1; worst=(k,i,p,p2)
            if one_better and p[i]<=p2[i]: viol+=1; worst=(k,i,p,p2)
            if True: print(f"bump {k+2} world {i+1}: pair found |p-p'|={math.dist(p,p2):.4f}, comparable? {'p2 better' if two_better else ('p better' if one_better else 'no (crossing)')}  dp_i={p2[i]-p[i]:+.4f}",flush=True)
print("equal-projection pairs tested:",tested,"  (G)-violations:",viol, worst)
