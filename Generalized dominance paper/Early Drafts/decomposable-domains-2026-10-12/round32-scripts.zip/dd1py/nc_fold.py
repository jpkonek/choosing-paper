# Targeted (NC) test of the fold: triples (bump centre q_k in slot i, posterior/transition points in the other slots)
import sys,os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import math, geom
from family import *
D=float(sys.argv[1]); rho=float(sys.argv[2]); N=int(sys.argv[3]) if len(sys.argv)>3 else 41
Fm=default_family(D,rho)
u=[1/3]*3
def pt(a,b,i):
    z=[0,0,0]; oth=[x for x in range(3) if x!=i]; z[oth[0]]=a; z[oth[1]]=b
    p=[math.exp(x) for x in z]; s=sum(p); return [x/s for x in p]
worst=None
for k,q in enumerate(Fm.qs):
    Kc=Fm.K(q)
    for i in range(3):
        j,l=[x for x in range(3) if x!=i]
        # the same other point in both other slots: compatible ==> q_i < p_i  (violation if p_i <= q_i)
        R=1.2; g=[-R+2*R*t/(N-1) for t in range(N)]
        mn=9; arg=None
        for a in g:
            for b in g:
                p=pt(a,b,i)
                sl=[None]*3; sl[i]=Kc; Kp_=Fm.K(p); sl[j]=Kp_; sl[l]=Kp_
                if p[i]<mn and geom.compatible_fast(*sl): mn=p[i]; arg=p
        print(f"D={D} rho={rho} bump {k+2} slot {i+1}: q_i={q[i]:.4f}  min p_i over forward-compatible = {mn:.4f}  {'VIOLATION' if mn<=q[i] else 'ok'}  at {None if arg is None else [round(x,4) for x in arg]}",flush=True)
