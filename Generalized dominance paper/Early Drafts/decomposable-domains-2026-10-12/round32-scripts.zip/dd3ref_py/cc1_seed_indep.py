# DD3 referee: independent exact re-derivation of CC1's seed data (not importing cc1py).
# (1) acceptance patterns of B_1..B_4 at the seven centres, world-1 correctness = cell index;
# (2) strictness of every defining inequality at the centre; modulus >= 0.15 * max;
# (3) world-1 record sums (certificate); world-2/3 improvement table;
# (4) LP: does the CLOSURE of each CC1 cell touch a coordinate plane? (audit's remark)
# Run: python3 -I cc1_seed_indep.py
from fractions import Fraction as F
import itertools
import numpy as np
from scipy.optimize import linprog

eps = F(3, 10); u = [F(1, 3)] * 3
T1 = [[(1 - eps) * u[i] + (eps if i == k else 0) for i in range(3)] for k in range(3)]
Kp = [[u[i] + F(9, 10) * (T1[k][i] - u[i]) for i in range(3)] for k in range(3)]
def fr(L): return [[F(x) for x in v] for v in L]
V = [T1,
     fr([['19/30', '3/20', '13/60'], ['17/60', '8/15', '11/60'], ['1/5', '11/60', '37/60']]),
     fr([['13/30', '1/5', '11/30'], ['11/60', '3/5', '13/60'], ['19/60', '13/60', '7/15']]),
     fr([['31/60', '3/10', '11/60'], ['3/20', '13/30', '5/12'], ['1/6', '1/3', '1/2']])]
for Vk in V:
    for m in Vk:
        assert sum(m) == 1 and all(x > 0 for x in m)
# cells as in CC1 table (bases numbered 1..4 there; 0..3 here)
centres = {(0, 1): ['1', '-30809/100000', '-3/20'], (0, 2): ['1', '-3/20', '-319/1000'],
           (0, 3): ['3/20', '-46328/100000', '1'], (1, 2): ['-2766/10000', '1', '-2766/10000'],
           (1, 3): ['-29159/100000', '-23288/100000', '1'], (2, 3): ['1', '1', '-91083/100000'],
           (): ['-22449/100000', '1', '1']}
dot = lambda a, b: sum(x * y for x, y in zip(a, b))
res = []
allok = True
pattern = {}
cellcons = {}
for S, hs in centres.items():
    h = [F(x) for x in hs]
    assert all(dot(v, h) > 0 for v in Kp)
    acc = [min(dot(m, h) for m in Vk) > 0 for Vk in V]
    corr1 = [k for k in range(4) if acc[k] == (h[0] > 0)]
    allok &= set(corr1) == set(S)
    mx = max(abs(x) for x in h)
    allok &= all(abs(x) >= F(15, 100) * mx for x in h)
    # constraint list (as rows a with a.h > 0), strict at centre
    cons = []
    for i in range(3):
        e = [0, 0, 0]; e[i] = 1 if h[i] > 0 else -1; cons.append(e)
    cons += [list(v) for v in Kp]
    for k in range(4):
        if acc[k]:
            cons += [list(m) for m in V[k]]
        else:
            mstar = min(V[k], key=lambda m: dot(m, h))   # one witness with m.h<0
            cons.append([-x for x in mstar])
    allok &= all(dot(c, h) > 0 for c in cons)
    cellcons[S] = (cons, [1 if x > 0 else -1 for x in h])
    pattern[S] = (acc, h)
    res.append(f"cell {S}: accept {[int(a) for a in acc]}, world-1 correct {corr1}")
res.append(f"(1)-(2) seven patterns, strictness at centres, modulus >= 0.15 max: {allok}")
# (3) records at worlds 1..3: +1 if B_k correct at world j (toggle worsens), -1 otherwise
cells = list(centres)
def correct(k, S, j):
    acc, h = pattern[S]; return acc[k] == (h[j] > 0)
g = {(k, j): [1 if correct(k, S, j) else -1 for S in cells] for k in range(4) for j in range(3)}
tot = [sum(g[(k, 0)][i] for k in range(4)) for i in range(7)]
res.append(f"(3) world-1 sum of the four records per cell {dict(zip(cells, tot))}")
for k in range(4):
    for j in (1, 2):
        imp = [cells[i] for i in range(7) if g[(k, j)][i] == -1]
        res.append(f"    X_{k+1} improves at world {j+1} on {imp}")
# (4) LP on closures: minimise s_i h_i subject to closed constraints and sum_j s_j h_j = 1
touch = {}
for S, (cons, s) in cellcons.items():
    A = -np.array([[float(x) for x in c] for c in cons])
    b = np.zeros(len(cons))
    mins = []
    for i in range(3):
        c = np.zeros(3); c[i] = s[i]
        r = linprog(c, A_ub=A, b_ub=b, A_eq=[s], b_eq=[1], bounds=[(None, None)] * 3, method="highs")
        mins.append(round(r.fun, 6))
    touch[S] = mins
res.append("(4) min over closure of |h_i| / ||h||_1, i = 1,2,3 (0 means the closed cell touches h_i = 0):")
for S, m in touch.items():
    res.append(f"    {S}: {m}")
print("\n".join(res))
