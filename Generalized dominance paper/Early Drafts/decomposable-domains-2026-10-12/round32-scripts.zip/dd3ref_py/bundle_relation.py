# DD3 referee: the audit's finite bundle relation (B) on the full four-advice ladder (world-1 ranks 0..3 per cell).
# Cells S in {12,13,14,23,24,34,0}; designated increment j_S = 1 (h_1>0 cells: good|silence) or 2 (h_1<0: silence|bad).
# Relation: X R Y iff d(X,Y) >= 0 or d(X,Y) >= g_k for some k, where d is the ladder-increment vector.
# Per cell this is a union of PRODUCT relations R = R0^7 u U_k prod_S R_{k,S}; composition of products is the product
# of per-cell compositions, so transitivity reduces to finitely many 4x4 checks (exact). We also cross-check
# (G)-strictness, the four-seed bundle certificate, Lemma 4 (incoming comparisons at B_k are guidance), and the
# Pareto claim, with base patterns derived from CC1's exact data (cc1_seed_indep.py logic, re-entered here).
# Run: python3 -I bundle_relation.py
import itertools, random
cells = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3), ()]
h1pos = {(0, 1): True, (0, 2): True, (0, 3): True, (1, 2): False, (1, 3): False, (2, 3): True, (): False}
j = {S: (1 if h1pos[S] else 2) for S in cells}
R = range(4)
def inc(rx, ry):           # ladder increment vector (3 coords) of the change rx -> ry
    return tuple((1 if rx < s <= ry else (-1 if ry < s <= rx else 0)) for s in (1, 2, 3))
def ge(d, g): return all(a >= b for a, b in zip(d, g))
def gvec(k, S):
    v = [0, 0, 0]; v[j[S] - 1] = 1 if k in S else -1; return tuple(v)
R0 = {(a, b) for a in R for b in R if ge(inc(a, b), (0, 0, 0))}
Rk = {(k, S): {(a, b) for a in R for b in R if ge(inc(a, b), gvec(k, S))} for k in range(4) for S in cells}
def comp(A, B): return {(a, c) for (a, b) in A for (b2, c) in B if b == b2}
out = []
# definitional cross-check of per-cell form
ok = all(Rk[(k, S)] == ({(a, b) for a in R for b in R if a < j[S] <= b} if k in S else
                        (R0 | {(j[S], j[S] - 1)})) for k in range(4) for S in cells)
out.append(f"per-cell form of d >= g_k (up-crossing on P_k cells; guidance or single down-step at j_S on N_k): {ok}")
t1 = all(comp(R0, R0) <= R0 for S in cells)
t2 = all(comp(R0, Rk[(k, S)]) <= Rk[(k, S)] and comp(Rk[(k, S)], R0) <= Rk[(k, S)] for k in range(4) for S in cells)
t3 = all(any(len(comp(Rk[(k, S)], Rk[(l, S)])) == 0 for S in cells) for k in range(4) for l in range(4))
out.append(f"transitivity: R0oR0<=R0 {t1}; R0oRk, RkoR0 <= Rk cellwise {t2}; RkoRl empty in some cell for all k,l (k=l incl.) {t3}")
# strict guidance: d <= 0 and != 0 never in R
sg = all(not any(a > b for (a, b) in Rk[(k, S)] if b <= a) or True for k in range(4) for S in cells)
sg = all(all(not (b <= a) for (a, b) in Rk[(k, S)]) for k in range(4) for S in cells if k in S)
out.append(f"strict (G): on every P_k cell R_k forces a strict up-move, so no nonpositive record satisfies d >= g_k: {sg}")
# CC1 base patterns at world 1 (rank of B_k's advice in each cell): correct&h1>0 -> accept -> 0; correct&h1<0 -> silent -> 1;
# wrong&h1>0 -> silent -> 1; wrong&h1<0 -> accept -> 2  (CC1 cells are in U: advice is accept h or silence)
rank = {(k, S): (0 if h1pos[S] else 1) if k in S else (1 if h1pos[S] else 2) for k in range(4) for S in cells}
# seed application on a bundle: B_k -> X_k swaps accept/silence in every cell
def swapped(k, S):
    r = rank[(k, S)]
    if h1pos[S]: return 1 - r                # 0<->1
    return 3 - r                             # 1<->2
seedrec = all(ge(inc(rank[(k, S)], swapped(k, S)), gvec(k, S)) and inc(rank[(k, S)], swapped(k, S)) == gvec(k, S)
              for k in range(4) for S in cells)
out.append(f"seed k on a bundle has record exactly g_k: {seedrec}")
cert = {S: sum(gvec(k, S)[j[S] - 1] for k in range(4)) for S in cells}
out.append(f"bundle certificate: sum_k g_k at designated increments {cert}")
# Lemma 4: no (Y, B_k) in prod_S R_{l,S}
lem4 = all(any(not any(b == rank[(k, S)] for (a, b) in Rk[(l, S)]) for S in cells) for k in range(4) for l in range(4))
out.append(f"Lemma 4: for all k,l no Y has Y R_l B_k (incoming comparisons at B_k are guidance): {lem4}")
# Pareto: three-world rank vectors at mixed sign patterns
def ranks(sig):   # sig = signs of (h1,h2,h3); advice '+','0','-','x'
    rv = {}
    for a in '+0-x':
        rv[a] = tuple((0 if (a == '+') == (s > 0) else 2) if a in '+-' else (1 if a == '0' else 3) for s in sig)
    return rv
par = True
for sig in itertools.product([1, -1], repeat=3):
    rv = ranks(sig)
    mixed = len(set(sig)) == 2
    for a in ('+0-' if mixed else ('+' if sig[0] > 0 else '-')):
        for b in '+0-x':
            if b != a and all(x <= y for x, y in zip(rv[b], rv[a])):
                par = False
    assert len(set(rv.values())) == 4
out.append(f"Pareto: at mixed problems +,0,- are undominated in the three guidance orders; ranks separate all advice: {par}")
# random cross-check of transitivity on full 7-cell bundles (4^7 states)
random.seed(1)
def rel(X, Y):
    d = [inc(X[i], Y[i]) for i in range(7)]
    if all(ge(di, (0, 0, 0)) for di in d): return True
    return any(all(ge(d[i], gvec(k, cells[i])) for i in range(7)) for k in range(4))
bad = 0; n = 0
for _ in range(20000):
    Y = tuple(random.randrange(4) for _ in range(7))
    Xs = [tuple(random.randrange(4) for _ in range(7)) for _ in range(30)]
    Zs = [tuple(random.randrange(4) for _ in range(7)) for _ in range(30)]
    # bias: include seed-preimages/images of Y
    for k in range(4):
        Xs.append(tuple(rank[(k, S)] for S in cells))
    for X in Xs:
        if not rel(X, Y): continue
        for Z in Zs:
            if rel(Y, Z):
                n += 1
                if not rel(X, Z): bad += 1
out.append(f"sampled transitivity on 7-cell bundles: {n} composable pairs, {bad} failures (NUMERICS)")
print("\n".join(out))
