# DD3 referee: independent checks of CC2 §2 and of two points in §5.
# (A) exact: pointwise q-Bayes advice of the rank-weighted Brier field equals the advice of D_{R(q)} (fresh sampler,
#     boundary q, kappa = 1 included); (A') vertices of {m in simplex: m_i q_j <= kappa m_j q_i} = normalised q*t.
# (C) exact: Gamma_3 cone generators lie on the stated planes; hexagon R(u) has six vertices.
# (S) Cor 5.7 strengthening: at a SIDE-arc point of a facet of D_T1, an interior core weight q reproduces T1 locally,
#     so the middle-arc restriction is not what makes the corollary work (sampled, exact arithmetic).
# Run: python3 -I cc2_core.py
from fractions import Fraction as F
import itertools, random
random.seed(77)
def P(K, h): return min(sum(m[i] * h[i] for i in range(3)) for m in K)
def adv(K, h):
    a, b = P(K, h) > 0, P(K, [-x for x in h]) > 0
    return 'x' if a and b else ('+' if a else ('-' if b else '0'))
def bayes(q, h, l1, l2, l3):
    cost = {}
    for a in '+0-x':
        t = F(0)
        for k in range(3):
            lam = {'0': l1, 'x': l3}.get(a)
            if lam is None:
                lam = 0 if ((a == '+') == (h[k] > 0)) else l2
            t += q[k] * lam * abs(h[k])
        cost[a] = t
    m = min(cost.values()); best = [a for a in cost if cost[a] == m]
    return best[0] if len(best) == 1 else None
def Rq(q, kap):
    pts = []
    for t in itertools.product([F(1), kap], repeat=3):
        v = [q[i] * t[i] for i in range(3)]; z = sum(v)
        if z: pts.append([x / z for x in v])
    return pts
out = []
tests = mism = 0
for (l1, l2) in [(F(1), F(2)), (F(3), F(8)), (F(1), F(5)), (F(2), F(9))]:
    kap = (l2 - l1) / l1
    for _ in range(5000):
        a = [F(random.randint(0, 40)) for _ in range(3)]
        if sum(a) == 0: continue
        q = [x / sum(a) for x in a]
        h = [F(random.randint(-90, 90), random.randint(1, 13)) for _ in range(3)]
        if 0 in h: continue
        b = bayes(q, h, l1, l2, l2 + 1)
        if b is None: continue
        tests += 1
        mism += b != adv(Rq(q, kap), h)
out.append(f"(A) Bayes advice vs D_R(q): {tests} exact tests (kappa in {{1, 5/3, 4, 7/2}}, boundary q included), {mism} mismatches")
# (A') vertex enumeration of the ratio polytope for random interior q
bad = 0
for _ in range(200):
    a = [F(random.randint(1, 30)) for _ in range(3)]; q = [x / sum(a) for x in a]; kap = F(random.randint(11, 60), 10)
    cons = [(i, jj) for i in range(3) for jj in range(3) if i != jj]   # m_i q_j - kap m_j q_i <= 0
    def row(i, jj):
        r = [F(0)] * 3; r[i] += q[jj]; r[jj] -= kap * q[i]; return r
    verts = set()
    for (c1, c2) in itertools.combinations(cons, 2):
        A = [row(*c1), row(*c2), [F(1)] * 3]; bvec = [F(0), F(0), F(1)]
        # solve 3x3 exactly
        import copy
        M = [A[r] + [bvec[r]] for r in range(3)]
        try:
            for c in range(3):
                p = next(r for r in range(c, 3) if M[r][c] != 0)
                M[c], M[p] = M[p], M[c]
                for r in range(3):
                    if r != c and M[r][c] != 0:
                        f = M[r][c] / M[c][c]; M[r] = [x - f * y for x, y in zip(M[r], M[c])]
            m = tuple(M[r][3] / M[r][r] for r in range(3))
        except StopIteration:
            continue
        if all(x >= 0 for x in m) and all(sum(rr * mm for rr, mm in zip(row(*c), m)) <= 0 for c in cons):
            verts.add(m)
    hull = {tuple(v) for v in Rq(q, kap)}
    hullv = {v for v in hull if v in verts}
    bad += not (verts <= hull and len(verts) == 6)
out.append(f"(A') ratio polytope vertices = normalised q*t, six of them, for 200 random interior (q, kappa): failures {bad}")
# (C)
eps = F(3, 10); kap = (1 + 2 * eps) / (1 - eps); c0 = (1 - eps) / 3
T1 = [[c0 + (eps if i == k else 0) for i in range(3)] for k in range(3)]
w3 = [kap, kap, F(1)]
dot = lambda a, b: sum(x * y for x, y in zip(a, b))
r12 = [F(-1), F(-1), kap + 1]; w21 = [F(-1), F(0), kap]; w12 = [F(0), F(-1), kap]
out.append("(C) r12 on F1,F2: %s; w21 on F1 and w3-plane: %s; w12' on F2 and w3-plane: %s; r12 strictly on w3<0 side: %s" % (
    dot(T1[0], r12) == 0 and dot(T1[1], r12) == 0, dot(T1[0], w21) == 0 and dot(w3, w21) == 0,
    dot(T1[1], w12) == 0 and dot(w3, w12) == 0, dot(w3, r12) < 0))
out.append(f"    hexagon R(u): normalised points other than u: {len({tuple(v) for v in Rq([F(1,3)]*3, kap)} - {(F(1,3),)*3})} (t=(1,1,1),(k,k,k) give the centre u)")
# (S) side arc of F3: h = (-a, a + kap*c, -c), c > a > 0, lies on F3 with v1.h, v2.h > 0
a_, c_ = F(1, 5), F(1)
h0 = [-a_, a_ + kap * c_, -c_]
on = dot(T1[2], h0) == 0 and dot(T1[0], h0) > 0 and dot(T1[1], h0) > 0
# matching core weight for a core with arbitrary kappa_c: (kappa_c q1, q2, kappa_c q3) ∝ (1, 1, kap)
res = []
for kc in [F(3, 2), kap, F(5)]:
    q = [1 / kc, F(1), kap / kc]; z = sum(q); q = [x / z for x in q]
    K = Rq(q, kc); dis = 0; n = 0
    for _ in range(3000):
        h = [h0[i] + F(random.randint(-1000, 1000), 20000) for i in range(3)]
        n += 1; dis += adv(T1, h) != adv(K, h)
    res.append(f"kappa_core={kc}: q={tuple(float(x) for x in q)}, disagreements near h0: {dis}/{n}")
out.append(f"(S) side-arc point h0={tuple(float(x) for x in h0)} on F3 (other vertex values > 0): {on}")
out += ["    " + r for r in res]
print("\n".join(out))
