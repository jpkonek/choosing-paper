# DD3 referee: AUDIT_CC_plan §3 coupling warning, on a four-part discretisation of the bundle parameter.
# Part k (k=0..3) of the bundles carries base B_k's world-1 ranks; M is that spliced model. Seed k is applied on part k.
# Checks: (a) M -> M' is accepted by (B) part by part, and is also reachable as a chain of four single-part seed
#   applications (each an (IB)-transport of B_k <=_1 X_k^{A_k}); (b) in each pair cell the multiset of ranks over the
#   four parts is unchanged, and in the empty cell every part improves; (c) undoing M' -> M'' by a permutation of
#   parts inside each pair cell separately yields d(M, M'') <= 0, != 0 (pure guidance improvement), which (B) rejects.
# Run: python3 -I coupling.py
from collections import Counter
cells = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3), ()]
h1pos = {(0, 1): True, (0, 2): True, (0, 3): True, (1, 2): False, (1, 3): False, (2, 3): True, (): False}
j = {S: (1 if h1pos[S] else 2) for S in cells}
rank = {(k, S): (0 if h1pos[S] else 1) if k in S else (1 if h1pos[S] else 2) for k in range(4) for S in cells}
def sw(S, r): return 1 - r if h1pos[S] else 3 - r
def inc(rx, ry): return tuple((1 if rx < s <= ry else (-1 if ry < s <= rx else 0)) for s in (1, 2, 3))
def gvec(k, S):
    v = [0, 0, 0]; v[j[S] - 1] = 1 if k in S else -1; return tuple(v)
def ge(d, g): return all(a >= b for a, b in zip(d, g))
def B_ok(Xb, Yb):        # (B) on one bundle (7 cells)
    d = [inc(Xb[i], Yb[i]) for i in range(7)]
    return all(ge(x, (0, 0, 0)) for x in d) or any(all(ge(d[i], gvec(k, cells[i])) for i in range(7)) for k in range(4))
def accepted(X, Y): return all(B_ok(X[p], Y[p]) for p in range(4))
M = [[rank[(k, S)] for S in cells] for k in range(4)]                 # part k carries B_k
Mp = [[sw(S, M[k][i]) for i, S in enumerate(cells)] for k in range(4)]
out = [f"(a) M <=_1 M' accepted directly by (B): {accepted(M, Mp)}"]
cur = [row[:] for row in M]; chain_ok = True
for k in range(4):
    nxt = [row[:] for row in cur]; nxt[k] = Mp[k][:]
    chain_ok &= accepted(cur, nxt); cur = nxt
out.append(f"    and as a chain of four single-part seed steps: {chain_ok}")
same = all(Counter(M[p][i] for p in range(4)) == Counter(Mp[p][i] for p in range(4)) for i in range(6))
imp = all(Mp[p][6] < M[p][6] for p in range(4))
out.append(f"(b) pair cells: rank multisets over parts unchanged: {same}; empty cell: every part strictly improves: {imp}")
# (c) per pair cell, permute parts so that M'' agrees with M there
Mpp = [row[:] for row in Mp]
for i in range(6):
    vals = sorted(range(4), key=lambda p: Mp[p][i]); targ = sorted(range(4), key=lambda p: M[p][i])
    perm = dict(zip(targ, vals))           # part targ gets M'-value of part vals: a within-cell rearrangement
    for p in range(4): Mpp[p][i] = Mp[perm[p]][i]
d = [[M[p][i] - Mpp[p][i] for i in range(7)] for p in range(4)]   # rank(M'') - rank(M) < 0 means improvement
pure = all(Mpp[p][i] <= M[p][i] for p in range(4) for i in range(7)) and any(Mpp[p][i] < M[p][i] for p in range(4) for i in range(7))
only_empty = all(Mpp[p][i] == M[p][i] for p in range(4) for i in range(6))
out.append(f"(c) M'' (pair cells rearranged back) is a pure guidance improvement on M: {pure}; differs only in the empty cell: {only_empty}")
out.append(f"    (B) rejects M <=_1 M'': {not accepted(M, Mpp)}  -> with M <= M' and an accepted rearrangement M' <= M'', transitivity breaks strict (G)")
# each single-cell rearrangement M' -> (M' with cell i rearranged) has a record with gains and losses in that cell only
print("\n".join(out))
