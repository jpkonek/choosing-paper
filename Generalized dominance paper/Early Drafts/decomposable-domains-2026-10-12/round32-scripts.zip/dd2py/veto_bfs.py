"""DD2 veto lemma (fragment check).

Hypothesis V: world 1 judges records SUPPORTED ON THE SEED CELLS by the bundle relation (B) alone
(no compensation at world 1 for records supported on R).  Then, at an index p on the edge {1,2}, every record out
of C_p that is supported on R and rejected by (B) must be accepted at world 2 (competitiveness on supp p = {1,2}).
We search for a chain of such forced world-2 records and world-2 background moves from a pattern P to a pattern Q
strictly world-2 better than P: by transitivity that is a strict guidance reversal at world 2.
Records are constant over bundles here (the m = 1 cell fragment), so (B) is read on the cell ladder vector.

Run: python3 -I veto_bfs.py
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import itertools, collections
from common import *


def main(edge=(0, 1), other_world=1):
    bases = grid_bases(120)
    eb = sorted({pt for (pt, s) in bases if s == edge})
    print("edge", tuple(i + 1 for i in edge), "patterns:", eb)
    states = [''.join(t) for t in itertools.product(ADV, repeat=NC)]
    idx = {s: n for n, s in enumerate(states)}
    n = len(states)
    adj = [dict() for _ in states]
    forced = set()
    for st in states:
        for pi in eb:
            M = [c for c in range(NC) if st[c] == pi[c]]
            for vals in itertools.product(*[[None] + [a for a in ADV if a != pi[c]] for c in M]):
                if all(v is None for v in vals):
                    continue
                end = list(st)
                for c, v in zip(M, vals):
                    if v is not None:
                        end[c] = v
                end = ''.join(end)
                # the record st -> end is a record out of C_pi (pi agrees with st on its support)
                if B_accepts(ladder(0, st, end)):
                    continue
                forced.add((pi, ''.join(end[c] if end[c] != st[c] else '.' for c in range(NC))))
                adj[idx[st]].setdefault(idx[end], ('forced', pi))
    for st in states:
        for c in range(NC):
            for a in ADV:
                if a != st[c] and rank(other_world, c, a) >= rank(other_world, c, st[c]):
                    adj[idx[st]].setdefault(idx[st[:c] + a + st[c + 1:]], ('bg', c, a))
    print("forced world-%d records (base, change):" % (other_world + 1), len(forced),
          " graph edges:", sum(len(a) for a in adj))

    def better(q, p):
        d = drank(other_world, p, q)
        return all(x <= 0 for x in d) and any(x < 0 for x in d)

    R = [0] * n
    for a in range(n):
        for b in adj[a]:
            R[a] |= 1 << b
    changed, it = True, 0
    while changed:
        changed, it = False, it + 1
        for a in range(n):
            x = R[a]; y = x; m = x
            while m:
                low = m & -m; b = low.bit_length() - 1; m ^= low
                y |= R[b]
            if y != x:
                R[a] = y; changed = True
    print("closure iterations", it)
    bad = [(P, Q) for P in range(n) for Q in range(n) if (R[P] >> Q) & 1 and better(states[Q], states[P])]
    print("reachable strict world-%d improvements:" % (other_world + 1), len(bad))
    if not bad:
        print("no forced reversal under hypothesis V")
        return
    # shortest witness
    best = None
    for P0, Q0 in bad[:400]:
        prev = {P0: None}; dq = collections.deque([P0])
        while dq:
            s_ = dq.popleft()
            if s_ == Q0:
                break
            for t, lab in adj[s_].items():
                if t not in prev:
                    prev[t] = (s_, lab); dq.append(t)
        path = []; s_ = Q0
        while prev[s_] is not None:
            a, lab = prev[s_]; path.append((states[a], lab, states[s_])); s_ = a
        path.reverse()
        if best is None or len(path) < len(best[2]):
            best = (states[P0], states[Q0], path)
    P, Q, path = best
    print("REVERSAL at world %d under V: from %s to %s (strictly better at world %d)" % (other_world + 1, P, Q,
                                                                                      other_world + 1))
    for a, lab, b in path:
        print("   ", a, "->", b, lab, " world-1 ladder:", ladder(0, a, b), " (B) accepts:",
              B_accepts(ladder(0, a, b)), " world-%d rank change:" % (other_world + 1), drank(other_world, a, b))


if __name__ == "__main__":
    main((0, 1), 1)
    main((0, 2), 2)
