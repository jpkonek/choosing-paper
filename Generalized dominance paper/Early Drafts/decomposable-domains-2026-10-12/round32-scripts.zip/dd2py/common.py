"""DD2 common data: CC1's seven cells, world ranks, posterior-family patterns, seed bases and seed records.
Advice on a cell: '+' accept h, '0' silence, '-' accept -h ('x' contradictory omitted: fragment).
Exact rationals throughout."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fractions import Fraction as F
import itertools
from patterns import CELLS, H, adv, pattern, T1, u
ADV = '+0-'
NC = len(CELLS)
SIGN = [[1 if H[c][i] > 0 else -1 for i in range(3)] for c in CELLS]

def rank(i, c, a):
    """world-i rank of advice a on cell index c: good 0, silence 1, bad 2"""
    if a == '0': return 1
    good = '+' if SIGN[c][i] > 0 else '-'
    return 0 if a == good else 2

# seed bases (CC1): B_1 = C_u = D_T1, B_2..B_4 rational triangles; patterns on the cells (accept or silence)
ACC = {(0,1):[1,1,0,0],(0,2):[1,0,1,0],(0,3):[1,0,0,1],(1,2):[1,0,0,1],(1,3):[1,0,1,0],(2,3):[0,0,1,1],():[1,1,1,1]}
BASES_SEED = [''.join('+' if ACC[c][k] else '0' for c in CELLS) for k in range(4)]
X_SEED = [''.join('0' if ch == '+' else '+' for ch in b) for b in BASES_SEED]

def grid_bases(N=120):
    """distinct (pattern, support) pairs of the posterior family K^0 on an N-grid of the simplex (no ties at centres)"""
    out = {}
    for a in range(N + 1):
        for b in range(N + 1 - a):
            p = [F(a, N), F(b, N), F(N - a - b, N)]
            pt = pattern(p)
            if '?' in pt: continue
            s = tuple(i for i in range(3) if p[i] > 0)
            out.setdefault((pt, s), p)
    return out

def drank(i, start, end):
    """per-cell world-i rank change of the record start->end (strings over ADV)"""
    return [rank(i, c, end[c]) - rank(i, c, start[c]) for c in range(NC)]

def ladder(i, start, end):
    """world-i ladder increments: per cell two increments (0-1, 1-2), entries in {-1,0,1}"""
    v = []
    for c in range(NC):
        r0, r1 = rank(i, c, start[c]), rank(i, c, end[c])
        for j in (0, 1):  # increment between rank j and j+1
            if r0 <= j < r1: v.append(1)
            elif r1 <= j < r0: v.append(-1)
            else: v.append(0)
    return v

def designated(c):
    """index (0 or 1) of the increment changed by the + <-> 0 swap at world 1 on cell c"""
    return 0 if SIGN[c][0] > 0 else 1

G = []
for k in range(4):
    g = [0] * (2 * NC)
    for ci, S in enumerate(CELLS):
        g[2 * ci + designated(ci)] = 1 if k in S else -1
    G.append(g)

def B_accepts(v):
    """audit's finite-bundle relation (B) on a ladder vector v"""
    if all(x >= 0 for x in v): return True
    return any(all(x >= y for x, y in zip(v, g)) for g in G)
