"""DD2 Prop 2.5 sanity check (NUMERICS on cell centres + random problems): along each edge of the simplex the
posterior boundary family K^0 is a pointwise chain at the two edge worlds (moving toward e_i improves world i).
Run: python3 -I edge_chain.py"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import random
from fractions import Fraction as F
from patterns import T1
def advice(p, h):
    vals = [sum(p[i]*v[i]*h[i] for i in range(3)) for v in T1]
    if all(x > 0 for x in vals): return '+'
    if all(x < 0 for x in vals): return '-'
    return '0'
def rk(i, h, a):
    if a == '0': return 1
    return 0 if (a == '+') == (h[i] > 0) else 2
random.seed(1)
viol = 0; strict = 0; tests = 0
for (i, j) in ((0, 1), (0, 2), (1, 2)):
    xs = [F(k, 200) for k in range(1, 200)]
    for _ in range(4000):
        h = [random.uniform(-1, 1) for _ in range(3)]
        if h[0] <= 0: h = [-x for x in h]
        prev = None
        for x in xs:
            p = [F(0)] * 3; p[i] = 1 - x; p[j] = x      # moving x up = toward e_j
            a = advice(p, h)
            if prev is not None:
                tests += 1
                if rk(j, h, a) > rk(j, h, prev): viol += 1   # world j must not get worse toward e_j
                if rk(i, h, a) < rk(i, h, prev): viol += 1   # world i must not get better toward e_j
                if a != prev: strict += 1
            prev = a
print("edge steps tested:", tests, " monotonicity violations:", viol, " advice changes seen:", strict)
