"""DD2: advice patterns of the posterior family K^0_p = co{p.v_k/(p.v_k)} on the seven CC1 cell centres.
Exact rationals. Advice per cell: '+' accept h, '0' silence, '-' accept -h.  Run: python3 -I patterns.py"""
from fractions import Fraction as F
import itertools, collections
eps=F(3,10); u=[F(1,3)]*3
T1=[[(1-eps)*u[i]+eps*(1 if i==k else 0) for i in range(3)] for k in range(3)]
CELLS=[(0,1),(0,2),(0,3),(1,2),(1,3),(2,3),()]
H={ (0,1):['1','-30809/100000','-3/20'], (0,2):['1','-3/20','-319/1000'], (0,3):['3/20','-46328/100000','1'],
    (1,2):['-2766/10000','1','-2766/10000'], (1,3):['-29159/100000','-23288/100000','1'],
    (2,3):['1','1','-91083/100000'], ():['-22449/100000','1','1']}
H={c:[F(x) for x in v] for c,v in H.items()}
def adv(p,h):
    vals=[sum(p[i]*v[i]*h[i] for i in range(3)) for v in T1]
    if all(x>0 for x in vals): return '+'
    if all(x<0 for x in vals): return '-'
    if any(x==0 for x in vals): return '?'
    return '0'
def pattern(p): return ''.join(adv(p,H[c]) for c in CELLS)
if __name__=="__main__":
    N=60
    pats=collections.defaultdict(list)
    for a in range(N+1):
        for b in range(N+1-a):
            p=[F(a,N),F(b,N),F(N-a-b,N)]
            pats[(tuple(i for i in range(3) if p[i]>0),pattern(p))].append(tuple(p))
    print("cells order:",CELLS)
    print("u pattern",pattern(u))
    bysupp=collections.defaultdict(set)
    for (s,pt),L in pats.items(): bysupp[s].add(pt)
    for s in sorted(bysupp,key=lambda x:(len(x),x)):
        print("support",s,"patterns:",sorted(bysupp[s]))
