"""DD2 Lemma 2.10 (CHECKED exactly): the conversion cycle B1 -g1-> X1 -c12-> B2 -g2-> X2 -c23-> B3 -g3-> X3 -c34-> B4
-g4-> X4 -c41'-> B1' with B1' = B1 corrected on the empty cell.  Prints world-1 rank changes per cell.
Run: python3 -I cycle_check.py"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
B = BASES_SEED; X = X_SEED
B1p = B[0][:6] + ('0' if rank(0, 6, '0') < rank(0, 6, B[0][6]) else B[0][6])
chain = [B[0], X[0], B[1], X[1], B[2], X[2], B[3], X[3], B1p]
names = ['B1', 'X1', 'B2', 'X2', 'B3', 'X3', 'B4', 'X4', "B1'"]
print("cells:", CELLS)
tot = [0] * NC
for a, b, na, nb in zip(chain, chain[1:], names, names[1:]):
    d = drank(0, a, b); tot = [x + y for x, y in zip(tot, d)]
    print(f"{na:>3} -> {nb:<3} world-1 rank change {d}  sum {sum(d)}  (B) accepts: {B_accepts(ladder(0, a, b))}")
print("composite B1 -> B1' :", drank(0, B[0], B1p), " = sum of steps", tot)
