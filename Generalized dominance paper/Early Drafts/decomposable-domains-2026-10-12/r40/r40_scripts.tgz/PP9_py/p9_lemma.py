"""PP9 lemma checks (CHECKED, exact integer/rational arithmetic).

(1) Regular-improvement lemma (pointwise): on a problem where the OLD advice is regular (correct on unanimous
    problems, A/S/B on mixed ones), every change that strictly improves world j has delta_u + delta_v >= 0 for
    the two other worlds, with equality exactly on M_u u M_v (j in the majority) and 2|delta_j| on M_j.
(2) Line 12 of the optional-defenders audit: every nontrivial change alters the rank at every world.
(3) Finite abstract cross-check of Theorem A: random finite 'problem atoms' (classes M_1,M_2,M_3,U), random
    masses, a random finite list of regular 'selected' models (the coherent family stand-in: anchoring means
    agreeing with one of them on the changed atoms), a random pool of arbitrary models (incl. contradiction).
    Protected link (s=1): b_l < 0 at all worlds, old side anchored, new side not, Phi4_j >= 0.
    Guidance link at j: Q_j null.  Claim: no 3-cycle at any world made only of protected and guidance links
    contains a protected link (such a cycle is a (TC) violation since protected links are strict)."""
import itertools, random
from fractions import Fraction as F

ADV = ['A', 'S', 'B', 'C']
def rank(adv, cls, j):
    if adv == 'C': return 3
    if adv == 'S': return 1
    if cls == 'U': return 0 if adv == 'A' else 2          # 'A' = correct on unanimous problems
    maj = (j != cls)
    if adv == 'A': return 0 if maj else 2
    return 2 if maj else 0                                # 'B' = minority answer

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s); out.append(s)

pr('(1) regular-improvement lemma')
viol = 0; eqcases = {}; n = 0
for cls in [0, 1, 2, 'U']:
    olds = ['A'] if cls == 'U' else ['A', 'S', 'B']
    for old in olds:
        for new in ADV:
            if new == old: continue
            for j in range(3):
                d = [rank(new, cls, l) - rank(old, cls, l) for l in range(3)]
                if d[j] < 0:
                    n += 1
                    u, v = [l for l in range(3) if l != j]
                    s = d[u] + d[v]
                    if s < 0: viol += 1
                    eqcases.setdefault((cls == j, s), 0); eqcases[(cls == j, s)] += 1
pr('   improving (class, old, new, j) cases: %d; violations of delta_u+delta_v >= 0: %d' % (n, viol))
pr('   (j is the minority world?, delta_u+delta_v) -> count:', sorted(eqcases.items(), key=str))

pr('(2) every nontrivial change alters every rank')
bad = 0
for cls in [0, 1, 2, 'U']:
    for old in ADV:
        for new in ADV:
            if new != old and any(rank(new, cls, l) == rank(old, cls, l) for l in range(3)): bad += 1
pr('   counterexamples: %d' % bad)

pr('(3) abstract finite cross-check of Theorem A')
def run(seed, natoms=7, nsel=6, npool=45, irregular_anchor=False):
    rnd = random.Random(seed)
    classes = [rnd.choice([0, 1, 2, 'U']) for _ in range(natoms)]
    mass = [F(rnd.randint(1, 9), 7) for _ in range(natoms)]
    def regular():
        return tuple('A' if c == 'U' else rnd.choice('ASB') for c in classes)
    sel = list({regular() for _ in range(nsel)})
    if irregular_anchor:          # control: an irregular 'coherent' model (contradiction / wrong on unanimous)
        x = list(sel[0]); k = rnd.randrange(natoms); x[k] = 'C'; sel.append(tuple(x))
    pool = set(sel)
    while len(pool) < npool:
        x = list(rnd.choice(sel))
        for k in rnd.sample(range(natoms), rnd.randint(1, 3)): x[k] = rnd.choice(ADV)
        pool.add(tuple(x))
    pool = list(pool)
    def recd(X, Y):
        D = [k for k in range(natoms) if X[k] != Y[k]]
        P = [sum((mass[k]*max(0, rank(Y[k], classes[k], j) - rank(X[k], classes[k], j)) for k in D), F(0)) for j in range(3)]
        Q = [sum((mass[k]*max(0, rank(X[k], classes[k], j) - rank(Y[k], classes[k], j)) for k in D), F(0)) for j in range(3)]
        anc = lambda Z: any(all(S[k] == Z[k] for k in D) for S in sel)
        return D, P, Q, anc(X), anc(Y)
    n = len(pool)
    link = {}
    nprot = 0
    for a in range(n):
        for b in range(n):
            if a == b: continue
            D, P, Q, ax, ay = recd(pool[a], pool[b])
            for j in range(3):
                g = (Q[j] == 0)
                prot = ax and not ay and all(P[l] - Q[l] < 0 for l in range(3)) and 4*P[j] - Q[j] >= 0
                elig = ax and 4*P[j] - Q[j] >= 0
                nprot += prot
                link[(a, b, j)] = 'G' if g else ('P' if prot else ('0' if elig else None))
    bad = ctrl = 0
    for j in range(3):
        for a, b, c in itertools.permutations(range(n), 3):
            ls = (link[(a, b, j)], link[(b, c, j)], link[(c, a, j)])
            if None in ls or 'P' not in ls: continue
            if '0' in ls: ctrl += 1
            else: bad += 1
    return nprot, bad, ctrl

for irr in (False, True):
    tot_p = tot_b = tot_c = 0
    for seed in range(60):
        p, b, c = run(seed, npool=50, irregular_anchor=irr); tot_p += p; tot_b += b; tot_c += c
    pr('   %s: 60 random instances (7 atoms, ~6 anchors, 50 models): protected links %d; cycles made of protected+guidance links only (containing a protected link): %d; control: cycles with a protected link and an ordinary eligible link: %d'
       % ('anchors regular (Theorem A setting)' if not irr else 'CONTROL, one irregular anchor allowed', tot_p, tot_b, tot_c))

open(__file__.replace('.py', '.out'), 'w').write('\n'.join(out) + '\n')
