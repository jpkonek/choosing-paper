"""PP9 B1 (CHECKED): drop triangles delete the STICKY defences of a non-protected three-cone record, and the
resulting non-closed section (Q2).

Cones: PP7 t8's base cones T_w (largest silent cell of C_p0 in class M_w), and sub-cones S_w of them.
  X  = C_p0 with A on S_1, S_2, S_3, masses mu = (2.2, 1, 1) a      (world indices 0,1,2 = worlds 1,2,3)
  d* = rec(C_p0, X):  b = (+, -, -)  -> NOT protected (s = 0);  rev d* has A = empty (outer polygon empty)
  Z2 = C_p0 with A on S_3  (a pointwise strict world-2 improvement of C_p0)
  Z3 = C_p0 with A on S_2  (a pointwise strict world-3 improvement of C_p0)
Triangle at world 2: C <=_2 X (d*), X <=_2 Z2 (rec(X,Z2), chosen at world 2 by the joint rule), Z2 <=_2 C
(guidance), while X <=_2 C is refused.  The pair {C,X} has the lowest priority, so d* is deleted at world 2.
Symmetrically at world 3.

Q2 part: S_1 is replaced by the nested family S_1(s) (PP7 'shrunk'); s* with mu_1(s*) = mu_2 + mu_3 exists by
the intermediate value theorem and is bracketed by certified s_lo < s* < s_hi.  All inequalities of the drop
triangle are certified uniformly for mu_1 in [mu_1(s_lo), mu_1(s_hi)] (closed-form record data, cross-checked
against the exact cell computation at s_lo and s_hi), and A(rev d*) is empty already for s_lo."""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

CFG = {
    'e1_3': ((F(9, 10), F(6, 100), F(4, 100)), F(3, 10)),
    'e1_1': ((F(9, 10), F(6, 100), F(4, 100)), F(1, 10)),
    'u_3':  ((F(35, 100), F(33, 100), F(32, 100)), F(3, 10)),
    'u_1':  ((F(35, 100), F(33, 100), F(32, 100)), F(1, 10)),
}
E = [(F(1), F(0), F(0)), (F(0), F(1), F(0)), (F(0), F(0), F(1))]

def base_cones(p0, eps):
    cells = base_cells(p0, eps)
    sil = {0: [], 1: [], 2: []}
    for c in cells:
        g = interior(c)
        if cls(g) != 'U' and sel_advice(p0, g, eps) == '0': sil[cls(g)].append(c)
    big = {w: max(sil[w], key=lambda c: mass_float(largest_triangle(c))) for w in range(3)}
    tau = 0.25*min(mass_float(largest_triangle(big[w])) for w in range(3))
    return [cone_with_mass(big[w], tau) for w in range(3)], tau

def A_on(C, cones, name):
    return C.with_ov([(S, adv_from_label(interior(list(S)), 'A')) for S in cones], name=name)

def pair(X, Y, wd, wb):
    rd, rb = rec(X, Y), rec(Y, X)
    Ad, Fd, okd = anchor_info(rd, wd); Ab, Fb, okb = anchor_info(rb, wb)
    jc = joint_choice(rd, rb, Ad, Fd, Ab, Fb)
    return dict(rd=rd, rb=rb, Ad=Ad, Ab=Ab, Fd=Fd, Fb=Fb, jc=jc, okd=okd, okb=okb)

def acc_of(pairs, names, i):
    acc = {}
    for a in range(3):
        acc[(a, a)] = True
        for b in range(3):
            if a == b: continue
            key = (names[a], names[b])
            if key in pairs: acc[(a, b)] = bool(pairs[key]['jc']['state'][i][0])
            else: acc[(a, b)] = bool(pairs[(names[b], names[a])]['jc']['state'][i][1])
    return acc

def prio_of(pairs, x, y, i):
    if (x, y) in pairs: P = pairs[(x, y)]
    else: P = pairs[(y, x)]
    return priority(P['rd'], P['rb'], P['Ad'], P['Ab'], P['jc']['state'], i)

def show_prio(p):
    if p is None: return 'absent'
    if p[0] == 'G': return 'guidance (unremovable)'
    return '(s=%d, m=%s)' % (p[0], ivs(p[1], 6))

def triangle(pairs, names, i):
    acc = acc_of(pairs, names, i)
    viol = tc_violation(acc)
    pr('      triangle %s at world %d: accepted links %s ; (TC) violated: %s' % (
        names, i+1, ['%s<=%s' % (names[a], names[b]) for a in range(3) for b in range(3) if a != b and acc[(a, b)]], viol))
    pp = {(names[a], names[b]): prio_of(pairs, names[a], names[b], i) for a, b in [(0, 1), (1, 2), (0, 2)]}
    for k, v in pp.items(): pr('         pair {%s,%s}: %s' % (k[0], k[1], show_prio(v)))
    target = pp[(names[0], names[1])]
    lowest = all(prio_less(target, v) for k, v in pp.items() if k != (names[0], names[1]))
    pr('         pair {%s,%s} is the unique lowest-priority removable pair: %s' % (names[0], names[1], lowest))
    return viol and lowest

def run(key):
    p0, eps = CFG[key]
    t0 = time.time()
    pr('\n=== %s: eps = %s, p0 = %s' % (key, eps, tuple(str(x) for x in p0)))
    T, tau = base_cones(p0, eps)
    a = 0.4*tau
    mus = [2.2*a, a, a]
    S = [cone_in_tri_with_mass(T[w], mus[w]) for w in range(3)]
    C = Model(p0, eps, name='C')
    X = A_on(C, S, 'X'); Z2 = A_on(C, [S[2]], 'Z2'); Z3 = A_on(C, [S[1]], 'Z3')
    pairs = {}
    pairs[('C', 'X')] = pair(C, X, [p0], [])
    pairs[('X', 'Z2')] = pair(X, Z2, [E[2]], [p0])
    pairs[('Z2', 'C')] = pair(Z2, C, [E[0], E[1]], [p0])
    pairs[('X', 'Z3')] = pair(X, Z3, [E[1]], [p0])
    pairs[('Z3', 'C')] = pair(Z3, C, [E[0], E[2]], [p0])
    d = pairs[('C', 'X')]
    pr('   cone masses (one side) mu =', [ivs(mass_iv(list(s)), 6) for s in S])
    pr('   d* = rec(C,X): b =', fmt(d['rd']['add']), ' Phi4 =', fmt(d['rd']['phi4']))
    pr('      A(d*) contains p0 (exact): %s, faces %s ; A(rev d*) certified EMPTY (outer polygon): %s' % (d['Ad'], d['Fd'], d['Ab'] is False))
    pr('      protected? %s (needs b < 0 at all worlds)' % all(ivsign(x) < 0 for x in d['rd']['add']))
    pr('      joint choice: state %s (unique: %s) -> d* accepted at worlds %s' % (d['jc']['state'], d['jc']['unique'], [i+1 for i in range(3) if d['jc']['state'][i][0]]))
    ok_all = True
    for (x, y) in [('X', 'Z2'), ('Z2', 'C'), ('X', 'Z3'), ('Z3', 'C')]:
        P = pairs[(x, y)]
        pr('   rec(%s,%s): b = %s, guidance %s, A(.) %s faces %s; rev: A %s faces %s; joint choice %s unique %s' % (
            x, y, fmt(P['rd']['add']), [i+1 for i in range(3) if P['rd']['guid'][i]], P['Ad'], P['Fd'], P['Ab'], P['Fb'], P['jc']['state'], P['jc']['unique']))
        ok_all &= P['jc']['unique']
        # robustness of the joint choice to the (conservative) face sets: recompute with interior-only faces
        alt = joint_choice(P['rd'], P['rb'], P['Ad'], [(0, 1, 2)] if P['Ad'] else [], P['Ab'], [(0, 1, 2)] if P['Ab'] else [])
        if alt['state'] != P['jc']['state']: pr('      WARNING: choice depends on the conservative faces'); ok_all = False
    r2 = triangle(pairs, ['C', 'X', 'Z2'], 1)
    r3 = triangle(pairs, ['C', 'X', 'Z3'], 2)
    pr('   => d* deleted at world 2: %s ; at world 3: %s ; its world-1 defence has b_1 > 0 (additively safe)' % (r2, r3))
    # ---------------- Q2: s* with mu_1(s*) = mu_2 + mu_3 (IVT bracket), uniform certification
    m2, m3 = mass_iv(list(S[1])), mass_iv(list(S[2]))
    target = m2 + m3
    lo, hi = F(0), F(1)
    full = T[0]
    assert lohi(mass_iv(list(full)))[0] > lohi(target)[1]
    for _ in range(40):
        mid = (lo + hi)/2
        if mass_float(shrunk(full, mid)) < float(ivmid(target)): lo = mid
        else: hi = mid
    s_lo, s_hi = lo - F(1, 2**30), hi + F(1, 2**30)
    S1lo, S1hi = shrunk(full, s_lo), shrunk(full, s_hi)
    M1lo, M1hi = mass_iv(list(S1lo)), mass_iv(list(S1hi))
    br = lohi(M1lo)[1] < lohi(target)[0] and lohi(target)[1] < lohi(M1hi)[0]
    pr('   Q2: bracket s in [%s, %s]: mu_1(s_lo) < mu_2+mu_3 < mu_1(s_hi) certified: %s' % (float(s_lo), float(s_hi), br))
    Xlo = A_on(C, [S1lo, S[1], S[2]], 'Xlo'); Xhi = A_on(C, [S1hi, S[1], S[2]], 'Xhi')
    rlo, rhi = rec(Xlo, C), rec(Xhi, C)
    pr('       A(rev d*(s_lo)) certified empty: %s  (so A(rev d*(s)) is empty for every s >= s_lo: more constraints)' % rlo['poly_empty'])
    # closed forms (per problem mass, record units = 2 x cone mass): S->A on M_w moves world w by +1, others by -1
    dlo, dhi = rec(C, Xlo), rec(C, Xhi)
    def cf(m1):
        mm = [2*m1, 2*m2, 2*m3]
        b = [mm[i] - sum(mm[w] for w in range(3) if w != i) for i in range(3)]
        return mm, b
    for m1, dd in ((M1lo, dlo), (M1hi, dhi)):
        mm, b = cf(m1)
        agree = all(abs(float(ivmid(b[i] - dd['add'][i]))) < 1e-12 for i in range(3))
        pr('       closed-form b agrees with the exact cell computation: %s' % agree)
    M1 = iv.mpf([lohi(M1lo)[0], lohi(M1hi)[1]])     # interval hull: contains mu_1(s*)
    mm = [2*M1, 2*m2, 2*m3]
    # at s*: b_1 = 0 exactly (by construction), b_2 = -2 mu_1(s*)... certified < 0 uniformly:
    b2 = mm[1] - mm[0] - mm[2]; b3 = mm[2] - mm[0] - mm[1]
    phi2_d = 4*mm[1] - mm[0] - mm[2]
    m_d2 = phi2_d/(mm[0] + mm[1] + mm[2])
    # rec(X,Z2) = A->S on S_1 u S_2.  World 2: P = mm0, Q = mm1.  World 1: P = mm1, Q = mm0.  World 3: guidance.
    c2 = mm[1]/(mm[0] + mm[1]); c1 = mm[0]/(mm[0] + mm[1])
    phi2_xz = 4*mm[0] - mm[1]; phi1_xz = 4*mm[1] - mm[0]; phi1_zx = 4*mm[0] - mm[1]; phi2_zx = 4*mm[1] - mm[0]
    m_xz2 = phi2_xz/(mm[0] + mm[1])
    conds = {
        'b_2(d*) < 0': ivsign(b2) < 0, 'b_3(d*) < 0': ivsign(b3) < 0,
        'Phi4_2(d*) > 0 (d* accepted at world 2)': ivsign(phi2_d) > 0,
        'rec(X,Z2) and its reverse eligible at worlds 1,2': all(ivsign(x) > 0 for x in (phi2_xz, phi1_xz, phi1_zx, phi2_zx)),
        'c_2(rec(X,Z2)) < 1/2 < c_1(rec(X,Z2)) (rule picks rec(X,Z2) at 2, reverse at 1)': lohi(c2)[1] < 0.5 < lohi(c1)[0],
        'm(rec(X,Z2), world 2) > m(d*, world 2)': lohi(m_xz2)[0] > lohi(m_d2)[1],
    }
    for k, v in conds.items(): pr('       uniform on the bracket: %s: %s' % (k, v))
    pr('       => at s*, d*(s*) has b_1 = 0 (s = 0, unprotected) and is deleted at world 2 by the drop triangle;')
    pr('          for p(t) = (p0 - t e1)/(1-t), t > 0 small, rec(C_p(t), X(s*)) is protected (PROVED), hence never deleted.')
    # illustration at one t: exact pointwise world-1 improvement and certified protection for every s in the bracket
    t = F(1, 2000)
    pt = tuple((p0[k] - (t if k == 0 else 0))/(1 - t) for k in range(3))
    Ct = Model(pt, eps, name='Ct')
    g = rec(C, Ct)
    pr('       t = %s: C_p0 is a pointwise world-1 improvement of C_p(t) (exact cells): %s, and the change is non-null: %s' % (t, g['guid'][0], lohi(g['P'][0])[0] > 0))
    ehi, elo = rec(Ct, Xhi), rec(Ct, Xlo)
    prot = ivsign(ehi['add'][0]) < 0 and ivsign(elo['add'][1]) < 0 and ivsign(elo['add'][2]) < 0 and ivsign(ehi['phi4'][1]) > 0
    pr('       t = %s: b_1(rec(C_p(t),X(s_hi))) = %s, b_2,b_3(rec(C_p(t),X(s_lo))) = %s, %s; Phi4_2(rec(C_p(t),X(s_hi))) = %s'
       % (t, ivs(ehi['add'][0], 5), ivs(elo['add'][1], 5), ivs(elo['add'][2], 5), ivs(ehi['phi4'][1], 5)))
    pr('       => rec(C_p(t), X(s)) protected and accepted at world 2 for every s in the bracket (monotonicity in mu_1): %s' % prot)
    pr('   time %.0fs' % (time.time() - t0))
    return r2 and r3 and ok_all and br and all(conds.values()) and prot

if __name__ == '__main__':
    res = {}
    for key in (sys.argv[1:] or list(CFG)):
        res[key] = run(key)
    pr('\nSUMMARY:', res)
    open(os.path.join(HERE, 'p9_B1_%s.out' % '_'.join(sys.argv[1:] or ['all'])), 'w').write('\n'.join(out) + '\n')
