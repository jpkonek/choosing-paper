"""PP9 common: the joint-defence candidate (AUDIT_joint_defence.md) evaluated EXACTLY on single record pairs.

Re-uses PP7's exact geometry (PP7_py/core.py, read only): rational cones, exact cells, interval solid
angles, exact anchor polygons.

For a record pair {d, rev d} this module computes, exactly / with certified interval signs:
  * P_i, Q_i, b_i = add_i, Phi4_i = 4 nu(P_i) - nu(Q_i), c_i = nu(Q_i)/(nu(P_i)+nu(Q_i));
  * guidance at each world (exact cell test);
  * anchor information: outer anchor polygon (empty => A(d) is certainly empty), explicit witnesses
    verified on exact refined cells (=> A(d) certainly nonempty), and the faces met;
  * the joint initial choice of AUDIT_joint_defence.md section 2 (all 64 states, objectives 1-3,
    the optimum certified unique so that objective 4 never acts);
  * the priority (s, m) of the pair at a world (section 3);
  * (TC) violation of an ordered triple at a world.
Conventions are PP7's: X <=_i Y is accepted on rec(X,Y); P_i = steps Y adds (errors added)."""
import sys, os, itertools
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'PP7_py'))
from core import *          # noqa: F401,F403  (PP7 library, read only)

COORD = [(1, 0, 0), (0, 1, 0), (0, 0, 1)]

def rec(X, Y):
    """certified record data for rec(X,Y)."""
    cells, _ = record_cells(X, Y)
    r = record(X, Y, use_iv=True, cells=cells)
    ch = r['changed']
    r['guid'] = [len(ch) > 0 and all(rank(ay, interior(c), j) >= rank(ax, interior(c), j) for c, ax, ay in ch)
                 for j in range(3)]
    r['phi4'] = [4*r['P'][i] - r['Q'][i] for i in range(3)]
    r['c'] = [r['Q'][i]/(r['P'][i] + r['Q'][i]) for i in range(3)]
    r['mratio'] = [r['phi4'][i]/(r['P'][i] + r['Q'][i]) for i in range(3)]
    mu = iv.mpf(0)
    for c, ax, ay in ch: mu += mass_iv(c)
    r['mu'] = mu
    r['old_silent'] = any(ax == '0' for c, ax, ay in ch)
    r['old_contra'] = any(ax == 'C' for c, ax, ay in ch)
    r['poly'] = anchor_set(ch, X.eps)
    r['poly_empty'] = all(len(r['poly'][k]) == 0 for k in range(3))
    r['eps'] = X.eps
    return r

def verify_anchor(r, q):
    """exact: C_q's advice equals the old advice on every changed cell (cells refined by q's planes)."""
    eps = r['eps']
    pl = dedup_planes(normals(q, eps) + DIAG + COORD)
    for c, ax, ay in r['changed']:
        for sc in arrangement(pl, start=[list(c)]):
            if sel_advice(q, interior(sc), eps) != ax: return False
    return True

def anchor_info(r, witnesses=()):
    """(status, faces): status True (certified nonempty: a witness verified), False (certified empty:
    outer polygon empty or contradictory old side), None (undecided).  Faces: interior only when the old
    side is silent on a non-null set (a precise boundary model is silent only on a null set); otherwise
    the faces met by the closed exact polygon (conservative superset)."""
    if r['old_contra'] or r['poly_empty']: return False, [], []
    ok = [q for q in witnesses if verify_anchor(r, q)]
    st = True if ok else None
    if r['old_silent']: faces = [(0, 1, 2)]
    else: faces = faces_met(r['poly'])
    return st, faces, ok

def sgn(x): return ivsign(x)

def joint_choice(rd, rb, Ad, Fd, Ab, Fb):
    """AUDIT section 2 for the pair (d, rev d).  Ad/Ab: anchor status (True/False), Fd/Fb: faces.
    Returns dict(state=[(acc_d, acc_b) per world], unique=bool, feasible=n, ...)."""
    def allowed(r, A, i):
        if r['guid'][i]: return 'G'
        if not A: return None
        s = sgn(r['phi4'][i])
        if s > 0: return 'E'
        if s < 0: return None
        return '?'
    al_d = [allowed(rd, Ad, i) for i in range(3)]
    al_b = [allowed(rb, Ab, i) for i in range(3)]
    if '?' in al_d + al_b: raise ValueError('uncertified eligibility sign')
    best = []
    for st in itertools.product([(0, 0), (1, 0), (0, 1), (1, 1)], repeat=3):
        ok = True
        for i in range(3):
            a, b = st[i]
            if al_d[i] == 'G' and not a: ok = False
            if al_b[i] == 'G' and not b: ok = False
            if a and al_d[i] is None: ok = False
            if b and al_b[i] is None: ok = False
        if not ok: continue
        if Ad:
            for I in Fd:
                if not any(st[i][0] for i in I): ok = False
        if Ab:
            for I in Fb:
                if not any(st[i][1] for i in I): ok = False
        if not ok: continue
        nboth = sum(1 for i in range(3) if st[i] == (1, 1))
        nng = sum(1 for i in range(3) if st[i][0] and al_d[i] == 'E') + sum(1 for i in range(3) if st[i][1] and al_b[i] == 'E')
        cs = iv.mpf(0)
        for i in range(3):
            if st[i][0] and al_d[i] == 'E': cs += rd['c'][i]
            if st[i][1] and al_b[i] == 'E': cs += rb['c'][i]
        best.append((nboth, -nng, cs, st))
    if not best: return dict(state=None, unique=False, feasible=0)
    k1 = min(x[0] for x in best); best = [x for x in best if x[0] == k1]
    k2 = min(x[1] for x in best); best = [x for x in best if x[1] == k2]
    # objective 3, certified
    lo = lambda x: lohi(x[2])[0]; hi = lambda x: lohi(x[2])[1]
    cand = min(best, key=lambda x: float(lohi(x[2])[1]))
    others = [x for x in best if x[3] != cand[3]]
    unique = all(hi(cand) < lo(x) for x in others)
    return dict(state=cand[3], unique=unique, feasible=len(best), obj=(k1, -k2, ivs(cand[2], 6)),
                al_d=al_d, al_b=al_b)

def priority(rd, rb, Ad, Ab, st, i):
    """priority of the pair at world i in the chosen state: 'G' (unremovable), (1, m) or (0, m), None if absent."""
    a, b = st[i]
    if not (a or b): return None
    if (a and rd['guid'][i]) or (b and rb['guid'][i]): return ('G',)
    s = 0
    if a and Ad and not Ab and all(sgn(x) < 0 for x in rd['add']): s = 1
    if b and Ab and not Ad and all(sgn(x) < 0 for x in rb['add']): s = 1
    ms = []
    if a: ms.append(rd['mratio'][i])
    if b: ms.append(rb['mratio'][i])
    m = ms[0] if len(ms) == 1 else (ms[0] if lohi(ms[0])[1] < lohi(ms[1])[0] else ms[1])
    return (s, m)

def prio_less(p1, p2):
    """certified strict p1 < p2 in the lexicographic (s, m) order; 'G' is +infinity."""
    if p1[0] == 'G': return False
    if p2[0] == 'G': return True
    if p1[0] != p2[0]: return p1[0] < p2[0]
    return lohi(p1[1])[1] < lohi(p2[1])[0]

def tc_violation(acc):
    """acc[(a,b)] = a <= b accepted (a,b in 0..2).  True iff the triple violates (TC)."""
    for a, b, c in itertools.permutations(range(3)):
        if acc[(a, b)] and acc[(b, c)] and acc[(c, a)]:
            if not (acc[(b, a)] and acc[(c, b)] and acc[(a, c)]): return True
    return False

def fmt(xs, d=5): return '[' + ', '.join(ivs(x, d) for x in xs) + ']'

def split_cone(tri):
    """two disjoint open simplicial sub-cones of tri (cut through r0 and the midpoint ray of r1 r2)."""
    r0, r1, r2 = tri
    s = [F(1/math.sqrt(float(dot(r, r)))) for r in (r1, r2)]
    mid = prim(tuple(s[0]*r1[t] + s[1]*r2[t] for t in range(3)))
    a, b = (r0, r1, mid), (r0, mid, r2)
    a = a if det3(*a) > 0 else (a[0], a[2], a[1])
    b = b if det3(*b) > 0 else (b[0], b[2], b[1])
    return a, b

def cone_in_tri_with_mass(tri, target, steps=40):
    """exact sub-cone of the simplicial cone tri, shrunk to cone mass <= target (close to it)."""
    if mass_float(tri) <= target: return tri
    lo, hi = F(0), F(1)
    for _ in range(steps):
        mid = (lo + hi)/2
        if mass_float(shrunk(tri, mid)) <= target: lo = mid
        else: hi = mid
    return shrunk(tri, lo)
