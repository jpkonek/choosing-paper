"""PP9 D search (NUMERICS, exploratory): selected models C_q near C_p0 that are MORE MAJORITY than C_p0 on a
non-null set of lines in all three classes ('dominating-splice cells': C_p0 silent, C_q gives A), and
cells where both are silent (candidates for E).  Output: for each candidate q, the largest such cell mass
per class.  Used only to choose the exact instance in p9_D.py."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

CFG = {
    'e1_3': ((F(9, 10), F(6, 100), F(4, 100)), F(3, 10)),
    'e1_1': ((F(9, 10), F(6, 100), F(4, 100)), F(1, 10)),
    'u_3':  ((F(35, 100), F(33, 100), F(32, 100)), F(3, 10)),
    'u_1':  ((F(35, 100), F(33, 100), F(32, 100)), F(1, 10)),
}

def lab(p, g, eps):
    return label(g, sel_advice(p, g, eps))

def scan(p0, eps, q):
    pl = dedup_planes(normals(p0, eps) + normals(q, eps) + DIAG + COORD)
    cells = arrangement(pl)
    dom = {0: [], 1: [], 2: []}; both = {0: [], 1: [], 2: []}
    for c in cells:
        g = interior(c)
        if cls(g) == 'U': continue
        a0, a1 = lab(p0, g, eps), lab(q, g, eps)
        if a0 == 'S' and a1 == 'A': dom[cls(g)].append(c)
        if a0 == 'S' and a1 == 'S': both[cls(g)].append(c)
    return dom, both

if __name__ == '__main__':
    out = []
    for key in (sys.argv[1:] or list(CFG)):
        p0, eps = CFG[key]
        res = []
        for v in [(1, 0, -1), (0, 1, -1), (1, -1, 0), (-1, 1, 0), (-1, 0, 1), (0, -1, 1), (1, 1, -2), (1, -2, 1), (-2, 1, 1)]:
            for th in [F(1, 200), F(1, 500), F(1, 1000), F(1, 3000)]:
                q = tuple(p0[k] + th*v[k] for k in range(3))
                if min(q) <= 0: continue
                dom, both = scan(p0, eps, q)
                mx = [max([mass_float(largest_triangle(c)) for c in dom[w]] or [0]) for w in range(3)]
                mb = [max([mass_float(largest_triangle(c)) for c in both[w]] or [0]) for w in range(3)]
                res.append((min(mx), v, th, mx, mb))
        res.sort(key=lambda x: -x[0])
        s = '%s: best candidates (min over classes of largest dominating-cell triangle mass):' % key
        print(s); out.append(s)
        for r in res[:6]:
            s = '   dir %s theta %s: dom %s, both-silent %s' % (r[1], r[2], ['%.2e' % x for x in r[3]], ['%.2e' % x for x in r[4]])
            print(s); out.append(s)
    open(os.path.join(HERE, 'p9_D_search.out'), 'w').write('\n'.join(out) + '\n')
