"""PP9 Q3 scan (CHECKED where stated): anchoring of the records inside PP7's three-cone family.

Family (PP7 Thm 4.2 / t8): Y(t) = C_p0 with A on S_w(t_w) = shrunk(T_w, t_w), T_w the t8 base cones.
(a) Central-ray test: if no q makes C_q weakly A at the three central rays of T_1, T_2, T_3, then
    A(rec(Y(t), C_p0)) is empty for EVERY t (every S_w(t) contains the central ray; a.e.-agreement implies weak
    agreement at the ray by closedness).  Exact outer polygon with the three rays only.
(b) Transferred rival-to-rival records d = rec(Y(t), Y(t')), t <= t' coordinatewise: by (IB) this is the record
    'S -> A on the three annuli S_w(t'_w) minus S_w(t_w)' out of C_p0.  Its reverse has old side 'A on the
    annuli'.  We test whether rev d is anchored (outer polygon; witness = polygon centroid verified on exact
    cells) and report b(d)."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
from p9_B1 import base_cones, CFG

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def centroid_witnesses(poly):
    ws = []
    for k in range(3):
        P = poly[k]
        if not P: continue
        cx = sum(F(v[0]) for v in P)/len(P); cy = sum(F(v[1]) for v in P)/len(P)
        ws.append((cx, cy, 1 - cx - cy))
    return ws

def annulus_model(C, T, S):
    ov = [(S[w], '0') for w in range(3) if S[w] is not None] + [(T[w], adv_from_label(interior(list(T[w])), 'A')) for w in range(3)]
    return C.with_ov(ov)

for key in (sys.argv[1:] or list(CFG)):
    p0, eps = CFG[key]
    T, tau = base_cones(p0, eps)
    C = Model(p0, eps)
    pr('\n=== %s' % key)
    def cen(tri):   # the common central ray of the nested family shrunk(tri, s), 0 < s <= 1 (same normalisation as core.shrunk)
        sc = [F(1/math.sqrt(float(dot(r, r)))) for r in tri]
        return prim(tuple(sum(sc[k]*tri[k][i] for k in range(3)) for i in range(3)))
    cens = [cen(T[w]) for w in range(3)]
    assert all(in_cone(cens[w], shrunk(T[w], F(1, 1000))) for w in range(3))
    fake = [([cens[w]], adv_from_label(cens[w], 'A'), '0') for w in range(3)]
    poly = anchor_set(fake, eps)
    pr('   (a) weak-A at the three common central rays: outer anchor polygon empty: %s  => A(rec(Y(t),C_p0)) empty for all t' % all(len(poly[k]) == 0 for k in range(3)))
    for s in [F(1, 2), F(4, 5), F(9, 10), F(19, 20)]:
        S = [shrunk(T[w], s) for w in range(3)]
        Yt = annulus_model(C, T, S)     # C_p0 + A on the annuli T_w minus S_w(s)
        d = rec(C, Yt); rb = rec(Yt, C)
        ws = centroid_witnesses(rb['poly'])
        ok = [q for q in ws if verify_anchor(rb, q)]
        pr('   (b) s = %s: annulus masses %s; b(d) = %s; rev d: outer polygon empty %s; verified witness %s' % (
            s, [ivs(mass_iv(list(T[w])) - mass_iv(list(S[w])), 4) for w in range(3)], fmt(d['add'], 4), rb['poly_empty'],
            [tuple(str(x) for x in q) for q in ok][:1]))
    open(os.path.join(HERE, 'p9_Q3_scan.out'), 'a').write('\n'.join(out) + '\n'); out.clear()
