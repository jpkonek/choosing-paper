"""PP9 D (CHECKED): an anchored record that loses EVERY defender under the joint-defence rule.

Construction (all cones exact, masses certified by interval arithmetic):
  q      : a selected model near p0 that is more 'majority' than C_p0 on lines of all three classes
           (cells where C_p0 is silent and C_q says A; p9_D_search.py);
  T_l    : cones in those cells, class l = lam (the lonely world), mass 1.2a;
  T_j = T_j^drop u T_j^keep, T_k = T_k^drop u T_k^keep (classes j,k != lam), masses 0.9a + 0.1a;
  Z'     = C_p0 with A on all five cones          (a splice of C_p0 with C_q: rev d is anchored at q);
  d      = rec(C_p0, Z'):  b < 0 at all three worlds, A(d) contains p0 (interior), A(rev d) contains q,
           so d is NOT protected (A(rev d) nonempty) and the joint choice gives d exactly one world, lam;
  E_j    : a cone of class j where C_p0 and C_q are both silent, mass 0.05a;
  W      = C_p0 with A on T_j^keep, T_k^keep, E_j  (a pointwise strict world-lam improvement of C_p0).
Triangle at world lam: C_p0 <= Z' (d, the only defence of d), Z' <= W (rec(Z',W): its reverse has an
EMPTY anchor set, so the rule accepts it at every eligible world), W <= C_p0 (guidance), and Z' <= C_p0 is
refused at lam.  {C_p0, Z'} is the unique lowest-priority removable pair, so d is deleted at lam.
Hence d is accepted at no world of the final relation, although p0 in A(d) is interior: the defence clause fails."""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
from p9_D_search import scan, CFG
from p9_B1 import pair, triangle

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

E = [(F(1), F(0), F(0)), (F(0), F(1), F(0)), (F(0), F(0), F(1))]
CHOICE = {   # (direction, theta) from p9_D_search.out
    'e1_3': ((1, 0, -1), F(1, 200)),
    'e1_1': ((1, 0, -1), F(1, 200)),
    'u_3': ((1, 1, -2), F(1, 200)),
    'u_1': ((1, 1, -2), F(1, 200)),
}

def A_on(C, cones, name):
    return C.with_ov([(S, adv_from_label(interior(list(S)), 'A')) for S in cones], name=name)

def run(key):
    t0 = time.time()
    p0, eps = CFG[key]
    v, th = CHOICE[key]
    q = tuple(p0[k] + th*v[k] for k in range(3))
    pr('\n=== %s: eps = %s, p0 = %s, q = %s' % (key, eps, tuple(str(x) for x in p0), tuple(str(x) for x in q)))
    dom, both = scan(p0, eps, q)
    big = {w: max(dom[w], key=lambda c: mass_float(largest_triangle(c))) for w in range(3)}
    bm = {w: mass_float(largest_triangle(big[w])) for w in range(3)}
    lam = max(range(3), key=lambda w: bm[w])
    j, k = [w for w in range(3) if w != lam]
    a = 0.3*min(bm[lam]/1.2, bm[j], bm[k])
    T_l = cone_with_mass(big[lam], 1.2*a)
    def two(w):
        t1, t2 = split_cone(largest_triangle(big[w]))
        return cone_in_tri_with_mass(t1, 0.9*a), cone_in_tri_with_mass(t2, 0.1*a)
    Tj_d, Tj_k = two(j); Tk_d, Tk_k = two(k)
    C = Model(p0, eps, name='C')
    Zp = A_on(C, [T_l, Tj_d, Tj_k, Tk_d, Tk_k], "Z'")
    pr('   lonely world lam = %d; cone masses: T_lam %s, T_j drop/keep %s %s, T_k drop/keep %s %s' % (
        lam+1, ivs(mass_iv(list(T_l)), 4), ivs(mass_iv(list(Tj_d)), 4), ivs(mass_iv(list(Tj_k)), 4), ivs(mass_iv(list(Tk_d)), 4), ivs(mass_iv(list(Tk_k)), 4)))
    # choose E_j: a both-silent cell of class j (or k) making the W side of rec(Z',W) unanchored
    found = None
    for w in (j, k):
        for cell in sorted(both[w], key=lambda c: -mass_float(largest_triangle(c)))[:12]:
            Ej = cone_with_mass(cell, 0.05*a)
            W = A_on(C, [Tj_k, Tk_k, Ej], 'W')
            rWZ = rec(W, Zp)
            if rWZ['poly_empty']:
                found = (w, Ej, W); break
        if found: break
    if not found:
        pr('   no E cell found that unanchors the W side'); return False
    wE, Ej, W = found
    pr('   E: class %d, mass %s' % (wE+1, ivs(mass_iv(list(Ej)), 4)))
    pairs = {}
    pairs[('C', "Z'")] = pair(C, Zp, [p0], [q])
    pairs[("Z'", 'W')] = pair(Zp, W, [q], [p0])
    pairs[('W', 'C')] = pair(W, C, [E[lam], q], [p0])
    d = pairs[('C', "Z'")]
    pr('   d = rec(C,Z\'): b = %s, Phi4 = %s, c = %s' % (fmt(d['rd']['add']), fmt(d['rd']['phi4']), fmt(d['rd']['c'])))
    pr('      A(d): %s (witness p0 verified on exact cells), faces %s;  A(rev d): %s (witness q verified: %s), faces %s' % (
        d['Ad'], d['Fd'], d['Ab'], d['okb'] != [], d['Fb']))
    pr('      protected: %s (requires A(rev d) empty)' % (d['Ab'] is False))
    st = d['jc']['state']
    pr('      joint choice: %s unique %s -> d accepted at worlds %s; rev d at worlds %s' % (
        st, d['jc']['unique'], [i+1 for i in range(3) if st[i][0]], [i+1 for i in range(3) if st[i][1]]))
    alt = joint_choice(d['rd'], d['rb'], d['Ad'], [(0, 1, 2)], d['Ab'], [(0, 1, 2)])
    pr('      same choice with interior-only faces for rev d (robust to the conservative face set): %s' % (alt['state'] == st))
    ok = d['jc']['unique'] and alt['state'] == st and [i for i in range(3) if st[i][0]] == [lam]
    for (x, y) in [("Z'", 'W'), ('W', 'C')]:
        P = pairs[(x, y)]
        pr('   rec(%s,%s): b = %s, Phi4 = %s, guidance %s; A(.) %s faces %s; A(rev) %s faces %s; choice %s unique %s' % (
            x, y, fmt(P['rd']['add']), fmt(P['rd']['phi4']), [i+1 for i in range(3) if P['rd']['guid'][i]], P['Ad'], P['Fd'], P['Ab'], P['Fb'], P['jc']['state'], P['jc']['unique']))
        ok &= P['jc']['unique']
    viol = triangle(pairs, ['C', "Z'", 'W'], lam)
    pr('   => d deleted at world %d: %s.  d is accepted at no other world in R^0.  Final relation: d accepted NOWHERE,' % (lam+1, viol))
    pr('      while p0 in A(d) is interior: the defence clause FAILS: %s' % (viol and ok))
    pr('   time %.0fs' % (time.time() - t0))
    return viol and ok

if __name__ == '__main__':
    res = {key: run(key) for key in (sys.argv[1:] or list(CFG))}
    pr('\nSUMMARY:', res)
    open(os.path.join(HERE, 'p9_D_%s.out' % '_'.join(sys.argv[1:] or ['all'])), 'w').write('\n'.join(out) + '\n')
