"""PP9 tie-break scan (NUMERICS): hypothesis (H_T) of Proposition T.

(H_T): there are interior p != q with L_i(C_q) = L_i(C_p) (an exact additive tie at world i of the doubly anchored
record rec(C_p, C_q)) and L_j(C_q) - L_j(C_p), L_k(C_q) - L_k(C_p) nonzero of opposite signs.
For each setting and world i: on the circle |q - p0| = r (in the simplex plane) locate the two tie points by
bisection (PP6's closed-form L, double precision) and report the other two differences."""
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
from p9_B1 import CFG

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

e = (1/math.sqrt(2), -1/math.sqrt(2), 0.0); f = (1/math.sqrt(6), 1/math.sqrt(6), -2/math.sqrt(6))
for key, (p0, eps) in CFG.items():
    P0 = [float(x) for x in p0]; L0 = L_float(p0, eps)
    r = 0.25*min(P0)
    def q_at(th): return tuple(P0[k] + r*(math.cos(th)*e[k] + math.sin(th)*f[k]) for k in range(3))
    def D(th): return [a - b for a, b in zip(L_float(tuple(F(x) for x in q_at(th)), eps), L0)]
    N = 72
    vals = [D(2*math.pi*k/N) for k in range(N+1)]
    for i in range(3):
        ties = []
        for k in range(N):
            if vals[k][i]*vals[k+1][i] < 0:
                lo, hi = 2*math.pi*k/N, 2*math.pi*(k+1)/N
                for _ in range(50):
                    mid = (lo+hi)/2
                    if D(lo)[i]*D(mid)[i] <= 0: hi = mid
                    else: lo = mid
                d = D(lo); ties.append(d)
        pr('%s world %d: %d tie points on the circle r = %.4f; other differences at them: %s' % (
            key, i+1, len(ties), r, ['(%+.2e, %+.2e)' % tuple(d[j] for j in range(3) if j != i) for d in ties]))
open(os.path.join(HERE, 'p9_tie.out'), 'w').write('\n'.join(out) + '\n')
