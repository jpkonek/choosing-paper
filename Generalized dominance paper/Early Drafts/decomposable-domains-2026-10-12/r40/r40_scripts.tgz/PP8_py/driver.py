"""PP8 driver: run the joint-defence candidate on one pool and report items 1, 3, 4 (item 2 is t2_sections.py)."""
import sys, os, itertools, time
sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from jd import *

def nm(P, u): return P.names[u]

def recname(P, r):
    ctx_ = P.contexts(r)
    u, v = ctx_[0]
    return 'rec(%s,%s)' % (nm(P, u), nm(P, v)) + ('' if len(ctx_) == 1 else ' [+%d contexts]' % (len(ctx_)-1))

def run_pool(models, eps, label, pr, cap=400, closure=True, lp=True, detail=True):
    t0 = time.time()
    pr('\n' + '='*100 + '\n=== %s' % label)
    P = Pool(models, eps, log=pr)
    if closure:
        P.closed = P.close(cap=cap)
    else:
        P.closed = None
    P.build_records(); P.joint(); P.priorities(); P.delete()
    N = P.N
    sel = [k for k in range(N) if P.selp[k] is not None]
    pr('models: %d (%d selected); records %d; obj-4 tie-break used %d times; uncertified obj-3 comparisons %d; uncertified Phi signs %d'
       % (N, len(sel), P.R, P.flags['obj4_used'], P.flags['obj3_neartie'], P.flags['phi_unc']))
    tc0 = P.tc_check(P.acc0); tc1 = P.tc_check(P.acc)
    pr('(TC) violations, initial R^0 per world: %s; after the deletion: %s' % (tc0, tc1))
    ob0 = P.obligations(P.acc0); ob1 = P.obligations(P.acc)
    pr('face obligations unmet: initial %d, final %d' % (len(ob0), len(ob1)))
    # describe marked pairs
    for i in range(3):
        for pid in sorted(P.marked[i]):
            e = P.rev[pid]
            anch = [x for x in (pid, e) if P.faces[x]]
            wit = P.witness[i].get(pid, [])
            pr('   world %d marks %s / reverse: priority (s=%d, m=%.4g); accepted at %d: fwd %s rev %s; anchored directions: %s; marking triangles in pool >= %d'
               % (i+1, recname(P, pid), P.s[pid, i], P.prio[pid, i] - 10*P.s[pid, i], i+1, P.acc0[pid, i], P.acc0[e, i],
                  [(recname(P, x), P.faces[x]) for x in anch], len(wit)))
    # item 1: anchored records losing defenders
    lost_some = []
    for r in range(P.R):
        if not P.faces[r]: continue
        lostw = [i for i in range(3) if P.acc0[r, i] and not P.acc[r, i]]
        if lostw: lost_some.append((r, lostw))
    pr('ITEM 1. anchored records that lose at least one initial defender: %d; that lose EVERY defender required by a face obligation: %d'
       % (len(lost_some), len(ob1)))
    for r, lw in lost_some[:20]:
        pr('   %s faces %s: initial worlds %s, lost %s, final %s' % (recname(P, r), P.faces[r],
           [i+1 for i in range(3) if P.acc0[r, i]], [i+1 for i in lw], [i+1 for i in range(3) if P.acc[r, i]]))
    res = dict(P=P, tc0=tc0, tc1=tc1, ob1=ob1, lost_some=lost_some)
    for (r, I) in ob1:
        pr('   FAILURE: %s, face %s: initial defenders %s, all deleted.' % (recname(P, r), tuple(x+1 for x in I),
           [i+1 for i in I if P.acc0[r, i]]))
        pid = min(r, P.rev[r])
        for i in I:
            if not P.acc0[r, i]: continue
            for (x, y, z) in P.witness[i].get(pid, []):
                pr('      world %d triangle: %s <= %s <= %s <= %s, refused %s <= %s; priorities {%s,%s}=%s {%s,%s}=%s {%s,%s}=%s'
                   % (i+1, nm(P, x), nm(P, y), nm(P, z), nm(P, x), nm(P, x), nm(P, z),
                      nm(P, x), nm(P, y), P.prio[P.recmat[x, y], i], nm(P, y), nm(P, z), P.prio[P.recmat[y, z], i],
                      nm(P, z), nm(P, x), P.prio[P.recmat[z, x], i]))
    # item 3
    dom, ties = P.selected_checks(P.acc)
    dom0, ties0 = P.selected_checks(P.acc0)
    pr('ITEM 3. dominated selected models: initial %d, final %d; all-world ties with selected models: initial %d, final %d'
       % (len(dom0), len(dom), len(ties0), len(ties)))
    for x, s in dom[:10]: pr('   DOMINATED (final): %s by %s' % (nm(P, s), nm(P, x)))
    for x, s, cert in ties[:10]:
        pr('   tie (final): %s ~ %s at every world; incoherence certificate of %s: %s' % (nm(P, x), nm(P, s), nm(P, x), cert[0] if cert else None))
    res['dom'] = dom; res['ties'] = ties
    bad_C = [(x, s) for x, s, c in ties if c is not None]
    pr('   direct (C) violations (all-world tie of a selected model with a certified-incoherent model): %d' % len(bad_C))
    # strict defences out of selected models vs non-guidance rivals
    nstrict = 0; nties = 0
    for s in sel:
        for x in range(N):
            if x == s: continue
            d = P.recmat[s, x]
            for i in range(3):
                if P.acc[d, i] and not P.G[d, i]:
                    if P.acc[P.rev[d], i]: nties += 1
                    else: nstrict += 1
    pr('   non-guidance defences out of selected models in R: %d strict, %d ties' % (nstrict, nties))
    # item 4
    if lp:
        for i in range(3):
            recs = sorted(set(int(P.recmat[s, x]) for s in sel for x in range(N) if x != s
                              and P.acc[P.recmat[s, x], i] and not P.G[P.recmat[s, x], i]))
            ok, cert = P.endorse_lp(P.acc, i, recs)
            if ok:
                pr('ITEM 4. world %d: %d surviving non-guidance defences out of selected models; a strictly positive field ENDORSES all of them on the pool (max-min relative margin %.3g; exact rational re-check of the field: %s)'
                   % (i+1, len(recs), cert[1] if cert else 0, cert[2] if cert else None))
            else:
                pr('ITEM 4. world %d: %d surviving non-guidance defences out of selected models; NO strictly positive field endorses them: %s'
                   % (i+1, len(recs), cert[0]))
                if cert[0] == 'farkas':
                    pr('      exact Farkas certificate verified: %s; combination: %s' % (cert[1], [(recname(P, r), str(l)) for r, l in cert[2]]))
            res.setdefault('lp', []).append((ok, len(recs), cert))
    pr('time %.0fs' % (time.time()-t0))
    return res
