"""PP8 t5: the FULL collection, in each closed pool, of violating triangles that mark a record whose face obligation
then fails; grouped by the three record pairs they realise (records identified by exact equality).
Usage: python3 -I -B t5_triangles.py <setting> ..."""
import sys, os
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from driver import *
from configs import *

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def all_marking(P, pid, i):
    """every ordered violating triangle (x,y,z) at world i in which pair pid has lowest removable priority."""
    M = P.relation(P.acc0, i); res = []
    for (u, v) in P.contexts(pid) + P.contexts(P.rev[pid]):
        for w in range(P.N):
            if w in (u, v): continue
            for (x, y, z) in ((u, v, w), (v, w, u), (w, u, v), (v, u, w), (u, w, v), (w, v, u)):
                if not (M[x, y] and M[y, z] and M[z, x] and not M[x, z]): continue
                pr_ = [P.prio[P.recmat[x, y], i], P.prio[P.recmat[y, z], i], P.prio[P.recmat[z, x], i]]
                pids = [P.pairid[x, y], P.pairid[y, z], P.pairid[z, x]]
                mn = min(pr_)
                if any(pp == mn and q == pid for pp, q in zip(pr_, pids)): res.append((x, y, z))
    return sorted(set(res))

def describe(P, x, y, z, i):
    def link(u, v):
        r = P.recmat[u, v]
        kind = 'guidance' if P.G[r, i] else ('additively safe' if P.b[r, i] >= 0 else 'additively unsafe')
        return '%s <=_%d %s [%s; record anchored: %s; priority of the pair %s]' % (
            P.names[u], i+1, P.names[v], kind, bool(P.Anon[r]),
            'unremovable' if not np.isfinite(P.prio[r, i]) else '(s=%d, m=%.6f)' % (P.s[r, i], P.prio[r, i] - 10*P.s[r, i]))
    rz = P.recmat[x, z]
    why = 'guidance reverse' if P.G[P.rev[rz], i] else ('not chosen by the joint choice' if (P.Anon[rz] and P.phi[rz, i] >= 0) else 'ineligible')
    return '%s; %s; %s; and %s <=_%d %s is refused (%s)' % (link(x, y), link(y, z), link(z, x), P.names[x], i+1, P.names[z], why)

def run(models, eps, label):
    pr('\n=== %s' % label)
    P = Pool(models, eps, log=lambda *a: None)
    P.close(cap=400); P.build_records(); P.joint(); P.priorities(); P.delete()
    for r, I in P.obligations(P.acc):
        pr('FAILED OBLIGATION: %s, face %s; initial defenders %s' % (recname(P, r), tuple(t+1 for t in I), [i+1 for i in I if P.acc0[r, i]]))
        pid = int(min(r, P.rev[r]))
        for i in I:
            if not P.acc0[r, i]: continue
            tri = all_marking(P, pid, i)
            groups = {}
            for (x, y, z) in tri:
                key = tuple(sorted({int(P.pairid[x, y]), int(P.pairid[y, z]), int(P.pairid[z, x])}))
                groups.setdefault(key, []).append((x, y, z))
            pr('   world %d: %d ordered marking triangles in the pool, realising %d distinct triples of record pairs' % (i+1, len(tri), len(groups)))
            for key, lst in groups.items():
                x, y, z = lst[0]
                pr('     record-pair triple %s, realised by %d ordered triangles (contexts: %s)' % (
                    key, len(lst), sorted(set(tuple(sorted((P.names[a], P.names[b], P.names[c]))) for a, b, c in lst))[:6]))
                pr('        e.g. ' + describe(P, x, y, z, i))

if __name__ == '__main__':
    for key in (sys.argv[1:] or list(SETTINGS)):
        p0, eps = SETTINGS[key]
        a = PP5_A if key == 'e1_3' else p0
        for w in range(3):
            ms, q = cfg_pp5_pump(a, eps, world=w)
            run(ms, eps, '%s pump, lead world %d' % (key, w+1))
        run(cfg_t1(p0, eps) + cfg_pp5_pump(p0, eps)[0][1:], eps, '%s mixed pool (PP7 t1 + PP5 pump on C_p0)' % key)
    open(os.path.join(HERE, 't5_triangles_%s.out' % '_'.join(sys.argv[1:] or ['all'])), 'w').write('\n'.join(out) + '\n')
