"""PP8 t3: exact certificate that the joint-defence candidate deletes the ONLY defence of C_a against PP5's
pump rival Y (kappa = 4 version), in all four settings (CHECKED).

Independent of the global-arrangement library jd.py: each record is computed on its own local cell arrangement
(pp7core.record_cells, PP7's routine) with mpmath interval solid angles (pp7core.record(use_iv=True)); anchors by
pp7core.anchor_set; the 64-state joint choice and the priorities are re-implemented here with interval
arithmetic, and every comparison used is required to be certified (disjoint intervals).

The triangle is (C_a, Y, Z) at the defending world j:
   C_a <=_j Y   (the unique initial defence; priority (0, m1) with m1 = Phi_j/(P_j+Q_j) < 3/2)
   Y   <=_j Z   (anchored return, additively safe; priority (0, m2) with m2 > 3/2)
   Z   <_j C_a  (Z is a pointwise strict world-j improvement of C_a: compulsory guidance, unremovable)."""
import sys, os, itertools
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from pp7core import *
from configs import *
import mpmath
from mpmath import iv
iv.dps = 40

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def lo(x): return lohi(x)[0]
def hi(x): return lohi(x)[1]
def certified_lt(x, y): return hi(x) < lo(y)

class Rec:
    def __init__(self, X, Y):
        cells, _ = record_cells(X, Y)
        r = record(X, Y, use_iv=True, cells=cells)
        self.P, self.Q = r['P'], r['Q']
        self.changed = r['changed']
        self.guid = [len(r['changed']) > 0 and all(rank(ay, interior(c), j) >= rank(ax, interior(c), j) for c, ax, ay in r['changed'])
                     for j in range(3)]
        self.polys = anchor_set(r['changed'], X.eps)
        self.faces = faces_met(self.polys)
        self.Anon = (0, 1, 2) in self.faces
        self.phi = [4*self.P[i] - self.Q[i] for i in range(3)]
        self.b = [self.P[i] - self.Q[i] for i in range(3)]
        self.c = [self.Q[i]/(self.P[i] + self.Q[i]) for i in range(3)]
        self.m = [self.phi[i]/(self.P[i] + self.Q[i]) for i in range(3)]
    def anchor_pts(self):
        pts = []
        for k in self.polys:
            for v in self.polys[k]: pts.append(tuple(str(t) for t in (v[0], v[1], 1 - v[0] - v[1])))
        return pts

STATES = [(1, 0), (0, 1), (1, 1), (0, 0)]
NAMES = ['forward only', 'reverse only', 'both', 'neither']

def joint(d, e):
    """returns (state tuple, certified?) of the 64-state choice for the pair (d forward, e reverse)."""
    allow = {}
    for tag, x, y in (('d', d, e), ('e', e, d)):
        for i in range(3):
            if x.guid[i]: allow[(tag, i)] = 'G'
            elif y.guid[i]: allow[(tag, i)] = None
            elif x.Anon and lo(x.phi[i]) >= 0: allow[(tag, i)] = 'E'
            elif x.Anon and hi(x.phi[i]) >= 0: raise RuntimeError('uncertified eligibility')
            else: allow[(tag, i)] = None
    cands = []
    for st in itertools.product(range(4), repeat=3):
        fd = [STATES[s][0] for s in st]; fe = [STATES[s][1] for s in st]
        ok = all(not (allow[('d', i)] == 'G' and not fd[i]) and not (allow[('d', i)] is None and fd[i]) and
                 not (allow[('e', i)] == 'G' and not fe[i]) and not (allow[('e', i)] is None and fe[i]) for i in range(3))
        ok = ok and all(any(fd[i] for i in I) for I in d.faces) and all(any(fe[i] for i in I) for I in e.faces)
        if not ok: continue
        nboth = sum(fd[i] and fe[i] for i in range(3))
        cs = iv.mpf(0); nng = 0
        for i in range(3):
            if fd[i] and allow[('d', i)] == 'E': cs += d.c[i]; nng += 1
            if fe[i] and allow[('e', i)] == 'E': cs += e.c[i]; nng += 1
        cands.append(((nboth, -nng), cs, st, fd, fe))
    b12 = min(c[0] for c in cands)
    c12 = [c for c in cands if c[0] == b12]
    best = min(c12, key=lambda c: mpmath.mpf(lo(c[1])))
    cert = all(c is best or certified_lt(best[1], c[1]) for c in c12)
    return best, cert, len(cands), allow

def run(key, world, tcell=0):
    a = PP5_A if key == 'e1_3' else SETTINGS[key][0]
    eps = SETTINGS[key][1]
    ms, q = cfg_pp5_pump(a, eps, world=world, tcell=tcell)
    if ms is None: pr('no further T cell'); return None
    Ca, Cq, Y, Z = ms
    pr('\n=== %s, lead world %d, T cell #%d: a = %s, eps = %s, anchor of the reverse q = %s' % (key, world+1, tcell, tuple(map(str, a)), eps, tuple(map(str, q))))
    d, db = Rec(Ca, Y), Rec(Y, Ca)
    r, rb = Rec(Y, Z), Rec(Z, Y)
    g, gb = Rec(Z, Ca), Rec(Ca, Z)
    pr('masses (interval, 40 digits): rec(C_a,Y): nu(P) =', [ivs(x, 6) for x in d.P], ' nu(Q) =', [ivs(x, 6) for x in d.Q])
    pr('   b = add =', [ivs(x, 6) for x in d.b], '-> every additive balance < 0 certified:', all(hi(x) < 0 for x in d.b))
    pr('   Phi^4 =', [ivs(x, 6) for x in d.phi])
    pr('   faces of A(rec(C_a,Y)):', d.faces, '; A(rec(Y,C_a)) nonempty:', db.Anon, 'faces', db.faces, 'vertices (q coordinates):', db.anchor_pts()[:6])
    pr('   q itself in A(rec(Y,C_a)): C_q agrees with Y on every changed cell:',
       all(sel_advice(q, interior(c), eps) == ay for c, ax, ay in d.changed))
    best, cert, nf, allow = joint(d, db)
    pr('joint choice for {rec(C_a,Y), rec(Y,C_a)}: %d feasible states of 64; eligibility (G/E/-): fwd %s rev %s' % (
        nf, [allow[('d', i)] or '-' for i in range(3)], [allow[('e', i)] or '-' for i in range(3)]))
    pr('   chosen state:', [NAMES[s] for s in best[2]], '; objective-3 value', ivs(best[1], 8), '; unique optimum certified:', cert)
    W = [i for i in range(3) if best[3][i]]
    pr('   => C_a <=_i Y accepted initially exactly at worlds', [i+1 for i in W])
    assert len(W) == 1
    j = W[0]
    bestr, certr, nfr, allowr = joint(r, rb)
    pr('joint choice for {rec(Y,Z), rec(Z,Y)}: chosen', [NAMES[s] for s in bestr[2]], 'certified:', certr,
       '; A(rec(Y,Z)) faces', r.faces, '; b(rec(Y,Z)) =', [ivs(x, 6) for x in r.b])
    bestg, certg, nfg, allowg = joint(g, gb)
    pr('joint choice for {rec(Z,C_a), rec(C_a,Z)}: chosen', [NAMES[s] for s in bestg[2]], 'certified:', certg,
       '; rec(Z,C_a) guidance at worlds', [i+1 for i in range(3) if g.guid[i]])
    # the triangle at world j
    acc = {('Ca', 'Y'): best[3][j], ('Y', 'Ca'): best[4][j], ('Y', 'Z'): bestr[3][j], ('Z', 'Y'): bestr[4][j],
           ('Z', 'Ca'): bestg[3][j], ('Ca', 'Z'): bestg[4][j]}
    viol = acc[('Ca', 'Y')] and acc[('Y', 'Z')] and acc[('Z', 'Ca')] and not acc[('Ca', 'Z')]
    pr('world %d: C_a <= Y: %s, Y <= Z: %s, Z <= C_a: %s, C_a <= Z: %s  -> (TC) violation of R^0: %s' % (
        j+1, acc[('Ca', 'Y')], acc[('Y', 'Z')], acc[('Z', 'Ca')], acc[('Ca', 'Z')], viol))
    # priorities
    def prio(x, xb, ax, axb):
        if x.guid[j] or xb.guid[j]: return None, None
        s = 0; m = None
        for (e_, eb, a_) in ((x, xb, ax), (xb, x, axb)):
            if not a_: continue
            if e_.Anon and not eb.Anon and all(hi(t) < 0 for t in e_.b): s = 1
            m = e_.m[j] if m is None or hi(e_.m[j]) < lo(m) else m
        return s, m
    s1, m1 = prio(d, db, acc[('Ca', 'Y')], acc[('Y', 'Ca')])
    s2, m2 = prio(r, rb, acc[('Y', 'Z')], acc[('Z', 'Y')])
    s3, m3 = prio(g, gb, acc[('Z', 'Ca')], acc[('Ca', 'Z')])
    pr('priorities at world %d: {C_a,Y} = (s=%s, m=%s); {Y,Z} = (s=%s, m=%s); {Z,C_a} = %s' % (
        j+1, s1, ivs(m1, 8), s2, ivs(m2, 8), 'not removable (guidance)' if s3 is None else (s3, ivs(m3, 8))))
    lowest = (s3 is None) and (s1 < s2 or (s1 == s2 and certified_lt(m1, m2)))
    pr('   {C_a,Y} is the unique lowest removable pair (certified): %s' % lowest)
    fails = bool(viol and lowest and cert and certr and certg)
    pr('CERTIFIED: {rec(C_a,Y), rec(Y,C_a)} is marked at world %d and deleted there in every context; C_a <=_i Y then holds at NO world,'
       ' although a is an interior point of A(rec(C_a,Y)) (full-face obligation): %s' % (j+1, fails))
    return fails

if __name__ == '__main__':
    res = {}
    for key in (sys.argv[1:] or list(SETTINGS)):
        for w in range(3):
            for tc in range(4):
                r_ = run(key, w, tc)
                res[(key, w+1, tc)] = r_
                if r_ is None or r_: break
    pr('\nSUMMARY (setting, lead world, T cell): certified failure')
    for k, v in res.items(): pr('   ', k, v)
    open(os.path.join(HERE, 't3_pump_certificate.out'), 'w').write('\n'.join(out) + '\n')
