"""PP8 t6: R^0 alone has non-closed sections (CHECKED at every listed point).
R^0 is record-local, so no pool is needed: for p = a + t v, t = +-10^-k, the verdict of the joint choice on
{rec(C_p, Ypump), rec(Ypump, C_p)} is computed with the independent implementation of t3_pump_certificate.py
(local cells, 40-digit interval masses, exact anchor polygons, interval objectives)."""
import sys, os
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import t3_pump_certificate as T
from configs import *

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def run(key, v, ks):
    a = PP5_A if key == 'e1_3' else SETTINGS[key][0]
    eps = SETTINGS[key][1]
    ms, q = cfg_pp5_pump(a, eps)
    Ca, Cq, Y, Z = ms
    pr('\n=== %s, pump rival Ypump (lead world 1), path p = a + t v, v = %s' % (key, v))
    ts = [F(0)] + [sg*F(1, 10**k) for k in ks for sg in (1, -1)]
    for t in sorted(ts, key=lambda x: (abs(x), x)):
        p = tuple(a[k] + t*v[k] for k in range(3))
        Cp = Model(p, eps)
        d, db = T.Rec(Cp, Y), T.Rec(Y, Cp)
        best, cert, nf, allow = T.joint(d, db)
        W = [i+1 for i in range(3) if best[3][i]]; Wr = [i+1 for i in range(3) if best[4][i]]
        bneg = all(T.hi(x) < 0 for x in d.b)
        pr('   t = %-14s all b<0 (certified): %-5s  A(rev) nonempty: %-5s  R^0 accepts C_p <= Y at %s, Y <= C_p at %s  (unique optimum certified: %s)'
           % (('%.0e' % float(t)) if t else '0', bneg, db.Anon, W, Wr, cert))

if __name__ == '__main__':
    keys = sys.argv[1:] or list(SETTINGS)
    for key in keys:
        for v in ((1, -1, 0), (0, 1, -1)):
            run(key, v, range(6, 13, 2))
    open(os.path.join(HERE, 't6_r0_sequence.out'), 'w').write('\n'.join(out) + '\n')
