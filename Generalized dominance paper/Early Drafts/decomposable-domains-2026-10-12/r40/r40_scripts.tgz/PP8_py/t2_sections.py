"""PP8 t2: sections {p : C_p R_i X} along paths of selected models, rival X held fixed (item 2), and covering
(some world in supp p accepts rec(C_p, X)).

R^0 is record-local, so the R^0 sections are exact at every path point (CHECKED signs).  The deletion is
computed on the finite pool (path models + the configuration's other models): a deleted point is valid (more
triples can only delete more), a surviving point is not proof.
Paths:
  pump: X = PP5 pump rival Y (anchored reverse at p = a only); p = a + t v through a;
  Y:    X = PP7's sticky rival Y (reverse never anchored); p = p0 + t e through p0, across the boundary of N(Y),
        pool also containing PP7 t1's pump partners Xc, Xu, Z_j, YZ_j."""
import sys, os
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from jd import *
from configs import *

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def section_table(P, path_idx, ts, X, label):
    pr('   %s: rival %s; per path point: t, all b<0?, A(reverse) nonempty?, R^0 worlds, R worlds, s per world, covered?' % (label, P.names[X]))
    rows = []
    for t, u in zip(ts, path_idx):
        d = P.recmat[u, X]; e = P.rev[d]
        bneg = bool((P.b[d] < 0).all()); bcert = bool((np.abs(P.b[d]) > P.be[d]).all())
        w0 = ''.join(str(i+1) if P.acc0[d, i] else '.' for i in range(3))
        w1 = ''.join(str(i+1) if P.acc[d, i] else '.' for i in range(3))
        ss = ''.join(str(P.s[d, i]) if P.acc0[d, i] or P.acc0[e, i] else '-' for i in range(3))
        rows.append((t, bneg, bool(P.Anon[e]), w0, w1, ss, w1 != '...'))
        pr('      t = %-12s b<0: %-5s (cert %s)  A(rev)!={}: %-5s  R0: %s  R: %s  s: %s  covered: %s' % (
            ('%.3e' % t), bneg, bcert, bool(P.Anon[e]), w0, w1, ss, w1 != '...'))
    # sections and closedness diagnostics
    for i in range(3):
        S0 = [r[3][i] != '.' for r in rows]; S1 = [r[4][i] != '.' for r in rows]
        iso0 = [rows[k][0] for k in range(1, len(rows)-1) if not S0[k] and S0[k-1] and S0[k+1]]
        iso1 = [rows[k][0] for k in range(1, len(rows)-1) if not S1[k] and S1[k-1] and S1[k+1]]
        pr('      world %d section, R^0: %s   R: %s   isolated refused points (accepted on both sides) R^0: %s R: %s' % (
            i+1, ''.join('#' if x else '.' for x in S0), ''.join('#' if x else '.' for x in S1), iso0, iso1))
    return rows

def pump_path(key, v, ts, extra_rivals=True):
    a = PP5_A if key == 'e1_3' else SETTINGS[key][0]
    eps = SETTINGS[key][1]
    ms, q = cfg_pp5_pump(a, eps)
    Ca, Cq, Y, Z = ms
    path = []
    for t in ts:
        p = tuple(a[k] + t*v[k] for k in range(3))
        path.append(Model(p, eps, name='P(%s)' % t))
    pool_models = path + [Cq, Y, Z]
    P = Pool(pool_models, eps, log=pr)
    P.closed = None
    P.build_records(); P.joint(); P.priorities(); P.delete()
    pr('   TC after deletion: %s; obligations unmet after deletion: %d' % (P.tc_check(P.acc), len(P.obligations(P.acc))))
    idx = list(range(len(path)))
    Xi = P.names.index('Ypump')
    return section_table(P, idx, [float(t) for t in ts], Xi, 'pump path through a along v = %s' % (v,))

def y_path(key, ts):
    p0, eps = SETTINGS[key]
    t1 = cfg_t1(p0, eps)
    Y = t1[1]
    e = (1, -1, 0)
    path = [Model(tuple(p0[k] + t*e[k] for k in range(3)), eps, name='P(%s)' % t) for t in ts]
    P = Pool(path + t1[1:], eps, log=pr)
    P.closed = None
    P.build_records(); P.joint(); P.priorities(); P.delete()
    pr('   TC after deletion: %s; obligations unmet after deletion: %d' % (P.tc_check(P.acc), len(P.obligations(P.acc))))
    idx = list(range(len(path)))
    rows = section_table(P, idx, [float(t) for t in ts], P.names.index('Y'), 'PP7 Y path through p0 along e = (1,-1,0)')
    for name in ('YZ1', 'YZ2', 'YZ3', 'Xc'):
        section_table(P, idx, [float(t) for t in ts], P.names.index(name), 'same path, rival %s' % name)
    return rows


def s_boundary(key, v, t_in, t_out, steps=30):
    """bisection on the path p = a + t v for the boundary t* of N(Ypump) (where max_j b_j(rec(C_p, Ypump)) = 0),
    then the pool {C_a, C_p(t), C_q, Ypump, Zpump} at rational t just inside and just outside: is rec(C_p,Ypump)
    deleted at the defending worlds, and by which triangle?"""
    a = PP5_A if key == 'e1_3' else SETTINGS[key][0]
    eps = SETTINGS[key][1]
    ms, q = cfg_pp5_pump(a, eps)
    Ca, Cq, Y, Z = ms
    def pt(t): return Model(tuple(a[k] + t*v[k] for k in range(3)), eps, name='P(%s)' % t)
    def inside(t): return all(x < 0 for x in record(pt(t), Y)['add'])
    assert inside(t_in) and not inside(t_out)
    for _ in range(steps):
        mid = (t_in + t_out)/2
        if inside(mid): t_in = mid
        else: t_out = mid
    pr('   boundary of N(Ypump) along v = %s: t* in [%.12e, %.12e]' % (v, float(t_in), float(t_out)))
    for t in (t_in, t_out):
        Pp = Pool([pt(t), Ca, Cq, Y, Z], eps, log=lambda *x: None)
        Pp.build_records(); Pp.joint(); Pp.priorities(); Pp.delete()
        d = Pp.recmat[0, Pp.names.index('Ypump')]; pid = min(d, Pp.rev[d])
        pr('      t = %.12e: b = %s (|b| > error: %s); R^0 worlds %s; R worlds %s; priorities %s' % (
            float(t), ['%.3e' % x for x in Pp.b[d]], bool((np.abs(Pp.b[d]) > Pp.be[d]).all()),
            [i+1 for i in range(3) if Pp.acc0[d, i]], [i+1 for i in range(3) if Pp.acc[d, i]],
            ['(s=%d, m=%.6f)' % (Pp.s[d, i], Pp.prio[d, i] - 10*Pp.s[d, i]) for i in range(3) if Pp.acc0[d, i]]))
        for i in range(3):
            for (x, y, z) in Pp.witness[i].get(int(pid), [])[:1]:
                pr('         world %d deleting triangle: %s <= %s <= %s <= %s; pair priorities %.6f, %.6f, %.6f' % (
                    i+1, Pp.names[x], Pp.names[y], Pp.names[z], Pp.names[x], Pp.prio[Pp.recmat[x, y], i], Pp.prio[Pp.recmat[y, z], i], Pp.prio[Pp.recmat[z, x], i]))

if __name__ == '__main__':
    keys = sys.argv[1:] or list(SETTINGS)
    for key in keys:
        pr('\n' + '='*100 + '\n=== %s' % key)
        base = [F(0), F(1, 10**6), F(-1, 10**6), F(1, 10**5), F(-1, 10**5), F(3, 10**5), F(-3, 10**5), F(1, 10**4), F(-1, 10**4),
                F(3, 10**4), F(-3, 10**4), F(1, 10**3), F(-1, 10**3)]
        ts = sorted(base)
        for v in ((1, -1, 0), (0, 1, -1)):
            rows = pump_path(key, v, ts)
            # refine at both ends of N(Ypump) along the path
            ins = [F(r[0]).limit_denominator(10**7) for r in rows if r[1]]
            for sgn in (1, -1):
                tin = max(ins) if sgn > 0 else min(ins)
                touts = [F(r[0]).limit_denominator(10**7) for r in rows if not r[1] and sgn*r[0] > sgn*float(tin)]
                if touts:
                    tout = min(touts) if sgn > 0 else max(touts)
                    s_boundary(key, v, tin, tout)
        p0, eps = SETTINGS[key]
        Y, m, add = build_Y(p0, eps)
        pts, h = lattice(p0, eps, add, 3)
        ts2 = sorted(set([k*h for k in range(-24, 25, 3)] + [F(0)]))
        y_path(key, ts2)
    open(os.path.join(HERE, 't2_sections_%s.out' % '_'.join(keys)), 'w').write('\n'.join(out) + '\n')
