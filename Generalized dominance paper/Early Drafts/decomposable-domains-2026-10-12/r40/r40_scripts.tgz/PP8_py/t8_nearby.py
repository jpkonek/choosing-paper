"""PP8 t8: NOT the candidate.  The nearby rule V2+V3 (NUMERICS on pools and paths):
   V3: deletion priority (crit, s, m), crit = 1 if world i is the only initial world covering some face obligation of
       an accepted direction of the pair;
   V2: R^0 closed at anchored-reverse points: an additively dominated direction (A(d) != {}, all b_j(d) < 0) is also
       accepted at every world with Phi_i(d) >= 0 (ties with the reverse allowed there).
Reports obligations / dominance / ties on the PP5 and PP7 pools, and the sections along the pump paths.
Usage: python3 -I -B t8_nearby.py <setting> ..."""
import sys, os
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from driver import *
from configs import *

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def pool_run(models, eps, label, jv, pv, closure=True):
    P = Pool(models, eps, log=lambda *a: None)
    if closure: P.close(cap=400)
    P.build_records(); P.joint(variant=jv); P.priorities(variant=pv); P.delete()
    return P

def summary(P, label, jv, pv):
    ob = P.obligations(P.acc); dom, ties = P.selected_checks(P.acc)
    pr('   %-24s joint=%s prio=%s: models %d, TC final %s, failed obligations %d, dominated %d, all-world ties %d (certified incoherent %d)'
       % (label, jv, pv, P.N, P.tc_check(P.acc), len(ob), len(dom), len(ties), sum(1 for x, s, c in ties if c is not None)))
    for r, I in ob[:3]: pr('      failed: %s face %s' % (recname(P, r), I))

if __name__ == '__main__':
    for key in (sys.argv[1:] or list(SETTINGS)):
        p0, eps = SETTINGS[key]
        a = PP5_A if key == 'e1_3' else p0
        pr('\n=== %s' % key)
        cfgs = [('pump lead 1', cfg_pp5_pump(a, eps, world=0)[0]), ('pump lead 2', cfg_pp5_pump(a, eps, world=1)[0]),
                ('pump lead 3', cfg_pp5_pump(a, eps, world=2)[0]),
                ('mix (t1 + pump)', cfg_t1(p0, eps) + cfg_pp5_pump(p0, eps)[0][1:]),
                ('PP7 t8', cfg_t8(p0, eps)), ('PP7 t1', cfg_t1(p0, eps)), ('PP7 t3 core', cfg_t3core(p0, eps, key)[0]),
                ('PP7 t6 core', cfg_t6core(p0, eps, key))]
        for lab, ms in cfgs:
            P = pool_run(ms, eps, lab, 'V2', 'V3'); summary(P, lab, 'V2', 'V3')
        # sections along the pump paths
        ms, q = cfg_pp5_pump(a, eps); Ca, Cq, Y, Z = ms
        ts = sorted([F(0)] + [sg*F(1, 10**k) for k in (3, 4, 5, 6, 8) for sg in (1, -1)])
        for v in ((1, -1, 0), (0, 1, -1)):
            path = [Model(tuple(a[k] + t*v[k] for k in range(3)), eps, name='P(%s)' % t) for t in ts]
            for jv, pv in ((None, 'V3'), ('V2', 'V3')):
                P = pool_run(path + [Cq, Y, Z], eps, 'path', jv, pv, closure=False)
                Xi = P.names.index('Ypump')
                secs0 = [''.join('#' if P.acc0[P.recmat[u, Xi], i] else '.' for u in range(len(path))) for i in range(3)]
                secs = [''.join('#' if P.acc[P.recmat[u, Xi], i] else '.' for u in range(len(path))) for i in range(3)]
                ob = P.obligations(P.acc)
                pr('   path v=%s joint=%s prio=%s: t = %s' % (v, jv, pv, [('%.0e' % float(t)) if t else '0' for t in ts]))
                pr('      R^0 sections w1 %s w2 %s w3 %s | R sections w1 %s w2 %s w3 %s | failed obligations in the path pool %d'
                   % (secs0[0], secs0[1], secs0[2], secs[0], secs[1], secs[2], len(ob)))
                for r, I in ob[:3]: pr('      failed: %s face %s' % (recname(P, r), I))
    open(os.path.join(HERE, 't8_nearby_%s.out' % '_'.join(sys.argv[1:] or ['all'])), 'w').write('\n'.join(out) + '\n')
