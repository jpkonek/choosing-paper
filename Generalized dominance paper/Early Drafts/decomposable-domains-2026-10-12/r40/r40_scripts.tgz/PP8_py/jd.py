"""PP8 library: audit's joint-defence candidate (AUDIT_joint_defence.md), implemented as specified.

Geometry (exact) and conventions are PP7's (pp7core.py is an unmodified copy of PP7_py/core.py):
  * one GLOBAL central arrangement of every plane of every model in the pool (+ diagonal and coordinate
    planes); every model is a vector of advice over its cells, so two records rec(X,Y), rec(X',Y') are
    EQUAL iff they have the same changed cells with the same (old,new) advice: records are identified across
    contexts by exact record equality;
  * cell masses: float (exact integer determinants, PP7's routine) with a RIGOROUS per-cell error radius
    obtained from a 160-bit arb ball (python-flint) for the same solid angle.  Every derived quantity
    (nu(P_i), nu(Q_i), b_i, Phi_i, c_i, priorities) carries a rigorous absolute error bound, so every
    sign/comparison used is either CERTIFIED or reported as uncertified;
  * anchors A(d): exact rational polygons (PP5/PP7 per-ray linear constraints), with a float pre-filter that
    only SKIPS half-planes satisfied with a large margin at every current vertex (exact clipping otherwise).

The rule (all four steps exactly as the audit states them):
  1. per record: b_i, Phi_i = 4 nu(P_i) - nu(Q_i), c_i = nu(Q_i)/(nu(P_i)+nu(Q_i)); eligible: guidance
     compulsorily (strict guidance reverse forbidden); a non-guidance d only if A(d) != {} and Phi_i(d) >= 0;
     face requirements for d and for bar(d);
  2. joint choice per unordered pair over the 4^3 states: min #both-worlds, max #accepted non-guidance
     directions, min sum of c_i over accepted non-guidance directions, then the canonical tie-break
     (first nonzero world-1 rank-difference integral over an enumeration of rational boxes orients the pair;
     states ordered lexicographically: forward only < reverse only < both < neither, world 1 first);
  3. priority (s,m) of a removable pair present at world i;
  4. one simultaneous deletion: in every violating triple of the pool at world i, all removable pairs of
     lowest priority are marked; marked records and reverses are removed at world i in every context."""
import sys, os, itertools, math, time
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from pp7core import *
import numpy as np
from flint import arb, ctx as fctx
fctx.prec = 160

ADVC = '+-0C'
AIDX = {a: k for k, a in enumerate(ADVC)}
FACES = [(0,), (1,), (2,), (0, 1), (0, 2), (1, 2), (0, 1, 2)]
EPSM = 2.3e-16

# ------------------------------------------------------------------ certified masses
def tri_arb(a, b, c):
    num = abs(det3(a, b, c))
    if num == 0: return arb(0)
    na, nb, nc = (arb(dot(x, x)).sqrt() for x in (a, b, c))
    den = na*nb*nc + dot(a, b)*nc + dot(a, c)*nb + dot(b, c)*na
    return 2*arb.atan2(arb(num), den)

def mass_arb(poly):
    s = arb(0)
    for k in range(1, len(poly)-1): s += tri_arb(poly[0], poly[k], poly[k+1])
    return s/(4*arb.pi())

def chi3cdf(r):
    return math.erf(r/math.sqrt(2)) - math.sqrt(2/math.pi)*r*math.exp(-r*r/2)

# ------------------------------------------------------------------ anchors with float pre-filter
def _lin_float(r, k, sign, epsf):
    """float coefficients (A1,A2,B) of q -> P_q(sign*r) on chamber k, in (x,y) coords."""
    if sign > 0:
        c = [float(t) for t in r]; c[k] += epsf*(3*min(r) - sum(r))
    else:
        c = [-float(t) for t in r]; c[k] += epsf*(sum(r) - 3*max(r))
    return (c[0]-c[2], c[1]-c[2], c[2])

def anchor_polys(changed, eps):
    """changed: list of (cell polygon, old advice char).  Returns {k: polygon} (exact), or None if empty
    because the old side is contradictory somewhere."""
    epsf = float(eps)
    H = {0: {}, 1: {}, 2: {}}
    for c, ax in changed:
        if ax == 'C': return None
        for r in c:
            for k in range(3):
                if ax == '+': H[k].setdefault((r, +1, 1), None)
                elif ax == '-': H[k].setdefault((r, -1, 1), None)
                else:
                    H[k].setdefault((r, +1, -1), None); H[k].setdefault((r, -1, -1), None)
    polys = {}
    for k in range(3):
        poly = chamber(k)
        pf = [(float(v[0]), float(v[1])) for v in poly]
        for (r, sgn, flip) in H[k]:
            if not poly: break
            A1, A2, B = _lin_float(r, k, sgn, epsf)
            if flip < 0: A1, A2, B = -A1, -A2, -B
            ok = True
            for (x, y) in pf:
                val = A1*x + A2*y + B
                if not (val > 1e-11*(abs(A1*x) + abs(A2*y) + abs(B)) + 1e-300):
                    ok = False; break
            if ok: continue
            c = lin_lowprev(r, k, sgn, eps)
            if flip < 0: c = [-t for t in c]
            poly = clip2(poly, to2d(c))
            pf = [(float(v[0]), float(v[1])) for v in poly]
        polys[k] = poly
    return polys


# ------------------------------------------------------------------ exact equality of step masses by symmetry
SIGNED_PERMS = [(perm, sg) for perm in itertools.permutations(range(3)) for sg in itertools.product((1, -1), repeat=3)]
def canon_cell(poly):
    """canonical form of a cone up to the 48 signed coordinate permutations (orthogonal maps, so congruent
    cones have equal solid angle exactly)."""
    best = None
    for perm, sg in SIGNED_PERMS:
        rs = [prim(tuple(sg[k]*r[perm[k]] for k in range(3))) for r in poly]
        n = len(rs)
        for seq in (rs, rs[::-1]):
            for k in range(n):
                t = tuple(seq[k:] + seq[:k])
                if best is None or t < best: best = t
    return best

# ------------------------------------------------------------------ the pool on a global arrangement
class Pool:
    def __init__(self, models, eps, log=print, extra_planes=()):
        t0 = time.time()
        self.eps = F(eps); self.log = log
        pl = []
        for M in models: pl += M.planes()
        self.planes = dedup_planes(pl + DIAG + list(extra_planes))
        self.cells = arrangement(self.planes)
        C = len(self.cells); self.C = C
        self.g = [interior(c) for c in self.cells]
        self.mf = np.array([mass_float(c) for c in self.cells])
        rad = np.empty(C)
        for k, c in enumerate(self.cells):
            ma = mass_arb(c)
            rad[k] = abs(float(ma.mid()) - self.mf[k]) + float(ma.rad()) + 1e-17*self.mf[k] + 1e-300
        self.mrad = rad
        tot = float(self.mf.sum())
        assert abs(tot - 1) < 1e-9, tot
        self.rk = np.zeros((C, 4, 3), dtype=np.int8)
        for k, g in enumerate(self.g):
            for a in ADVC:
                for i in range(3): self.rk[k, AIDX[a], i] = rank(a, g, i)
        self.sigidx = {self.signs(g): k for k, g in enumerate(self.g)}
        assert len(self.sigidx) == C, 'cell sign vectors not distinct'
        self.octant = np.array([(0 if g[0] < 0 else 4) + (0 if g[1] < 0 else 2) + (0 if g[2] < 0 else 1) for g in self.g])
        self.A = []; self.names = []; self.selp = []; self.bykey = {}
        for M in models: self.add_vec(np.array([AIDX[M.advice(g)] for g in self.g], dtype=np.int8), M.name,
                                      M.p if M.selected else None)
        log('pool: %d planes, %d cells (total mass %.15f), %d models, %.1fs' % (len(self.planes), C, tot, len(self.A), time.time()-t0))

    def signs(self, g):
        return tuple(1 if dot(n, g) > 0 else (-1 if dot(n, g) < 0 else 0) for n in list(self.planes) + [(1, 0, 0), (0, 1, 0), (0, 0, 1)])
    def locate(self, g):
        s = self.signs(g)
        if 0 in s: return None
        return self.sigidx.get(s)

    def add_vec(self, a, name, p=None):
        key = a.tobytes()
        if key in self.bykey:
            k = self.bykey[key]
            if p is not None and self.selp[k] is None: self.selp[k] = p
            return k, False
        self.bykey[key] = len(self.A); self.A.append(a); self.names.append(name); self.selp.append(p)
        return len(self.A)-1, True

    # -------------------------------------------------------------- closure under splicing of records
    def close(self, cap=400, rounds=6):
        """add Z with Y's advice on D for every record rec(X,Y) of the pool and every pool model Z that
        agrees with X on D; repeat until closed (or cap)."""
        for rnd in range(rounds):
            N = len(self.A)
            Am = np.array(self.A)
            diff = {}
            for u in range(N):
                d = (Am != Am[u])                              # N x C
                pk = np.packbits(d, axis=1)
                for z in range(N): diff[(u, z)] = int.from_bytes(pk[z].tobytes(), 'big')
            seen = set(); added = 0
            for u in range(N):
                for v in range(N):
                    if u == v: continue
                    D = np.nonzero(Am[u] != Am[v])[0]
                    key = (D.tobytes(), Am[u][D].tobytes(), Am[v][D].tobytes())
                    if key in seen: continue
                    seen.add(key)
                    duv = diff[(u, v)]
                    for z in range(N):
                        if z == u or (diff[(u, z)] & duv): continue
                        a = Am[z].copy(); a[D] = Am[v][D]
                        k, new = self.add_vec(a, '%s^[%s>%s]' % (self.names[z], self.names[u], self.names[v]))
                        if new:
                            added += 1
                            if len(self.A) >= cap:
                                self.log('closure: CAP %d reached in round %d (not closed)' % (cap, rnd+1)); return False
            self.log('closure round %d: +%d models -> %d' % (rnd+1, added, len(self.A)))
            if added == 0: return True
        return False

    # -------------------------------------------------------------- records
    def build_records(self):
        t0 = time.time()
        N = len(self.A); Am = np.array(self.A); self.Am = Am
        self.N = N
        self.recmat = -np.ones((N, N), dtype=np.int64)
        keys = {}; self.rD = []; self.rold = []; self.rnew = []
        for u in range(N):
            for v in range(N):
                if u == v: continue
                D = np.nonzero(Am[u] != Am[v])[0]
                key = (D.tobytes(), Am[u][D].tobytes(), Am[v][D].tobytes())
                r = keys.get(key)
                if r is None:
                    r = len(self.rD); keys[key] = r
                    self.rD.append(D); self.rold.append(Am[u][D]); self.rnew.append(Am[v][D])
                self.recmat[u, v] = r
        R = len(self.rD); self.R = R
        self.rev = np.array([keys[(self.rD[r].tobytes(), self.rnew[r].tobytes(), self.rold[r].tobytes())] for r in range(R)])
        self.P = np.zeros((R, 3)); self.Q = np.zeros((R, 3)); self.Pe = np.zeros((R, 3)); self.Qe = np.zeros((R, 3))
        self.G = np.zeros((R, 3), dtype=bool)
        for r in range(R):
            D = self.rD[r]
            ro = self.rk[D, self.rold[r], :].astype(int); rn = self.rk[D, self.rnew[r], :].astype(int)
            dl = rn - ro
            pos = np.maximum(dl, 0); ng = np.maximum(-dl, 0)
            m = self.mf[D][:, None]; e = self.mrad[D][:, None]
            n = len(D) + 2
            self.P[r] = (pos*m).sum(0); self.Q[r] = (ng*m).sum(0)
            self.Pe[r] = (pos*e).sum(0) + n*EPSM*(pos*m).sum(0)
            self.Qe[r] = (ng*e).sum(0) + n*EPSM*(ng*m).sum(0)
            self.G[r] = (len(D) > 0) & (ng.sum(0) == 0)
        self.b = self.P - self.Q; self.be = self.Pe + self.Qe
        self.phi = 4*self.P - self.Q; self.phie = 4*self.Pe + self.Qe
        self.log('records: %d distinct (from %d ordered model pairs), %.1fs' % (R, N*(N-1), time.time()-t0))
        # anchors
        t0 = time.time()
        selidx = [k for k in range(N) if self.selp[k] is not None]
        self.faces = [None]*R; self.Anon = np.zeros(R, dtype=bool)
        cache = {}
        nshort = 0
        for r in range(R):
            D = self.rD[r]; old = self.rold[r]
            ck = (D.tobytes(), old.tobytes())
            if ck in cache:
                self.faces[r] = cache[ck]; self.Anon[r] = (0, 1, 2) in cache[ck]; continue
            if (old == AIDX['C']).any(): f = []
            else:
                selmatch = any((Am[s][D] == old).all() for s in selidx)
                silent = (old == AIDX['0']).any()
                if selmatch and silent:
                    f = [(0, 1, 2)]; nshort += 1        # x in A(d); silence on D excludes every boundary anchor
                else:
                    polys = anchor_polys([(self.cells[c], ADVC[o]) for c, o in zip(D, old)], self.eps)
                    f = [] if polys is None else faces_met(polys)
                    if selmatch: assert (0, 1, 2) in f
            cache[ck] = f; self.faces[r] = f; self.Anon[r] = (0, 1, 2) in f
        self.log('anchors: %d distinct old sides (%d by the selected+silence shortcut), %.1fs' % (len(cache), nshort, time.time()-t0))

    # -------------------------------------------------------------- canonical orientation (tie-break)
    def orient(self, r):
        """+1 if r is the canonical forward direction of {r, rev r}: the first rational box (unit cubes
        prod [a_j, a_j+1], a in {-1,0}^3, lexicographic) on which the world-1 rank-difference integral
        int (r_1(new) - r_1(old)) d gamma is nonzero has a positive integral.  Returns (sign, exact?)."""
        D = self.rD[r]
        d1 = self.rk[D, self.rnew[r], 0].astype(int) - self.rk[D, self.rold[r], 0].astype(int)
        order = [0, 1, 2, 3, 4, 5, 6, 7]       # (a1,a2,a3) in {-1,0}^3 lexicographic = octant code order
        for o in order:
            sel = self.octant[D] == o
            if not sel.any(): continue
            vals = d1[sel]
            if (vals > 0).all(): return 1, True
            if (vals < 0).all(): return -1, True
            tot = 0.0; scale = 0.0
            for c, dv in zip(D[sel], vals):
                gm = self.cube_mass(c)
                tot += dv*gm; scale += abs(dv)*gm
            if abs(tot) > 1e-6*scale: return (1 if tot > 0 else -1), False
        return 1, False

    def cube_mass(self, c, depth=3):
        """gamma(unit cube of c's octant cap cone c) = int_{cone cap S^2} chi3cdf(1/|w|_inf) dsigma/(4 pi),
        by recursive midpoint subdivision of the fan triangles (float; used only to orient a pair)."""
        def unit(v):
            v = np.array(v, dtype=float); return v/np.linalg.norm(v)
        def area(a, b, cc):
            num = abs(np.dot(a, np.cross(b, cc)))
            return 2*math.atan2(num, 1 + np.dot(a, b) + np.dot(a, cc) + np.dot(b, cc))
        tot = 0.0
        stack = []
        V = [unit([float(x) for x in p]) for p in self.cells[c]]
        for k in range(1, len(V)-1): stack.append((V[0], V[k], V[k+1], depth))
        while stack:
            a, b, cc, d = stack.pop()
            if d == 0:
                w = unit(a + b + cc)
                tot += chi3cdf(1/np.abs(w).max())*area(a, b, cc)/(4*math.pi); continue
            ab, bc, ca = unit(a+b), unit(b+cc), unit(cc+a)
            stack += [(a, ab, ca, d-1), (ab, b, bc, d-1), (ca, bc, cc, d-1), (ab, bc, ca, d-1)]
        return tot


    def exact_PeqQ(self, r, i):
        """True if nu(P_i(r)) = nu(Q_i(r)) EXACTLY: some signed coordinate permutation sigma (an orthogonal map,
        preserving the Gaussian measure) carries the step-count function of P_i onto that of Q_i a.e.  Checked
        exactly on the common refinement of the arrangement and its image under sigma.  False = not shown."""
        D = self.rD[r]
        dl = self.rk[D, self.rnew[r], i].astype(int) - self.rk[D, self.rold[r], i].astype(int)
        fP = {int(c): int(v) for c, v in zip(D, dl) if v > 0}
        fQ = {int(c): int(-v) for c, v in zip(D, dl) if v < 0}
        if abs(self.P[r, i] - self.Q[r, i]) > self.Pe[r, i] + self.Qe[r, i]: return False
        for perm, sg in SIGNED_PERMS:
            def sig(v): return tuple(sg[k]*v[perm[k]] for k in range(3))
            def sig_inv(v):
                w = [0, 0, 0]
                for k in range(3): w[perm[k]] = sg[k]*v[k]
                return tuple(w)
            # quick float precheck on cell interiors
            ok = True
            for c, k in list(fP.items())[:20]:
                cc = self.locate(sig(self.g[c]))
                if cc is not None and fQ.get(cc, 0) != k: ok = False; break
            if not ok: continue
            planes = dedup_planes(self.planes + [sig(n) for n in self.planes])
            good = True
            for cell in arrangement(planes):
                g = interior(cell)
                c1 = self.locate(g); c0 = self.locate(sig_inv(g))
                if c1 is None or c0 is None: good = False; break
                if fQ.get(c1, 0) != fP.get(c0, 0): good = False; break
            if good: return True
        return False

    # -------------------------------------------------------------- step 2: joint choice
    def joint(self, variant=None):
        """variant None = the audit's rule.  variant 'V2' (NOT the candidate; t4_variant.py only): afterwards, every
        additively dominated direction d (A(d) != {}, all b_j(d) < 0) is also accepted at every world with Phi_i(d) >= 0
        (closing R^0 at points where A(bar d) switches on; ties allowed there)."""
        t0 = time.time()
        R = self.R
        self.acc0 = np.zeros((R, 3), dtype=bool)
        self.flags = {'phi_unc': 0, 'obj3_neartie': 0, 'obj4_used': 0, 'orient_numeric': 0, 'infeasible': 0}
        self.obj4_cases = []; self.obj3_unc = []
        done = np.zeros(R, dtype=bool)
        STATES = [(1, 0), (0, 1), (1, 1), (0, 0)]   # forward only, reverse only, both, neither
        for d in range(R):
            if done[d]: continue
            e = self.rev[d]; done[d] = done[e] = True
            if d == e: raise RuntimeError('self-reverse record')
            allow = {}
            for x, y in ((d, e), (e, d)):
                for i in range(3):
                    if self.G[x, i]: allow[(x, i)] = 'G'
                    elif self.G[y, i]: allow[(x, i)] = None
                    elif self.Anon[x] and self.phi[x, i] >= 0:
                        allow[(x, i)] = 'E'
                        if abs(self.phi[x, i]) <= self.phie[x, i]: self.flags['phi_unc'] += 1
                    else:
                        allow[(x, i)] = None
                        if self.Anon[x] and abs(self.phi[x, i]) <= self.phie[x, i]: self.flags['phi_unc'] += 1
            def cval(x, i):
                P, Q = self.P[x, i], self.Q[x, i]; return Q/(P+Q)
            cands = []
            for st in itertools.product(range(4), repeat=3):
                fx = [STATES[s][0] for s in st]; fy = [STATES[s][1] for s in st]
                ok = True
                for i in range(3):
                    for x, f in ((d, fx[i]), (e, fy[i])):
                        a = allow[(x, i)]
                        if a == 'G' and not f: ok = False
                        if a is None and f: ok = False
                if not ok: continue
                if any(not any(fx[i] for i in I) for I in self.faces[d]): continue
                if any(not any(fy[i] for i in I) for I in self.faces[e]): continue
                nboth = sum(fx[i] and fy[i] for i in range(3))
                nng = 0; terms = []; ce = 0.0
                for i in range(3):
                    for x, f in ((d, fx[i]), (e, fy[i])):
                        if f and allow[(x, i)] == 'E':
                            nng += 1; terms.append(cval(x, i))
                            P, Q, Pe, Qe = self.P[x, i], self.Q[x, i], self.Pe[x, i], self.Qe[x, i]
                            ce += (Qe*(P+Q) + Q*(Pe+Qe))/((P+Q-Pe-Qe)**2) + 1e-15
                cands.append(((nboth, -nng), math.fsum(sorted(terms)), ce, st, fx, fy))
            if not cands:
                self.flags['infeasible'] += 1; continue
            best12 = min(c[0] for c in cands)
            c12 = [c for c in cands if c[0] == best12]
            bcs = min(c[1] for c in c12)
            win0 = [c for c in c12 if c[1] == bcs]
            bce = win0[0][2]
            near = [c for c in c12 if c[1] != bcs and c[1] - bcs <= c[2] + bce]
            # exact ties: states differing only by d <-> bar(d) at worlds where nu(P_i) = nu(Q_i) exactly (c_i = 1/2 both ways)
            def exact_equal(c1, c2):
                for i in range(3):
                    s1, s2 = (c1[4][i], c1[5][i]), (c2[4][i], c2[5][i])
                    if s1 == s2: continue
                    if {s1, s2} != {(1, 0), (0, 1)}: return False
                    if allow[(d, i)] != 'E' or allow[(e, i)] != 'E' or not self.exact_PeqQ(d, i): return False
                return True
            still = []
            for c in near:
                if exact_equal(c, win0[0]): win0.append(c); self.flags['exact_tie'] = self.flags.get('exact_tie', 0) + 1
                else: still.append(c)
            if still:
                self.flags['obj3_neartie'] += 1
                self.obj3_unc.append((d, e, bcs, [c[1] for c in still]))
            if len(win0) > 1:
                self.flags['obj4_used'] += 1
                o, exact = self.orient(d)
                if not exact: self.flags['orient_numeric'] += 1
                sw = {0: 1, 1: 0, 2: 2, 3: 3}
                def code(c):
                    return c[3] if o > 0 else tuple(sw[t] for t in c[3])
                win = min(win0, key=code)
                self.obj4_cases.append((d, e, len(win0), o, exact))
            else:
                win = win0[0]
            self.acc0[d] = win[4]; self.acc0[e] = win[5]
        if variant == 'V2':
            nv = 0
            for d in range(R):
                if self.Anon[d] and (self.b[d] < 0).all() and self.Anon[self.rev[d]]:
                    for i in range(3):
                        if self.phi[d, i] >= 0 and not self.acc0[d, i]: self.acc0[d, i] = True; nv += 1
            self.flags['V2_added'] = nv
        self.log('joint choice: %d record pairs, flags %s, %.1fs' % (R//2, self.flags, time.time()-t0))

    # -------------------------------------------------------------- step 3: priorities
    def priorities(self, variant=None):
        """variant None = the audit's rule.  variant 'V1' (NOT the candidate; used only in t4_variant.py): s=1 also when
        A(bar d) is nonempty, i.e. every accepted additively dominated defence (all b_j(d) < 0, A(d) != {}) is protected.
        variant 'V3' (NOT the candidate): priority (crit, s, m), crit = 1 if world i is the only initial (R^0) world covering
        some face obligation of an accepted direction of the pair."""
        """prio[r, i] (same for r and rev r): s*10 + m for a removable pair present at i; +inf if not
        removable (guidance in either direction at i); nan if absent.  Also an error radius for m."""
        R = self.R
        self.prio = np.full((R, 3), np.nan); self.prioe = np.zeros((R, 3)); self.s = np.zeros((R, 3), dtype=int)
        self.s_unc = 0
        for d in range(R):
            e = self.rev[d]
            for i in range(3):
                if not (self.acc0[d, i] or self.acc0[e, i]): continue
                if self.G[d, i] or self.G[e, i]:
                    self.prio[d, i] = np.inf; continue
                s = 0; m = np.inf; me = 0.0
                for x in (d, e):
                    if not self.acc0[x, i]: continue
                    y = self.rev[x]
                    if self.Anon[x] and (variant == 'V1' or not self.Anon[y]) and (self.b[x] < 0).all():
                        s = 1
                        if (np.abs(self.b[x]) <= self.be[x]).any(): self.s_unc += 1
                    P, Q = self.P[x, i], self.Q[x, i]
                    val = (4*P - Q)/(P + Q)
                    err = (4*self.Pe[x, i] + self.Qe[x, i])/(P+Q-self.Pe[x, i]-self.Qe[x, i]) \
                        + abs(4*P-Q)*(self.Pe[x, i]+self.Qe[x, i])/((P+Q)*(P+Q-self.Pe[x, i]-self.Qe[x, i])) + 1e-15
                    if val < m: m, me = val, err
                crit = 0
                if variant == 'V3':
                    for x in (d, e):
                        if self.acc0[x, i] and any([j for j in I if self.acc0[x, j]] == [i] for I in self.faces[x]): crit = 1
                self.prio[d, i] = 100*crit + 10*s + m; self.prioe[d, i] = me; self.s[d, i] = s
        self.log('priorities computed; s uncertified %d' % self.s_unc)

    # -------------------------------------------------------------- step 4: one simultaneous deletion
    def relation(self, acc, i):
        N = self.N
        M = acc[self.recmat, i]
        np.fill_diagonal(M, True)
        return M

    def delete(self, keep_witness=True):
        t0 = time.time()
        N = self.N
        self.marked = [set(), set(), set()]
        self.ntri = [0, 0, 0]; self.neartie = [0, 0, 0]
        self.witness = [{}, {}, {}]
        pairid = np.minimum(self.recmat, self.rev[np.maximum(self.recmat, 0)])
        np.fill_diagonal(pairid, -1)
        self.pairid = pairid
        for i in range(3):
            M = self.relation(self.acc0, i)
            Pm = self.prio[self.recmat, i].copy(); np.fill_diagonal(Pm, np.nan)
            Em = self.prioe[self.recmat, i].copy(); np.fill_diagonal(Em, 0)
            for x in range(N):
                ys = M[x].copy(); ys[x] = False
                zs = M[:, x] & ~M[x, :]
                if not ys.any() or not zs.any(): continue
                yi = np.nonzero(ys)[0]; zi = np.nonzero(zs)[0]
                V = M[np.ix_(yi, zi)]
                if not V.any(): continue
                a, c = np.nonzero(V)
                Y = yi[a]; Z = zi[c]
                p1 = Pm[x, Y]; p2 = Pm[Y, Z]; p3 = Pm[Z, x]
                e1 = Em[x, Y]; e2 = Em[Y, Z]; e3 = Em[Z, x]
                mn = np.minimum(np.minimum(p1, p2), p3)
                assert np.isfinite(mn).all(), 'violating triple with no removable pair'
                self.ntri[i] += len(Y)
                for (pp, ee, U, W) in ((p1, e1, np.full(len(Y), x), Y), (p2, e2, Y, Z), (p3, e3, Z, np.full(len(Y), x))):
                    hit = pp == mn
                    near = (~hit) & (pp - mn <= ee + np.where(p1 == mn, e1, np.where(p2 == mn, e2, e3)))
                    self.neartie[i] += int(near.sum())
                    for u, w in zip(U[hit], W[hit]):
                        pid = pairid[u, w]
                        self.marked[i].add(int(pid))
                if keep_witness:
                    for k in range(len(Y)):
                        for (pp, U, W) in ((p1[k], x, Y[k]), (p2[k], Y[k], Z[k]), (p3[k], Z[k], x)):
                            if pp == mn[k]:
                                lst = self.witness[i].setdefault(int(pairid[U, W]), [])
                                if len(lst) < 50: lst.append((x, int(Y[k]), int(Z[k])))
        self.acc = self.acc0.copy()
        for i in range(3):
            for pid in self.marked[i]:
                self.acc[pid, i] = False; self.acc[self.rev[pid], i] = False
        self.log('deletion: violating triples per world %s; marked record pairs per world %s; near-ties (uncertified priority order) %s; %.1fs'
                 % (self.ntri, [len(m) for m in self.marked], self.neartie, time.time()-t0))

    def tc_check(self, acc):
        out = []
        for i in range(3):
            M = self.relation(acc, i)
            cnt = 0
            for x in range(self.N):
                zs = M[:, x] & ~M[x, :]
                if not zs.any(): continue
                ys = M[x].copy()
                V = M[np.ix_(np.nonzero(ys)[0], np.nonzero(zs)[0])]
                cnt += int(V.sum())
            out.append(cnt)
        return out

    # -------------------------------------------------------------- checks
    def obligations(self, acc):
        bad = []
        for r in range(self.R):
            for I in self.faces[r]:
                if not any(acc[r, i] for i in I): bad.append((r, I))
        return bad

    def contexts(self, r):
        u, v = np.nonzero(self.recmat == r); return list(zip(u.tolist(), v.tolist()))

    def incoherence(self, k):
        a = self.A[k]
        if (a == AIDX['C']).any():
            c = int(np.nonzero(a == AIDX['C'])[0][0]); return ('contradiction', self.g[c])
        for c in range(self.C):
            g = self.g[c]
            if (all(t > 0 for t in g) or all(t < 0 for t in g)) and self.rk[c, a[c], 0] != 0:
                return ('unanimous problem not accepted', g, ADVC[a[c]])
        sels = [s for s in range(self.N) if self.selp[s] is not None]
        if not sels: return None
        s0 = min(sels, key=lambda s: int((self.A[s] != a).sum()))
        diffc = np.nonzero(self.A[s0] != a)[0]
        accd = [self.g[c] for c in diffc if a[c] == AIDX['+']]
        acc_all = [self.g[c] for c in range(self.C) if a[c] == AIDX['+']]
        step = max(1, len(acc_all)//300)
        for g1 in accd[:40]:
            for g2 in acc_all[::step]:
                for t in (F(1), F(1, 4), F(4), F(1, 16), F(16)):
                    g3 = tuple(F(g1[j]) + t*g2[j] for j in range(3))
                    if not any(g3): continue
                    g3 = prim(g3)
                    c3 = self.locate(g3)
                    if c3 is None: continue
                    if a[c3] != AIDX['+']: return ('nonconvex acceptance', g1, g2, t, g3, ADVC[a[c3]])
        return None

    def selected_checks(self, acc):
        sels = [s for s in range(self.N) if self.selp[s] is not None]
        dom = []; ties = []
        self.incoh = {}
        for s in sels:
            for x in range(self.N):
                if x == s: continue
                xs = [acc[self.recmat[x, s], i] for i in range(3)]
                sx = [acc[self.recmat[s, x], i] for i in range(3)]
                if all(xs) and not all(sx): dom.append((x, s))
                if all(xs) and all(sx):
                    if x not in self.incoh: self.incoh[x] = self.incoherence(x)
                    ties.append((x, s, self.incoh[x]))
        return dom, ties

    # -------------------------------------------------------------- LP endorsement
    def endorse_lp(self, acc, i, recs):
        """Is there a strictly positive field w on rank steps (cell, level) with sum_P w - sum_Q w >= 0 for
        every record in recs at world i?  Exact on the pool (any positive cell weights are realisable).
        Returns (feasible, certificate) where the certificate is an exact Farkas combination."""
        from scipy.optimize import linprog
        from scipy.sparse import lil_matrix
        steps = {}
        rows = []
        for r in recs:
            D = self.rD[r]
            ro = self.rk[D, self.rold[r], i].astype(int); rn = self.rk[D, self.rnew[r], i].astype(int)
            row = {}
            for c, a, b in zip(D, ro, rn):
                if b > a:
                    for l in range(a+1, b+1): row[steps.setdefault((int(c), l), len(steps))] = 1
                elif a > b:
                    for l in range(b+1, a+1): row[steps.setdefault((int(c), l), len(steps))] = -1
            rows.append(row)
        if not rows: return True, None
        S = len(steps)
        m = np.zeros(S)
        for (c, l), k in steps.items(): m[k] = self.mf[c]
        Am = lil_matrix((len(rows), S))
        for k, row in enumerate(rows):
            for j, v in row.items(): Am[k, j] = v
        Am = Am.tocsr()
        # primal with margin: maximise t s.t. A w >= t * rowscale, m <= w <= 1000 m, t <= 1
        from scipy.sparse import hstack, csr_matrix
        rs = np.abs(Am) @ m
        Aub = hstack([-Am, csr_matrix(rs.reshape(-1, 1))]).tocsr()
        c = np.zeros(S+1); c[-1] = -1
        bnds = [(m[k], 1000*m[k]) for k in range(S)] + [(None, 1)]
        res = linprog(c, A_ub=Aub, b_ub=np.zeros(len(rows)), bounds=bnds, method='highs')
        if res.status == 0 and res.x[-1] >= -1e-12:
            w = [F(float(x)) for x in res.x[:S]]
            exact_ok = all(x > 0 for x in w) and all(sum(v*w[j] for j, v in row.items()) >= 0 for row in rows)
            return True, ('field', float(res.x[-1]), exact_ok)
        # the cap w <= 1000 m is only a normalisation: retry the plain feasibility problem w >= m, A w >= 0
        res1 = linprog(np.zeros(S), A_ub=-Am, b_ub=np.zeros(len(rows)), bounds=[(m[k], None) for k in range(S)], method='highs')
        if res1.status == 0:
            w = [F(float(x)) for x in res1.x]
            exact_ok = all(x > 0 for x in w) and all(sum(v*w[j] for j, v in row.items()) >= 0 for row in rows)
            return True, ('field (uncapped)', float((Am @ res1.x).min()), exact_ok)
        # Farkas: lambda >= 0 with lambda^T A <= 0 and sum(lambda^T A) <= -1
        AT = Am.T.tocsr()
        res2 = linprog(np.ones(len(rows)), A_ub=np.vstack([AT.toarray(), np.ones((1, S)) @ AT.toarray()]),
                       b_ub=np.concatenate([np.zeros(S), [-1]]), bounds=[(0, None)]*len(rows), method='highs')
        if res2.status != 0: return False, ('lp-infeasible, no certificate', res.status, res2.status)
        lam = [F(x).limit_denominator(1000) for x in res2.x]
        tot = {}
        for k, row in enumerate(rows):
            if lam[k] == 0: continue
            for j, v in row.items(): tot[j] = tot.get(j, 0) + lam[k]*v
        okc = all(v <= 0 for v in tot.values()) and any(v < 0 for v in tot.values())
        supp = [(recs[k], lam[k]) for k in range(len(rows)) if lam[k] != 0]
        return False, ('farkas', okc, supp)
