"""PP8 t1: the joint-defence candidate on PP7's certified configurations and PP5's configurations, all four
settings, pools closed under splicing of their own records.  Items 1, 3, 4.
Usage: python3 -I -B t1_main.py <setting> [config ...]"""
import sys, os
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from driver import *
from configs import *

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def main(key, which):
    p0, eps = SETTINGS[key]
    summary = []
    for cf in which:
        if cf == 't8':
            ms = cfg_t8(p0, eps); lab = 'PP7 t8 single base: C_p0 + 8 nested sticky rivals (grid {1,9/10}^3)'
        elif cf == 't1':
            ms = cfg_t1(p0, eps); lab = 'PP7 t1 pairs and pumps: C_p0, Y, Xc, Xu, Z1-3, YZ1-3'
        elif cf == 't3c':
            ms, h = cfg_t3core(p0, eps, key); lab = 'PP7 t3 deletion-minimal core: %d selected + Y (lattice step %s)' % (len(ms)-1, h)
        elif cf == 't6c':
            ms = cfg_t6core(p0, eps, key); lab = 'PP7 t6 deletion-minimal mixed core: %s' % [M.name for M in ms]
        elif cf.startswith('pump'):
            wv = int(cf[4:] or 1) - 1
            a = PP5_A if key == 'e1_3' else p0
            ms, q = cfg_pp5_pump(a, eps, world=wv)
            if ms is None: pr('no pump geometry for world', wv+1); continue
            lab = 'PP5 t7 pump (kappa = 4 version), lead world %d: C_a (a = %s), C_q (q = %s), Ypump, Zpump' % (wv+1, tuple(map(str, a)), tuple(map(str, q)))
        elif cf == 'diag':
            if key != 'e1_3': continue
            ms = cfg_pp5_diag(); lab = 'PP5 diagnostic: selected a, b, c, y1, y2 and the two certified grid triples'
        elif cf == 'mix':
            ms = cfg_t1(p0, eps)
            pm, q = cfg_pp5_pump(p0, eps)
            ms = ms + pm[1:]
            lab = 'mixed: PP7 t1 models + PP5 pump models on the same C_p0'
        elif cf == 't6':
            ms = cfg_t6(p0, eps); lab = 'PP7 t6 full pool: 9 selected + 16 rivals'
        else:
            continue
        res = run_pool(ms, eps, '%s / %s' % (key, lab), pr, cap=int(os.environ.get('PP8_CAP', '400')))
        P = res['P']
        summary.append((cf, P.N, P.closed, res['tc0'], res['tc1'], len(res['ob1']), len(res['lost_some']), len(res['dom']), len(res['ties']),
                        [('E' if ok else 'NOT') for ok, n, c in res.get('lp', [])]))
    pr('\nSUMMARY %s: (config, models, closed, TC initial, TC final, failed obligations, anchored records losing some defender, dominated, ties, LP endorsement per world)' % key)
    for s in summary: pr('   ', s)

if __name__ == '__main__':
    key = sys.argv[1]
    which = sys.argv[2:] or ['diag', 't8', 't1', 't3c', 't6c', 'pump1', 'pump2', 'pump3', 'mix']
    main(key, which)
    tag = key if len(sys.argv) <= 2 else key + '_' + '_'.join(sys.argv[2:])
    open(os.path.join(HERE, 't1_main_%s.out' % tag), 'w').write('\n'.join(out) + '\n')
