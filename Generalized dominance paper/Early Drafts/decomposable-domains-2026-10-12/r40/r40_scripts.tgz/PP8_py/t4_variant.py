"""PP8 t4: NOT the candidate.  Nearby variants, on the same pools (NUMERICS on pools; signs certified as in t1):
   V1 = priority s = 1 for every accepted additively dominated direction (A(d) != {}, all b_j(d) < 0), dropping the
        clause A(bar d) = {};
   V1+V2 = V1, and R^0 closed at anchored-reverse points (additively dominated d also accepted at every
        Phi-eligible world; ties allowed there);
   V3 = priority (crit, s, m): a pair is critical at world i if i is the only initial world covering some face
        obligation of one of its accepted directions (record-local, so (IB) is kept).
Usage: python3 -I -B t4_variant.py <setting>"""
import sys, os
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from driver import *
from configs import *

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

def run(models, eps, label, jv, pv):
    P = Pool(models, eps, log=lambda *a: None)
    P.close(cap=400); P.build_records(); P.joint(variant=jv); P.priorities(variant=pv); P.delete()
    ob = P.obligations(P.acc); dom, ties = P.selected_checks(P.acc)
    tc = P.tc_check(P.acc)
    lost = sum(1 for r in range(P.R) if P.faces[r] and any(P.acc0[r, i] and not P.acc[r, i] for i in range(3)))
    pr('   %-28s joint=%s prio=%s: models %d, TC final %s, failed obligations %d, anchored records losing a defender %d, dominated %d, all-world ties %d (incoherent %d), V2 additions %s'
       % (label, jv, pv, P.N, tc, len(ob), lost, len(dom), len(ties), sum(1 for x, s, c in ties if c is not None), P.flags.get('V2_added', 0)))
    for r, I in ob[:4]:
        pr('      failed: %s face %s; initial worlds %s' % (recname(P, r), I, [i+1 for i in range(3) if P.acc0[r, i]]))
        pid = int(min(r, P.rev[r]))
        for i in I:
            if not P.acc0[r, i]: continue
            for (x, y, z) in P.witness[i].get(pid, [])[:2]:
                pr('         world %d: %s <= %s <= %s <= %s, refused %s <= %s; priorities %.4f %.4f %.4f' % (
                    i+1, P.names[x], P.names[y], P.names[z], P.names[x], P.names[x], P.names[z],
                    P.prio[P.recmat[x, y], i], P.prio[P.recmat[y, z], i], P.prio[P.recmat[z, x], i]))

if __name__ == '__main__':
    key = sys.argv[1]
    p0, eps = SETTINGS[key]
    a = PP5_A if key == 'e1_3' else p0
    pr('\n=== %s' % key)
    cfgs = [('pump lead 1', cfg_pp5_pump(a, eps, world=0)[0]), ('pump lead 2', cfg_pp5_pump(a, eps, world=1)[0]),
            ('pump lead 3', cfg_pp5_pump(a, eps, world=2)[0]),
            ('mix (t1 + pump)', cfg_t1(p0, eps) + cfg_pp5_pump(p0, eps)[0][1:]),
            ('PP7 t8', cfg_t8(p0, eps)), ('PP7 t1', cfg_t1(p0, eps)), ('PP7 t3 core', cfg_t3core(p0, eps, key)[0]),
            ('PP7 t6 core', cfg_t6core(p0, eps, key))]
    for lab, ms in cfgs:
        for jv, pv in ((None, None), (None, 'V1'), ('V2', 'V1'), (None, 'V3')):
            run(ms, eps, lab, jv, pv)
    open(os.path.join(HERE, 't4_variant_%s.out' % key), 'w').write('\n'.join(out) + '\n')
