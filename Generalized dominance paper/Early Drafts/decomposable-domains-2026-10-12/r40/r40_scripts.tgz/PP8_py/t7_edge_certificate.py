"""PP8 t7: second certified failure (F-B), three models {C_a, C_p, Ypump}, with the independent implementation of
t3_pump_certificate.py (local cells, interval masses, exact anchors, interval objectives).

rec(Ypump, C_a) is anchored (q in A) and its anchor polygon meets the edge Delta_12, so (S) requires
Ypump <=_i C_a at world 1 or 2.  The joint choice puts it at worlds {2,3}.  At world 2 the triangle
C_a <=_2 C_p <=_2 Ypump <=_2 C_a, with C_a <=_2 Ypump refused, has lowest removable pair {Ypump, C_a}
(C_p's defence is protected, s = 1): the edge obligation is left with world 3 only."""
import sys, os
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import t3_pump_certificate as T
from configs import *
from mpmath import iv

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); print(s, flush=True); out.append(s)

CASES = {'e1_3': ((1, -1, 0), F(1, 10**6)), 'e1_1': ((1, -1, 0), F(1, 10**8)),
         'u_3': ((0, 1, -1), F(-1, 10**6)), 'u_1': ((1, -1, 0), F(1, 10**8))}

def prio(x, xb, ax, axb, j):
    if x.guid[j] or xb.guid[j]: return None
    s = 0; m = None
    for (e_, eb, a_) in ((x, xb, ax), (xb, x, axb)):
        if not a_: continue
        if e_.Anon and not eb.Anon and all(T.hi(t) < 0 for t in e_.b): s = 1
        m = e_.m[j] if m is None or T.hi(e_.m[j]) < T.lo(m) else m
    return (s, m)

def lower(p1, p2):
    if p1 is None: return False
    if p2 is None: return True
    return p1[0] < p2[0] or (p1[0] == p2[0] and T.certified_lt(p1[1], p2[1]))

def run(key):
    a = PP5_A if key == 'e1_3' else SETTINGS[key][0]; eps = SETTINGS[key][1]
    ms, q = cfg_pp5_pump(a, eps); Ca, Cq, Y, Z = ms
    v, t = CASES[key]
    p = tuple(a[k] + t*v[k] for k in range(3)); Cp = Model(p, eps, name='C_p')
    pr('\n=== %s: a = %s, p = a + (%s) %s' % (key, tuple(map(str, a)), t, v))
    R = {}
    for (n1, X1), (n2, X2) in (((('Ca', Ca)), ('Y', Y)), (('Ca', Ca), ('Cp', Cp)), (('Cp', Cp), ('Y', Y))):
        d, db = T.Rec(X1, X2), T.Rec(X2, X1)
        best, cert, nf, allow = T.joint(d, db)
        R[(n1, n2)] = (d, db, best, cert)
        pr('   {%s,%s}: R^0 %s<=%s at %s, %s<=%s at %s; unique optimum certified %s; faces fwd %s rev %s' % (
            n1, n2, n1, n2, [i+1 for i in range(3) if best[3][i]], n2, n1, [i+1 for i in range(3) if best[4][i]], cert, d.faces, db.faces))
    j = 1
    acc = lambda u, w: (R[(u, w)][2][3][j] if (u, w) in R else R[(w, u)][2][4][j])
    viol = acc('Ca', 'Cp') and acc('Cp', 'Y') and acc('Y', 'Ca') and not acc('Ca', 'Y')
    pr('   world 2: C_a <= C_p %s, C_p <= Y %s, Y <= C_a %s, C_a <= Y %s -> violation %s' % (acc('Ca', 'Cp'), acc('Cp', 'Y'), acc('Y', 'Ca'), acc('Ca', 'Y'), viol))
    P1 = prio(*R[('Ca', 'Cp')][:2], R[('Ca', 'Cp')][2][3][j], R[('Ca', 'Cp')][2][4][j], j)
    P2 = prio(*R[('Cp', 'Y')][:2], R[('Cp', 'Y')][2][3][j], R[('Cp', 'Y')][2][4][j], j)
    P3 = prio(*R[('Ca', 'Y')][:2], R[('Ca', 'Y')][2][3][j], R[('Ca', 'Y')][2][4][j], j)
    f = lambda P_: 'unremovable' if P_ is None else '(s=%d, m=%s)' % (P_[0], ivs(P_[1], 8))
    pr('   priorities at world 2: {C_a,C_p} %s, {C_p,Y} %s, {Y,C_a} %s' % (f(P1), f(P2), f(P3)))
    low = lower(P3, P1) and lower(P3, P2)
    dbY = R[('Ca', 'Y')][1]
    edge = (0, 1) in dbY.faces
    W = [i+1 for i in range(3) if R[('Ca', 'Y')][2][4][i]]
    ok = bool(viol and low and edge and W == [2, 3] and all(R[k][3] for k in R))
    pr('   CERTIFIED: {Y,C_a} uniquely lowest (%s); A(rec(Y,C_a)) meets the edge Delta_12 (%s); its initial worlds %s -> after deletion only world 3, edge obligation fails: %s' % (low, edge, W, ok))
    return ok

if __name__ == '__main__':
    res = {k: run(k) for k in (sys.argv[1:] or list(SETTINGS))}
    pr('\nSUMMARY', res)
    open(os.path.join(HERE, 't7_edge_certificate.out'), 'w').write('\n'.join(out) + '\n')
