"""Configurations: PP7's certified configurations and PP5's configurations, rebuilt with the same code paths
(functions copied verbatim from PP7_py/t8_single_base.py, t3_tieglue.py, t1_pairs_pumps.py, t6_onesided.py and,
for PP5's t7 pump, re-expressed with pp7core cones)."""
import sys, os, itertools, math
sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pp7core import *

SETTINGS = {
    'e1_3': ((F(9, 10), F(6, 100), F(4, 100)), F(3, 10)),
    'e1_1': ((F(9, 10), F(6, 100), F(4, 100)), F(1, 10)),
    'u_3':  ((F(35, 100), F(33, 100), F(32, 100)), F(3, 10)),
    'u_1':  ((F(35, 100), F(33, 100), F(32, 100)), F(1, 10)),
}

# ---------------------------------------------------------------- PP7 t8 (guidance-gluing, one selected model)
def t8_base_cones(p0, eps):
    cells = base_cells(p0, eps)
    sil = {0: [], 1: [], 2: []}
    for c in cells:
        g = interior(c)
        if cls(g) != 'U' and sel_advice(p0, g, eps) == '0': sil[cls(g)].append(c)
    big = {w: max(sil[w], key=lambda c: mass_float(largest_triangle(c))) for w in range(3)}
    tau = 0.25*min(mass_float(largest_triangle(big[w])) for w in range(3))
    return [cone_with_mass(big[w], tau) for w in range(3)]

def cfg_t8(p0, eps, grid=(F(1), F(9, 10))):
    T = t8_base_cones(p0, eps)
    C0 = Model(p0, eps, name='C_p0')
    rivals = []
    for t in itertools.product(grid, repeat=3):
        ov = []
        for w in range(3):
            S = shrunk(T[w], t[w]) if t[w] != 1 else T[w]
            ov.append((S, adv_from_label(interior(list(S)), 'A')))
        rivals.append(Model(p0, eps, ov, name='Y%s' % ''.join(str(grid.index(x)) for x in t)))
    return [C0] + rivals

# ---------------------------------------------------------------- PP7 t3 (sticky rival Y, selected lattice)
def build_Y(p0, eps):
    cells = base_cells(p0, eps)
    sil = {0: [], 1: [], 2: []}
    for c in cells:
        g = interior(c)
        if cls(g) == 'U': continue
        if sel_advice(p0, g, eps) == '0': sil[cls(g)].append(c)
    ovs = []
    big = {w: max(sil[w], key=lambda c: mass_float(largest_triangle(c))) for w in range(3)}
    tau = 0.25*min(mass_float(largest_triangle(big[w])) for w in range(3))
    m = [0.0]*3
    for w in range(3):
        t = cone_with_mass(big[w], tau)
        ovs.append((t, adv_from_label(interior(list(t)), 'A'))); m[w] += 2*mass_float(list(t))
    Y = Model(p0, eps, ovs, name='Y')
    add = [m[i] - sum(m[w] for w in range(3) if w != i) for i in range(3)]
    return Y, m, add

def lattice(p0, eps, add, k, safety=F(1, 2)):
    e, f = (1, -1, 0), (1, 0, -1)
    L0 = L_float(p0, eps); d = 1e-7
    def Lq(v): return L_float(tuple(float(p0[t]) + v[t] for t in range(3)), eps)
    Ge = [(Lq([d*x for x in e])[i] - L0[i])/d for i in range(3)]
    Gf = [(Lq([d*x for x in f])[i] - L0[i])/d for i in range(3)]
    delta = [-a for a in add]
    hf = float(safety)*min(delta[i]/(k*(abs(Ge[i]) + abs(Gf[i]))) for i in range(3))
    h = F(hf).limit_denominator(10**9)
    h = F(int(h*10**9), 10**9)
    pts = []
    for i in range(-k, k+1):
        for j in range(-k, k+1):
            q = tuple(p0[t] + h*(i*e[t] + j*f[t]) for t in range(3))
            pts.append(((i, j), q))
    return pts, h

T3_CORES = {}
def t3_cores():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'PP7_py', 't3_tieglue_cores.txt')
    for line in open(path):
        if line.startswith(('e1_', 'u_')) and ': core ' in line:
            lab, rest = line.split(': core ')
            T3_CORES[lab.strip()] = eval(rest.strip())
    return T3_CORES

def cfg_t3core(p0, eps, label):
    if not T3_CORES: t3_cores()
    Y, m, add = build_Y(p0, eps)
    pts, h = lattice(p0, eps, add, 3)
    core = set(T3_CORES[label])
    sel = [Model(q, eps, name='C%+d%+d' % ij) for ij, q in pts if ij in core]
    return sel + [Y], h

def cfg_t3full(p0, eps, k=3):
    Y, m, add = build_Y(p0, eps)
    pts, h = lattice(p0, eps, add, k)
    return [Model(q, eps, name='C%+d%+d' % ij) for ij, q in pts] + [Y], h

# ---------------------------------------------------------------- PP7 t1 (pairs and pumps)
def tiny_cone_where(p0, eps, pred, target, avoid=()):
    cells = base_cells(p0, eps, extra=[n for r in avoid for n in facet_planes(r)])
    good = [c for c in cells if pred(interior(c)) and not any(in_cone(interior(c), r) or in_cone(neg(interior(c)), r) for r in avoid)]
    c = max(good, key=lambda c: mass_float(largest_triangle(c)))
    return cone_with_mass(c, target)

def cfg_t1(p0, eps):
    Y, m, add = build_Y(p0, eps)
    S = [r for r, _ in Y.ov]
    tau = 0.02*m[0]/2
    C0 = Model(p0, eps, name='C_p0')
    W = tiny_cone_where(p0, eps, lambda g: cls(g) == 'U', tau, avoid=S)
    Xc = Y.with_ov([(W, 'C')], name='Xc')
    U2 = tiny_cone_where(p0, eps, lambda g: cls(g) == 'U' and not in_cone(g, W) and not in_cone(neg(g), W), tau, avoid=S + [W])
    Xu = Y.with_ov([(U2, '0')], name='Xu')
    Z, YZ = [], []
    for j in range(3):
        T = tiny_cone_where(p0, eps, lambda g, j=j: cls(g) == j and sel_advice(p0, g, eps) == '0', tau, avoid=S)
        adv = adv_from_label(interior(list(T)), 'B')
        Z.append(C0.with_ov([(T, adv)], name='Z%d' % (j+1)))
        YZ.append(Y.with_ov([(T, adv)], name='YZ%d' % (j+1)))
    return [C0, Y, Xc, Xu] + Z + YZ

# ---------------------------------------------------------------- PP7 t6 (mixed small cores)
def scaled_Y(Y, p0, eps, ws, t):
    ov = []
    for rays, a in Y.ov:
        if cls(interior(list(rays))) in ws:
            target = t*mass_float(rays)
            lo, hi = F(0), F(1)
            for _ in range(30):
                mid = (lo+hi)/2
                if mass_float(shrunk(rays, mid)) <= target: lo = mid
                else: hi = mid
            ov.append((shrunk(rays, lo), a))
        else: ov.append((rays, a))
    return Model(Y.p, Y.eps, ov, name='Y%s_%s' % (''.join(str(w+1) for w in ws), t))

def cfg_t6(p0, eps, k=1, ts=(F(7, 10), F(11, 20), F(9, 20), F(3, 10))):
    Y, m, add = build_Y(p0, eps)
    pts, h = lattice(p0, eps, add, 3)
    sel = [q for (ij, q) in pts if max(abs(ij[0]), abs(ij[1])) <= k]
    pump = cfg_t1(p0, eps)
    models = [Model(q, eps) for q in sel] + [pump[1], pump[2]] + pump[4:10]
    for ws in ((1, 2), (0, 2)):
        for t in ts: models.append(scaled_Y(Y, p0, eps, ws, t))
    for i, M in enumerate(models):
        M.name = ('C%d' % i) if M.selected else ('%s#%d' % (M.name, i))
    return models

T6_CORES = {
    'e1_3': ['C7', 'C8', 'Xc#10', 'YZ1#14', 'YZ2#15', 'YZ3#16', 'Y23_7/10#17', 'Y13_7/10#21', 'Y13_11/20#22', 'Y13_9/20#23'],
    'e1_1': ['C7', 'C8', 'Xc#10', 'YZ1#14', 'YZ2#15', 'YZ3#16', 'Y23_7/10#17', 'Y13_7/10#21', 'Y13_11/20#22', 'Y13_9/20#23'],
    'u_3':  ['C7', 'C8', 'Y#9', 'YZ1#14', 'YZ2#15', 'Y23_7/10#17', 'Y13_7/10#21', 'Y13_11/20#22'],
    'u_1':  ['C7', 'C8', 'Y#9', 'YZ1#14', 'YZ2#15', 'YZ3#16', 'Y23_7/10#17', 'Y13_11/20#22'],
}
def cfg_t6core(p0, eps, label):
    ms = cfg_t6(p0, eps)
    want = T6_CORES[label]
    return [M for M in ms if M.name in want]

# ---------------------------------------------------------------- PP5 configurations
PP5_A = (F(9, 10), F(1, 20), F(1, 20)); PP5_B = (F(901, 1000), F(8, 100), F(19, 1000)); PP5_C = (F(902, 1000), F(49, 1000), F(49, 1000))
PP5_Y1 = (F(898, 1000), F(47, 1000), F(55, 1000)); PP5_Y2 = (F(907, 1000), F(44, 1000), F(49, 1000))
PP5_GRID = [(F(95, 100), F(1, 100), F(4, 100)), (F(96, 100), F(3, 100), F(1, 100)), (F(96, 100), F(1, 100), F(3, 100)),
            (F(94, 100), F(1, 100), F(5, 100)), (F(95, 100), F(4, 100), F(1, 100))]

def cfg_pp5_diag():
    eps = F(3, 10)
    pts = [('a', PP5_A), ('b', PP5_B), ('c', PP5_C), ('y1', PP5_Y1), ('y2', PP5_Y2)] + [('g%d' % k, p) for k, p in enumerate(PP5_GRID)]
    return [Model(p, eps, name=n) for n, p in pts]

def _cells_by_label(a, q, eps):
    cells = arrangement(dedup_planes(normals(a, eps) + normals(q, eps) + DIAG))
    out = {}
    for c in cells:
        g = interior(c)
        if dot(g, (1, 1, 1)) <= 0: continue          # one representative of each antipodal pair
        if cls(g) == 'U': continue
        la = label(g, sel_advice(a, g, eps)); lq = label(g, sel_advice(q, g, eps))
        out.setdefault((cls(g), la, lq), []).append(c)
    return out

def _carve(cells_, target):
    """one exact simplicial sub-cone (of the cell with the largest fan triangle) with mass ~ target."""
    c = max(cells_, key=lambda c: mass_float(largest_triangle(c)))
    return cone_with_mass(c, target/2)               # cone mass = half the problem mass

def pump_q(a, eps, world=0):
    """a nearby q such that C_q says A while C_a is silent on lines of every class, and both are silent on
    some lines of class M_world (PP5 t7 geometry; PP5's own q at its own a and eps)."""
    if a == PP5_A and eps == F(3, 10) and world == 0: return (F(901, 1000), F(51, 1000), F(48, 1000))
    for h in (F(1, 1000), F(1, 300), F(1, 100)):
        for ang in range(0, 360, 10):
            v = (math.cos(math.radians(ang)), math.sin(math.radians(ang)))
            d = (v[0], -v[0]/2 + v[1]*math.sqrt(3)/2, -v[0]/2 - v[1]*math.sqrt(3)/2)
            q = tuple(a[t] + h*F(d[t]).limit_denominator(1000) for t in range(3))
            if min(q) <= 0: continue
            lab = _cells_by_label(a, q, eps)
            if all((w, 'S', 'A') in lab for w in range(3)) and (world, 'S', 'S') in lab:
                return q
    return None

def cfg_pp5_pump(a, eps, s=F(3, 4), world=0, tcell=0):
    """PP5 t7: Y = C_a with A on S_1,S_2,S_3 (masses m, s m, s m with the lead class = world; C_a silent, C_q says A
    there); Z = C_a with B on T in class M_world (both silent there; a strict pointwise world improvement of C_a).
    tcell selects which (world,S,S) cell carries T (cells sorted by size, largest first)."""
    q = pump_q(a, eps, world)
    if q is None: return None, None
    lab = _cells_by_label(a, q, eps)
    avail = {w: max(mass_float(largest_triangle(c)) for c in lab[(w, 'S', 'A')]) for w in range(3)}
    m1 = 0.9*min(avail[world], min(avail[w] for w in range(3) if w != world)/float(s))*2
    ov = []
    for w in range(3):
        t = _carve(lab[(w, 'S', 'A')], m1 if w == world else float(s)*m1)
        ov.append((t, adv_from_label(interior(list(t)), 'A')))
    Ca = Model(a, eps, name='C_a'); Cq = Model(q, eps, name='C_q')
    Y = Model(a, eps, ov, name='Ypump')
    tc = sorted(lab[(world, 'S', 'S')], key=lambda c: -mass_float(largest_triangle(c)))
    if tcell >= len(tc): return None, None
    T = cone_with_mass(tc[tcell], 0.05*float(s)*m1/2)
    Z = Model(a, eps, [(T, adv_from_label(interior(list(T)), 'B'))], name='Zpump')
    return [Ca, Cq, Y, Z], q
