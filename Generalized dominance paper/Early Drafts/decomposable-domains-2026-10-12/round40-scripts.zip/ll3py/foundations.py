# LL3 Part A: exact checks.
#  (1) audit's five-model certificate (n=4, q=3, eta=1/16): every ordered pair, TC on all triples, all strict cycles;
#  (2) Nakamura numbers of q-quota games = ceil(n/(n-q)) (n <= 8) and of some weighted games;
#  (3) explicit realisations: nontrivial ties when the game is not proper, a forbidden triangle when nu <= 3,
#      strict k-cycles for every nu <= k <= nu+2, for several games and margins.
# Run: python3 -I foundations.py > foundations.out
from fractions import Fraction as F
import itertools, math
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from quorum import World, CellModels, quota, weighted, nakamura, is_proper, theta_of

ok_all = True
def check(cond, msg):
    global ok_all
    if not cond:
        ok_all = False
        print("FAIL:", msg)

# ---------------------------------------------------------------- (1) audit certificate
print("== (1) audit five-model certificate, n=4, q=3, eta=1/16 ==")
W4 = World(4, quota(4, 3), F(1, 16))
G = [1, 6, 6, 6]; H = [2, 1, 7, 7]; J = [3, 2, 1, 8]
cells = {'F': (F(1), (4, 4, 4, 4)), 'E': (F(1), (1, 1, 1, 1)),
         'G': (F(1), tuple(G)), 'H': (F(1), tuple(H)), 'J': (F(1), tuple(J))}
CM = CellModels(W4, cells)
mods = {'A0': frozenset('FE'), 'A1': frozenset('G'), 'A2': frozenset('H'), 'A3': frozenset('J'), 'A4': frozenset('F')}
names = list(mods)
for v in range(4):
    print("  judge", v + 1, "losses", [CM.L(mods[m], v) for m in names])
R = {(x, y): CM.R(mods[x], mods[y]) for x in names for y in names}
for x, y in zip(names, names[1:] + names[:1]):
    s = CM.supporters(mods[x], mods[y]); sr = CM.supporters(mods[y], mods[x])
    print(f"  {x} R {y}: supporters {[v+1 for v in s]}; reverse supporters {[v+1 for v in sr]}")
    check(R[(x, y)] and not R[(y, x)], f"edge {x}->{y} not strictly accepted")
ties = [(x, y) for x in names for y in names if x < y and R[(x, y)] and R[(y, x)]]
print("  nontrivial ties:", ties); check(not ties, "tie")
viol = [(x, y, z) for x in names for y in names for z in names
        if R[(x, y)] and R[(y, z)] and R[(z, x)] and not R[(x, z)]]
print("  TC violations (X R Y, Y R Z, Z strictly R X) among the five models:", viol); check(not viol, "TC")
# all strict simple cycles
strict = {(x, y) for x in names for y in names if x != y and R[(x, y)] and not R[(y, x)]}
cyc = []
for k in range(2, 6):
    for perm in itertools.permutations(names, k):
        if perm[0] != min(perm): continue
        if all((perm[t], perm[(t + 1) % k]) in strict for t in range(k)):
            cyc.append(perm)
print("  strict simple cycles:", cyc)
print("  accepted non-identity comparisons:", sorted((x, y) for (x, y) in R if R[(x, y)] and x != y))

# ---------------------------------------------------------------- (2) Nakamura numbers
print("\n== (2) Nakamura numbers ==")
for n in range(2, 9):
    for q in range(1, n + 1):
        nu, fam = nakamura(n, quota(n, q))
        pred = None if q == n else math.ceil(n / (n - q))
        check(nu == pred, f"nakamura n={n} q={q}: {nu} vs {pred}")
        check(is_proper(n, quota(n, q)) == (2 * q > n), f"proper n={n},q={q}")
        check((nu is None or nu >= 4) == (3 * q > 2 * n), f"TC-iff n={n} q={q}")
print("  q-quota: nu = ceil(n/(n-q)) (q<n), collegial (q=n); proper iff 2q>n; nu>=4 iff 3q>2n: checked n<=8")
WG = [((3, 2, 2, 1, 1), 6), ((2, 1, 1, 1), 4), ((2, 1, 1, 1), 3), ((3, 1, 1, 1, 1), 5), ((1, 1, 1, 1, 1, 1, 1), 5),
      ((4, 3, 2, 1), 7), ((5, 2, 2, 1, 1), 7)]
for wts, tau in WG:
    nu, fam = nakamura(len(wts), weighted(wts, tau))
    print(f"  weights {wts}, threshold {tau}: proper={is_proper(len(wts), weighted(wts, tau))}, nu={nu}",
          "family", [sorted(S) for S in fam] if fam else "-")

# ---------------------------------------------------------------- (3) realisations
print("\n== (3) realisations (Condorcet-type cell constructions) ==")
def condorcet(n, win, eta, k, fam):
    """k models Y_0..Y_{k-1}, Y_m errs only on cell m; fam = k winning coalitions with empty intersection.
    judge v opposes edge j(v) (some j with v not in fam[j]) and has cyclic order starting at Y_{j(v)+1};
    masses are powers of r = 1/theta along its order."""
    th = min(theta_of(F(e)) for e in ([eta] * n if not isinstance(eta, list) else eta))
    r = 1 / th
    jv = [min(j for j in range(k) if v not in fam[j]) for v in range(n)]
    z = {}
    for m in range(k):
        z[m] = tuple(r ** ((m - jv[v] - 1) % k) for v in range(n))
    cells = {m: (F(1), z[m]) for m in range(k)}
    CMk = CellModels(World(n, win, eta), cells)
    Y = [frozenset([m]) for m in range(k)]
    edges = all(CMk.R(Y[m], Y[(m + 1) % k]) and not CMk.R(Y[(m + 1) % k], Y[m]) for m in range(k))
    return edges

cases = [(4, 3, F(1, 16)), (4, 3, F(1, 2)), (5, 4, F(1, 3)), (7, 5, F(1, 10)), (6, 5, F(9, 10)), (8, 7, F(1, 5))]
for n, q, eta in cases:
    win = quota(n, q); nu, fam = nakamura(n, win)
    res = []
    for k in range(nu, nu + 3):
        famk = list(fam) + [fam[0]] * (k - nu)
        res.append((k, condorcet(n, win, eta, k, famk)))
    print(f"  n={n} q={q} eta={eta}: nu={nu}; strict k-cycles realised:", res)
    check(all(b for _, b in res), f"cycle realisation n={n},q={q}")
for wts, tau in WG:
    n = len(wts); win = weighted(wts, tau)
    if not is_proper(n, win): continue
    nu, fam = nakamura(n, win)
    if nu is None: continue
    res = [(k, condorcet(n, win, F(1, 7), k, list(fam) + [fam[0]] * (k - nu))) for k in range(nu, nu + 2)]
    print(f"  weights {wts} tau={tau}: nu={nu}; strict k-cycles realised:", res)
    check(all(b for _, b in res), f"weighted cycle {wts}")

# nontrivial tie when not proper: S, S^c both winning; X errs on cell a, Y on cell b
def tie_example(n, win, eta):
    allS = [frozenset(S) for r in range(n + 1) for S in itertools.combinations(range(n), r)]
    S = next(S for S in allS if win(S) and win(frozenset(range(n)) - S))
    th = theta_of(F(eta)); r = 1 / th
    cells = {'a': (F(1), tuple(F(1) if v in S else r for v in range(n))),
             'b': (F(1), tuple(r if v in S else F(1) for v in range(n)))}
    CMt = CellModels(World(n, win, eta), cells)
    X, Y = frozenset('a'), frozenset('b')
    return CMt.R(X, Y) and CMt.R(Y, X)
for n, q in [(4, 2), (6, 3), (5, 2)]:
    b = tie_example(n, quota(n, q), F(1, 4)); print(f"  not proper n={n}, q={q}: nontrivial tie realised: {b}")
    check(b, "tie example")

# forbidden triangle when nu <= 3: three winning coalitions S1,S2,S3 with empty intersection and S1&S2 losing
def triangle_example(n, win, eta):
    allS = [frozenset(S) for r in range(n + 1) for S in itertools.combinations(range(n), r)]
    Wn = [S for S in allS if win(S)]
    for S1, S2, S3 in itertools.product(Wn, repeat=3):
        if S1 & S2 & S3 or win(S1 & S2): continue
        th = theta_of(F(eta)); r = 1 / th
        # judge orders: in S1&S2: X<Y<Z ; S2&S3: Y<Z<X ; S3&S1: Z<X<Y ; S1 only: X<Y, X=Z ; S2 only: Y<Z, Y=X;
        # S3 only: Z<X, Z=Y ; none: all equal.  masses (mX, mY, mZ) of the error cells of X, Y, Z.
        ms = []
        for v in range(n):
            a, b, c = v in S1, v in S2, v in S3
            if a and b: m = (1, r, r * r)
            elif b and c: m = (r * r, 1, r)
            elif c and a: m = (r, r * r, 1)
            elif a: m = (1, r, 1)
            elif b: m = (1, 1, r)
            elif c: m = (r, 1, 1)
            else: m = (1, 1, 1)
            ms.append(tuple(F(x) for x in m))
        cells = {'x': (F(1), tuple(m[0] for m in ms)), 'y': (F(1), tuple(m[1] for m in ms)),
                 'z': (F(1), tuple(m[2] for m in ms))}
        CMt = CellModels(World(n, win, eta), cells)
        X, Y, Z = frozenset('x'), frozenset('y'), frozenset('z')
        return (CMt.R(X, Y) and CMt.R(Y, Z) and CMt.R(Z, X) and not CMt.R(X, Z)), (sorted(S1), sorted(S2), sorted(S3))
    return None, None
for n, q in [(3, 2), (6, 4), (5, 3), (4, 2), (9, 6)]:
    b, fam = triangle_example(n, quota(n, q), F(1, 5))
    print(f"  n={n}, q={q} (3q<=2n): forbidden triangle realised: {b} via {fam}")
    check(b, "triangle example")

print("\nALL CHECKS PASSED" if ok_all else "\nSOME CHECK FAILED")
