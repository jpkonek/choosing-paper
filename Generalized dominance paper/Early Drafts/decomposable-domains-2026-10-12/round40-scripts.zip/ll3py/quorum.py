# LL3: exact quorum-world bookkeeping on finitely many cells (two-level records: good <-> silence at one world).
# A "cell" carries a judge-type vector z (judge v's increment density is proportional to z_v there) and a mass.
# A model is described by its error cells (silence where good advice is available); the loss of judge v is
# L_v(X) = sum_{c in E(X)} mass(c) * z_c[v]; d_v(X,Y) = sum over the symmetric difference.
from fractions import Fraction as F
import itertools

def theta_of(eta):
    return (1 - eta) / (1 + eta)

class World:
    def __init__(self, n, winning, eta):
        """winning: predicate on frozensets of judges (monotone).  eta: common margin, or a list per judge."""
        self.n = n
        self.win = winning
        self.eta = eta if isinstance(eta, (list, tuple)) else [eta] * n

    def supporters_masses(self, I, W):
        """judges supporting a record with improvement masses I[v] and worsening masses W[v]."""
        return frozenset(v for v in range(self.n) if W[v] - I[v] >= self.eta[v] * (W[v] + I[v]))

    def accepts_masses(self, I, W):
        return self.win(self.supporters_masses(I, W))

class CellModels:
    """models given by error-cell sets over a list of cells (mass, type)."""
    def __init__(self, world, cells):
        self.w = world
        self.cells = cells       # name -> (mass, z) with z a tuple of length n

    def L(self, E, v):
        return sum(self.cells[c][0] * self.cells[c][1][v] for c in E)

    def masses(self, EX, EY):
        """record X -> Y: improvement where Y removes an error of X, worsening where Y adds one."""
        imp = EX - EY
        wor = EY - EX
        I = [self.L(imp, v) for v in range(self.w.n)]
        W = [self.L(wor, v) for v in range(self.w.n)]
        return I, W

    def R(self, EX, EY):
        """X R Y (X no worse than Y)."""
        if EX == EY:
            return True
        I, W = self.masses(EX, EY)
        return self.w.accepts_masses(I, W)

    def supporters(self, EX, EY):
        I, W = self.masses(EX, EY)
        return sorted(self.w.supporters_masses(I, W))

def quota(n, q):
    return lambda S: len(S) >= q

def weighted(wts, tau):
    return lambda S: sum(wts[v] for v in S) >= tau

def nakamura(n, win):
    """least k such that some k winning coalitions have empty intersection (None if collegial)."""
    allS = [frozenset(S) for r in range(n + 1) for S in itertools.combinations(range(n), r)]
    W = [S for S in allS if win(S)]
    # minimal winning suffices
    Wmin = [S for S in W if not any(T < S for T in W)]
    full = frozenset(range(n))
    for k in range(1, n + 2):
        for fam in itertools.combinations_with_replacement(Wmin, k):
            inter = full
            for S in fam:
                inter = inter & S
            if not inter:
                return k, fam
    return None, None

def is_proper(n, win):
    allS = [frozenset(S) for r in range(n + 1) for S in itertools.combinations(range(n), r)]
    return not any(win(S) and win(frozenset(range(n)) - S) for S in allS)
