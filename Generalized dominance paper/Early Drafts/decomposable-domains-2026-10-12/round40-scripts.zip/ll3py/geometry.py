# LL3: exact geometry of two crossing selected models of the plain posterior family near T1.
# C_p = D_{K_p} = {g : p (.) g in D_{T1}}  (FF1 §1; EE2 Prop 2.3a), so on mixed g:
#   C_p accepts g  iff  phi_p(g) := c0 * sum_j p_j g_j + eps * min_j p_j g_j > 0.
# For models A = C_pA, B = C_pB and a world i we exhibit rational problems g with
#   R_AB(i): g_i > 0, A accepts g, B silent on {g,-g}   (A good at world i, B silent)
#   R_BA(i): g_i > 0, B accepts g, A silent              (B good, A silent)
# together with an explicit sup-norm radius r such that every h with |h-g|_inf < r has the same classes, the same
# sign pattern and no zero coordinate.  (phi_p is 1-Lipschitz for |.|_inf because c0*sum p + eps*max p <= 1.)
# Construction: x on the relative interior of a facet F_k of D_{T1} (v_k.x = 0), pushed slightly out of D_{T1};
# g = x / p_B is then outside cl C_B and -g outside C_B, while p_A (.) g = (p_A/p_B) (.) x may lie inside D_{T1}.
# Run: python3 -I geometry.py > geometry.out
from fractions import Fraction as F
import itertools

def setup(eps):
    c0 = (1 - eps) / 3
    V = [tuple(c0 + (eps if j == k else 0) for j in range(3)) for k in range(3)]
    return c0, V

def phi(p, g, c0, eps):
    w = [p[j] * g[j] for j in range(3)]
    return c0 * sum(w) + eps * min(w)

def classes(p, g, c0, eps):
    a, b = phi(p, g, c0, eps), phi(p, tuple(-x for x in g), c0, eps)
    if a > 0 and b < 0: return '+', min(a, -b)
    if b > 0 and a < 0: return '-', min(b, -a)
    if a < 0 and b < 0: return '0', min(-a, -b)
    return '?', F(0)

def dot(a, b): return sum(x * y for x, y in zip(a, b))
def crossv(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])

def find(pA, pB, i, eps, want, grid=40):
    """want = 'AB' (A good, B silent) or 'BA'.  Search facet points; return (g, radius) with the largest radius."""
    c0, V = setup(eps)
    first, second = (pA, pB) if want == 'AB' else (pB, pA)   # 'first' accepts, 'second' silent
    best = None
    for k in range(3):
        others = [j for j in range(3) if j != k]
        rays = [crossv(V[k], V[j]) for j in others]
        # orient each corner ray so that it lies in cl D_{T1}: v_l . r >= 0 for all l
        rays = [r if all(dot(V[l], r) >= 0 for l in range(3)) else tuple(-x for x in r) for r in rays]
        for t in range(1, grid):
            a = F(t, grid)
            x = tuple(a * rays[0][j] + (1 - a) * rays[1][j] for j in range(3))
            for s in [F(1, 10**e) for e in (2, 3, 4, 5, 6, 7, 8)]:
                xo = tuple(x[j] - s * V[k][j] for j in range(3))       # pushed outside along -v_k
                g = tuple(xo[j] / second[j] for j in range(3))
                if g[i] <= 0:
                    # use the other orientation of the pair
                    g = tuple(-y for y in g)
                if g[i] <= 0: continue
                c1, m1 = classes(first, g, c0, eps)
                c2, m2 = classes(second, g, c0, eps)
                if c1 == '+' and c2 == '0':
                    r = min(m1, m2, min(abs(y) for y in g)) / 2
                    if best is None or r / max(abs(y) for y in g) > best[1] / max(abs(y) for y in best[0]):
                        best = (g, r)
    return best

def verify(pA, pB, i, eps, g, r, want):
    """re-verify the point and the radius: corners of the sup-norm box give the extreme values of each phi,
    because phi_p is concave piecewise linear: its minimum over the box is attained at a vertex, and its maximum
    is bounded by phi(g) + r.  We check: on all 8 box corners the strict inequalities hold, and the Lipschitz bound."""
    c0, V = setup(eps)
    first, second = (pA, pB) if want == 'AB' else (pB, pA)
    ok = g[i] > 0 and min(abs(y) for y in g) > r
    # Lipschitz bound (1-Lipschitz in sup norm) gives the strict inequalities on the open box from the margins
    c1, m1 = classes(first, g, c0, eps); c2, m2 = classes(second, g, c0, eps)
    ok = ok and c1 == '+' and c2 == '0' and m1 > r and m2 > r
    for sgn in itertools.product((-1, 1), repeat=3):
        h = tuple(g[j] + sgn[j] * r * F(99, 100) for j in range(3))
        ok = ok and classes(first, h, c0, eps)[0] == '+' and classes(second, h, c0, eps)[0] == '0' and h[i] > 0
    return ok

if __name__ == '__main__':
    allok = True
    for eps in (F(3, 10), F(1, 2), F(1, 20)):
        u = (F(1, 3),) * 3
        for d in (F(1, 300), F(1, 30000), F(1, 3 * 10**6)):
            pA = (u[0] + 2 * d, u[1] - d, u[2] - d)
            pB = (u[0] - d, u[1] + 2 * d, u[2] - d)
            for i in range(3):
                for want in ('AB', 'BA'):
                    res = find(pA, pB, i, eps, want)
                    if res is None:
                        print(f"eps={eps} d={d} world {i+1} {want}: NOT FOUND"); allok = False; continue
                    g, r = res
                    ok = verify(pA, pB, i, eps, g, r, want)
                    allok &= ok
                    if d == F(1, 300) or i == 0:
                        print(f"eps={eps} pA={tuple(map(str,pA))} pB={tuple(map(str,pB))} world {i+1} R_{want}: "
                              f"g={tuple(map(str,g))} radius={r} verified={ok}")
    print("ALL VERIFIED" if allok else "SOME FAILURE")
