# LL3 Part B: exact checks.
#  (B1) the 8-record certificate out of two coherent (plain-posterior) models A, B at world 1, n=4, q=3,
#       eta=1/16, judge increments of ratio <= M = 2: every record accepted, pointwise net improvement;
#  (B2) the same certificate shape for eta=1/2 with M = 8 (> M* = 7);
#  (B3) the threshold M*(n,q,eta) = 1 + 2 q eta / ((n-q)(1-eta)):
#       at M = M* the symmetric dual family y^S = 1_S satisfies theta*max_S y^S.z <= min_S y^S.z on every
#       extreme ray z of K_M (so the bottom-q field endorses every comparison);  at M = M*(1+1/1000) the
#       symmetric primal certificate (records R_A, |A| = n-q) is valid;
#  (B4) a strict 4-cycle in the M = 2, eta = 1/16 certificate world (types z_w and the background type 1).
# Run: python3 -I certificate.py > certificate.out
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
import itertools, math
from quorum import World, CellModels, quota, theta_of
import geometry

ok_all = True
def check(c, msg):
    global ok_all
    if not c:
        ok_all = False; print("FAIL:", msg)

def zvec(n, A, M):
    return tuple(M if v in A else F(1) for v in range(n))

def record_masses(rec, pieces, n):
    """rec: piece -> (from_rank, to_rank).  improvement/worsening masses per judge."""
    I = [F(0)] * n; W = [F(0)] * n
    for p, (r0, r1) in rec.items():
        m, z = pieces[p]
        for v in range(n):
            if r1 < r0: I[v] += m * z[v] * (r0 - r1)
            elif r1 > r0: W[v] += m * z[v] * (r1 - r0)
    return I, W

def build_two_model_certificate(n, q, eta, M, a, b):
    """symmetric certificate, doubled over the two crossing regions R_AB, R_BA.
    types: z_D for (n-q)-subsets D.  Type-level record R_D: improve mass a on z_D, worsen mass b on every z_B
    with B disjoint from D.  A-copy: improvement in R_BA (A silent -> good), worsening in R_AB (A good -> silent);
    B-copy symmetric.  Pieces: in region X in {AB, BA} and type D, one piece Q[X,D,D'] of mass b for every record
    D' (disjoint from D) worsening there, and one remainder piece of mass a - (#D') b."""
    Ds = [frozenset(D) for D in itertools.combinations(range(n), n - q)]
    pieces = {}; recs = {}
    # rank of A and B on the regions at world i: R_AB: A good(0), B silent(1); R_BA: A silent(1), B good(0)
    base_rank = {('A', 'AB'): 0, ('B', 'AB'): 1, ('A', 'BA'): 1, ('B', 'BA'): 0}
    for X in ('AB', 'BA'):
        for D in Ds:
            worseners = [D2 for D2 in Ds if not (D2 & D)]
            for D2 in worseners:
                pieces[(X, D, 'Q', D2)] = (b, zvec(n, D, M))
            pieces[(X, D, 'rest')] = (a - len(worseners) * b, zvec(n, D, M))
            check(a - len(worseners) * b > 0, "remainder mass positive")
    for model, impX, worX in (('A', 'BA', 'AB'), ('B', 'AB', 'BA')):
        for D in Ds:
            rec = {}
            # improvement: all of the type-D pieces in impX (mass a in total)
            for key in pieces:
                if key[0] == impX and key[1] == D:
                    rec[key] = (base_rank[(model, impX)], 1 - base_rank[(model, impX)])
            # worsening: the piece Q[worX, D2, D] for each type D2 disjoint from D
            for D2 in Ds:
                if not (D2 & D):
                    key = (worX, D2, 'Q', D)
                    rec[key] = (base_rank[(model, worX)], 1 - base_rank[(model, worX)])
            # consistency: improvement goes 1 -> 0, worsening 0 -> 1, from the base model's own advice
            for key, (r0, r1) in rec.items():
                check(r0 == base_rank[(model, key[0])], "record starts at the base model's advice")
            recs[(model, D)] = rec
    return pieces, recs, Ds

def verify_certificate(n, q, eta, M, a, b, verbose=False):
    pieces, recs, Ds = build_two_model_certificate(n, q, eta, M, a, b)
    Wd = World(n, quota(n, q), eta)
    allacc = True
    for key, rec in recs.items():
        I, W = record_masses(rec, pieces, n)
        S = Wd.supporters_masses(I, W)
        acc = Wd.win(S)
        allacc &= acc
        if verbose:
            print(f"   record out of {key[0]}, dissenter set {sorted(key[1])}: supporters {sorted(S)} accepted={acc}"
                  f"  I={[str(x) for x in I]} W={[str(x) for x in W]}")
    # pointwise net: on each piece, sum over records of (to - from) (all moves are between ranks 0 and 1)
    net = {p: 0 for p in pieces}
    for rec in recs.values():
        for p, (r0, r1) in rec.items():
            net[p] += (r1 - r0)
    worsening_free = all(x <= 0 for x in net.values())
    strict = any(x < 0 for x in net.values())
    # each piece is touched at most once by an improving and at most once by a worsening move
    return allacc, worsening_free, strict, len(recs), pieces, recs, net

print("== (B1) n=4, q=3, eta=1/16, M=2, a=13/4, b=1 ==")
th = theta_of(F(1, 16))
print("   theta =", th, "; M* =", 1 + F(2 * 3, 1) * F(1, 16) / ((4 - 3) * (1 - F(1, 16))))
acc, wf, st, nr, pieces, recs, net = verify_certificate(4, 3, F(1, 16), F(2), F(13, 4), F(1), verbose=True)
print(f"   {nr} records; all accepted: {acc}; pointwise worsening-free: {wf}; strict improvement somewhere: {st}")
print("   net improvement pieces:", sorted(((p[0], tuple(sorted(p[1]))), str(pieces[p][0])) for p in net if net[p] < 0))
check(acc and wf and st, "B1")
# geometric realisation of the two regions at world 1 (eps = 3/10, models near u)
eps = F(3, 10); d = F(1, 300); u = F(1, 3)
pA = (u + 2 * d, u - d, u - d); pB = (u - d, u + 2 * d, u - d)
for want in ('AB', 'BA'):
    g, r = geometry.find(pA, pB, 0, eps, want)
    okg = geometry.verify(pA, pB, 0, eps, g, r, want)
    print(f"   world 1 region R_{want}: open box centre {tuple(map(str, g))}, sup-radius {r}: verified {okg}")
    check(okg, "geometry")

print("\n== (B2) n=4, q=3, eta=1/2, M=8 (M*=7), a=16/5, b=1 ==")
acc, wf, st, nr, *_ = verify_certificate(4, 3, F(1, 2), F(8), F(16, 5), F(1))
print(f"   {nr} records; all accepted: {acc}; worsening-free: {wf}; strict: {st}"); check(acc and wf and st, "B2")

print("\n== (B3) threshold M* = 1 + 2 q eta / ((n-q)(1-eta)) ==")
def Mstar(n, q, eta): return 1 + F(2 * q) * eta / ((n - q) * (1 - eta))
def dual_ok(n, q, eta, M):
    thv = theta_of(eta)
    Ss = [frozenset(S) for S in itertools.combinations(range(n), q)]
    for r in range(1, n):
        for A in itertools.combinations(range(n), r):
            z = zvec(n, frozenset(A), M)
            vals = [sum(z[v] for v in S) for S in Ss]
            if thv * max(vals) > min(vals): return False
    return True
for n, q in [(3, 2), (4, 3), (5, 3), (5, 4), (6, 4), (6, 5), (7, 4), (7, 5), (7, 6)]:
    for eta in (F(1, 16), F(1, 3), F(1, 2), F(9, 10)):
        Ms = Mstar(n, q, eta)
        d_at = dual_ok(n, q, eta, Ms)
        d_above = dual_ok(n, q, eta, Ms * F(1001, 1000))
        # symmetric primal certificate just above M*
        M = Ms * F(1001, 1000); thv = theta_of(eta)
        Np = math.comb(q, n - q); Cq = math.comb(q - 1, n - q - 1)
        upper = thv * (Np + (M - 1) * Cq)     # a <= upper * b for supporters
        b = F(1); a = (Np + upper) / 2
        acc, wf, st, nr, *_ = verify_certificate(n, q, eta, M, a, b)
        print(f"   n={n} q={q} eta={eta}: M*={Ms}; dual at M*: {d_at}; dual above: {d_above}; "
              f"primal certificate above ({nr} records): {acc and wf and st}")
        check(d_at and not d_above and acc and wf and st, f"threshold n={n} q={q} eta={eta}")

print("\n== (B4) strict 4-cycle in the (B1) world: types z_w (M=2) and background 1, eta=1/16 ==")
n = 4; M = F(2); eta = F(1, 16); thv = theta_of(eta)
# models Y_0..Y_3 with disjoint error sets E_j = sum_w c[j][w] * (type z_w piece) + c0[j] * (type 1 piece)
# judge v's loss on Y_j = s + (M-1) c[j][v], s = sum_w c[j][w] + c0[j] = 1;  judge v opposes edge v and ranks
# Y_{v+1} < Y_{v+2} < Y_{v+3} < Y_v with consecutive ratio >= 1/theta.
alpha = [(1 / thv) ** p - 1 for p in range(4)]   # = 0, 2/15, 64/225, 1538/3375 (sum < 1)
check(1 + alpha[1] >= (1 + alpha[0]) / thv and 1 + alpha[2] >= (1 + alpha[1]) / thv and
      1 + alpha[3] >= (1 + alpha[2]) / thv, "geometric ratios")
cells = {}
for j in range(4):
    cs = []
    for w in range(4):
        pos = (j - w - 1) % 4
        cs.append(alpha[pos] / (M - 1))
    c0 = 1 - sum(cs); check(c0 >= 0, "background mass")
    for w in range(4):
        cells[(j, w)] = (cs[w], zvec(4, {w}, M))
    cells[(j, 'bg')] = (c0, (F(1),) * 4)
CM = CellModels(World(4, quota(4, 3), eta), cells)
Y = [frozenset(k for k in cells if k[0] == j) for j in range(4)]
for v in range(4):
    print("   judge", v + 1, "losses", [str(CM.L(Y[j], v)) for j in range(4)])
cyc = all(CM.R(Y[j], Y[(j + 1) % 4]) and not CM.R(Y[(j + 1) % 4], Y[j]) for j in range(4))
print("   strict 4-cycle Y0 R Y1 R Y2 R Y3 R Y0:", cyc,
      [(j, [v + 1 for v in CM.supporters(Y[j], Y[(j + 1) % 4])]) for j in range(4)])
check(cyc, "4-cycle")
print("   (no strict 3-cycle exists in any (4,3) quorum world: PROVED, TC)")

print("\nALL CHECKS PASSED" if ok_all else "\nSOME CHECK FAILED")
