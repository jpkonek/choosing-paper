# LL2 Section 7: exact condition under which the SUM of the judges endorses every accepted comparison,
# for judges whose pointwise change magnitudes have mutual ratio <= M.
# Condition (Prop 7.1):  2 q eta + (n-q) [ (1+eta)/M - (1-eta) M ] >= 0.
from fractions import Fraction as F
import random, itertools
random.seed(7)

def cond(n, q, eta, M):
    return 2*q*eta + (n-q)*((1+eta)/M - (1-eta)*M)

def worst_case(n, q, eta, M, W=F(1)):
    th = (1-eta)/(1+eta)
    I = th*W                                   # supporters at the boundary of support
    sup = [(W, I)]*q                           # (worsened mass, improved mass)
    non = [(W/M, M*I)]*(n-q)                   # ratio 1/M on the worsening set, M on the improving set
    votes = [Wv - Iv >= eta*(Wv + Iv) for Wv, Iv in sup + non]
    total = sum(Wv - Iv for Wv, Iv in sup + non)
    return sum(votes), total

n, q = 4, 3
for eta in [F(1,16), F(1,4), F(1,2)]:
    # bracket the threshold M* by rationals
    lo, hi = F(1), F(100)
    for _ in range(60):
        mid = (lo+hi)/2
        if cond(n, q, eta, mid) >= 0: lo = mid
        else: hi = mid
    Mbelow, Mabove = lo, hi
    v1, t1 = worst_case(n, q, eta, Mabove)
    v0, t0 = worst_case(n, q, eta, Mbelow)
    print(f"eta={eta}: M* in [{float(Mbelow):.6f},{float(Mabove):.6f}]; "
          f"worst case at M just above: votes={v1} (accepted iff >=3), sum-field change={float(t1):.3e}; "
          f"at M just below: sum-field change={float(t0):.3e}")
    # random finite records respecting the ratio bound M = Mbelow: sum field never negative on accepted ones
    M = Mbelow; viol = 0; acc = 0
    for _ in range(3000):
        cells = random.randint(1, 6)
        base = [F(random.randint(1, 100), random.randint(1, 20)) for _ in range(cells)]
        sgn  = [random.choice([-1, 1]) for _ in range(cells)]
        mass = [F(random.randint(1, 50), 7) for _ in range(cells)]
        judges = []
        for v in range(n):
            # magnitudes within ratio M of the base, hence pairwise within M^2; use sqrt-free scheme:
            # factor in [1, M] so that pairwise ratios are <= M
            fac = [1 + (M-1)*F(random.randint(0, 100), 100) for _ in range(cells)]
            judges.append([b*f for b, f in zip(base, fac)])
        N = [sum(m*s*x for m, s, x in zip(mass, sgn, xs)) for xs in judges]
        G = [sum(m*x for m, x in zip(mass, xs)) for xs in judges]
        votes = sum(1 for a, g in zip(N, G) if a >= eta*g)
        if votes >= q:
            acc += 1
            if sum(N) < 0: viol += 1
    print(f"   random records with ratio <= M*: accepted={acc}, accepted with negative sum-field change={viol}")
