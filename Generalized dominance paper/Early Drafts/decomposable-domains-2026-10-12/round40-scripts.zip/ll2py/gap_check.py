# LL2: exact checks of the gap inequalities (Lemmas 3.1, 3.2) and their sharpness.
# All arithmetic in Fractions.
from fractions import Fraction as F
import random, itertools
random.seed(20261018)

def rnd(lo=1, hi=1000):
    return F(random.randint(lo, hi), random.randint(1, 50))

print("== Part A: Lemma 3.1 (every world has margin eta) ==")
for eta in [F(1,16), F(1,4), F(1,2), F(9,10)]:
    kappa = (1+eta)/(1-eta)
    bad = 0
    for trial in range(4000):
        m = random.randint(1, 12)              # number of (world, judge) terms
        alpha = [rnd() for _ in range(m)]
        # alpha' with componentwise ratio strictly inside (1/kappa, kappa)
        alphap = []
        for a in alpha:
            r = F(1)/kappa + (kappa - F(1)/kappa) * F(random.randint(1, 999), 1000)
            alphap.append(a*r)
        D = [rnd(1, 10**6) * random.choice([-1, 1]) for _ in range(m)]
        lhs = sum((a-b)*d for a, b, d in zip(alpha, alphap, D))
        rhs = eta*sum((a+b)*abs(d) for a, b, d in zip(alpha, alphap, D))
        # Lemma 3.1 claims lhs < rhs
        if not lhs < rhs:
            bad += 1
    print(f"eta={eta}: kappa={kappa}; 4000 random instances; violations of lhs<rhs: {bad}")

print("\n-- sharpness of kappa (single problem, two worlds, equality in both conditions) --")
for eta in [F(1,16), F(1,4), F(1,2)]:
    kappa = (1+eta)/(1-eta)
    a, b = 1+eta, 1-eta                    # |Delta| at world 1 (C->C' worsens), world 2 (improves)
    al = (F(1), F(1)); alp = (F(1)/kappa, kappa)   # ratios exactly 1/kappa and kappa
    condC  = al[0]*(1-eta)*a - al[1]*(1+eta)*b          # C's distorted condition for switching to C'
    condCp = -alp[0]*(1+eta)*a + alp[1]*(1-eta)*b       # C''s distorted condition for switching back
    print(f"eta={eta}: condC={condC}, condC'={condCp}  (both >= 0: closed ratio interval is not enough)")

print("\n== Part B: Lemma 3.2 (one world free, eta_1 = 0) ==")
def lemma32_violations(eta, rho, trials=3000, worlds=3):
    bad = 0
    for _ in range(trials):
        s = [random.choice([-1, 1]) for _ in range(worlds)]
        A = [rnd(0, 10**4) for _ in range(worlds)]
        if sum(A) == 0: continue
        Ap = [x * (F(1)/rho + (rho-F(1)/rho)*F(random.randint(0,1000),1000)) for x in A]
        et = [F(0)] + [eta]*(worlds-1)
        C  = sum((s[i]-et[i])*A[i]  for i in range(worlds))
        Cp = sum((-s[i]-et[i])*Ap[i] for i in range(worlds))
        if C >= 0 and Cp >= 0:
            bad += 1
    return bad
for eta in [F(1,16), F(1,4), F(1,2)]:
    # choose rho>1 with (rho-1)(rho^2+1) < eta(1+1/rho): take rho = 1 + eta/4
    rho = 1 + eta/4
    ok = (rho-1)*(rho**2+1) < eta*(1+1/rho)
    print(f"eta={eta}, rho={rho}: threshold inequality holds: {ok}; "
          f"random instances with both conditions: {lemma32_violations(eta, rho)}")

print("\n-- exhaustive sign patterns with A' = A (rho = 1), worlds 1 free: both conditions force sum(A)=0 --")
# With A'=A, adding the conditions gives -sum_{i>1} 2 eta A_i >= 0, so A_2=A_3=0, then A_1=0.
for s in itertools.product([-1,1], repeat=3):
    eta = F(1,4)
    # LP-free check: C + C' = -2*eta*(A2+A3) when A'=A
    coeffC  = [s[0]-0, s[1]-eta, s[2]-eta]
    coeffCp = [-s[0]-0, -s[1]-eta, -s[2]-eta]
    tot = [x+y for x, y in zip(coeffC, coeffCp)]
    print(f"signs {s}: coefficients of C+C' = {tot}")

print("\n-- two free worlds: the analogue of Lemma 3.2 fails for every rho>1 --")
eta = F(1,4)
for N in [10, 100, 1000, 10**6]:
    A  = [F(N), F(N), F(1)]
    Ap = [F(N), F(N+2), F(1)]
    s  = [1, -1, 1]
    et = [F(0), F(0), eta]
    C  = sum((s[i]-et[i])*A[i]  for i in range(3))
    Cp = sum((-s[i]-et[i])*Ap[i] for i in range(3))
    rho = max(max(a/b, b/a) for a, b in zip(A, Ap))
    print(f"N={N}: rho={rho} ; C-condition={C} >=0 ; C'-condition={Cp} >=0")
