# LL2 Prop 6.1 illustration: the mirror swap across T1's facet F_1 defeats every judge at every world.
# Exact arithmetic. eps = 3/10. Two-point surrogate of the measure-theoretic swap (equal masses lam at
# h_in = h0 + t v1 and h_out = h0 - t v1); the measure version is Prop 6.1.
from fractions import Fraction as F

eps = F(3,10); c0 = (1-eps)/3; kappa = (1+2*eps)/(1-eps)
v = [[c0 + (eps if j == k else 0) for j in range(3)] for k in range(3)]
dot = lambda a, b: sum(x*y for x, y in zip(a, b))
inD = lambda g: all(dot(vk, g) > 0 for vk in v)        # g in D_T1 (no nonneg nonzero g occurs here)

h0 = [F(-2), kappa, kappa]                              # = r_12 + r_31, relative interior of F_1
print("kappa =", kappa, " h0 =", h0)
print("v_k . h0 =", [dot(vk, h0) for vk in v], "(facet F_1: first is 0, others > 0)")

def rank(h, i, a):          # world-i rank of advice a on pair indexed by h: good 0, silence 1, bad 2, both 3
    if a == 'x': return 3
    if a == '0': return 1
    good = (h[i] > 0) if a == '+' else (h[i] < 0)
    return 0 if good else 2

# four heterogeneous judges per world: ell_iv(h,a) = rho_iv(h) * rank_i(h,a), rho_iv polynomial and > 0
coef = {}
scales = [F(1), F(1000), F(1,1000), F(37,3)]
for i in range(3):
    for vv in range(4):
        w = [F(1+i+vv), F(2*vv-3), F(5-i*vv)]
        coef[(i, vv)] = (scales[vv], F(vv*vv+1, 7), w)
def rho(i, vv, h):
    s, b, w = coef[(i, vv)]
    return s * (1 + b*dot(w, h)**2)

for eta in [F(1,16), F(1,4), F(1,2), F(9,10)]:
    for t in [F(1,10), F(1,1000)]:
        hin  = [x + t*y for x, y in zip(h0, v[0])]
        hout = [x - t*y for x, y in zip(h0, v[0])]
        neg = lambda g: [-x for x in g]
        aC_in  = '+' if inD(hin) and not inD(neg(hin)) else '?'
        aC_out = '0' if (not inD(hout)) and (not inD(neg(hout))) else '?'
        lam = F(1)
        allfail = True; worst = F(0)
        for i in range(3):
            for vv in range(4):
                d_in  = rho(i, vv, hin)  * (rank(hin, i, '0')  - rank(hin, i, '+'))   # switch + -> 0 at h_in
                d_out = rho(i, vv, hout) * (rank(hout, i, '+') - rank(hout, i, '0'))  # switch 0 -> + at h_out
                N = lam*(d_in + d_out); G = lam*(abs(d_in) + abs(d_out))
                fails = N < eta*G          # judge does NOT support "T1 no worse than X"
                allfail &= fails
                worst = max(worst, N/G)
        print(f"eta={eta}, t={t}: T1 advice at h_in={aC_in}, at h_out={aC_out}; "
              f"every judge at every world fails: {allfail}; max N/G = {float(worst):.3e}")
