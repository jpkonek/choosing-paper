"""LL1 Prop 5.2: at eta = 0 the quorum rule (n=4, q=3) violates (TC).

One world. Three disjoint non-null cells cX, cY, cZ on which accepting is good at the world.
Base model B accepts on all three; X is B made silent on cX, Y silent on cY, Z silent on cZ.
For judge v, m_v(c) := integral over c of (l_v(silence) - l_v(accept)) > 0.  Then
  L_v(X) - L_v(Y) = m_v(cX) - m_v(cY),   d_v(X,Y) = m_v(cX) + m_v(cY).
Any positive masses are realised by strictly guiding judges (scale each judge's density on each cell).
Vote: v supports A R B iff L_v(B) - L_v(A) >= eta d_v(A,B); accept with >= 3 of 4 votes.
"""
from fractions import Fraction as Fr

m = {  # judge -> masses on (cX, cY, cZ)
    1: (1, 1, 1),   # indifferent judge
    2: (1, 2, 3),   # X < Y < Z
    3: (3, 1, 2),   # Y < Z < X
    4: (2, 3, 1),   # Z < X < Y
}
idx = {'X': 0, 'Y': 1, 'Z': 2}

def votes(A, B, eta):
    s = []
    for v, mv in m.items():
        LA, LB = mv[idx[A]], mv[idx[B]]
        d = LA + LB
        if LB - LA >= eta * d:
            s.append(v)
    return s

out = []
for eta in (Fr(0), Fr(1, 16)):
    R = {(A, B): len(votes(A, B, eta)) >= 3 for A in 'XYZ' for B in 'XYZ' if A != B}
    line = [f"eta={eta}:"]
    for (A, B), acc in sorted(R.items()):
        line.append(f"  {A} R {B}: votes {votes(A, B, eta)} -> {'accepted' if acc else 'not accepted'}")
    viol = []
    for A in 'XYZ':
        for B in 'XYZ':
            for C in 'XYZ':
                if len({A, B, C}) == 3 and R[(A, B)] and R[(B, C)] and R[(C, A)] and not R[(A, C)]:
                    viol.append(f"{A} R {B}, {B} R {C}, {C} strictly R {A}")
    line.append(f"  TC violations: {viol if viol else 'none'}")
    out.append("\n".join(line))
open('tc_eta0.out', 'w').write("\n".join(out) + "\n")
print("\n".join(out))
