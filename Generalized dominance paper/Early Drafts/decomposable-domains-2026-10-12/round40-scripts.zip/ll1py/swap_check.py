"""LL1: exact illustration of the mirror-swap lemma (Lemma 2.1 of LL1_notes.md).

Twelve heterogeneous, continuous, strictly guiding judges (four per world).
Selected models: T1 = C_u and posterior models C_p = {g : p (.) g in D_T1} near u.
At a point h0 on the accept/silence boundary of C_p we take h_in = h0 + s n (C_p accepts)
and h_out = h0 - s n (C_p silent), n the facet normal. The swap that silences h_in and
accepts h_out (equal small masses, point-evaluation limit of the ball construction in the
notes) has, for judge (i,v), increment Delta = delta_iv(h_out) - delta_iv(h_in) and size
d = |delta_iv(h_in)| + |delta_iv(h_out)|, where delta = l(.,accept) - l(.,silence).
We check exactly that Delta < eta * d for all 12 judges once s is small: every judge at
every world fails, so no quorum (of any size >= 1) supports C_p R_i X at any world.
All arithmetic is in Fractions.
"""
from fractions import Fraction as Fr
from itertools import product

eps = Fr(3, 10)
c0 = (1 - eps) / 3
V = [[c0 + (eps if j == k else 0) for j in range(3)] for k in range(3)]  # vertices of T1
eta = Fr(1, 16)

def rank(i, f, a):
    # world-i rank of advice a on the pair indexed by f: good 0, silence 1, bad 2, contradiction 3
    if a == 'x':
        return 3
    if a == '0':
        return 1
    good = (f[i] > 0) if a == '+' else (f[i] < 0)
    return 0 if good else 2

def dens(i, v, f):
    # heterogeneous strictly positive rational densities (continuous in f)
    q = 1 + sum(x * x for x in f)
    return [1, 1 + f[i] * f[i] / q, 1 + (f[(i + 1) % 3] ** 2) * 3 / q, Fr(1, 2) + (v + 1) * (f[(i + 2) % 3] ** 2) / q][v]

def loss(i, v, f, a):
    # strictly guiding: density times (rank + a rank-dependent convex bump)
    r = rank(i, f, a)
    return dens(i, v, f) * (r + Fr(r * r, 5))

def delta(f):
    return {(i, v): loss(i, v, f, '+') - loss(i, v, f, '0') for i in range(3) for v in range(4)}

def accepts(p, g):
    # posterior model C_p accepts g iff (p (.) g) . v_k > 0 for all k (mixed g)
    pg = [p[j] * g[j] for j in range(3)]
    return all(sum(pg[j] * V[k][j] for j in range(3)) > 0 for k in range(3))

def boundary_point(p):
    # a point on facet k=0 of C_p: (p (.) h) . v_0 = 0 with the other two facets strictly positive
    # take h = (a, 1, b) with mixed signs; solve for a
    n0 = [p[j] * V[0][j] for j in range(3)]
    b = Fr(-1, 5)
    a = -(n0[1] * 1 + n0[2] * b) / n0[0]
    h = [a, Fr(1), b]
    return h, n0

out = []
for p in [(Fr(1, 3), Fr(1, 3), Fr(1, 3)), (Fr(167, 500), Fr(333, 1000), Fr(333, 1000)), (Fr(2, 5), Fr(7, 20), Fr(1, 4))]:
    h0, n0 = boundary_point(p)
    others = [sum(p[j] * h0[j] * V[k][j] for j in range(3)) for k in (1, 2)]
    out.append(f"p={tuple(str(x) for x in p)} h0={[str(x) for x in h0]} facet0=0 others>0: {all(o > 0 for o in others)} mixed: {min(h0) < 0 < max(h0)}")
    for k in range(1, 9):
        s = Fr(1, 10 ** k)
        hin = [h0[j] + s * n0[j] for j in range(3)]
        hout = [h0[j] - s * n0[j] for j in range(3)]
        assert accepts(p, hin) and not accepts(p, hout)
        di, do = delta(hin), delta(hout)
        fails = 0
        worst = None
        for key in di:
            assert di[key] != 0 and do[key] != 0 and (di[key] > 0) == (do[key] > 0)  # same sign pattern
            D = do[key] - di[key]             # increment for the swap record (silence on h_in, accept on h_out)
            dd = abs(di[key]) + abs(do[key])
            if D < eta * dd:
                fails += 1
            ratio = D / dd
            worst = ratio if worst is None or ratio > worst else worst
        out.append(f"  s=1e-{k}: judges failing {fails}/12; max Delta/d = {float(worst):.3e} (eta={eta})")
open('swap_check.out', 'w').write("\n".join(out) + "\n")
print("\n".join(out))
