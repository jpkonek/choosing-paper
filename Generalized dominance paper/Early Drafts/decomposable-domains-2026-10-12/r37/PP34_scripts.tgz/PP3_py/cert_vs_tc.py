"""Is the triple-certificate condition implied by strict (G) + (TC) on the triple?
For every table entry (presence pattern, accepted bits): compute the G-forced values from the
presence pattern (A <= B forced true iff B holds every step A holds... i.e. U(A) subset U(B);
forced false iff U(B) strictly inside U(A)); keep entries consistent with G; test (TC) on all six
orderings; report G-consistent, TC-free entries that are certificate-infeasible."""
import pickle
from cert import TYPES, PAIRS
feas, conflict = pickle.load(open('cert_table.pkl', 'rb'))
def has(a, pres):   # set of types held by model a
    return {t for t, T in enumerate(TYPES) if (pres >> t) & 1 and a in T}
bad = []; ngood = 0
for pres in range(64):
    for acc in range(64):
        A = {PAIRS[k]: bool((acc >> k) & 1) for k in range(6)}
        ok = True
        for (a, b) in PAIRS:
            Ua, Ub = has(a, pres), has(b, pres)
            if Ua <= Ub and not A[(a, b)]: ok = False      # guidance pair must be accepted
            if Ub < Ua and A[(a, b)]: ok = False           # strict improvement never accepted
        if not ok: continue
        # reflexive
        le = lambda a, b: True if a == b else A[(a, b)]
        tc = True
        for x, y, z in [(0,1,2),(0,2,1),(1,0,2),(1,2,0),(2,0,1),(2,1,0)]:
            if le(x, y) and le(y, z) and le(z, x) and not le(x, z): tc = False
        if not tc: continue
        ngood += 1
        if not feas[pres*64 + acc]: bad.append((pres, acc))
print('G-consistent, TC-free entries:', ngood, '; of these certificate-infeasible:', len(bad))
for pres, acc in bad[:10]:
    print('  presence', [TYPES[t] for t in range(6) if (pres >> t) & 1], 'accepted', [PAIRS[k] for k in range(6) if (acc >> k) & 1])
