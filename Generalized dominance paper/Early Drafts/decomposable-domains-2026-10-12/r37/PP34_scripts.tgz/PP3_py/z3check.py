"""Independent z3 re-check of a minimal core written by run_atoms.py (core_atoms_*.json).
Re-derives, from the line normals alone: models from indices, world ranks, records (as tuples),
strict-(G) forcing, and one z3 Bool per (world, record) ((IB)).  Re-checks every listed selected
model by recomputing the coherent model at its stored sample index with its own implementation of
the credal family.  Then asserts exactly the core constraints and asks z3 for satisfiability.
usage: python3 z3check.py core.json"""
import sys, json, itertools
from fractions import Fraction as F
import z3

d = json.load(open(sys.argv[1]))
G = [tuple(F(a) for a in g) for g in d['G']]; N = len(G)
nadv = d.get('nadv', 3)
ADV = 'PSMC'
def model(i):
    X = []
    for _ in range(N): X.append(i % nadv); i //= nadv
    return tuple(reversed(X))
def rank(w, c, a):
    if a == 1: return 1
    if a == 3: return 3
    good = (G[c][w] > 0) == (a == 0)
    return 0 if good else 2
def record(X, Y):
    return tuple((c, X[c], Y[c]) for c in range(N) if X[c] != Y[c])
V = {}
def v(w, X, Y):
    """X <=_w Y"""
    rx = [rank(w, c, X[c]) for c in range(N)]; ry = [rank(w, c, Y[c]) for c in range(N)]
    worse = any(b > a for a, b in zip(rx, ry)); better = any(b < a for a, b in zip(rx, ry))
    if not better: return z3.BoolVal(True)
    if not worse: return z3.BoolVal(False)
    key = (w, record(X, Y))
    if key not in V: V[key] = z3.Bool('v_%d_%s' % (w, '_'.join('%d%d%d' % t for t in key[1])))
    return V[key]
# credal families (own implementation)
c3 = F(1, 3)
def K_hom(p):
    rho = 3*min(p); s = F(3, 20)
    return [tuple(p[i] + rho*s*((1 if i == k else 0) - c3) for i in range(3)) for k in range(3)]
def K_mult(p):
    beta = F(1, 4)
    l = [max(F(0), (1-beta)*x) for x in p]; u = [min(F(1), (1+beta)*x) for x in p]
    Vt = set()
    for i, j in itertools.permutations(range(3), 2):
        k = 3 - i - j
        for a in (l[i], u[i]):
            for b in (l[j], u[j]):
                x = [None]*3; x[i] = a; x[j] = b; x[k] = 1 - a - b
                if all(l[m] <= x[m] <= u[m] for m in range(3)): Vt.add(tuple(x))
    return list(Vt)
Kf = K_hom if d['fam'] == 'hom' else K_mult
def coh(p):
    out = []
    for g in G:
        vals = [sum(a*b for a, b in zip(x, g)) for x in Kf(p)]
        out.append(0 if min(vals) > 0 else (2 if max(vals) < 0 else 1))
    return tuple(out)
sel = {}
for nm, (sups, pts) in d['sel'].items():
    X = tuple(ADV.index(ch) for ch in nm)
    for p in pts:
        p = tuple(F(a) for a in p)
        assert coh(p) == X, 'selected model not coherent at its sample'
    sel[X] = [tuple(s) for s in sups]
S = z3.Solver()
kinds = {}
for kind, data in d['core']:
    kinds[kind] = kinds.get(kind, 0) + 1
    if kind == 'comp':
        ci, s, x = data; C = model(ci); X = model(x)
        assert C in sel and tuple(s) in sel[C]
        S.add(z3.Or([v(w, C, X) for w in s]))
    elif kind == 'undom':
        ci, x = data; C = model(ci); X = model(x); assert C in sel
        S.add(z3.Not(z3.And(z3.And([v(w, X, C) for w in range(3)]), z3.Or([z3.Not(v(w, C, X)) for w in range(3)]))))
    elif kind == 'kkm':
        X = model(data); assert X not in sel
        S.add(z3.Or([z3.And([v(w, C, X) for w in range(3)]) for C in sel]))
    elif kind == 'tc':
        w, x, y, zz = data; X, Y, Z = model(x), model(y), model(zz)
        S.add(z3.Not(z3.And(v(w, X, Y), v(w, Y, Z), v(w, Z, X), z3.Not(v(w, X, Z)))))
print(sys.argv[1], 'core constraints', kinds, 'record variables', len(V), 'z3:', S.check())
