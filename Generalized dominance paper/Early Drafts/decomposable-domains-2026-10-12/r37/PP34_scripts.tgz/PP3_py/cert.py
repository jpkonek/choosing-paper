"""Audit's triple-certificate condition, exactly.

For a triple {X,Y,Z} and a world w, the steps where the three models' world-w step sets are not all
equal fall into six presence types: steps held by exactly X, Y, Z, XY, XZ or YZ.  An additive
strictly guiding evaluator gives each step a positive weight; only the total weight W_T of each
present type matters, and these totals are independent positive reals (absent types have W_T = 0).
So "some strictly positive additive weight supports every accepted comparison in the triple, with
strict comparisons strict" depends only on (presence bits, accepted bits) and is decided by one LP
per table entry (64 x 64 entries).  The table also stores a deletion-minimal conflict set of facts
(accepted / rejected comparisons) for each infeasible entry, used to build blocking clauses."""
import itertools
import numpy as np
from scipy.optimize import linprog

TYPES = [(0,), (1,), (2,), (0, 1), (0, 2), (1, 2)]
PAIRS = [(0, 1), (1, 0), (0, 2), (2, 0), (1, 2), (2, 1)]
REV = [1, 0, 3, 2, 5, 4]

def feasible(pres, facts):
    """facts: dict pair-index -> True (accepted) / False (rejected).  Accepted (a,b): L(a) <= L(b);
    strict if the reverse is a rejected fact."""
    A = []; b = []
    for k, (a, bb) in enumerate(PAIRS):
        if facts.get(k) is True:
            row = [(1 if a in T else 0) - (1 if bb in T else 0) for T in TYPES]
            A.append(row); b.append(-1.0 if facts.get(REV[k]) is False else 0.0)
    if not A: return True
    bounds = [(1, None) if (pres >> t) & 1 else (0, 0) for t in range(6)]
    res = linprog(np.zeros(6), A_ub=np.array(A, dtype=float), b_ub=np.array(b), bounds=bounds, method='highs')
    return res.status == 0

def build_table():
    feas = np.ones(64*64, dtype=bool)
    conflict = {}
    for pres in range(64):
        for acc in range(64):
            facts = {k: bool((acc >> k) & 1) for k in range(6)}
            if feasible(pres, facts): continue
            feas[pres*64 + acc] = False
            cur = dict(facts)
            for k in list(cur):
                trial = {kk: v for kk, v in cur.items() if kk != k}
                if not feasible(pres, trial): cur = trial
            conflict[pres*64 + acc] = cur
    return feas, conflict

def umasks(RK):
    """world-w step bitmask per model (bit 2c+(j-1) for step (c,j), j=1,2; j=3 for contradiction)"""
    M, N = RK.shape
    u = np.zeros(M, dtype=np.int64)
    for c in range(N):
        for j in (1, 2, 3):
            u |= np.where(RK[:, c] >= j, np.int64(1) << np.int64(3*c + j - 1), 0)
    return u

def scan(A, u, feas, cap=None, rnd=None):
    """all unordered triples X<Y<Z: return count of failing triples and up to cap samples
    (x, y, z, code)"""
    M = len(u)
    tot = 0; out = []
    iu, ju = np.triu_indices(M, 1)
    for x in range(M - 2):
        m = iu > x
        Y = iu[m]; Z = ju[m]
        ux = u[x]; uy = u[Y]; uz = u[Z]
        pres = (((ux & ~uy & ~uz) != 0).astype(np.int64)
                | (((~ux & uy & ~uz) != 0).astype(np.int64) << 1)
                | (((~ux & ~uy & uz) != 0).astype(np.int64) << 2)
                | (((ux & uy & ~uz) != 0).astype(np.int64) << 3)
                | (((ux & ~uy & uz) != 0).astype(np.int64) << 4)
                | (((~ux & uy & uz) != 0).astype(np.int64) << 5))
        acc = (A[x, Y].astype(np.int64) | (A[Y, x].astype(np.int64) << 1) | (A[x, Z].astype(np.int64) << 2)
               | (A[Z, x].astype(np.int64) << 3) | (A[Y, Z].astype(np.int64) << 4) | (A[Z, Y].astype(np.int64) << 5))
        code = pres*64 + acc
        bad = ~feas[code]
        nb = int(bad.sum())
        if nb:
            tot += nb
            ks = np.nonzero(bad)[0]
            for k in ks:
                out.append((x, int(Y[k]), int(Z[k]), int(code[k])))
    if cap is not None and len(out) > cap:
        out = rnd.sample(out, cap)
    return tot, out

if __name__ == '__main__':
    import pickle, time
    t = time.time()
    feas, conflict = build_table()
    pickle.dump((feas, conflict), open('cert_table.pkl', 'wb'))
    print('table: %d infeasible entries of 4096 (%.0fs)' % ((~feas).sum(), time.time()-t))
    # classify minimal conflicts by shape
    from collections import Counter
    shapes = Counter()
    for code, cf in conflict.items():
        acc = tuple(sorted(PAIRS[k] for k, v in cf.items() if v)); rej = tuple(sorted(PAIRS[k] for k, v in cf.items() if not v))
        shapes[(len(acc), len(rej))] += 1
    print('minimal conflict sizes (accepted facts, rejected facts):', sorted(shapes.items()))
