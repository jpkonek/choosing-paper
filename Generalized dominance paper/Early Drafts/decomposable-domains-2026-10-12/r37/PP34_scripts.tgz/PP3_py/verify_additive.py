"""Independent check of an additive solution: build X <=_w Y iff L_w(X) <= L_w(Y) from the saved
integer step weights, with ranks recomputed by verify.ranks, and run verify.verify (IB, strict G,
TC on all triples, competitiveness on every support, KKM dominators, undominatedness).
usage: python3 verify_additive.py additive_ls_<fam>_N<N>_s<seed>.json"""
import sys, json
import numpy as np
from verify import ranks, verify
from common import load, selection_atoms
d = json.load(open(sys.argv[1]))
assert d.get('f', 0) == 0
G, Kf, Ls = load(d['fam'], d['N'], d['seed'])
sel, _ = selection_atoms(Kf, G, Ls)
N = len(G); models, RK = ranks(G, N)
W = np.array(d['W'], dtype=np.int64)          # (N, 6): index 2*w + (j-1)
assert (W > 0).all()
mats = []
for w in range(3):
    L = np.zeros(len(models), dtype=np.int64)
    for c in range(N):
        L += np.where(RK[w][:, c] >= 1, W[c, 2*w], 0) + np.where(RK[w][:, c] >= 2, W[c, 2*w+1], 0)
    mats.append(L[:, None] <= L[None, :])
print(sys.argv[1], 'min weight', W.min(), 'max weight', W.max())
print('ALL AXIOMS (additive):', verify(G, {X: sorted(sel[X][0]) for X in sel}, mats))
