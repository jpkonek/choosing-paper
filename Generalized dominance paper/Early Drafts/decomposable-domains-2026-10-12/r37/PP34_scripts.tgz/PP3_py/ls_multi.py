import sys, json
from additive_ls import *
fam = sys.argv[1]; N = int(sys.argv[2]); seeds = [int(a) for a in sys.argv[3].split(',')]
iters = int(sys.argv[4]); restarts = int(sys.argv[5])
for seed in seeds:
    best = None
    for r in range(restarts):
        (f, W, parts), (G, sel, Mo) = run(fam, N, seed, iters, log=lambda s: None, rs=r)
        if best is None or f < best[0]: best = (f, W, parts)
        if f == 0: break
    f, W, parts = best
    print('RESULT additive-LS %s N=%d seed=%d: best objective %d %s (restarts %d x %d)' % (fam, N, seed, f, parts, r+1, iters), flush=True)
    json.dump(dict(fam=fam, N=N, seed=seed, f=int(f), parts=[int(a) for a in parts], W=W.tolist()), open('additive_ls_%s_N%d_s%d.json' % (fam, N, seed), 'w'))
