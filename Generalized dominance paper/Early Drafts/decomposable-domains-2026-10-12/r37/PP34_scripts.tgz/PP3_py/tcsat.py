"""PP3 SAT screen: free record-based verdicts with strict (G), (IB), (TC), competitiveness on every
support of every selected model, KKM dominators for every non-selected model, and no selected model
dominated.  No gates, keys or verdict formula.

Model collection (mode 'atoms'): all 3^N regular cell-constant models on PP1's N lines; selected =
PP1's exact enumeration of the atom-coherent models C_p (cells and boundary indices) with all their
supports.  (TC) is imposed lazily (counterexample-guided) on ALL ordered triples of the collection,
so a SAT answer is SAT on the whole regular collection; UNSAT answers use only a subset of the (TC)
clauses, hence are valid.

Mode 'splits' (continuum stand-in, see splits.py) adds PP1's boundary split models as further
selected models with their own unlinked verdict variables.
"""
import sys, time, json, random, argparse, pickle
import numpy as np
from pysat.solvers import Solver
from common import *

TRUE = 1 << 40
FALSE = -(1 << 40)

class Enc:
    def __init__(self, Mo, extra=None):
        """Mo: Models.  extra: optional ExtraModels (splits) providing pair literals for pairs
        involving a model with index >= Mo.M"""
        self.Mo = Mo; self.extra = extra
        self.var = [dict(), dict(), dict()]   # per world: rec -> id
        self.info = {}                        # id -> (w, rec) or ('x', ...)
        self.nv = 0
        self.Mtot = Mo.M + (extra.K if extra else 0)
    def newvar(self, key):
        self.nv += 1; self.info[self.nv] = key; return self.nv
    def getvar(self, w, r):
        d = self.var[w]
        v = d.get(r)
        if v is None:
            v = self.newvar((w, int(r))); d[r] = v
        return v
    def lits(self, w, I, J):
        """literals for v_w(I[k], J[k]) (arrays of model indices in 0..Mtot-1)"""
        I = np.asarray(I, dtype=np.int64); J = np.asarray(J, dtype=np.int64)
        out = np.zeros(len(I), dtype=np.int64)
        Mo = self.Mo
        base = (I < Mo.M) & (J < Mo.M)
        if base.any():
            ii = I[base]; jj = J[base]
            A = Mo.models[ii]; B = Mo.models[jj]
            code = np.where(A == B, 0, 1 + Mo.nadv*A + B)
            rec = (code * Mo.pow10[None, :]).sum(1)
            ri = Mo.RK[w][ii]; rj = Mo.RK[w][jj]
            up = (rj > ri).any(1); down = (rj < ri).any(1)
            o = np.zeros(len(ii), dtype=np.int64)
            o[~down] = TRUE
            o[(~up) & down] = FALSE
            fr = np.nonzero(up & down)[0]
            for k in fr:
                o[k] = self.getvar(w, int(rec[k]))
            out[base] = o
        if (~base).any():
            for k in np.nonzero(~base)[0]:
                out[k] = self.extra.lit(self, w, int(I[k]), int(J[k]))
        return out

def clause_from(lits):
    """drop FALSE, return None if some TRUE (satisfied)"""
    cl = []
    for l in lits:
        l = int(l)
        if l == TRUE: return None
        if l == FALSE: continue
        cl.append(l)
    return cl

class Problem:
    def __init__(self, Mo, sel_idx, kkm_rivals, cand_idx, comp_targets=None, extra=None, closed=None):
        """sel_idx: list of (model index, list of supports) for selected models
        kkm_rivals: model indices needing a dominator among cand_idx
        comp_targets: indices X used as rivals for competitiveness / undominatedness (default all)
        closed: list of (S, A): v_w(A,X) => v_w(S,X) for all X in comp_targets, w (closedness)"""
        self.Mo = Mo; self.E = Enc(Mo, extra)
        self.groups = []      # (kind, data, [clauses])
        self.aux = []         # unconditional definitional clauses
        self.trivial = []
        E = self.E
        Mt = E.Mtot
        targets = np.arange(Mt) if comp_targets is None else np.asarray(comp_targets)
        for (ci, sups) in sel_idx:
            J = targets[targets != ci]
            I = np.full(len(J), ci)
            L = [E.lits(w, I, J) for w in range(3)]          # v_w(C, X)
            Lr = [E.lits(w, J, I) for w in range(3)]         # v_w(X, C)
            for s in sups:
                for k in range(len(J)):
                    cl = clause_from([L[w][k] for w in s])
                    if cl is None: continue
                    if not cl: self.trivial.append(('comp', ci, s, int(J[k]))); continue
                    self.groups.append(('comp', (ci, tuple(s), int(J[k])), [cl]))
            # undominated: not( all_w v_w(X,C) and some_w not v_w(C,X) )
            for k in range(len(J)):
                cls = []
                ok = True
                for j in range(3):
                    cl = clause_from([-Lr[w][k] if abs(Lr[w][k]) != TRUE else (FALSE if Lr[w][k] == TRUE else TRUE) for w in range(3)] + [L[j][k]])
                    if cl is None: continue
                    if not cl: self.trivial.append(('undom', ci, int(J[k]))); ok = False; break
                    cls.append(cl)
                if cls: self.groups.append(('undom', (ci, int(J[k])), cls))
        cand_idx = list(cand_idx)
        for X in kkm_rivals:
            I = np.array(cand_idx); J = np.full(len(I), X)
            L = [E.lits(w, I, J) for w in range(3)]
            opts = []; done = False
            for k in range(len(I)):
                req = []
                bad = False
                for w in range(3):
                    l = int(L[w][k])
                    if l == FALSE: bad = True; break
                    if l != TRUE: req.append(l)
                if bad: continue
                if not req: done = True; break
                d = E.newvar(('kkm', int(I[k]), int(X)))
                for l in req: self.aux.append([-d, l])
                opts.append(d)
            if done: continue
            if not opts: self.trivial.append(('kkm', int(X))); continue
            self.groups.append(('kkm', int(X), [opts]))
        if closed:
            for (S, A) in closed:
                J = targets[(targets != S) & (targets != A)]
                for w in range(3):
                    La = E.lits(w, np.full(len(J), A), J); Ls = E.lits(w, np.full(len(J), S), J)
                    for k in range(len(J)):
                        a = int(La[k]); s = int(Ls[k])
                        if a == FALSE or s == TRUE: continue
                        cl = clause_from([-a if a != TRUE else FALSE, s])
                        if cl is None: continue
                        if not cl: self.trivial.append(('closed', S, A, w, int(J[k]))); continue
                        self.groups.append(('closed', (S, A, w, int(J[k])), [cl]))
        self.tc = []          # TC groups added lazily

    def _cache(self):
        if hasattr(self, '_inv'): return
        Mo = self.Mo; M = Mo.M
        rec = np.zeros((M, M), dtype=np.int64)
        for i0 in range(0, M, 256):
            ii = np.arange(i0, min(M, i0+256))
            Ai = Mo.models[ii][:, None, :]; Bj = Mo.models[None, :, :]
            code = np.where(Ai == Bj, 0, 1 + Mo.nadv*Ai + Bj)
            rec[ii] = (code * Mo.pow10[None, None, :]).sum(2)
        U, inv = np.unique(rec, return_inverse=True)
        self._U = U; self._inv = inv.reshape(M, M).astype(np.int32); del rec
        self._forced = []; self._free = []
        for w in range(3):
            fo = np.zeros((M, M), dtype=bool); fr = np.zeros((M, M), dtype=bool)
            for i0 in range(0, M, 256):
                ii = np.arange(i0, min(M, i0+256))
                ri = Mo.RK[w][ii][:, None, :]; rj = Mo.RK[w][None, :, :]
                up = (rj > ri).any(2); down = (rj < ri).any(2)
                fo[ii] = ~down; fr[ii] = up & down
            self._forced.append(fo); self._free.append(fr)

    def matrices(self, model_set):
        """verdict matrices A_w (Mtot x Mtot) under a solver model (set of true var ids)"""
        self._cache()
        E = self.E; Mo = self.Mo; Mt = E.Mtot
        mats = []
        for w in range(3):
            keys = np.array(sorted(E.var[w].keys()), dtype=np.int64)
            vals = np.array([E.var[w][k] in model_set for k in keys], dtype=bool)
            valu = np.zeros(len(self._U), dtype=bool)
            if len(keys):
                pos = np.searchsorted(self._U, keys); assert (self._U[pos] == keys).all()
                valu[pos] = vals
            A = np.zeros((Mt, Mt), dtype=bool)
            A[:Mo.M, :Mo.M] = self._forced[w] | (self._free[w] & valu[self._inv])
            if E.extra:
                E.extra.fill_matrix(E, w, A, model_set)
            mats.append(A)
        return mats

def tc_violations(A, cap, rnd):
    Af = A.astype(np.float32)
    P = Af @ Af
    V = (P > 0) & A.T & ~A
    xs, zs = np.nonzero(V)
    n = len(xs)
    if n == 0: return 0, []
    pick = rnd.sample(range(n), min(cap, n))
    out = []
    for k in pick:
        x, z = int(xs[k]), int(zs[k])
        y = int(np.argmax(A[x, :] & A[:, z]))
        out.append((x, y, z))
    return n, out

def run(P, solver='cadical153', cap=20000, maxit=400, seed=0, log=print, timeout=None, phase=None):
    """phase: optional function (w, rec) -> bool giving the preferred value of a record variable"""
    rnd = random.Random(seed)
    E = P.E
    if P.trivial:
        return 'UNSAT-TRIVIAL', None
    S = Solver(name=solver)
    for cl in P.aux: S.add_clause(cl)
    for g in P.groups:
        for cl in g[2]: S.add_clause(cl)
    t0 = time.time()
    it = 0
    while True:
        it += 1
        try:
            if phase is None:
                S.set_phases([-v for v in range(1, E.nv+1)])
            else:
                ph = []
                for v in range(1, E.nv+1):
                    key = E.info[v]
                    if isinstance(key[0], int) and len(key) == 2:
                        ph.append(v if phase(key[0], key[1]) else -v)
                    else:
                        ph.append(-v)
                S.set_phases(ph)
        except Exception:
            pass
        ok = S.solve()
        if not ok:
            S.delete()
            return 'UNSAT', it
        m = set(l for l in S.get_model() if l > 0)
        mats = P.matrices(m)
        tot = 0; added = 0
        for w in range(3):
            n, viol = tc_violations(mats[w], cap, rnd)
            tot += n
            if not viol: continue
            xs = np.array([v[0] for v in viol]); ys = np.array([v[1] for v in viol]); zs = np.array([v[2] for v in viol])
            l1 = E.lits(w, xs, ys); l2 = E.lits(w, ys, zs); l3 = E.lits(w, zs, xs); l4 = E.lits(w, xs, zs)
            for k in range(len(viol)):
                cl = clause_from([-l1[k], -l2[k], -l3[k], l4[k]])
                assert cl is not None and cl, 'forced TC violation'
                S.add_clause(cl); added += 1
            P.tc.append((np.array([[w, a, b, c] for (a, b, c) in viol], dtype=np.int32),
                         np.stack([-l1, -l2, -l3, l4], 1)))
        log('  it %d: TC violations %d, added %d, vars %d, %.0fs' % (it, tot, added, E.nv, time.time()-t0))
        if tot == 0:
            S.delete()
            return 'SAT', (m, mats)
        if it >= maxit or (timeout and time.time()-t0 > timeout):
            S.delete()
            return 'UNKNOWN', it

def core(P, solver='cadical153', log=print):
    """selector-based core over all groups (base + accumulated TC), then deletion minimisation"""
    E = P.E
    groups = list(P.groups)
    for (trip, lits) in P.tc:
        for k in range(len(trip)):
            cl = clause_from(list(lits[k]))
            groups.append(('tc', tuple(int(a) for a in trip[k]), [cl]))
    nv0 = E.nv
    sels = list(range(nv0+1, nv0+1+len(groups)))
    S = Solver(name=solver)
    for cl in P.aux: S.add_clause(cl)
    for g, s in zip(groups, sels):
        for cl in g[2]: S.add_clause(cl + [-s])
    assert not S.solve(assumptions=sels)
    cur = sorted(set(S.get_core()))
    log('  initial core %d groups' % len(cur))
    # iterate core shrinking
    for _ in range(5):
        assert not S.solve(assumptions=cur)
        c2 = sorted(set(S.get_core()))
        if len(c2) >= len(cur): break
        cur = c2
    k = 0
    while k < len(cur):
        trial = cur[:k] + cur[k+1:]
        if not S.solve(assumptions=trial):
            c2 = set(S.get_core())
            cur = [s for s in trial if s in c2]
        else:
            k += 1
    S.delete()
    log('  minimal core %d groups' % len(cur))
    return [groups[s - nv0 - 1] for s in cur]
