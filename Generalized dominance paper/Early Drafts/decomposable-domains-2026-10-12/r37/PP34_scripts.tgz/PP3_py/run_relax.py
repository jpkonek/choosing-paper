"""Free-verdict screen, repair-from-additive version (decides the same question as run_atoms.py).
Every record variable starts ASSUMED equal to a near-additive verdict (assumption literals, not
clauses).  Loop:
  solve under the current assumptions;
  UNSAT -> take the solver's core of assumptions; if it is empty the problem is UNSAT outright
           (genuine: only base clauses and valid (TC) instances were used); else drop those
           assumptions (free those records) and continue;
  SAT   -> check (TC) on all triples; add violated instances (valid clauses) and continue;
           no violation -> SAT (verified independently).
usage: python3 run_relax.py fam N seed phaseW.json"""
import sys, os, time, json, random
import numpy as np
from pysat.solvers import Solver
from common import *
from tcsat import *

fam, N, seed, wf = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
cap = int(os.environ.get('CAP', '50000')); tlim = float(os.environ.get('TLIM', '6000'))
G, Kf, Ls = load(fam, N, seed)
sel, _ = selection_atoms(Kf, G, Ls)
Mo = Models(G)
sel_idx = [(Mo.idx(X), sorted(sel[X][0])) for X in sel]
seli = set(i for i, _ in sel_idx)
P = Problem(Mo, sel_idx, [i for i in range(Mo.M) if i not in seli], [i for i, _ in sel_idx])
E = P.E
Wph = json.load(open(wf))['W']
def pen(w, c, a):
    r = Mo.R[w][c][a]
    return (Wph[c][2*w] if r >= 1 else 0) + (Wph[c][2*w+1] if r >= 2 else 0)
def addv(w, rec):
    d = 0
    for c in range(N):
        code = (rec // Mo.B**c) % Mo.B
        if code:
            a, b = divmod(code - 1, Mo.nadv); d += pen(w, c, a) - pen(w, c, b)
    return d <= 0
assume = {}
def refresh_assumptions():
    for w in range(3):
        for rec, v in E.var[w].items():
            if v not in assume and v not in freed:
                assume[v] = v if addv(w, rec) else -v
freed = set()
S = Solver(name='cadical153')
for cl in P.aux: S.add_clause(cl)
for g in P.groups:
    for cl in g[2]: S.add_clause(cl)
rnd = random.Random(0); t0 = time.time(); it = 0; ntc = 0
print('%s N=%d seed=%d: nsel %d, groups %d' % (fam, N, seed, len(sel), len(P.groups)), flush=True)
res = 'UNKNOWN'
while time.time() - t0 < tlim:
    it += 1
    refresh_assumptions()
    A = list(assume.values())
    if not S.solve(assumptions=A):
        core = S.get_core() or []
        core = [l for l in core if abs(l) in assume]
        if not core:
            assert not S.solve()          # confirm: unsatisfiable with no assumptions at all
            res = 'UNSAT'; break
        for l in core:
            freed.add(abs(l)); del assume[abs(l)]
        print('  it %d: UNSAT under assumptions; freed %d records (total freed %d, assumed %d), TC clauses %d, %.0fs'
              % (it, len(core), len(freed), len(assume), ntc, time.time()-t0), flush=True)
        continue
    m = set(l for l in S.get_model() if l > 0)
    mats = P.matrices(m)
    tot = 0
    for w in range(3):
        n, viol = tc_violations(mats[w], cap, rnd)
        tot += n
        if not viol: continue
        xs = np.array([v[0] for v in viol]); ys = np.array([v[1] for v in viol]); zs = np.array([v[2] for v in viol])
        l1 = E.lits(w, xs, ys); l2 = E.lits(w, ys, zs); l3 = E.lits(w, zs, xs); l4 = E.lits(w, xs, zs)
        for k in range(len(viol)):
            cl = clause_from([-l1[k], -l2[k], -l3[k], l4[k]])
            S.add_clause(cl); ntc += 1
    print('  it %d: SAT under assumptions; TC violations %d (freed %d), %.0fs' % (it, tot, len(freed), time.time()-t0), flush=True)
    if tot == 0:
        res = 'SAT'
        from verify import verify
        good = verify(G, {X: sorted(sel[X][0]) for X in sel}, mats)
        print('INDEPENDENT VERIFY:', good, flush=True)
        np.savez_compressed('sol_relax_%s_N%d_s%d.npz' % (fam, N, seed), *[np.packbits(A_) for A_ in mats], shape=np.array(mats[0].shape))
        break
print('RESULT relax %s N=%d seed=%d: %s (iterations %d, freed records %d, TC clauses %d, %.0fs)' % (fam, N, seed, res, it, len(freed), ntc, time.time()-t0), flush=True)
