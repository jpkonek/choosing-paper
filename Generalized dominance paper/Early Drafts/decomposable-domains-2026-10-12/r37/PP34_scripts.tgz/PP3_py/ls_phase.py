"""near-additive weights (local search) to guide the free-verdict CEGAR phases"""
import sys, json
from additive_ls import run
fam, N, seed, iters = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
(f, W, parts), _ = run(fam, N, seed, iters, log=lambda s: print(s, flush=True))
print('best', f, parts, flush=True)
json.dump(dict(W=W.tolist(), f=int(f), parts=[int(a) for a in parts]), open('phaseW_%s_N%d_s%d.json' % (fam, N, seed), 'w'))
