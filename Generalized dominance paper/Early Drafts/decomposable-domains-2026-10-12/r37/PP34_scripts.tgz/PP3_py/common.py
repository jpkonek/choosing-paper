"""PP3 common layer: PP1's exact arrangements, the regular cell-constant model set, records,
strict (G) status, and record-shared ((IB)) verdict variables.

Verdict variable v_w(X,Y) means "X is no worse than Y at world w" (X <=_w Y).
(IB): v_w(X,Y) depends only on the record rec(X,Y) = (set where X,Y differ, X's advice there,
Y's advice there).  One boolean per (world, record).
Strict (G): if Y is a pointwise weak world-w worsening of X (ranks of Y >= ranks of X everywhere)
then v_w(X,Y) = True; if moreover the change is strict, v_w(Y,X) = False.  For regular advice
every changed line changes the rank at every world, so a pointwise weak worsening with X != Y is
strict.
"""
import sys, itertools, math
sys.path.insert(0, '/tmp/claude-0/-home-claude/516e9253-01b8-5264-9018-734bfcf63f58/scratchpad/r9/PP1_py')
import numpy as np
from fractions import Fraction as F
from core import random_lines, rank_table, fam_hom, fam_mult, coherent
from arrangement import hom_lines, mult_lines, enumerate_models

c3 = (F(1, 3),)*3
def tri(s):
    return [tuple(s*((1 if i == k else 0) - c3[i]) for i in range(3)) for k in range(3)]

def load(fam, N, seed):
    """exactly PP1's run_exact.py set-up"""
    G = random_lines(N, seed)
    T = tri(F(3, 20)); beta = F(1, 4)
    if fam == 'hom': Kf, Ls = fam_hom(T), hom_lines(G, T)
    else: Kf, Ls = fam_mult(beta), mult_lines(G, beta)
    return G, Kf, Ls

ADV = 'PSMC'   # 0 = accept g (P), 1 = silent (S), 2 = accept -g (M)
def name(X):
    return ''.join(ADV[a] for a in X)

class Models:
    """all nadv^N cell-constant models (nadv = 3 regular, 4 with contradiction);
    index = base-nadv number, line 0 most significant"""
    def __init__(self, G, nadv=3):
        self.G = G; self.N = N = len(G); self.nadv = nadv
        self.R = rank_table(G)                       # R[w][c][a]
        self.models = np.array(list(itertools.product(range(nadv), repeat=N)), dtype=np.int64)
        self.M = len(self.models)
        self.RK = []
        for w in range(3):
            tab = np.array([self.R[w][c][:nadv] for c in range(N)], dtype=np.int64)
            self.RK.append(tab[np.arange(N)[None, :], self.models])   # (M,N)
        self.pow3 = nadv**np.arange(N-1, -1, -1)
        self.B = 10 if nadv == 3 else 17
        self.pow10 = self.B**np.arange(N, dtype=np.int64)
    def idx(self, X):
        return int(np.dot(np.array(X), self.pow3))
    def recs_row(self, i, js=None):
        """record codes of pairs (i, j): per line 0 if equal, else 1+3a+b (a=X_c, b=Y_c)"""
        A = self.models[i][None, :]
        B = self.models if js is None else self.models[js]
        code = np.where(A == B, 0, 1 + self.nadv*A + B)
        return (code * self.pow10[None, :]).sum(1)
    def status_row(self, i, w, js=None):
        """status of v_w(i, j): 1 forced True (j weak worsening of i), 0 forced False
        (j strict improvement), 2 free"""
        ri = self.RK[w][i][None, :]
        rj = self.RK[w] if js is None else self.RK[w][js]
        up = (rj > ri).any(1); down = (rj < ri).any(1)
        st = np.full(len(rj), 2, dtype=np.int8)
        st[~down] = 1
        st[(~up) & down] = 0
        return st

def selection_atoms(Kf, G, Ls):
    """PP1's exact enumeration: dict model -> [set of supports, sample indices]"""
    sel, sp = enumerate_models(Kf, G, Ls)
    return sel, sp
