"""Exact (integer) confirmation of cert_vs_tc.py: for every presence pattern and every accepted
relation on a triple that satisfies reflexivity, strict (G) and (TC), exhibit integer weights
W_T in {1,...,6} on the present types (0 on absent ones) that support every accepted comparison and
make every strict comparison strict.  Pure integer arithmetic, no LP."""
import itertools
import numpy as np
from cert import TYPES, PAIRS
grid = np.array(list(itertools.product(range(1, 7), repeat=6)), dtype=np.int64)   # 46656 x 6
def has(a, pres): return {t for t, T in enumerate(TYPES) if (pres >> t) & 1 and a in T}
nent = 0; nok = 0
for pres in range(64):
    Wg = grid * np.array([(pres >> t) & 1 for t in range(6)])[None, :]
    L = np.stack([Wg[:, [t for t, T in enumerate(TYPES) if a in T]].sum(1) for a in range(3)], 1)
    for acc in range(64):
        A = {PAIRS[k]: bool((acc >> k) & 1) for k in range(6)}
        ok = True
        for (a, b) in PAIRS:
            Ua, Ub = has(a, pres), has(b, pres)
            if Ua <= Ub and not A[(a, b)]: ok = False
            if Ub < Ua and A[(a, b)]: ok = False
        if not ok: continue
        le = lambda a, b: True if a == b else A[(a, b)]
        if any(le(x, y) and le(y, z) and le(z, x) and not le(x, z) for x, y, z in itertools.permutations(range(3))):
            continue
        nent += 1
        good = np.ones(len(grid), dtype=bool)
        for (a, b) in PAIRS:
            if A[(a, b)]:
                good &= (L[:, a] < L[:, b]) if not A[(b, a)] else (L[:, a] <= L[:, b])
        nok += bool(good.any())
print('G+TC-consistent entries %d; with an exact integer certificate %d' % (nent, nok))
