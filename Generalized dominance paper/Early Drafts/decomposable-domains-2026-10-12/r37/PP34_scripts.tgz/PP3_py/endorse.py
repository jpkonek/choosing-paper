"""For a SAT solution (sol_atoms_*.npz): (1) re-scan every triple with the exact certificate table
(sanity check of the (G)+(TC) <=> certificate equivalence); (2) per world, LP: is there ONE strictly
positive step weighting endorsing every accepted comparison out of a selected model (strict ones
strict)?  If not, extract a Farkas certificate: a positive combination of accepted comparisons out
of selected models whose step-difference is >= 0 (a non-additive 'cycle'), and report its length.
usage: python3 endorse.py fam N seed [--scan]"""
import sys, pickle
import numpy as np
from scipy.optimize import linprog
from common import *
from cert import umasks, scan

fam, N, seed = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
G, Kf, Ls = load(fam, N, seed)
sel, _ = selection_atoms(Kf, G, Ls)
Mo = Models(G)
z = np.load('sol_atoms_%s_N%d_s%d.npz' % (fam, N, seed))
shape = tuple(z['shape'])
mats = [np.unpackbits(z['arr_%d' % w])[:shape[0]*shape[1]].reshape(shape).astype(bool) for w in range(3)]
if '--scan' in sys.argv:
    feas, conflict = pickle.load(open('cert_table.pkl', 'rb'))
    for w in range(3):
        u = umasks(Mo.RK[w])
        tot, _ = scan(mats[w], u, feas)
        print('world %d: triples failing the certificate table: %d' % (w, tot), flush=True)
S = sorted(Mo.idx(X) for X in sel)
for w in range(3):
    u = np.zeros((Mo.M, 2*N))
    for c in range(N):
        u[:, 2*c] = Mo.RK[w][:, c] >= 1; u[:, 2*c+1] = Mo.RK[w][:, c] >= 2
    rows = []; rhs = []; lab = []
    for ci in S:
        for X in np.nonzero(mats[w][ci])[0]:
            if X == ci: continue
            strict = not mats[w][X, ci]
            rows.append(u[ci] - u[X]); rhs.append(-1.0 if strict else 0.0); lab.append((ci, int(X), strict))
    A = np.array(rows); b = np.array(rhs)
    res = linprog(np.zeros(2*N), A_ub=A, b_ub=b, bounds=[(1, None)]*(2*N), method='highs')
    if res.status == 0:
        print('world %d: %d accepted comparisons out of selected models; ONE positive weight endorses all' % (w, len(rows)))
        continue
    # Farkas: y >= 0, y^T A >= 0 componentwise ... find minimal support certificate:
    # min sum y  s.t.  A^T y >= 0 (i.e. -A^T y <= 0), b^T y <= -1   (y >= 0)
    m = len(rows)
    res2 = linprog(np.ones(m), A_ub=np.vstack([-A.T, b[None, :]]), b_ub=np.concatenate([np.zeros(2*N), [-1.0]]),
                   bounds=[(0, None)]*m, method='highs')
    y = res2.x; supp_ = np.nonzero(y > 1e-9)[0]
    print('world %d: %d accepted comparisons out of selected models; NO single positive weight endorses them; '
          'Farkas certificate uses %d comparisons:' % (w, m, len(supp_)))
    for k in supp_[:12]:
        ci, X, st = lab[k]
        print('     %.3g x  %s <=_%d %s %s' % (y[k], name(tuple(Mo.models[ci])), w, name(tuple(Mo.models[X])), '(strict)' if st else ''))
