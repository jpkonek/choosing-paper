"""Independent check of a SAT solution (verdict matrices on the regular cell-constant models).
Recomputes ranks from the signs of the line normals, records with a different encoding, and checks
(IB), strict (G), (TC) on all triples, competitiveness on every support, KKM dominators,
undominatedness.  Does not use tcsat.py."""
import itertools
import numpy as np

def ranks(G, N, nadv=3):
    models = np.array(list(itertools.product(range(nadv), repeat=N)), dtype=np.int64)
    RK = []
    for w in range(3):
        pos = np.array([1 if g[w] > 0 else 0 for g in G])
        # advice 0 accepts g: good (0) if g_w>0 else bad (2); advice 2 the reverse; 1 silent
        r0 = np.where(pos == 1, 0, 2); r2 = 2 - r0
        cols = [r0, np.ones(N, dtype=np.int64), r2] + ([3*np.ones(N, dtype=np.int64)] if nadv == 4 else [])
        tab = np.stack(cols, 1)
        RK.append(tab[np.arange(N)[None, :], models])
    return models, RK

def verify(G, sel_sup, mats, log=print):
    """sel_sup: dict model tuple -> list of supports; mats: list of 3 bool (M,M) arrays"""
    N = len(G); nadv = 3 if mats[0].shape[0] == 3**N else 4
    models, RK = ranks(G, N, nadv); M = len(models)
    idx = {tuple(int(a) for a in r): k for k, r in enumerate(models)}
    ok = True
    # record ids: differ mask in base 2 plus advices of both in base 3 on differ set
    for w in range(3):
        A = mats[w]
        assert A.shape == (M, M)
        bad_ib = 0; bad_g = 0
        for i in range(M):
            X = models[i]; Y = models
            diff = (Y != X[None, :])
            key = (diff * (2**np.arange(N))).sum(1).astype(np.int64)
            key = key * nadv**N + (np.where(diff, X[None, :], 0) * nadv**np.arange(N)).sum(1)
            key = key * nadv**N + (np.where(diff, Y, 0) * nadv**np.arange(N)).sum(1)
            if i == 0: allkeys = []
            allkeys.append(key)
            rx = RK[w][i][None, :]; ry = RK[w]
            worse = (ry > rx).any(1); better = (ry < rx).any(1)
            # guidance accepted; strict improvement never accepted in worsening direction
            bad_g += int((~better & ~A[i]).sum())          # Y weakly worse => X <= Y
            bad_g += int((~worse & better & A[i]).sum())   # Y strictly better => not X <= Y
        K = np.concatenate(allkeys); V = A.reshape(-1)
        order = np.argsort(K, kind='stable'); Ks = K[order]; Vs = V[order]
        brk = np.nonzero(np.diff(Ks))[0] + 1
        starts = np.concatenate([[0], brk]); ends = np.concatenate([brk, [len(Ks)]])
        mn = np.minimum.reduceat(Vs.astype(np.int8), starts); mx = np.maximum.reduceat(Vs.astype(np.int8), starts)
        bad_ib = int((mn != mx).sum())
        # TC: X<=Y<=Z and Z<X (Z<=X, not X<=Z)
        Ai = A.astype(np.float32)   # path counts <= M < 2^24, exact in float32
        P = Ai @ Ai
        bad_tc = int(((P > 0) & A.T & ~A).sum())
        log('  world %d: IB violations %d, G violations %d, TC violations %d' % (w, bad_ib, bad_g, bad_tc))
        ok &= (bad_ib == 0 and bad_g == 0 and bad_tc == 0)
    seli = {idx[tuple(X)]: sups for X, sups in sel_sup.items()}
    bad_c = 0; bad_u = 0; bad_k = 0
    for ci, sups in seli.items():
        for s in sups:
            acc = np.zeros(M, dtype=bool)
            for w in s: acc |= mats[w][ci]
            acc[ci] = True
            bad_c += int((~acc).sum())
        dom = mats[0][:, ci] & mats[1][:, ci] & mats[2][:, ci] & ~(mats[0][ci] & mats[1][ci] & mats[2][ci])
        dom[ci] = False
        bad_u += int(dom.sum())
    S = np.array(sorted(seli))
    D = mats[0][S] & mats[1][S] & mats[2][S]
    has = D.any(0)
    bad_k = int((~has).sum())
    log('  competitiveness failures %d, dominated selected %d, rivals without dominator %d' % (bad_c, bad_u, bad_k))
    return ok and bad_c == 0 and bad_u == 0 and bad_k == 0
