"""Independent re-check of 'no additive solution': rebuild the active constraint set stored in
additive_smt_*.json from the line normals alone (own model decoding, own world ranks, own coherent-
model check of every selected model at its stored indices, written into the json by this script's
caller via common.selection_atoms only for the list of selected models and their supports), and
ask z3 (exact linear real arithmetic) again.
usage: python3 additive_z3check.py additive_smt_<fam>_N<N>_s<seed>.json"""
import sys, json, ast
from fractions import Fraction as F
import z3
sys.path.insert(0, '/tmp/claude-0/-home-claude/516e9253-01b8-5264-9018-734bfcf63f58/scratchpad/r9/PP1_py')
from core import random_lines
from arrangement import hom_lines, mult_lines, enumerate_models
import itertools
# credal families (own implementation)
c3 = F(1, 3)
def K_hom(p):
    rho = 3*min(p); s = F(3, 20)
    return [tuple(p[i] + rho*s*((1 if i == k else 0) - c3) for i in range(3)) for k in range(3)]
def K_mult(p):
    beta = F(1, 4)
    l = [max(F(0), (1-beta)*x) for x in p]; u = [min(F(1), (1+beta)*x) for x in p]
    Vt = set()
    for i, j in itertools.permutations(range(3), 2):
        k = 3 - i - j
        for a in (l[i], u[i]):
            for b in (l[j], u[j]):
                x = [None]*3; x[i] = a; x[j] = b; x[k] = 1 - a - b
                if all(l[m] <= x[m] <= u[m] for m in range(3)): Vt.add(tuple(x))
    return list(Vt)

d = json.load(open(sys.argv[1])); assert d['f'] == -1
fam, N, seed = d['fam'], d['N'], d['seed']
G = random_lines(N, seed)
Kown = K_hom if fam == 'hom' else K_mult
def coh(p):
    out = []
    for g in G:
        vals = [sum(a*b for a, b in zip(x, g)) for x in Kown(p)]
        out.append(0 if min(vals) > 0 else (2 if max(vals) < 0 else 1))
    return tuple(out)
# selected models: PP1's exact enumeration, each re-checked with the own family at its samples
from common import load
_, Kf, Ls = load(fam, N, seed)
sel, _ = enumerate_models(Kf, G, Ls)
for X, (sups, pts) in sel.items():
    for p in pts: assert coh(p) == X
def model(i):
    X = []
    for _ in range(N): X.append(i % 3); i //= 3
    return tuple(reversed(X))
def rank(w, c, a):
    if a == 1: return 1
    return 0 if ((G[c][w] > 0) == (a == 0)) else 2
idx = {}
Wv = {(c, w, j): z3.Real('W_%d_%d_%d' % (c, w, j)) for c in range(N) for w in range(3) for j in (1, 2)}
def L(w, X):
    return z3.Sum([Wv[(c, w, j)] for c in range(N) for j in (1, 2) if rank(w, c, X[c]) >= j] + [z3.RealVal(0)])
S = z3.Solver()
for v in Wv.values(): S.add(v >= 1)
SEL = list(sel)
act = [k if isinstance(k, list) else ast.literal_eval(k) for k in d['active']]
for k in act:
    if k[0] == 'comp':
        _, ci, s, x = k; C = model(ci); X = model(x); assert C in sel and tuple(s) in sel[C][0]
        S.add(z3.Or([L(w, C) <= L(w, X) for w in s]))
    elif k[0] == 'undom':
        _, ci, x = k; C = model(ci); X = model(x); assert C in sel
        S.add(z3.Not(z3.And(z3.And([L(w, X) <= L(w, C) for w in range(3)]), z3.Or([L(w, X) < L(w, C) for w in range(3)]))))
    else:
        _, x = k; X = model(x); assert X not in sel
        S.add(z3.Or([z3.And([L(w, C) <= L(w, X) for w in range(3)]) for C in SEL]))
print(sys.argv[1], 'constraints', len(act), 'z3:', S.check(), flush=True)
