"""Local search for an ADDITIVE solution on the finite cells (atoms mode).
Objective = competitiveness failures + dominated selected + rivals without a selected dominator,
counted exactly with integer weights (additive.check).  Moves: multiply one weight by a random
factor; accept if the objective does not increase (with occasional uphill moves).  A zero-objective
weight vector is an exact additive solution; it is saved and re-verified.
usage: python3 additive_ls.py fam N seeds [iters]"""
import sys, time, json, random
import numpy as np
from additive import *

def run(fam, N, seed, iters=20000, log=print, rs=0):
    G, Kf, Ls = load(fam, N, seed)
    sel, _ = selection_atoms(Kf, G, Ls)
    samples, vg = enumerate2(Kf, G, Ls)
    Mo = Models(G)
    Wl, _ = hinge_lp(G, samples)
    W = np.array([np.clip(np.round(w*10), 10, 100000) for w in Wl], dtype=np.int64)   # (N,6)
    rnd = random.Random(rs)
    def obj(W):
        cf, uf, kf = check(Mo, sel, losses(Mo, W))
        return cf + uf + kf, (cf, uf, kf)
    f, parts = obj(W); best = (f, W.copy(), parts)
    t = time.time(); T = 1.0
    for it in range(iters):
        W2 = W.copy()
        for _ in range(rnd.choice([1, 1, 1, 2, 3])):
            c = rnd.randrange(N); k = rnd.randrange(6)
            W2[c, k] = min(10**9, max(1, int(W2[c, k] * np.exp(rnd.gauss(0, 0.5)))))
        f2, p2 = obj(W2)
        if f2 <= f or rnd.random() < np.exp(-(f2 - f)/T):
            W, f, parts = W2, f2, p2
            if f < best[0]: best = (f, W.copy(), parts)
        T = max(0.05, T*0.9995)
        if it % 1000 == 0: log('  it %d: current %d %s best %d %s (%.0fs)' % (it, f, parts, best[0], best[2], time.time()-t))
        if best[0] == 0: break
    return best, (G, sel, Mo)

if __name__ == '__main__':
    fam = sys.argv[1]; N = int(sys.argv[2]); seeds = [int(a) for a in sys.argv[3].split(',')]
    iters = int(sys.argv[4]) if len(sys.argv) > 4 else 20000
    for seed in seeds:
        t = time.time()
        (f, W, parts), (G, sel, Mo) = run(fam, N, seed, iters, log=lambda s: print(s, flush=True))
        print('RESULT additive-LS %s N=%d seed=%d: best objective %d %s (%.0fs)' % (fam, N, seed, f, parts, time.time()-t), flush=True)
        if f == 0:
            cf, uf, kf = check(Mo, sel, losses(Mo, W))
            print('   re-check: competitiveness failures %d, dominated %d, without dominator %d; min weight %d' % (cf, uf, kf, W.min()), flush=True)
            json.dump(dict(fam=fam, N=N, seed=seed, W=W.tolist()), open('additive_%s_N%d_s%d.json' % (fam, N, seed), 'w'))
