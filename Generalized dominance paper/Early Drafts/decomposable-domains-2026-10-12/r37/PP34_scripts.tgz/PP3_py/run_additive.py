"""usage: python3 run_additive.py fam N seeds -- hinge-LP additive weights, exact integer check"""
import sys
from additive import *
fam = sys.argv[1]; N = int(sys.argv[2]); seeds = [int(a) for a in sys.argv[3].split(',')]
for seed in seeds:
    G, Kf, Ls = load(fam, N, seed)
    sel, _ = selection_atoms(Kf, G, Ls)
    samples, vg = enumerate2(Kf, G, Ls)
    Mo = Models(G)
    Wl, viol = hinge_lp(G, samples)
    for scale in (1000, 100000):
        W = [[int(round(x*scale)) for x in wl] for wl in Wl]
        L = losses(Mo, W)
        cf, uf, kf = check(Mo, sel, L)
        print('%s N=%d seed=%d scale %d: violated Bayes rows per line %s; competitiveness failures %d, dominated selected %d, rivals without dominator %d' % (fam, N, seed, scale, viol, cf, uf, kf), flush=True)
