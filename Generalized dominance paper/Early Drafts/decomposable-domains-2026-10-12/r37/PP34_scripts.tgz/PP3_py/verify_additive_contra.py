"""Extension check: an additive solution on regular models, with ANY positive weight on the
contradiction step (here 1), still satisfies every axiom on the domain with contradictory advice
on the mixed lines (4^N models).  Independent verifier (verify.py).
usage: python3 verify_additive_contra.py additive_*.json"""
import sys, json
import numpy as np
from verify import ranks, verify
from common import load, selection_atoms
d = json.load(open(sys.argv[1]))
G, Kf, Ls = load(d['fam'], d['N'], d['seed'])
sel, _ = selection_atoms(Kf, G, Ls)
N = len(G); models, RK = ranks(G, N, 4)
W = np.array(d['W'], dtype=np.int64)
mats = []
for w in range(3):
    L = np.zeros(len(models), dtype=np.int64)
    for c in range(N):
        L += np.where(RK[w][:, c] >= 1, W[c, 2*w], 0) + np.where(RK[w][:, c] >= 2, W[c, 2*w+1], 0) + np.where(RK[w][:, c] >= 3, 1, 0)
    mats.append(L[:, None] <= L[None, :])
print(sys.argv[1], 'models', len(models))
print('ALL AXIOMS (additive, with contradiction):', verify(G, {X: sorted(sel[X][0]) for X in sel}, mats))
