"""Mode 'atoms': usage  python3 run_atoms.py fam N seeds [--core] [--nokkm] [--nocomp] [--noundom] [--notc]"""
import sys, time, json, pickle, os
from common import *
from tcsat import *

fam = sys.argv[1]; N = int(sys.argv[2]); seeds = [int(a) for a in sys.argv[3].split(',')]
flags = set(sys.argv[4:])
for seed in seeds:
    t = time.time()
    G, Kf, Ls = load(fam, N, seed)
    sel, sp = selection_atoms(Kf, G, Ls)
    Mo = Models(G, nadv=4 if '--contra' in flags else 3)
    sel_idx = [(Mo.idx(X), sorted(sel[X][0])) for X in sel]
    if '--nocomp' in flags:
        sel_idx_c = [(i, []) for i, s in sel_idx]
    else:
        sel_idx_c = sel_idx
    seli = set(i for i, _ in sel_idx)
    rivals = [] if '--nokkm' in flags else [i for i in range(Mo.M) if i not in seli]
    P = Problem(Mo, sel_idx_c, rivals, [i for i, _ in sel_idx])
    if '--noundom' in flags:
        P.groups = [g for g in P.groups if g[0] != 'undom']
    print('%s N=%d seed=%d: nsel %d, models %d, groups %d, trivial %d' % (fam, N, seed, len(sel), Mo.M, len(P.groups), len(P.trivial)), flush=True)
    maxit = 1 if '--notc' in flags else int(os.environ.get('MAXIT', '400'))
    import os
    phase = None
    if os.environ.get('PHASEW'):
        Wph = json.load(open(os.environ['PHASEW']))['W']
        B = Mo.B; nadv = Mo.nadv
        def pen(w, c, a):
            r = Mo.R[w][c][a]
            return (Wph[c][2*w] if r >= 1 else 0) + (Wph[c][2*w+1] if r >= 2 else 0)
        def phase(w, rec):
            d = 0
            for c in range(N):
                code = (rec // B**c) % B
                if code:
                    a, b = divmod(code - 1, nadv)
                    d += pen(w, c, a) - pen(w, c, b)
            return d <= 0
    if phase is not None and os.environ.get('FIXK'):
        # restriction (SAT under it is SAT of the original): records changing fewer than FIXK lines
        # are fixed to the near-additive verdict; only records changing >= FIXK lines stay free
        K = int(os.environ['FIXK']); nfix = 0
        for w in range(3):
            for rec, v in P.E.var[w].items():
                nd = sum(1 for c in range(N) if (rec // Mo.B**c) % Mo.B)
                if nd < K:
                    P.aux.append([v if phase(w, rec) else -v]); nfix += 1
        print('fixed %d record variables to the near-additive verdict (records changing < %d lines)' % (nfix, K), flush=True)
    res, info = run(P, phase=phase, maxit=maxit, cap=int(os.environ.get('CAP', '200000')), timeout=float(os.environ.get('TLIM', '5400')), log=lambda s: print(s, flush=True))
    print('RESULT %s N=%d seed=%d flags=%s: %s (%.0fs)' % (fam, N, seed, sorted(flags), res, time.time()-t), flush=True)
    if res == 'SAT':
        from verify import verify
        m, mats = info
        good = verify(G, {X: sorted(sel[X][0]) for X in sel}, mats)
        print('INDEPENDENT VERIFY:', good, flush=True)
        np.savez_compressed('sol_atoms_%s_N%d_s%d%s.npz' % (fam, N, seed, '_contra' if Mo.nadv == 4 else ''), *[np.packbits(A) for A in mats], shape=np.array(mats[0].shape))
    if res == 'UNSAT' and '--core' in flags:
        C = core(P, log=lambda s: print(s, flush=True))
        out = dict(fam=fam, N=N, seed=seed, nadv=Mo.nadv, G=[[str(a) for a in g] for g in G],
                   sel={name(X): [sorted(sel[X][0]), [[str(a) for a in p] for p in sel[X][1]]] for X in sel},
                   core=[(k, d) for k, d, _ in C])
        fn = 'core_atoms_%s_N%d_s%d%s.json' % (fam, N, seed, '_contra' if Mo.nadv == 4 else '')
        json.dump(out, open(fn, 'w'), default=int)
        print('core written', fn, 'kinds', {k: sum(1 for kk, _, _ in C if kk == k) for k in ('comp', 'undom', 'kkm', 'tc')}, flush=True)
