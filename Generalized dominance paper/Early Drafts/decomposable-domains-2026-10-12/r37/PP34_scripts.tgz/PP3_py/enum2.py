"""PP1's exact arrangement sampling (arrangement.enumerate_models), re-implemented so that it also
returns, for every sample index, its model, its support and the non-side arrangement lines through
it, and for every arrangement vertex the face models around it.  This gives:
  * cells: models of open faces (2-d sectors; 1-d side segments; corners), with supports;
  * boundary points: edge points (on one non-side line) and vertices, with the face models adjacent
    to them (used to build PP1's split models and closedness implications).
Selected atom models (all samples) agree with PP1's enumerate_models (checked in check_enum2.py)."""
from fractions import Fraction as F
import itertools, math
from core import coherent

def enumerate2(Kfun, G, Ls):
    Ls = [L for L in Ls if L is not None]
    sides = [(F(1), F(0), F(0)), (F(0), F(1), F(0)), (F(1), F(1), F(-1))]
    def norm(L):
        a, b, c = L; s = a if a != 0 else b
        return (a/s, b/s, c/s)
    sides = [norm(L) for L in sides]
    Ls = list(set(Ls) | set(sides))
    sideset = set(sides)
    inside = lambda x, y: x >= 0 and y >= 0 and x + y <= 1
    val = lambda L, x, y: L[0]*x + L[1]*y + L[2]
    P = lambda x, y: (x, y, 1-x-y)
    verts = {}
    for L1, L2 in itertools.combinations(Ls, 2):
        det = L1[0]*L2[1] - L1[1]*L2[0]
        if det == 0: continue
        x = (-L1[2]*L2[1] + L2[2]*L1[1]) / det; y = (-L1[0]*L2[2] + L2[0]*L1[2]) / det
        if inside(x, y): verts.setdefault((x, y), set()).update([L1, L2])
    samples = []     # (p, model, support, kind) kind in 'face','edge','vertex'
    vgroups = []     # (vertex p, support, [face models around], [(edge p, edge support, (face_a, face_b))])
    def model(x, y): return coherent(Kfun(P(x, y)), G)
    def supp(x, y): return tuple(i for i, v in enumerate(P(x, y)) if v > 0)
    for (x, y), through in verts.items():
        dirs = []
        for L in through:
            d = (L[1], -L[0]); dirs += [(d, L), ((-d[0], -d[1]), L)]
        dirs.sort(key=lambda dl: math.atan2(float(dl[0][1]), float(dl[0][0])))
        others = [L for L in Ls if L not in through]
        def step(d):
            eps = F(1, 10**6)
            for L in others:
                v = abs(val(L, x, y)); s = abs(L[0]*d[0]) + abs(L[1]*d[1])
                if s > 0: eps = min(eps, v/(2*s))
            return x + eps*d[0], y + eps*d[1]
        n = len(dirs)
        sector = [None]*n     # sector k between dirs[k] and dirs[k+1]
        for k in range(n):
            d1, d2 = dirs[k][0], dirs[(k+1) % n][0]
            n1 = abs(d1[0]) + abs(d1[1]); n2 = abs(d2[0]) + abs(d2[1])
            d = (d1[0]/n1 + d2[0]/n2, d1[1]/n1 + d2[1]/n2)
            if d == (0, 0): continue
            qx, qy = step(d)
            if not inside(qx, qy): continue
            Xm = model(qx, qy); sector[k] = Xm
            samples.append((P(qx, qy), Xm, supp(qx, qy), 'face'))
        rays = []
        faces = [s for s in sector if s is not None]
        for k in range(n):
            d, L = dirs[k]
            qx, qy = step(d)
            if not inside(qx, qy): continue
            Xm = model(qx, qy)
            if L in sideset:
                samples.append((P(qx, qy), Xm, supp(qx, qy), 'face'))   # open side segment
                faces.append(Xm)
            else:
                samples.append((P(qx, qy), Xm, supp(qx, qy), 'edge'))
                adj = tuple(s for s in (sector[(k-1) % n], sector[k]) if s is not None)
                rays.append((P(qx, qy), supp(qx, qy), adj, Xm))
        nonside = [L for L in through if L not in sideset]
        Xv = model(x, y)
        samples.append((P(x, y), Xv, supp(x, y), 'vertex' if nonside else 'face'))
        if not nonside: faces.append(Xv)
        vgroups.append((P(x, y), supp(x, y), faces, rays, Xv, bool(nonside)))
    return samples, vgroups
