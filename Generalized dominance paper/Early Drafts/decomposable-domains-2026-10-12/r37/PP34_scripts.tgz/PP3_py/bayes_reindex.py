"""Given an exact additive solution (integer step weights), test whether every selected atom model
is a Bayes act of that additive rule at SOME index q supported inside each of its supports s:
for every line c and every advice a, sum_w q_w pen_w(c, C_c) <= sum_w q_w pen_w(c, a).
(It cannot in general be Bayes at its own coherent index: the per-line Bayes LP at coherent
indices is infeasible, see additive.py.)  LP for q, then exact re-check with rational q.
usage: python3 bayes_reindex.py additive_*.json"""
import sys, json
import numpy as np
from fractions import Fraction as F
from scipy.optimize import linprog
from common import load, selection_atoms, rank_table

d = json.load(open(sys.argv[1]))
G, Kf, Ls = load(d['fam'], d['N'], d['seed'])
sel, _ = selection_atoms(Kf, G, Ls)
N = len(G); R = rank_table(G); W = d['W']
def pen(w, c, a):
    r = R[w][c][a]
    return (W[c][2*w] if r >= 1 else 0) + (W[c][2*w+1] if r >= 2 else 0)
tot = 0; ok = 0; fails = []
for X in sel:
    for s in sorted(sel[X][0]):
        tot += 1
        rows = []
        for c in range(N):
            for a in range(3):
                if a == X[c]: continue
                rows.append([pen(w, c, X[c]) - pen(w, c, a) if w in s else 0 for w in range(3)])
        A = np.array(rows, dtype=float)
        res = linprog(np.zeros(3), A_ub=A, b_ub=np.zeros(len(rows)), A_eq=np.ones((1, 3)), b_eq=[1],
                      bounds=[(0, 1) if w in s else (0, 0) for w in range(3)], method='highs')
        good = False
        if res.status == 0:
            q = [F(x).limit_denominator(10**9) for x in res.x]
            q = [x if w in s else F(0) for w, x in enumerate(q)]
            sq = sum(q); q = [x/sq for x in q]
            good = all(sum(q[w]*row[w] for w in range(3)) <= 0 for row in rows)
            if not good:   # try the LP centre via a small margin search
                res2 = linprog(np.zeros(3), A_ub=A, b_ub=-1e-9*np.ones(len(rows)), A_eq=np.ones((1, 3)), b_eq=[1],
                               bounds=[(0, 1) if w in s else (0, 0) for w in range(3)], method='highs')
                if res2.status == 0:
                    q = [F(x).limit_denominator(10**12) if w in s else F(0) for w, x in enumerate(res2.x)]
                    sq = sum(q); q = [x/sq for x in q]
                    good = all(sum(q[w]*row[w] for w in range(3)) <= 0 for row in rows)
        ok += good
        if not good: fails.append((''.join('PSM'[a] for a in X), s))
print(sys.argv[1], ': (selected model, support) pairs %d; Bayes at some index inside the support (exact check) %d' % (tot, ok))
if fails: print('   not Bayes anywhere in support:', fails[:10])
