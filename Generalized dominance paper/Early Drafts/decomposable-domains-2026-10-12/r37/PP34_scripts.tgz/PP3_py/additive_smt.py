"""Exact decision: does an ADDITIVE solution exist on the finite cells (atoms mode)?
Unknowns: strictly positive step weights W[c][w][j] (rationals).  L_w(X) = sum_c sum_{j<=r_w(c,X)} W.
Constraints (all exact, linear real arithmetic with disjunctions, z3):
  competitiveness  for every selected C, support s, rival X:  OR_{w in s} L_w(C) <= L_w(X)
  undominated      for every selected C, model X: NOT(all_w L_w(X) <= L_w(C) and some_w L_w(X) < L_w(C))
  KKM              for every non-selected X: OR_{C selected} AND_w L_w(C) <= L_w(X)
Counterexample-guided: solve on an active subset, evaluate every constraint exactly (Fractions ->
integers by common denominator), add the violated ones.  'unsat' on a subset is a proof that no
additive solution exists; 'sat' with no violations is an exact additive solution.
usage: python3 additive_smt.py fam N seeds"""
import sys, time, json
import numpy as np
import z3
from fractions import Fraction
from additive import *

def run(fam, N, seed, log=print, maxit=200, frac=False):
    G, Kf, Ls = load(fam, N, seed)
    sel, _ = selection_atoms(Kf, G, Ls)
    Mo = Models(G)
    seli = {Mo.idx(X): sorted(sel[X][0]) for X in sel}
    S = sorted(seli)
    W = [[[z3.Real('w_%d_%d_%d' % (c, w, j)) for j in (1, 2)] for w in range(3)] for c in range(N)]
    def L(w, X):
        X = Mo.models[X]
        return z3.Sum([W[c][w][j-1] for c in range(N) for j in (1, 2) if Mo.R[w][c][X[c]] >= j] + [z3.RealVal(0)])
    sol = z3.Solver()
    for c in range(N):
        for w in range(3):
            for j in (0, 1): sol.add(W[c][w][j] >= 1)
    # start: KKM for every non-selected model would be too many; start empty
    added = set()
    Wnum = np.ones((N, 6), dtype=object)
    t = time.time()
    for it in range(maxit):
        r = sol.check()
        if r == z3.unsat:
            return 'NO ADDITIVE SOLUTION (z3 unsat on %d active constraints)' % len(added), None, added
        m = sol.model()
        fr = [[[Fraction(str(m.eval(W[c][w][j], model_completion=True).as_fraction())) for j in (0, 1)] for w in range(3)] for c in range(N)]
        den = 1
        for c in range(N):
            for w in range(3):
                for j in (0, 1): den = den * fr[c][w][j].denominator // np.gcd(den, fr[c][w][j].denominator)
        Wi = [[int(fr[c][w][j] * den) for w in range(3) for j in (0, 1)] for c in range(N)]
        # exact integer losses (python ints via object arrays)
        Lm = np.zeros((3, Mo.M), dtype=object)
        for w in range(3):
            for c in range(N):
                r_ = Mo.RK[w][:, c]
                Lm[w] = Lm[w] + (r_ >= 1).astype(object) * Wi[c][2*w] + (r_ >= 2).astype(object) * Wi[c][2*w+1]
        new = []
        for ci, sups in seli.items():
            for s in sups:
                better = np.ones(Mo.M, dtype=bool)
                for w in s: better &= (Lm[w] < Lm[w][ci]).astype(bool)
                for X in np.nonzero(better)[0][:20]: new.append(('comp', ci, tuple(s), int(X)))
            le = np.ones(Mo.M, dtype=bool); lt = np.zeros(Mo.M, dtype=bool)
            for w in range(3):
                le &= (Lm[w] <= Lm[w][ci]).astype(bool); lt |= (Lm[w] < Lm[w][ci]).astype(bool)
            for X in np.nonzero(le & lt)[0][:20]: new.append(('undom', ci, int(X)))
        dom = np.zeros(Mo.M, dtype=bool)
        for ci in S:
            d = np.ones(Mo.M, dtype=bool)
            for w in range(3): d &= (Lm[w][ci] <= Lm[w]).astype(bool)
            dom |= d
        for X in np.nonzero(~dom)[0][:200]: new.append(('kkm', int(X)))
        if frac:
            # fractional rivals (blown-up, atomless neighbourhoods): x[c][a] >= 0, sum_a x[c][a] = 1.
            # LP: maximise t s.t. L_w(x) + t <= L_w(C) for w in s.
            pen = lambda w, c, a: (Wi[c][2*w] if Mo.R[w][c][a] >= 1 else 0) + (Wi[c][2*w+1] if Mo.R[w][c][a] >= 2 else 0)
            for ci, sups in seli.items():
                for s_ in sups:
                    nv = 3*N + 1
                    A = []; b = []
                    for w in s_:
                        row = [float(pen(w, c, a)) for c in range(N) for a in range(3)] + [1.0]
                        A.append(row); b.append(float(Lm[w][ci]))
                    Aeq = np.zeros((N, nv)); 
                    for c in range(N): Aeq[c, 3*c:3*c+3] = 1
                    res = linprog(np.concatenate([np.zeros(3*N), [-1.0]]), A_ub=np.array(A), b_ub=np.array(b), A_eq=Aeq, b_eq=np.ones(N),
                                  bounds=[(0, 1)]*(3*N) + [(None, 1)], method='highs')
                    if res.status == 0 and -res.fun > 1e-7:
                        x = [[Fraction(v).limit_denominator(1000) for v in res.x[3*c:3*c+3]] for c in range(N)]
                        x = [[v/sum(r) for v in r] for r in x]
                        new.append(('frac', ci, tuple(s_), tuple(tuple(r) for r in x)))
        new = [k for k in new if k not in added]
        log('  it %d: new violated constraints %d (active %d) %.0fs' % (it, len(new), len(added), time.time()-t))
        if not new:
            return 'ADDITIVE SOLUTION', Wi, added
        for k in new:
            added.add(k)
            if k[0] == 'comp':
                _, ci, s, X = k; sol.add(z3.Or([L(w, ci) <= L(w, X) for w in s]))
            elif k[0] == 'undom':
                _, ci, X = k
                sol.add(z3.Not(z3.And(z3.And([L(w, X) <= L(w, ci) for w in range(3)]), z3.Or([L(w, X) < L(w, ci) for w in range(3)]))))
            elif k[0] == 'kkm':
                _, X = k
                sol.add(z3.Or([z3.And([L(w, ci) <= L(w, X) for w in range(3)]) for ci in S]))
            else:
                _, ci, s_, x = k
                Lx = lambda w: z3.Sum([z3.RealVal(x[c][a]) * z3.Sum([W[c][w][j-1] for j in (1, 2) if Mo.R[w][c][a] >= j] + [z3.RealVal(0)])
                                       for c in range(N) for a in range(3) if x[c][a] != 0])
                sol.add(z3.Or([L(w, ci) <= Lx(w) for w in s_]))
    return 'UNKNOWN', None, added

if __name__ == '__main__':
    fam = sys.argv[1]; N = int(sys.argv[2]); seeds = [int(a) for a in sys.argv[3].split(',')]
    for seed in seeds:
        t = time.time()
        frac = '--frac' in sys.argv
        res, Wi, added = run(fam, N, seed, log=lambda s: print(s, flush=True), frac=frac)
        print('RESULT additive-SMT%s %s N=%d seed=%d: %s (%.0fs)' % (' (fractional rivals)' if frac else '', fam, N, seed, res, time.time()-t), flush=True)
        json.dump(dict(fam=fam, N=N, seed=seed, f=0 if Wi else -1, W=Wi, active=sorted(map(str, added))),
                  open('additive_smt%s_%s_N%d_s%d.json' % ('_frac' if frac else '', fam, N, seed), 'w'), default=int)
