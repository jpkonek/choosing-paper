"""Search for an ADDITIVE solution on the finite cells (atoms mode): strictly positive step weights
per world and line such that every selected atom model is competitive on each of its supports, no
selected model is weakly dominated, and every non-selected regular model has a selected dominator
at all three worlds.  Counterexample-guided MILP (scipy.optimize.milp / HiGHS) over the weights,
with an exact integer brute-force check of every constraint at each round.
A returned solution is verified exactly (integer weights) and is a genuine additive solution.
usage: python3 additive_milp.py fam N seeds"""
import sys, time, json
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from additive import *

U = 1000.0          # weight upper bound (lower bound 1)

def coef_rows(Mo):
    """loss L_w(X) = Coef[w][X] . Wvec, Wvec index 6*c + 2*w + (j-1)"""
    N = Mo.N
    C = np.zeros((3, Mo.M, 6*N))
    for w in range(3):
        for c in range(N):
            r = Mo.RK[w][:, c]
            C[w][:, 6*c+2*w] = (r >= 1); C[w][:, 6*c+2*w+1] = (r >= 2)
    return C

def solve(fam, N, seed, log=print, maxit=60):
    G, Kf, Ls = load(fam, N, seed)
    sel, _ = selection_atoms(Kf, G, Ls)
    samples, vg = enumerate2(Kf, G, Ls)
    Mo = Models(G)
    seli = {Mo.idx(X): sorted(sel[X][0]) for X in sel}
    S = sorted(seli)
    Cf = coef_rows(Mo)
    nW = 6*N
    BIG = 2*N*U + 10
    # start from hinge-LP weights
    Wl, _ = hinge_lp(G, samples)
    W0 = np.concatenate([np.clip(w, 1, U) for w in Wl])
    comp_set = set(); kkm_set = set(); und_set = set()
    for it in range(maxit):
        Wint = np.round(W0).astype(np.int64)
        L = np.stack([Cf[w] @ Wint for w in range(3)]).astype(np.int64)
        newc = []; newk = []; newu = []
        for ci, sups in seli.items():
            for s in sups:
                better = np.ones(Mo.M, dtype=bool)
                for w in s: better &= L[w] < L[w][ci]
                for X in np.nonzero(better)[0][:50]: newc.append((ci, tuple(s), int(X)))
            weak = (L <= L[:, [ci]]).all(0) & (L < L[:, [ci]]).any(0)
            for X in np.nonzero(weak)[0][:50]: newu.append((ci, int(X)))
        LS = L[:, S]
        dom = np.zeros(Mo.M, dtype=bool)
        for k in range(len(S)): dom |= (LS[:, [k]] <= L).all(0)
        newk = [int(X) for X in np.nonzero(~dom)[0]]
        log('  it %d: competitiveness failures %d, dominated %d, rivals without dominator %d' % (it, len(newc), len(newu), len(newk)))
        if not newc and not newu and not newk:
            return 'ADDITIVE-SOLUTION', Wint, (G, sel, Mo, L)
        comp_set |= set(newc); und_set |= set(newu); kkm_set |= set(newk)
        # build MILP
        cols = nW; rows = []; lb = []; ub = []; integ = [0]*nW
        def addvar():
            nonlocal cols
            cols += 1; integ.append(1); return cols - 1
        A = []   # list of (dict col->coef, lo, hi)
        for (ci, s, X) in comp_set:
            zs = [addvar() for _ in s]
            A.append(({z: 1.0 for z in zs}, 1, np.inf))
            for z, w in zip(zs, s):
                d = Cf[w][ci] - Cf[w][X]       # L_w(C) - L_w(X) <= BIG (1 - z)
                row = {k: float(d[k]) for k in np.nonzero(d)[0]}; row[z] = BIG
                A.append((row, -np.inf, BIG))
        for (ci, X) in und_set:
            ts = [addvar() for _ in range(3)]
            A.append(({t: 1.0 for t in ts}, 1, np.inf))
            for t, w in zip(ts, range(3)):
                d = Cf[w][X] - Cf[w][ci]       # L_w(X) - L_w(C) >= 1 - BIG (1 - t)
                row = {k: float(d[k]) for k in np.nonzero(d)[0]}; row[t] = -BIG
                A.append((row, 1 - BIG, np.inf))
        for X in kkm_set:
            ys = [addvar() for _ in S]
            A.append(({y: 1.0 for y in ys}, 1, np.inf))
            for y, ci in zip(ys, S):
                for w in range(3):
                    d = Cf[w][ci] - Cf[w][X]
                    row = {k: float(d[k]) for k in np.nonzero(d)[0]}; row[y] = BIG
                    A.append((row, -np.inf, BIG))
        from scipy.sparse import lil_matrix
        Mx = lil_matrix((len(A), cols))
        lo = np.zeros(len(A)); hi = np.zeros(len(A))
        for r, (row, l, h) in enumerate(A):
            for k, v in row.items(): Mx[r, k] = v
            lo[r] = l; hi[r] = h
        bl = np.array([1.0]*nW + [0.0]*(cols-nW)); bu = np.array([U]*nW + [1.0]*(cols-nW))
        t0 = time.time()
        res = milp(np.zeros(cols), constraints=LinearConstraint(Mx.tocsr(), lo, hi), integrality=np.array(integ),
                   bounds=Bounds(bl, bu), options=dict(time_limit=float(__import__("os").environ.get("MTL","600"))))
        log('     MILP %d rows %d cols: status %s (%.0fs)' % (len(A), cols, res.status, time.time()-t0))
        if res.status == 2 or res.x is None:
            return 'MILP-INFEASIBLE(within bounds)' if res.status == 2 else 'MILP-FAIL', None, None
        W0 = res.x[:nW]
    return 'UNKNOWN', None, None

if __name__ == '__main__':
    fam = sys.argv[1]; N = int(sys.argv[2]); seeds = [int(a) for a in sys.argv[3].split(',')]
    for seed in seeds:
        t = time.time()
        res, W, extra = solve(fam, N, seed, log=lambda s: print(s, flush=True))
        print('RESULT additive %s N=%d seed=%d: %s (%.0fs)' % (fam, N, seed, res, time.time()-t), flush=True)
        if W is not None:
            json.dump(dict(fam=fam, N=N, seed=seed, W=[int(x) for x in W]), open('additive_%s_N%d_s%d.json' % (fam, N, seed), 'w'))
