"""Additive (Bayes) solutions on the finite cells.

World w uses a fixed strictly positive step weighting: L_w(X) = sum_c sum_{j <= r_w(c,X)} W[w][c][j].
X <=_w Y iff L_w(X) <= L_w(Y).  Such a system satisfies reflexivity, strict (G), (IB) and
transitivity (so (TC) and every triple certificate, with one evaluator for all triples).

Step 1 (Bayes LP, per line): choose W so that at every face sample index p the coherent advice
C_p(c) minimises sum_w p_w pen_w(c, .).  The six weights of a line enter only that line's
constraints, so this is one small LP per line.
Step 2 (exact brute-force check, integer weights): competitiveness on every support of every
selected atom model, KKM dominators for every non-selected regular model, no selected model weakly
dominated.  Usage: python3 additive.py fam N seeds"""
import sys, itertools
import numpy as np
from fractions import Fraction as F
from scipy.optimize import linprog
from common import *
from enum2 import enumerate2

def pen_coeffs(R, w, c, a):
    """pen_w(c,a) as a 0/1 vector over the line's 6 weights (w', j) -> index 2*w'+(j-1)"""
    v = [0]*6
    for j in (1, 2):
        if R[w][c][a] >= j: v[2*w + j - 1] = 1
    return v

def bayes_lp(G, samples, margin=1e-9):
    N = len(G); R = rank_table(G)
    Wl = []; bad = []
    for c in range(N):
        A = []; b = []
        for (p, X, s, kind) in samples:
            if kind != 'face': continue
            a0 = X[c]
            for a in range(3):
                if a == a0: continue
                row = [0.0]*6
                for w in range(3):
                    v0 = pen_coeffs(R, w, c, a0); v1 = pen_coeffs(R, w, c, a)
                    for k in range(6): row[k] += float(p[w])*(v0[k]-v1[k])
                A.append(row); b.append(0.0)
        res = linprog(np.zeros(6), A_ub=np.array(A), b_ub=np.array(b), bounds=[(1, 1e4)]*6, method='highs')
        if res.status != 0:
            bad.append(c); Wl.append(None)
        else:
            Wl.append(res.x)
    return Wl, bad

def losses(Mo, W):
    """W[c] = 6 integer weights; returns L (3, M) int64"""
    L = np.zeros((3, Mo.M), dtype=np.int64)
    for w in range(3):
        for c in range(Mo.N):
            r = Mo.RK[w][:, c]
            L[w] += np.where(r >= 1, W[c][2*w], 0) + np.where(r >= 2, W[c][2*w+1], 0)
    return L

def check(Mo, sel, L):
    seli = {Mo.idx(X): sorted(sel[X][0]) for X in sel}
    cf = 0; uf = 0
    for ci, sups in seli.items():
        for s in sups:
            better = np.ones(Mo.M, dtype=bool)
            for w in s: better &= L[w] < L[w][ci]
            cf += int(better.sum())
        weak = (L <= L[:, [ci]]).all(0) & (L < L[:, [ci]]).any(0)
        uf += int(weak.sum())
    S = np.array(sorted(seli))
    LS = L[:, S]                       # (3, nsel)
    dom = np.zeros(Mo.M, dtype=bool)
    for k in range(len(S)):
        dom |= (LS[:, [k]] <= L).all(0)
    kf = int((~dom).sum())
    return cf, uf, kf

if __name__ == '__main__':
    fam = sys.argv[1]; N = int(sys.argv[2]); seeds = [int(a) for a in sys.argv[3].split(',')]
    for seed in seeds:
        G, Kf, Ls = load(fam, N, seed)
        sel, _ = selection_atoms(Kf, G, Ls)
        samples, vg = enumerate2(Kf, G, Ls)
        Mo = Models(G)
        Wl, bad = bayes_lp(G, samples)
        if bad:
            print('%s N=%d seed=%d: Bayes LP infeasible on lines %s' % (fam, N, seed, bad), flush=True)
            continue
        W = [[int(round(x*1000)) for x in wl] for wl in Wl]
        L = losses(Mo, W)
        cf, uf, kf = check(Mo, sel, L)
        print('%s N=%d seed=%d: Bayes LP feasible; competitiveness failures %d, dominated selected %d, rivals without dominator %d' % (fam, N, seed, cf, uf, kf), flush=True)

def hinge_lp(G, samples, margin=1e-7):
    """per line: minimise total violation of the Bayes inequalities at face samples (each row
    scaled to unit size), weights in [1, 1e4].  Returns weights for every line."""
    N = len(G); R = rank_table(G)
    Wl = []; viol = []
    for c in range(N):
        rows = []
        for (p, X, s, kind) in samples:
            if kind != 'face': continue
            a0 = X[c]
            for a in range(3):
                if a == a0: continue
                row = np.zeros(6)
                for w in range(3):
                    v0 = pen_coeffs(R, w, c, a0); v1 = pen_coeffs(R, w, c, a)
                    row += float(p[w])*(np.array(v0)-np.array(v1))
                nrm = np.abs(row).sum()
                if nrm > 0: rows.append(row/nrm)
        A = np.array(rows); m = len(rows)
        # variables: 6 weights, m slacks;  A w - s <= -margin*?  (use <= 0)
        from scipy import sparse
        Aub = sparse.hstack([sparse.csr_matrix(A), -sparse.identity(m, format='csr')]).tocsr()
        cost = np.concatenate([np.zeros(6), np.ones(m)])
        res = linprog(cost, A_ub=Aub, b_ub=np.zeros(m), bounds=[(1, 1e4)]*6 + [(0, None)]*m, method='highs')
        Wl.append(res.x[:6]); viol.append(int((res.x[6:] > 1e-12).sum()))
    return Wl, viol
