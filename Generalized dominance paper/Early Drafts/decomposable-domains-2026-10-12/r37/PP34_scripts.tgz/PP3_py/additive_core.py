"""Minimal unsatisfiable core for 'no additive solution' (additive_smt_*.json with f = -1), then an
independent re-check: the core constraints are rebuilt from the line normals alone (own ranks,
own model decoding, own coherent-model check at stored sample indices) and handed to z3 again.
usage: python3 additive_core.py additive_smt_<fam>_N<N>_s<seed>.json"""
import sys, json, time
import z3
from common import load, selection_atoms, name, Models

d = json.load(open(sys.argv[1])); assert d['f'] == -1
G, Kf, Ls = load(d['fam'], d['N'], d['seed'])
sel, _ = selection_atoms(Kf, G, Ls)
Mo = Models(G); N = len(G)
S = sorted(Mo.idx(X) for X in sel)
W = [[[z3.Real('w_%d_%d_%d' % (c, w, j)) for j in (1, 2)] for w in range(3)] for c in range(N)]
def L(w, X):
    X = Mo.models[X]
    return z3.Sum([W[c][w][j-1] for c in range(N) for j in (1, 2) if Mo.R[w][c][X[c]] >= j] + [z3.RealVal(0)])
def cons(k):
    if k[0] == 'comp':
        _, ci, s, X = k; return z3.Or([L(w, ci) <= L(w, X) for w in s])
    if k[0] == 'undom':
        _, ci, X = k
        return z3.Not(z3.And(z3.And([L(w, X) <= L(w, ci) for w in range(3)]), z3.Or([L(w, X) < L(w, ci) for w in range(3)])))
    _, X = k; return z3.Or([z3.And([L(w, ci) <= L(w, X) for w in range(3)]) for ci in S])
act = [tuple(tuple(x) if isinstance(x, list) else x for x in k) for k in d['active']]
sol = z3.Solver()
for c in range(N):
    for w in range(3):
        for j in (0, 1): sol.add(W[c][w][j] >= 1)
tr = [z3.Bool('t%d' % i) for i in range(len(act))]
for t, k in zip(tr, act): sol.add(z3.Implies(t, cons(k)))
t0 = time.time()
assert sol.check(tr) == z3.unsat
core = [i for i, t in enumerate(tr) if any(z3.eq(t, u) for u in sol.unsat_core())]
print('initial core', len(core), '%.0fs' % (time.time()-t0), flush=True)
k = 0
while k < len(core):
    trial = core[:k] + core[k+1:]
    if sol.check([tr[i] for i in trial]) == z3.unsat:
        uc = sol.unsat_core(); keep = set(i for i in trial if any(z3.eq(tr[i], u) for u in uc))
        core = [i for i in trial if i in keep]
    else:
        k += 1
print('minimal core', len(core), '%.0fs' % (time.time()-t0), flush=True)
mc = [act[i] for i in core]
for kk in mc:
    if kk[0] == 'comp': print('  comp: selected %s supp %s vs rival %s' % (name(tuple(Mo.models[kk[1]])), kk[2], name(tuple(Mo.models[kk[3]]))))
    elif kk[0] == 'undom': print('  undom: selected %s not dominated by %s' % (name(tuple(Mo.models[kk[1]])), name(tuple(Mo.models[kk[2]]))))
    else: print('  kkm: rival %s needs a selected dominator' % name(tuple(Mo.models[kk[1]])))
json.dump(dict(fam=d['fam'], N=N, seed=d['seed'], G=[[str(a) for a in g] for g in G],
               sel={name(X): [sorted(sel[X][0]), [[str(a) for a in p] for p in sel[X][1]]] for X in sel},
               core=mc), open(sys.argv[1].replace('.json', '_core.json'), 'w'), default=int)
