# PP4 s.2: exact check that the 2-swap records used in s.2 are records out of selected
# models near an interior target, in three worlds:
#  (a) double crossing of world-1 rank steps on four lines (all 12 ordered pairs realised),
#      for the precise family C_p = D_{p} and for a translate family C_p = D_{K_p},
#      K_p = p + (1/10)(T - centre), T the triangle with vertices (1,0,0),(0,1,0),(0,0,1)
#      shrunk; indices p on a rational grid in the disc |p - u| <= 1/5 around u=(1/3,1/3,1/3);
#  (b) for same-class pairs P,Q in M_1 (translate family): both orientations
#      "A on P, S on Q" and "A on Q, S on P" occur (needed for (C-same) in s.3).
from fractions import Fraction as Fr
import itertools

u = (Fr(1, 3),) * 3
# four M_1 lines (g with sign pattern (-,+,+)), passing near u in general position
G = [(-(1 + 1 + Fr(1, 40)), Fr(1), Fr(1)),
     (-(4 + 1 - Fr(1, 30)), Fr(4), Fr(1)),
     (-(1 + 4 + Fr(1, 25)), Fr(1), Fr(4)),
     (-(3 + 2 - Fr(1, 20)), Fr(3), Fr(2))]
# three more lines, one per class M_2, M_3 and another M_1 with different slope
G += [(Fr(1), -(1 + 1 + Fr(1, 35)), Fr(1)), (Fr(2), Fr(1), -(3 - Fr(1, 45)))]

def dot(a, b): return sum(x * y for x, y in zip(a, b))

def advice_precise(p, g):
    s = dot(p, g)
    return 'g' if s > 0 else ('-g' if s < 0 else 'tie')

delta = Fr(1, 10)
V = [tuple(Fr(1) if i == j else Fr(0) for i in range(3)) for j in range(3)]
def K(p):
    return [tuple(p[i] + delta * (v[i] - u[i]) for i in range(3)) for v in V]

def advice_K(p, g):
    vals = [dot(m, g) for m in K(p)]
    if min(vals) > 0: return 'g'
    if max(vals) < 0: return '-g'
    return 'S'

def rank1(adv, g):     # world-1 rank: accepting h is good at world 1 iff h_1 > 0
    if adv == 'S': return 1
    h1 = g[0] if adv == 'g' else -g[0]
    return 0 if h1 > 0 else 2

def maj_advice(adv, g):  # A (good for the two majority worlds), S, or B
    if adv == 'S': return 'S'
    h = g if adv == 'g' else tuple(-x for x in g)
    pos = sum(1 for x in h if x > 0)
    return 'A' if pos == 2 else 'B'

grid = []
r = Fr(1, 5); n = 30
for i in range(-n, n + 1):
    for j in range(-n, n + 1):
        d1, d2 = r * i / n, r * j / n
        p = (u[0] + d1, u[1] + d2, u[2] - d1 - d2)
        if (d1 * d1 + d2 * d2 + (d1 + d2) ** 2) <= r * r:
            grid.append(p)

def steps(adv_fn, p, lines, levels):
    out = set()
    for k, g in enumerate(lines):
        a = adv_fn(p, g)
        if a == 'tie': return None
        rk = rank1(a, g)
        for j in levels:
            if rk >= j: out.add((k, j))
    return out

for name, fn, levels in [("precise D_p", advice_precise, (1,)), ("translates D_{K_p}", advice_K, (1, 2))]:
    locs = [(k, j) for k in range(len(G)) for j in levels]
    realised = set()
    for p in grid:
        U = steps(fn, p, G, levels)
        if U is None: continue
        for x, y in itertools.permutations(locs, 2):
            if y in U and x not in U:
                realised.add((x, y))
    missing = [(x, y) for x, y in itertools.permutations(locs, 2) if (x, y) not in realised]
    # restrict to locations that are not constant over the grid
    var = [x for x in locs if any((x, y) in realised or (y, x) in realised for y in locs)]
    miss_var = [(x, y) for (x, y) in missing if x in var and y in var and x[0] != y[0]]
    print(f"{name}: {len(grid)} indices, {len(locs)} world-1 step locations, "
          f"non-constant {len(var)}, ordered pairs realised {len(realised)}, "
          f"missing among non-constant, different lines {len(miss_var)}")
    if miss_var: print("   missing (x absent, y present):", miss_var)

# (b) orientations for same-class pairs in M_1 (lines 0..3), translate family
M1 = [0, 1, 2, 3]
for P, Q in itertools.permutations(M1, 2):
    found = any(maj_advice(advice_K(p, G[P]), G[P]) == 'A' and maj_advice(advice_K(p, G[Q]), G[Q]) == 'S' for p in grid)
    print(f"  M_1 pair ({P},{Q}): some selected model is A on P and S on Q: {found}")
