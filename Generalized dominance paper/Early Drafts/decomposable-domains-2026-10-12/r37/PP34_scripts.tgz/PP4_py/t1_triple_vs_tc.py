# PP4 Theorem 1 check: on three models, a strictly guiding additive certificate exists
# iff (TC) holds, given (G) (weak and strict).  One world.
#
# Reduction (proved in PP4 s.1): a triple of models is described, up to the certificate
# question, by the set T of non-constant "types" t = (t_X, t_Y, t_Z) in {0,1}^3 that occur
# on a non-null set of rank steps.  A certificate is a vector c_t > 0 (t in T): the f-mass
# of the steps of type t.  F(U) - F(V) = sum_t c_t (t_U - t_V).
#
# We enumerate every T with X, Y, Z pairwise distinct and every relation on {X,Y,Z}
# (6 ordered pairs, reflexive), keep those satisfying (G), and compare (TC) with
# certificate existence.  Certificates found by LP are re-verified in exact rationals.
# Control: drop the weak half of (G) and show TC no longer suffices.
import itertools
from fractions import Fraction as Fr
from scipy.optimize import linprog

M = 3                                      # models 0=X, 1=Y, 2=Z
TYPES = [t for t in itertools.product((0, 1), repeat=3) if len(set(t)) == 2]   # 6 non-constant
PAIRS = [(u, v) for u in range(M) for v in range(M) if u != v]

def distinct(T):
    return all(any(t[u] != t[v] for t in T) for u, v in [(0, 1), (0, 2), (1, 2)])

def subset(T, u, v):          # U_i(u) subset of U_i(v)  (u pointwise weakly better)
    return all(t[u] <= t[v] for t in T)

def g_ok(T, rel, weak=True):
    for u, v in PAIRS:
        if subset(T, u, v):                 # u weakly better than v (strictly, as distinct)
            if weak and (u, v) not in rel:
                return False                # weak (G): worsening u -> v accepted
            if (v, u) in rel:
                return False                # strict (G): improvement v -> u refused
    return True

def strict(rel, u, v):
    return (u, v) in rel and (v, u) not in rel

def tc_ok(rel):
    for a, b, c in itertools.permutations(range(M), 3):
        if (a, b) in rel and (b, c) in rel and strict(rel, c, a):
            return False
    return True

def exact_check(T, rel, c):
    for u, v in rel:
        d = sum(c[k] * (t[u] - t[v]) for k, t in enumerate(T))   # F(u) - F(v)
        if d > 0: return False
        if strict(rel, u, v) and d >= 0: return False
    return all(x > 0 for x in c)

def certificate(T, rel):
    # homogeneous system; normalise c_t >= 1, strict margins >= 1
    A, b = [], []
    for u, v in rel:
        row = [t[u] - t[v] for t in T]
        A.append(row); b.append(-1 if strict(rel, u, v) else 0)
    if not A:
        return [Fr(1)] * len(T)
    res = linprog([0] * len(T), A_ub=A, b_ub=b, bounds=[(1, None)] * len(T), method="highs")
    if res.status != 0:
        return None
    for den in (1, 2, 3, 4, 6, 12, 60, 1000):
        c = [Fr(x).limit_denominator(den) for x in res.x]
        if exact_check(T, rel, c):
            return c
    # small integer search as fallback
    for c in itertools.product(range(1, 7), repeat=len(T)):
        c = [Fr(x) for x in c]
        if exact_check(T, rel, c):
            return c
    return "LP-feasible-but-not-verified"

def run(weak):
    stats = dict(cases=0, tc=0, tc_cert=0, tc_nocert=0, notc_cert=0, unverified=0)
    examples = []
    for r in range(1, len(TYPES) + 1):
        for T in itertools.combinations(TYPES, r):
            if not distinct(T):
                continue
            for mask in range(1 << len(PAIRS)):
                rel = {PAIRS[k] for k in range(len(PAIRS)) if mask >> k & 1}
                if not g_ok(T, rel, weak):
                    continue
                stats['cases'] += 1
                tc = tc_ok(rel)
                c = certificate(T, rel)
                if c == "LP-feasible-but-not-verified":
                    stats['unverified'] += 1; continue
                has = c is not None
                if tc:
                    stats['tc'] += 1
                    if has: stats['tc_cert'] += 1
                    else:
                        stats['tc_nocert'] += 1
                        if len(examples) < 2: examples.append((T, sorted(rel)))
                elif has:
                    stats['notc_cert'] += 1
    return stats, examples

if __name__ == "__main__":
    s, ex = run(weak=True)
    print("With (G) [weak + strict]:", s)
    print("  => TC <=> certificate:", s['tc_nocert'] == 0 and s['notc_cert'] == 0 and s['unverified'] == 0)
    s2, ex2 = run(weak=False)
    print("Control, strict (G) only:", s2)
    for T, rel in ex2:
        print("  TC holds, no certificate: types", T, "relation", rel)
