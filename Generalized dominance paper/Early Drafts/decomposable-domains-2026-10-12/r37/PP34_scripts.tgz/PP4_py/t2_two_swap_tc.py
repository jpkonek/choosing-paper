# PP4 s.2: exact (TC) check of "two-swap" worlds on finite cells, one world.
# 4 regions a,b,c,d, 3 atoms per region with masses 1,2,4 (any subset mass 0..7);
# a model = set of present rank steps = 12-bit mask; 4096 models; smaller is better.
# Rule S (swap-only): X <= Y iff Y adds nothing removed... precisely:
#   guidance: X \ Y empty; or 2-swap: Y\X inside one region x, X\Y inside one region y != x,
#   both non-empty, and m(Y\X) >= rho[x][y] * m(X\Y).
# Rule M (monotone closure): X\Y inside one region y (non-empty) and for some x != y,
#   m((Y\X) cap R_x) >= rho[x][y] m(X\Y)  (additions elsewhere only help).
# (TC) violation: X<=Y, Y<=Z, Z<=X, not X<=Z.  Checked for all 4096^3 triples by a
# boolean matrix product.  All comparisons in exact integer arithmetic.
import sys, itertools
import numpy as np
from fractions import Fraction as Fr

R, K = 4, 3
MASS = [1, 2, 4]
N = 1 << (R * K)
chunk_mass = np.array([sum(MASS[k] for k in range(K) if s >> k & 1) for s in range(1 << K)], dtype=np.int64)

def accept_matrix(rho, rule):
    X = np.arange(N, dtype=np.int64)[:, None]
    Y = np.arange(N, dtype=np.int64)[None, :]
    add = Y & ~X & (N - 1)
    rem = X & ~Y & (N - 1)
    addm = [chunk_mass[(add >> (K * r)) & 7] for r in range(R)]
    remm = [chunk_mass[(rem >> (K * r)) & 7] for r in range(R)]
    acc = (rem == 0)
    nrem = sum((m > 0).astype(np.int8) for m in remm)
    nadd = sum((m > 0).astype(np.int8) for m in addm)
    for x in range(R):
        for y in range(R):
            if x == y or rho[x][y] is None:
                continue
            q = Fr(rho[x][y]); num, den = q.numerator, q.denominator
            ok = (remm[y] > 0) & (nrem == 1) & (addm[x] * den >= num * remm[y])
            if rule == 'S':
                ok &= (addm[x] > 0) & (nadd == 1)
            acc |= ok
    return acc

def tc_violations(acc):
    A = acc.astype(np.float32)
    P = (A @ A) > 0.5                 # P[X,Z]: some Y with X<=Y<=Z
    V = P & acc.T & ~acc              # Z<=X and not X<=Z
    return int(V.sum()), np.argwhere(V)[:1]

def show(m):
    return "".join("abcd"[r] + str(chunk_mass[(m >> (K * r)) & 7]) + " " for r in range(R) if (m >> (K*r)) & 7)

h, t2, t8 = Fr(1, 2), Fr(2), Fr(8)
a, b, c, d = range(4)
def mat(entries):
    m = [[None] * R for _ in range(R)]
    for (x, y), v in entries.items(): m[x][y] = v
    return m
E = {(a, b): h, (b, c): h, (c, d): h, (d, a): h,
     (b, a): t2, (c, b): t2, (d, c): t2, (a, d): t2,
     (a, c): t8, (c, a): t8, (b, d): t8, (d, b): t8}
CASES = {
  "E  (neg. 4-cycle; all 2-,3-cycles positive)": mat(E),
  "C1 (triangle abc negative: rho_ca=1)": mat({**E, (c, a): Fr(1)}),
  "C2 (pair ab negative: rho_ba=1)": mat({**E, (b, a): Fr(1)}),
  "C3 (triangle abc product exactly 1, pairs not reciprocal)": mat({(a, b): h, (b, c): h, (c, a): Fr(4), (b, a): Fr(4), (c, b): Fr(4), (a, c): Fr(4)}),
  "C4 (triangle product 1, pairs reciprocal)": mat({(a, b): h, (b, c): h, (c, a): Fr(4), (b, a): t2, (c, b): t2, (a, c): Fr(1, 4)}),
  "C5 (sticky everywhere, rho=1/2: Remark 10)": mat({(x, y): h for x in range(R) for y in range(R) if x != y}),
  "C6 (spread everywhere, rho=2)": mat({(x, y): t2 for x in range(R) for y in range(R) if x != y}),
}

def neg_cycle(rho):
    # region-constant potential w exists iff no cycle with product of rho < 1 (Bellman-Ford on logs, exact via products)
    best = None
    for k in range(2, R + 1):
        for cyc in itertools.permutations(range(R), k):
            if cyc[0] != min(cyc): continue
            prod = Fr(1)
            for i in range(k):
                v = rho[cyc[i]][cyc[(i + 1) % k]]
                if v is None: prod = None; break
                prod *= v
            if prod is not None and prod < 1 and (best is None or k < len(best[0])):
                best = (cyc, prod)
    return best

if __name__ == "__main__":
    for name, rho in CASES.items():
        nc = neg_cycle(rho)
        for rule in ("S", "M"):
            acc = accept_matrix(rho, rule)
            nv, ex = tc_violations(acc)
            line = f"{name:58s} rule {rule}: accepted pairs {int(acc.sum()):9d}  TC violations {nv:9d}"
            if nv:
                X, Z = ex[0]
                line += f"   e.g. X=[{show(X)}] Z=[{show(Z)}]"
            print(line)
        print("    shortest cycle with rho-product < 1 (no region-constant potential):", nc)
        sys.stdout.flush()
