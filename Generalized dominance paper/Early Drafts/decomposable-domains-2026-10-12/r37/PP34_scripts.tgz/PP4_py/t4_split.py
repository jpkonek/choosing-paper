# PP4 s.3, Proposition 3.2 check: three same-class lines x,y,z in M_w, all six
# orientations realised out of selected models.  Scale-free 2-swap thresholds (logs):
#   minority world w: rw[(y,x)] for "add y, remove x";  majority worlds j,k: rj, rk.
# Covering of the record "x: A->S, y: S->A" out of a model that is A on x, S on y:
#   min(rj[(x,y)], rk[(x,y)]) + rw[(y,x)] <= 0.
# (TC) at each world on the 2-swap layer: pair sums >= 0, 3-cycle sums >= 0 (strictly here,
# so the equality clause (E) never triggers).
# For each of the 64 assignments "which majority world covers (x,y)", decide feasibility.
# Feasible ones are certified by an exact rational solution; infeasible ones by an exact
# combinatorial certificate (a pair or a 3-cycle whose covering inequalities sum to a
# contradiction with (P)/(T)).  An LP (HiGHS) cross-checks all 64.
import itertools
from fractions import Fraction as Fr
from scipy.optimize import linprog

L = [0, 1, 2]
OP = list(itertools.permutations(L, 2))          # 6 ordered pairs
CYC = [(0, 1, 2), (0, 2, 1)]

def tc_ok(r, strict=True):
    for x, y in OP:
        if x < y and r[(x, y)] + r[(y, x)] < 0: return False
    for c in CYC:
        s = r[(c[0], c[1])] + r[(c[1], c[2])] + r[(c[2], c[0])]
        if (s <= 0 if strict else s < 0): return False
    return True

def lp_feasible(assign, rw, eps=1e-6):
    # variables: rj[op], rk[op] (12); constraints A_ub v <= b
    idx = {('j', op): i for i, op in enumerate(OP)}; idx.update({('k', op): 6 + i for i, op in enumerate(OP)})
    A, b = [], []
    for op in OP:
        x, y = op
        row = [0] * 12; row[idx[(assign[op], op)]] = 1; A.append(row); b.append(-rw[(y, x)])
    for wld in 'jk':
        for x, y in OP:
            if x < y:
                row = [0] * 12; row[idx[(wld, (x, y))]] = -1; row[idx[(wld, (y, x))]] = -1; A.append(row); b.append(0)
        for c in CYC:
            row = [0] * 12
            for e in [(c[0], c[1]), (c[1], c[2]), (c[2], c[0])]: row[idx[(wld, e)]] -= 1
            A.append(row); b.append(-eps)
    res = linprog([0] * 12, A_ub=A, b_ub=b, bounds=[(-50, 50)] * 12, method="highs")
    return res.status == 0

def classify(assign):
    # split pairs and acyclicity of each world's covered set
    for x, y in OP:
        if x < y and assign[(x, y)] == assign[(y, x)]:
            return ("same world covers both orientations of", (x, y))
    for wld in 'jk':
        O = {op for op in OP if assign[op] == wld}
        for c in CYC:
            if {(c[0], c[1]), (c[1], c[2]), (c[2], c[0])} <= O:
                return ("cyclic covered set at world " + wld, c)
    return None

def exact_solution(assign, rw):
    # covered orientations of j form a total order (if classify() is None); put
    # r = -(rw of reverse) on covered edges, and a large value on uncovered ones
    big = Fr(10)
    rj = {op: (-rw[(op[1], op[0])] if assign[op] == 'j' else big) for op in OP}
    rk = {op: (-rw[(op[1], op[0])] if assign[op] == 'k' else big) for op in OP}
    ok = tc_ok(rj) and tc_ok(rk)
    for x, y in OP:
        ok &= min(rj[(x, y)], rk[(x, y)]) + rw[(y, x)] <= 0
    return ok

for label, rw in [("rw = +1 on all pairs (strict spread at the minority world)", {op: Fr(1) for op in OP}),
                  ("rw = 0 (reciprocal at the minority world)", {op: Fr(0) for op in OP})]:
    feas, n_lp, bad = [], 0, 0
    for choice in itertools.product('jk', repeat=6):
        assign = dict(zip(OP, choice))
        lp = lp_feasible(assign, rw)
        n_lp += lp
        cl = classify(assign)
        if cl is None:
            ex = exact_solution(assign, rw)
            if ex: feas.append(assign)
            if ex != lp: bad += 1
        else:
            # exact certificate of infeasibility exists only when rw pair/cycle sums are > 0
            if cl[0].startswith("same"):
                x, y = cl[1]; cert = rw[(x, y)] + rw[(y, x)] > 0
            else:
                c = cl[1]; cert = rw[(c[1], c[0])] + rw[(c[2], c[1])] + rw[(c[0], c[2])] >= 0
            if cert and lp: bad += 1
    print(label)
    print(f"   LP-feasible assignments: {n_lp} / 64;  split + transitive with exact solution: {len(feas)};  disagreements: {bad}")
    for a in feas:
        order_j = sorted(L, key=lambda v: -sum(1 for w in L if w != v and a[(v, w)] == 'j'))
        print("     world j covers 'add earlier, remove later' along", order_j, "; world k the reverse")
