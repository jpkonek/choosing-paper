"""PP35 general_seam_algebra.py -- CHECKED (exact rationals).

Pointwise algebra behind Theorem A (PP32 Thm 3.1 for general fields).
On W_12 at edge weights (a, b), relative to the all-correct baseline, the expected
penalties are: 1-correct b(al2+be2), 2-correct a(al1+be1), silence a al1 + b al2
(contradiction is worse than both acceptances).  kappa = a/b.
Claims (random positive rationals):
 (1) P_1-type point (edge model silent or 2-correct is optimal):
       2-correct optimal                       => al2 >= kappa be1;
       silent optimal and al1 al2 >= be1 be2   => al2 >= kappa be1  (in fact equality);
 (2) P_2-type point (edge model silent or 1-correct is optimal):
       1-correct optimal                       => be2 <= kappa al1;
       silent optimal and al1 al2 >= be1 be2   => be2 <= kappa al1;
 (3) without (H4) both inequalities can fail at a silent point (an instance is printed);
 (4) the fill: pieces A1 (M_1), A2 (M_2), A3 (M_3) carrying the needed inequalities, masses
     chosen with be1(A1) = al1(A2) and A3 small, give a majority fill out of a model silent on
     all three pieces whose values are negative at worlds 1, 2 and 3 (random finite instances).
Run: python3 -I -B general_seam_algebra.py > general_seam_algebra.out
"""
import random
from fractions import Fraction as F

random.seed(3503)
fails = 0


def rp():
    return F(random.randint(1, 400), random.randint(1, 60))


def best(a, b, al1, al2, be1, be2):
    cost = {"1c": b * (al2 + be2), "2c": a * (al1 + be1), "s": a * al1 + b * al2}
    m = min(cost.values())
    return {k for k, v in cost.items() if v == m}


n1 = n2 = 0
witness = None
for _ in range(200000):
    a, b = rp(), rp()
    kap = a / b
    al1, al2, be1, be2 = rp(), rp(), rp(), rp()
    opt = best(a, b, al1, al2, be1, be2)
    h4 = al1 * al2 >= be1 * be2
    if "2c" in opt and not al2 >= kap * be1:
        fails += 1
        print("FAIL (1) 2c", a, b, al1, al2, be1, be2)
    if "s" in opt and h4 and not al2 >= kap * be1:
        fails += 1
        print("FAIL (1) s", a, b, al1, al2, be1, be2)
    if "1c" in opt and not be2 <= kap * al1:
        fails += 1
        print("FAIL (2) 1c", a, b, al1, al2, be1, be2)
    if "s" in opt and h4 and not be2 <= kap * al1:
        fails += 1
        print("FAIL (2) s", a, b, al1, al2, be1, be2)
    if "s" in opt:
        n1 += 1
        if not h4 and al2 < kap * be1 and be2 > kap * al1 and witness is None:
            witness = (a, b, al1, al2, be1, be2)
    n2 += 1
if witness is None:
    fails += 1
    print("FAIL (3): no witness found")

# (4) fills
n4 = 0
for _ in range(20000):
    kap = rp()
    # A1 (M_1): alpha/beta densities treated as constants per piece; enforce al2 >= kap be1
    be1_1, al2_1, al3_1 = rp(), None, rp()
    al2_1 = kap * be1_1 + rp() / 1000 * random.randint(0, 1)
    # A2 (M_2): enforce be2 <= kap al1
    al1_2, al3_2 = rp(), rp()
    be2_2 = kap * al1_2 - (kap * al1_2) * F(random.randint(0, 999), 1000)
    # A3 (M_3)
    al1_3, al2_3, be3_3 = rp(), rp(), rp()
    # masses: m1 be1_1 = m2 al1_2 ; m3 small
    m1 = F(1)
    m2 = m1 * be1_1 / al1_2
    m3 = min(m1 * al3_1 + m2 * al3_2, F(1)) / (2 * be3_3 + 1)
    w1 = m1 * be1_1 - m2 * al1_2 - m3 * al1_3
    w2 = -m1 * al2_1 + m2 * be2_2 - m3 * al2_3
    w3 = -m1 * al3_1 - m2 * al3_2 + m3 * be3_3
    if not (w1 < 0 and w2 < 0 and w3 < 0):
        fails += 1
        print("FAIL (4)", w1, w2, w3)
    n4 += 1

print(f"(1),(2): {n2} random (weights, densities); {n1} with silence optimal")
print(f"(3) witness without (H4): a,b,al1,al2,be1,be2 = {tuple(str(x) for x in witness)}")
print(f"(4) {n4} random fills negative at all three worlds")
print("ALL PASS" if fails == 0 else f"{fails} FAILURES")
