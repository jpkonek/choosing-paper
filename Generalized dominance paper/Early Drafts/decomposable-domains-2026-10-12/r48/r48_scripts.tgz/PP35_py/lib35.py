"""PP35 shared helpers (exact rational arithmetic).

Conventions as in PP32: problems g in R^3 modulo sign; an answer is +1 (accept g),
-1 (accept -g), 0 (silent), 'X' (both).  Rank at world w: correct 0, silent 1,
wrong 2, contradictory 3.  T1 = D_M, M = c*1 + eps*Delta, c = (1-eps)/3.

A *general additive field* is given per problem g and world w by three positive numbers
  alpha_w(g) = l_w(silent) - l_w(correct),
  beta_w(g)  = l_w(wrong)  - l_w(silent),
  gamma_w(g) = l_w(contra) - l_w(wrong),
with l_w(correct) = 0.  Rank-linear fields are alpha = beta = gamma = rho_w(g).
"""
from fractions import Fraction as F

ANS = [1, -1, 0, 'X']


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def sgn(x):
    return (x > 0) - (x < 0)


def T_answer(g, eps):
    c = (1 - eps) / 3
    lo = c * sum(g) + eps * min(g)
    hi = c * sum(g) + eps * max(g)
    if lo > 0:
        return 1
    if hi < 0:
        return -1
    if lo < 0 < hi:
        return 0
    return None


def DK_answer(V, g):
    vals = [dot(v, g) for v in V]
    if min(vals) > 0:
        return 1
    if max(vals) < 0:
        return -1
    if min(vals) < 0 < max(vals):
        return 0
    return None


def rank(ans, g, w):
    if ans == 'X':
        return 3
    if ans == 0:
        return 1
    return 0 if ans * sgn(g[w]) > 0 else 2


def minority(g):
    s = [sgn(x) for x in g]
    if 0 in s:
        return None
    pos = [w for w in range(3) if s[w] > 0]
    neg = [w for w in range(3) if s[w] < 0]
    if len(pos) == 1:
        return pos[0]
    if len(neg) == 1:
        return neg[0]
    return None


def penalty(abg, ans, g, w):
    """l_w(g, ans) from (alpha, beta, gamma) at world w."""
    a, b, gm = abg[w]
    r = rank(ans, g, w)
    return [0, a, a + b, a + b + gm][r]


def bayes(abg, lam, g):
    """Return (unique minimiser or None if tie, sorted cost list)."""
    costs = {a: sum(lam[w] * penalty(abg, a, g, w) for w in range(3)) for a in ANS}
    best = min(costs.values())
    arg = [a for a in ANS if costs[a] == best]
    return (arg[0] if len(arg) == 1 else None), costs
