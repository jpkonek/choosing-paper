"""PP35 boxes_selection.py -- CHECKED (exact rationals).

The abstention field of 'Coverage after Neutral Abstention' eqs (3)-(4), in PP32's setting:
  mixed problems:     alpha_w = lam_w |g_w|,  beta_w = eta_w |g_w|,  gamma_w = (lam_w+eta_w)|g_w|
  unanimous problems: alpha_w = beta_w = |g_w|, gamma_w = 2|g_w|
with 0 < lam_w < eta_w (silence cheaper than the rank-linear midpoint).
Claims checked:
 (a) for random rational p in Delta (interior, edges, vertices) and random rational g, the
     pointwise expected-penalty minimiser is unique and equals the answer of D_{K_p},
     K_p = conv{ normalise(p (.) a) : a_w in {lam_w, eta_w} } (normalised box);
 (b) K_u has six distinct extreme points inside int Delta (an imprecise interior hexagon);
 (c) the field violates PP32-repair hypothesis (H4): alpha_i alpha_j < beta_i beta_j everywhere;
 (d) Corollary A' bookkeeping: for every rational edge weight ratio t, the edge Bayes model's
     silent window [t lam_1/eta_2, t eta_1/lam_2] is NOT inside N's seam band
     J_N = (lam_1/eta_2, eta_1/lam_2), N = D_{K_u}; it reaches an end of J_N.
Together with v3 thm:general (uniqueness => (LA),(S),(C), closed sections) this is a full
(S)-system with all Brief-48 axioms selecting an imprecise interior model; so PP32 Cor 3.3
does not extend to general additive fields.
Run: python3 -I -B boxes_selection.py > boxes_selection.out
"""
import random
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from lib35 import DK_answer, minority, bayes, sgn
from itertools import product

random.seed(3501)
LAM = [F(1), F(1), F(2)]
ETA = [F(2), F(3), F(3)]
fails = 0


def field(g):
    k = minority(g)
    if k is None:
        return [(abs(x), abs(x), 2 * abs(x)) for x in g]
    return [(LAM[w] * abs(g[w]), ETA[w] * abs(g[w]), (LAM[w] + ETA[w]) * abs(g[w])) for w in range(3)]


def Kverts(p):
    V = []
    for a in product(*[(LAM[w], ETA[w]) for w in range(3)]):
        v = [p[w] * a[w] for w in range(3)]
        s = sum(v)
        V.append(tuple(x / s for x in v))
    return V


def rand_p():
    r = random.random()
    if r < 0.1:
        e = [F(0)] * 3
        e[random.randrange(3)] = F(1)
        return tuple(e)
    x = [F(random.randint(1, 50)) for _ in range(3)]
    if r < 0.4:
        x[random.randrange(3)] = F(0)
    s = sum(x)
    return tuple(v / s for v in x)


na = nties = 0
for _ in range(400):
    p = rand_p()
    V = Kverts(p)
    for _ in range(60):
        g = tuple(F(random.randint(-300, 300), 37) for _ in range(3))
        if 0 in [sgn(x) for x in g]:
            continue
        b, _c = bayes(field(g), p, g)
        dk = DK_answer(V, g)
        if b is None or dk is None:
            nties += 1
            continue
        if b != dk:
            fails += 1
            print("FAIL (a)", p, g, b, dk)
        na += 1

def hull2(P):
    """Extreme points of a planar point set (exact monotone chain on (q1, q2))."""
    P = sorted(set((v[0], v[1]) for v in P))

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lower, upper = [], []
    for pt in P:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], pt) <= 0:
            lower.pop()
        lower.append(pt)
    for pt in reversed(P):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], pt) <= 0:
            upper.pop()
        upper.append(pt)
    return [(x, y, 1 - x - y) for (x, y) in lower[:-1] + upper[:-1]]


u = (F(1, 3),) * 3
ext = hull2(Kverts(u))
if len(ext) < 3 or any(min(v) <= 0 for v in ext):
    fails += 1
    print("FAIL (b)", ext)

nc = 0
for _ in range(5000):
    g = tuple(F(random.randint(-300, 300), 37) for _ in range(3))
    k = minority(g)
    if k is None:
        continue
    f = field(g)
    for j in range(3):
        if j != k and not f[k][0] * f[j][0] < f[k][1] * f[j][1]:
            fails += 1
            print("FAIL (c)", g)
    nc += 1

nd = 0
lo, hi = LAM[0] / ETA[1], ETA[0] / LAM[1]
for num in range(1, 200):
    t = F(num, 40)
    t0, t1 = t * LAM[0] / ETA[1], t * ETA[0] / LAM[1]
    inside = lo < t0 and t1 < hi
    if inside:
        fails += 1
        print("FAIL (d)", t)
    nd += 1

print(f"(a) {na} (p, g) pairs agree with the normalised box ({nties} sampled ties skipped)")
print(f"(b) K_u extreme points: {[tuple(str(x) for x in v) for v in ext]}")
print(f"(c) {nc} mixed problems violate (H4) strictly at both seam pairs")
print(f"(d) {nd} edge weights: no edge window inside J_N = ({lo}, {hi})")
print("ALL PASS" if fails == 0 else f"{fails} FAILURES")
