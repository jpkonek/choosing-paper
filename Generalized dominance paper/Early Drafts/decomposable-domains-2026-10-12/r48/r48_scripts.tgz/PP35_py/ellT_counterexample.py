"""PP35 ellT_counterexample.py -- CHECKED (exact rationals), eps in {1/10, 3/10, 1/2, 9/10}.

The field l^T.  L = (c+eps)/c = beta, 1/L = alpha, d = 1/(1+L) = c/(2c+eps).
  F(th) = th/(2d)               on (0, d]
        = 1/2 + L(th-d)/(2d)    on [d, 1/L]
        = L th                  on [1/L, oo)
  G(s)  = 1/F(1/s).
For a problem g in M_i (i the minority world), s_j = |g_j|/|g_i| (j != i):
  alpha_i = beta_i = |g_i|,  beta_j = |g_i| F(s_j),  alpha_j = |g_i| G(s_j),  gamma_w = |g_w|.
Unanimous problems: alpha = beta = gamma = |g_w|.
Claims checked:
 (a) d = c/(2c+eps); F continuous at d and 1/L; F(th) F(1/th) > 1 on a grid incl. breakpoints
     (so G < F: the field is non-adjacent, an abstention field);
 (b) at lambda = u the expected-penalty minimiser is unique and equals T1's answer
     (random rational g, all classes): T1 is u-Bayes, hence competitive at every world;
 (c) at every sampled rational edge weight (t/(1+t), 1/(1+t), 0) the minimiser is unique and
     equals D_K with K the edge segment whose thresholds are F^{-1}(t), G^{-1}(t):
     a coherent edge selection (Theorem 3.1's (H2) holds with closed sections);
     at t = 1 this K is the 'shadow' [(d,1-d,0),(1-d,d,0)];
 (d) every edge window [F^{-1}(t), G^{-1}(t)] reaches alpha or beta (Corollary A'): t<=1
     gives tau_0 <= alpha, t>=1 gives tau_1 >= beta;
 (e) an interior weight p where the p-Bayes model is incoherent: gambles g1, g2 accepted
     with strict margins, their midpoint strictly not accepted.  (F is not convex at 1/L.)
So l^T satisfies every hypothesis of PP32 Thm 3.1 with l^T-endorsement in place of
rho-endorsement, and the conclusion fails; and l^T cannot be completed to an (S)-system
(Contamination Triangle Prop. 'necessary' (a): interior Bayes models must be coherent).
Run: python3 -I -B ellT_counterexample.py > ellT_counterexample.out
"""
import random
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from lib35 import T_answer, DK_answer, minority, bayes, sgn

random.seed(3502)
fails = 0


def check(cond, msg):
    global fails
    if not cond:
        fails += 1
        print("FAIL:", msg)


def make(eps):
    c = (1 - eps) / 3
    L = (c + eps) / c
    d = 1 / (1 + L)

    def Ff(th):
        if th <= d:
            return th / (2 * d)
        if th <= 1 / L:
            return Fr(1, 2) + L * (th - d) / (2 * d)
        return L * th

    def Finv(y):
        if y <= Fr(1, 2):
            return 2 * d * y
        if y <= 1:
            return d + (y - Fr(1, 2)) * 2 * d / L
        return y / L

    def G(s):
        return 1 / Ff(1 / s)

    def Ginv(t):
        return 1 / Finv(1 / t)

    def field(g):
        k = minority(g)
        if k is None:
            return [(abs(x), abs(x), abs(x)) for x in g]
        gi = abs(g[k])
        out = []
        for w in range(3):
            if w == k:
                out.append((gi, gi, abs(g[w])))
            else:
                s = abs(g[w]) / gi
                out.append((gi * G(s), gi * Ff(s), abs(g[w])))
        return out
    return c, L, d, Ff, Finv, G, Ginv, field


for eps in [Fr(1, 10), Fr(3, 10), Fr(1, 2), Fr(9, 10)]:
    c, L, d, Ff, Finv, G, Ginv, field = make(eps)
    alpha, beta = 1 / L, L
    # (a)
    check(d == c / (2 * c + eps), "d")
    check(Ff(d) == Fr(1, 2) and Ff(1 / L) == 1 and Fr(1, 2) + L * (1 / L - d) / (2 * d) == 1, "continuity")
    grid = [Fr(k, 64) for k in range(1, 64 * 12)] + [d, 1 / L, L, 1 / d]
    mn = min(Ff(t) * Ff(1 / t) for t in grid)
    check(mn > 1, f"F(t)F(1/t) min {mn}")
    for y in [Fr(k, 37) for k in range(1, 200)]:
        check(Ff(Finv(y)) == y and G(Ginv(y)) == y, "inverse")
    # (b)
    u = (Fr(1, 3),) * 3
    nb = 0
    for _ in range(6000):
        g = tuple(Fr(random.randint(-400, 400), 53) for _ in range(3))
        if 0 in [sgn(x) for x in g]:
            continue
        tA = T_answer(g, eps)
        b, _ = bayes(field(g), u, g)
        if tA is None or b is None:
            continue
        check(b == tA, f"(b) eps={eps} g={g} bayes={b} T={tA}")
        nb += 1
    # (c), (d)
    nc = 0
    for num in list(range(1, 120)) + [40]:
        t = Fr(num, 40)
        lam = (t / (1 + t), 1 / (1 + t), Fr(0))
        tau0, tau1 = Finv(t), Ginv(t)
        check(tau0 < tau1, "window order")
        x0, x1 = tau0 / (1 + tau0), tau1 / (1 + tau1)
        K = [(x0, 1 - x0, Fr(0)), (x1, 1 - x1, Fr(0))]
        if t == 1:
            check(x0 == d and x1 == 1 - d, "shadow at t=1")
        check(tau0 <= alpha or tau1 >= beta, "(d) window inside J")
        check((t <= 1) <= (tau0 <= alpha) and (t >= 1) <= (tau1 >= beta), "(d) sides")
        for _ in range(40):
            g = tuple(Fr(random.randint(-400, 400), 53) for _ in range(3))
            if 0 in [sgn(x) for x in g]:
                continue
            b, _ = bayes(field(g), lam, g)
            dk = DK_answer(K, g)
            if b is None or dk is None:
                continue
            check(b == dk, f"(c) eps={eps} t={t} g={g} bayes={b} DK={dk}")
            nc += 1
    # (e) incoherent interior Bayes model near the edge [e1,e2]
    l1, l2, eta = Fr(1), Fr(4), Fr(1, 200)
    S = l1 + l2 + eta
    p = (l1 / S, l2 / S, eta / S)
    delta = (1 / L) / 4

    def bnd(s3):            # boundary s2 for minority acceptance, valid while it is < d
        return 2 * d * (l1 - eta * Ff(s3)) / l2
    s3a, s3b = 1 / L - delta, 1 / L + delta
    gap = (bnd(s3a) + bnd(s3b)) / 2 - bnd(1 / L)
    check(gap > 0, "(e) no convexity defect")
    zeta = gap / 2
    pts = []
    for s3 in (s3a, s3b):
        s2 = bnd(s3) - zeta
        check(0 < s2 < d, "(e) s2 range")
        pts.append((Fr(1), -s2, -s3))
    mid = tuple((a + b) / 2 for a, b in zip(*pts))
    res = []
    for g in pts + [mid]:
        b, costs = bayes(field(g), p, g)
        res.append(b)
    check(res[0] == 1 and res[1] == 1 and res[2] is not None and res[2] != 1,
          f"(e) eps={eps} answers {res}")
    print(f"eps={eps}: alpha=1/L={alpha}, beta=L={beta}, d={d}; min F(t)F(1/t) on grid = {float(mn):.4f}; "
          f"(b) {nb} problems T1 = u-Bayes; (c) {nc} edge checks; "
          f"(e) p={tuple(str(x) for x in p)}: answers at g1, g2, midpoint = {res}")

print("ALL PASS" if fails == 0 else f"{fails} FAILURES")
