"""PP21: twin nearT solution -- partial sources with no defence of T, grouped by
whether their source C is a cell-tightening (agrees with T wherever T answers)."""
import sys, itertools, random, collections
sys.argv = ['x']
from exp_joint import S as S1
from exp_split import rivals_twin, orders
from catcache import catalogue
from search import Searcher, improvement
from engine import closure_of, mk_rec
S = S1.split([S1.names[k] for k in S1.silent_cells()]); cat = catalogue(S); T = S.T
sr = Searcher(S, cat, rivals_twin(S), defender_order=orders(T)['nearT'], max_nodes=6000)
res, _ = sr.solve()
rnd = random.Random(5); tally = collections.Counter()
for C in res.P:
    D = [k for k in range(S.n) if C[k] != T[k]]
    if len(D) < 2: continue
    tight = all(C[k] == T[k] for k in range(S.n) if T[k] != 2)
    subs = [s for m in range(1, len(D)) for s in itertools.combinations(D, m)] if len(D) <= 8 else \
           list({tuple(sorted(rnd.sample(D, rnd.randint(1, len(D) - 1)))) for _ in range(150)})
    for sub in subs:
        X = list(T)
        for k in sub: X[k] = C[k]
        X = tuple(X)
        tally[(tight, 'tested')] += 1
        if res.defends(T, X): continue
        if not any(not improvement(S, mk_rec(T, X), w) and
                   closure_of(S, [('cmp', T, X, w)], coherent=sr.coh, base=res).failure is None for w in range(3)):
            tally[(tight, 'no defence')] += 1
for k, v in sorted(tally.items()): print(('tightening' if k[0] else 'non-tightening'), k[1], v)
