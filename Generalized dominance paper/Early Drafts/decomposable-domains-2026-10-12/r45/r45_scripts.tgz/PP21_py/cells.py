"""PP21: exact finite cell model of the three-world problem space.

Everything is exact (fractions.Fraction).  No floating point is used for any
decision.

Advice codes at a cell with representative gamble g:
    0 = 'P'  accept g
    1 = 'N'  accept -g
    2 = 'S'  silent
    3 = 'X'  contradiction
Ranks at world w: correct 0 < silent 1 < wrong 2 < contradiction 3, where
accepting g is correct at w iff g_w > 0.

Coherence.  A model (advice vector) is coherent iff it equals D_K at every
representative gamble for some nonempty closed convex K in the simplex, with
strict inequalities (accept: min_K m.g > 0; reject: max_K m.g < 0; silent:
min < 0 < max).  Two exact tests are implemented and cross-checked:
  * is_coherent(adv): polygon clipping in the 2-simplex with rationals;
  * catalogue(): every coherent vector, as the closure under 'meet' of the
    sign vectors of the open 2-faces of the line arrangement {m.g_k = 0}.
    (A meet of faces is realised by the convex hull of interior points of
    those faces; conversely every realising K can be pushed into open faces.)
Strict inequalities are open conditions, so every coherent cell vector is also
realised on small open neighbourhoods of the representatives: a cell is such a
neighbourhood.

Twin splitting ('atomless refinement'): split(cells) duplicates a cell into two
copies with the SAME representative gamble.  Coherent models must then agree on
the two copies, while rivals may fill one copy only (a fill of half a cell).
"""
from fractions import Fraction as Fr
import itertools

EPS = Fr(3, 10)
C0 = (1 - EPS) / 3          # c = 7/30
D = Fr(1, 10)               # audit's d
LW = Fr(5)                  # audit's L for W_ij

ADV = 'PNSX'

def dot(m, g): return sum(a * b for a, b in zip(m, g))

def gam(i, x):
    """coordinate i = -x, the other two = 1 (minority world i when x > 0)."""
    return tuple(-x if k == i else Fr(1) for k in range(3))

def advice_of(V, g):
    vals = [dot(m, g) for m in V]
    lo, hi = min(vals), max(vals)
    if lo > 0: return 0
    if hi < 0: return 1
    if lo < 0 < hi: return 2
    raise ValueError(('boundary', V, g))

T_VERTS = [tuple(C0 + EPS * (k == j) for k in range(3)) for j in range(3)]
UNIF = [(Fr(1, 3),) * 3]
VERT = [[tuple(Fr(int(k == j)) for k in range(3))] for j in range(3)]

# ---------------------------------------------------------------- cells
def base_cells(extra=True):
    """Return list of (name, gamble).  Per world i (minority world i on the axis
    g = (-x at i, 1, 1)):
      J_i  x = 1/2   T answers majority
      Gp_i x = 6/5   T silent, uniform majority   (generic majority-favouring)
      R_i  x = 2-3d  T silent, uniform majority   (audit's R_i)
      B_i  x = 2-d   T silent, uniform majority   (audit's B_i)
      A_i  x = 2+d   T silent, uniform minority   (audit's A_i)
      Gm_i x = 3     T silent, uniform minority   (generic minority-favouring)
      O_i  off-axis  T silent, uniform majority   (generic, breaks symmetry)
    W_ij (L at k): T answers minority-k.  U: unanimous."""
    cells = []
    spec = [('J', Fr(1, 2)), ('Gp', Fr(6, 5)), ('R', 2 - 3 * D), ('B', 2 - D),
            ('A', 2 + D), ('Gm', Fr(3))]
    for nm, x in spec:
        for i in range(3):
            cells.append((f'{nm}{i+1}', gam(i, x)))
    if extra:
        for i in range(3):
            j, k = [t for t in range(3) if t != i]
            g = [Fr(0)] * 3; g[i] = Fr(-2); g[j] = Fr(1, 2); g[k] = Fr(8, 5)
            cells.append((f'O{i+1}', tuple(g)))
    for (i, j) in ((0, 1), (0, 2), (1, 2)):
        g = tuple(Fr(-1) if t in (i, j) else LW for t in range(3))
        cells.append((f'W{i+1}{j+1}', g))
    cells.append(('U', (Fr(1), Fr(2), Fr(3))))
    return cells

class Space:
    """A finite cell model.  cells: list of (name, gamble); gambles may repeat
    (twin copies)."""
    def __init__(self, cells):
        self.cells = list(cells)
        self.names = [n for n, _ in cells]
        self.g = [g for _, g in cells]
        self.n = len(cells)
        self.idx = {n: k for k, n in enumerate(self.names)}
        # rank[w][k][v]
        self.rank = []
        for w in range(3):
            rw = []
            for g in self.g:
                assert g[w] != 0
                pgood = g[w] > 0
                rw.append((0 if pgood else 2, 2 if pgood else 0, 1, 3))
            self.rank.append(rw)
        # majority / minority answer and minority world for mixed cells
        self.maj, self.mino, self.minworld = [], [], []
        for g in self.g:
            pos = [w for w in range(3) if g[w] > 0]
            if len(pos) in (0, 3):
                self.maj.append(0 if len(pos) == 3 else 1); self.mino.append(None); self.minworld.append(None)
            elif len(pos) == 2:
                self.maj.append(0); self.mino.append(1)
                self.minworld.append([w for w in range(3) if g[w] < 0][0])
            else:
                self.maj.append(1); self.mino.append(0); self.minworld.append(pos[0])
        self.T = self.model(T_VERTS)
        self.V = self.model(UNIF)
        self.vertex = [self.model(V) for V in VERT if self._ok(V)] if False else None
        self._distinct = None

    def _ok(self, V):
        try:
            self.model(V); return True
        except ValueError:
            return False

    def model(self, V):
        return tuple(advice_of(V, g) for g in self.g)

    def fill(self, X, cellset, val):
        """X with value val ('maj', 'min', or code) on the given cells."""
        X = list(X)
        for k in cellset:
            k = self.idx[k] if isinstance(k, str) else k
            X[k] = self.maj[k] if val == 'maj' else self.mino[k] if val == 'min' else val
        return tuple(X)

    def silent_cells(self, X=None):
        X = self.T if X is None else X
        return [k for k in range(self.n) if X[k] == 2 and self.minworld[k] is not None]

    def show(self, X):
        return ''.join(ADV[v] for v in X)

    def split(self, names):
        """Twin-split the named cells: each becomes name+'a', name+'b' with the
        same gamble."""
        out = []
        for nm, g in self.cells:
            if nm in names:
                out += [(nm + 'a', g), (nm + 'b', g)]
            else:
                out.append((nm, g))
        return Space(out)

    # -------------------------------------------------------- coherence
    def is_coherent(self, X):
        return is_coherent(X, self.g)

    def catalogue(self):
        """All coherent advice vectors (exact)."""
        # distinct gambles
        dist = []
        pos = []
        for g in self.g:
            if g not in dist: dist.append(g)
            pos.append(dist.index(g))
        cat = coherent_catalogue(dist)
        return sorted({tuple(v[pos[k]] for k in range(self.n)) for v in cat})


# ------------------------------------------------- polygon clipping (exact)
# Points of the simplex are represented by (m1, m2); m3 = 1 - m1 - m2.
TRI = [(Fr(1), Fr(0)), (Fr(0), Fr(1)), (Fr(0), Fr(0))]

def lin(g):
    """m.g as a + b m1 + c m2 with m3 = 1 - m1 - m2."""
    return (g[2], g[0] - g[2], g[1] - g[2])

def val(l, p): return l[0] + l[1] * p[0] + l[2] * p[1]

def clip(poly, l, sign):
    """Keep sign*(l(p)) >= 0."""
    out = []
    n = len(poly)
    for t in range(n):
        p, q = poly[t], poly[(t + 1) % n]
        vp, vq = sign * val(l, p), sign * val(l, q)
        if vp >= 0: out.append(p)
        if (vp > 0 and vq < 0) or (vp < 0 and vq > 0):
            s = vp / (vp - vq)
            out.append((p[0] + s * (q[0] - p[0]), p[1] + s * (q[1] - p[1])))
    return out

def area2(poly):
    if len(poly) < 3: return Fr(0)
    a = Fr(0)
    for t in range(len(poly)):
        p, q = poly[t], poly[(t + 1) % len(poly)]
        a += p[0] * q[1] - q[0] * p[1]
    return abs(a)

def is_coherent(X, gambles):
    if any(v == 3 for v in X): return False
    poly = list(TRI)
    for v, g in zip(X, gambles):
        if v == 0: poly = clip(poly, lin(g), 1)
        elif v == 1: poly = clip(poly, lin(g), -1)
        if area2(poly) == 0: return False
    for v, g in zip(X, gambles):
        if v == 2:
            if area2(clip(poly, lin(g), 1)) == 0 or area2(clip(poly, lin(g), -1)) == 0:
                return False
    return True

def faces(gambles):
    """Sign vectors (0 = accept, 1 = reject) of the open 2-faces of the
    arrangement of the lines m.g = 0 inside the simplex."""
    pieces = [(list(TRI), ())]
    for g in gambles:
        l = lin(g); new = []
        for poly, sv in pieces:
            for code, sgn in ((0, 1), (1, -1)):
                q = clip(poly, l, sgn)
                if area2(q) > 0: new.append((q, sv + (code,)))
        pieces = new
    return pieces

def meet(x, y): return tuple(a if a == b else 2 for a, b in zip(x, y))

def coherent_catalogue(gambles):
    F = [sv for _, sv in faces(gambles)]
    seen = set(F); frontier = list(F)
    while frontier:
        nxt = []
        for x in frontier:
            for f in F:
                z = meet(x, f)
                if z not in seen:
                    seen.add(z); nxt.append(z)
        frontier = nxt
    return seen

def standard_space(extra=True):
    return Space(base_cells(extra))

if __name__ == '__main__':
    import random
    S = standard_space()
    print('cells:', S.n)
    for k in range(S.n):
        print(f'  {S.names[k]:4} g={tuple(str(t) for t in S.g[k])}  minority world={None if S.minworld[k] is None else S.minworld[k]+1}'
              f'  maj={ADV[S.maj[k]]}  T={ADV[S.T[k]]}  V_c*={ADV[S.V[k]]}')
    print('T     =', S.show(S.T), ' coherent:', S.is_coherent(S.T))
    print('V_c*  =', S.show(S.V), ' coherent:', S.is_coherent(S.V))
    print('T silent mixed cells:', [S.names[k] for k in S.silent_cells()])
    fc = faces(S.g); print('open 2-faces of the arrangement:', len(fc))
    cat = S.catalogue(); print('coherent vectors (catalogue):', len(cat))
    # cross-check catalogue vs clipping test
    catset = set(cat)
    bad = [x for x in cat if not S.is_coherent(x)]
    print('catalogue members failing clipping test:', len(bad))
    rnd = random.Random(0); mism = 0; tested = 0
    for x in cat[:3000]:
        for _ in range(3):
            y = list(x); k = rnd.randrange(S.n); y[k] = rnd.randrange(3); y = tuple(y)
            tested += 1
            if S.is_coherent(y) != (y in catset): mism += 1
    print(f'random one-cell mutations: {tested} tested, mismatches between the two tests: {mism}')
