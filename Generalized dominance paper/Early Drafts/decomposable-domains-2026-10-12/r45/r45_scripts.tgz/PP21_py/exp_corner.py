"""PP21 experiment 10: a cell model that sees corner tightenings honestly.

corner_cut.py shows (CHECKED) that the corner tightening K_t = M & {m_k <= t}
answers not only with the majority on part of M_k, but also with the MINORITY
answer on parts of M_i and M_j.  The 25-cell model hides this (its axis cells
lie in the majority part only).  Here we add six cells Ck_i (corner k, class M_i):
g_i = -5/4, g_j = 1/4, g_k = 1/2 (T silent there; corner cuts answer minority).

Defenders are restricted to a STATED FINITE CATALOGUE of credal sets K inside M
(the brief's alternative to the full LP): single corner cuts {m_k <= t},
t in {c + eps/4, c + eps/2, c + 3eps/4}; double corner cuts; edge cuts
{m_k >= c + s}, s in {eps/4, eps/2}; and combinations of one corner cut with
one edge cut.  Coherent rivals may still be registered.  Rival class: X*, Y_12,
Lambda_T, V_c*, maj/min fills of every T-silent cell, two-class majority fills
over the axis cells; then up to 3 rounds adding all partial sources of the
chosen defenders (sampled 150 per defender when |D_C| > 8).  Backtracking DFS
while the class has < 600 rivals, greedy (no backtracking; 'stuck' is not a
proof) beyond, for memory.
"""
import sys, itertools, random, time, collections
from fractions import Fraction as Fr
from cells import base_cells, Space, T_VERTS, EPS, C0, advice_of, TRI, clip, lin, area2
from catcache import catalogue
from search import Searcher, named_rivals, fill_rivals, improvement, solve_greedy
from engine import closure_of, mk_rec
from verify import verify

cells = base_cells()
extra = []
for k in range(3):
    for i in range(3):
        if i == k: continue
        j = 3 - i - k
        g = [Fr(0)] * 3; g[i] = Fr(-5, 4); g[j] = Fr(1, 4); g[k] = Fr(1, 2)
        extra.append((f'C{k+1}{i+1}', tuple(g)))
S = Space(cells[:-4] + extra + cells[-4:])
T = S.T
t0 = time.time(); cat = catalogue(S); cs = set(cat)
print(f'corner model: {S.n} cells; exact coherent catalogue {len(cat)} ({time.time()-t0:.0f}s)')
print('T silent on', [S.names[k] for k in S.silent_cells()])

# ---- finite catalogue of tightenings K inside M (polygons in (m1, m2) coordinates)
def poly_M():
    P = list(TRI)
    for j in range(3):          # M = {m_j >= c for all j}
        g = [-C0] * 3; g[j] = 1 - C0
        P = clip(P, lin(tuple(g)), 1)
    return P
def cut(P, k, t, upper=True):   # keep m_k <= t (upper) or m_k >= t
    g = [t] * 3; g[k] = t - 1    # m.g = t - m_k
    return clip(P, lin(tuple(g)), 1 if upper else -1)
def model_of(P):
    V = [(p[0], p[1], 1 - p[0] - p[1]) for p in P]
    try:
        return tuple(advice_of(V, g) for g in S.g)
    except ValueError:
        return None
fam = {}
ts = [C0 + EPS / 4, C0 + EPS / 2, C0 + 3 * EPS / 4]
ss = [EPS / 4, EPS / 2]
M0 = poly_M()
for k in range(3):
    for t in ts:
        fam[f'corner{k+1}@{t}'] = cut(M0, k, t)
        for s in ss:
            for l in range(3):
                if l != k: fam[f'corner{k+1}@{t}+edge{l+1}@{s}'] = cut(cut(M0, k, t), l, C0 + s, upper=False)
    for s in ss:
        fam[f'edge{k+1}@{s}'] = cut(M0, k, C0 + s, upper=False)
for k, l in itertools.combinations(range(3), 2):
    for t in ts:
        fam[f'corner{k+1}{l+1}@{t}'] = cut(cut(M0, k, t), l, t)
pool = {}
for nm, P in fam.items():
    if area2(P) == 0: continue
    X = model_of(P)
    if X is None or X == T: continue
    assert X in cs, nm
    pool.setdefault(X, nm)
print(f'finite catalogue of tightenings: {len(fam)} credal sets, {len(pool)} distinct models (all coherent, all agree with T where T answers: '
      f'{all(all(X[k] == T[k] for k in range(S.n) if T[k] != 2) for X in pool)})')
cnt = collections.Counter()
for X, nm in pool.items():
    kinds = set()
    for k in range(S.n):
        if X[k] != T[k] and S.minworld[k] is not None:
            kinds.add((f'M{S.minworld[k]+1}', 'maj' if X[k] == S.maj[k] else 'min'))
    cnt[len({c for c, _ in kinds})] += 1
print('defenders by number of classes in which they answer where T is silent:', dict(cnt))

R = named_rivals(S); R.update(fill_rivals(S, max_cells=1))
sil = S.silent_cells()
axis = [k for k in sil if S.names[k][:-1] in ('Gp', 'R', 'B', 'A', 'Gm')]
for a, b in itertools.combinations(axis, 2):
    if S.minworld[a] != S.minworld[b]:
        R[f'maj[{S.names[a]}+{S.names[b]}]'] = S.fill(T, [a, b], 'maj')
nd = lambda C: sum(x != y for x, y in zip(C, T))
ORD = {'rand1': lambda X, cat: random.Random(1).sample(cat, len(cat)),
       'nearT': lambda X, cat: sorted(cat, key=lambda C: (nd(C), C))}
plist = sorted(pool)
rnd = random.Random(3)
for on, o in ORD.items():
    RR = dict(R)
    print(f'== order {on}')
    for rd in range(3):
        t0 = time.time()
        sr = Searcher(S, cat, RR, defender_order=o, max_nodes=20000, pool=plist)
        res, info = sr.solve() if len(RR) < 600 else solve_greedy(sr)
        if res is None:
            print(f'  round {rd}: rivals {len(RR)}: no clean solution ({info if isinstance(info, str) else info[0]}); nodes {sr.nodes}, dead ends {len(sr.dead_ends)}')
            if sr.dead_ends:
                ob, cl, fails = sr.dead_ends[0]
                print(f'   first dead end: {ob[0]}-obligation for {ob[1]} = {S.show(ob[2])}; {len(fails)} options, all failing')
                from search import minimise
                from exp_deadends import classify
                for q, c2 in fails[:2]:
                    reqs = [c2.requests[i] for i in sorted(c2.failure_support())]
                    mn, clm = minimise(S, reqs, sr.coh)
                    names = dict(sr.names)
                    for x in mn:
                        if x[0] == 'dom': names.setdefault(x[1], pool.get(x[1], 'C'))
                    print(f'   option {clm.req_str(q, names)}: {classify(clm)}; minimal set:')
                    for x in mn: print('       ', clm.req_str(x, names))
                    for l in clm.derivation(names=names): print('          ', l)
            break
        print(f'  round {rd}: rivals {len(RR)}: CLEAN |P|={len(res.P)} nodes={sr.nodes} dead-ends={len(sr.dead_ends)} '
              f'records by origin {dict(collections.Counter(j[0] for w in range(3) for j in res.inst[w].values()))} '
              f'verify-errors {len(verify(res))} {time.time()-t0:.0f}s')
        print('     defenders used:', sorted({pool[N] for N in res.P if N in pool}))
        new = nodef = 0
        for C in list(res.P):
            D = [k for k in range(S.n) if C[k] != T[k]]
            if len(D) < 2: continue
            subs = [s for m in range(1, len(D)) for s in itertools.combinations(D, m)] if len(D) <= 8 else \
                   list({tuple(sorted(rnd.sample(D, rnd.randint(1, len(D) - 1)))) for _ in range(150)})
            for sub in subs:
                X = list(T)
                for k in sub: X[k] = C[k]
                X = tuple(X)
                if X in RR.values(): continue
                RR[f'part{rd}[{len(RR)}]'] = X; new += 1
                if not res.defends(T, X) and not any(not improvement(S, mk_rec(T, X), w) and
                        closure_of(S, [('cmp', T, X, w)], coherent=sr.coh, base=res).failure is None for w in range(3)):
                    nodef += 1
        print(f'     new partial-source rivals {new}; with no clean defence of T given this solution: {nodef}')
        sys.stdout.flush()
        if new == 0: print('  closed under partial sources.'); break
