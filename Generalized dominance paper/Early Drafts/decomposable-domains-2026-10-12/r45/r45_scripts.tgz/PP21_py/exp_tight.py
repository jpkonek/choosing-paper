"""PP21 experiment 9: tightening-only defenders, closed under their own partial sources.

A cell-tightening is a coherent model that agrees with T wherever T answers
(the cell shadow of D_K with K inside M).  Defenders are restricted to
cell-tightenings (reg of coherent rivals still allowed).  After a clean solution,
every partial source T[D' -> C] of every member C of P (all proper non-empty D'
if |D_C| <= 8, else 150 sampled) is added to the rival class and the search is
re-run from scratch; repeat until no new partial sources appear (max 4 rounds).
Classes: J1 (25 cells) and the twin-split class (43 cells).  The search is the
backtracking DFS while the class has < 1000 rivals, and the greedy
(non-backtracking) variant beyond that, for memory; 'STUCK' is not a proof of
infeasibility.  At most 3 rounds.
"""
import sys, itertools, random, time, collections
sys.argv_ = list(sys.argv); sys.argv = ['x']
from exp_joint import J1, ORD, S, cat, T
from exp_split import rivals_twin, orders
from catcache import catalogue
from search import Searcher, solve_greedy
from engine import mk_rec, closure_of
from verify import verify

def tight(S_, C): return all(C[k] == S_.T[k] for k in range(S_.n) if S_.T[k] != 2)

MAXR = 3
def run(tag, S_, cat_, R, order):
    pool = [C for C in cat_ if tight(S_, C)]
    print(f'== {tag}: cell-tightenings in catalogue: {len(pool)} of {len(cat_)}')
    rnd = random.Random(9)
    R = dict(R)
    for rd in range(MAXR):
        t0 = time.time()
        sr = Searcher(S_, cat_, R, defender_order=order, max_nodes=20000, pool=pool)
        res, info = sr.solve() if len(R) < 1000 else solve_greedy(sr)
        if res is None:
            print(f'  round {rd}: rivals {len(R)}: no clean solution found ({info if isinstance(info, str) else info[0]}; greedy STUCK is not a proof) nodes {sr.nodes}')
            if sr.dead_ends:
                ob, cl, fails = sr.dead_ends[-1]
                print('   last dead end at', ob[0], ob[1], 'options', len(fails))
            return
        nreq = collections.Counter(j[0] for w in range(3) for j in res.inst[w].values())
        print(f'  round {rd}: rivals {len(R)}: CLEAN |P|={len(res.P)} nodes={sr.nodes} dead-ends={len(sr.dead_ends)} '
              f'records by origin {dict(nreq)} verify-errors {len(verify(res))} {time.time()-t0:.0f}s')
        new = 0; nodef = 0
        for C in list(res.P):
            D = [k for k in range(S_.n) if C[k] != S_.T[k]]
            if len(D) < 2: continue
            subs = [s for m in range(1, len(D)) for s in itertools.combinations(D, m)] if len(D) <= 8 else \
                   list({tuple(sorted(rnd.sample(D, rnd.randint(1, len(D) - 1)))) for _ in range(150)})
            for sub in subs:
                X = list(S_.T)
                for k in sub: X[k] = C[k]
                X = tuple(X)
                if X in R.values(): continue
                R[f'part{rd}[{len(R)}]'] = X; new += 1
                if not res.defends(S_.T, X) and not any(
                        closure_of(S_, [('cmp', S_.T, X, w)], coherent=sr.coh, base=res).failure is None for w in range(3)):
                    nodef += 1
        print(f'     new partial-source rivals {new}; of these with no clean defence of T given this solution: {nodef}')
        sys.stdout.flush()
        if rd == MAXR - 1: print('  (stopped after', MAXR, 'rounds)'); return
        if new == 0:
            print('  closed under partial sources of its own defenders.')
            return

if len(sys.argv_) > 1 and sys.argv_[1] == 'J1nearT':
    run('J1, tightening defenders, nearT', S, cat, J1(), ORD['nearT']); sys.exit()
run('J1, tightening defenders, rand1', S, cat, J1(), ORD['rand1'])
S2 = S.split([S.names[k] for k in S.silent_cells()]); cat2 = catalogue(S2)
run('twin, tightening defenders, rand1', S2, cat2, rivals_twin(S2), orders(S2.T)['rand1'])
if len(sys.argv_) > 1 and sys.argv_[1] == 'twinnearT':
    run('twin, tightening defenders, nearT', S2, cat2, rivals_twin(S2), orders(S2.T)['nearT'])
