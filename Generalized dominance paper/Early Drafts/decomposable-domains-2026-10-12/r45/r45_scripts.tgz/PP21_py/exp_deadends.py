"""PP21 experiment 7: minimal failing sets at dead ends of the joint search.

For each dead end met by the DFS (an obligation all of whose options fail),
every option's failure is reduced to a deletion-minimal failing request set and
classified:
  two-link      F1 from one rule-II step on two requested records (Lemma 5.0*)
  exposure      F1/F2 from rule III/IV where the dominated record ends at a protected
                model (Lemma 0.4 with N = T or with N = another defender)
  deeper        anything else
Runs: J1 with orders rand2 and rand3 (weak and tie-first), and the twin-split
class with order nearT.
"""
import sys, collections
sys.argv = ['x']
from exp_joint import J1, ORD, S, cat, T
from search import Searcher, minimise
from catcache import catalogue

def classify(cl):
    steps = collections.Counter(); seen = set(); stack = [cl.failure.key]
    while stack:
        k = stack.pop()
        if k in seen: continue
        seen.add(k)
        j = cl._just(k)
        if j is None or j[0] == 'req': continue
        steps[j[0]] += 1; stack.extend(cl._parents(j))
    if cl.failure.kind == 'F1' and steps == collections.Counter({'II': 1}): return 'two-link'
    if not steps.get('II') and (steps.get('III') or steps.get('IV')): return 'exposure-' + cl.failure.kind
    return 'deeper(' + ','.join(f'{a}{b}' for a, b in sorted(steps.items())) + ')-' + cl.failure.kind

def analyse(tag, S_, cat_, R, order, ties=False, show=2):
    sr = Searcher(S_, cat_, R, defender_order=order, max_nodes=4000, ties=ties)
    res, info = sr.solve()
    coh = sr.coh
    tally = collections.Counter(); sizes = collections.Counter(); shown = 0
    for ob, cl, fails in sr.dead_ends:
        for q, c2 in fails:
            reqs = [c2.requests[i] for i in sorted(c2.failure_support())]
            mn, clm = minimise(S_, reqs, coh)
            c = classify(clm); tally[c] += 1; sizes[len(mn)] += 1
            if shown < show and c != 'two-link':
                shown += 1
                names = dict(sr.names)
                for x in mn:
                    if x[0] == 'dom': names.setdefault(x[1], 'C(' + sr.nm(x[2]) + ')')
                print(f'  [{tag}] dead end at {ob[0]}-obligation for {ob[1]}; option {clm.req_str(q, names)}; class {c}; minimal set:')
                for x in mn: print('       ', clm.req_str(x, names))
                for l in clm.derivation(names=names): print('          ', l)
    print(f'{tag}: {"CLEAN" if res is not None else "no solution"}; dead ends {len(sr.dead_ends)}; '
          f'failing options {sum(tally.values())}; classes {dict(tally)}; minimal-set sizes {dict(sizes)}')
    sys.stdout.flush()

if __name__ == '__main__':
    R = J1()
    for on in ('rand2', 'rand3', 'precise'):
        for ties in (False, 'first'):
            analyse(f'J1 {on} ties={ties}', S, cat, R, ORD[on], ties)
    from exp_split import rivals_twin, orders
    S2 = S.split([S.names[k] for k in S.silent_cells()]); cat2 = catalogue(S2)
    analyse('twin nearT', S2, cat2, rivals_twin(S2), orders(S2.T)['nearT'], show=3)
