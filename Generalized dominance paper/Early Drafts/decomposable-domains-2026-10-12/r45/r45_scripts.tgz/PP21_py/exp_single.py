"""PP21 experiment 1: single-rival maps.

For each rival X and each candidate coherent defender C (all 202 precise
models + 3000 random imprecise ones, seed 0), classify:
  dom(C, X) alone:
     F1dom   C is not strictly better than X at some cell, at some world
     EXP-F2  exposure: C = X on {X != T}; T[D -> C] is forced into P (Lemma 0.4)
             and is incoherent
     EXP-F1  exposure, and T[D -> C] is a strict guidance improvement of T at
             some world, so rule III installs a reversed guidance comparison
     EXP-tie exposure but T[D -> C] coherent: an all-world tie with T, clean;
             its later failures are labelled via-EXP-tie
     clean   otherwise
  for clean dom, and each world w, the request T R_w C:
     guid    already accepted by guidance
     L02     F1 and X <_w T is a strict guidance comparison (Lemma 0.2)
     imp     F1 because C is a strict pointwise improvement of T at w
     ok      clean
     other   any other failure (printed)
  and the single-world tie request T ~_w C (both directions at w).
Predicted: every failure falls in the named classes ('other' = 0).
"""
import random, sys, collections
from cells import standard_space
from catcache import catalogue
from engine import closure_of, mk_rec, inv
from search import named_rivals, improvement

S = standard_space(); cat = catalogue(S); cs = set(cat); coh = lambda X: X in cs
T = S.T
rnd = random.Random(0)
prec = [C for C in cat if 2 not in C]
imp_ = [C for C in cat if 2 in C]
sample = prec + rnd.sample(imp_, 3000)

R = named_rivals(S)
for c in ('R3', 'A3', 'Gp3', 'Gm3', 'O3'):
    R[f'maj[{c}]'] = S.fill(T, [c], 'maj')
    R[f'min[{c}]'] = S.fill(T, [c], 'min')
R['Y_H(Gp1+Gp2)'] = S.fill(T, ['Gp1', 'Gp2'], 'maj')
R['Y_H(Gm1+O2)'] = S.fill(T, ['Gm1', 'O2'], 'maj')

def strict_guid_worse(X, w):   # X <_w T strictly by guidance
    return improvement(S, mk_rec(T, X), w)

others = []
print(f'defender sample: {len(prec)} precise + 3000 imprecise = {len(sample)}')
for nm, X in R.items():
    cnt = collections.Counter()
    tcnt = collections.Counter(); tiec = collections.Counter()
    for C in sample:
        if C == X: continue
        cl = closure_of(S, [('dom', C, X)], coherent=coh)
        if cl.failure is not None:
            if cl.failure.kind == 'F1' and not all(any(S.rank[w][k][C[k]] < S.rank[w][k][X[k]] for k in range(S.n)) for w in range(3)):
                cnt['F1dom'] += 1
            elif all(C[k] == X[k] for k in range(S.n) if X[k] != T[k]):
                cnt['EXP-' + cl.failure.kind] += 1
            else:
                cnt['other'] += 1; others.append((nm, 'dom', C))
            continue
        exptie = len(cl.P) > 2
        if exptie: cnt['EXP-tie (T-splice coherent)'] += 1
        else: cnt['clean'] += 1
        for w in range(3):
            if cl.defends(T, C) and w in cl.defends(T, C):
                tcnt[(w+1, 'guid')] += 1; continue
            c2 = closure_of(S, [('cmp', T, C, w)], coherent=coh, base=cl)
            if c2.failure is None: tcnt[(w+1, 'ok')] += 1
            elif improvement(S, mk_rec(T, C), w): tcnt[(w+1, 'imp')] += 1
            elif strict_guid_worse(X, w): tcnt[(w+1, 'L02')] += 1
            elif exptie: tcnt[(w+1, 'via-EXP-tie')] += 1
            else:
                tcnt[(w+1, 'other')] += 1; others.append((nm, 'T', C, w, c2))
            # single-world tie
            if improvement(S, mk_rec(T, C), w) or improvement(S, mk_rec(C, T), w):
                tiec[(w+1, 'guid-strict')] += 1; continue
            c3 = closure_of(S, [('tie', T, C, w)], coherent=coh, base=cl)
            if c3.failure is None: tiec[(w+1, 'ok')] += 1
            elif strict_guid_worse(X, w): tiec[(w+1, 'L02')] += 1
            elif exptie: tiec[(w+1, 'via-EXP-tie')] += 1
            else: tiec[(w+1, 'other')] += 1; others.append((nm, 'tie', C, w, c3))
    print(f'\n{nm}: X = {S.show(X)}  coherent={X in cs}  strict-guidance-worse at worlds {[w+1 for w in range(3) if strict_guid_worse(X, w)]}')
    print('   dom alone:', dict(cnt))
    print('   T R_w C  :', dict(sorted(tcnt.items())))
    print('   T ~_w C  :', dict(sorted(tiec.items())))
    sys.stdout.flush()
print('\nunclassified failures:', len(others))
for o in others[:8]:
    print('  ', o[0], o[1], S.show(o[2]), o[3] + 1 if len(o) > 3 else '')
    if len(o) > 4:
        for l in o[4].derivation(names={T: 'T', R.get(o[0]): 'X', o[2]: 'C'}): print('       ', l)
