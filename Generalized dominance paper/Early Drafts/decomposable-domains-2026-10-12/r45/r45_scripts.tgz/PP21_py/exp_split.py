"""PP21 experiment 5: refinement.

(t) Twin splitting of all 18 T-silent cells (43 cells).  Coherent models must
    agree on twins (same gamble), rivals may fill one twin (a 'half-cell' fill;
    in the continuum such fills are non-conic and incoherent by Lemma H).
    Rival class: lifted X*, Y_12, Lambda_T, V_c*; majority/minority fills of
    every whole silent cell and of every half cell; majority fills of
    H1a + H2a for H1 in M_1, H2 in M_2 (Y_H-type, 36).
    Runs: fresh DFS (three orders), and DFS started from the lifted clean
    nearT solution of J1 restricted to these rivals (does the old choice extend?).
(p) Perturbed splitting: for world-1 and world-3 cells Gp, R, A add a second
    cell with x shifted by +1/40 (a distinct nearby gamble), so coherent models
    may separate the two; recompute the exact catalogue; rivals as in (t) on
    single cells plus named; fresh DFS.
"""
import sys, time, random, itertools
from cells import standard_space, base_cells, Space, gam
from catcache import catalogue
from search import Searcher, named_rivals, fill_rivals
from fractions import Fraction as Fr

def lift(S, S2, X):
    return tuple(X[S.idx[n.rstrip('ab')]] if n not in S.idx else X[S.idx[n]] for n in S2.names)

def rivals_twin(S2):
    T = S2.T
    R = named_rivals(S2)
    sil = S2.silent_cells()
    base = sorted({S2.names[k][:-1] for k in sil})
    for b in base:
        a, bb = S2.idx[b + 'a'], S2.idx[b + 'b']
        for kd in ('maj', 'min'):
            R[f'{kd}[{b}]'] = S2.fill(T, [a, bb], kd)
            R[f'{kd}[{b}a]'] = S2.fill(T, [a], kd)
            R[f'{kd}[{b}b]'] = S2.fill(T, [bb], kd)
    m1 = [b for b in base if S2.minworld[S2.idx[b + 'a']] == 0]
    m2 = [b for b in base if S2.minworld[S2.idx[b + 'a']] == 1]
    for h1, h2 in itertools.product(m1, m2):
        R[f'maj[{h1}a+{h2}a]'] = S2.fill(T, [S2.idx[h1 + 'a'], S2.idx[h2 + 'a']], 'maj')
    return R

def orders(T):
    nd = lambda C: sum(a != b for a, b in zip(C, T))
    return {
        'nearT': lambda X, cat: sorted(cat, key=lambda C: (nd(C), C)),
        'precise': lambda X, cat: sorted(cat, key=lambda C: (sum(v == 2 for v in C), nd(C), C)),
        'rand1': lambda X, cat: random.Random(1).sample(cat, len(cat)),
    }

def run(tag, S2, cat, R, order, fixed=(), budget=6000):
    t0 = time.time()
    sr = Searcher(S2, cat, R, defender_order=order, max_nodes=budget, fixed=fixed)
    res, info = sr.solve()
    if res is None:
        print(f'{tag}: {"BUDGET" if info == "budget" else "FIXED-FAILS" if isinstance(info, tuple) and info[0] == "fixed" else "DEAD"} '
              f'nodes={sr.nodes} dead-ends={len(sr.dead_ends)} {time.time()-t0:.1f}s')
        if isinstance(info, tuple) and info[0] == 'fixed':
            cl = info[1]
            for l in cl.derivation(names=sr.names): print('      ', l)
        return sr, None
    ties = [N for N, j in res.P.items() if j[0] == 'IV']
    print(f'{tag}: CLEAN rivals={len(R)} nodes={sr.nodes} dead-ends={len(sr.dead_ends)} |P|={len(res.P)} '
          f'records/world={res.stats()["records"]} rule-IV members={len(ties)} {time.time()-t0:.1f}s')
    sys.stdout.flush()
    return sr, res

if __name__ == '__main__':
    part = sys.argv[1] if len(sys.argv) > 1 else 't'
    S = standard_space(); cat = catalogue(S)
    if part == 't':
        sil_names = [S.names[k] for k in S.silent_cells()]
        S2 = S.split(sil_names); cat2 = catalogue(S2)
        assert len(cat2) == len(cat)
        R2 = rivals_twin(S2)
        for on, o in orders(S2.T).items():
            run(f'twin fresh order={on}', S2, cat2, R2, o)
        # lift the J1 nearT solution (restricted to rivals whose lifts are in R2) and extend
        sys.argv = ['x']
        from exp_joint import J1, ORD
        R1 = J1()
        sr1 = Searcher(S, cat, R1, defender_order=ORD['nearT'], max_nodes=4000)
        res1, _ = sr1.solve()
        fixed = []
        for q in res1.requests:
            if q[0] == 'reg': fixed.append(('reg', lift(S, S2, q[1])))
            elif q[0] == 'dom': fixed.append(('dom', lift(S, S2, q[1]), lift(S, S2, q[2])))
            elif q[0] in ('cmp', 'tie'): fixed.append((q[0], lift(S, S2, q[1]), lift(S, S2, q[2]), q[3]))
        for on, o in orders(S2.T).items():
            run(f'twin extend lifted J1-nearT solution ({len(fixed)} requests) order={on}', S2, cat2, R2, o, fixed=fixed)
    if part == 'p':
        cells = base_cells()
        extra = []
        for nm, x in (('Gp', Fr(6, 5)), ('R', Fr(17, 10)), ('A', Fr(21, 10))):
            for i in (0, 2):
                extra.append((f'{nm}{i+1}+', gam(i, x + Fr(1, 40))))
        S3 = Space(cells[:-4] + extra + cells[-4:])
        t0 = time.time(); cat3 = catalogue(S3)
        print(f'perturbed model: {S3.n} cells, exact coherent catalogue {len(cat3)} ({time.time()-t0:.0f}s)')
        R3 = named_rivals(S3); R3.update(fill_rivals(S3, max_cells=1))
        sil = S3.silent_cells()
        for a in [k for k in sil if S3.minworld[k] == 0]:
            for b in [k for k in sil if S3.minworld[k] == 1]:
                R3[f'maj[{S3.names[a]}+{S3.names[b]}]'] = S3.fill(S3.T, [a, b], 'maj')
        for on, o in orders(S3.T).items():
            run(f'perturbed fresh order={on}', S3, cat3, R3, o)
