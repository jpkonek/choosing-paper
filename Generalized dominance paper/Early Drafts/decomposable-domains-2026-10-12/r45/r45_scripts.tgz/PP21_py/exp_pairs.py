"""PP21 experiment 2: pairwise interactions and minimal failing sets.

A 'choice' for a rival X is a set of requests that is clean on its own:
dom(C, X), T R_wC C (unless already accepted), and T R_wX X when T has no
guidance defence against X.  We sample pairs of choices for different rivals,
close their union, and for every failure compute a deletion-minimal failing
request set and classify its derivation:
  depth1   one rule-II step: two requested records compose and the closing
           link is weak guidance (the Lemma 0.2 / Lemma 5.0 / Prop S shape);
  deeper   anything else (several rule-II steps, or rules III/IV).
"""
import random, sys, collections, itertools
from cells import standard_space
from catcache import catalogue
from engine import Closure, closure_of, mk_rec
from search import named_rivals, fill_rivals, improvement, minimise

S = standard_space(); cat = catalogue(S); cs = set(cat); coh = lambda X: X in cs
T = S.T
rnd = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 1)
R = named_rivals(S); R.update(fill_rivals(S, max_cells=1))
sil = S.silent_cells()
for a, b in itertools.product([k for k in sil if S.minworld[k] == 0], [k for k in sil if S.minworld[k] == 1]):
    R[f'YH[{S.names[a]}+{S.names[b]}]'] = S.fill(T, [a, b], 'maj')
names = {v: k for k, v in R.items()}; names[T] = 'T'
pool = list(R.items())

def random_choice():
    while True:
        nm, X = rnd.choice(pool)
        reqs = []
        if not closure_of(S, [], coherent=coh).defends(T, X):
            ws = [w for w in range(3) if not improvement(S, mk_rec(T, X), w)]
            reqs.append(('cmp', T, X, rnd.choice(ws)))
        if X in cs and rnd.random() < 0.3:
            reqs.append(('reg', X))
        else:
            C = rnd.choice(cat)
            if C == X: continue
            reqs.append(('dom', C, X))
            cl = closure_of(S, reqs, coherent=coh)
            if cl.failure is not None: continue
            if not cl.defends(T, C):
                ws = [w for w in range(3) if closure_of(S, [('cmp', T, C, w)], coherent=coh, base=cl).failure is None]
                if not ws: continue
                reqs.append(('cmp', T, C, rnd.choice(ws)))
        if closure_of(S, reqs, coherent=coh).failure is None:
            return nm, reqs

def classify(cl):
    steps = collections.Counter()
    seen = set(); stack = [cl.failure.key]
    while stack:
        k = stack.pop()
        if k in seen: continue
        seen.add(k)
        j = cl._just(k)
        if j is None or j[0] == 'req': continue
        steps[j[0]] += 1
        stack.extend(cl._parents(j))
    if cl.failure.kind == 'F1' and steps == collections.Counter({'II': 1}): return 'depth1'
    return 'deeper:' + ','.join(f'{a}{b}' for a, b in sorted(steps.items())) + ':' + cl.failure.kind

N = int(sys.argv[1]) if len(sys.argv) > 1 else 3000
stats = collections.Counter(); ex = {}
shape = collections.Counter()
for t in range(N):
    (n1, q1), (n2, q2) = random_choice(), random_choice()
    if n1 == n2: continue
    cl = closure_of(S, q1 + q2, coherent=coh)
    if cl.failure is None:
        stats['clean'] += 1; continue
    mn, clm = minimise(S, q1 + q2, coh)
    c = classify(clm)
    stats[c] += 1
    sig = tuple(sorted(q[0] + ('' if q[0] != 'cmp' else ('T' if q[1] == T else '?')) for q in mn))
    shape[(c, sig)] += 1
    if c not in ex or len(mn) < len(ex[c][0]): ex[c] = (mn, clm, n1, n2)
print(f'pairs sampled: {N}')
for k, v in sorted(stats.items()): print(f'  {k}: {v}')
print('minimal failing sets by (class, request kinds):')
for k, v in sorted(shape.items()): print(f'  {k}: {v}')
for c, (mn, clm, n1, n2) in sorted(ex.items()):
    print(f'\nexample [{c}] rivals {n1}, {n2}; minimal failing set:')
    nm2 = dict(names)
    for q in mn:
        if q[0] == 'dom': nm2.setdefault(q[1], 'C(' + names.get(q[2], '?') + ')')
    for q in mn: print('    ', clm.req_str(q, nm2))
    for l in clm.derivation(names=nm2): print('       ', l)
