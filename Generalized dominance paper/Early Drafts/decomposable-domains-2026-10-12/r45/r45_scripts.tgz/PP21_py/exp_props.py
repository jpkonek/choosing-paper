"""PP21 experiment 3: the referee's Prop S (split-defender compensation) and
Lemma 5.0 inside the exact closure, on geometric cells.

Setting: majority fills X_E, X_E' on M_3 cells E != E' (T silent there);
coherent defenders C, C2 (single-clean, T defends against each at world 3);
rival Y_H = T[H1 u H2 -> majority], H1 a T-silent cell of M_1, H2 of M_2.
For each world w in {1, 2} we compare
  engine:  closure{dom(C,X_E), dom(C2,X_E'), T R_3 C, T R_3 C2, T R_w Y_H}
           fails?
  predicted: Lemma 5.0 applies at w to (C, X_E) or to (C2, X_E') with
           Y = Y_H (D_Y misses E, {D <_w T} \\ E inside D_Y, Y <=_w D on D_Y).
World 3 is always refused (Y_H <_3 T by strict (G)).  'T has no defence
against Y_H' = both worlds fail.  We also search for a referee-type pair: C
alone and C2 alone leave a defence of Y_H, but together they do not.
"""
import random, sys, collections, itertools
from cells import standard_space
from catcache import catalogue
from engine import closure_of, mk_rec
from search import improvement

S = standard_space(); cat = catalogue(S); cs = set(cat); coh = lambda X: X in cs
T = S.T; n = S.n
rnd = random.Random(3)
sil = S.silent_cells()
M = {w: [k for k in sil if S.minworld[k] == w] for w in range(3)}

def le(a, b, k, w): return S.rank[w][k][a] <= S.rank[w][k][b]
def lt(a, b, k, w): return S.rank[w][k][a] < S.rank[w][k][b]

def lemma50(Cd, X, Y, w):
    E = [k for k in range(n) if X[k] != T[k]]
    DY = [k for k in range(n) if Y[k] != T[k]]
    if set(DY) & set(E): return False
    if not any(lt(X[k], Cd[k], k, w) for k in E): return False        # strict on E
    if not all(le(X[k], Cd[k], k, w) for k in E): return False
    for k in range(n):
        if k not in E and lt(Cd[k], T[k], k, w) and k not in DY: return False
    return all(le(Y[k], Cd[k], k, w) for k in DY)

def two_link(Cd, X, A, Y, w):
    """Exact two-link kill (Lemma 5.0*): C R_w X and A R_w Y compose, in one of the
    two orders, to a nonempty weak improvement at w."""
    r, s = mk_rec(Cd, X), mk_rec(A, Y)
    from engine import comp, is_empty
    for a, b in ((r, s), (s, r)):
        if all(x < 0 or y < 0 or x % 4 == y // 4 for x, y in zip(a, b)):
            c = comp(a, b)
            if not is_empty(c) and improvement(S, c, w): return True
    return False

def single_clean_defenders(X, limit):
    out = []
    for C in rnd.sample(cat, len(cat)):
        cl = closure_of(S, [('dom', C, X), ('cmp', T, C, 2)], coherent=coh)
        if cl.failure is None: out.append(C)
        if len(out) >= limit: break
    return out

stats = collections.Counter(); mismatch = []; refpairs = []; unpred = []
cells3 = M[2]
for E, E2 in itertools.permutations(cells3, 2):
    XE, XE2 = S.fill(T, [E], 'maj'), S.fill(T, [E2], 'maj')
    D1 = single_clean_defenders(XE, 25); D2 = single_clean_defenders(XE2, 25)
    for C, C2 in itertools.product(D1, D2):
        base = closure_of(S, [('dom', C, XE), ('dom', C2, XE2), ('cmp', T, C, 2), ('cmp', T, C2, 2)], coherent=coh)
        if base.failure is not None:
            stats['pair itself fails'] += 1; continue
        H1, H2 = rnd.choice(M[0]), rnd.choice(M[1])
        Y = S.fill(T, [H1, H2], 'maj')
        res = []
        for w in (0, 1):
            eng = closure_of(S, [('cmp', T, Y, w)], coherent=coh, base=base).failure is not None
            pred = lemma50(C, XE, Y, w) or lemma50(C2, XE2, Y, w)
            exact = two_link(C, XE, T, Y, w) or two_link(C2, XE2, T, Y, w)
            stats[('w%d' % (w + 1), 'engine F' if eng else 'engine ok', 'two-link' if exact else 'no two-link')] += 1
            if exact != eng: mismatch.append(('two-link-vs-engine', C, C2, Y, w))
            stats[('w%d' % (w + 1), 'engine F' if eng else 'engine ok', 'L5.0' if pred else '-')] += 1
            if pred and not eng: mismatch.append(('pred-not-engine', C, C2, Y, w))
            if eng and not pred and len(unpred) < 400: unpred.append((C, C2, XE, XE2, Y, w))
            res.append(eng)
        if all(res):
            stats['T has no defence vs Y_H'] += 1
            # referee pattern: each defender alone leaves a defence
            alone = []
            for (Cd, Xd) in ((C, XE), (C2, XE2)):
                b1 = closure_of(S, [('dom', Cd, Xd), ('cmp', T, Cd, 2)], coherent=coh)
                alone.append(any(closure_of(S, [('cmp', T, Y, w)], coherent=coh, base=b1).failure is None for w in (0, 1)))
            if all(alone):
                stats['  ... while each defender alone leaves a defence (Prop S pattern)'] += 1
                if len(refpairs) < 3: refpairs.append((C, C2, XE, XE2, Y))
for k, v in sorted(stats.items(), key=str): print(' ', k, v)
print('mismatches (Lemma 5.0 predicted but engine clean; or exact two-link criterion != engine):', len(mismatch))
names = {T: 'T'}
for C, C2, XE, XE2, Y in refpairs:
    print('\nProp S pattern: X_E =', S.show(XE), ' X_E\' =', S.show(XE2), ' Y_H =', S.show(Y))
    print('  C  =', S.show(C)); print('  C2 =', S.show(C2))
    for w in (0, 1):
        cl = closure_of(S, [('dom', C, XE), ('dom', C2, XE2), ('cmp', T, C, 2), ('cmp', T, C2, 2), ('cmp', T, Y, w)], coherent=coh)
        nm = {T: 'T', C: 'C', C2: 'C2', XE: 'X_E', XE2: "X_E'", Y: 'Y_H'}
        print(f'  T R_{w+1} Y_H fails:')
        for l in cl.derivation(names=nm): print('     ', l)

# engine failures not predicted by Lemma 5.0: classify minimal failing sets
from search import minimise
shapes = collections.Counter(); shown = 0
for C, C2, XE, XE2, Y, w in unpred:
    reqs = [('dom', C, XE), ('dom', C2, XE2), ('cmp', T, C, 2), ('cmp', T, C2, 2), ('cmp', T, Y, w)]
    mn, clm = minimise(S, reqs, coh)
    nm = {T: 'T', C: 'C', C2: 'C2', XE: 'X_E', XE2: "X_E'", Y: 'Y_H'}
    sig = tuple(clm.req_str(q, nm) for q in mn)
    shapes[tuple(sorted(s.split(':')[0] + ':' + s.split(':')[1][:12] for s in sig))] += 1
    if shown < 2:
        shown += 1
        print('\nunpredicted failure, minimal set:'); [print('   ', s) for s in sig]
        for l in clm.derivation(names=nm): print('      ', l)
print('\nunpredicted failures by minimal request shape:')
for k, v in shapes.items(): print('  ', v, k)
