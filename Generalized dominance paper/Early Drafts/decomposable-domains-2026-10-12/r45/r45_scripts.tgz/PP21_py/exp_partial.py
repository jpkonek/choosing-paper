"""PP21 experiment 8: partial-source rivals (PP19 Prop 9).

(S) needs T competitive against every model, in particular against every
partial source T[D' -> C] of a protected defender C (D' a proper non-empty part
of {C != T}).  Starting from a clean J1 solution (fixed), we ask for each such
rival whether T has a clean defence at some world given the solution, and
reduce every 'no defence at any world' case to minimal failing request sets.
"""
import sys, collections, itertools, random
sys.argv = ['x']
from exp_joint import J1, ORD, S, cat, T
from search import Searcher, minimise, improvement
from engine import closure_of, mk_rec
from exp_deadends import classify
MODE = sys.argv_mode if hasattr(sys, 'argv_mode') else None
import os
if os.environ.get('PP21_TWIN'):
    from exp_split import rivals_twin, orders
    from catcache import catalogue
    S = S.split([S.names[k] for k in S.silent_cells()]); cat = catalogue(S); T = S.T
    R = rivals_twin(S); ORD = orders(T); RUNS = ('nearT', 'precise', 'rand1')
else:
    R = J1(); RUNS = ('nearT', 'precise', 'rand1', 'rand2')
rnd = random.Random(5)
for on in RUNS:
    sr = Searcher(S, cat, R, defender_order=ORD[on], max_nodes=4000)
    res, info = sr.solve()
    coh = sr.coh
    nps = 0; nodef = 0; tally = collections.Counter(); shown = 0; tight = 0
    for C in list(res.P):
        D = [k for k in range(S.n) if C[k] != T[k]]
        if len(D) < 2: continue
        subs = [s for m in range(1, len(D)) for s in itertools.combinations(D, m)] if len(D) <= 8 else \
               [tuple(sorted(rnd.sample(D, rnd.randint(1, len(D) - 1)))) for _ in range(150)]
        for sub in set(subs):
            X = list(T)
            for k in sub: X[k] = C[k]
            X = tuple(X); nps += 1
            if res.defends(T, X): continue
            ok = [w for w in range(3) if not improvement(S, mk_rec(T, X), w)
                  and closure_of(S, [('cmp', T, X, w)], coherent=coh, base=res).failure is None]
            if ok: continue
            nodef += 1
            kinds = []
            for w in range(3):
                if improvement(S, mk_rec(T, X), w): kinds.append(f'w{w+1}:X<T by guidance'); continue
                cl = closure_of(S, [('cmp', T, X, w)], coherent=coh, base=res)
                reqs = [cl.requests[i] for i in sorted(cl.failure_support())]
                mn, clm = minimise(S, reqs, coh)
                c = classify(clm); kinds.append(f'w{w+1}:{c}/{len(mn)}')
                if shown < 2:
                    shown += 1
                    names = dict(sr.names); names[X] = 'X=T[D\'->C]'; names[C] = 'C'
                    for x in mn:
                        if x[0] == 'dom': names.setdefault(x[1], 'C(' + sr.nm(x[2]) + ')')
                    print(f'  [{on}] partial source of C={S.show(C)} on {[S.names[k] for k in sub]}: T R_{w+1} X fails, minimal set:')
                    for x in mn: print('       ', clm.req_str(x, names))
                    for l in clm.derivation(names=names): print('          ', l)
            tally[tuple(kinds)] += 1
    print(f'{on}: |P|={len(res.P)}; partial-source rivals tested {nps}; with no clean defence of T at any world: {nodef}')
    for k, v in tally.most_common(6): print('     ', v, k)
    sys.stdout.flush()
