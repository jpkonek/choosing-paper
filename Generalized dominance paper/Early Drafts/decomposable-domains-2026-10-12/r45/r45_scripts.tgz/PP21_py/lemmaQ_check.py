"""PP21: exact check of Lemma Q.  For K inside M containing the two vertices of M
other than v_k, every answer D_K gives where T is silent is wrong at world k.
Tested on random rational gambles for corner cuts {m_k <= t} at several t,
and on random convex K = conv(v_i, v_j, random points of M)."""
from fractions import Fraction as Fr
import random
from cells import T_VERTS, EPS, C0, advice_of
rnd = random.Random(1)
def rand_pt_M():
    a = [Fr(rnd.randint(0, 50)) for _ in range(3)]; s = sum(a) or 1
    return tuple(C0 + EPS * x / s for x in a)
bad = tested = 0
for trial in range(300):
    k = rnd.randrange(3); i, j = [q for q in range(3) if q != k]
    K = [T_VERTS[i], T_VERTS[j]] + [rand_pt_M() for _ in range(rnd.randint(1, 4))]
    for _ in range(200):
        g = tuple(Fr(rnd.randint(-30, 30), rnd.randint(1, 7)) for _ in range(3))
        try: a, b = advice_of(T_VERTS, g), advice_of(K, g)
        except ValueError: continue
        if a == 2 and b != 2:
            tested += 1
            s = 1 if b == 0 else -1
            if s * g[k] > 0: bad += 1
print(f'new answers of K (K in M containing the other two vertices) tested: {tested}; correct at world k: {bad}')
