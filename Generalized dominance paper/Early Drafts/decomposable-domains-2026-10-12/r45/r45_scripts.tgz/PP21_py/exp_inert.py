"""PP21 experiment 6: anatomy of clean joint closures (class J1) and an independent
re-verification of each (verify.verify: rules II, III/IV, F1, F2 re-checked from the
definitions, F2 by polygon clipping).  For each clean closure we count the records
installed by requests and by rules II/III, and the P-members entered by rule IV."""
import sys, collections, time
sys.argv = ['x']
from exp_joint import J1, ORD, S, cat, T
from search import Searcher
from verify import verify
R = J1()
for on in ORD:
    for ties in (False, 'first'):
        sr = Searcher(S, cat, R, defender_order=ORD[on], max_nodes=4000, ties=ties)
        res, info = sr.solve()
        if res is None: print(on, ties, 'no clean solution'); continue
        c = collections.Counter()
        for w in range(3):
            for r, j in res.inst[w].items(): c[j[0]] += 1
        pj = collections.Counter(j[0] for j in res.P.values())
        e = verify(res)
        nreq = len(res.requests)
        kinds = collections.Counter(q[0] for q in res.requests)
        # defenders that are tightenings of T: agree with T wherever T answers
        P = [N for N in res.P if N != T]
        tight = sum(all(N[k] == T[k] for k in range(S.n) if T[k] != 2) for N in P)
        print(f'{on:9} ties={str(ties):5}: requests {dict(kinds)}; installed records by origin {dict(c)}; '
              f'P by origin {dict(pj)}; P-members that are tightenings of T (agree where T answers): {tight}/{len(P)}; '
              f'independent verification errors: {len(e)}')
        sys.stdout.flush()
