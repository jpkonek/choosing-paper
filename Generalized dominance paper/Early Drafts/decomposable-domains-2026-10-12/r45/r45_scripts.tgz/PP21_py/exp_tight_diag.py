"""PP21: diagnose partial sources left undefended by the tightening-only twin
solution (order nearT): minimal failing sets and derivations, per world."""
import sys, itertools, random, collections
sys.argv = ['x']
from exp_joint import S as S1
from exp_split import rivals_twin, orders
from catcache import catalogue
from search import Searcher, improvement, minimise
from engine import closure_of, mk_rec
from exp_deadends import classify
S = S1.split([S1.names[k] for k in S1.silent_cells()]); cat = catalogue(S); T = S.T
pool = [C for C in cat if all(C[k] == T[k] for k in range(S.n) if T[k] != 2)]
R = rivals_twin(S)
sr = Searcher(S, cat, R, defender_order=orders(T)['nearT'], max_nodes=6000, pool=pool)
res, _ = sr.solve()
print('|P| =', len(res.P))
for i, N in enumerate(res.P):
    print(f'  P{i}:', {S.names[k]: 'PNSX'[N[k]] for k in range(S.n) if N[k] != T[k]})
rnd = random.Random(9)
for C in list(res.P):
    D = [k for k in range(S.n) if C[k] != T[k]]
    if len(D) < 2: continue
    subs = [s for m in range(1, len(D)) for s in itertools.combinations(D, m)] if len(D) <= 8 else \
           list({tuple(sorted(rnd.sample(D, rnd.randint(1, len(D) - 1)))) for _ in range(150)})
    for sub in subs:
        X = list(T)
        for k in sub: X[k] = C[k]
        X = tuple(X)
        if res.defends(T, X): continue
        if any(not improvement(S, mk_rec(T, X), w) and closure_of(S, [('cmp', T, X, w)], coherent=sr.coh, base=res).failure is None for w in range(3)):
            continue
        names = dict(sr.names); names[X] = 'Y'
        print(f'\nno defence of T against Y = T[{[S.names[k] for k in sub]} -> C], C differs from T on {[S.names[k] for k in D]}')
        for w in range(3):
            if improvement(S, mk_rec(T, X), w): print(f'  world {w+1}: Y <_w T by strict guidance'); continue
            cl = closure_of(S, [('cmp', T, X, w)], coherent=sr.coh, base=res)
            reqs = [cl.requests[i] for i in sorted(cl.failure_support())]
            mn, clm = minimise(S, reqs, sr.coh)
            for x in mn:
                if x[0] == 'dom': names.setdefault(x[1], 'C(' + sr.nm(x[2]) + ')')
            print(f'  world {w+1}: class {classify(clm)}; minimal set:')
            for x in mn: print('      ', clm.req_str(x, names))
            for l in clm.derivation(names=names): print('         ', l)
