"""PP21: who defends whom in the nearT clean solutions (J1 and twin split).
Prints P and, for each rival, the members of P that dominate it at all worlds and
T's defence worlds.  'tightening' = agrees with T wherever T answers."""
import sys
sys.argv = ['x']
from exp_joint import J1, ORD, S, cat, T
from exp_split import rivals_twin, orders
from catcache import catalogue
from search import Searcher
from engine import mk_rec
def show(tag, S_, cat_, R, o):
    sr = Searcher(S_, cat_, R, defender_order=o, max_nodes=6000)
    res, _ = sr.solve()
    Pl = list(res.P)
    print(f'== {tag}: |P| = {len(Pl)}')
    for i, N in enumerate(Pl):
        D = [S_.names[k] for k in range(S_.n) if N[k] != S_.T[k]]
        tight = all(N[k] == S_.T[k] for k in range(S_.n) if S_.T[k] != 2)
        print(f'  P{i}: differs from T on {D} -> {["PNSX"[N[S_.idx[d]]] for d in D]}  tightening={tight}  T defends at {[w+1 for w in res.defends(S_.T, N)]}')
    for nm, X in R.items():
        ds = [i for i, N in enumerate(Pl) if all(res.accepted(mk_rec(N, X), w) for w in range(3))]
        print(f'  {nm:22} dominated by P{ds}  T defends at {[w+1 for w in res.defends(S_.T, X)]}')
    sys.stdout.flush()
show('J1 nearT', S, cat, J1(), ORD['nearT'])
S2 = S.split([S.names[k] for k in S.silent_cells()]); cat2 = catalogue(S2)
show('twin nearT', S2, cat2, rivals_twin(S2), orders(S2.T)['nearT'])
