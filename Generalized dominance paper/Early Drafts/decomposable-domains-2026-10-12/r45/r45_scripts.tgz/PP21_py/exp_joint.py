"""PP21 experiment 4: joint search over the rival class.

Classes (all on the 25-cell model):
  J1 = X*, Y_12, Lambda_T, V_c*, majority and minority fills of every single
       T-silent cell (36), and every majority fill on two cells from two
       different minority classes (X*/Y_H-type, 108).
  J2 = J1 + every fill of two T-silent cells with any of maj/min on each (612).
  J3 = J2 + 1000 random fills of T's silence (each silent cell independently
       S / maj / min), seed 7.
Defender orders: nearT (fewest cells differing from T), precise-first,
imprecise-first, random (3 seeds); T-defence options weak-first or
single-world-tie-first.  Also all 36 fixed choices of T's world against
(X*, Y_12, Lambda_T, V_c*).
Reported for clean solutions: |P|, records, P-members entered by rule IV (all-world
ties; these are the only places where avoiding F2 depends on the cell-level
coherence test of a splice), and T's defence worlds for the named rivals.
"""
import random, sys, time, itertools, collections
from cells import standard_space
from catcache import catalogue
from engine import mk_rec
from search import Searcher, named_rivals, fill_rivals

S = standard_space(); cat = catalogue(S); T = S.T
sil = S.silent_cells()
def J1():
    R = named_rivals(S); R.update(fill_rivals(S, max_cells=1))
    for c1, c2 in itertools.combinations(range(3), 2):
        for a in [k for k in sil if S.minworld[k] == c1]:
            for b in [k for k in sil if S.minworld[k] == c2]:
                R[f'maj[{S.names[a]}+{S.names[b]}]'] = S.fill(T, [a, b], 'maj')
    return R
def J2():
    R = J1(); R.update(fill_rivals(S, max_cells=2, mixed=True)); return R
def J3():
    R = J2(); rnd = random.Random(7)
    for t in range(1000):
        X = list(T)
        for k in sil: X[k] = rnd.choice([2, S.maj[k], S.mino[k]])
        R[f'rand{t}'] = tuple(X)
    return R

nd = lambda C: sum(a != b for a, b in zip(C, T))
ORD = {
    'nearT': lambda X, cat: sorted(cat, key=lambda C: (nd(C), C)),
    'precise': lambda X, cat: sorted(cat, key=lambda C: (sum(v == 2 for v in C), nd(C), C)),
    'imprecise': lambda X, cat: sorted(cat, key=lambda C: (-sum(v == 2 for v in C), C)),
    'rand1': lambda X, cat: random.Random(1).sample(cat, len(cat)),
    'rand2': lambda X, cat: random.Random(2).sample(cat, len(cat)),
    'rand3': lambda X, cat: random.Random(3).sample(cat, len(cat)),
}

def report(tag, R, sr, res, info, t0):
    if res is None:
        print(f'{tag}: {"BUDGET" if info == "budget" else "DEAD"} nodes={sr.nodes} dead-ends={len(sr.dead_ends)} {time.time()-t0:.1f}s')
        return
    ties = [N for N, j in res.P.items() if j[0] == 'IV']
    named = {k: [w + 1 for w in res.defends(T, R[k])] for k in ('X*', 'Y12', 'LamT', 'Vc*')}
    print(f'{tag}: CLEAN rivals={len(R)} nodes={sr.nodes} dead-ends={len(sr.dead_ends)} |P|={len(res.P)} '
          f'records/world={res.stats()["records"]} rule-IV members={len(ties)} T-defence worlds {named} {time.time()-t0:.1f}s')
    sys.stdout.flush()

if __name__ == '__main__':
    part = sys.argv[1] if len(sys.argv) > 1 else 'a'
    if part == 'a':
        R = J1()
        for oname, o in ORD.items():
            for ties in (False, 'first'):
                t0 = time.time()
                sr = Searcher(S, cat, R, defender_order=o, max_nodes=4000, ties=ties)
                res, info = sr.solve()
                report(f'J1 order={oname} ties={ties}', R, sr, res, info, t0)
                if oname == 'nearT' and not ties and res is not None:
                    for N, j in res.P.items():
                        print('     P:', S.show(N), sr.nm(N), 'entered by', j[0])
    if part == 'b':
        R = J1(); cnt = collections.Counter()
        for wx, wy, wl, wv in itertools.product((0, 1), (0, 1), (0, 1, 2), (0, 1, 2)):
            fixed = [('cmp', T, R['X*'], wx), ('cmp', T, R['Y12'], wy), ('cmp', T, R['LamT'], wl), ('cmp', T, R['Vc*'], wv)]
            for oname in ('nearT', 'rand1'):
                t0 = time.time()
                sr = Searcher(S, cat, R, defender_order=ORD[oname], max_nodes=4000, fixed=fixed)
                res, info = sr.solve()
                cnt[(oname, res is not None)] += 1
                if res is None: report(f'fixed worlds X*={wx+1} Y12={wy+1} Lam={wl+1} V={wv+1} order={oname}', R, sr, res, info, t0)
        print('fixed named-world combinations (order, clean):', dict(cnt))
    if part in ('c', 'd'):
        R = J2() if part == 'c' else J3()
        for oname in ('nearT', 'precise', 'rand1'):
            t0 = time.time()
            sr = Searcher(S, cat, R, defender_order=ORD[oname], max_nodes=6000)
            res, info = sr.solve()
            report(f'{"J2" if part == "c" else "J3"} order={oname}', R, sr, res, info, t0)
    if part == 'e':
        # strict exposure: no rule-IV ties allowed (any all-world tie with a member of P counts as F2),
        # coherent rivals may not be registered: they too need a dominator.
        from engine import Closure
        orig = Closure._rule3
        def strict_rule3(self, r, N):
            if not all(self.accepted(r, w) for w in range(3)): return
            from engine import source_of
            X = source_of(r, N)
            self.register(X, ('IV', N, X, tuple(self.why(r, w) for w in range(3))))
            from engine import Failure
            raise Failure('F2', ('P', X), self)
        Closure._rule3 = strict_rule3
        for cls in ('J1', 'J2'):
            R = J1() if cls == 'J1' else J2()
            for oname in ('nearT', 'precise', 'rand1'):
                t0 = time.time()
                sr = Searcher(S, cat, R, defender_order=ORD[oname], max_nodes=6000, allow_reg=False)
                res, info = sr.solve()
                report(f'STRICT {cls} order={oname}', R, sr, res, info, t0)
        Closure._rule3 = orig
    if part == 'f':
        # closure under partial sources (PP19 Prop 9): T must also be competitive against, and
        # (S) needs a dominator of, every T[D' -> C] with C in P and D' inside {C != T}.
        rnd = random.Random(11)
        R = J1(); fixed = []
        for rnd_i in range(4):
            t0 = time.time()
            on = sys.argv[2] if len(sys.argv) > 2 else 'rand1'
            sr = Searcher(S, cat, R, defender_order=ORD[on], max_nodes=8000, fixed=fixed)
            res, info = sr.solve()
            report(f'partial-source round {rnd_i} order={on} (rivals {len(R)})', R, sr, res, info, t0)
            if res is None: break
            fixed = [q for q in res.requests if not (q[0] == 'reg' and q[1] == T)]
            new = 0
            for C in list(res.P):
                D = [k for k in range(S.n) if C[k] != T[k]]
                subs = [s for m in range(1, len(D)) for s in itertools.combinations(D, m)] if len(D) <= 10 else \
                       [tuple(sorted(rnd.sample(D, rnd.randint(1, len(D) - 1)))) for _ in range(200)]
                for sub in subs:
                    X = list(T)
                    for k in sub: X[k] = C[k]
                    X = tuple(X)
                    if X not in R.values():
                        R[f'part[{sr.nm(C)}|{"+".join(S.names[k] for k in sub)}]'] = X; new += 1
            print(f'   added {new} partial-source rivals'); sys.stdout.flush()
            if new == 0: break
