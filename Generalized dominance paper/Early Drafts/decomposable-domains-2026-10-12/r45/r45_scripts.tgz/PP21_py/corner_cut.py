"""PP21: which new answers does a corner tightening give?  K_t = M cut by
{m_3 <= t}, t = c + eps/2 (cuts off T's world-3 vertex).  Exact rational test on
random gambles: classes (minority world) and answer type (majority/minority)
where T is silent and D_{K_t} answers.  Used in section 8 (design caveat)."""
from fractions import Fraction as Fr
import random, collections
from cells import T_VERTS, EPS, C0, advice_of
t = C0 + EPS / 2
v1, v2, v3 = T_VERTS
def pt(a, b, s):  # point on segment a->b with third coordinate s
    lam = (s - a[2]) / (b[2] - a[2]); return tuple(a[q] + lam * (b[q] - a[q]) for q in range(3))
K = [v1, v2, pt(v1, v3, t), pt(v2, v3, t)]
rnd = random.Random(0); cnt = collections.Counter(); n = 0
while n < 20000:
    g = tuple(Fr(rnd.randint(-40, 40), rnd.randint(1, 9)) for _ in range(3))
    try:
        a, b = advice_of(T_VERTS, g), advice_of(K, g)
    except ValueError: continue
    pos = [x > 0 for x in g]
    if sum(pos) in (0, 3) or 0 in g: continue
    n += 1
    if a == 2 and b != 2:
        majpos = sum(pos) == 2
        minworld = [q for q in range(3) if pos[q] != majpos][0] + 1
        kind = 'maj' if (b == 0) == majpos else 'min'
        cnt[(f'M_{minworld}', kind)] += 1
print('new answers of the corner cut K_t = M & {m_3 <= c + eps/2}, among 20000 random mixed gambles:')
for k, v in sorted(cnt.items()): print('  ', k, v)
