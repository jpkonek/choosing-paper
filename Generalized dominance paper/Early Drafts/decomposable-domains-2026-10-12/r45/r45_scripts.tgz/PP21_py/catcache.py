"""Cache the exact coherent catalogue of a Space (keyed by its distinct gambles)."""
import pickle, os, hashlib
from cells import coherent_catalogue
HERE = os.path.dirname(os.path.abspath(__file__))
def catalogue(S):
    dist = []
    pos = []
    for g in S.g:
        if g not in dist: dist.append(g)
        pos.append(dist.index(g))
    key = hashlib.sha1(repr(dist).encode()).hexdigest()[:16]
    fn = os.path.join(HERE, f'cat_{key}.pkl')
    if os.path.exists(fn):
        with open(fn, 'rb') as f: cat = pickle.load(f)
    else:
        cat = sorted(coherent_catalogue(dist))
        with open(fn, 'wb') as f: pickle.dump(cat, f)
    return sorted({tuple(v[pos[k]] for k in range(S.n)) for v in cat})
