"""PP21: independent checks of the closure engine.

verify(cl): re-checks a finished clean closure directly from the definitions
  (II) every pair of installed records that composes, with accepted inverse
       composite, has all three reverses accepted;
  (II') every installed record has a strictly positive rank change (so no
       triangle with one installed and two guidance links);
  (III/IV) every record accepted at all worlds that ends at a member of P has
       its reverse accepted at all worlds and its source in P;
  F1: no installed record is a weak improvement; F2: every member of P is
      coherent by the polygon-clipping test (independent of the catalogue).

brute(): on small cell spaces, compares the record-level closure with the
model-level definition: all 4^n models, every triple at every world, and
rules III/IV over P, with random request sets.
"""
import itertools, random, sys
from engine import Closure, mk_rec, inv, comp, is_empty, ends_at, source_of

def verify(cl):
    S = cl.S
    errs = []
    for w in range(3):
        recs = list(cl.inst[w])
        for r in recs:
            if not any(d > 0 for d in cl.deltas(r, w)): errs.append(('noworse', w, r))
            if cl.improvement(r, w): errs.append(('F1', w, r))
        for r in recs:
            for s in recs:
                c = comp(r, s)
                # composable?
                ok = all(x < 0 or y < 0 or x % 4 == y // 4 for x, y in zip(r, s))
                if not ok or is_empty(c): continue
                if cl.accepted(inv(c), w):
                    for t in (inv(r), inv(s), c):
                        if not cl.accepted(t, w): errs.append(('II', w, r, s))
    allrecs = set(cl.inst[0]) | set(cl.inst[1]) | set(cl.inst[2])
    for N in cl.P:
        if not S.is_coherent(N): errs.append(('F2', N))
        for r in allrecs:
            if ends_at(r, N) and all(cl.accepted(r, w) for w in range(3)):
                if not all(cl.accepted(inv(r), w) for w in range(3)): errs.append(('III', N, r))
                if source_of(r, N) not in cl.P: errs.append(('IV', N, r))
    return errs

def brute(trials=200, seed=0):
    from cells import Space, base_cells
    rnd = random.Random(seed)
    allc = base_cells()
    pick = [c for c in allc if c[0] in ('R3', 'A3', 'Gp1', 'B2', 'W12')]
    nbad = 0; nclean = 0; nfail = 0
    for t in range(trials):
        cells = rnd.sample(pick, 3)
        S = Space(cells)
        models = list(itertools.product(range(4), repeat=S.n))
        coh = {X: S.is_coherent(X) for X in models}
        cohl = [X for X in models if coh[X]]
        cl = Closure(S, lambda X: coh[X]); cl.request(('reg', S.T))
        for _ in range(rnd.randint(1, 4)):
            if rnd.random() < 0.5:
                C = rnd.choice(cohl); X = rnd.choice(models)
                if C != X: cl.request(('dom', C, X))
            else:
                A = S.T if rnd.random() < 0.7 else rnd.choice(models)
                cl.request(('cmp', A, rnd.choice(models), rnd.randrange(3)))
        cl.run()
        if cl.failure is not None:
            nfail += 1
            continue
        nclean += 1
        R = [[[cl.accepted(mk_rec(A, B), w) for B in models] for A in models] for w in range(3)]
        ix = {X: i for i, X in enumerate(models)}
        n = len(models)
        bad = 0
        for w in range(3):
            Rw = R[w]
            for a in range(n):
                for b in range(n):
                    if not Rw[a][b]: continue
                    for c in range(n):
                        if Rw[b][c] and Rw[c][a] and not (Rw[a][c] and Rw[b][a] and Rw[c][b]): bad += 1
        for N in cl.P:
            i = ix[N]
            for X in models:
                j = ix[X]
                if all(R[w][j][i] for w in range(3)):
                    if not all(R[w][i][j] for w in range(3)) or X not in cl.P: bad += 1
            if not coh[N]: bad += 1
        # strict guidance reverses
        for w in range(3):
            for a in range(n):
                for b in range(n):
                    r = mk_rec(models[a], models[b])
                    if R[w][a][b] and cl.improvement(r, w): bad += 1
        nbad += bad
    return nclean, nfail, nbad

if __name__ == '__main__':
    nc, nf, nb = brute(int(sys.argv[1]) if len(sys.argv) > 1 else 150)
    print(f'brute-force model-level check on 3-cell spaces: {nc} clean closures, {nf} failing, violations {nb}')

def naive_closure(S, models, coh, reqs):
    """Model-level least fixpoint of rules I-IV by exhaustive iteration over all
    triples of models (records stand for (IB) classes).  Returns (status, acc, P)."""
    def guid(r, w):
        return all(S.rank[w][k][v % 4] - S.rank[w][k][v // 4] >= 0 for k, v in enumerate(r) if v >= 0)
    def imp(r, w):
        ds = [S.rank[w][k][v % 4] - S.rank[w][k][v // 4] for k, v in enumerate(r) if v >= 0]
        return len(ds) > 0 and all(d <= 0 for d in ds)
    acc = [set() for _ in range(3)]
    P = {S.T}
    for q in reqs:
        if q[0] == 'dom':
            P.add(q[1]); [acc[w].add(mk_rec(q[1], q[2])) for w in range(3)]
        elif q[0] == 'cmp':
            acc[q[3]].add(mk_rec(q[1], q[2]))
    A = lambda r, w: is_empty(r) or guid(r, w) or r in acc[w]
    n = len(models)
    rec = {}
    for a in models:
        for b in models: rec[a, b] = mk_rec(a, b)
    changed = True
    while changed:
        changed = False
        for w in range(3):
            if any(imp(r, w) for r in acc[w]): return 'F1', acc, P
        if any(not coh[N] for N in P): return 'F2', acc, P
        for w in range(3):
            for a in models:
                for b in models:
                    if not A(rec[a, b], w): continue
                    for c in models:
                        if A(rec[b, c], w) and A(rec[c, a], w):
                            for r in (rec[a, c], rec[b, a], rec[c, b]):
                                if not A(r, w): acc[w].add(r); changed = True
        for N in list(P):
            for X in models:
                if all(A(rec[X, N], w) for w in range(3)):
                    for w in range(3):
                        if not A(rec[N, X], w): acc[w].add(rec[N, X]); changed = True
                    if X not in P: P.add(X); changed = True
        # pure guidance dominators are covered by the loop above (guid records)
    return 'clean', acc, P

def brute2(trials=60, seed=1):
    from cells import Space, base_cells
    rnd = random.Random(seed)
    allc = base_cells()
    pick = [c for c in allc if c[0] in ('R3', 'A3', 'Gp1', 'B2', 'W12', 'A1')]
    agree = 0; disagree = 0; kinds = {}
    for t in range(trials):
        S = Space(rnd.sample(pick, 3))
        models = list(itertools.product(range(4), repeat=S.n))
        coh = {X: S.is_coherent(X) for X in models}
        cohl = [X for X in models if coh[X]]
        reqs = []
        for _ in range(rnd.randint(1, 4)):
            if rnd.random() < 0.5:
                C = rnd.choice(cohl); X = rnd.choice(models)
                if C != X: reqs.append(('dom', C, X))
            else:
                reqs.append(('cmp', S.T if rnd.random() < 0.7 else rnd.choice(models), rnd.choice(models), rnd.randrange(3)))
        cl = Closure(S, lambda X: coh[X]); cl.request(('reg', S.T))
        for q in reqs: cl.request(q)
        cl.run()
        st, acc, P = naive_closure(S, models, coh, reqs)
        e = 'clean' if cl.failure is None else 'fail'
        b = 'clean' if st == 'clean' else 'fail'
        same = (e == b)
        if same and e == 'clean':
            same = all(set(cl.inst[w]) == {r for r in acc[w] if not cl.guidance(r, w)} for w in range(3)) and set(cl.P) == P
        kinds[(e, b)] = kinds.get((e, b), 0) + 1
        if same: agree += 1
        else: disagree += 1
    return agree, disagree, kinds

if __name__ == '__main__' and len(sys.argv) > 2:
    print('engine vs naive model-level fixpoint (agree, disagree, kinds):', brute2(int(sys.argv[2])))
