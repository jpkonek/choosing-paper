"""PP21: search over defender choices and T's defence worlds.

Obligations (for a finite rival class Rv; checked against the closure):
  (D) every rival X needs some N in P with N R_i X accepted at all i
      (the dominator demanded by (S) via KKM).  Options: reg(X) if X is
      coherent (X itself becomes protected), else dom(C, X) for a coherent C.
  (T) T must be competitive against every rival and every member of P:
      some w with T R_w X accepted.  Options: cmp(T, X, w), w = 1, 2, 3.
Because the closure is monotone, a satisfied obligation stays satisfied in
every extension; the DFS therefore scans obligations with a moving pointer.
A node whose every option fails is a dead end; its failures (with their
derivations) are kept.
"""
import itertools, random
from engine import Closure, closure_of, mk_rec

def named_rivals(S):
    T = S.T
    sil = S.silent_cells()
    R = {}
    R['X*'] = S.fill(T, [k for k in range(S.n) if S.names[k].rstrip('ab') in ('A1', 'A2')], 'maj')
    R['Y12'] = S.fill(T, [k for k in range(S.n) if S.names[k].rstrip('ab') in ('R1', 'R2')], 'maj')
    R['LamT'] = S.fill(T, sil, 'maj')
    R['Vc*'] = S.V
    return R

def fill_rivals(S, kinds=('maj', 'min'), max_cells=1, cellset=None, mixed=False):
    T = S.T
    sil = S.silent_cells() if cellset is None else [S.idx[c] for c in cellset]
    R = {}
    for m in range(1, max_cells + 1):
        for E in itertools.combinations(sil, m):
            if mixed:
                for vals in itertools.product(kinds, repeat=m):
                    X = list(T)
                    for k, kd in zip(E, vals): X[k] = S.maj[k] if kd == 'maj' else S.mino[k]
                    nm = '[' + '+'.join(f'{S.names[k]}:{kd}' for k, kd in zip(E, vals)) + ']'
                    R[nm] = tuple(X)
            else:
                for kd in kinds:
                    R[f'{kd}[' + '+'.join(S.names[k] for k in E) + ']'] = S.fill(T, E, kd)
    return R

def improvement(S, r, w):
    ds = [S.rank[w][k][v % 4] - S.rank[w][k][v // 4] for k, v in enumerate(r) if v >= 0]
    return len(ds) > 0 and all(d <= 0 for d in ds)


class Searcher:
    def __init__(self, S, cat, rivals, defender_order=None, max_nodes=20000,
                 t_worlds=(0, 1, 2), allow_reg=True, fixed=(), ties=False, pool=None):
        self.ties = ties
        self.pool = pool       # optional restricted list of candidate defenders
        self.S, self.cat, self.catset = S, cat, set(cat)
        self.coh = lambda X: X in self.catset
        self.rivals = list(rivals.items())
        self.names = {v: k for k, v in rivals.items()}
        self.names[S.T] = 'T'
        self.max_nodes = max_nodes
        self.nodes = 0
        self.defender_order = defender_order
        self.t_worlds = t_worlds
        self.allow_reg = allow_reg
        self.fixed = list(fixed)
        self.dead_ends = []
        self._cand = {}

    def nm(self, X): return self.names.get(X, self.S.show(X))

    # ----------------------------------------------------- candidates
    def candidates(self, X):
        """Coherent C != X, generated lazily in a fixed order, each clean on
        its own: closure{dom(C, X)} clean and closure{dom(C,X), T R_w C}
        clean for some w."""
        if X not in self._cand:
            base = self.cat if self.pool is None else self.pool
            order = base if self.defender_order is None else self.defender_order(X, base)
            self._cand[X] = ([], iter(order))
        done, it = self._cand[X]
        for C in list(done): yield C
        S = self.S
        while True:
            try: C = next(it)
            except StopIteration: return
            if C == X or not self.quick_ok(C, X): continue
            cl = closure_of(S, [('dom', C, X)], coherent=self.coh)
            if cl.failure is not None: continue
            if not cl.defends(S.T, C) and not any(
                    closure_of(S, [('cmp', S.T, C, w)], coherent=self.coh, base=cl).failure is None
                    for w in self.t_worlds):
                continue
            done.append(C)
            yield C

    def quick_ok(self, C, X):
        S = self.S
        for w in range(3):
            if not any(S.rank[w][k][C[k]] < S.rank[w][k][X[k]] for k in range(S.n)): return False
        return True

    # ----------------------------------------------------- obligations
    def dominated(self, cl, X):
        if X in cl.P: return True
        return any(all(cl.accepted(mk_rec(N, X), w) for w in range(3)) for N in cl.P)

    def next_obligation(self, cl, ptr):
        """P-members' T-defences first (they have <= 3 options), then rivals."""
        i, j = ptr
        Ps = list(cl.P)
        while j < len(Ps):
            N = Ps[j]
            if N != self.S.T and not cl.defends(self.S.T, N): return ('T', self.nm(N), N), (i, j)
            j += 1
        while i < len(self.rivals):
            nm, X = self.rivals[i]
            if not cl.defends(self.S.T, X): return ('T', nm, X), (i, j)
            if not self.dominated(cl, X): return ('D', nm, X), (i, j)
            i += 1
        return None, (i, j)

    def options(self, ob):
        X = ob[2]
        if ob[0] == 'T':
            ok = [w for w in self.t_worlds if not improvement(self.S, mk_rec(self.S.T, X), w)]
            weak = [('cmp', self.S.T, X, w) for w in ok]
            ties = [('tie', self.S.T, X, w) for w in ok
                    if not improvement(self.S, mk_rec(X, self.S.T), w)] if self.ties else []
            return ties + weak if self.ties == 'first' else weak + ties
        head = [('reg', X)] if (self.coh(X) and self.allow_reg) else []
        return itertools.chain(head, (('dom', C, X) for C in self.candidates(X)))

    # ------------------------------------------------------------ DFS
    def solve(self):
        import sys, threading
        sys.setrecursionlimit(1000000)
        threading.stack_size(1 << 29)
        out = {}
        th = threading.Thread(target=lambda: out.setdefault('r', self._solve()))
        th.start(); th.join()
        return out['r']

    def _solve(self):
        base = Closure(self.S, self.coh); base.request(('reg', self.S.T))
        for q in self.fixed: base.request(q)
        base.run()
        if base.failure is not None: return None, ('fixed', base)
        return self._dfs(base, (0, 0))

    def _dfs(self, cl, ptr):
        self.nodes += 1
        if self.nodes > self.max_nodes: return None, 'budget'
        ob, ptr = self.next_obligation(cl, ptr)
        if ob is None: return cl, None
        fails = []
        for q in self.options(ob):
            c2 = cl.clone(); c2.request(q); c2.run()
            if c2.failure is not None:
                fails.append((q, c2)); continue
            res, info = self._dfs(c2, ptr)
            if res is not None: return res, None
            if info == 'budget': return None, 'budget'
        self.dead_ends.append((ob, cl, fails))
        return None, ('dead', ob, fails)


def minimise(S, reqs, coh):
    """Deletion-minimal failing subset of a failing request list (T is
    always registered)."""
    def run(rs):
        cl = Closure(S, coh); cl.request(('reg', S.T))
        for q in rs: cl.request(q)
        cl.run()
        return cl
    assert run(reqs).failure is not None
    cur = [q for q in reqs if not (q[0] == 'reg' and q[1] == S.T)]
    i = 0
    while i < len(cur):
        trial = cur[:i] + cur[i + 1:]
        if run(trial).failure is not None: cur = trial
        else: i += 1
    return cur, run(cur)

def failure_requests(cl):
    return [cl.requests[i] for i in sorted(cl.failure_support())]


def solve_greedy(sr):
    """Memory-light variant of Searcher.solve: no backtracking.  At each
    obligation the first option whose closure is clean is committed.  Returns
    (closure, None) or (None, ('stuck', obligation, failures)); 'stuck' is not a
    proof that no solution exists."""
    base = Closure(sr.S, sr.coh); base.request(('reg', sr.S.T))
    for q in sr.fixed: base.request(q)
    base.run()
    if base.failure is not None: return None, ('fixed', base)
    cl, ptr = base, (0, 0)
    while True:
        sr.nodes += 1
        ob, ptr = sr.next_obligation(cl, ptr)
        if ob is None: return cl, None
        fails = []
        for q in sr.options(ob):
            c2 = cl.clone(); c2.request(q); c2.run()
            if c2.failure is None: cl = c2; break
            fails.append((q, c2))
        else:
            sr.dead_ends.append((ob, cl, fails))
            return None, ('stuck', ob, fails)
