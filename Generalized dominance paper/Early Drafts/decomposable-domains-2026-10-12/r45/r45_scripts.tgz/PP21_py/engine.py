"""PP21: exact closure engine for audit's rules I-IV (AUDIT_completion.md s.3).

Relations.  By (IB) (rule I) acceptance of a comparison (A, B) at world w
depends only on its record rec(A, B) = {(k, A_k, B_k) : A_k != B_k}.  So each
relation R_w is stored as
    Guid_w  (implicit: every rank change r_w(B) - r_w(A) >= 0)   [weak guidance]
  + Inst_w  (explicit set of installed records)
and rule I holds automatically: installing a record installs every
common-context copy.  Reflexivity = the empty record.

Rule II (triangle completion).  Two copies r: A->B and s: B->C compose iff
b_r = a_s on D_r & D_s; the composite comp(r, s) = rec(A, C) is context free
(PP17 s.1).  A triangle A->B->C->A is accepted iff r, s are accepted and
inv(comp(r, s)) is accepted; rule II then installs inv(r), inv(s), comp(r, s).
Every triangle with at least two installed links is found by processing each
newly installed record against every installed record in both orders (the
last-installed link is adjacent to another installed link).  A triangle with
one installed link r and two guidance links forces r to be a weak improvement,
which is caught as F1 when r is installed.  Purely guidance triangles are
trivial (rank changes >= 0 summing to 0 around a cycle).

Rule III (protection).  X R_i N for all i means: the single record
r = rec(X, N) is accepted at all three worlds.  For N in P and every such r
whose new side agrees with N on D_r, install inv(r) at every world.
Rule IV.  Then X = N[D_r -> old side of r] is tied with N at every world and is
put into P.

F1: an installed record whose rank changes are all <= 0 at its world (the
reverse of a strict guidance comparison), including a pure-guidance all-world
dominator of a member of P.
F2: an incoherent model in P.

Every installed record and every member of P carries a justification, so a
failure yields a derivation (a finite proof) and the set of requests used.
"""
import numpy as np
from collections import deque

def mk_rec(X, Y):
    return tuple(-1 if a == b else a * 4 + b for a, b in zip(X, Y))

def inv(r):
    return tuple(-1 if v < 0 else (v % 4) * 4 + v // 4 for v in r)

def is_empty(r): return all(v < 0 for v in r)

def comp(r, s):
    out = []
    for x, y in zip(r, s):
        if x < 0 and y < 0: out.append(-1); continue
        a = x // 4 if x >= 0 else y // 4
        b = y % 4 if y >= 0 else x % 4
        out.append(-1 if a == b else a * 4 + b)
    return tuple(out)

def ends_at(r, N):
    return all(v < 0 or v % 4 == N[k] for k, v in enumerate(r))

def source_of(r, N):
    return tuple(N[k] if v < 0 else v // 4 for k, v in enumerate(r))


class Failure(Exception):
    def __init__(self, kind, key, closure):
        self.kind, self.key, self.cl = kind, key, closure
        super().__init__(kind)


class Closure:
    def __init__(self, S, coherent=None):
        self.S = S
        n = S.n
        self.n = n
        # DEL[w][k, a, b] = r_w(b) - r_w(a)
        self.DEL = []
        for w in range(3):
            D = np.zeros((n, 4, 4), dtype=np.int8)
            for k in range(n):
                for a in range(4):
                    for b in range(4):
                        D[k, a, b] = S.rank[w][k][b] - S.rank[w][k][a]
            self.DEL.append(D)
        self.coherent = coherent if coherent is not None else S.is_coherent
        self.inst = [dict() for _ in range(3)]      # record -> justification
        self.recs = [[] for _ in range(3)]
        self.OLD = [np.zeros((0, n), dtype=np.int8) for _ in range(3)]
        self.NEW = [np.zeros((0, n), dtype=np.int8) for _ in range(3)]
        self._pend = [[] for _ in range(3)]          # rows not yet in arrays
        self.P = {}                                  # model -> justification
        self.requests = []                           # list of request tuples
        self.queue = deque()
        self.newP = deque()
        self.failure = None

    # ------------------------------------------------------------ basics
    def deltas(self, r, w):
        return [int(self.DEL[w][k, v // 4, v % 4]) for k, v in enumerate(r) if v >= 0]

    def guidance(self, r, w):
        return all(d >= 0 for d in self.deltas(r, w))

    def improvement(self, r, w):
        ds = self.deltas(r, w)
        return len(ds) > 0 and all(d <= 0 for d in ds)

    def accepted(self, r, w):
        return is_empty(r) or r in self.inst[w] or self.guidance(r, w)

    def why(self, r, w):
        """justification key of an accepted record"""
        if is_empty(r): return ('refl',)
        if r in self.inst[w]: return ('inst', w, r)
        if self.guidance(r, w): return ('guid', w, r)
        return None

    def install(self, w, r, just):
        if self.accepted(r, w): return False
        self.inst[w][r] = just
        self.recs[w].append(r)
        self._pend[w].append(r)
        self.queue.append((w, r))
        return True

    def register(self, N, just):
        if N in self.P: return False
        self.P[N] = just
        self.newP.append(N)
        return True

    def _arrays(self, w):
        if self._pend[w]:
            o = np.array([[v // 4 if v >= 0 else -1 for v in r] for r in self._pend[w]], dtype=np.int8)
            nn = np.array([[v % 4 if v >= 0 else -1 for v in r] for r in self._pend[w]], dtype=np.int8)
            self.OLD[w] = np.vstack([self.OLD[w], o]); self.NEW[w] = np.vstack([self.NEW[w], nn])
            self._pend[w] = []
        return self.OLD[w], self.NEW[w]

    # ---------------------------------------------------------- requests
    def request(self, req):
        """req = ('dom', C, X): register C in P and install C R_i X at all i.
               ('cmp', A, B, w): install A R_w B.
               ('reg', N): register N in P."""
        rid = len(self.requests); self.requests.append(req)
        kind = req[0]
        if kind == 'reg':
            self.register(req[1], ('req', rid))
        elif kind == 'dom':
            _, C, X = req
            self.register(C, ('req', rid))
            r = mk_rec(C, X)
            for w in range(3): self.install(w, r, ('req', rid))
        elif kind == 'cmp':
            _, A, B, w = req
            self.install(w, mk_rec(A, B), ('req', rid))
        elif kind == 'tie':
            _, A, B, w = req
            self.install(w, mk_rec(A, B), ('req', rid))
            self.install(w, mk_rec(B, A), ('req', rid))
        return rid

    # ----------------------------------------------------------- closure
    def run(self):
        try:
            self._run()
        except Failure as f:
            self.failure = f
        return self.failure

    def _fail(self, kind, key):
        raise Failure(kind, key, self)

    def _run(self):
        while self.queue or self.newP:
            while self.newP:
                N = self.newP.popleft()
                if not self.coherent(N): self._fail('F2', ('P', N))
                self._guidance_dominator(N)
                # rule III against every all-world accepted installed record ending at N
                for w in range(3):
                    for r in list(self.recs[w]):
                        if ends_at(r, N): self._rule3(r, N)
            if not self.queue: break
            w, r = self.queue.popleft()
            if self.improvement(r, w): self._fail('F1', ('inst', w, r))
            self._rule2(w, r)
            for N in list(self.P):
                if ends_at(r, N): self._rule3(r, N)

    def _guidance_dominator(self, N):
        S = self.S
        for k in range(self.n):
            for v in range(4):
                if v != N[k] and all(S.rank[w][k][v] <= S.rank[w][k][N[k]] for w in range(3)):
                    X = list(N); X[k] = v; X = tuple(X)
                    self._fail('F1', ('guiddom', N, X))

    def _rule3(self, r, N):
        if not all(self.accepted(r, w) for w in range(3)): return
        X = source_of(r, N)
        keys = tuple(self.why(r, w) for w in range(3))
        ir = inv(r)
        for w in range(3):
            self.install(w, ir, ('III', N, X, keys))
        self.register(X, ('IV', N, X, keys))

    def _rule2(self, w, r):
        O, Nw = self._arrays(w)
        if len(self.recs[w]) == 0: return
        nr = np.array([v % 4 if v >= 0 else -1 for v in r], dtype=np.int8)
        orr = np.array([v // 4 if v >= 0 else -1 for v in r], dtype=np.int8)
        ok1 = np.all((nr < 0)[None, :] | (O < 0) | (nr[None, :] == O), axis=1)   # r then s
        ok2 = np.all((Nw < 0) | (orr < 0)[None, :] | (Nw == orr[None, :]), axis=1)  # s then r
        recs = self.recs[w]
        for idx in np.nonzero(ok1)[0]:
            self._tri(w, r, recs[idx])
        for idx in np.nonzero(ok2)[0]:
            self._tri(w, recs[idx], r)

    def _tri(self, w, r, s):
        c = comp(r, s)
        if is_empty(c): return
        t = inv(c)
        if not self.accepted(t, w): return
        just = ('II', w, ('inst', w, r), ('inst', w, s), self.why(t, w))
        self.install(w, inv(r), just)
        self.install(w, inv(s), just)
        self.install(w, c, just)

    # ------------------------------------------------------- derivations
    def support(self, key, seen=None):
        """Set of request ids used by the justification of key."""
        if seen is None: seen = {}
        out = set()
        stack = [key]
        while stack:
            k = stack.pop()
            if k in seen: continue
            seen[k] = True
            j = self._just(k)
            if j is None: continue
            if j[0] == 'req': out.add(j[1]); continue
            stack.extend(self._parents(j))
        return out

    def _just(self, key):
        if key[0] == 'inst': return self.inst[key[1]].get(key[2])
        if key[0] == 'P': return self.P.get(key[1])
        if key[0] == 'guiddom': return ('GD', key[1])
        return None

    def _parents(self, j):
        if j[0] == 'II': return [j[2], j[3], j[4]]
        if j[0] in ('III', 'IV'): return [('P', j[1])] + [k for k in j[3]]
        if j[0] == 'GD': return [('P', j[1])]
        return []

    def failure_support(self):
        f = self.failure
        return self.support(f.key)

    # ---------------------------------------------------- pretty printing
    def rstr(self, r):
        S = self.S; ADV = 'PNSX'
        return ', '.join(f'{S.names[k]}:{ADV[v//4]}>{ADV[v%4]}' for k, v in enumerate(r) if v >= 0) or '(empty)'

    def derivation(self, key=None, names=None):
        """Topologically ordered list of lines proving the failure."""
        names = names or {}
        if key is None: key = self.failure.key
        order, seen = [], set()
        def visit(k):
            if k in seen: return
            seen.add(k)
            j = self._just(k)
            if j is not None and j[0] not in ('req',):
                for p in self._parents(j): visit(p)
            order.append(k)
        visit(key)
        lab = {k: f'[{i+1}]' for i, k in enumerate(order)}
        lines = []
        S = self.S
        def mname(X): return names.get(X, S.show(X))
        for k in order:
            j = self._just(k)
            if k[0] in ('inst', 'guid'):
                w, r = k[1], k[2]
                head = f'{lab[k]} world {w+1}: accept record {{{self.rstr(r)}}}'
            elif k[0] == 'refl':
                head = f'{lab[k]} reflexivity'
            elif k[0] == 'P':
                head = f'{lab[k]} P contains {mname(k[1])}'
            else:
                head = f'{lab[k]} guidance dominator of {mname(k[1])}: {mname(k[2])}'
            if k[0] == 'guid':
                body = 'weak guidance'
            elif j is None:
                body = '(reflexive)'
            elif j[0] == 'req':
                body = f'request #{j[1]} {self.req_str(self.requests[j[1]], names)}'
            elif j[0] == 'II':
                body = f'rule II from triangle {lab[j[2]]},{lab[j[3]]},{lab[j[4]]}'
            elif j[0] == 'III':
                body = f'rule III: {mname(j[2])} R_i {mname(j[1])} at all i by {",".join(lab[x] for x in j[3])}'
            elif j[0] == 'IV':
                body = f'rule IV: all-world tie with {mname(j[1])}'
            elif j[0] == 'GD':
                body = 'pointwise all-world weak improvement'
            else:
                body = str(j)
            lines.append(f'{head}   <- {body}')
        f = self.failure
        if f is not None and key == f.key:
            if f.kind == 'F1':
                lines.append(f'F1: the last record is the reverse of a strict guidance comparison.')
            else:
                lines.append(f'F2: {mname(key[1])} is incoherent.')
        return lines

    def req_str(self, q, names=None):
        names = names or {}
        S = self.S
        def mname(X): return names.get(X, S.show(X))
        if q[0] == 'dom': return f'dom: {mname(q[1])} R_i {mname(q[2])} at all i, {mname(q[1])} in P'
        if q[0] == 'cmp': return f'cmp: {mname(q[1])} R_{q[3]+1} {mname(q[2])}'
        if q[0] == 'reg': return f'reg: {mname(q[1])} in P'
        if q[0] == 'tie': return f'tie: {mname(q[1])} R_{q[3]+1} {mname(q[2])} and reverse'
        return str(q)

    # ------------------------------------------------------------ copying
    def clone(self):
        c = Closure.__new__(Closure)
        c.S, c.n, c.DEL, c.coherent = self.S, self.n, self.DEL, self.coherent
        c.inst = [dict(d) for d in self.inst]
        c.recs = [list(x) for x in self.recs]
        for w in range(3): self._arrays(w)
        c.OLD = [x.copy() for x in self.OLD]; c.NEW = [x.copy() for x in self.NEW]
        c._pend = [[] for _ in range(3)]
        c.P = dict(self.P); c.requests = list(self.requests)
        c.queue = deque(self.queue); c.newP = deque(self.newP)
        c.failure = self.failure
        return c

    def stats(self):
        return {'records': [len(x) for x in self.recs], 'P': len(self.P)}

    def defends(self, A, X):
        """worlds at which A R_w X is accepted"""
        r = mk_rec(A, X)
        return [w for w in range(3) if self.accepted(r, w)]


def closure_of(S, reqs, coherent=None, base=None):
    cl = base.clone() if base is not None else Closure(S, coherent)
    if base is None: cl.request(('reg', S.T))
    for q in reqs: cl.request(q)
    cl.run()
    return cl
