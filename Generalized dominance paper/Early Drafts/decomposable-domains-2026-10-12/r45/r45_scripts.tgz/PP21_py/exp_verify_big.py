"""PP21: independent re-verification (verify.verify) and anatomy of the clean
closures for J2 (orders nearT, rand1) and the twin-split class (rand1, precise)."""
import sys, collections
sys.argv = ['x']
from exp_joint import J2, ORD, S, cat, T
from exp_split import rivals_twin, orders
from catcache import catalogue
from search import Searcher
from verify import verify
def anat(tag, S_, cat_, R, o):
    sr = Searcher(S_, cat_, R, defender_order=o, max_nodes=6000)
    res, info = sr.solve()
    if res is None: print(tag, 'no clean solution'); return
    c = collections.Counter(j[0] for w in range(3) for j in res.inst[w].values())
    print(f'{tag}: rivals {len(R)}; installed records by origin {dict(c)}; P by origin '
          f'{dict(collections.Counter(j[0] for j in res.P.values()))}; verification errors {len(verify(res))}')
    sys.stdout.flush()
R = J2()
for on in ('nearT', 'rand1'): anat(f'J2 {on}', S, cat, R, ORD[on])
S2 = S.split([S.names[k] for k in S.silent_cells()]); cat2 = catalogue(S2); R2 = rivals_twin(S2)
for on in ('rand1', 'precise'): anat(f'twin {on}', S2, cat2, R2, orders(S2.T)[on])
