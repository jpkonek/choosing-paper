"""Referee checks for REFEREE_Z_PP19.md (exact, exhaustive, finite cells).

Bookkeeping only. Cells are atoms; nothing here is evidence about (S).

Advice relative to the majority orientation: A majority, S silence,
B minority, X contradiction.  Classes M1, M2, M3 (minority world), U.
Written independently of PP19_py.  Run: python3 -I -B split_defender.py
"""
from itertools import product

ADV = 'ASBX'
CLASSES = ['M1', 'M2', 'M3', 'U']
AW = {'B': 0, 'S': 1, 'A': 2}          # A-wardness (X excluded)


def r(a, cls, w):
    if a == 'X':
        return 3
    if cls == 'U':
        return {'A': 0, 'S': 1, 'B': 2}[a]
    minority = int(cls[1])
    if w == minority:
        return {'B': 0, 'S': 1, 'A': 2}[a]
    return {'A': 0, 'S': 1, 'B': 2}[a]


def better(a, b, cls, w):              # a <_w b : a strictly better at w
    return r(a, cls, w) < r(b, cls, w)


def noworse(a, b, cls, w):             # a <=_w b
    return r(a, cls, w) <= r(b, cls, w)


# ------------------------------------------------------------------ part 1
def part1_feasibility(i=1, j=2, k=3):
    """Prop S: fills on M_k; C defends at i, C2 defends at j.
    K_i = {C <_i T}, K_j = {C2 <_j T} (outside the fills).
    On K, need y with y <=_i C, y <=_j C2, y <=_k T.
    Claimed obstruction set O (infeasible points of K):
      K in M_k: always;  K_i in M_i: always;  K_j in M_j: always;
      K_j \\ K_i in M_i: iff C != X and AW[C] < AW[C2];
      K_i \\ K_j in M_j: iff C2 != X and AW[C2] < AW[C];
      U: K empty there.
    Also: on K_i a feasible y differs from T (strictness at k)."""
    Mi, Mj, Mk = 'M%d' % i, 'M%d' % j, 'M%d' % k
    n = 0
    for cls in CLASSES:
        tset = 'A' if cls == 'U' else 'ASB'      # T coherent: A on U, never X
        for t, c, c2 in product(tset, ADV, ADV):
            Ki = better(c, t, cls, i)
            Kj = better(c2, t, cls, j)
            if not (Ki or Kj):
                continue
            ys = [y for y in ADV if noworse(y, c, cls, i)
                  and noworse(y, c2, cls, j) and noworse(y, t, cls, k)]
            infeasible = not ys
            if cls == 'U':
                raise AssertionError('K meets U')
            if cls == Mk:
                claim = True
            elif cls == Mi:
                claim = Ki or (c != 'X' and c2 != 'X' and AW[c] < AW[c2])
            else:  # Mj
                claim = Kj or (c2 != 'X' and c != 'X' and AW[c2] < AW[c])
            assert infeasible == claim, (cls, t, c, c2, ys)
            if Ki and ys:
                assert all(y != t for y in ys)
            n += 1
    print('part 1 (Prop S pointwise obstruction set): %d K-points OK' % n)


def part2_reduction(i=1, j=2, k=3):
    """With C2 = C, the obstruction set is exactly Theorem 5's set
    ({C <_i T} u {C <_j T}) \\ {C <_k T}."""
    n = 0
    for cls in CLASSES:
        tset = 'A' if cls == 'U' else 'ASB'
        for t, c in product(tset, ADV):
            inK = better(c, t, cls, i) or better(c, t, cls, j)
            if not inK:
                continue
            ys = [y for y in ADV if noworse(y, c, cls, i)
                  and noworse(y, c, cls, j) and noworse(y, t, cls, k)]
            thm5 = not better(c, t, cls, k)
            assert (not ys) == thm5, (cls, t, c)
            n += 1
    print('part 2 (C2 = C reduces to Theorem 5): %d points OK' % n)


# ------------------------------------------------------------------ part 3
CELLS = ['E', 'E2', 'H1', 'H2', 'G1', 'G2', 'U0']
CLS_OF = {'E': 'M3', 'E2': 'M3', 'H1': 'M1', 'H2': 'M2',
          'G1': 'M1', 'G2': 'M2', 'U0': 'U'}


def model(**kw):
    m = {c: kw.get(c) for c in CELLS}
    return m


def record(X, Y):
    D = tuple(c for c in CELLS if X[c] != Y[c])
    return (D, tuple(X[c] for c in D), tuple(Y[c] for c in D))


def splice(Z, D, src):
    W = dict(Z)
    for c in D:
        W[c] = src[c]
    return W


def pointwise(X, Y, w):
    """returns (X <=_w Y pointwise, strictly somewhere)"""
    le = all(noworse(X[c], Y[c], CLS_OF[c], w) for c in CELLS)
    st = any(better(X[c], Y[c], CLS_OF[c], w) for c in CELLS)
    return le, st


def kill(C, X, Y, T, w):
    """Lemma 5.0 triangle: A0 = T[D->C], B0 = T[D->X] (copy of rec(C,X)),
    Z0 = B0[D_Y -> Y] (copy of rec(T,Y)), and Z0 <_w A0 strictly pointwise."""
    D = [c for c in CELLS if C[c] != X[c]]
    A0, B0 = splice(T, D, C), splice(T, D, X)
    assert record(A0, B0) == record(C, X)
    DY = [c for c in CELLS if Y[c] != T[c]]
    Z0 = splice(B0, DY, Y)
    assert record(B0, Z0) == record(T, Y), 'not a copy of rec(T,Y)'
    le, st = pointwise(Z0, A0, w)
    assert le and st, ('closing link not a strict guidance improvement', w)


def thm5_comp(C, E, T, i=1, j=2, k=3):
    return [c for c in CELLS if c not in E and
            (better(C[c], T[c], CLS_OF[c], i) or better(C[c], T[c], CLS_OF[c], j))
            and not better(C[c], T[c], CLS_OF[c], k)]


def part3_example():
    T = model(E='S', E2='S', H1='S', H2='S', G1='S', G2='S', U0='A')
    XE = splice(T, ['E'], {'E': 'A'})
    XE2 = splice(T, ['E2'], {'E2': 'A'})
    C = model(E='S', E2='S', H1='A', H2='A', G1='S', G2='B', U0='A')
    C2 = model(E='S', E2='S', H1='A', H2='A', G1='B', G2='S', U0='A')
    # Theorem 5 does not kill either defender on its own
    assert thm5_comp(C, ['E'], T) == ['G2']
    assert thm5_comp(C2, ['E2'], T) == ['G1']
    # Prop S kill with C at world 1, C2 at world 2: Y = T[H1 u H2 -> A]
    Y = splice(T, ['H1', 'H2'], {'H1': 'A', 'H2': 'A'})
    kill(C, XE, Y, T, 1)
    kill(C2, XE2, Y, T, 2)
    le, st = pointwise(Y, T, 3)
    assert le and st                      # Y <_3 T by strict (G)
    print('part 3 (within-class example): Theorem 5 compensation sets',
          thm5_comp(C, ['E'], T), thm5_comp(C2, ['E2'], T),
          '; Y = T[H1,H2 -> A] refused by T at worlds 1, 2 (Lemma 5.0) and 3 (strict G): OK')


if __name__ == '__main__':
    part1_feasibility()
    part2_reduction()
    part3_example()
    print('ALL PASS')
