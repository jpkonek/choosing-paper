import sys; sys.path.insert(0,'.')
from radial import *; from search import *
xs = eval(sys.argv[1]); mode = sys.argv[2]; seeds = int(sys.argv[3])
c,g = make(xs); W = World(c,g); T=W.T
maj = [i for i in range(W.N) if set(W.vals[i]) <= {0,1} and i!=T]
mino = [i for i in range(W.N) if set(W.vals[i]) <= {1,2} and i!=T]
if mode=='joint':
    dom = [x for x in maj+mino if not W.coh[x]]
    tdef = maj+mino+[i for i in np.nonzero(W.coh)[0]]   # all fills and all coherent models (V among them)
else:  # full: every model
    dom = [x for x in range(W.N) if not W.coh[x]]
    tdef = list(range(W.N))
print('N',W.N,'coherent',W.coh.sum(),'dom',len(dom),'tdef',len(tdef))
for s in range(seeds):
    t=time.time(); res = search(W, dom, tdef, seed=s)
    print('seed',s,res['status'],res.get('culprit'),round(time.time()-t,1),flush=True)
    if res['status']=='SUCCESS':
        rep=report(W,res,dom,tdef); print(rep['bad'][:5], rep['single_world_tie_pairs'], rep['mixed_accepted'], len(rep['P'])); break
