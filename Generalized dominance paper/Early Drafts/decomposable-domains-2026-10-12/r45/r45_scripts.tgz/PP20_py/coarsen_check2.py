"""CHECKED: PP20 Thm 3' (rivals agreeing with T on the footprints F_1,F_2,F_3, otherwise arbitrary,
including changes of T's answers) on abstract cells, record level.
Cells: silent cells (T=S) one per class; footprint cells H_w (T=B, C_w=S); free answered cells:
G_k (T=A) and H'_k (T=B) for the classes listed on the command line."""
import sys, itertools; sys.path.insert(0,'.')
from reclevel import *
vals = (0,1,2,3) if 'X' in sys.argv else (0,1,2)
Gs = [0,1,2] if 'allG' in sys.argv else [0]
Hs = [0,1,2] if 'allH' in sys.argv else [1]
cls = [0,1,2] + [0,1,2] + Gs + Hs
nD=3; foot=[3,4,5]
C = Cells(cls); n=len(cls)
T = tuple([1,1,1] + [2,2,2] + [0]*len(Gs) + [2]*len(Hs))
Cw = [tuple(1 if c==foot[w] else T[c] for c in range(n)) for w in range(3)]
free=[c for c in range(n) if c not in foot]
rivals=[]
for v in itertools.product(vals, repeat=len(free)):
    X=list(T)
    for c,x in zip(free,v): X[c]=x
    X=tuple(X)
    if X!=T: rivals.append(X)
M0=[set(),set(),set()]
for w in range(3): M0[w].add(C.rec(T,Cw[w]))
assign={}
for X in rivals:
    wX = next(w for w in range(3) if C.kind(C.rec(T,X),w) in ('W','M'))
    assign[X]=wX
    for u in range(3): M0[u].add(C.rec(Cw[wX],X))
    if 'tall' in sys.argv:
        for w in range(3):
            if C.kind(C.rec(T,X),w)=='M': M0[w].add(C.rec(T,X))
    elif C.kind(C.rec(T,X),wX)=='M': M0[wX].add(C.rec(T,X))
if 'src' in sys.argv:
    for w in range(3):
        for u in range(3):
            if u!=w: M0[u].add(C.rec(Cw[w],T))
Mset,P,F1,log = closure(C,M0,{T}|set(Cw))
acc = lambda r,w: r in Mset[w] or C.kind(r,w) in ('W','triv')
bad=0
for X in rivals:
    c=Cw[assign[X]]
    if not all(acc(C.rec(c,X),w) for w in range(3)) or any(acc(C.rec(X,c),w) for w in range(3)): bad+=1
    if not any(acc(C.rec(T,X),w) for w in range(3)): bad+=1
if 'src' in sys.argv:
    for w in range(3):
        if not any(acc(C.rec(Cw[w],T),u) for u in range(3)): bad+=1
        if all(acc(C.rec(Cw[w],T),u) for u in range(3)) or all(acc(C.rec(T,Cw[w]),u) for u in range(3)): bad+=1
print('cells',n,'rivals',len(rivals),'M-records/world',[len(m) for m in Mset],'F1',len(F1),'P',len(P),'events',len(log),'failures',bad,
      '=> ALL PASS' if (bad==0 and not F1 and len(P)==4 and not log) else '=> FAIL')
