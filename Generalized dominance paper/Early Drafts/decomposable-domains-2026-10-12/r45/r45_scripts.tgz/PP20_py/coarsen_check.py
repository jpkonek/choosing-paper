"""CHECKED: the coarsening extension theorem (PP20 Thm 3) on abstract cells.
Cells: d silent cells per class (T=S) and, for each class k, one answered cell H_k where T gives the
minority answer B (right at k, wrong at the two majority worlds) and one cell G_k where T gives A.
Defender C_w = T with S on H_w (a coarsening): better than T at u!=w, worse at w on H_w."""
import sys, itertools; sys.path.insert(0,'.')
from reclevel import *
d = int(sys.argv[1]) if len(sys.argv)>1 else 1
vals = (0,1,2,3) if (len(sys.argv)>2 and sys.argv[2]=='X') else (0,1,2)
cls = [k for k in range(3) for _ in range(d)] + [0,1,2] + [0,1,2]
C = Cells(cls); n=len(cls); nD=3*d
T = tuple([1]*nD + [2,2,2] + [0,0,0])
Cw = [tuple(1 if c==nD+w else T[c] for c in range(n)) for w in range(3)]
fills = [tuple(list(v)+list(T[nD:])) for v in itertools.product(vals, repeat=nD) if any(x!=1 for x in v)]
M0=[set(),set(),set()]
for w in range(3): M0[w].add(C.rec(T,Cw[w]))
assign={}
for X in fills:
    wX = next(w for w in range(3) if C.kind(C.rec(T,X),w) in ('W','M'))
    assign[X]=wX
    for u in range(3): M0[u].add(C.rec(Cw[wX],X))
    if C.kind(C.rec(T,X),wX)=='M': M0[wX].add(C.rec(T,X))
Mset,P,F1,log = closure(C,M0,{T}|set(Cw))
print('cells',n,'fills',len(fills),'installed M-records per world',[len(m) for m in Mset])
print('F1:',len(F1),'P size',len(P),'rule II/III/IV events',len(log))
# strict domination at every world and T's defences
acc = lambda r,w: r in Mset[w] or C.kind(r,w) in ('W','triv')
bad=0
for X in fills:
    c=Cw[assign[X]]
    if not all(acc(C.rec(c,X),w) for w in range(3)): bad+=1
    if any(acc(C.rec(X,c),w) for w in range(3)): bad+=1
    if not any(acc(C.rec(T,X),w) for w in range(3)): bad+=1
for c in Cw:
    if not any(acc(C.rec(T,c),w) for w in range(3)): bad+=1
print('obligation failures:',bad, '=> ALL PASS' if (bad==0 and not F1 and len(P)==4 and not log) else '=> FAIL')
