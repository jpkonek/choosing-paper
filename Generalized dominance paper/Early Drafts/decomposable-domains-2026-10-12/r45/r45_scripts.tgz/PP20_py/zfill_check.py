"""CHECKED (exploratory): Theorem-Z fills on a footprint, Z = T[Q -> A] with Q one of two halves of F_w
(T = B there: right at w, wrong at the other two worlds; A is correct at both other worlds),
served by C_w itself, on top of Thm 3.2 / 4.3 (t-records for every model in L and for the Z's)."""
import sys, itertools; sys.path.insert(0,'.')
from reclevel import *
cls=[0,1,2]+[0,0,1,1,2,2]
foot={0:[3,4],1:[5,6],2:[7,8]}
C=Cells(cls); n=len(cls)
T=tuple([1,1,1]+[2]*6)
Cw=[tuple(1 if c in foot[w] else T[c] for c in range(n)) for w in range(3)]
Fall=[c for w in foot for c in foot[w]]
L=[m for m in itertools.product((0,1,2),repeat=3)]
L=[tuple(list(m)+[2]*6) for m in L if list(m)!=[1,1,1]]
Z=[]
for w in range(3):
    for q in foot[w]:
        z=list(T); z[q]=0; Z.append((w,tuple(z)))
    z=list(T)
    for q in foot[w]: z[q]=0
    Z.append((w,tuple(z)))          # Q = all of F_w (expected to fail with C_w as server)
M0=[set(),set(),set()]
for w in range(3): M0[w].add(C.rec(T,Cw[w]))
serve={}
for X in L:
    wX=next(w for w in range(3) if C.kind(C.rec(T,X),w) in ('W','M')); serve[X]=wX
    for u in range(3): M0[u].add(C.rec(Cw[wX],X))
def tworld(Y):
    return next(u for u in range(3) if C.kind(C.rec(T,Y),u) in ('W','M'))
for Y in L:
    u=tworld(Y)
    if C.kind(C.rec(T,Y),u)=='M': M0[u].add(C.rec(T,Y))
for tag,ZZ in (('half-footprint Z',[z for w,z in Z if sum(1 for c in foot[w] if z[c]==0)==1]),
               ('whole-footprint Z',[z for w,z in Z if sum(1 for c in foot[w] if z[c]==0)==2])):
    M1=[set(m) for m in M0]; bad=[]
    for z in ZZ:
        w=next(w for w in range(3) if any(z[c]!=T[c] for c in foot[w]))
        b=C.rec(Cw[w],z)
        kinds=[C.kind(b,u) for u in range(3)]
        if 'I' in kinds: bad.append(('b is improvement',kinds)); continue
        for u in range(3): M1[u].add(b)
        tu=tworld(z); 
        if C.kind(C.rec(T,z),tu)=='M': M1[tu].add(C.rec(T,z))
    Mset,P,F1,log=closure(C,M1,{T}|set(Cw))
    print(tag,': installed-improvement issues',bad[:3],'| F1',len(F1),'| P',len(P),'| events',len(log))
