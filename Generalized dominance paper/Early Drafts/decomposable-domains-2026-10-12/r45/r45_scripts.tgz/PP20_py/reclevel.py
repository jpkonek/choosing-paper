"""Record-level closure (rules I-IV of AUDIT_completion) for finite cell models.
A cell has a class k (minority world) or 'U'.  Advice values 0=A(majority) 1=S 2=B(minority) 3=X.
Ranks: majority worlds A0 S1 B2 X3; minority world B0 S1 A2 X3.
Records: tuple over cells of None or (old,new).  Accepted records at w = guidance (weakly worsening)
plus the explicit M-set (records with a strict worsening and a strict improvement point).
Lemma (triangle trichotomy, PP20 Sec.2): only M-records enter non-degenerate triangles, and F1 occurs
iff some installed record is a weak improvement or two accepted M-records compose to a strict improvement.
We nevertheless also test pairs (M, guidance) by brute force on small instances (check_trichotomy)."""
import itertools
def rank(cls, w, v):
    if v == 3: return 3
    if cls == w: return (2,1,0)[v]
    return v  # A0 S1 B2
class Cells:
    def __init__(self, classes): self.cls = classes; self.n = len(classes)
    def rec(self, P, Q):
        return tuple(None if p==q else (p,q) for p,q in zip(P,Q))
    def change(self, r, w):
        return [None if x is None else rank(self.cls[c],w,x[1]) - rank(self.cls[c],w,x[0]) for c,x in enumerate(r)]
    def kind(self, r, w):
        ch = [d for d in self.change(r,w) if d is not None]
        up = any(d>0 for d in ch); dn = any(d<0 for d in ch)
        if not ch: return 'triv'
        if up and dn: return 'M'
        return 'W' if up else 'I'
    def inv(self, r): return tuple(None if x is None else (x[1],x[0]) for x in r)
    def compose(self, r1, r2):
        out=[]
        for a,b in zip(r1,r2):
            if a is None: out.append(b)
            elif b is None: out.append(a)
            else:
                if a[1]!=b[0]: return 'X'
                out.append(None if a[0]==b[1] else (a[0],b[1]))
        return tuple(out)
def closure(C, M0, P0, maxit=50):
    """M0: list of 3 sets of installed records.  Returns (Mset, P, F1list, log)."""
    M = [set(), set(), set()]; F1=[]; log=[]
    for w in range(3):
        for r in M0[w]:
            k = C.kind(r,w)
            if k=='I': F1.append(('installed improvement',w,r))
            elif k=='M': M[w].add(r)
    P=set(P0)
    for it in range(maxit):
        changed=False
        for w in range(3):
            L=list(M[w])
            for r1 in L:
                for r2 in L:
                    c = C.compose(r1,r2)
                    if c=='X': continue
                    k = C.kind(c,w)
                    if k=='I': F1.append(('pair',w,r1,r2,c))
                    if k=='M' and C.inv(c) in M[w]:   # all-mixed triangle -> complete
                        for new in (c, C.inv(r1), C.inv(r2)):
                            if new not in M[w]: M[w].add(new); changed=True; log.append(('II',w,new))
        # rule III: records ending at N accepted at all worlds
        for N in list(P):
            for w0 in range(3):
                for r in list(M[w0]):
                    if any(x is not None and x[1]!=N[c] for c,x in enumerate(r)): continue
                    if all(r in M[w] or C.kind(r,w) in ('W','triv') for w in range(3)):
                        X = tuple(N[c] if x is None else x[0] for c,x in enumerate(r))
                        ri = C.inv(r)
                        for w in range(3):
                            if C.kind(ri,w)=='I': F1.append(('ruleIII',w,N,X))
                            elif C.kind(ri,w)=='M' and ri not in M[w]: M[w].add(ri); changed=True; log.append(('III',w,N,X))
                        # rule IV: tie?
                        if all(ri in M[w] or C.kind(ri,w) in ('W','triv') for w in range(3)):
                            if X not in P: P.add(X); changed=True; log.append(('IV',X))
        if not changed: break
    return M, P, F1, log
