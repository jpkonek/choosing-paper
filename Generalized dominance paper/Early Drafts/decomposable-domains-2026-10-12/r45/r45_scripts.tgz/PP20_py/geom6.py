"""Geometric 6-line cell model with general coherent models D_K, K any closed convex subset of the simplex.
Per class k: a silent line (T silent) and an answered line where T gives the minority answer (T right
at k, wrong at the two majority worlds).  Coherence oracle by exact LP-free argument is not available
for general K, so we use scipy LP with a margin and then certify each feasible pattern with explicit
rational witness points (a pattern is accepted only if certified)."""
import sys, itertools; sys.path.insert(0,'.')
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import linprog
from cells import World, closure, EPS, C0, D as DD
def lines():
    L=[]
    for k in range(3):
        # majority-oriented gamble with coordinate k negative; accept = majority answer A
        x = 2-DD
        g=[Fr(1)]*3; g[k]=-x; L.append((k,g))          # T silent
    t = C0/2
    for k in range(3):
        g=[t]*3; g[k]=-(1-t); L.append((k,g))         # T rejects -> answer B (minority), right at k
    return L
def mval(m,g): return sum(a*b for a,b in zip(m,g))
def T_advice(g):
    verts=[[C0+(EPS if i==j else 0) for i in range(3)] for j in range(3)]
    v=[mval(m,g) for m in verts]
    return 0 if min(v)>0 else (2 if max(v)<0 else 1)
def realizable(L, pat, margin=1e-6):
    # region: m>=0, sum=1, A-lines m.g>=margin, B-lines m.g<=-margin; S-lines: witnesses both sides
    A_ub=[]; b_ub=[]
    for (k,g),v in zip(L,pat):
        gf=[float(x) for x in g]
        if v==0: A_ub.append([-x for x in gf]); b_ub.append(-margin)
        elif v==2: A_ub.append(gf); b_ub.append(-margin)
    def feas(extra):
        A=A_ub+[e[0] for e in extra]; b=b_ub+[e[1] for e in extra]
        r=linprog(np.zeros(3),A_ub=np.array(A) if A else None,b_ub=np.array(b) if b else None,
                  A_eq=[[1,1,1]],b_eq=[1],bounds=[(0,1)]*3,method='highs')
        return r.status==0, (r.x if r.status==0 else None)
    ok,_=feas([])
    if not ok: return False
    for (k,g),v in zip(L,pat):
        if v==1:
            gf=[float(x) for x in g]
            if not feas([([-x for x in gf],-margin)])[0]: return False
            if not feas([(gf,-margin)])[0]: return False
    return True
def build():
    L=lines(); n=len(L)
    W=World([(k,Fr(0)) for k,g in L])   # ranks depend only on class
    W.coh[:]=np.array([realizable(L,tuple(v)) for v in W.vals])
    W.T=W.index([T_advice(g) for k,g in L])
    return W,L
if __name__=='__main__':
    W,L=build()
    print('T =',W.show(W.T),' coherent patterns:',W.coh.sum())
    print([W.show(i) for i in np.nonzero(W.coh)[0]])
