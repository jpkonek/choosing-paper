"""Generic greedy search for a clean closure (no F1, no F2) meeting obligations:
 - every model in `dom` (incoherent) has a strict all-world dominator registered in P;
 - T is competitive (some world) against every model in `tdef` and every registered defender."""
import sys, time, random; sys.path.insert(0,'.')
from cells import *
def clean(r): return all(len(f)==0 for f in r['F1']) and not r['F2']
def search(W, dom, tdef, seed=0, verbose=False, cand_filter=None):
    random.seed(seed); T = W.T; S = W.show
    coh = [i for i in np.nonzero(W.coh)[0] if i != T]
    installs=[]; P={T}; defs={}
    r = closure(W, installs, P)
    tdefd = lambda r,y: any(r['R'][w][T,y] for w in range(3))
    allw = lambda r,a,b: all(r['R'][w][a,b] for w in range(3))
    for y in tdef:
        if tdefd(r,y): continue
        ok=False
        for w in random.sample(range(3),3):
            r2 = closure(W, installs+[(w,T,y)], P)
            if clean(r2): installs.append((w,T,y)); r=r2; ok=True; break
        if not ok: return dict(status='T-defence', culprit=S(y), installs=installs, r=r)
    order = dom[:]; random.shuffle(order)
    for x in order:
        if any(allw(r,c,x) and not allw(r,x,c) for c in r['P']): defs[x]=None; continue
        cands = coh[:] if cand_filter is None else [c for c in coh if cand_filter(c,x)]
        random.shuffle(cands)
        ok=False
        for c in cands:
            new=[(w,c,x) for w in range(3)]
            tws = [None] if tdefd(r,c) else random.sample(range(3),3)
            for w0 in tws:
                extra = [] if w0 is None else [(w0,T,c)]
                r2 = closure(W, installs+new+extra, P|{c})
                if clean(r2) and all(tdefd(r2,y) for y in tdef):
                    installs+=new+extra; P|={c}; r=r2; defs[x]=c; ok=True; break
            if ok: break
        if not ok: return dict(status='repair', culprit=S(x), installs=installs, r=r, defs=defs)
        if verbose: print(' ', S(x), '<-', S(c), flush=True)
    return dict(status='SUCCESS', installs=installs, r=r, defs=defs)
def report(W, res, dom, tdef):
    r=res['r']; R=r['R']; P=r['P']; T=W.T; S=W.show
    allw = lambda a,b: all(R[w][a,b] for w in range(3))
    bad=[]
    for x in dom:
        if not any(allw(c,x) and not allw(x,c) for c in P): bad.append(('undominated',S(x)))
    for y in list(tdef)+list(P):
        if not any(R[w][T,y] for w in range(3)): bad.append(('T undefended',S(y)))
    for p in P:
        for x in range(W.N):
            if allw(x,p) and not allw(p,x): bad.append(('P dominated',S(p),S(x)))
    ties = [(w,(R[w]&R[w].T).sum()-W.N) for w in range(3)]
    mixed=[int((r['acc'][w]&W.better[w]&W.worse[w]).sum()) for w in range(3)]
    return dict(bad=bad, single_world_tie_pairs=ties, mixed_accepted=mixed, P=sorted(S(p) for p in P))
