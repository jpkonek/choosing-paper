import sys, time; sys.path.insert(0,'.')
from cells import *
W = World(make_cells())
T = W.T
maj = [i for i in range(W.N) if set(W.vals[i]) <= {0,1} and i!=T]
mino = [i for i in range(W.N) if set(W.vals[i]) <= {1,2} and i!=T]
print('maj fills', len(maj), 'coherent:', [W.show(i) for i in maj if W.coh[i]])
print('min fills', len(mino), 'coherent:', [W.show(i) for i in mino if W.coh[i]])
t=time.time(); r = closure(W, [], {T}); print('guidance closure', time.time()-t, r['it'], [len(f) for f in r['F1']])
