import sys, pickle; sys.path.insert(0,'.')
from greedy import *
def verify(r, defs, label=''):
    R = r['R']; P = r['P']
    allw = lambda a,b: all(R[w][a,b] for w in range(3))
    bad = []
    for x in fills:
        if not any(allw(c,x) and not allw(x,c) for c in P): bad.append(('undominated fill',S(x)))
    for y in range(W.N):
        if not any(R[w][T,y] for w in range(3)): pass
    needT = maj+mino+special+list(P)
    for y in needT:
        if not any(R[w][T,y] for w in range(3)): bad.append(('T undefended',S(y)))
    for p in P:
        for x in range(W.N):
            if allw(x,p) and not allw(p,x): bad.append(('P dominated',S(p),S(x)))
    print(label, 'violations:', bad[:10], len(bad))
    tieT = [S(x) for x in range(W.N) if x!=T and allw(x,T) and allw(T,x)]
    print('T all-world ties:', tieT)
    for w in range(3):
        a = r['acc'][w]; print('world',w,'accepted records',a.sum(),'guidance',(~W.better[w]).sum(),
              'mixed accepted', (a & W.better[w] & W.worse[w]).sum(), 'ties among models', (R[w]&R[w].T).sum()-W.N)
    # how many all-world ties overall
    tie = R[0]&R[1]&R[2]&R[0].T&R[1].T&R[2].T
    print('all-world tied pairs', (tie.sum()-W.N)//2)
    # T competitive vs everything?
    und = [y for y in range(W.N) if not any(R[w][T,y] for w in range(3))]
    print('models T does not defend against:', len(und), [S(y) for y in und[:20]])
if __name__=='__main__':
    out = run(0)
    pickle.dump((out[1], out[2]), open('greedy0.pkl','wb'))
    verify(out[3], out[2])
