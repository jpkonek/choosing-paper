"""Dense model-level cross-check of Thm 4.3 on 6 cells (one silent cell + one footprint cell per class):
Thm 3.2 seed, then T <=_w Y for EVERY model Y at the first world of W(Y) that keeps the closure clean."""
import sys; sys.path.insert(0,'.')
from cells import *
from search import clean
cells=[(k,Fr(1,3)) for k in range(3)]*2
W=World(cells); idx=lambda v: W.index(v)
T=idx([1,1,1,2,2,2]); W.T=T
Cw=[idx([1,1,1]+[1 if j==w else 2 for j in range(3)]) for w in range(3)]
W.coh[:]=False
for p in [T]+Cw: W.coh[p]=True
fills=[i for i in range(W.N) if list(W.vals[i][3:])==[2,2,2] and i!=T]
inst=[(w,T,Cw[w]) for w in range(3)]
for X in fills:
    wX=next(w for w in range(3) if W.worse[w][W.recid[T,X]])
    inst+=[(u,Cw[wX],X) for u in range(3)]
r=closure(W,inst,{T,*Cw}); assert clean(r)
firstfail=0; nodef=0
for Y in range(W.N):
    if Y==T or any(r['R'][w][T,Y] for w in range(3)): continue
    Wy=[w for w in range(3) if W.worse[w][W.recid[T,Y]]]
    ok=False
    for k,w in enumerate(Wy):
        r2=closure(W,[(w,T,Y)],r['P'],acc0=r['acc'])
        if clean(r2): r=r2; ok=True; firstfail+=(k>0); break
    nodef+=(not ok)
R=r['R']
tie=sum(((R[w]&R[w].T).sum()-W.N) for w in range(3))
print('models without a defence:',nodef,'| first world refused (needed the second):',firstfail,
      '| P',len(r['P']),'| single-world ties',tie,'| all models defended:',all(any(R[w][T,y] for w in range(3)) for y in range(W.N)))
