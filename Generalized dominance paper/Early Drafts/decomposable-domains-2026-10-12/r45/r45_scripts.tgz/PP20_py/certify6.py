"""Exact certification that every registered defender in the saved full6 run is coherent:
construct explicit rational points in the simplex whose convex hull K realises the pattern exactly."""
import sys, pickle; sys.path.insert(0,'.')
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import linprog
from geom6 import lines, build
W,L=build(); S=W.show
d=pickle.load(open(sys.argv[1],'rb'))
def dot(m,g): return sum(a*b for a,b in zip(m,g))
def point(cons):
    # find m in simplex with sign constraints cons=[(g,sign)] strictly (margin), return rational point
    A=[]; b=[]
    for g,sg in cons:
        gf=[float(x) for x in g]
        A.append([-sg*x for x in gf]); b.append(-1e-4)
    r=linprog(np.zeros(3),A_ub=np.array(A) if A else None,b_ub=np.array(b) if b else None,A_eq=[[1,1,1]],b_eq=[1],bounds=[(1e-6,1)]*3,method='highs')
    if r.status!=0: return None
    m=[Fr(x).limit_denominator(10**6) for x in r.x[:2]]; m.append(1-m[0]-m[1])
    if any(x<0 for x in m): return None
    if not all(sg*dot(m,g)>0 for g,sg in cons): return None
    return m
def realise(pat):
    base=[(g,1 if v==0 else -1) for (k,g),v in zip(L,pat) if v!=1]
    pts=[]
    p0=point(base)
    if p0 is None: return None
    pts.append(p0)
    for (k,g),v in zip(L,pat):
        if v==1:
            for sg in (1,-1):
                p=point(base+[(g,sg)])
                if p is None: return None
                pts.append(p)
    # exact advice of conv(pts)
    adv=[]
    for k,g in L:
        vals=[dot(m,g) for m in pts]
        adv.append(0 if min(vals)>0 else (2 if max(vals)<0 else 1))
    return pts if tuple(adv)==tuple(pat) else None
ok=0; bad=[]
for p in d['P']:
    pat=tuple(int(x) for x in W.vals[p])
    if realise(pat) is not None: ok+=1
    else: bad.append(S(p))
print('registered models certified coherent (exact rational witnesses):',ok,'of',len(d['P']),'failures:',bad)
allc=[i for i in np.nonzero(W.coh)[0]]
nc=sum(1 for i in allc if realise(tuple(int(x) for x in W.vals[i])) is not None)
print('all LP-coherent patterns certified exactly:',nc,'of',len(allc))
