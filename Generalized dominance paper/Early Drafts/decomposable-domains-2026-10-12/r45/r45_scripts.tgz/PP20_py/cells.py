"""PP20 cell engine: T's silent region D split into cells, refinement defenders.
Values: 0=A (majority answer), 1=S (silence), 2=B (minority answer).
Exact rationals for geometry; numpy booleans for the closure (rules I-IV of AUDIT_completion)."""
from fractions import Fraction as Fr
import itertools, numpy as np

EPS = Fr(3,10); C0 = (1-EPS)/3; D = Fr(1,10)
LO, HI = C0, C0+EPS          # m_k range of M = c*1 + eps*Delta

def make_cells(xs=(2+D, 2-D)):
    """cells: list of (class k, threshold t) ; line g with coord k = -x, others 1;
    a credal point m accepts g iff m_k < 1/(1+x) =: t."""
    cells = []
    for k in range(3):
        for x in xs:
            cells.append((k, 1/(1+x)))
    return cells

def coherent_pattern(cells, pat):
    """Is advice vector pat (per cell) realised by some closed convex K inside M?"""
    L = [LO]*3; U = [HI]*3; Ls=[False]*3; Us=[False]*3   # strict flags
    wit = []
    for (k,t),v in zip(cells,pat):
        if v == 0:   # A : all m_k < t
            if t < U[k] or (t==U[k]): U[k] = min(U[k],t); Us[k]=True
        elif v == 2: # B : all m_k > t
            if t > L[k] or t==L[k]: L[k] = max(L[k],t); Ls[k]=True
        else:
            wit.append((k,t))
    def feas(L,U):
        if any(L[k] >= U[k] for k in range(3)): return False
        return sum(L) < 1 < sum(U)
    if not feas(L,U): return False
    for k,t in wit:
        U2 = list(U); U2[k] = min(U2[k], t)
        L2 = list(L); L2[k] = max(L2[k], t)
        if not feas(L,U2) or not feas(L2,U): return False
    return True

class World:
    def __init__(self, cells, geo=None):
        self.geo = geo
        self.cells = cells; n = self.n = len(cells)
        self.N = 3**n
        self.vals = np.array(list(itertools.product(range(3), repeat=n)), dtype=np.int8)
        # rank[w, cell, value]
        rk = np.zeros((3,n,3), dtype=np.int8)
        for w in range(3):
            for c,(k,t) in enumerate(cells):
                if w == k: rk[w,c] = [2,1,0]
                else:      rk[w,c] = [0,1,2]
        self.rk = rk
        pairs = [(a,b) for a in range(3) for b in range(3) if a!=b]
        code = np.zeros((3,3), dtype=np.int64)
        for i,(a,b) in enumerate(pairs): code[a,b] = i+1
        self.pairs = pairs
        pw = 7**np.arange(n, dtype=np.int64)
        V = self.vals.astype(np.int64)
        self.recid = (code[V[:,None,:], V[None,:,:]] * pw).sum(-1)   # N x N
        self.nrec = 7**n
        # record rank-change signs per world
        digits = np.array(list(itertools.product(range(7), repeat=n)))[:, ::-1]  # digit c = code at cell c
        # careful: recid uses pw[c]*code_c, so digit for cell c is (id // 7^c) % 7
        ids = np.arange(self.nrec)
        dig = np.stack([(ids // 7**c) % 7 for c in range(n)], axis=1)
        old = np.zeros_like(dig); new = np.zeros_like(dig)
        for i,(a,b) in enumerate(pairs):
            old[dig==i+1] = a; new[dig==i+1] = b
        self.dig = dig
        self.worse = np.zeros((3,self.nrec), bool); self.better = np.zeros((3,self.nrec), bool)
        for w in range(3):
            ch = np.zeros(dig.shape, np.int8)
            for c in range(n):
                m = dig[:,c] > 0
                ch[m,c] = rk[w,c,new[m,c]] - rk[w,c,old[m,c]]
            self.worse[w] = (ch>0).any(1); self.better[w] = (ch<0).any(1)
        geo = getattr(self, 'geo', None)
        def ok(v):
            if geo is not None:
                for a in range(n):
                    for b in range(n):
                        if geo[a]==geo[b] and v[a]!=v[b]: return False
            return coherent_pattern(cells, tuple(v))
        self.coh = np.array([ok(v) for v in self.vals])
        self.T = self.index([1]*n)
    def index(self, v):
        i = 0
        for x in v: i = i*3 + x
        return i
    def show(self, i):
        return ''.join('ASB'[x] for x in self.vals[i])

def closure(W, installs, P0, maxit=200, verbose=False, acc0=None):
    """installs: list of (w, P, Q) meaning P <=_w Q. Returns dict with relations and failures."""
    acc = [~W.better[w] for w in range(3)] if acc0 is None else [a.copy() for a in acc0]
    for (w,p,q) in installs: acc[w][W.recid[p,q]] = True
    P = set(P0)
    for it in range(maxit):
        changed = False
        R = [acc[w][W.recid] for w in range(3)]
        for w in range(3):
            Rf = R[w].astype(np.float32)
            two = (Rf @ Rf) > 0
            newT = R[w] & two.T          # edge X->Y lies on a triangle
            ys, xs = np.nonzero(newT)
            ids = W.recid[xs, ys]        # reverse Y->X  : recid[Y,X]; note newT[X,Y] -> install Y<=X
            ids = W.recid[np.nonzero(newT)[1], np.nonzero(newT)[0]]
            fresh = ids[~acc[w][ids]]
            if fresh.size:
                acc[w][fresh] = True; changed = True
        R = [acc[w][W.recid] for w in range(3)]
        for Nn in list(P):
            dom = R[0][:,Nn] & R[1][:,Nn] & R[2][:,Nn]
            xs = np.nonzero(dom)[0]
            for w in range(3):
                ids = W.recid[Nn, xs]
                fresh = ids[~acc[w][ids]]
                if fresh.size: acc[w][fresh] = True; changed = True
        R = [acc[w][W.recid] for w in range(3)]
        for Nn in list(P):
            tie = R[0][:,Nn] & R[1][:,Nn] & R[2][:,Nn] & R[0][Nn,:] & R[1][Nn,:] & R[2][Nn,:]
            for x in np.nonzero(tie)[0]:
                if x not in P: P.add(int(x)); changed = True
        if not changed: break
    R = [acc[w][W.recid] for w in range(3)]
    F1 = [np.nonzero(acc[w] & W.better[w] & ~W.worse[w])[0] for w in range(3)]
    F2 = [p for p in P if not W.coh[p]]
    return dict(acc=acc, R=R, P=P, F1=F1, F2=F2, it=it)
