"""Exploration (CHECKED-on-cells only): can the coarsening design be extended on the 6-line geometric
model to the FULL cell domain: T competitive against every model, every incoherent model strictly
dominated by a registered coherent model, closure free of F1/F2?  Greedy, seeded with PP20 Thm 3."""
import sys, time, random; sys.path.insert(0,'.')
from geom6 import *; from search import clean
W,L = build(); T=W.T; S=W.show; N=W.N
rnd = random.Random(int(sys.argv[1]) if len(sys.argv)>1 else 0)
idx = lambda s: W.index(['ASB'.index(c) for c in s])
Cw=[idx('SSSSBB'),idx('SSSBSB'),idx('SSSBBS')]
inst=[(w,T,Cw[w]) for w in range(3)]; P={T,*Cw}
LD=[i for i in range(N) if S(i)[3:]=='BBB' and i!=T]
for X in LD:
    wX=next(w for w in range(3) if W.worse[w][W.recid[T,X]])
    inst += [(u,Cw[wX],X) for u in range(3)]
    if W.better[wX][W.recid[T,X]]: inst.append((wX,T,X))
r=closure(W,inst,P); print('seed (Thm 3) clean:',clean(r),flush=True)
allw=lambda r,a,b: all(r['R'][w][a,b] for w in range(3))
tdefd=lambda r,y: any(r['R'][w][T,y] for w in range(3))
t0=time.time()
rest=[y for y in range(N) if not tdefd(r,y)]; rnd.shuffle(rest)
fail=[]
for y in rest:
    if tdefd(r,y): continue
    ok=False
    for w in rnd.sample(range(3),3):
        if not W.worse[w][W.recid[T,y]]: continue
        r2=closure(W,[(w,T,y)],r['P'],acc0=r['acc'])
        if clean(r2): inst.append((w,T,y)); r=r2; ok=True; break
    if not ok: fail.append(S(y))
print('T-defence phase: undefendable',len(fail),fail[:20],round(time.time()-t0),'s',flush=True)
coh=[i for i in np.nonzero(W.coh)[0] if i!=T]
dom=[x for x in range(N) if not W.coh[x]]; rnd.shuffle(dom)
prio=[idx(s) for s in sys.argv[2:]]; dom=prio+[x for x in dom if x not in prio]
undone=[]
for x in dom:
    if any(allw(r,c,x) and not allw(r,x,c) for c in r['P']): continue
    cands=[c for c in coh if all(W.worse[u][W.recid[c,x]] for u in range(3))]; rnd.shuffle(cands); cands=[c for c in cands if c in r['P']]+[c for c in cands if c not in r['P']]; ok=False
    for c in cands:
        new=[(u,c,x) for u in range(3)]
        tws=[None] if tdefd(r,c) else [w for w in range(3) if W.worse[w][W.recid[T,c]]]
        for w0 in tws:
            extra=[] if w0 is None else [(w0,T,c)]
            r2=closure(W,new+extra,r['P']|{c},acc0=r['acc'])
            if clean(r2):
                inst+=new+extra; P|={c}; r=r2; ok=True; break
        if ok: break
    if not ok: undone.append(S(x))
    print('  ',S(x),'->',S(c) if ok else 'NONE',len(undone),round(time.time()-t0),flush=True)
print('domination phase: undominated incoherent',len(undone),undone[:20],round(time.time()-t0),'s')
print('P:',sorted(S(p) for p in r['P']))
