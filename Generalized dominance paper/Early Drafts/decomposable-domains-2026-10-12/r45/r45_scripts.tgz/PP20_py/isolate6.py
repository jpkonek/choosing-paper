"""Which coherent models can dominate a given footprint rival cleanly on top of the Thm 3.2 seed
(6-line model), with and without T's defences against the rival itself?"""
import sys; sys.path.insert(0,'.')
from geom6 import *; from search import clean
W,L=build(); T=W.T; S=W.show; N=W.N
idx=lambda s: W.index(['ASB'.index(c) for c in s])
Cw=[idx('SSSSBB'),idx('SSSBSB'),idx('SSSBBS')]
inst=[(w,T,Cw[w]) for w in range(3)]
for X in [i for i in range(N) if S(i)[3:]=='BBB' and i!=T]:
    wX=next(w for w in range(3) if W.worse[w][W.recid[T,X]])
    inst += [(u,Cw[wX],X) for u in range(3)]
    if W.better[wX][W.recid[T,X]]: inst.append((wX,T,X))
r0=closure(W,inst,{T,*Cw}); assert clean(r0)
coh=[i for i in np.nonzero(W.coh)[0] if i!=T]
for s in sys.argv[1:]:
    x=idx(s); good=[]
    for c in coh:
        if not all(W.worse[u][W.recid[c,x]] for u in range(3)): continue
        tw=[w for w in range(3) if W.worse[w][W.recid[T,c]]]
        for w0 in tw:
            r=closure(W,[(u,c,x) for u in range(3)]+[(w0,T,c)],r0['P']|{c},acc0=r0['acc'])
            if clean(r): good.append((S(c),w0+1))
    print(s,'coherent?',bool(W.coh[x]),'clean dominators on the seed:',good)
