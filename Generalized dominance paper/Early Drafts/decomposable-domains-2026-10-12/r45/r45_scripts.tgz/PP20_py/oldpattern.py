"""Point 1 on audit's six-source module (cells of PP17): does adding T <=_w Y for
Y in {Lambda_T, V_c*, Y_12, X*} survive the closure (rules I-III) when triangles may be completed?
Incremental record-level closure: the module itself has no accepted 3-cycle (PP17), so every new
triangle or F1 pair contains a new record.  CHECKED on cells only."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'PP17_py'))
import records as R
from records import T, C, F, RANK, NC, names, gambles, rec, inv, delta
src, group, inst, info = R.build('six_all')
def kind(r,w):
    if not r: return 'triv'
    d=delta(r,w).values(); up=any(v>0 for v in d); dn=any(v<0 for v in d)
    return 'M' if up and dn else ('W' if up else 'I')
def compose(r1,r2):
    a={k:(x,y) for k,x,y in r1}; b={k:(x,y) for k,x,y in r2}; out=[]
    for k in sorted(set(a)|set(b)):
        if k in a and k in b:
            if a[k][1]!=b[k][0]: return None
            if a[k][0]!=b[k][1]: out.append((k,a[k][0],b[k][1]))
        elif k in a: out.append((k,)+a[k])
        else: out.append((k,)+b[k])
    return tuple(out)
def acc(r,w,extra): return (not r) or kind(r,w) in ('W','triv') or r in inst[w] or r in extra[w]
P = [T]+C+F
def run(newrecs, cap=4000):
    extra=[set(),set(),set()]; log=[]; F1=[]
    frontier=[(w,r) for w,r in newrecs]
    for w,r in newrecs:
        if kind(r,w)=='I': F1.append(('installed improvement',w)); 
        extra[w].add(r)
    while frontier and len(log)<cap:
        w,r=frontier.pop()
        pool=[s for s in list(inst[w])+list(extra[w]) if kind(s,w)=='M']
        for s in pool:
            for (x,y) in ((r,s),(s,r)):
                c=compose(x,y)
                if c is None or not c: continue
                k=kind(c,w)
                if k=='I': F1.append((w,x,y,c)); continue
                if k=='M' and acc(inv(c),w,extra):
                    for nr in (c,inv(x),inv(y)):
                        if not acc(nr,w,extra):
                            extra[w].add(nr); frontier.append((w,nr)); log.append((w,nr))
        if F1: break
    # rule III check for registered sources (only new records can create dominators)
    dom=[]
    for N in P:
        for w0 in range(3):
            for r in extra[w0]:
                if all(N[k]==b for k,a,b in r):
                    X=list(N)
                    for k,a,b in r: X[k]=a
                    if all(acc(r,w,extra) for w in range(3)): dom.append((N,tuple(X)))
    return F1, log, dom
def model(name):
    m=list(T)
    for k,g in enumerate(gambles):
        if T[k]!=2: continue
        if name=='Lambda': m[k]=0 if sum(1 for x in g if x>0)>=2 else 1
        if name=='V': m[k]=0 if sum(g)>0 else 1
        if name=='Y12' and names[k] in ('R1','R2'): m[k]=0
        if name=='Xstar' and names[k] in ('A1','A2'): m[k]=0
    return tuple(m)
for name in ('Lambda','V','Y12','Xstar'):
    Y=model(name); r=rec(T,Y)
    for w in range(3):
        k=kind(r,w)
        if k=='I': print(name,'w',w+1,': strict guidance refuses'); continue
        if k=='W': print(name,'w',w+1,': guidance already defends'); continue
        F1,log,dom=run([(w,r)])
        tag='F1' if F1 else ('CLEAN' if not dom else 'P-dominated')
        ex=''
        if F1:
            f=F1[0]
            if len(f)==4:
                lab=lambda x: ','.join(sorted(inst[w].get(x,{'completion/new'})))
                ex=' first F1 pair: [%s] then [%s]'%(lab(f[1]),lab(f[2]))
        print(name,'w',w+1,':',tag,'| completions',len(log),'| P-dominations',len(dom),ex,flush=True)
if len(sys.argv)>1 and sys.argv[1]=='joint':
    import itertools
    names4=('Lambda','V','Y12','Xstar'); recs={n:rec(T,model(n)) for n in names4}
    allowed={n:[w for w in range(3) if kind(recs[n],w)=='M'] for n in names4}
    res={}
    for choice in itertools.product(*[allowed[n] for n in names4]):
        F1,log,dom=run([(w,recs[n]) for n,w in zip(names4,choice)])
        res[choice]=('F1' if F1 else 'CLEAN' if not dom else 'Pdom', len(log))
    print('joint choices (worlds for Lambda,V,Y12,X*):', {k:v for k,v in res.items()})
