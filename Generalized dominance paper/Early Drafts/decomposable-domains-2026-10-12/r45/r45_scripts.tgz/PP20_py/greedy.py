import sys, time, random; sys.path.insert(0,'.')
from cells import *
W = World(make_cells())
T = W.T; S = W.show
idx = lambda s: W.index(['ASB'.index(ch) for ch in s])
maj = [i for i in range(W.N) if set(W.vals[i]) <= {0,1} and i!=T]
mino = [i for i in range(W.N) if set(W.vals[i]) <= {1,2} and i!=T]
fills = [x for x in maj+mino if not W.coh[x]]
coh = [i for i in np.nonzero(W.coh)[0] if i != T]
special = [idx('ASASSS'), idx('SASASS'), idx('AAAAAA'), idx('BABABA')]
def clean(r): return all(len(f)==0 for f in r['F1']) and not r['F2']
def t_defended(r, y): return any(r['R'][w][T,y] for w in range(3))
def run(seed):
    random.seed(seed)
    installs = []; P = {T}; defs = {}
    order = fills[:]; random.shuffle(order)
    r = closure(W, installs, P)
    # first T's defences for special rivals
    for y in special + [x for x in maj+mino if not t_defended(r,x)]:
        if t_defended(r,y): continue
        ok = False
        for w in random.sample(range(3),3):
            r2 = closure(W, installs+[(w,T,y)], P)
            if clean(r2): installs.append((w,T,y)); r=r2; ok=True; break
        if not ok: return ('T-defence', S(y), installs)
    for x in order:
        if any(all(r['R'][w][c,x] for w in range(3)) for c in r['P'] if c!=x):
            continue
        cands = coh[:]; random.shuffle(cands)
        ok = False
        for c in cands:
            new = [(w,c,x) for w in range(3)]
            if not t_defended(r, c):
                tw = [w for w in range(3)]
                random.shuffle(tw)
            else: tw=[None]
            for w0 in tw:
                extra = [] if w0 is None else [(w0,T,c)]
                r2 = closure(W, installs+new+extra, P|{c})
                if clean(r2) and all(t_defended(r2,y) for y in special) :
                    installs += new+extra; P |= {c}; r = r2; defs[x]=c; ok=True; break
            if ok: break
        if not ok: return ('repair', S(x), installs, defs)
    return ('SUCCESS', installs, defs, r)
if __name__ == '__main__':
    for seed in range(int(sys.argv[1]) if len(sys.argv)>1 else 1):
        t=time.time(); out = run(seed)
        print(seed, out[0], out[1] if out[0]!='SUCCESS' else len(out[2]), round(time.time()-t,1), flush=True)
        if out[0]=='SUCCESS':
            r=out[3]; print('P:', sorted(S(p) for p in r['P']))
            for x,c in out[2].items(): print(' ', S(x), '<-', S(c))
            break
