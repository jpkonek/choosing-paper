"""Independent re-verification (from scratch, not incremental) of a saved full6 run."""
import sys, pickle; sys.path.insert(0,'.')
from geom6 import *; from search import clean
W,L=build(); T=W.T; S=W.show; N=W.N
d=pickle.load(open(sys.argv[1],'rb'))
r=closure(W,d['inst'],set(d['P']))
R=r['R']; P=r['P']
allw=lambda a,b: all(R[w][a,b] for w in range(3))
F1=sum(len(f) for f in r['F1']); F2=len(r['F2'])
undef=[S(y) for y in range(N) if not any(R[w][T,y] for w in range(3))]
undom=[S(x) for x in range(N) if not W.coh[x] and not any(allw(c,x) and not allw(x,c) for c in P)]
Pdom=[(S(p),S(x)) for p in P for x in range(N) if allw(x,p) and not allw(p,x)]
ties=[(R[w]&R[w].T).sum()-N for w in range(3)]
allties=((R[0]&R[1]&R[2]&R[0].T&R[1].T&R[2].T).sum()-N)//2
print('F1',F1,'F2',F2,'| P',len(P),'(registered',len(d['P']),') | T undefended',len(undef),'| incoherent undominated',len(undom),
      '| P dominated',len(Pdom),'| single-world tie pairs',ties,'| all-world tie pairs',allties)
print('ALL PASS' if (F1==0 and F2==0 and not undef and not undom and not Pdom) else 'FAIL')
