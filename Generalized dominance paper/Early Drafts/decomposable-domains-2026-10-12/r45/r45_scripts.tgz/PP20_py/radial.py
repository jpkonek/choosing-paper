"""Radial-split cell model: each geometric line (one per class) is split into two radial halves.
Coherent models are constant on both halves (homogeneity, Lemma H); fills need not be."""
import sys, time, random; sys.path.insert(0,'.')
from cells import *
def make(xs):
    cells=[]; geo=[]
    g=0
    for k in range(3):
        for x in xs:
            for h in range(2):
                cells.append((k, 1/(1+x))); geo.append(g)
            g+=1
    return cells, geo
