"""Dense model-level cross-check (all copies, guidance included, rules I-IV) of the coarsening theorem
on 6 cells: one silent cell per class + one answered cell H_k (T = minority answer) per class."""
import sys; sys.path.insert(0,'.')
from cells import *
cells = [(k, Fr(1,3)) for k in range(3)]*2
W = World(cells)
idx = lambda v: W.index(v)
T = idx([1,1,1,2,2,2]); W.T = T
Cw = [idx([1,1,1]+[1 if j==w else 2 for j in range(3)]) for w in range(3)]
W.coh[:] = False
for p in [T]+Cw: W.coh[p] = True
fills = [i for i in range(W.N) if list(W.vals[i][3:])==[2,2,2] and i!=T]
inst=[]
for w in range(3): inst.append((w,T,Cw[w]))
assign={}
for X in fills:
    wX = next(w for w in range(3) if W.worse[w][W.recid[T,X]])
    assign[X]=wX
    for u in range(3): inst.append((u,Cw[wX],X))
    inst.append((wX,T,X))
r = closure(W, inst, {T}+set() if False else {T,*Cw})
R=r['R']
print('F1 per world', [len(f) for f in r['F1']], 'F2', r['F2'], 'P', len(r['P']))
ok = all(all(R[u][Cw[assign[X]],X] for u in range(3)) and not any(R[u][X,Cw[assign[X]]] for u in range(3)) for X in fills)
ok &= all(any(R[w][T,X] for w in range(3)) for X in fills+Cw)
tie = sum(((R[w]&R[w].T).sum()-W.N) for w in range(3))
print('strict domination at every world & T defences:', ok, '; single-world tie pairs:', tie)
