import sys; sys.path.insert(0,'.')
from radial import *; from search import *
xs = eval(sys.argv[1])
c,g = make(xs); W = World(c,g); T=W.T; S=W.show
coh = [i for i in np.nonzero(W.coh)[0] if i!=T]
targets = [W.index(['ASB'.index(ch) for ch in s]) for s in sys.argv[2:]]
for x in targets:
    good=[]
    for cc in coh:
        new=[(w,cc,x) for w in range(3)]
        for w0 in [None,0,1,2]:
            extra = [] if w0 is None else [(w0,T,cc)]
            r = closure(W,new+extra,{T,cc})
            if clean(r) and any(r['R'][w][T,cc] for w in range(3)):
                good.append((S(cc),w0))
    print(S(x), 'clean single dominators:', good)
