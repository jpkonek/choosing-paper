"""PP20 Lemma 3.1, exact check: q_w = s e_w + (1-s)/2 (1-e_w), K_w = conv(M u {q_w}), g^w = e_w - t*1,
0<s<t<c.  On g^w: T accepts (min over M > 0), C_w silent (q_w.g^w<0<min_M), C_{w'} accepts (q_{w'}.g^w>0).
Accepting g^w is correct at w only.  Checked at the centre direction for many eps (exact rationals);
the proof in the note gives the open neighbourhood."""
from fractions import Fraction as Fr
def run(eps):
    c=(1-eps)/3; s=c/3; t=2*c/3
    M=[[c+(eps if i==j else 0) for i in range(3)] for j in range(3)]
    q=[[s if i==w else (1-s)/2 for i in range(3)] for w in range(3)]
    ok=True
    for w in range(3):
        g=[(1 if i==w else 0)-t for i in range(3)]
        dot=lambda m: sum(a*b for a,b in zip(m,g))
        ok &= min(dot(m) for m in M)>0 and dot(q[w])<0
        ok &= all(dot(q[v])>0 for v in range(3) if v!=w)
        ok &= g[w]>0 and all(g[i]<0 for i in range(3) if i!=w)
    return ok
eps_list=[Fr(k,1000) for k in (1,10,50,100,200,300,333,400,500,600,700,800,900,950,990,999)]
res=[run(e) for e in eps_list]
print('Lemma 3.1 centre checks:', 'ALL PASS' if all(res) else res)
