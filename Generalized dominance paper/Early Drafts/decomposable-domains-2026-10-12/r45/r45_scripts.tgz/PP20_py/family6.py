"""Joint repair of the recurring leftover family on the 6-line model, by exhaustive backtracking,
on top of: Thm 3.2 seed + T's defences against all 729 models (as in full6's first phase)."""
import sys, time, random, pickle; sys.path.insert(0,'.')
from geom6 import *; from search import clean
W,L=build(); T=W.T; S=W.show; N=W.N
idx=lambda s: W.index(['ASB'.index(c) for c in s])
Cw=[idx('SSSSBB'),idx('SSSBSB'),idx('SSSBBS')]
inst=[(w,T,Cw[w]) for w in range(3)]
for X in [i for i in range(N) if S(i)[3:]=='BBB' and i!=T]:
    wX=next(w for w in range(3) if W.worse[w][W.recid[T,X]])
    inst += [(u,Cw[wX],X) for u in range(3)]
    if W.better[wX][W.recid[T,X]]: inst.append((wX,T,X))
r=closure(W,inst,{T,*Cw}); assert clean(r)
tdefd=lambda r,y: any(r['R'][w][T,y] for w in range(3))
for y in range(N):
    if tdefd(r,y): continue
    for w in range(3):
        if not W.worse[w][W.recid[T,y]]: continue
        r2=closure(W,[(w,T,y)],r['P'],acc0=r['acc'])
        if clean(r2): r=r2; break
assert all(tdefd(r,y) for y in range(N))
fam=[idx(s) for s in sys.argv[1:]]
coh=[i for i in np.nonzero(W.coh)[0] if i!=T]
allw=lambda r,a,b: all(r['R'][w][a,b] for w in range(3))
def options(r,x):
    out=[]
    for c in coh:
        if not all(W.worse[u][W.recid[c,x]] for u in range(3)): continue
        tws=[None] if tdefd(r,c) else [w for w in range(3) if W.worse[w][W.recid[T,c]]]
        for w0 in tws:
            extra=[] if w0 is None else [(w0,T,c)]
            r2=closure(W,[(u,c,x) for u in range(3)]+extra,r['P']|{c},acc0=r['acc'])
            if clean(r2): out.append((c,w0,r2))
    return out
nodes=[0]
def bt(r,i):
    nodes[0]+=1
    if i==len(fam): return []
    x=fam[i]
    if any(allw(r,c,x) and not allw(r,x,c) for c in r['P']): 
        res=bt(r,i+1); return None if res is None else [(S(x),'already')]+res
    for c,w0,r2 in options(r,x):
        res=bt(r2,i+1)
        if res is not None: return [(S(x),S(c),w0)]+res
    return None
t=time.time(); sol=bt(r,0)
print('family',sys.argv[1:],'joint repair:',sol,'nodes',nodes[0],round(time.time()-t),'s')
