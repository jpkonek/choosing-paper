"""CHECKED: PP20 Thm 4.1 on abstract cells (record level).  Theorem 3.2's installation, plus
t_Y = rec(T,Y) at ONE safe world sigma(Y) for EVERY model Y != T (including Y changing the footprints).
sigma(Y) is chosen by the recipe of the proof: the least world u0 in W(Y) unless it is killed by a
cross pair with some b-record, in which case the defended world w of the killing defender."""
import sys, itertools; sys.path.insert(0,'.')
from reclevel import *
vals=(0,1,2)
cls=[0,1,2]+[0,1,2]+[0]+[1]       # silent cells, footprint cells H_w, G_0 (T=A), H'_1 (T=B)
foot=[3,4,5]; C=Cells(cls); n=len(cls)
T=tuple([1,1,1]+[2,2,2]+[0]+[2])
Cw=[tuple(1 if c==foot[w] else T[c] for c in range(n)) for w in range(3)]
free=[c for c in range(n) if c not in foot]
models=[m for m in itertools.product(vals,repeat=n) if m!=T]
L0=[m for m in models if all(m[c]==T[c] for c in foot)]
M0=[set(),set(),set()]
for w in range(3): M0[w].add(C.rec(T,Cw[w]))
bw={}
for X in L0:
    wX=next(w for w in range(3) if C.kind(C.rec(T,X),w) in ('W','M')); bw[X]=wX
    for u in range(3): M0[u].add(C.rec(Cw[wX],X))
brecs=[(bw[X],C.rec(Cw[bw[X]],X)) for X in L0]
def killed(Y,u):
    t=C.rec(T,Y)
    for w,b in brecs:
        for c in (C.compose(t,b),C.compose(b,t)):
            if c!='X' and c and C.kind(c,u)=='I': return w
    return None
sigma={}; recipe_ok=True
for Y in models:
    t=C.rec(T,Y)
    W=[u for u in range(3) if C.kind(t,u) in ('W','M')]
    u0=W[0]; k=killed(Y,u0)
    s=u0 if k is None else k
    if s not in W or killed(Y,s) is not None: recipe_ok=False
    sigma[Y]=s
    if C.kind(t,s)=='M': M0[s].add(t)
Mset,P,F1,log=closure(C,M0,{T}|set(Cw))
acc=lambda r,w: r in Mset[w] or C.kind(r,w) in ('W','triv')
bad=sum(1 for Y in models if not any(acc(C.rec(T,Y),w) for w in range(3)))
bad+=sum(1 for X in L0 if not all(acc(C.rec(Cw[bw[X]],X),u) for u in range(3)) or any(acc(C.rec(X,Cw[bw[X]]),u) for u in range(3)))
print('cells',n,'models',len(models)+1,'L0',len(L0),'M-records/world',[len(m) for m in Mset],
      'recipe ok',recipe_ok,'F1',len(F1),'P',len(P),'events',len(log),'failures',bad,
      '=> ALL PASS' if (recipe_ok and bad==0 and not F1 and len(P)==4 and not log) else '=> FAIL')
