# KK1 exact checks (fractions.Fraction only). Run: python3 -I checks.py > checks.out
# Nothing in the referee verdict rests on this script; it double-checks algebra proved in KK1_referee.md.
from fractions import Fraction as F
import random, itertools

random.seed(20261018)
ADV = ['M', 'S', 'O', 'X']

def dot(a, b):
    return sum(x * y for x, y in zip(a, b))

def rnd(lo=1, hi=9, den=7):
    return F(random.randint(lo, hi * den), den)

def make_pair(j, l, o, zeros):
    """Majority orientation h with h_j,h_l>0>h_o. Weakly guiding, strict-best, X strictly worst.
    Positive world: M < S <= O < X (zero: S=O). Odd world: O < S <= M < X (zero: S=M)."""
    phi = [dict() for _ in range(3)]
    for i in (j, l):
        m = rnd(0, 3); s = m + rnd(); oo = s if i in zeros else s + rnd()
        phi[i] = {'M': m, 'S': s, 'O': oo, 'X': oo + rnd()}
    oo = rnd(0, 3); s = oo + rnd(); mm = s if o in zeros else s + rnd()
    phi[o] = {'O': oo, 'S': s, 'M': mm, 'X': mm + rnd()}
    return phi

def val(phi, w, a):
    return sum(w[i] * phi[i][a] for i in range(3))

def minset(phi, w):
    vals = {a: val(phi, w, a) for a in ADV}
    m = min(vals.values())
    return frozenset(a for a in ADV if vals[a] == m)

fails = {}
def check(name, cond):
    fails.setdefault(name, [0, 0])
    fails[name][0] += 1
    if not cond:
        fails[name][1] += 1

# ---------------------------------------------------------------------------------------------
# (A) JJ3 Lemma 4.2, repaired step 6: on the WHOLE opposite edge {w_j = 0} the pair minimiser of an
# essential pair is exactly M on (0,m_h), S on (m_h,s_h), O on (s_h,1). Complete test: the minimiser
# set is constant between consecutive breakpoints of the affine edge functions, so it suffices to test
# every breakpoint and every midpoint of consecutive breakpoints (plus the ends).
def edge_point(j, l, o, t):
    w = [F(0)] * 3
    w[l] = 1 - t; w[o] = t
    return w

n_ess = 0
trials = 0
while n_ess < 3000:
    trials += 1
    j, l, o = random.sample(range(3), 3)
    phi = make_pair(j, l, o, {j})
    c = [phi[i]['S'] - phi[i]['M'] for i in range(3)]
    cp = [phi[i]['S'] - phi[i]['O'] for i in range(3)]
    m_h = c[l] / (c[l] - c[o])            # c.w0(t) = c_l(1-t)+c_o t = 0
    s_h = -cp[l] / (cp[o] - cp[l])        # c'.w0(t) = 0
    if not (m_h < s_h):                   # not case (b2): c'.b >= 0 at b = m_h
        continue
    n_ess += 1
    # breakpoints: zeros in (0,1) of every pairwise difference along the edge
    bps = {F(0), F(1)}
    for a, b in itertools.combinations(ADV, 2):
        A0 = phi[l][a] - phi[l][b]; A1 = phi[o][a] - phi[o][b]   # (1-t)A0 + t A1
        if A0 != A1:
            t = A0 / (A0 - A1)
            if 0 < t < 1:
                bps.add(t)
    bps = sorted(bps)
    pts = list(bps) + [(bps[k] + bps[k + 1]) / 2 for k in range(len(bps) - 1)]
    for t in pts:
        if t in (0, 1):
            continue
        ms = minset(phi, edge_point(j, l, o, t))
        if t < m_h:
            check('A whole-edge minimiser = {M} on (0,m_h)', ms == {'M'})
        elif t == m_h:
            check('A tie {M,S} at m_h', ms == {'M', 'S'})
        elif t < s_h:
            check('A whole-edge minimiser = {S} on (m_h,s_h)', ms == {'S'})
        elif t == s_h:
            check('A tie {S,O} at s_h', ms == {'S', 'O'})
        else:
            check('A whole-edge minimiser = {O} on (s_h,1)', ms == {'O'})
            # the audit's chain of signs on (s_h,1): c'>0, c<0, d=c-c'<0
            w = edge_point(j, l, o, t)
            check('A signs on (s_h,1): c<0<c\', d<0',
                  dot(c, w) < 0 < dot(cp, w) and dot([c[i] - cp[i] for i in range(3)], w) < 0)
    # d(1) < 0 (value at e_o) and c(s_h) < 0
    w1 = edge_point(j, l, o, F(1)); ws = edge_point(j, l, o, s_h)
    check('A d(e_o)<0 and c(s_h)<0', dot([c[i] - cp[i] for i in range(3)], w1) < 0 and dot(c, ws) < 0)
print('(A) essential pairs tested:', n_ess, 'of', trials, 'random single-zero pairs')

# (A') the inference in JJ3's original step 6 is not valid: two essential pairs with s_h <= m_h'
# (so s_h is not > t0 = max(m_h, m_h')). Exhibit one exactly (the lemma's conclusion is not refuted;
# only the stated inference).
def pair_from(cl, co, cpl, cpo, cj=F(1)):
    # build penalties at worlds (j,l,o)=(0,1,2) with given c_l, c_o (<0), c'_l (<0), c'_o, c'_j = 0
    # positive worlds j,l: M=0, S=c_i, O=S-c'_i ; odd world o: O=0, S=c'_o, M=S-c_o
    phi = [dict() for _ in range(3)]
    phi[0] = {'M': F(0), 'S': cj, 'O': cj, 'X': cj + 1}
    phi[1] = {'M': F(0), 'S': cl, 'O': cl - cpl, 'X': cl - cpl + 1}
    phi[2] = {'O': F(0), 'S': cpo, 'M': cpo - co, 'X': cpo - co + 1}
    return phi
# choose explicit essential pairs: m_h = c_l/(c_l+|c_o|), s_h = |c'_l|/(|c'_l|+c'_o)
p1 = pair_from(F(1), F(-4), F(-3), F(7))     # m = 1/5, s = 3/10
p2 = pair_from(F(2), F(-3), F(-3), F(2))     # m = 2/5, s = 3/5
for nm, p in (('p1', p1), ('p2', p2)):
    c = [p[i]['S'] - p[i]['M'] for i in range(3)]; cp = [p[i]['S'] - p[i]['O'] for i in range(3)]
    print("(A') %s: m_h = %s, s_h = %s" % (nm, c[1] / (c[1] - c[2]), -cp[1] / (cp[2] - cp[1])))
print("(A') t0 = max(m_h,m_h') = 2/5 > s_h(p1) = 3/10: 'both s exceed t0' fails for this configuration")

# ---------------------------------------------------------------------------------------------
# (B) Jacobians of the two parametrisations (JJ3 §4), exactly at random rational points.
def det3(M):
    return (M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1])
            - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0])
            + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0]))
for _ in range(2000):
    lam = rnd(); rho = rnd(); pi = F(random.randint(1, 99), 100); a = rnd()
    # h = lam*(rho, pi, -(1-pi)); columns d/dpi, d/drho, d/dlam; rows j,l,o
    J1 = [[0, lam, rho], [lam, 0, pi], [lam, 0, -(1 - pi)]]
    check('B Jacobian (pi,rho,lam) -> h equals lam^2', abs(det3(J1)) == lam * lam)
    # y = lam*(a, -pi, 1-pi); columns d/dpi, d/da, d/dlam
    J2 = [[0, lam, a], [-lam, 0, -pi], [-lam, 0, 1 - pi]]
    check('B Jacobian (pi,a,lam) -> y equals lam^2', abs(det3(J2)) == lam * lam)

# ---------------------------------------------------------------------------------------------
# (C) N21.6 Steps 2-3 under weak signs (JJ2 Table 7.2 S8b, S8c). Normalised facet data of T1 with x = x_+,
# at three values of eps where x_+ is rational: eps = 1/19 (x=3/2), 1/7 (x=2), 4/13 (x=3).
def facet_c(k, h, x):
    h1, h2, h3 = h
    if k == 0: return (-(x * h2 + h3), x * h2, h3)
    if k == 1: return (h1, -(h1 + x * h3), x * h3)
    return (x * h1, h2, -(x * h1 + h2))
for eps, x in ((F(1, 19), F(3, 2)), (F(1, 7), F(2)), (F(4, 13), F(3))):
    kap = (1 + 2 * eps) / (1 - eps)
    check('C corner equation x+1/x = kappa+1', x + 1 / x == kap + 1)
    check('C box fails: x^2 > kappa', x * x > kap)
    # failing pairs (a,b) for x_+: (1,2),(2,3),(3,1) -> 0-based (0,1),(1,2),(2,0); c = third
    for (a, b) in ((0, 1), (1, 2), (2, 0)):
        cidx = 3 - a - b
        # b-crossings: on facet a (w', w'_a<0, w'_b=0, w'_c>0) and on facet c (w, w_c<0, w_b=0, w_a>0).
        # On F_k the crossing of coordinate i is at h with h_i = 0, h.v_k = 0, written cyclically:
        # F_1 crossings (-1,0,kappa) [coord 2], (-1,kappa,0) [coord 3]; cyclic shifts for F_2, F_3.
        def crossing(k, i):
            h = [F(0)] * 3
            h[k] = F(-1)
            other = 3 - k - i
            h[other] = kap
            return tuple(h)
        wp = crossing(a, b); w = crossing(cidx, b)
        ca = facet_c(a, wp, x); cc = facet_c(cidx, w, x)
        check('C A-case: c_a(w\')_a < 0 strictly', ca[a] < 0)
        check('C B-case: c_c(w)_c < 0 strictly (strict vertex in V-)', cc[cidx] < 0)
        check('C B-case: crossing row c_c(w)_b = 0', cc[b] == 0)
        check('C B-case: c_c(w)_a > 0', cc[a] > 0)
# Steps 2-3 of N21.6 with weak signs, on random chart vectors (alpha = c.q, d), edge [e_a,e_b] with
# coordinates q = (1-s) e_b + s e_a.  A-case: g_a<0<g_b, c_a<0 (strict, by veccluster), V- = {e_a}.
# B-case: g_a>0>g_b, g_c<0, c_b <= 0 (possibly 0), c_c<0 (strict), V- = {e_b, e_c}.
for _ in range(4000):
    case = random.choice('AB')
    a, b, cc_ = 0, 1, 2
    if case == 'A':
        c = [-rnd(), rnd(), rnd()]                     # weak signs of g: (-,+,+), with c_a<0 strict
        dvec = [-rnd(), rnd(), rnd()]                  # (F2): strict sign of g
        Vminus = [a]
    else:
        cb = random.choice([F(0), -rnd()])
        c = [rnd(), cb, -rnd()]                        # g: (+,-,-); c_b weak, c_c strict
        dvec = [rnd(), -rnd(), -rnd()]
        Vminus = [b, cc_]
    def ev(v, q): return dot(v, q)
    def edgeq(s): q = [F(0)] * 3; q[a] = s; q[b] = 1 - s; return q
    # sigma: zero of alpha on the closed edge
    A0, A1 = c[b], c[a]                                # alpha((1-s)e_b+s e_a) = (1-s)c_b + s c_a
    if A0 == A1: continue
    sig = A0 / (A0 - A1)
    D0, D1 = dvec[b], dvec[a]
    z = D0 / (D0 - D1)
    if not (0 <= sig <= 1 and 0 < z < 1): continue
    # q0 with alpha(q0)>0 and d(q0)<=0 between them
    lo, hi = (min(sig, z), max(sig, z))
    if lo == hi: continue
    s0 = (lo + hi) / 2
    q0 = edgeq(s0)
    if not (ev(c, q0) > 0 and ev(dvec, q0) <= 0): continue
    sq = edgeq(sig)
    check('C d(sigma) < 0 (F2)', ev(dvec, sq) < 0)
    check('C alpha(z) > 0', ev(c, edgeq(z)) > 0)
    if case == 'B' and c[b] == 0:
        check('C B-case with c_b=0: sigma = e_b', sig == 0)
    # Step 3 needs a vertex of V- with alpha<0 and d<0 (so {alpha<=0} meets int Delta near it)
    check('C Step 3: some e_l in V- has alpha(e_l)<0 and d(e_l)<0',
          any(c[l] < 0 and dvec[l] < 0 for l in Vminus))
# control: if every vertex of V- had alpha = 0 (an odd-zero-like alpha), {alpha<=0} meets Delta only at
# that vertex, so Step 3's "points of {alpha<=0} in int Delta near e_l" fails.
c = [F(0), F(2), F(3)]
grid = [(F(i, 12), F(k, 12), F(12 - i - k, 12)) for i in range(1, 12) for k in range(1, 12) if i + k < 12]
print('(C) control: interior grid points with alpha<=0 when alpha(e_a)=0 and alpha>0 at the other vertices:',
      sum(1 for q in grid if dot(c, q) <= 0))

# ---------------------------------------------------------------------------------------------
# (D) S8a: chart-form edge box via d. If g = A+lam B has g_a,g_b<0 and (F2), then d^g < 0 on the closed
# edge [e_a,e_b] while R(g) is contained in {d^g>0}; with only weak c^g (zeros allowed at a or b) the
# c-version can fail at a vertex of the edge.
cnt_c_fail = 0
for _ in range(3000):
    d = [-rnd(), -rnd(), rnd()]                        # strict sign of g = (-,-,+)
    cg = [random.choice([F(0), -rnd()]), random.choice([F(0), -rnd()]), rnd()]
    for s in [F(k, 20) for k in range(21)]:
        q = [1 - s, s, F(0)]
        check('D d^g<0 on the closed edge', dot(d, q) < 0)
        if dot(cg, q) == 0:
            cnt_c_fail += 1
print('(D) edge points where the weak c-version gives c.q = 0 (no contradiction from c):', cnt_c_fail)

# ---------------------------------------------------------------------------------------------
# (E) JJ2 Prop 5.3 applied to BOTH orientations in turn (rotate g's inactive zero, then -g's), on pairs
# where both orientations carry zeros and all zeros are inactive. Minimiser sets compared at every vertex,
# edge-midpoint and centroid of the line arrangement (complete test), and strict guidance after.
def chart_lines(phi):
    L = []
    for a, b in itertools.combinations(['M', 'S', 'O'], 2):
        L.append(tuple(phi[i][a] - phi[i][b] for i in range(3)))
    return L
def arrangement_points(lines):
    E = [(F(1), F(0), F(0)), (F(0), F(1), F(0)), (F(0), F(0), F(1))]
    allL = list(lines) + [(F(1), 0, 0), (0, F(1), 0), (0, 0, F(1))]
    pts = set(E)
    for L1, L2 in itertools.combinations(allL, 2):
        # solve L1.w = 0, L2.w = 0, sum w = 1
        M = [list(L1), list(L2), [F(1), F(1), F(1)]]
        D = det3(M)
        if D == 0: continue
        sol = []
        for col in range(3):
            Mc = [row[:] for row in M]
            for r in range(3): Mc[r][col] = F(1) if r == 2 else F(0)
            sol.append(det3(Mc) / D)
        if all(v >= 0 for v in sol): pts.add(tuple(sol))
    pts = list(pts)
    extra = []
    for p, q in itertools.combinations(pts, 2):
        extra.append(tuple((p[i] + q[i]) / 2 for i in range(3)))
    for p, q, r in itertools.combinations(pts, 3):
        extra.append(tuple((p[i] + q[i] + r[i]) / 3 for i in range(3)))
    return pts + extra
def rotate(phi, acc, accneg, t):
    # c^{g} with g the orientation accepted by 'acc'; add t*c^{-g} to both acceptances
    cneg = [phi[i]['S'] - phi[i][accneg] for i in range(3)]
    new = [dict(phi[i]) for i in range(3)]
    for i in range(3):
        new[i][acc] += t * cneg[i]; new[i][accneg] += t * cneg[i]
        m = max(new[i]['M'], new[i]['S'], new[i]['O'])
        if new[i]['X'] <= m: new[i]['X'] = m + 1
    return new
def strictly_guiding(phi, j, l, o):
    ok = True
    for i in (j, l): ok &= phi[i]['M'] < phi[i]['S'] < phi[i]['O'] < phi[i]['X']
    ok &= phi[o]['O'] < phi[o]['S'] < phi[o]['M'] < phi[o]['X']
    return ok
nE = 0
while nE < 400:
    j, l, o = random.sample(range(3), 3)
    zs = random.choice([{o, j}, {o, l}, {o, j, l}])    # odd zero (zero of g=h) plus zeros of -h
    phi = make_pair(j, l, o, zs)
    nE += 1
    pts = arrangement_points(chart_lines(phi))
    before = [minset(phi, p) for p in pts]
    # orientation h (acc 'M') carries the odd zero at o; rotate it with c^{-h}; then -h (acc 'O')
    p1 = rotate(phi, 'M', 'O', F(1, 2))
    p2 = rotate(p1, 'O', 'M', F(1, 2))
    pts2 = arrangement_points(chart_lines(phi) + chart_lines(p2))   # overlay: complete test
    check('E minimiser sets unchanged after both rotations',
          all(minset(phi, p) == minset(p2, p) for p in pts2))
    check('E strictly guiding after both rotations', strictly_guiding(p2, j, l, o))
    check('E silence never a weak minimiser (odd zero present)', all('S' not in minset(phi, p) for p in pts))

print()
for k, (n, f) in fails.items():
    print('%-70s %6d tests, %d failures' % (k, n, f))
print('TOTAL FAILURES:', sum(f for n, f in fails.values()))
