# CHECKS for KK3 Theorem 2.1 (two-sided or one-sided) and its ingredients. Exact arithmetic.
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kk3common import *
random.seed(20261018)
fails = 0
out = []

# (1) Identity: P_{conv(K u {e_l,e_o})}(g) = min(P_K(g), g_l, g_o)  (Lemma 2.2(b) of KK3).
n1 = 0
for _ in range(20000):
    K = [rnd_simplex_point(30, False) for _ in range(random.randint(1, 5))]
    l, o = random.sample(range(3), 2)
    g = rnd_gamble()
    lhs = P(K + [E(l), E(o)], g)
    rhs = min(P(K, g), g[l], g[o])
    n1 += 1
    if lhs != rhs: fails += 1
out.append(f"(1) hull identity for D_K cap D_l cap D_o: {n1} cases")

# (2) conv(T1 u {e_i}) meets the boundary of the simplex only at e_i: every vertex v_k of T1 has all
#     coordinates > 0, so lam*e_i + (1-lam)*x has a zero coordinate only if lam = 1.
n2 = 0
for eps in [F(1, 100), F(1, 20), F(3, 10), F(1, 2), F(3, 5), F(9, 10), F(99, 100)]:
    for v in T1_vertices(eps):
        n2 += 1
        if not min(v) > 0: fails += 1
out.append(f"(2) T1 vertices interior: {n2} cases")

# (3) Core of Lemma 2.3: if conv(U_l u {e_l,e_o}) = conv(U_o u {e_l,e_o}) = W is not inside the edge
#     Delta_lo, then no gamble g with g_l > 0 > g_o has P_{U_l}(g) > 0 and P_{U_o}(-g) > 0.
#     Instances: W random polygon containing e_l, e_o with a vertex off the edge; U_l, U_o contain
#     the off-edge vertices of W plus random points of W. Control: U_l={e_l}, U_o={e_o}.
n3 = 0; n3hull = 0; ctrl_hits = 0; ctrl_n = 0
for trial in range(3000):
    l, o = random.sample(range(3), 2)
    j = 3 - l - o
    extra = [rnd_simplex_point(24, False) for _ in range(random.randint(1, 4))]
    W = hull([E(l), E(o)] + extra)
    off = [m for m in W if m[j] > 0]
    if not off:
        continue
    def rnd_in_W():
        # random convex combination of hull vertices
        wts = [F(random.randint(0, 9)) for _ in W]
        if sum(wts) == 0: wts[0] = F(1)
        s = sum(wts)
        return tuple(sum(wts[k]*W[k][i] for k in range(len(W)))/s for i in range(3))
    Ul = off + [rnd_in_W() for _ in range(random.randint(0, 3))]
    Uo = off + [rnd_in_W() for _ in range(random.randint(0, 3))]
    if random.random() < 0.5: Ul.append(E(l))
    if random.random() < 0.5: Uo.append(E(o))
    Hl = hull(Ul + [E(l), E(o)]); Ho = hull(Uo + [E(l), E(o)])
    n3hull += 1
    if set(Hl) != set(Ho) or set(Hl) != set(W): fails += 1
    for _ in range(40):
        g = list(rnd_gamble())
        g[l] = abs(g[l]) + F(1, 50); g[o] = -abs(g[o]) - F(1, 50)
        g = tuple(g); mg = tuple(-x for x in g)
        n3 += 1
        if P(Ul, g) > 0 and P(Uo, mg) > 0: fails += 1
        # control with precise vertex sets
        ctrl_n += 1
        if P([E(l)], g) > 0 and P([E(o)], mg) > 0: ctrl_hits += 1
out.append(f"(3) common off-edge extreme point blocks two-sided pairs across the edge: {n3hull} hull instances (hull equality verified), {n3} gambles; control (precise vertex sets): {ctrl_hits}/{ctrl_n} gambles two-sided")

# (4) The one-sided family V_i = conv(e_i, Q), Q a polygon inside the intersection of conv(T1 u e_i):
#     (a) V_i inside conv(T1 u e_i) (T1 evaluable is consistent);  (b) compatibility:
#     conv(V_i u e_j) = conv(V_j u e_i);  (c) (LF): sampled points of the boundary of D_T1 lie in some
#     D_{V_i} with strict margin;  (d) one-sided: no sampled mixed g has g and -g both in Av;
#     (e) (Av_{l,o}) fails: an explicit g with g_l, g_o > 0 outside Av.
n4 = 0; n4c = 0; n4d = 0
for eps in [F(1, 10), F(3, 10), F(1, 2), F(4, 5)]:
    T = T1_vertices(eps)
    u = (F(1, 3),) * 3
    for trial in range(60):
        s = F(random.randint(1, 9), 10)
        # Q: random small polygon inside u + s(T1 - u) (a shrunken copy of T1, inside int T1)
        Ts = [tuple(u[i] + s*(v[i]-u[i]) for i in range(3)) for v in T]
        Q = []
        for _ in range(random.randint(1, 4)):
            wts = [F(random.randint(0, 9)) for _ in range(3)]
            if sum(wts) == 0: wts[0] = F(1)
            Q.append(tuple(sum(wts[k]*Ts[k][i] for k in range(3))/sum(wts) for i in range(3)))
        V = [hull([E(i)] + Q) for i in range(3)]
        ok = True
        for i in range(3):
            Ci = hull(T + [E(i)])
            ok &= all(in_hull(m, Ci) for m in V[i])                       # (a)
            for jj in range(3):
                if jj != i:
                    ok &= set(hull(V[i] + [E(jj)])) == set(hull(V[jj] + [E(i)]))   # (b)
        # (c) boundary points of D_T1: h with min_T h.m = 0 (facet points), sampled
        for _ in range(30):
            k = random.randrange(3)
            a = rnd_gamble()
            # project a onto v_k^perp then shift so that h is on facet F_k only if min is at v_k
            vk = T[k]
            h = tuple(a[i] - dot(a, vk) for i in range(3))   # h.vk = 0 since vk sums to 1
            if all(dot(h, T[m]) >= 0 for m in range(3)) and any(x != 0 for x in h):
                n4c += 1
                ok &= any(P(V[i], h) > 0 for i in range(3))
        # (d) one-sidedness
        for _ in range(60):
            g = rnd_gamble()
            if min(g) < 0 < max(g):
                mg = tuple(-x for x in g)
                inAv = any(P(V[i], g) > 0 and g[i] > 0 for i in range(3))
                inAvm = any(P(V[i], mg) > 0 and mg[i] > 0 for i in range(3))
                n4d += 1
                ok &= not (inAv and inAvm)
        # (e) explicit non-availability witness for each edge {l,o}: g = (-N, 1, 1) in coordinates (j,l,o)
        for j in range(3):
            l, o = [x for x in range(3) if x != j]
            qj = min(m[j] for m in Q)
            N = 3 / qj
            g = [F(0)]*3; g[j] = -N; g[l] = F(1); g[o] = F(1); g = tuple(g)
            ok &= all(not (P(V[i], g) > 0 and g[i] > 0) for i in range(3))
        n4 += 1
        if not ok: fails += 1
out.append(f"(4) one-sided admissible family V_i = conv(e_i,Q): {n4} domains, {n4c} boundary points, {n4d} mixed gambles")

out.append(f"FAILURES: {fails}")
print("\n".join(out))
