# Exact helpers for KK3 (fractions only). Points of the simplex are triples of Fractions.
from fractions import Fraction as F
import random, itertools

def dot(a, b):
    return sum(x*y for x, y in zip(a, b))

def E(i):
    return tuple(F(int(k == i)) for k in range(3))

def P(V, g):
    """Lower prevision min_{m in conv V} m.g (minimum over the vertex list)."""
    return min(dot(m, g) for m in V)

def cross2(o, a, b):
    return (a[0]-o[0])*(b[1]-o[1]) - (a[1]-o[1])*(b[0]-o[0])

def hull(pts):
    """Exact convex hull (vertex set, strict extreme points) in aff(simplex), via coordinates (w0,w1)."""
    pts = sorted(set(pts), key=lambda p: (p[0], p[1]))
    if len(pts) <= 2:
        return pts
    lower, upper = [], []
    for p in pts:
        while len(lower) >= 2 and cross2(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(pts):
        while len(upper) >= 2 and cross2(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]

def in_hull(x, H):
    """x in conv(H) for a hull H given in counter-clockwise order (len >= 3), exact."""
    n = len(H)
    if n == 1:
        return x == H[0]
    if n == 2:
        a, b = H
        if cross2(a, b, x) != 0:
            return False
        return min(a[0], b[0]) <= x[0] <= max(a[0], b[0]) and min(a[1], b[1]) <= x[1] <= max(a[1], b[1])
    return all(cross2(H[k], H[(k+1) % n], x) >= 0 for k in range(n))

def rnd_simplex_point(den=40, interior=True):
    while True:
        a = random.randint(0, den); b = random.randint(0, den - a); c = den - a - b
        p = (F(a, den), F(b, den), F(c, den))
        if not interior or min(p) > 0:
            return p

def rnd_gamble(den=7, hi=30):
    return tuple(F(random.randint(-hi, hi), random.randint(1, den)) for _ in range(3))

def T1_vertices(eps):
    c0 = (1 - eps) / 3
    return [tuple(c0 + (eps if k == i else 0) for k in range(3)) for i in range(3)]
