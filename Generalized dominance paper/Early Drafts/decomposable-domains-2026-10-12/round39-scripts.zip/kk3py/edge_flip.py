# CHECKS for KK3 Lemma 3.2 (repaired JJ3 Lemma 4.2 edge pattern) and Lemma 4.1 (raising unanimous zeros).
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kk3common import *
random.seed(181018)
ADV = ['M', 'S', 'O', 'X']
def rr(lo=1, hi=9, den=7): return F(random.randint(lo, hi*den), den)

def make_pair(j, l, o, zeros):
    """Weakly guiding, strict-best, X strictly worst; h_j,h_l>0>h_o; zeros (bad~silence) at listed worlds."""
    phi = [dict() for _ in range(3)]
    for i in (j, l):
        m = rr(0, 3); s = m + rr(); oo = s if i in zeros else s + rr()
        phi[i] = {'M': m, 'S': s, 'O': oo, 'X': oo + rr()}
    oo = rr(0, 3); s = oo + rr(); mm = s if o in zeros else s + rr()
    phi[o] = {'O': oo, 'S': s, 'M': mm, 'X': mm + rr()}
    return phi

def argmin(phi, w):
    vals = {a: dot(w, tuple(phi[i][a] for i in range(3))) for a in ADV}
    mn = min(vals.values())
    return frozenset(a for a in ADV if vals[a] == mn)

fails = 0; ness = 0; nflip = 0; npts = 0
for trial in range(20000):
    j, l, o = random.choice(list(itertools.permutations(range(3))))
    phi = make_pair(j, l, o, {j})
    c  = tuple(phi[i]['S'] - phi[i]['M'] for i in range(3))
    cp = tuple(phi[i]['S'] - phi[i]['O'] for i in range(3))
    d  = tuple(c[i] - cp[i] for i in range(3))
    def w0(t):
        w = [F(0)]*3; w[l] = 1 - t; w[o] = t; return tuple(w)
    # edge points: m_h where c.w0 = 0, s_h where cp.w0 = 0 (o-coordinate)
    m_h = c[l] / (c[l] - c[o])          # c_l > 0 > c_o
    s_h = -cp[l] / (cp[o] - cp[l])      # cp_l < 0 < cp_o
    essential = (m_h < s_h)             # case (b2) of JJ3 Lemma 3.1: the S-triangle has interior points
    # interior S points exist iff the triangle is nondegenerate; check via an interior test point
    if not essential:
        continue
    ness += 1
    # audit repair inequalities
    ok = dot(c, w0(s_h)) < 0 and dot(d, w0(s_h)) < 0 and dot(d, w0(F(1))) < 0
    ok &= dot(d, w0(F(0))) > 0 and dot(d, w0(m_h)) > 0
    # exact edge pattern at sample points
    ts = [F(0), m_h/2, m_h*F(999, 1000)]
    ts_S = [m_h + (s_h - m_h)*F(k, 7) for k in range(1, 7)]
    ts_O = [s_h + (1 - s_h)*F(k, 7) for k in range(1, 8)] + [s_h + (1 - s_h)/10**6]
    for t in ts:   ok &= argmin(phi, w0(t)) == frozenset('M')
    for t in ts_S: ok &= argmin(phi, w0(t)) == frozenset('S')
    for t in ts_O: ok &= argmin(phi, w0(t)) == frozenset('O')
    ok &= argmin(phi, w0(s_h)) == frozenset(['S', 'O'])
    ok &= argmin(phi, w0(m_h)) == frozenset(['M', 'S'])
    npts += len(ts) + len(ts_S) + len(ts_O) + 2
    # the flip: accept h at t=0, accept -h at t=1
    ok &= argmin(phi, w0(F(0))) == frozenset('M') and argmin(phi, w0(F(1))) == frozenset('O')
    nflip += 1
    # L_h passes through e_j (cp_j = 0) and the interior silence triangle exists: centroid of (m_h, s_h, t_h)
    if not ok: fails += 1

# Lemma 4.1: raising phi(O) on unanimous pairs with S~O zeros: strictly guiding, M-cost unchanged.
nr = 0
for trial in range(5000):
    phi = [dict() for _ in range(3)]
    zero = [random.random() < 0.5 for _ in range(3)]
    for i in range(3):
        m = rr(0, 3); s = m + rr(); oo = s if zero[i] else s + rr()
        phi[i] = {'M': m, 'S': s, 'O': oo, 'X': oo + rr()}
    h = tuple(F(random.randint(1, 50), random.randint(1, 9)) for _ in range(3))
    new = [dict(p) for p in phi]
    for i in range(3):
        new[i]['O'] = phi[i]['O'] + h[i]
        new[i]['X'] = max(phi[i]['X'], new[i]['O']) + h[i]
    ok = all(new[i]['M'] < new[i]['S'] < new[i]['O'] < new[i]['X'] for i in range(3))
    ok &= all(new[i]['M'] == phi[i]['M'] for i in range(3))
    ok &= all(new[i][a] >= phi[i][a] for i in range(3) for a in ADV)
    nr += 1
    if not ok: fails += 1

print(f"essential single-zero pairs tested: {ness}; exact edge points: {npts}; flips M->O verified: {nflip}")
print(f"unanimous raises tested: {nr}")
print(f"FAILURES: {fails}")
