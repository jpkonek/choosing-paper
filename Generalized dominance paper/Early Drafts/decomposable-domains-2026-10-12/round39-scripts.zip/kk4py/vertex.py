# KK4 section 5: a vertex best-tie (strict-best fails at the odd world o = world 2).
# Regions (o-odd pairs, positive worlds 0, 1):
#   Z : phi_2(O) = phi_2(S) (best-tie at the odd world), phi_1(O) = phi_1(S), phi_0(S) < phi_0(O).
#       O -> S increments: Phi = (-1, 0, 0), Psi = (-1, -1, 1).
#   P : strict at world 2.  O -> S increments: Phi = (-1, -1, 1), Psi = (-1, -1, 1).
# A model is (sigma, kappa): silent on a sigma-share of Z and on a kappa-share of P, rejecting (O) elsewhere.
# B^o = (0, 0).  It pays a phi_2-cost iff kappa > 0.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from zono import *

ZOS = ((F(-1), F(0), F(0)), (F(-1), F(-1), F(1)))
POS = ((F(-1), F(-1), F(1)), (F(-1), F(-1), F(1)))
neg = lambda g: (tuple(-x for x in g[0]), tuple(-x for x in g[1]))
J = [0, 1, 2]


def gens_of(sigma, kappa):
    return [ZOS, neg(ZOS), POS, neg(POS)], [1 - sigma, sigma, 1 - kappa, kappa]


print("=" * 8, "(A) fixed competitor X0 = B^o with S on Z, transported to indices p_n -> e_o (II2 Prop 3.2 mechanism)")
print("    C_{p_n} = (sigma=0, kappa=1/n): rejects on Z, pays phi_2-cost kappa on P; C_{e_o} = B^o")
for n in [2, 10, 100, 10**4, 10**8]:
    k = F(1, n)
    phi, psi = comb([ZOS, neg(POS)], [F(1), k])     # t_n = rec(C_{p_n}, X0)
    r = [r_world(phi[i], psi[i]) for i in J]
    print(f"  n={n}: Phi(t_n)={[str(x) for x in phi]}, Psi(t_n)={[str(x) for x in psi]}, size={1 + k}, "
          f"r_i={[str(x) for x in r]}, r={rmin(phi, psi, J)}")
print("  at the vertex itself (kappa = 0): rec(B^o, X0) has Phi_2 = 0 < Psi_2: r = 0, defended by world 2")
phi, psi = comb([ZOS], [F(1)])
print("   ", [str(x) for x in phi], [str(x) for x in psi], "r =", rmin(phi, psi, J), " (star) at e_o: weight e_2 is",
      "in W^Phi(B^o), supp e_2 = I^>= = {2}")

print("\n" + "=" * 8, "(B) each C_{p_n} is nevertheless lexicographically competitive (exact grid, 9^4 points)")
for n in [2, 10, 100]:
    g, caps = gens_of(F(0), F(1, n))
    best, arg, lexbad, npts = scan(g, caps, 8, J, F(1, 2))
    print(f"  kappa=1/{n}: points lex-better at all three worlds: {lexbad};  max r at size>=1/2 on grid: {best}")

print("\n" + "=" * 8, "(C) the plateau C_p = B^o near e_o: r = 0 for every record (exact grid)")
g, caps = gens_of(F(0), F(0))
best, arg, lexbad, npts = scan(g, caps, 16, J, F(1, 100))
print(f"  plateau: grid points {npts}, max r = {best}, lex-bad = {lexbad}")

print("\n" + "=" * 8, "(D) a phi_2-optimal model silent on half of Z (sigma = 1/2, kappa = 0)")
g, caps = gens_of(F(1, 2), F(0))
for a in [F(1, 2), F(1, 4), F(1, 16)]:
    best, arg, lexbad, npts = scan(g, caps, 16, J, a)
    print(f"  size >= {a}: grid points {npts}, max r = {best} at {[str(x) for x in arg] if arg else None}, lex-bad = {lexbad}")
