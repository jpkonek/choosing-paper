# KK4 Lemma 2.2 / Theorem 2.1, step 1 (exact check on the atomic surrogate).
# Claim: a pointwise lexicographic minimiser of (w^1.phi, ..., w^r.phi, w'.psi), where SOME w^s is interior and w' is
# interior (w^t for t != s may be boundary weights or arbitrary vectors), is undominated in the lexicographic base L.
# Controls: chains with no interior phi-weight, a boundary psi-weight, or a pure Phi-minimiser with adversarial
# tie-break can be L-dominated.
# Cells carry planted ties: concurrent ties at a fixed interior w0 (S~M and O~S on odd-world cells) and best-ties.
from itertools import product
import random
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

rng = random.Random(20261018)
w0 = [F(1, 3), F(1, 3), F(1, 3)]


def planted_cell(rng, kind):
    """o-odd cell whose leading penalties tie at w0 between two advices that are both w0-minimisers."""
    for _ in range(2000):
        o = rng.choice(W)
        j, l = [i for i in W if i != o]
        cell = {'type': 'mixed', 'odd': o, 'mu': F(rng.randint(1, 9), rng.randint(1, 5))}
        phi = {a: [None] * 3 for a in ADV}
        if kind == 'SM':          # n = phi(S) - phi(M): n_j, n_l >= 0 >= n_o, w0.n = 0
            nj, nl = F(rng.randint(0, 6)), F(rng.randint(0, 6))
            if nj + nl == 0:
                continue
            no = -(w0[j] * nj + w0[l] * nl) / w0[o]
            for i, ni in ((j, nj), (l, nl)):
                phi['M'][i] = F(rng.randint(-3, 3)); phi['S'][i] = phi['M'][i] + ni
                phi['O'][i] = phi['S'][i] + F(rng.randint(3, 12)); phi['X'][i] = phi['O'][i] + F(rng.randint(0, 3))
            phi['M'][o] = F(rng.randint(-3, 3)); phi['S'][o] = phi['M'][o] + no
            phi['O'][o] = phi['S'][o] - F(rng.randint(0, 2)); phi['X'][o] = phi['M'][o] + F(rng.randint(0, 3))
        else:                     # 'OS': n' = phi(S) - phi(O): n'_j, n'_l <= 0 <= n'_o, w0.n' = 0
            nj, nl = -F(rng.randint(0, 6)), -F(rng.randint(0, 6))
            if nj + nl == 0:
                continue
            no = -(w0[j] * nj + w0[l] * nl) / w0[o]
            for i, ni in ((j, nj), (l, nl)):
                phi['O'][i] = F(rng.randint(-3, 3)); phi['S'][i] = phi['O'][i] + ni
                phi['M'][i] = phi['S'][i] - F(rng.randint(0, 2)); phi['X'][i] = phi['O'][i] + F(rng.randint(0, 3))
            phi['O'][o] = F(rng.randint(-3, 3)); phi['S'][o] = phi['O'][o] + no
            phi['M'][o] = phi['S'][o] + F(rng.randint(3, 12)); phi['X'][o] = phi['M'][o] + F(rng.randint(0, 3))
        # weak guidance check
        ok = all(phi[r[k]][i] <= phi[r[k + 1]][i] for i in W for r in [rank(cell, i)] for k in range(3))
        cell['phi'] = phi
        cell['psi'] = gen_levels(cell, rng, 0.0, strict=True)
        mins = lexmin_cell(cell, [w0], None)
        pair = ('S', 'M') if kind == 'SM' else ('S', 'O')
        if ok and set(pair) <= set(mins):
            return cell
    raise RuntimeError('no planted cell')


def best_tie_cell(rng):
    """odd-world best-tie: phi_o(O) = phi_o(S) (strict-best fails at the odd world)."""
    for _ in range(2000):
        cell = random_cell(rng, tie_prob=0)
        if cell['type'] != 'mixed':
            continue
        o = cell['odd']
        cell['phi']['S'][o] = cell['phi']['O'][o]
        ok = all(cell['phi'][r[k]][i] <= cell['phi'][r[k + 1]][i] for i in W for r in [rank(cell, i)] for k in range(3))
        if ok:
            return cell
    raise RuntimeError


def instance(rng):
    cells = [planted_cell(rng, rng.choice(['SM', 'OS'])), best_tie_cell(rng)]
    cells += [random_cell(rng) for _ in range(2)]
    rng.shuffle(cells)
    return cells


def pick(cells, chain, psi_w, adversarial=None):
    model = []
    for c in cells:
        mins = lexmin_cell(c, chain, psi_w)
        if adversarial is not None:      # among minimisers take the WORST for adversarial.psi
            mins = sorted(mins, key=lambda a: dot(adversarial, c['psi'][a]))
            model.append(mins[-1])
        else:
            model.append(mins[0])
    return model


def dominated(cells, B):
    for Y in product(ADV, repeat=len(cells)):
        if L_dominates(cells, list(Y), B):
            return list(Y)
    return None


E = [[F(1), F(0), F(0)], [F(0), F(1), F(0)], [F(0), F(0), F(1)]]
TRIALS = 300
chains = {
    'theorem: (w0 ; w\')': lambda r: ([w0], rand_interior(r), None),
    'theorem: (w0, v ; w\'), v in Z^3': lambda r: ([w0, [F(r.randint(-5, 5)) for _ in W]], rand_interior(r), None),
    'theorem: (e_k, w ; w\')': lambda r: ([E[r.randint(0, 2)], rand_interior(r)], rand_interior(r), None),
    'theorem: (e_k, e_j, w ; w\')': lambda r: ([E[0], E[1], rand_interior(r)], rand_interior(r), None),
    'theorem: (w ; w\'), random interior w': lambda r: ([rand_interior(r)], rand_interior(r), None),
    'remark: (w0 ; e_k), vertex psi-weight (psi_k separates)': lambda r: ([w0], E[r.randint(0, 2)], None),
    'control: w0-minimiser, adversarial psi tie-break': lambda r: ([w0], None, rand_interior(r)),
}
for name, mk in chains.items():
    nd = 0
    example = None
    for t in range(TRIALS):
        cells = instance(rng)
        chain, psi_w, adv = mk(rng)
        B = pick(cells, chain, psi_w, adv)
        Y = dominated(cells, B)
        if Y is not None:
            nd += 1
            if example is None:
                example = (B, Y, totals(cells, B, 'phi'), totals(cells, Y, 'phi'),
                           totals(cells, B, 'psi'), totals(cells, Y, 'psi'))
    print(f"{name:55s}: {TRIALS} instances, L-dominated minimisers: {nd}")
    if example is not None:
        B, Y, PB, PY, QB, QY = example
        print(f"    first example: B={B} Y={Y}\n      Phi(B)={[str(x) for x in PB]} Phi(Y)={[str(x) for x in PY]}"
              f"\n      Psi(B)={[str(x) for x in QB]} Psi(Y)={[str(x) for x in QY]}")


# ---------------------------------------------------------------------------------------------------------
# Explicit control: a chain with NO interior phi-weight, (e_0, e_1 ; u), whose minimiser is L-dominated.
# Two cells with odd world 2.  Cell 1: M ~ S tied at worlds 0 and 1, S cheaper at world 2; psi(S)-psi(M) = (1,1,-1).
# Cell 2: M ~ S tied at all three worlds (fully blind); psi(M)-psi(S) = (-2,-2,10).  At w' = u the chain picks M on
# cell 1 and S on cell 2.  Switching both gives equal Phi_0, Phi_1, smaller Phi_2, and smaller Psi_0, Psi_1.
def mk(phiM, phiS, psiM, psiS):
    big = [F(50)] * 3
    c = {'type': 'mixed', 'odd': 2, 'mu': F(1)}
    c['phi'] = {'M': phiM, 'S': phiS, 'O': [F(20), F(20), F(-20)], 'X': big}
    c['psi'] = {'M': psiM, 'S': psiS, 'O': [F(30), F(30), F(-30)], 'X': [F(60)] * 3}
    # make O worst-but-one at positive worlds and best at the odd world, consistently with the ranks
    return c
c1 = mk([F(0), F(0), F(1)], [F(0), F(0), F(0)], [F(0), F(0), F(1)], [F(1), F(1), F(0)])
c2 = mk([F(0), F(0), F(1)], [F(0), F(0), F(1)], [F(0), F(0), F(2)], [F(2), F(2), F(-8)])
c1['phi']['O'] = [F(5), F(5), F(-1)]; c2['phi']['O'] = [F(5), F(5), F(0)]
c1['psi']['O'] = [F(5), F(5), F(-1)]; c2['psi']['O'] = [F(5), F(5), F(-9)]
cells = [c1, c2]
for c in cells:
    for i in W:
        r = rank(c, i)
        assert all(c['phi'][r[k]][i] <= c['phi'][r[k + 1]][i] for k in range(3)), ('phi', i)
        assert all(c['psi'][r[k]][i] < c['psi'][r[k + 1]][i] for k in range(3)), ('psi', i)
u = [F(1, 3)] * 3
B = pick(cells, [E[0], E[1]], u)
Y = dominated(cells, B)
print("\nexplicit control (e_0, e_1 ; u): minimiser", B, "dominated by", Y)
print("  Phi(B) =", [str(x) for x in totals(cells, B, 'phi')], " Phi(Y) =", [str(x) for x in totals(cells, Y, 'phi')])
print("  Psi(B) =", [str(x) for x in totals(cells, B, 'psi')], " Psi(Y) =", [str(x) for x in totals(cells, Y, 'psi')])
for ch in ([u], [u, E[0]], [E[0], u], [E[0], E[1], u]):
    Bc = pick(cells, ch, u)
    print("  with an interior phi-weight, chain", [[str(x) for x in w] for w in ch], ": minimiser", Bc,
          "dominated:", dominated(cells, Bc) is not None)
