# KK4 Proposition 5.4 (geometry): for every credal set K != {e_o}, the disagreement set of D_K and D_{e_o} contains a
# non-null open cone of o-odd pairs AND a non-null open cone of pairs whose odd world is j != o (o a positive world).
# Exact witnesses with a box certificate: a linear function of g is checked at all 8 corners of a box, so the strict
# inequality holds on the whole box.  K is the convex hull of 1-3 random rational points of the simplex (sometimes
# containing e_o).  Majority orientation of a mixed pair: two positive coordinates, one negative (the odd world).
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from itertools import product
import random

rng = random.Random(7)


def rand_pt():
    a, b = rng.randint(0, 20), rng.randint(0, 20)
    if a + b > 20:
        a, b = 20 - a, 20 - b
    return [F(a, 20), F(b, 20), F(20 - a - b, 20)]


def dot(m, g):
    return sum(x * y for x, y in zip(m, g))


def box_ok(center, rad, conds):
    for eps in product([-1, 1], repeat=3):
        g = [c + e * rad for c, e in zip(center, eps)]
        if not all(f(g) for f in conds):
            return False
    return True


fails, total = 0, 0
for trial in range(3000):
    o = rng.randint(0, 2)
    j, l = [i for i in range(3) if i != o]
    eo = [F(1) if i == o else F(0) for i in range(3)]
    pts = [rand_pt() for _ in range(rng.randint(1, 3))]
    if rng.random() < 0.5:
        pts.append(eo)
    if all(p == eo for p in pts):
        continue
    total += 1
    m = next(p for p in pts if p != eo)           # a vertex of K other than e_o
    jj = j if m[j] > 0 else l                       # a world != o charged by m
    ll = l if jj == j else j
    # (1) o-odd witness: g_jj = 1, g_ll = eta, g_o = -zeta with m.g > 0: D_{e_o} gives O (accept -g), D_K does not
    zeta = m[jj] / (2 * m[o]) if m[o] > 0 else F(1)
    g1 = [None] * 3; g1[jj] = F(1); g1[ll] = F(1, 100); g1[o] = -zeta
    rad1 = min(F(1, 400), zeta / 4, m[jj] / 40)
    ok1 = box_ok(g1, rad1, [lambda g: g[o] < 0 < g[jj], lambda g: g[ll] > 0, lambda g: dot(m, g) > 0])
    # (2) witness with odd world jj (o positive): g_jj = -1, g_ll = eta, g_o = zeta' with m.g < 0:
    #     D_{e_o} accepts g (M), D_K does not (min_K m.g <= m.g < 0)
    zeta2 = m[jj] / (4 * m[o]) if m[o] > 0 else F(1)
    g2 = [None] * 3; g2[jj] = F(-1); g2[ll] = m[jj] / (4 * m[ll]) if m[ll] > 0 else F(1); g2[o] = zeta2
    rad2 = min(F(1, 400), zeta2 / 4, g2[ll] / 4, m[jj] / 40)
    ok2 = box_ok(g2, rad2, [lambda g: g[jj] < 0 < g[o], lambda g: g[ll] > 0, lambda g: dot(m, g) < 0])
    if not (ok1 and ok2):
        fails += 1
        print("FAIL", pts, m, g1, g2)
print(f"credal sets K != {{e_o}} tested: {total};  both open witness boxes certified in all but {fails} cases")

# The facet-adjacency: the witnesses can be taken with |g_o| arbitrarily small relative to the other stakes when
# m_o > 0 is small or m_jj large; record the smallest ratio |g_o|/max(|g_jj|,|g_ll|) used above for a few K.
print("example: K = [e_2, (1/10, 0, 9/10)], o = 2:")
m = [F(1, 10), F(0), F(9, 10)]
print("  o-odd box centre g = (1, 1/100, -1/18):  m.g =", dot(m, [F(1), F(1, 100), F(-1, 18)]), "> 0, e_o.g < 0")
print("  0-odd box centre g = (-1, 1, 1/36):      m.g =", dot(m, [F(-1), F(1), F(1, 36)]), "< 0, e_o.g > 0")
