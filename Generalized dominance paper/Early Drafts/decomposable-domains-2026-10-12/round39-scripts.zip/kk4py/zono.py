# KK4 zonotope surrogate helpers (as in ii2py/segment_examples.py).  A selected model C and disjoint regions R_k,
# each of measure cap_k, each carrying one alternative advice with constant increments g_k = (Phi-incs, Psi-incs)
# per unit mass.  Switching on mass alpha_k in [0, cap_k] gives the record value sum_k alpha_k g_k with size
# sum_k alpha_k (Lyapunov; Lemma 1.1 of II2).  Exact Fractions.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from itertools import product
from common import r_world, rmin, INF


def comb(gens, alphas):
    phi = [sum(a * g[0][i] for a, g in zip(alphas, gens)) for i in range(3)]
    psi = [sum(a * g[1][i] for a, g in zip(alphas, gens)) for i in range(3)]
    return phi, psi


def lexneg(p, q):
    return p < 0 or (p == 0 and q < 0)


def grid(caps, steps):
    axes = [[c * F(t, steps) for t in range(steps + 1)] for c in caps]
    return product(*axes)


def scan(gens, caps, steps, J, amin):
    """max r over grid points of size >= amin; count of lex-negative-at-all-active-worlds points."""
    best, arg, lexbad, npts = F(0), None, 0, 0
    for al in grid(caps, steps):
        size = sum(al)
        if size == 0:
            continue
        phi, psi = comb(gens, al)
        if all(lexneg(phi[i], psi[i]) for i in J):
            lexbad += 1
        if size < amin:
            continue
        npts += 1
        r = rmin(phi, psi, J)
        if r == INF:
            best, arg = INF, al
            break
        if r > best:
            best, arg = r, al
    return best, arg, lexbad, npts
