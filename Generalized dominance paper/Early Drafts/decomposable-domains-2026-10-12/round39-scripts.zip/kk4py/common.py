# KK4 common helpers.  Exact arithmetic (fractions.Fraction) throughout.
#
# Atomic "cell" surrogate of the problem space.  A cell is one pair type carrying a mass mu > 0 and the four
# advices M (accept the majority orientation h), S (silence), O (accept -h), X (both).  Worlds are 0, 1, 2.
# World ranks (better first), write-up background order:
#   mixed cell with odd world o:  at i != o: M, S, O, X;   at i == o: O, S, M, X
#   unanimous cell:               at every world: M, S, O, X
# phi (leading) is weakly guiding: nondecreasing along each world's rank.  psi (lower) is strictly guiding.
from fractions import Fraction as F
import random

ADV = ['M', 'S', 'O', 'X']
W = [0, 1, 2]
INF = 'inf'


def rank(cell, i):
    if cell['type'] == 'mixed' and cell['odd'] == i:
        return ['O', 'S', 'M', 'X']
    return ['M', 'S', 'O', 'X']


def gen_levels(cell, rng, tie_prob, strict):
    """penalty dict adv -> [v0, v1, v2], nondecreasing (strict if strict) along every world's rank."""
    pen = {a: [None, None, None] for a in ADV}
    for i in W:
        v = F(rng.randint(-6, 6), rng.randint(1, 4))
        for a in rank(cell, i):
            pen[a][i] = v
            if strict or rng.random() >= tie_prob:
                v = v + F(rng.randint(1, 9), rng.randint(1, 5))
    return pen


def random_cell(rng, tie_prob=F(1, 3)):
    if rng.random() < 0.15:
        cell = {'type': 'unan', 'odd': None}
    else:
        cell = {'type': 'mixed', 'odd': rng.choice(W)}
    cell['mu'] = F(rng.randint(1, 9), rng.randint(1, 5))
    cell['phi'] = gen_levels(cell, rng, float(tie_prob), strict=False)
    cell['psi'] = gen_levels(cell, rng, 0.0, strict=True)
    return cell


def dot(w, v):
    return sum(a * b for a, b in zip(w, v))


def totals(cells, model, level):
    return [sum(c['mu'] * c[level][model[k]][i] for k, c in enumerate(cells)) for i in W]


def lex_le(a, b):
    return a[0] < b[0] or (a[0] == b[0] and a[1] <= b[1])


def lex_lt(a, b):
    return a[0] < b[0] or (a[0] == b[0] and a[1] < b[1])


def L_dominates(cells, Y, B):
    """Y dominates B in the lexicographic base L = (Phi_i, Psi_i) at every world."""
    PY, QY = totals(cells, Y, 'phi'), totals(cells, Y, 'psi')
    PB, QB = totals(cells, B, 'phi'), totals(cells, B, 'psi')
    allle = all(lex_le((PY[i], QY[i]), (PB[i], QB[i])) for i in W)
    somelt = any(lex_lt((PY[i], QY[i]), (PB[i], QB[i])) for i in W)
    return allle and somelt


def lexmin_cell(cell, phi_chain, psi_w):
    """advices (non-X allowed too) minimising (w1.phi, ..., wr.phi, psi_w.psi) lexicographically."""
    def key(a):
        k = [dot(w, cell['phi'][a]) for w in phi_chain]
        if psi_w is not None:
            k.append(dot(psi_w, cell['psi'][a]))
        return tuple(k)
    best = min(key(a) for a in ADV)
    return [a for a in ADV if key(a) == best]


def rand_interior(rng, den=12):
    while True:
        a, b = rng.randint(1, den - 2), rng.randint(1, den - 2)
        if a + b < den:
            return [F(a, den), F(b, den), F(den - a - b, den)]


def r_world(phi, psi):
    if phi == 0 and psi >= 0:
        return F(0)
    if phi > 0:
        return max(F(0), -psi / phi)
    return INF


def rmin(phi, psi, J):
    vals = [r_world(phi[i], psi[i]) for i in J]
    fin = [v for v in vals if v != INF]
    return INF if not fin else min(fin)
