# KK4 section 6: concurrent leading ties at the interior weight w0 = u (branch R1), on a zonotope surrogate.
# Each region has measure 1 and advices M, S, O (X is strictly worst everywhere and is omitted).  Arrows are given
# as increments OUT OF M (Phi, Psi); O is strictly w0-worse than M in every region.  In a tied region M ~ S at w0.
# The fan member Y(w') = lex-min(w0.phi, w'.psi) picks M or S in each tied region by the sign of w'.(psi(S)-psi(M)).
# Theorem 2.4: every fan member is a selected model, so (RB) requires (star) at its index (II2 Thm 3.1(b)).
# Three parameter sets:
#   P1: d = (1,0,-1), two regions with opposite tie directions; strict unanimity holds for the mixed member.
#   P2: as P1 with another psi on B; (star) fails because W^Phi(Y) misses the face of I^>= (explicit segment).
#   P3: d = (1,1,-2), two regions with the SAME direction; the face of I^>= misses the chord {alpha.d = 0} itself,
#       which is the pairwise criterion of Proposition 6.4 (explicit segment).
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from zono import *
from common import rand_interior
import random

w0 = [F(1, 3)] * 3
J = [0, 1, 2]
dotp = lambda a, b: sum(x * y for x, y in zip(a, b))
negv = lambda v: tuple(-x for x in v)


def member_gens(R, choice):
    alts = {'M': (tuple([F(0)] * 3), tuple([F(0)] * 3))}
    alts.update(R['arrows'])
    base = alts[choice]
    return [(tuple(x - y for x, y in zip(p, base[0])), tuple(x - y for x, y in zip(q, base[1])))
            for a, (p, q) in alts.items() if a != choice]


def W_chord(gens, d, den=60):
    pts = []
    for a0 in range(den + 1):
        for a1 in range(den + 1 - a0):
            al = (F(a0, den), F(a1, den), F(den - a0 - a1, den))
            if dotp(al, d) == 0 and all(dotp(al, g[0]) >= 0 for g in gens):
                pts.append(al)
    return pts


def run(name, d, regions):
    print("=" * 8, name, ": d =", [str(x) for x in d])
    for R in regions:
        for a, (p, q) in R['arrows'].items():
            v = dotp(w0, p)
            assert (v == 0) if (R['tied'] and a == 'S') else (v > 0), (R['name'], a, v)
    tied = [R for R in regions if R['tied']]
    rng = random.Random(1)
    seen = {}
    for _ in range(4000):
        wp = rand_interior(rng, den=60)
        ch = tuple('M' if dotp(wp, R['arrows']['S'][1]) > 0 else 'S' for R in tied)
        seen.setdefault(ch, wp)
    for ch, wp in sorted(seen.items()):
        choice = dict(zip([R['name'] for R in tied], ch))
        gens = []
        for R in regions:
            gens += member_gens(R, choice.get(R['name'], 'M'))
        caps = [F(1)] * len(gens)
        best, arg, lexbad, npts = scan(gens, caps, 3, J, F(1, 4))
        Wc = W_chord(gens, d)
        print(f"  member {ch} realised at w'={[str(x) for x in wp]}: grid records L-better at all worlds: {lexbad}"
              f" (Thm 2.4: 0);  W^Phi(Y) on chord: {len(Wc)} grid points"
              + (f", from {[str(x) for x in Wc[0]]} to {[str(x) for x in Wc[-1]]}" if Wc else ""))
        # Phi-null records: one tied region switched along +d, another along -d, equal masses
        sw = {R['name']: [g for g in member_gens(R, choice[R['name']]) if g[0] in (d, negv(d))][0] for R in tied}
        plus = [k for k, g in sw.items() if g[0] == d]
        minus = [k for k, g in sw.items() if g[0] == negv(d)]
        if not plus or not minus:
            print("     every tied switch points the same way: no Phi-null record on the tie set")
            continue
        for kp in plus:
            for km in minus:
                ps = tuple(x + y for x, y in zip(sw[kp][1], sw[km][1]))
                Ige = [i for i in J if ps[i] >= 0]
                ok = any(all(al[i] == 0 for i in J if i not in Ige) for al in Wc)
                face_meets_chord = any(all(al[i] == 0 for i in J if i not in Ige) and dotp(al, d) == 0
                                       for al in [(F(a, 60), F(b, 60), F(60 - a - b, 60))
                                                  for a in range(61) for b in range(61 - a)])
                print(f"     Phi-null record ({kp} along +d, {km} along -d): Psi={[str(x) for x in ps]}, I^>={Ige};"
                      f" face meets chord: {face_meets_chord}; (star): {ok}")
                if ok:
                    continue
                zp = None
                for al in grid(caps, 4):
                    ph, pq = comb(gens, al)
                    if all(ph[i] < 0 for i in Ige):
                        zp = (ph, pq, al); break
                print(f"       z' with Phi < 0 on I^>=: Phi={[str(x) for x in zp[0]]}; segment z_s=(1-s)z*+s z':")
                zs = ([x + y for x, y in zip(sw[kp][0], sw[km][0])], list(ps))
                for s in [F(1, 10), F(1, 100), F(1, 10**4), F(1, 10**8)]:
                    ph = [(1 - s) * zs[0][i] + s * zp[0][i] for i in J]
                    pq = [(1 - s) * zs[1][i] + s * zp[1][i] for i in J]
                    print(f"         s={s}: size>={(1 - s) * 2}, r={rmin(ph, pq, J)}")


dA = (F(1), F(0), F(-1))
OA = ((F(3), F(3), F(-1)), (F(4), F(4), F(-2)))          # odd world 2: O better at 2, worse at 0, 1
OB = ((F(-1), F(3), F(3)), (F(-2), F(4), F(4)))          # odd world 0
C = {'name': 'C', 'tied': False,
     'arrows': {'O': ((F(2), F(-1), F(2)), (F(2), F(-1), F(2))), 'S': ((F(1), F(-1, 2), F(1)), (F(1), F(-1, 2), F(1)))}}
for name, psiB in [("P1", (F(-1), F(1), F(3))), ("P2", (F(-3), F(1), F(1)))]:
    A = {'name': 'A', 'tied': True, 'arrows': {'S': (dA, (F(2), F(2), F(-1))), 'O': OA}}
    B = {'name': 'B', 'tied': True, 'arrows': {'S': (negv(dA), psiB), 'O': OB}}
    run(name, dA, [A, B, C])

d3 = (F(1), F(1), F(-2))
A1 = {'name': 'A1', 'tied': True, 'arrows': {'S': (d3, (F(4), F(4), F(-3))), 'O': OA}}
A2 = {'name': 'A2', 'tied': True, 'arrows': {'S': (d3, (F(1), F(1), F(-2))), 'O': OA}}
run("P3", d3, [A1, A2])
