"""IW66a: numerical replay of Steps A-D of the infinite-world audit theorem
for a measure of the auditor's form  mu = law(g + t*1),  g ~ nu atomic, t ~ N(0,1)
independent.  Here E = R^3 (three worlds), omega_0 = world 0, E_0 = {g : g_0 = 0},
nu = finitely many weighted atoms g_k in E_0.  mu is concentrated on the lines
g_k + R*1, so it is NOT absolutely continuous w.r.t. Lebesgue: the finite-world
refereed theorem (mu ~ Lebesgue) does not cover it, but the audit theorem
(boundary-null + first moment) does.  Full support is irrelevant to Steps A-D.

On line k a model is a finite union of t-intervals.  For q in the simplex,
q(g_k + t 1) = q.g_k + t, so every D_Q meets line k in the half-line
t > -P_Q(g_k).

Checks per random incoherent rival X (all NUMERICS, double precision):
  A  Q_X = {q : q.g_k + essinf X_k >= 0}; X within hull(X) on every line.
  B  q* = argmin_q F(q), F(q) = max_{Y in G} q.m(Y) - q.m(X) (convex, C^1);
     N_0 = G cap {q*.h > 0};  min_i (m(N_0)-m(X))_i > 0 and ~= F(q*) (saddle).
  C  N_tau = N_0 cap D_{Q_tau}: margin >= v/2, mu(N_tau minus X) > 0.
  D  Q_{X minus N_tau} = Q_X (compare support functions P on 400 directions).
  control: tau = 0 (no shrink): how often Q_{X minus N_0} != Q_X.
Run:  python3 -I lines_check.py > lines_check.out
"""
import numpy as np
from scipy.stats import norm
from scipy.optimize import linprog, minimize

rng = np.random.default_rng(66)
Phi, phi = norm.cdf, norm.pdf
INF = np.inf


def P_of(constraints, g):
    """min q.g over Q = {q in simplex : q.gk + a >= 0 for (gk, a) in constraints}."""
    A = np.array([-gk for gk, a in constraints]) if constraints else None
    b = np.array([a for gk, a in constraints]) if constraints else None
    r = linprog(g, A_ub=A, b_ub=b, A_eq=np.ones((1, 3)), b_eq=[1.0],
                bounds=[(0, 1)] * 3, method="highs")
    assert r.status == 0, r.message
    return r.fun


def mom_interval(gk, a, b):
    """int_a^b (g_k + t 1) phi(t) dt, and the mu-mass of the interval."""
    Fa, Fb = Phi(a), (1.0 if b == INF else Phi(b))
    fa, fb = phi(a), (0.0 if b == INF else phi(b))
    return gk * (Fb - Fa) + (fa - fb) * np.ones(3), Fb - Fa


def model_moment(lines, w, sets):
    m, mass = np.zeros(3), 0.0
    for gk, wk, ivs in zip(lines, w, sets):
        for a, b in ivs:
            mm, ms = mom_interval(gk, a, b)
            m += wk * mm
            mass += wk * ms
    return m, mass


def minus(ivs, thr):
    """part of the interval union below thr (i.e. outside the half-line t > thr)."""
    out = []
    for a, b in ivs:
        if a < thr:
            out.append((a, min(b, thr)))
    return [(a, b) for a, b in out if b > a + 1e-14]


def halfline_minus_set(thr, ivs):
    """(thr, inf) minus the interval union; returns interval list."""
    out, cur = [], thr
    for a, b in sorted(ivs):
        if b <= cur:
            continue
        if a > cur:
            out.append((cur, a))
        cur = max(cur, b)
        if cur == INF:
            break
    if cur < INF:
        out.append((cur, INF))
    return [(a, b) for a, b in out if b > a + 1e-14]


def constraints_of(lines, sets):
    return [(gk, min(a for a, b in ivs)) for gk, ivs in zip(lines, sets) if ivs]


def run_one(trial):
    K = int(rng.integers(3, 9))
    lines = [np.array([0.0, *rng.normal(0, 1.5, 2)]) for _ in range(K)]
    w = rng.random(K); w /= w.sum()
    kp = rng.dirichlet([2, 2, 2])                     # K' = {kp}
    u = [-(kp @ gk) for gk in lines]                  # U on line k: t > u_k
    sets = []
    for k in range(K):
        kind = rng.integers(0, 4)
        lo = u[k] + rng.exponential(0.6)
        if kind == 0:                                 # half-line with a hole
            h1 = lo + rng.exponential(0.5); h2 = h1 + rng.exponential(0.7)
            sets.append([(lo, h1), (h2, INF)])
        elif kind == 1:                               # bounded interval (spike)
            sets.append([(lo, lo + rng.exponential(1.0))])
        elif kind == 2:                               # plain half-line
            sets.append([(lo, INF)])
        else:                                         # empty on this line
            sets.append([])
    cons = constraints_of(lines, sets)
    P = lambda g: P_of(cons, g)
    c = [-P(gk) for gk in lines]                      # G on line k: t > c_k
    # Step A checks
    for k in range(K):
        if sets[k]:
            assert min(a for a, b in sets[k]) >= c[k] - 1e-9
    x, massX = model_moment(lines, w, sets)

    def F_and_grad(q):
        val, grad = -q @ x, -x.copy()
        for gk, wk, ck in zip(lines, w, c):
            L = max(ck, -(q @ gk))
            val += wk * ((q @ gk) * (1 - Phi(L)) + phi(L))
            grad += wk * gk * (1 - Phi(L))
        return val, grad

    best = None
    for s in range(8):
        q0 = rng.dirichlet([1, 1, 1])
        r = minimize(lambda q: F_and_grad(q)[0], q0, jac=lambda q: F_and_grad(q)[1],
                     method="SLSQP", bounds=[(0, 1)] * 3,
                     constraints=[{"type": "eq", "fun": lambda q: q.sum() - 1}],
                     options={"ftol": 1e-13, "maxiter": 500})
        if best is None or r.fun < best.fun:
            best = r
    qs = np.clip(best.x, 0, None); qs /= qs.sum()
    v = F_and_grad(qs)[0]
    if v < 1e-9:
        return None                                    # X (numerically) coherent: skip
    L0 = [max(ck, -(qs @ gk)) for gk, ck in zip(lines, c)]
    N0 = [[(L, INF)] for L in L0]
    mN0, _ = model_moment(lines, w, N0)
    marg0 = np.min(mN0 - x)
    gain0 = model_moment(lines, w, [halfline_minus_set(L, ivs) for L, ivs in zip(L0, sets)])[1]

    def Ptau(g, tau):
        return (1 - tau) * P(g) + tau * g.min()

    tau = 0.5
    while True:
        thr = [max(L, -Ptau(gk, tau)) for L, gk in zip(L0, lines)]
        mN, _ = model_moment(lines, w, [[(t, INF)] for t in thr])
        gain = model_moment(lines, w, [halfline_minus_set(t, ivs) for t, ivs in zip(thr, sets)])[1]
        if np.min(mN - x) >= v / 2 and gain > 0.5 * gain0:
            break
        tau /= 2
        assert tau > 1e-12
    # Step D: hull invariance
    dirs = [rng.normal(size=3) for _ in range(400)] + [np.eye(3)[i] for i in range(3)]
    rem = [minus(ivs, t) for ivs, t in zip(sets, thr)]
    consR = constraints_of(lines, rem)
    dev = max(abs(P_of(consR, d) - P(d)) for d in dirs)
    rem0 = [minus(ivs, t) for ivs, t in zip(sets, L0)]
    cons0 = constraints_of(lines, rem0)
    dev0 = max(abs(P_of(cons0, d) - P(d)) for d in dirs[:60])
    return dict(v=v, marg0=marg0, saddle_gap=abs(marg0 - v), tau=tau,
                margtau=np.min(mN - x), gain=gain, dev=dev, dev0=dev0)


res, skipped = [], 0
for trial in range(300):
    r = run_one(trial)
    if r is None:
        skipped += 1
    else:
        res.append(r)

print(f"rivals tested: {len(res)}  (skipped as numerically coherent: {skipped})")
print(f"Step B  min over rivals of v                 : {min(r['v'] for r in res):.3e}")
print(f"Step B  min over rivals of min_i(m(N0)-m(X))  : {min(r['marg0'] for r in res):.3e}")
print(f"Step B  max saddle gap |min_i(...) - v|       : {max(r['saddle_gap'] for r in res):.3e}")
print(f"Step C  min margin after shrink / v           : {min(r['margtau']/r['v'] for r in res):.3f}")
print(f"Step C  min mu(N_tau minus X)                 : {min(r['gain'] for r in res):.3e}")
print(f"Step C  smallest tau used                     : {min(r['tau'] for r in res):.3e}")
print(f"Step D  max |P_(Q_(X-N_tau)) - P_(Q_X)|       : {max(r['dev'] for r in res):.3e}")
fails0 = sum(r['dev0'] > 1e-7 for r in res)
print(f"control tau=0: rivals with Q_(X-N0) != Q_X    : {fails0} / {len(res)}")
ok = all(r['marg0'] > 0 and r['margtau'] >= r['v'] / 2 - 1e-12 and r['gain'] > 0
         and r['dev'] < 1e-7 for r in res)
print("ALL CHECKS PASS" if ok else "FAILURE")
