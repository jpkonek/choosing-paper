"""IW66a: the contamination target on Omega = [0,1], E = C[0,1], p = Lebesgue.
K = (1-eps){p} + eps S,  P_K(h) = (1-eps) p(h) + eps min h.
(1) boundary gambles h_eta = b_eta - (1-eps) p(b_eta) 1, with b_eta a tent of height 1
    and base width eta, satisfy P_K(h_eta) = 0 and p(h_eta)/||h_eta|| = eps*eta/2/||h||
    -> 0: (LF) holds pointwise (p > 0 on the boundary minus 0) but with NO uniform conic
    margin; the norm distance from h_eta/||h_eta|| to the complement of U tends to 0.
(2) p is not in the algebraic relative interior (core relative to aff K) of K:
    p + t(p - k) leaves K for every t > 0 when k = (1-eps)p + eps*delta_x.
Exact rational arithmetic on the tent functions (closed forms).
Run: python3 -I contamination_check.py > contamination_check.out
"""
from fractions import Fraction as Fr

for eps in [Fr(1, 10), Fr(1, 2), Fr(1)]:
    print(f"eps = {eps}")
    for k in range(1, 7):
        eta = Fr(1, 10 ** k)
        pb = eta / 2                       # integral of a tent of height 1, base eta
        s = (1 - eps) * pb                 # shift putting h on the boundary
        # h = b - s*1 : min h = -s, max h = 1 - s, ||h|| = max(1-s, s) = 1 - s
        minh, norm_h = -s, 1 - s
        p_h = pb - s
        PK = (1 - eps) * p_h + eps * minh
        assert PK == 0 and p_h > 0
        # largest r with ball B(h, r) inside U = {p > 0}: p(h - r 1) = p_h - r, so r = p_h
        print(f"  eta=1e-{k}: P_K(h)={PK}, p(h)={float(p_h):.3e}, "
              f"p(h)/||h|| = {float(p_h / norm_h):.3e}  (= radius of largest ball in U / ||h||)")
# (2) non-core: q_t = p + t(p - k) with k = (1-eps)p + eps delta_x  equals
#     (1 + t*eps) p - t*eps delta_x ; to lie in K it must be (1-eps)p + eps s with s >= 0,
#     s = ((t*eps + eps) p - t*eps delta_x)/eps = (1+t) p - t delta_x, which has
#     mass -t < 0 on {x} because p({x}) = 0.  So no t > 0 works.
print("non-core: s = (1+t)p - t*delta_x has s({x}) = -t < 0 for every t > 0 (p atomless): CHECKED symbolically")
