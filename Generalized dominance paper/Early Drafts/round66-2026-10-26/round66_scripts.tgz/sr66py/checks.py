"""SR66 exact checks of the simple safe-improvement ranking (two worlds, cone models).

Run:  python3 -I checks.py > checks.out
All arithmetic is exact (fractions).  mu has density exp(-|h|_1); no atoms.
"""
import os
import sys
import random
from fractions import Fraction as F
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cone2d import (Domain, norm, inter, union, diff, meas, null, subset_ae, eq_ae,
                    moment, rec, inv, is_null_rec, d, guided, acc, leq, strict,
                    rand_set, POS, NEG)

rng = random.Random(66)
fails = []


def check(name, cond):
    if not cond:
        fails.append(name)
    return cond


print("SR66 checks: two worlds, density exp(-|h|_1), cone models, exact arithmetic")
print("sanity: m(int R^2_+) =", moment(norm([(0, 1)])), " mu(int R^2_+) =", meas(norm([(0, 1)])))
assert moment(norm([(0, 1)])) == (1, 1)

DOMS = [Domain(F(1, 3), F(2, 3)), Domain(F(1, 5), F(4, 5)), Domain(F(1, 2), F(1, 2)),
        Domain(0, F(1, 2))]  # last: K' meets the boundary of Delta (k1 = 0)

# ---------------------------------------------------------------- C1
print("\n[C1] safe (definition, brute force over coherent models) <=> mu(A cap hull B) > 0")
n_rec = 0
special = {"B null": 0, "Q_B = Delta (B in R^2_+), B non-null": 0, "A null": 0, "both null": 0}
for dom in DOMS:
    lo, hi = dom.L0, dom.R0
    for _ in range(1500):
        A = rand_set(rng, lo, hi)
        B = diff(rand_set(rng, lo, hi), A)
        mode = rng.random()
        if mode < 0.1:
            B = ()
        elif mode < 0.2:
            B = diff(rand_set(rng, 0, 1), A)
        elif mode < 0.3:
            A = ()
        elif mode < 0.33:
            A, B = (), ()
        r = (A, B)
        s1, s2 = dom.safe_attack(r), dom.safe_hull(r)
        check("C1 equivalence", s1 == s2)
        if null(B) and null(A):
            special["both null"] += 1
            check("C1 null record unsafe", not s1)
        elif null(B):
            special["B null"] += 1
            check("C1 B null: safe iff A meets int R^2_+",
                  s1 == (meas(inter(A, norm([(0, 1)]))) > 0))
        elif null(A):
            special["A null"] += 1
            check("C1 A null: unsafe", not s1)
        elif subset_ae(B, norm([(0, 1)])):
            special["Q_B = Delta (B in R^2_+), B non-null"] += 1
            check("C1 Q_B=Delta: hull = int R^2_+", eq_ae(dom.hull(B), norm([(0, 1)])))
        n_rec += 1
print("  records tested:", n_rec, " special cases:", special)

# ---------------------------------------------------------------- C2
print("\n[C2] non-null guided records have d_i > 0 (and their inverses are refused)")
cnt = 0
for dom in DOMS:
    for i in (1, 2):
        for _ in range(500):
            A = inter(rand_set(rng, dom.L0, dom.R0), POS[i])
            B = inter(diff(rand_set(rng, dom.L0, dom.R0), A), NEG[i])
            r = (A, B)
            if is_null_rec(r):
                continue
            check("C2 guided", guided(i, r))
            check("C2 d>0", d(i, r) > 0)
            check("C2 accepted", acc(dom, i, r))
            check("C2 inverse refused", not acc(dom, i, inv(r)))
            cnt += 1
print("  non-null guided records tested:", cnt)

# ---------------------------------------------------------------- C3
print("\n[C3] (Add): accepted disjoint records have accepted union; targeted mixed case")
tot = mixed = 0
for dom in DOMS:
    for _ in range(4000):
        A1 = rand_set(rng, dom.L0, dom.R0)
        B1 = diff(rand_set(rng, dom.L0, dom.R0), A1)
        S1 = union(A1, B1)
        A2 = diff(rand_set(rng, dom.L0, dom.R0), S1)
        B2 = diff(diff(rand_set(rng, dom.L0, dom.R0), S1), A2)
        if rng.random() < 0.5:  # force a guided component at some world
            i0 = rng.choice((1, 2))
            A1, B1 = inter(A1, POS[i0]), inter(B1, NEG[i0])
        r1, r2 = (A1, B1), (A2, B2)
        ru = (union(A1, A2), union(B1, B2))
        for i in (1, 2):
            a1, a2 = acc(dom, i, r1), acc(dom, i, r2)
            if a1 and a2:
                tot += 1
                check("C3 Add", acc(dom, i, ru))
                g1, g2 = guided(i, r1), guided(i, r2)
                s1, s2 = dom.safe_hull(r1), dom.safe_hull(r2)
                if (g1 and not s1 and s2 and not g2) or (g2 and not s2 and s1 and not g1):
                    mixed += 1
                    check("C3 mixed union safe", dom.safe_hull(ru))
                    check("C3 mixed union d>0", d(i, ru) > 0)
        # model-level (Add): X <= Y <= Z with disjoint changes
        Z = diff(rand_set(rng, dom.L0, dom.R0), union(A2, A1))
        Z = union(Z, union(B1, B2))
        Y = union(diff(Z, B2), A2)
        X = union(diff(Y, B1), A1)
        check("C3 rec composition", rec(X, Z) == ru and rec(Y, Z) == r2 and rec(X, Y) == r1)
print("  accepted disjoint pairs:", tot, " of which mixed guidance/safe:", mixed)

# ---------------------------------------------------------------- C4
print("\n[C4] (TC)/(FCC): accepted non-null records strictly raise m_i; no non-trivial ties")
cnt = 0
for dom in DOMS:
    for _ in range(1500):
        Xs = [rand_set(rng, dom.L0, dom.R0) for _ in range(4)]
        for i in (1, 2):
            for X in Xs:
                for Y in Xs:
                    if leq(dom, i, X, Y):
                        cnt += 1
                        if eq_ae(X, Y):
                            continue
                        check("C4 strict increase", moment(X)[i - 1] > moment(Y)[i - 1])
                        check("C4 no tie", not leq(dom, i, Y, X))
print("  accepted comparisons examined:", cnt)

# ---------------------------------------------------------------- C5
print("\n[C5] protection: no Y != C weakly dominates a coherent C")
cnt = targ = 0
for dom in DOMS:
    for _ in range(800):
        L = F(rng.randint(int(dom.L0 * 60), 0), 60)
        R = F(rng.randint(60, int(dom.R0 * 60)), 60)
        C = dom.coherent_model(L, R)
        mode = rng.random()
        if mode < 0.5:
            Y = rand_set(rng, dom.L0, dom.R0)
        else:  # C plus/minus a change guided at one world (the hard case)
            i0 = rng.choice((1, 2))
            add = inter(diff(rand_set(rng, dom.L0, dom.R0), C), POS[i0])
            rem = inter(inter(rand_set(rng, dom.L0, dom.R0), C), NEG[i0])
            Y = union(diff(C, rem), add)
            targ += 1
        if eq_ae(Y, C):
            continue
        cnt += 1
        r = rec(Y, C)
        check("C5 change out of coherent model is unsafe", not dom.safe_attack(r))
        check("C5 no weak dominance", not (leq(dom, 1, Y, C) and leq(dom, 2, Y, C)))
print("  pairs (C, Y):", cnt, " of which C (+) guided change:", targ)

# ---------------------------------------------------------------- C6
print("\n[C6] Theorem H chain on random incoherent X: coherent N, strict margin,")
print("     hull(X\\N) = hull(X), N subset hull(X\\N), safe record, N strictly dominates X")


def defender(dom, X):
    G = dom.hull(X)
    L, R = G[0]
    a, b = -L, 2 - R          # Q_X = [a,b]
    mX = moment(X)
    best = None
    for k in range(0, 241):
        p = F(k, 240)
        N0 = inter(G, norm([(-p, 2 - p)]))
        dm = (moment(N0)[0] - mX[0], moment(N0)[1] - mX[1])
        v = min(dm)
        if best is None or v > best[0]:
            best = (v, p, N0)
    v, p, N0 = best
    if v <= 0:
        return None
    for tau in [F(1, 2), F(1, 4), F(1, 10), F(1, 100), F(1, 1000), F(1, 10**5)]:
        Dt = norm([(-(1 - tau) * a, 2 - (1 - tau) * b - tau)])
        N = inter(N0, Dt)
        dm = (moment(N)[0] - mX[0], moment(N)[1] - mX[1])
        if min(dm) > 0 and meas(diff(N, X)) > 0:
            return (p, tau, N0, N, v)
    return None


cnt = 0
taus = {}
for dom in DOMS:
    tries = 0
    while tries < 300:
        X = rand_set(rng, dom.L0, dom.R0, kmax=5)
        if dom.is_coherent(X):
            continue
        tries += 1
        res = defender(dom, X)
        check("C6 defender found", res is not None)
        if res is None:
            print("   no defender found for", X)
            continue
        p, tau, N0, N, v = res
        taus[tau] = taus.get(tau, 0) + 1
        check("C6 N coherent", dom.is_coherent(N))
        check("C6 hull invariance", eq_ae(dom.hull(diff(X, N)), dom.hull(X)))
        check("C6 N in hull(X\\N)", subset_ae(N, dom.hull(diff(X, N))))
        r = rec(N, X)
        check("C6 safe (definition)", dom.safe_attack(r))
        check("C6 strict dominance", strict(dom, 1, N, X) and strict(dom, 2, N, X))
        # control: Lemma S invariance for arbitrary tau and the unshrunk N0
        for t2 in [F(1, 3), F(9, 10)]:
            L, R = dom.hull(X)[0]
            a, b = -L, 2 - R
            Dt = norm([(-(1 - t2) * a, 2 - (1 - t2) * b - t2)])
            Nt = inter(rand_set(rng, dom.L0, dom.R0), Dt)
            check("C6 Cor shrink", eq_ae(dom.hull(diff(X, Nt)), dom.hull(X)))
        cnt += 1
print("  incoherent rivals certified:", cnt, " shrink parameters used:",
      {str(k): v for k, v in sorted(taus.items(), reverse=True)})

# ---------------------------------------------------------------- C7
print("\n[C7] (Tr) is not claimed and fails: exact instance at world 1, K' = {1/2}")
dom = Domain(F(1, 2), F(1, 2))  # U = (-1/2, 3/2)
c = norm([(F(-3, 10), F(-2, 10))])
a2 = norm([(F(-45, 100), F(-40, 100))])
a1 = norm([(F(10, 100), F(11, 100))])
b1 = norm([(F(13, 10), F(14, 10))])
b2 = norm([(F(50, 100), F(51, 100))])
X, Y, Z = c, union(a1, a2), union(b1, b2)
print("  X =", X, " Y =", Y, " Z =", Z)
print("  m_1(X), m_1(Y), m_1(Z) =", moment(X)[0], moment(Y)[0], moment(Z)[0])
print("  hull(Z\\X) =", dom.hull(diff(Z, X)), " hull(Y\\X) =", dom.hull(diff(Y, X)))
check("C7 X<=_1 Y", leq(dom, 1, X, Y))
check("C7 Y<=_1 Z", leq(dom, 1, Y, Z))
check("C7 not X<=_1 Z", not leq(dom, 1, X, Z))
check("C7 not Z<=_1 X", not leq(dom, 1, Z, X))
check("C7 r(X,Z) unsafe, not guided", (not dom.safe_attack(rec(X, Z))) and not guided(1, rec(X, Z)))
check("C7 changes not disjoint (no (Add) instance)",
      meas(inter(union(diff(X, Y), diff(Y, X)), union(diff(Y, Z), diff(Z, Y)))) > 0)
print("  X <=_1 Y:", leq(dom, 1, X, Y), " Y <=_1 Z:", leq(dom, 1, Y, Z),
      " X <=_1 Z:", leq(dom, 1, X, Z), " Z <=_1 X:", leq(dom, 1, Z, X),
      " -> X, Z incomparable at world 1")

# ---------------------------------------------------------------- C8
print("\n[C8] lower-dimensional evaluable coherent model: K' = {1/2}, U = D_{K'} = D_K, K = {1/2}")
dom = Domain(F(1, 2), F(1, 2))
C = dom.U
cnt = 0
for _ in range(3000):
    if rng.random() < 0.5:
        Y = rand_set(rng, dom.L0, dom.R0)
    else:
        i0 = rng.choice((1, 2))
        rem = inter(rand_set(rng, dom.L0, dom.R0), NEG[i0])
        Y = diff(C, rem)
    if eq_ae(Y, C):
        continue
    cnt += 1
    check("C8 lower-dim D_K not weakly dominated", not (leq(dom, 1, Y, C) and leq(dom, 2, Y, C)))
# (LF) failure: boundary rays t = -1/2 and t = 3/2 lie outside the open U.
eps = F(1, 1000)
check("C8 (LF) fails: every neighbourhood of a boundary ray leaves U",
      meas(diff(norm([(F(-1, 2) - eps, F(-1, 2) + eps)]), dom.U)) > 0)
print("  rivals Y tested:", cnt, "; D_K undominated; (LF) fails at the boundary rays")

print("\nFAILURES:", sorted(set(fails)) if fails else "none")
print("ALL PASS" if not fails else "SOME CHECKS FAILED")
