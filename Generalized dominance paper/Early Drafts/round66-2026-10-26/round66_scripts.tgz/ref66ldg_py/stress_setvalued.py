# REF66_ldg: randomized exact checks of the set-valued instance and Lemma 3.16 of LDG v3.3.
# Atoms with weights in {0,1,2}; weight-0 atoms are null, so models are identified modulo them.
# Checks: characterisation of "applies"; record composition on T and (TS); (GI),(RS),(TG) for integral
# scores with sign guidance; Lemma 3.16(a) when least coherent supersets exist; Lemma 3.16(b);
# record-based <=> (IB) of W62 for the safe-improvement ranking; and the full theorem when GP, SI hold.
import random
from itertools import product

random.seed(6606)
stats = dict(inst=0, hulls=0, lemb=0, full=0)

def run():
    n = random.randint(2, 4)
    nw = random.randint(1, 3)
    wt = [random.choice([0, 1, 1, 2]) for _ in range(n)]
    POS = sum(1 << i for i in range(n) if wt[i] > 0)
    FULLm = (1 << n) - 1
    canon = lambda x: x & POS                       # representative mod null sets
    M = sorted({canon(x) for x in range(1 << n)})   # models = classes
    hv = {(w, i): random.randint(-2, 2) for w in range(nw) for i in range(n)}
    mu = lambda x: sum(wt[i] for i in range(n) if x >> i & 1)
    phi = lambda w, x: sum(wt[i] * hv[w, i] for i in range(n) if x >> i & 1)
    rec = lambda x, y: (canon(x & ~y), canon(y & ~x))
    # coherent class: either intersection-closed (with U) or arbitrary
    if random.random() < 0.6:
        gens = [canon(random.randrange(1 << n)) for _ in range(random.randint(0, 3))]
        C = {POS}
        changed = True
        C |= set(gens)
        while changed:
            changed = False
            for a, b in product(list(C), list(C)):
                if (a & b) not in C:
                    C.add(a & b); changed = True
        C = sorted(C)
    else:
        C = sorted({x for x in M if random.random() < 0.4})
    stats['inst'] += 1
    def applies_def(r, z):
        return any(rec(zp, z) == r for zp in M)
    def applies_char(r, z):
        a, b = r
        return (b & ~z) == 0 and mu(a & z) == 0
    RECS = {rec(x, y) for x in M for y in M}
    for r in RECS:
        for z in M:
            assert applies_def(r, z) == applies_char(r, z)
    safe = {r: not any(applies_def(r, z) for z in C) for r in RECS}
    G = {w: {r for r in RECS if all(hv[w, i] > 0 for i in range(n) if r[0] >> i & 1)
             and all(hv[w, i] < 0 for i in range(n) if r[1] >> i & 1)} for w in range(nw)}
    for w in range(nw):
        assert (0, 0) in G[w]
        for x, y in product(M, M):
            r = rec(x, y)
            d = phi(w, x) - phi(w, y)
            assert d == sum(wt[i] * hv[w, i] for i in range(n) if r[0] >> i & 1) - \
                       sum(wt[i] * hv[w, i] for i in range(n) if r[1] >> i & 1)       # (RS)
            if x != y and r in G[w]:
                assert d > 0                                                     # (GI)
    # T, composition, TS, TG
    for x, y, z in product(M, M, M):
        if mu((x ^ y) & (y ^ z)) == 0:
            r1, r2, r = rec(x, y), rec(y, z), rec(x, z)
            assert r == (r1[0] | r2[0], r1[1] | r2[1])
            if safe[r1] or safe[r2]:
                assert safe[r]
            for w in range(nw):
                if r1 in G[w] and r2 in G[w]:
                    assert r in G[w]
    # Lemma 3.16(a)
    def least_sup(b):
        cands = [z for z in C if (b & ~z) == 0]
        least = [z for z in cands if all((z & ~y) == 0 for y in cands)]
        return least[0] if least else None
    hulls = all(least_sup(b) is not None for b in M)
    if hulls:
        stats['hulls'] += 1
        for r in RECS:
            assert safe[r] == (mu(r[0] & least_sup(r[1])) > 0)
    # Lemma 3.16(b)
    sg = canon(sum(1 << i for i in range(n) if all(hv[w, i] > 0 for w in range(nw))))
    sl = canon(sum(1 << i for i in range(n) if all(hv[w, i] < 0 for w in range(nw))))
    GP = all(m == c for c in C for m in M if all(rec(m, c) in G[w] for w in range(nw)))
    if all((sg & ~c) == 0 for c in C) and mu(sl) == 0:
        stats['lemb'] += 1
        assert GP
    # ranking, (IB) <=> record-based, and full theorem if GP and SI
    def le(w, x, y):
        r = rec(x, y)
        return r in G[w] or (safe[r] and phi(w, x) > phi(w, y))
    for w in (range(nw) if len(M) <= 8 else []):
        for x, y, xp, yp in product(M, M, M, M):
            # W62 (IB) with S = (x^y)|(xp^yp)
            S = (x ^ y) | (xp ^ yp)
            if canon(x & ~S) == canon(y & ~S) and canon(xp & ~S) == canon(yp & ~S) and \
               canon(x & S) == canon(xp & S) and canon(y & S) == canon(yp & S):
                assert le(w, x, y) == le(w, xp, yp)
    Cn = [c for c in C if c in M]
    SI = all(any(safe[rec(c, m)] and all(phi(w, c) > phi(w, m) for w in range(nw)) for c in Cn)
             for m in M if m not in Cn)
    if GP and SI:
        stats['full'] += 1
        def wdom(a, b): return all(le(w, a, b) for w in range(nw))
        def dom(a, b): return wdom(a, b) and not wdom(b, a)
        Ul = [x for x in M if not any(dom(y, x) for y in M)]
        assert sorted(Ul) == sorted(Cn) and Cn
    return True

for _ in range(1500):
    run()
print(stats)
print('ALL PASS')

# Countability in Lemma 3.16(b) cannot be dropped (argument, not computation):
# H=U=[0,1] with Lebesgue measure, Omega=[0,1], h_w = 1 off {w}, -1 at w, coherent class {emptyset}.
# Then the intersection of {h_w>0} over w is empty and the intersection of {h_w<0} is empty, so the
# hypotheses of 3.16(b) hold except countability; but r(U, emptyset) = (U, emptyset) is guided at every
# world (U is a.e. inside {h_w>0}), and U != emptyset, so (GP) fails.
