# REF66_ldg: randomized exact stress test of Theorem 3.13 and Remarks 3.14-3.15 (abstract setting).
# Random finite model sets, random record maps (coarse: random labels with r(m,m')=0 iff m=m'),
# random coherent classes, guided sets containing 0, integer scores. GI is enforced by rejection.
import random
from itertools import product

random.seed(6602)
STATS = dict(inst=0, GP=0, SI=0, RS=0, TGTS=0)

def run(n, nworld, nlab, finest=False):
    M = list(range(n))
    W = list(range(nworld))
    # record map
    r = {}
    for x, y in product(M, M):
        if x == y:
            r[x, y] = 0
        else:
            r[x, y] = ('f', x, y) if finest else random.randint(1, nlab)
    C = [x for x in M if random.random() < 0.5]
    REC = set(r.values())
    G = {w: {0} | {rho for rho in REC if rho != 0 and random.random() < 0.3} for w in W}
    phi = {(w, x): random.randint(-3, 3) for w in W for x in M}
    # enforce GI
    for w in W:
        for x, y in product(M, M):
            if x != y and r[x, y] in G[w] and not phi[w, x] > phi[w, y]:
                return None
    def applies(rho, z):
        return any(r[zp, z] == rho for zp in M)
    safe = {rho: not any(applies(rho, z) for z in C) for rho in REC}
    def le(w, x, y):
        rho = r[x, y]
        return rho in G[w] or (safe[rho] and phi[w, x] > phi[w, y])
    def lt(w, x, y):
        return le(w, x, y) and not le(w, y, x)
    def wdom(a, b):
        return all(le(w, a, b) for w in W)
    def dom(a, b):
        return wdom(a, b) and not wdom(b, a)
    def sdom(a, b):
        return all(lt(w, a, b) for w in W)
    GP = all(m == c for c in C for m in M if all(r[m, c] in G[w] for w in W))
    SIc = {m: [c for c in C if (safe[r[c, m]] and all(phi[w, c] > phi[w, m] for w in W))
               or all(r[c, m] in G[w] for w in W)]
           for m in M if m not in C}
    SI = all(SIc[m] for m in SIc)
    STATS['inst'] += 1
    # (a)
    for w in W:
        assert all(le(w, x, x) for x in M)
        for x, y in product(M, M):
            if x != y:
                assert not (le(w, x, y) and le(w, y, x))
                if r[x, y] in G[w]:
                    assert lt(w, x, y)
        # acyclicity via score: accepted distinct steps strictly raise phi
        for x, y in product(M, M):
            if x != y and le(w, x, y):
                assert phi[w, x] > phi[w, y]
        for x, y, z in product(M, M, M):
            if le(w, x, y) and le(w, y, z):
                assert not lt(w, z, x)
    # (b) and Remark 3.14 part 1: GP <=> (b)
    b_holds = all(m == c for c in C for m in M if wdom(m, c))
    assert b_holds == GP
    if GP:
        STATS['GP'] += 1
        Ul = [x for x in M if not any(dom(y, x) for y in M)]
        assert all(c in Ul for c in C)
    # (c)
    for m, cs in SIc.items():
        for c in cs:
            assert sdom(c, m)
    # Remark 3.14 (revision 2): (i) SI <=> (ii) dominance <=> (iii) weak dominance; strictness
    SI_all = all(SIc[m] for m in SIc)
    ii = all(any(dom(c, m) for c in C) for m in SIc)
    iii = all(any(wdom(c, m) for c in C) for m in SIc)
    assert SI_all == ii == iii
    for m in SIc:
        for c in C:
            if wdom(c, m):
                assert sdom(c, m)
    # given GP: SI <=> (W)
    if GP:
        Ul = [x for x in M if not any(dom(y, x) for y in M)]
        CL = [c for c in C if c in Ul]
        Wh = all(any(wdom(c, m) for c in CL) for m in M)
        assert Wh == SI_all
    # (d)
    if GP and SI:
        STATS['SI'] += 1
        Ul = [x for x in M if not any(dom(y, x) for y in M)]
        CL = [c for c in C if c in Ul]
        assert sorted(Ul) == sorted(CL) == sorted(C) and CL
        assert all(any(wdom(c, m) for c in CL) for m in M)              # (W)
        assert all(m in CL for m in M for c in CL if wdom(m, c) and wdom(c, m))  # (C)
        for m in M:
            if m not in C:
                assert any(sdom(c, m) for c in CL)
    # (e) under RS
    for w in W:
        RS = True
        cmp = {}
        for x, y in product(M, M):
            v = phi[w, x] > phi[w, y]
            if cmp.setdefault(r[x, y], v) != v:
                RS = False
        if RS:
            STATS['RS'] += 1
            acc = {}
            for x, y in product(M, M):
                v = le(w, x, y)
                assert acc.setdefault(r[x, y], v) == v
    # (f): random T; check whenever TG at w and TS hold on T
    T = [t for t in product(M, M, M) if random.random() < 0.3]
    TS = all(safe[r[x, z]] for (x, y, z) in T if safe[r[x, y]] or safe[r[y, z]])
    for w in W:
        TG = all(r[x, z] in G[w] for (x, y, z) in T if r[x, y] in G[w] and r[y, z] in G[w])
        if TG and TS:
            STATS['TGTS'] += 1
            for (x, y, z) in T:
                if le(w, x, y) and le(w, y, z):
                    assert le(w, x, z)
    # Remark 3.15 (finest records): safety of r(m,m') <=> m' incoherent
    if finest:
        for x, y in product(M, M):
            if x != y:
                assert safe[r[x, y]] == (y not in C)
    return True

done = 0
tries = 0
while done < 4000:
    tries += 1
    n = random.randint(2, 6)
    res = run(n, random.randint(1, 3), random.randint(1, 8), finest=(tries % 5 == 0))
    if res:
        done += 1
print('instances', STATS['inst'], 'with GP', STATS['GP'], 'with GP and SI', STATS['SI'],
      'worlds with RS', STATS['RS'], 'worlds with TG and TS on random T', STATS['TGTS'])
print('ALL PASS')
