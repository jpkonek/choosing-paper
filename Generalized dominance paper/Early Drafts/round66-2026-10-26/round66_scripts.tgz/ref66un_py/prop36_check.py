"""REF66_un: exact instance checks (two worlds, cone models, density exp(-|h|_1)).

  P36  Proposition 3.6: (i) weak dominance by Y != X  <=>  (ii) dominance  <=>
       (iii) strict dominance  <=>  (iv) r(Y,X) safe and m(Y)-m(X) >> 0.
       Safety is tested from the DEFINITION (brute force over coherent models), not by
       the hull test; acceptance uses that definitional test.
  C37  Corollary 3.7: no coherent model has a weak dominator other than itself.
  LEX  Section 7.3: lexicographic variant (score (m_i, m_1+m_2)): analogue of Prop 3.6
       with (iv') r safe, m(Y) >= m(X), m(Y) != m(X); (Add); no nontrivial ties.
  RF   Section 6 closing paragraph (record-free construction):
       RF0: X <= Y iff X = Y or (Y incoherent and m_i(X) > m_i(Y))   -> transitive
            (so (Add) HOLDS), but (G) and (IB) fail;
       RF1: add "or r(X,Y) guided at i"  -> (IB) and (Add) fail.

cone2d.py is a verbatim copy of sr66py/cone2d.py (exact interval-set library).
Run: python3 -I prop36_check.py
"""
import os
import sys
import random
from fractions import Fraction as F
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cone2d import (Domain, norm, inter, union, diff, meas, null, subset_ae, eq_ae,
                    moment, rec, is_null_rec, d, guided, rand_set)

rng = random.Random(6606)
fails = []
counts = {}


def check(name, cond):
    counts[name] = counts.get(name, 0) + 1
    if not cond:
        fails.append(name)
    return cond


DOMS = [Domain(F(1, 3), F(2, 3)), Domain(F(1, 5), F(4, 5)), Domain(F(1, 2), F(1, 2)),
        Domain(0, F(1, 2))]
W = (1, 2)


def acc(dom, i, r):            # safe-improvement ranking, definitional safety
    return guided(i, r) or (dom.safe_attack(r) and d(i, r) > 0)


def acc_lex(dom, i, r):
    if guided(i, r):
        return True
    if not dom.safe_attack(r):
        return False
    s = (d(i, r), d(1, r) + d(2, r))
    return s > (0, 0)


def leq(A, dom, i, X, Y):
    return A(dom, i, rec(X, Y))


def strict(A, dom, i, X, Y):
    return leq(A, dom, i, X, Y) and not leq(A, dom, i, Y, X)


def defender(dom, X):
    """Theorem 4.3 construction in the cone model (grid search for lambda*, then shrink)."""
    G = dom.hull(X)
    L, R = G[0]
    a, b = -L, 2 - R
    mX = moment(X)
    best = None
    for k in range(0, 121):
        p = F(k, 120)
        N0 = inter(G, norm([(-p, 2 - p)]))
        dm = (moment(N0)[0] - mX[0], moment(N0)[1] - mX[1])
        if best is None or min(dm) > best[0]:
            best = (min(dm), N0)
    v, N0 = best
    if v <= 0:
        return None
    for tau in [F(1, 4), F(1, 20), F(1, 1000), F(1, 10**6)]:
        Dt = norm([(-(1 - tau) * a, 2 - (1 - tau) * b - tau)])
        N = inter(N0, Dt)
        dm = (moment(N)[0] - mX[0], moment(N)[1] - mX[1])
        if min(dm) > 0 and meas(diff(N, X)) > 0:
            return N
    return None


def pairs(dom, k):
    """Random pairs plus structured ones likely to give dominance."""
    out = []
    for _ in range(k):
        X = rand_set(rng, dom.L0, dom.R0, kmax=4)
        mode = rng.random()
        if mode < 0.35:
            Y = rand_set(rng, dom.L0, dom.R0, kmax=4)
        elif mode < 0.6:
            N = defender(dom, X) if not dom.is_coherent(X) else None
            Y = N if N is not None else rand_set(rng, dom.L0, dom.R0)
        elif mode < 0.8:   # small perturbation of X
            E = rand_set(rng, dom.L0, dom.R0, kmax=2, den=240)
            Y = union(diff(X, E), inter(E, rand_set(rng, dom.L0, dom.R0, kmax=2, den=240)))
        else:              # Y coherent
            L = F(rng.randint(int(dom.L0 * 60), 0), 60)
            Rr = F(rng.randint(60, int(dom.R0 * 60)), 60)
            Y = dom.coherent_model(L, Rr)
        out.append((X, Y))
    return out


# ------------------------------------------------------------------ P36 and LEX
pos = {"P36 (iv) true": 0, "LEX (iv') true": 0, "LEX dominance with some m_i = 0": 0}
npairs = 0
for dom in DOMS:
    for X, Y in pairs(dom, 350):
        npairs += 1
        neq = not eq_ae(X, Y)
        r = rec(Y, X)
        dm = (moment(Y)[0] - moment(X)[0], moment(Y)[1] - moment(X)[1])
        safe = dom.safe_attack(r)
        for A, tag in ((acc, "P36"), (acc_lex, "LEX")):
            wd = all(leq(A, dom, i, Y, X) for i in W)
            st = [strict(A, dom, i, Y, X) for i in W]
            i_ = wd and neq
            ii = wd and any(st)
            iii = all(st)
            if tag == "P36":
                iv = safe and min(dm) > 0
            else:
                iv = safe and min(dm) >= 0 and dm != (0, 0)
            check(f"{tag} (i)<=>(ii)", i_ == ii)
            check(f"{tag} (ii)<=>(iii)", ii == iii)
            check(f"{tag} (iii)<=>(iv)", iii == iv)
            if iv:
                pos["P36 (iv) true" if tag == "P36" else "LEX (iv') true"] += 1
                if tag == "LEX" and min(dm) == 0:
                    pos["LEX dominance with some m_i = 0"] += 1
            # no nontrivial ties at any world
            for i in W:
                tie = leq(A, dom, i, X, Y) and leq(A, dom, i, Y, X)
                check(f"{tag} no nontrivial ties", (not tie) or not neq)
print("pairs:", npairs, " positives:", pos)

# Weak-only lexicographic dominance: construct an instance with m_1(r) = 0 < m_2(r)
# (show that the LEX remark's modified (iv) is genuinely weaker than strict margin)

# ------------------------------------------------------------------ C37
nc = 0
for dom in DOMS:
    for _ in range(250):
        L = F(rng.randint(int(dom.L0 * 60), 0), 60)
        Rr = F(rng.randint(60, int(dom.R0 * 60)), 60)
        C = dom.coherent_model(L, Rr)
        mode = rng.random()
        if mode < 0.5:
            Y = rand_set(rng, dom.L0, dom.R0)
        else:   # C modified by a change guided at one world
            i = rng.choice(W)
            from cone2d import POS, NEG
            Y = union(diff(C, inter(rand_set(rng, dom.L0, dom.R0), NEG[i])),
                      inter(rand_set(rng, dom.L0, dom.R0), POS[i]))
            Y = inter(Y, dom.U)
        for A, tag in ((acc, "C37"), (acc_lex, "C37-LEX")):
            wd = all(leq(A, dom, i, Y, C) for i in W)
            check(f"{tag} protection", (not wd) or eq_ae(Y, C))
        nc += 1
print("protection pairs:", nc)

# ------------------------------------------------------------------ LEX (Add), FCC
nadd = 0
for dom in DOMS:
    for _ in range(300):
        Y = rand_set(rng, dom.L0, dom.R0, kmax=4)
        S1 = rand_set(rng, dom.L0, dom.R0, kmax=2)
        S2 = diff(rand_set(rng, dom.L0, dom.R0, kmax=2), S1)
        # X differs from Y only on S1, Z differs from Y only on S2
        X = union(diff(Y, S1), inter(S1, rand_set(rng, dom.L0, dom.R0)))
        Z = union(diff(Y, S2), inter(S2, rand_set(rng, dom.L0, dom.R0)))
        for i in W:
            if leq(acc_lex, dom, i, X, Y) and leq(acc_lex, dom, i, Y, Z):
                nadd += 1
                check("LEX (Add)", leq(acc_lex, dom, i, X, Z))
            if leq(acc, dom, i, X, Y) and leq(acc, dom, i, Y, Z):
                check("SI (Add)", leq(acc, dom, i, X, Z))
print("LEX (Add) premises satisfied:", nadd)


# ------------------------------------------------------------------ RF (record-free)
def rf0(dom, i, X, Y):
    return eq_ae(X, Y) or ((not dom.is_coherent(Y)) and
                           moment(X)[i - 1] > moment(Y)[i - 1])


def rf1(dom, i, X, Y):
    return guided(i, rec(X, Y)) or rf0(dom, i, X, Y)


ntr = 0
for dom in DOMS:
    for _ in range(300):
        X, Y, Z = (rand_set(rng, dom.L0, dom.R0) for _ in range(3))
        if rng.random() < 0.3:
            Z = dom.coherent_model(dom.L0, dom.R0)
        for i in W:
            if rf0(dom, i, X, Y) and rf0(dom, i, Y, Z):
                ntr += 1
                check("RF0 transitive (hence (Add))", rf0(dom, i, X, Z))
print("RF0 transitivity premises:", ntr)

# explicit instances, K' = {1/2}: U = (-1/2, 3/2), C = U coherent
dom = Domain(F(1, 2), F(1, 2))
C = dom.coherent_model(F(-1, 2), F(3, 2))
# (G) fails for RF0: removing a gamble wrong at world 1 from C
A1 = norm([(F(5, 4), F(3, 2))])          # t in (1, 2): h1 < 0
Yg = diff(C, A1)
check("RF0 (G) fails: guided change out of coherent C is refused",
      guided(1, rec(Yg, C)) and not rf0(dom, 1, Yg, C))
# (IB) fails for RF0 and RF1: record (empty, B) with B mixed at world 1, m_1(B) < 0
B = norm([(F(9, 10), F(3, 2))])
E = norm([(F(-1, 2), F(-2, 5))])         # piece of U to make an incoherent base
C2 = dom.coherent_model(F(-2, 5), F(3, 2))   # coherent; C2 u E = U is coherent too!
base_inc = diff(C, norm([(F(-1, 5), F(-1, 10))]))   # incoherent (two intervals)
check("base_inc incoherent", not dom.is_coherent(base_inc))
Xc, Yc = diff(C, B), C
Xn, Yn = diff(base_inc, B), base_inc
check("same record", rec(Xc, Yc) == rec(Xn, Yn))
check("record not guided at 1, m_1 > 0", (not guided(1, rec(Xc, Yc))) and d(1, rec(Xc, Yc)) > 0)
for f, tag in ((rf0, "RF0"), (rf1, "RF1")):
    check(f"{tag} (IB) fails", f(dom, 1, Xn, Yn) and not f(dom, 1, Xc, Yc))
# (Add) fails for RF1: X <=_1 Y (Y incoherent, Brier), Y <=_1 Z (Z = C coherent, guidance),
# disjoint changes, but X not <=_1 Z.
Ag = norm([(F(6, 5), F(13, 10))])         # interior piece wrong at world 1 -> guidance
Ymid = diff(C, Ag)
Bm = norm([(F(9, 10), F(23, 20))])        # mixed at world 1, disjoint from Ag
Xlow = diff(Ymid, Bm)
check("RF1 premises", rf1(dom, 1, Xlow, Ymid) and rf1(dom, 1, Ymid, C)
      and not dom.is_coherent(Ymid))
check("RF1 steps disjoint", null(inter(union(*rec(Xlow, Ymid)), union(*rec(Ymid, C)))))
check("RF1 (Add) fails", not rf1(dom, 1, Xlow, C))
check("SI (Add) holds on the same triple",
      (not (acc(dom, 1, rec(Xlow, Ymid)) and acc(dom, 1, rec(Ymid, C))))
      or acc(dom, 1, rec(Xlow, C)))

print("\ncheck counts:", {k: v for k, v in sorted(counts.items())})
print("\nALL PASS" if not fails else f"\nFAILURES: {sorted(set(fails))}")
