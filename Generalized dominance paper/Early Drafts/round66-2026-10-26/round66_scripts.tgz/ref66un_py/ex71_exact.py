"""REF66_un: exact check of Example 7.1 (failure of (Tr) at world 1).

Part A (all admissible mu): every inequality the note's proof uses is a statement about
the balls only (coordinate ranges, containment in U, disjointness) plus linear bounds in
the masses; these are checked here in exact rational / algebraic arithmetic.

Part B (one concrete admissible mu): density 1 on the three balls V_a, V_b, V_c (any
positive integrable continuation elsewhere, e.g. a Gaussian, keeps (M)); then every
moment of a concentric sub-ball is exact (centre * area), and hull(B) is computed
exactly from Q_B (an interval of q = (t, 1-t)), without using the note's 3/5 witness.

Run: python3 -I ex71_exact.py
"""
import sympy as sp

fails = []


def check(name, cond):
    cond = bool(cond)
    print(("PASS " if cond else "FAIL ") + name)
    if not cond:
        fails.append(name)


R = sp.Rational
r0 = R(1, 10)
a, b, c = sp.Matrix([-1, 3]), sp.Matrix([-2, 3]), sp.Matrix([1, 1])

# ---------------- Part A: universal (any mu satisfying (M)) -----------------------
print("Part A: statements valid for every mu satisfying (M)")
# containment in U = {h1 + h2 > 0}: min over the closed ball of h1+h2 = c1+c2 - r*sqrt2
for name, ctr in (("a", a), ("b", b), ("c", c)):
    check(f"closed ball about {name} inside U", ctr[0] + ctr[1] - r0 * sp.sqrt(2) > 0)
# pairwise disjoint (closed balls): distance > 2r
for (n1, p1), (n2, p2) in ((("a", a), ("b", b)), (("a", a), ("c", c)), (("b", b), ("c", c))):
    check(f"balls {n1},{n2} disjoint", (p1 - p2).norm() > 2 * r0)
# coordinate ranges (open ball => strict)
check("h1 in (-1.1,-0.9) on V_a", a[0] - r0 == R(-11, 10) and a[0] + r0 == R(-9, 10))
check("h1 < -1.9 on V_b", b[0] + r0 == R(-19, 10))
check("h1 in (0.9,1.1) on V_c", c[0] - r0 == R(9, 10) and c[0] + r0 == R(11, 10))
# witness a' - (3/5) b' >> 0 for all a' in V_a, b' in V_b: worst case per coordinate
lam = R(3, 5)
w1 = (a[0] - r0) - lam * (b[0] + r0)       # inf of a'_1 - lam b'_1 (strict >)
w2 = (a[1] - r0) - lam * (b[1] + r0)       # inf of a'_2 - lam b'_2
print("   coordinate infima of a'-(3/5)b':", w1, w2)
check("a' - (3/5) b' >> 0 on V_a x V_b (box bound)", w1 >= R(1, 25) and w2 >= R(26, 25))
# sharper: exact infimum over the discs (|direction| bound), still positive
check("exact disc infimum of first coordinate > 0",
      a[0] - lam * b[0] - r0 * (1 + lam) > 0)
# mass bounds: mu(A)=d/2, mu(B-)=d, mu(B+)=d/4; m1(A) > -1.1 mu(A); m1(B-) < -1.9 mu(B-);
# m1(B+) < 1.1 mu(B+).  Lower bound for m1(A) - m1(B), in units of delta:
lb = -R(11, 10) * R(1, 2) - (-R(19, 10) * 1 + R(11, 10) * R(1, 4))
print("   lower bound on m_1(r(X,Y)) / delta:", lb)
check("m_1(r(X,Y)) > 0 for every admissible mu", lb > 0)
check("note's numbers: -0.55 and -1.625", -R(11, 10) * R(1, 2) == R(-55, 100)
      and -R(19, 10) + R(11, 10) * R(1, 4) == R(-1625, 1000))
# m_1(B) can be negative or positive? note only needs m1(B) < 0 for r(C,X) refused:
check("m_1(B) < 0 for every admissible mu (r(C,X) = (B, empty) has m_1 < 0)",
      -R(19, 10) + R(11, 10) * R(1, 4) < 0)

# ---------------- Part B: one concrete admissible mu, everything exact -------------
print("\nPart B: density 1 on V_a, V_b, V_c (exact moments, exact hull)")
area = lambda rho: sp.pi * rho**2
delta = area(r0)
rA = sp.sqrt(delta / 2 / sp.pi)
rBm = r0
rBp = sp.sqrt(delta / 4 / sp.pi)
check("mu(A) = delta/2", sp.simplify(area(rA) - delta / 2) == 0)
check("mu(B+) = delta/4", sp.simplify(area(rBp) - delta / 4) == 0)
m1A = a[0] * area(rA)
m1B = b[0] * area(rBm) + c[0] * area(rBp)
m1r = sp.simplify(m1A - m1B)
print("   m_1(A) =", m1A, " m_1(B) =", m1B, " m_1(r(X,Y)) =", m1r)
check("m_1(r(X,Y)) > 0 (concrete)", m1r > 0)

# Q_B = {t in [0,1]: q=(t,1-t), q.h >= 0 on closed B- and closed B+}
t = sp.symbols('t', real=True)
q = sp.Matrix([t, 1 - t])
nq = sp.sqrt(t**2 + (1 - t)**2)
gBm = (q.T * b)[0] - rBm * nq
gBp = (q.T * c)[0] - rBp * nq
# gBp > 0 on [0,1] (c >> 0 and c - rBp*|q| ... check endpoints and concavity)
check("B+ imposes no constraint (q.c - r|q| > 0 on [0,1])",
      all(gBp.subs(t, v) > 0 for v in (0, 1)))   # concave in t => min at endpoints
roots = sp.solve(sp.Eq((q.T * b)[0]**2, rBm**2 * nq**2), t)
roots = [sp.nsimplify(r_) for r_ in roots]
roots = [r_ for r_ in roots if r_.is_real and 0 <= r_ <= 1 and (q.T * b)[0].subs(t, r_) >= 0]
tmax = max(roots)
print("   Q_B = {(t,1-t): 0 <= t <= t_max}, t_max =", sp.simplify(tmax), "~", sp.N(tmax))
check("Q_B endpoint: q.b - r|q| = 0 at t_max", sp.simplify(gBm.subs(t, tmax)) == 0)
check("q.b - r|q| >= 0 at t = 0", gBm.subs(t, 0) >= 0)
check("q.b - r|q| < 0 beyond t_max", gBm.subs(t, tmax + R(1, 1000)) < 0)
gA = (q.T * a)[0] - rA * nq   # inf over closed ball A of q.h (concave in t)
vals = [sp.N(gA.subs(t, 0), 30), sp.N(gA.subs(t, tmax), 30)]
print("   inf_{h in A} q.h at the endpoints of Q_B:", vals)
check("A subset hull(B): inf_{q in Q_B, h in cl A} q.h > 0 (concave => endpoints)",
      sp.simplify(gA.subs(t, 0)) > 0 and gA.subs(t, tmax).evalf(50) > 0)
# also: hull(B) does NOT contain B+ trivially? not needed.  Unsafety of (empty,B) from C:
print("   r(X,C) = (empty, B): B subset C = U, so it applies to C (unsafe);")
check("B+ subset {h1 > 0} (so (empty,B) not guidance at 1)", c[0] - rBp > 0)
check("r(Y,C) = (empty, A) guidance at 1 (A subset {h1<0})", a[0] + rA < 0)
check("r(C,X) = (B, empty): m_1 < 0", m1B < 0)

print("\nALL PASS" if not fails else f"\nFAILURES: {fails}")
