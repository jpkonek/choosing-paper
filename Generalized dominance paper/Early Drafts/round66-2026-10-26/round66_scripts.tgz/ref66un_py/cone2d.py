"""Exact two-world cone models for SR66.

Setting (finite-world setting of round 65 with n = 2):
  gambles h in R^2, mu with density exp(-|h|_1) (satisfies (M)).

Cone models.  A cone model is a union of open rays.  Parametrise ray directions by
the L1-unit diamond, t in (-1, 3):
  t in [-1,0]: dir(t) = (1+t, t)      (quadrant IV: h1>=0, h2<=0)
  t in [ 0,1]: dir(t) = (1-t, t)      (quadrant I)
  t in [ 1,2]: dir(t) = (1-t, 2-t)    (quadrant II)
  t in [ 2,3]: dir(t) = (t-3, 2-t)    (quadrant III)
For a simplicial cone spanned by u, v with linear l = |.|_1 on it,
  mu(cone) = |det(u,v)| / (l(u) l(v)),  m(cone) = |det(u,v)| (u/(l(u)^2 l(v)) + v/(l(u) l(v)^2)).
With l(u) = l(v) = 1 and |det(dir(a),dir(b))| = b - a inside one quadrant, this gives
  mu = Lebesgue measure in t,   m(X) = integral over X of 2 dir(t) dt.
So mu and m of a cone model are exact rationals for rational interval endpoints.
These are genuine measurable subsets of R^2 under a non-atomic measure: records may
cut any interval anywhere (no atom structure).

Credal sets: q = (p, 1-p), Q = [a,b] subset [0,1].
  D_{[a,b]} = open interval (-a, 2-b) in t.
  K' = [k1,k2], U = D_{K'} = (-k1, 2-k2).
  Coherent models on U: (L,R) with -k1 <= L <= 0, 1 <= R <= 2-k2.
  hull(B) = (min(0, ess inf B), max(1, ess sup B)) for B subset U  (B empty: (0,1)).
"""
from fractions import Fraction as F
import random

BREAKS = [F(-1), F(0), F(1), F(2), F(3)]


def dirv(t):
    t = F(t)
    if -1 <= t <= 0:
        return (1 + t, t)
    if 0 <= t <= 1:
        return (1 - t, t)
    if 1 <= t <= 2:
        return (1 - t, 2 - t)
    if 2 <= t <= 3:
        return (t - 3, 2 - t)
    raise ValueError(t)


# ---------- interval sets (finite unions of open intervals, a.e.) ----------

def norm(iv):
    """sort, drop empty, merge overlapping/adjacent (a.e. identification)."""
    iv = sorted((F(a), F(b)) for a, b in iv if F(b) > F(a))
    out = []
    for a, b in iv:
        if out and a <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], b))
        else:
            out.append((a, b))
    return tuple(out)


def inter(X, Y):
    out = []
    for a, b in X:
        for c, d in Y:
            lo, hi = max(a, c), min(b, d)
            if hi > lo:
                out.append((lo, hi))
    return norm(out)


def union(X, Y):
    return norm(list(X) + list(Y))


def diff(X, Y):
    out = list(X)
    for c, d in Y:
        new = []
        for a, b in out:
            if d <= a or c >= b:
                new.append((a, b))
            else:
                if c > a:
                    new.append((a, c))
                if d < b:
                    new.append((d, b))
        out = new
    return norm(out)


def meas(X):
    return sum((b - a for a, b in X), F(0))


def null(X):
    return meas(X) == 0


def subset_ae(X, Y):
    return null(diff(X, Y))


def eq_ae(X, Y):
    return subset_ae(X, Y) and subset_ae(Y, X)


def moment(X):
    m1 = F(0)
    m2 = F(0)
    for a, b in X:
        cuts = [a] + [c for c in BREAKS if a < c < b] + [b]
        for lo, hi in zip(cuts, cuts[1:]):
            u, v = dirv(lo), dirv(hi)
            m1 += (hi - lo) * (u[0] + v[0])
            m2 += (hi - lo) * (u[1] + v[1])
    return (m1, m2)


# ---------- worlds, guidance, scores ----------
POS = {1: norm([(-1, 1)]), 2: norm([(0, 2)])}
NEG = {1: norm([(1, 3)]), 2: norm([(-1, 0), (2, 3)])}


def rec(X, Y):
    return (diff(X, Y), diff(Y, X))


def inv(r):
    return (r[1], r[0])


def is_null_rec(r):
    return null(r[0]) and null(r[1])


def d(i, r):
    return moment(r[0])[i - 1] - moment(r[1])[i - 1]


def guided(i, r):
    return subset_ae(r[0], POS[i]) and subset_ae(r[1], NEG[i])


# ---------- domain and coherence ----------
class Domain:
    def __init__(self, k1, k2):
        self.k1, self.k2 = F(k1), F(k2)
        self.U = norm([(-self.k1, 2 - self.k2)])
        self.L0, self.R0 = -self.k1, 2 - self.k2

    def coherent_model(self, L, R):
        L, R = F(L), F(R)
        assert self.L0 <= L <= 0 and 1 <= R <= self.R0, (L, R)
        return norm([(L, R)])

    def is_model(self, X):
        return subset_ae(X, self.U)

    def is_coherent(self, X):
        X = norm(X)
        if len(X) != 1:
            return False
        L, R = X[0]
        return self.L0 <= L <= 0 and 1 <= R <= self.R0

    def hull(self, B):
        B = norm(B)
        if null(B):
            return norm([(0, 1)])
        lo = min(a for a, b in B)
        hi = max(b for a, b in B)
        return norm([(min(F(0), lo), max(F(1), hi))])

    def safe_hull(self, r):
        A, B = r
        return meas(inter(A, self.hull(B))) > 0

    def safe_attack(self, r):
        """Brute force from the definition: r is safe iff it attacks no coherent model.
        An attacked coherent (L,R) must contain B a.e. and miss A a.e.  The containment
        condition is L <= min(0, inf B), R >= max(1, sup B) (and the U-constraints); the
        miss condition is monotone (smaller interval is better).  We enumerate every
        candidate endpoint pair drawn from the endpoints of A, B and the constants, which
        contains the optimal pair; the test itself does not call hull()."""
        A, B = r
        pts = {F(0), F(1), self.L0, self.R0}
        for a, b in A + B:
            pts.add(a)
            pts.add(b)
        Ls = [p for p in pts if self.L0 <= p <= 0]
        Rs = [p for p in pts if 1 <= p <= self.R0]
        for L in Ls:
            for R in Rs:
                C = norm([(L, R)])
                if subset_ae(B, C) and null(inter(A, C)):
                    return False
        return True


def acc(dom, i, r):
    return guided(i, r) or (dom.safe_hull(r) and d(i, r) > 0)


def leq(dom, i, X, Y):
    return acc(dom, i, rec(X, Y))


def strict(dom, i, X, Y):
    return leq(dom, i, X, Y) and not leq(dom, i, Y, X)


# ---------- random sets ----------
def rand_set(rng, lo, hi, kmax=4, den=60):
    lo, hi = F(lo), F(hi)
    k = rng.randint(0, kmax)
    pts = sorted(rng.randint(int(lo * den), int(hi * den)) for _ in range(2 * k))
    iv = [(F(pts[2 * j], den), F(pts[2 * j + 1], den)) for j in range(k)]
    return norm(iv)
