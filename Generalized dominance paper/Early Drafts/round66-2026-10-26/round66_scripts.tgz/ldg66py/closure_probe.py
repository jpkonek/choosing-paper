from itertools import product
M=range(8); X_,Y_,Z_=1,2,4
coh=lambda s: not (s&X_) or bool(s&Z_)
COH=[s for s in M if coh(s)]
rec=lambda a,b:(a&~b&7,b&~a&7)
def safe(r): return not any(rec(zp,z)==r for z in COH for zp in M)
h={1:(1,-1,3),2:(-2,1,-1)}
nm=lambda s:'{'+','.join('xyz'[i] for i in range(3) if s>>i&1)+'}'
phi=lambda w,s: sum(h[w][i] for i in range(3) if s>>i&1)
def g(w,r): return all(h[w][i]>0 for i in range(3) if r[0]>>i&1) and all(h[w][i]<0 for i in range(3) if r[1]>>i&1)
def le(w,a,b): r=rec(a,b); return g(w,r) or (safe(r) and phi(w,a)>phi(w,b))
print({nm(s):(phi(1,s),phi(2,s)) for s in M})
tc={}
for w in (1,2):
    R={(a,b) for a in M for b in M if le(w,a,b)}
    while True:
        new={(a,c) for (a,b) in R for (b2,c) in R if b==b2}-R
        if not new: break
        R|=new
    tc[w]=R
    print('w',w,'fails',[(nm(a),nm(b),nm(c)) for a,b,c in product(M,M,M) if le(w,a,b) and le(w,b,c) and not le(w,a,c)])
for c in COH:
    doms=[nm(m) for m in M if m!=c and all((m,c) in tc[w] for w in (1,2))]
    print('coherent',nm(c),'weakly dominated in transitive closure by',doms)
