# Search: same closure as Example 3.17 ("x implies z" on items x,y,z), two worlds,
# small integer h with no item of constant sign, (SI) holds; report intransitivity.
from itertools import product
n=3; M=range(8); X_,Y_,Z_=1,2,4
coh=lambda s: not (s&X_) or bool(s&Z_)
COH=[s for s in M if coh(s)]
rec=lambda a,b:(a&~b&7,b&~a&7)
def safe(r): return not any(rec(zp,z)==r for z in COH for zp in M)
vals=[v for v in range(-3,4) if v]
found=[]
for hx1,hy1,hz1,hx2,hy2,hz2 in product(vals,repeat=6):
    h={1:(hx1,hy1,hz1),2:(hx2,hy2,hz2)}
    if any((h[1][i]>0)==(h[2][i]>0) for i in range(3)): continue
    phi=lambda w,s: sum(h[w][i] for i in range(3) if s>>i&1)
    def g(w,r): return all(h[w][i]>0 for i in range(3) if r[0]>>i&1) and all(h[w][i]<0 for i in range(3) if r[1]>>i&1)
    def le(w,a,b): r=rec(a,b); return g(w,r) or (safe(r) and phi(w,a)>phi(w,b))
    if not all(any(safe(rec(c,m)) and all(phi(w,c)>phi(w,m) for w in (1,2)) for c in COH) for m in M if not coh(m)): continue
    fails=[(w,a,b,c) for w in (1,2) for a,b,c in product(M,M,M) if le(w,a,b) and le(w,b,c) and not le(w,a,c)]
    if fails: found.append((h,fails[0]))
print(len(found)); print(found[:5])
nm=lambda s:'{'+','.join('xyz'[i] for i in range(3) if s>>i&1)+'}'
for h,_ in found:
    phi=lambda w,s: sum(h[w][i] for i in range(3) if s>>i&1)
    def g(w,r): return all(h[w][i]>0 for i in range(3) if r[0]>>i&1) and all(h[w][i]<0 for i in range(3) if r[1]>>i&1)
    def le(w,a,b): r=rec(a,b); return g(w,r) or (safe(r) and phi(w,a)>phi(w,b))
    plain=[(nm(m),nm(c)) for c in COH for m in M if m!=c and all(phi(w,m)>=phi(w,c) for w in (1,2)) and any(phi(w,m)>phi(w,c) for w in (1,2))]
    fails=[(w,nm(a),nm(b),nm(c)) for w in (1,2) for a,b,c in product(M,M,M) if le(w,a,b) and le(w,b,c) and not le(w,a,c)]
    s=sum(abs(v) for v in h[1]+h[2])
    print(s,h,'plain',plain,'fails',len(fails),fails[:3])
