# LDG66 revision 2: exact check of Example 3.17 (items x,y,z; h_1=(1,-1,3)), adapted from REF66_ldg's check_example.py.
# Independent implementation: models are bitmasks over atoms a=bit0, b=bit1, c=bit2.
# Every clause of Theorem 3.13, Remark 3.14, Lemma 3.16 and the text of the example is checked.
from itertools import product

ATOMS = 'xyz'
A_, B_, C_ = 1, 2, 4
FULL = 7
h = {1: (1, -1, 3), 2: (-2, 1, -1)}
W = (1, 2)
M = list(range(8))

def name(x):
    return '{' + ','.join(ATOMS[i] for i in range(3) if x >> i & 1) + '}'

def coherent(x):            # x implies z
    return not (x & A_) or bool(x & C_)

COH = [x for x in M if coherent(x)]

def phi(w, x):
    return sum(h[w][i] for i in range(3) if x >> i & 1)

def rec(x, y):               # change turning y into x
    return (x & ~y & FULL, y & ~x & FULL)

NULL = (0, 0)
ALLREC = {rec(x, y) for x in M for y in M}

def applies(r, z):           # definition: r = rec(z', z) for some z' in M
    return any(rec(zp, z) == r for zp in M)

def safe(r):
    return not any(applies(r, z) for z in COH)

def guided(w, r):
    a, b = r
    return all(h[w][i] > 0 for i in range(3) if a >> i & 1) and \
           all(h[w][i] < 0 for i in range(3) if b >> i & 1)

def le(w, x, y):
    r = rec(x, y)
    return guided(w, r) or (safe(r) and phi(w, x) > phi(w, y))

def lt(w, x, y):
    return le(w, x, y) and not le(w, y, x)

def wdom(c, m):
    return all(le(w, c, m) for w in W)

def dom(c, m):
    return wdom(c, m) and not wdom(m, c)

def sdom(c, m):
    return all(lt(w, c, m) for w in W)

ok = True
def check(cond, msg):
    global ok
    if not cond:
        ok = False
        print('FAIL:', msg)

# --- statements in the text of the example
check([name(x) for x in COH] == ['{}', '{b}', '{c}', '{b,c}', '{a,c}', '{a,b,c}'] or len(COH) == 6, 'six coherent')
check(sorted(name(x) for x in M if not coherent(x)) == ['{x,y}', '{x}'], 'incoherent are {x},{x,y}')
def hull(b):
    cands = [z for z in COH if b & ~z == 0]
    least = [z for z in cands if all(z & ~y == 0 for y in cands)]
    assert len(least) == 1
    return least[0]
for b in M:
    check(hull(b) == ((b | C_) if b & A_ else b), 'hull formula ' + name(b))
check([phi(w, A_) for w in W] == [1, -2], 'score {a}')
check([phi(w, A_ | B_) for w in W] == [0, -1], 'score {a,b}')
check([phi(w, C_) for w in W] == [3, -1], 'score {z}')
check([phi(w, B_ | C_) for w in W] == [2, 0], 'score {y,z}')
check([phi(w, 0) for w in W] == [0, 0] and [phi(w, FULL) for w in W] == [3, -2], 'scores of {} and {x,y,z}')
check(rec(C_, A_) == (C_, A_) and rec(B_ | C_, A_ | B_) == (C_, A_), 'repair record ({c},{a})')
check(safe((C_, A_)), 'repair record safe')
for i in range(3):
    check(not all(h[w][i] > 0 for w in W) and not all(h[w][i] < 0 for w in W), 'no sure sign item ' + ATOMS[i])

# --- Lemma 3.16(a): safe iff mu(A cap hull(B))>0, for every record (all disjoint pairs)
for a, b in product(M, M):
    if a & b:
        continue
    check(safe((a, b)) == bool(a & hull(b)), 'hull test (%s,%s)' % (name(a), name(b)))
# every disjoint pair is a record of some pair of models
check(len(ALLREC) == 27, 'records = all 27 disjoint pairs')

# --- (GI)
for w in W:
    for x, y in product(M, M):
        if x != y and guided(w, rec(x, y)):
            check(phi(w, x) > phi(w, y), 'GI')
# --- (GP)
for c in COH:
    for m in M:
        if all(guided(w, rec(m, c)) for w in W):
            check(m == c, 'GP')
# --- (SI)
for m in M:
    if coherent(m):
        continue
    imps = [c for c in COH if safe(rec(c, m)) and all(phi(w, c) > phi(w, m) for w in W)]
    print('SI: incoherent', name(m), 'safe strict improvers', [name(c) for c in imps])
    check(len(imps) > 0, 'SI ' + name(m))

# --- Theorem (a): reflexive, no cycles of any length, no nontrivial ties, strict guidance
for w in W:
    for x in M:
        check(le(w, x, x), 'reflexive')
    # acyclicity: the graph x->y for x!=y, x<=y has no directed cycle
    succ = {x: [y for y in M if y != x and le(w, x, y)] for x in M}
    colour = {x: 0 for x in M}
    def dfs(u):
        colour[u] = 1
        for v in succ[u]:
            if colour[v] == 1:
                return True
            if colour[v] == 0 and dfs(v):
                return True
        colour[u] = 2
        return False
    check(not any(colour[x] == 0 and dfs(x) for x in M), 'acyclic at %d' % w)
    for x, y in product(M, M):
        if x != y:
            check(not (le(w, x, y) and le(w, y, x)), 'no tie')
            if guided(w, rec(x, y)):
                check(lt(w, x, y), 'strict guidance')
    # (TC) and finite chains of length up to 4
    for x, y, z in product(M, M, M):
        if le(w, x, y) and le(w, y, z):
            check(not lt(w, z, x), 'TC')
    # monotonicity of the score along accepted comparisons
    for x, y in product(M, M):
        if x != y and le(w, x, y):
            check(phi(w, x) > phi(w, y), 'score strictly increases')
# --- (b), (c), (d)
for c in COH:
    check(all(m == c for m in M if wdom(m, c)), '(b) ' + name(c))
U = [x for x in M if not any(dom(y, x) for y in M)]
CL = [c for c in COH if c in U]
check(sorted(U) == sorted(COH) and sorted(CL) == sorted(COH), '(d) U_L = C_L = C')
for m in M:
    if not coherent(m):
        imps = [c for c in COH if safe(rec(c, m)) and all(phi(w, c) > phi(w, m) for w in W)]
        check(all(sdom(c, m) for c in imps), '(c) strict dominance ' + name(m))
check(all(any(wdom(c, m) for c in CL) for m in M), '(W)')
check(all(coherent(m) for m in M for c in CL if wdom(m, c) and wdom(c, m)), '(C)')
# --- (e): record-based, and (RS)
for w in W:
    seen = {}
    for x, y in product(M, M):
        r = rec(x, y)
        v = le(w, x, y)
        check(seen.setdefault(r, v) == v, '(e)')
        s = phi(w, x) > phi(w, y)
        key = ('RS', r)
        check(seen.setdefault(key, s) == s, '(RS)')
# --- (f) / (Add) on T, and TS, TG
for w in W:
    for x, y, z in product(M, M, M):
        if (x ^ y) & (y ^ z):
            continue
        r1, r2, r = rec(x, y), rec(y, z), rec(x, z)
        check(r == (r1[0] | r2[0], r1[1] | r2[1]), 'record composition identity')
        if safe(r1) or safe(r2):
            check(safe(r), '(TS)')
        if guided(w, r1) and guided(w, r2):
            check(guided(w, r), '(TG)')
        if le(w, x, y) and le(w, y, z):
            check(le(w, x, z), '(f)')
# full transitivity (not claimed; reported)
for w in W:
    fails = [(name(x), name(y), name(z)) for x, y, z in product(M, M, M)
             if le(w, x, y) and le(w, y, z) and not le(w, x, z)]
    print('world', w, 'transitivity failures (not claimed either way):', len(fails))

# --- second paragraph of the example: plain score comparison and incomparability
pairs = []
for c in COH:
    for m in M:
        if m != c and all(phi(w, m) >= phi(w, c) for w in W) and any(phi(w, m) > phi(w, c) for w in W):
            pairs.append((m, c))
print('plain-score weak dominators of coherent models:', [(name(m), name(c)) for m, c in pairs])
check(sorted(pairs) == sorted([(B_ | C_, 0), (C_, FULL)]), 'exactly the two pairs named')
for m, c in pairs:
    for w in W:
        check(not le(w, m, c) and not le(w, c, m), 'incomparable')
    check(applies(rec(m, c), c) and applies(rec(c, m), m) and coherent(m), 'records apply to coherent models')
    for w in W:
        check(not guided(w, rec(m, c)) and not guided(w, rec(c, m)), 'not guided')

# --- Remark 3.14 in the example: GP necessary for (b); SI-or-guided characterisation
for m in M:
    if coherent(m):
        continue
    domd = any(dom(c, m) for c in COH)
    alt = any((safe(rec(c, m)) and all(phi(w, c) > phi(w, m) for w in W)) or
              all(guided(w, rec(c, m)) for w in W) for c in COH)
    check(domd == alt, 'Remark 3.14 characterisation')


# ---------------- additions for revision 2 ----------------
SI = lambda m: [c for c in COH if all(guided(w, rec(c, m)) for w in W) or
                (safe(rec(c, m)) and all(phi(w, c) > phi(w, m) for w in W))]
# (SI) in its exact form; Remark 3.14: (i) <=> (ii) <=> (iii), strictness, and (SI) <=> (W)
for m in M:
    if coherent(m):
        continue
    i_ = len(SI(m)) > 0
    ii = any(dom(c, m) for c in COH)
    iii = any(wdom(c, m) for c in COH)
    check(i_ == ii == iii, 'Remark 3.14 (i)<=>(ii)<=>(iii) ' + name(m))
    for c in COH:
        if wdom(c, m):
            check(sdom(c, m), 'weak dominance of incoherent by coherent is strict')
WOK = all(any(wdom(c, m) for c in CL) for m in M)
check(WOK == all(len(SI(m)) > 0 for m in M if not coherent(m)), '(SI) <=> (W)')
# (GP) <=> (b)
GP = all(m == c for c in COH for m in M if all(guided(w, rec(m, c)) for w in W))
B_ok = all(all(m == c for m in M if wdom(m, c)) for c in COH)
check(GP == B_ok, '(GP) <=> (b)')
# Lemma set-records (a): applies <=> B subset Z and A cap Z empty
for (a, b) in ALLREC:
    for z in M:
        check(applies((a, b), z) == ((b & ~z) == 0 and (a & z) == 0), 'applies characterisation')
# Lemma set-records (b): record-based <=> independence (W62 form), for the ranking at each world
def indep(w):
    for S in M:
        for x, y, xp, yp in product(M, M, M, M):
            if (x & ~S) == (y & ~S) and (xp & ~S) == (yp & ~S) and (x & S) == (xp & S) and (y & S) == (yp & S):
                if le(w, x, y) != le(w, xp, yp):
                    return False
    return True
def recbased(w):
    d = {}
    return all(d.setdefault(rec(x, y), le(w, x, y)) == le(w, x, y) for x, y in product(M, M))
for w in W:
    check(indep(w) and recbased(w), 'independence and record-based at %d' % w)
# Lemma set-records (e): (f) at w <=> accepted records closed under disjoint union
for w in W:
    acc = {rec(x, y) for x, y in product(M, M) if le(w, x, y)}
    clos = all((a1 | a2, b1 | b2) in acc for (a1, b1) in acc for (a2, b2) in acc if not ((a1 | b1) & (a2 | b2)))
    fT = all(le(w, x, z) for x, y, z in product(M, M, M)
             if not ((x ^ y) & (y ^ z)) and le(w, x, y) and le(w, y, z))
    check(clos == fT and fT, 'Lemma set-records (e) at %d' % w)
# Lemma hull-test (b): iff form, S+ = S- = empty here
Splus = sum(1 << i for i in range(3) if all(h[w][i] > 0 for w in W))
Sminus = sum(1 << i for i in range(3) if all(h[w][i] < 0 for w in W))
cond = all((Splus & ~c) == 0 and (c & Sminus) == 0 for c in COH)
check(Splus == 0 and Sminus == 0 and cond == GP and GP, 'Lemma hull-test (b)')
# the intransitivity stated in the example: {y,z} <=_1 {x} <=_1 {} but incomparable {y,z},{} at world 1
YZ, X, E = B_ | C_, A_, 0
check(le(1, YZ, X) and le(1, X, E) and not le(1, YZ, E) and not le(1, E, YZ), 'stated intransitivity at world 1')
check(safe(rec(YZ, X)) and phi(1, YZ) == 2 and phi(1, X) == 1 and guided(1, rec(X, E)), 'reasons for the two steps')
check(applies(rec(YZ, E), E) and not guided(1, rec(YZ, E)) and not guided(2, rec(YZ, E)), 'composite applies to {} and is unguided')
# (SI) improvers stated in the text
check(C_ in SI(A_) and (B_ | C_) in SI(A_ | B_) and rec(C_, A_) == rec(B_ | C_, A_ | B_) == (C_, A_), 'stated repairs')
print('ALL PASS' if ok else 'SOME FAILURES')
