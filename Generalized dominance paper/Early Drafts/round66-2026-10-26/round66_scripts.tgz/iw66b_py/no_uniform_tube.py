"""IW66b: CHECKED (exact rational arithmetic).
Contamination on Omega=[0,1], E=C[0,1], p = Lebesgue, K=(1-eps){p}+eps*S, U={p(h)>0}.
Tent h_j: peak 1 at 1/2, half-width r_j = 2^-j, so p(h_j)=r_j, min h_j=0, ||h_j||=1.
g_j := h_j - P_K(h_j) 1 lies on the boundary {P_K=0}, is nonzero, and
dist(g_j, E \\ U) <= p(g_j) = eps*r_j  (subtract p(g_j)*1).  The relative
distance p(g_j)/||g_j|| -> 0: no boundary tube of uniform relative width lies in U.
"""
from fractions import Fraction as F
for eps in (F(1, 2), F(1)):
    print(f"eps = {eps}")
    for j in range(1, 11, 3):
        r = F(1, 2**j)
        p_h, min_h, norm_h = r, F(0), F(1)
        PK = (1 - eps) * p_h + eps * min_h          # P_K(h_j)
        # g = h - PK*1: P_K(g)=0, p(g) = p_h - PK, ||g|| = max(1-PK, PK)
        p_g = p_h - PK
        norm_g = max(1 - PK, PK)
        assert (1 - eps) * p_g + eps * (min_h - PK) == 0   # g on the boundary
        print(f"  j={j:2d}: P_K(g)=0, p(g)={p_g}, ||g||={norm_g}, p(g)/||g|| = {float(p_g/norm_g):.3e}")
