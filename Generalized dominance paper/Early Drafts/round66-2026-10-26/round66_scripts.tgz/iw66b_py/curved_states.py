"""IW66b: NUMERICS replay of the infinite-world construction (audit section 4,
Steps A-D) on a space with uncountably many worlds and a curved state space.

Worlds: Omega = [0,1].  Gambles: E = span{1, w, w^2}  (h <-> (a,b,c)).
States: probability measures on [0,1], acting through moments (m1,m2);
S = {(m1,m2): m1^2 <= m2 <= m1}, whose extreme points are the evaluations
delta_w <-> (w, w^2), a continuum.  K' = {p}, p = Lebesgue mean (1/2, 1/3).
mu = law of N(0, I_3) on coefficients (full support, finite first moment,
{P_Q = 0} null because P_Q(h + t1) = P_Q(h) + t).

All integrals are taken against the empirical measure of a fixed sample, so
every reported quantity is exact for that discrete measure and a Monte Carlo
estimate for mu.  Label: NUMERICS.
"""
import numpy as np

rng = np.random.default_rng(66)
n = 400_000
H = rng.standard_normal((n, 3))
a, b, c = H[:, 0], H[:, 1], H[:, 2]


def qval(m1, m2):
    return a + b * m1 + c * m2


def quad_min_on_unit(coef):
    """exact min over w in [0,1] of coef[...,0] + coef[...,1] w + coef[...,2] w^2"""
    coef = np.atleast_2d(coef)
    A, B, C = coef[:, 0], coef[:, 1], coef[:, 2]
    vals = [A, A + B + C]
    with np.errstate(divide="ignore", invalid="ignore"):
        ws = np.where(C > 0, -B / (2 * C), 0.0)
    ws = np.clip(ws, 0, 1)
    vals.append(A + B * ws + C * ws * ws)
    return np.min(np.vstack(vals), axis=0)


def P_poly(verts):
    return np.min(np.vstack([qval(*v) for v in verts]), axis=0)


PS = quad_min_on_unit(H)                     # P_S(h) = inf_w h(w)
p = (0.5, 1 / 3)
d0, dh, d1 = (0.0, 0.0), (0.5, 0.25), (1.0, 1.0)
U = qval(*p) > 0


def moment(mask):
    return H[mask].sum(axis=0) / n          # m(Y) in E, as coefficients


def grid_states(k=81):
    out = []
    for m1 in np.linspace(0, 1, k):
        for s in np.linspace(0, 1, k):
            out.append((m1, m1 * m1 + s * (m1 - m1 * m1)))
    return np.array(out)


GRID = grid_states()


def minimax(G, x):
    """min over q in S of  sigma_G(q) - q(x);  convex in (m1,m2)."""
    best = None
    for (m1, m2) in GRID:
        qv = qval(m1, m2)
        F = np.where(G, np.maximum(qv, 0), 0).sum() / n - (x[0] + x[1] * m1 + x[2] * m2)
        if best is None or F < best[0]:
            best = (F, m1, m2)
    # local refinement by pattern search inside S
    F0, m1, m2 = best
    step = 0.02
    while step > 1e-5:
        improved = False
        for dm1, dm2 in [(step, 0), (-step, 0), (0, step), (0, -step),
                         (step, step), (-step, -step), (step, -step), (-step, step)]:
            u1, u2 = m1 + dm1, m2 + dm2
            if not (0 <= u1 <= 1 and u1 * u1 - 1e-12 <= u2 <= u1 + 1e-12):
                continue
            qv = qval(u1, u2)
            F = np.where(G, np.maximum(qv, 0), 0).sum() / n - (x[0] + x[1] * u1 + x[2] * u2)
            if F < F0:
                F0, m1, m2, improved = F, u1, u2, True
                break
        if not improved:
            step /= 2
    return F0, m1, m2


def dist_to_poly(q, verts):
    # distance in (m1,m2) to the convex hull of 1 or 2 vertices
    q = np.asarray(q)
    if len(verts) == 1:
        return np.linalg.norm(q - np.asarray(verts[0]))
    A, B = np.asarray(verts[0]), np.asarray(verts[1])
    t = np.clip(np.dot(q - A, B - A) / np.dot(B - A, B - A), 0, 1)
    return np.linalg.norm(q - (A + t * (B - A)))


def hull_report(B, QXverts, label):
    """For grid states q, count removed points h in B with q(h) < 0.
    q in Q_B  <=>  count 0.  Report the smallest count among q at distance
    >= r from Q_X, and the largest count among q in Q_X (should be 0)."""
    Hb = H[B]
    rows = []
    for r in (0.02, 0.05, 0.1):
        mins = None
        for (m1, m2) in GRID:
            if dist_to_poly((m1, m2), QXverts) < r:
                continue
            cnt = int(((Hb[:, 0] + Hb[:, 1] * m1 + Hb[:, 2] * m2) < 0).sum())
            mins = cnt if mins is None else min(mins, cnt)
        rows.append((r, mins))
    print(f"    {label}: |removed| = {B.sum()}; min #violations for q at dist >= r from Q_X: "
          + ", ".join(f"r={r}: {m}" for r, m in rows))
    return rows


def run(name, X, QXverts):
    print(f"== {name}")
    assert not np.any(X & ~U), "X must lie in U"
    PX = P_poly(QXverts)
    G = PX > 0
    print(f"  mu(X) = {X.mean():.4f}, mu(G) = {G.mean():.4f}, mu(X \\ G) = {(X & ~G).mean():.2e}, "
          f"mu(G \\ X) = {(G & ~X).mean():.4f}  (incoherent: X != hull a.e.)")
    x = moment(X)
    v, m1, m2 = minimax(G, x)
    N0 = G & (qval(m1, m2) > 0)
    marg0 = quad_min_on_unit(moment(N0) - x)[0]
    print(f"  Step B: q* = (m1,m2) = ({m1:.4f},{m2:.4f}); v = {v:.5f}; "
          f"inf_w [m(N0)-m(X)](w) = {marg0:.5f}; mu(N0 \\ X) = {(N0 & ~X).mean():.4f}")
    # Step C: halve tau from 0.3 until half the margin survives (audit's rule)
    tau = 0.3
    while True:
        Ntau = N0 & ((1 - tau) * PX + tau * PS > 0)
        marg = quad_min_on_unit(moment(Ntau) - x)[0]
        if marg >= v / 2 and (Ntau & ~X).any():
            break
        tau /= 2
    print(f"  Step C: tau = {tau:.3e}: inf_w margin = {marg:.6f} (>= v/2); mu(N\\X) = {(Ntau & ~X).mean():.4f}; "
          f"N subset hull(X): {not np.any(Ntau & ~G)}")
    print("  Step D (hull(X\\N) = hull(X)): q in Q_(X\\N) iff no removed h has q(h) < 0")
    hull_report(X & ~Ntau, QXverts, "after shrink ")
    hull_report(X & ~N0, QXverts, "control tau=0")
    print()


# R1: union of two Bayes-type coherent models; Q_X = Q1 cap Q2 = {p}; hull = U
X1 = (P_poly([p, d0]) > 0) | (P_poly([p, d1]) > 0)
run("R1: D_[p,d0] u D_[p,d1]  (Q_X = {p})", X1, [p])

# R2: two triangles sharing the edge [p, d_1/2]; Q_X = [p, d_1/2]
X2 = (P_poly([p, d0, dh]) > 0) | (P_poly([p, dh, d1]) > 0)
run("R2: D_conv(p,d0,d.5) u D_conv(p,d.5,d1)  (Q_X = [p, d_.5])", X2, [p, dh])

# R3: U with a ball removed (deep hole); Q_X = {p}
X3 = U & (np.linalg.norm(H, axis=1) > 0.8)
run("R3: U minus a ball  (Q_X = {p})", X3, [p])
