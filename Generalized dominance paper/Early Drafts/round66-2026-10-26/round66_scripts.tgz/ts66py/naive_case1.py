"""TS66 control: rivals WITH nonempty hull (Q_X nonempty) on the full domain, on which the
naive full-domain Brier-minimax half-space {pi0.h>0} has an unsafe record.  Then: add a far
thin cone E with Q_{X u E} empty but E inside {pi0.h>0}, giving a Case-2 rival whose naive
defender is unsafe, and certify the TS66 construction on it.
Run: python3 -I naive_case1.py [trials] [seed]"""
import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geo3 import *
from case2_check import small_cone, simplicial, run, pos, fl, disjoint_union
from naive_hunt import naive
T = int(sys.argv[1]) if len(sys.argv) > 1 else 80
rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 5)
log = []; hits = []; tried = 0
for t in range(T):
    p = V(*[Fr(rng.randint(1, 6)) for _ in range(3)]); p = sc(1/sum(p), p)
    cones = []
    for _ in range(rng.randint(1, 3)):
        q = V(*[Fr(rng.randint(0, 6)) for _ in range(3)])
        if sum(q) == 0: continue
        q = sc(1/sum(q), q); cones.append([p, q])          # D_{[p,q]}
    if not cones: continue
    X = disjoint_union(*cones)
    if rng.random() < 0.7:
        d = V(*[Fr(rng.randint(-4, 6)) for _ in range(3)])
        hole = small_cone(d, Fr(rng.randint(1, 8), 20))
        X = minus(X, hole) if hole else X
        X = [x for x in X if not is_null(x)]
    if not X: continue
    QX = Q_model(X)
    if not QX: continue
    G = list(QX)
    if mass(G) == mass_model(X): continue        # coherent
    tried += 1
    pi0, sf = naive(X)
    if pi0 is None or sf[0]: continue
    hits.append((X, pi0, QX))
    log.append('Case-1 naive-unsafe: pieces=%d, pi0=%s, Q_X=%s, Q_B=%s, witness=%s'
               % (len(X), fl(pi0, 5), [fl(q, 3) for q in QX], [fl(q, 3) for q in sf[1]['Q_B']], sf[1]['witness']))
    print(log[-1], flush=True)
log.append('Case-1 rivals tried: %d ; naive-unsafe: %d' % (tried, len(hits)))
# --- lift to Case 2: add a thin cone E around s with pi0.s > 0 but q.s < 0 for all q in Q_X
res = []; lifted = 0
for X, pi0, QX in hits:
    if lifted >= 3: break
    found = None
    for _ in range(4000):
        s = V(*[Fr(rng.randint(-8, 8), rng.randint(1, 3)) for _ in range(3)])
        if dot(pi0, s) <= 0 or max(dot(q, s) for q in QX) >= 0: continue
        Ec = small_cone(s, Fr(1, 200))
        ok = all(dot(pi0, g) > 0 and max(dot(q, g) for q in QX) < 0 for g in [add(s, sc(Fr(1,200), sub(E[i], U3))) for i in range(3)])
        if not ok: continue
        Ec = Ec + [neg(x) for x in []]
        Y = X + minus([Ec], [])  # placeholder
        Y = list(X)
        pieces = [Ec]
        for pc in X:
            new = []
            for c in pieces: new += minus([c], pc)
            pieces = new
        Y += [c for c in pieces if not is_null(c)]
        if Q_model(Y): continue
        pi1, sf1 = naive(Y)
        log.append('  lift attempt: s=%s ; Q_Y empty ; naive pi=%s ; naive SAFE=%s' % (fl(s, 3), None if pi1 is None else fl(pi1, 5), None if sf1 is None else sf1[0]))
        print(log[-1], flush=True)
        if pi1 is not None and not sf1[0]:
            found = Y; break
    if found:
        lifted += 1
        run('Case-2 rival with UNSAFE naive defender (lift %d)' % lifted, found, res)
txt = '\n'.join(log + [''] + res); print('\n'.join(res))
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'naive_case1.out'), 'w').write(txt + '\n')
