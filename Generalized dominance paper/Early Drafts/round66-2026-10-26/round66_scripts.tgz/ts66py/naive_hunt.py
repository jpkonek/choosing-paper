"""TS66 control: hunt for Case-2 rivals (Q_X empty) on which the naive defender -- the
full-domain Brier-minimax half-space {pi0.h>0} -- has an UNSAFE record.  Each hit is then
re-run through the full TS66 construction (Lemma E + Theorem H' + shrink), exactly.
Rivals: X = {p.h>0} u (S n {p.h<0}) u (optional second cone), S a thin cone around s.
Run: python3 -I naive_hunt.py [trials] [seed]
"""
import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geo3 import *
from case2_check import simplicial, small_cone, run, pos, fl

def naive(X):
    mX = m_model(X)
    sv, pf = minimax_search([], mX)
    pi0 = certify_prior(pf, lambda p: pos(sub(mom([p]), mX)))
    if pi0 is None: return None, None
    return pi0, record_safety([pi0], X)

if __name__ == '__main__':
    T = int(sys.argv[1]) if len(sys.argv) > 1 else 60
    seed = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    rng = random.Random(seed); hits = []; log = []; tried = 0
    for t in range(T):
        p = V(*[Fr(rng.randint(1, 9)) for _ in range(3)]); p = sc(1/sum(p), p)
        X = [[p]]
        for _ in range(rng.choice((1, 1, 2))):
            s = V(*[Fr(rng.randint(-9, 9), rng.randint(1, 4)) for _ in range(3)])
            if dot(p, s) >= 0 or max(s) <= 0: continue
            eps = Fr(rng.randint(1, 12), 40)
            c = small_cone(s, eps) + [neg(p)]
            for q in X[1:]:
                pass
            if is_null(c): continue
            # keep pieces disjoint
            pieces = [c]
            for q in X[1:]:
                new = []
                for pc in pieces: new += minus([pc], q)
                pieces = new
            X += pieces
        if len(X) < 2 or Q_model(X): continue
        tried += 1
        pi0, sf = naive(X)
        if pi0 is None: continue
        safe, info = sf
        if not safe:
            hits.append((p, X, pi0, info))
            log.append('HIT %d: p=%s, pieces=%d, pi0=%s, Q_B=%s, witness=%s'
                       % (len(hits), fl(p, 4), len(X), fl(pi0, 6), [fl(q, 4) for q in info['Q_B']], info['witness']))
            print(log[-1], flush=True)
    log.append('naive-unsafe hits: %d among %d Case-2 rivals tried' % (len(hits), tried))
    out = []
    for k, (p, X, pi0, info) in enumerate(hits[:4]):
        run('naive-unsafe hit %d' % (k+1), X, out)
    txt = '\n'.join(log + [''] + out)
    print(txt)
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'naive_hunt.out'), 'w') as f:
        f.write(txt + '\n')
