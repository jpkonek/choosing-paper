"""TS66 control: targeted hunt (first-order analysis in TS66_notes §5.3) for a Case-2 rival
X = {p.h>0} u (S n {p.h<0}) whose naive full-domain Brier-minimax defender is unsafe.
Run: python3 -I naive_target.py"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geo3 import *
from case2_check import small_cone, run, pos, fl
from naive_hunt import naive
out = []; hits = []
for p in [V(Fr(4,5),Fr(1,10),Fr(1,10)), V(Fr(7,10),Fr(2,10),Fr(1,10)), V(Fr(9,10),Fr(1,20),Fr(1,20))]:
    for s in [V(Fr(-156,100),Fr(1,50),Fr(-70,100)), V(Fr(-156,100),Fr(1,10),Fr(-70,100)), V(Fr(-15,10),Fr(-7,10),Fr(1,20)),
              V(Fr(-2),Fr(1,5),Fr(-1)), V(Fr(-1),Fr(1,10),Fr(-1)), V(Fr(-3),Fr(1,2),Fr(-1)), V(Fr(-1),Fr(1,3),Fr(-1,3))]:
        for eps in [Fr(1,40), Fr(1,10), Fr(1,4), Fr(1,2)]:
            X = [[p], small_cone(s, eps) + [neg(p)]]
            if is_null(X[1]) or Q_model(X): continue
            pi0, sf = naive(X)
            if pi0 is None: continue
            line = 'p=%s s=%s eps=%s : naive pi0=%s safe=%s Q_B=%s witness=%s' % (fl(p,3), fl(s,3), eps, fl(pi0,5), sf[0],
                   'empty' if sf[1]['Q_B']=='empty' else [fl(q,3) for q in sf[1]['Q_B']], sf[1]['witness'])
            out.append(line); print(line, flush=True)
            if not sf[0]: hits.append(X)
out.append('hits: %d' % len(hits))
res = []
for k, X in enumerate(hits[:3]): run('targeted naive-unsafe hit %d' % (k+1), X, res)
txt = '\n'.join(out + [''] + res); print('\n'.join(res))
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'naive_target.out'), 'w').write(txt + '\n')
