"""TS66: exact three-world geometry for the full (two-sided) domain.

Measure: density exp(-|h|_1) on R^3 (mutually absolutely continuous with Lebesgue,
finite first moment), up to a positive constant factor that is irrelevant to all checks.

A *cone* is a list of 3-vectors a meaning the open polyhedral cone {h : a.h > 0 for all a};
the empty list is the whole space R^3.  A *model* is a list of cones that are pairwise
disjoint (up to null sets).  Everything marked exact uses fractions.Fraction; floats are
used only to search for priors, and every prior is re-verified exactly.

Key facts used (PROVED in TS66_notes.md, or standard):
  * mass/moment of a polyhedral cone: split by orthant s; on orthant s, |h|_1 = s.h, the
    section {s.h = 1} of the cone is a polygon; triangulating it into triangles (g0,g1,g2)
    gives mass |det| and first moment |det|*(g0+g1+g2) (gamma integrals).
  * Q of a non-null piece {a.h > 0, a in A} is {q in Delta : q.g >= 0 for g in gens(cl)}.
  * Q_X is the intersection over non-null pieces; it is computed as a clipped polygon of
    Delta (vertex list; [] means empty).  D_Q = D_{vertices of Q}.
"""
from fractions import Fraction as Fr
from itertools import product, combinations

def V(*x): return tuple(Fr(t) for t in x)
def dot(a, b): return sum(x*y for x, y in zip(a, b))
def add(*vs): return tuple(sum(c) for c in zip(*vs))
def sub(a, b): return tuple(x-y for x, y in zip(a, b))
def sc(c, a): return tuple(c*x for x in a)
def neg(a): return tuple(-x for x in a)
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def det(a, b, c): return dot(a, cross(b, c))
E = [V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)]
ONE = V(1, 1, 1)
U3 = V(Fr(1, 3), Fr(1, 3), Fr(1, 3))
ZERO = V(0, 0, 0)

# ------------------------------------------------------------------ polygon clipping
def clip(poly, a, strict_keep=False):
    """Clip a convex polygon (list of points, possibly degenerate) by {a.x >= 0}."""
    out = []; n = len(poly)
    if n == 0: return []
    if n == 1: return list(poly) if dot(a, poly[0]) >= 0 else []
    for k in range(n):
        p, q = poly[k], poly[(k+1) % n]
        fp, fq = dot(a, p), dot(a, q)
        if fp >= 0: out.append(p)
        if fp*fq < 0:
            t = fp/(fp-fq); out.append(tuple(p[i]+t*(q[i]-p[i]) for i in range(3)))
    res = []
    for p in out:
        if p not in res: res.append(p)
    return res

# ------------------------------------------------------------------ moments
def moments(ineqs, flt=False):
    """(mass, first moment) of {a.h>0 for a in ineqs} under exp(-|h|_1) (up to a constant)."""
    if flt:
        ineqs = [tuple(float(x) for x in a) for a in ineqs]
        one, zero = 1.0, 0.0
    else:
        one, zero = Fr(1), Fr(0)
    M = zero; m = [zero, zero, zero]
    for s in product((1, -1), repeat=3):
        poly = [tuple((one*s[i] if i == k else zero) for i in range(3)) for k in range(3)]
        for a in ineqs:
            poly = clip(poly, a)
            if len(poly) < 3: break
        if len(poly) < 3: continue
        g0 = poly[0]
        for k in range(1, len(poly)-1):
            d = abs(det(g0, poly[k], poly[k+1]))
            M += d
            for i in range(3): m[i] += d*(g0[i]+poly[k][i]+poly[k+1][i])
    return M, tuple(m)

def mass(c): return moments(c)[0]
def is_null(c): return mass(c) == 0
def mom(c): return moments(c)[1]

def m_model(X, flt=False):
    tot = (0.0,)*3 if flt else (Fr(0),)*3
    for p in X: tot = add(tot, moments(p, flt)[1])
    return tot

def mass_model(X): return sum((mass(p) for p in X), Fr(0))

# ------------------------------------------------------------------ generators of closures
def _rank_null(A):
    rows = [list(a) for a in A if any(a)]
    M = [r[:] for r in rows]; piv = []; r = 0
    for c in range(3):
        p = next((i for i in range(r, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[r], M[p] = M[p], M[r]
        for i in range(len(M)):
            if i != r and M[i][c] != 0:
                f = M[i][c]/M[r][c]
                M[i] = [M[i][j]-f*M[r][j] for j in range(3)]
        piv.append(c); r += 1
    free = [c for c in range(3) if c not in piv]
    basis = []
    for fc in free:
        x = [Fr(0)]*3; x[fc] = Fr(1)
        for i, pc in enumerate(piv): x[pc] = -M[i][fc]/M[i][pc]
        basis.append(tuple(x))
    return r, basis

def generators(A):
    """Finite G with {a.h >= 0 for a in A} = cone(G); valid when the open cone is non-null."""
    A = [a for a in A if any(a)]
    rk, null = _rank_null(A)
    feas = lambda g: any(g) and all(dot(a, g) >= 0 for a in A)
    if rk == 0:
        return [*E, *map(neg, E)]
    if rk == 1:
        a = A[0]
        return [null[0], neg(null[0]), null[1], neg(null[1]), a]
    if rk == 2:
        l = null[0]; G = [l, neg(l)]
        for a in A:
            c = cross(l, a)
            for g in (c, neg(c)):
                if feas(g) and g not in G: G.append(g)
        return G
    G = []
    for a, b in combinations(A, 2):
        c = cross(a, b)
        for g in (c, neg(c)):
            if feas(g) and g not in G: G.append(g)
    return G

# ------------------------------------------------------------------ credal sets
DELTA = [E[0], E[1], E[2]]

def Q_from_gens(gens):
    poly = list(DELTA)
    for g in gens:
        poly = clip(poly, g)
        if not poly: return []
    return poly

def gens_model(X):
    gs = []
    for p in X:
        if is_null(p): continue
        for g in generators(p):
            if g not in gs: gs.append(g)
    return gs

def Q_model(X):
    """vertex list of Q_X ([] if empty)."""
    return Q_from_gens(gens_model(X))

def in_Q(q, gens): return all(dot(q, g) >= 0 for g in gens)

def Q_equal(Q1, Q2, gens1, gens2):
    """exact equality of two polygons given by vertices and defining generators."""
    return all(in_Q(q, gens2) for q in Q1) and all(in_Q(q, gens1) for q in Q2)

def shrink(QV, tau):
    """vertices (generating set) of (1-tau) Q + tau Delta."""
    return [tuple((1-tau)*q[t] + tau*(1 if t == i else 0) for t in range(3)) for q in QV for i in range(3)]

# ------------------------------------------------------------------ set operations on models
def intersect(X, cin):
    return [p + list(cin) for p in X if not is_null(p + list(cin))]

def minus(X, Nin):
    """pieces of X \\ N, N = {a.h>0 : a in Nin}; disjoint; null ones dropped."""
    if not Nin: return []
    out = []
    for p in X:
        for j, a in enumerate(Nin):
            c = p + list(Nin[:j]) + [neg(a)]
            if not is_null(c): out.append(c)
    return out

def mass_cone_minus_model(Nin, X):
    """mu(N \\ X) for N a cone and X a model."""
    M = mass(list(Nin))
    for p in X: M -= mass(p + list(Nin))
    return M

def mom_cone_minus_model(Nin, X):
    m = mom(list(Nin))
    for p in X: m = sub(m, mom(p + list(Nin)))
    return m

# ------------------------------------------------------------------ safety of a record r(N,X)
def record_safety(Nin, X):
    """Record (A,B) = (N\\X, X\\N) for coherent N = D_{Nin}.  Returns (safe, info).
    safe  <=>  Q_B empty, or mu(A n hull(B)) > 0   (TS66 Lemma 2.2)."""
    B = minus(X, Nin)
    gB = gens_model(B)
    QB = Q_from_gens(gB)
    if not QB:
        return True, {'Q_B': 'empty', 'witness': None}
    hullB = list(QB)
    w = mass_cone_minus_model(list(Nin) + hullB, X)
    return w > 0, {'Q_B': QB, 'witness': w}

# ------------------------------------------------------------------ float searches
def rat(p, den):
    a = Fr(round(p[0]*den), den); b = Fr(round(p[1]*den), den)
    return (a, b, 1-a-b)

def simplex_search(score, grid=30, tol=1e-10):
    best = (-1e18, None)
    for i in range(grid+1):
        for j in range(grid+1-i):
            p = (i/grid, j/grid, (grid-i-j)/grid)
            s = score(p)
            if s > best[0]: best = (s, p)
    s0, p = best; step = 1.0/grid
    dirs = [(1, -1, 0), (-1, 1, 0), (1, 0, -1), (-1, 0, 1), (0, 1, -1), (0, -1, 1)]
    while step > tol:
        imp = False
        for d in dirs:
            c = tuple(p[t]+step*d[t] for t in range(3))
            if min(c) < 0: continue
            s = score(c)
            if s > s0: s0, p, imp = s, c, True
        if not imp: step /= 2
    return s0, p

def lemmaE_search(X):
    """Lemma E dual: minimise the convex function int_X (lam.h)^- = -lam.m(X n {lam.h<0})
    over Delta; then report the primal value min_i -m_i(X n {lam.h<0}) at the minimiser."""
    def dual(l):
        if min(l) < 0: return -1e18
        m = m_model(intersect_f(X, [tuple(-x for x in l)]), flt=True)
        return sum(l[i]*m[i] for i in range(3))          # = -F(l); maximise
    _, l = simplex_search(dual)
    m = m_model(intersect_f(X, [tuple(-x for x in l)]), flt=True)
    return min(-x for x in m), l

def intersect_f(X, cin):
    return [p + list(cin) for p in X]

def minimax_search(Gin, mX):
    """Dual of the relative minimax: minimise the convex function
    sigma_G(pi) - pi.m(X) = pi.(m(G n {pi.h>0}) - m(X)) over Delta; at the minimiser pi*
    the primal vector m(G n {pi*.h>0}) - m(X) is >= v 1 (saddle point).  Returns
    (primal min-coordinate at the computed pi, pi)."""
    fX = [float(x) for x in mX]
    def dual(p):
        if min(p) < 0: return -1e18
        _, m = moments([p] + list(Gin), flt=True)
        return -sum(p[i]*(m[i]-fX[i]) for i in range(3))
    _, p = simplex_search(dual, tol=1e-13)
    _, m = moments([p] + list(Gin), flt=True)
    return min(m[i]-fX[i] for i in range(3)), p

def certify_prior(pf, test, dens=(10**4, 10**6, 10**8, 10**10, 10**12)):
    for den in dens:
        c = rat(pf, den)
        if min(c) < 0: continue
        if test(c): return c
    return None
