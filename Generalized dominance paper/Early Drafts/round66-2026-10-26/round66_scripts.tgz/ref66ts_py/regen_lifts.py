"""REF66_ts: regenerate the base rivals of TS66's two lifted examples (naive_case1.py, seed 5)
without running TS66's searches.  The rival sequence depends only on the RNG; we stop at the
iterations whose Q_X matches the two reported hits (6 pieces, Q_X={(5/8,1/4,1/8)}) and
(4 pieces, Q_X={(1/4,1/2,1/4)}), then form the lift with the reported s and eps=1/200."""
import sys, os, random, pickle
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'ts66py'))
from geo3 import *
from case2_check import small_cone, disjoint_union
rng = random.Random(5)
found = {}
tried = 0
for t in range(400):
    p = V(*[Fr(rng.randint(1, 6)) for _ in range(3)]); p = sc(1/sum(p), p)
    cones = []
    for _ in range(rng.randint(1, 3)):
        q = V(*[Fr(rng.randint(0, 6)) for _ in range(3)])
        if sum(q) == 0: continue
        q = sc(1/sum(q), q); cones.append([p, q])
    if not cones: continue
    X = disjoint_union(*cones)
    if rng.random() < 0.7:
        d = V(*[Fr(rng.randint(-4, 6)) for _ in range(3)])
        hole = small_cone(d, Fr(rng.randint(1, 8), 20))
        X = minus(X, hole) if hole else X
        X = [x for x in X if not is_null(x)]
    if not X: continue
    QX = Q_model(X)
    if not QX: continue
    if mass(list(QX)) == mass_model(X): continue
    tried += 1
    key = (len(X), tuple(QX))
    if len(QX) == 1 and QX[0] == V(Fr(5,8), Fr(1,4), Fr(1,8)) and len(X) == 6: found['L1'] = (t, X)
    if len(QX) == 1 and QX[0] == V(Fr(1,4), Fr(1,2), Fr(1,4)) and len(X) == 4: found['L2'] = (t, X)
    if len(found) == 2: break
print('tried', tried, {k: (v[0], len(v[1])) for k, v in found.items()})
S = {'L1': V(Fr(-4, 3), Fr(7, 3), 1), 'L2': V(Fr(5, 2), 1, -5)}
lifts = {}
for k, (t, X) in found.items():
    Ec = small_cone(S[k], Fr(1, 200))
    pieces = [Ec]
    for pc in X:
        new = []
        for c in pieces: new += minus([c], pc)
        pieces = new
    Y = list(X) + [c for c in pieces if not is_null(c)]
    lifts[k] = {'base': X, 'lift': Y, 's': S[k], 'iter': t}
    print(k, 'base pieces', len(X), 'lift pieces', len(Y), 'Q_lift empty:', not Q_model(Y))
pickle.dump(lifts, open(os.path.join(HERE, 'lifts.pkl'), 'wb'))
