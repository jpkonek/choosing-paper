"""REF66_ts check 0: the independent engine (poly3) against TS66's geo3, and sanity checks.
  (a) on 300 random open cones (2-5 random constraints): mass and first moment agree EXACTLY
      with geo3 under the L1 density;
  (b) Q of each non-null cone: poly3 (vertex generators) == geo3 (pairwise cross products),
      as polygons (mutual inclusion, exact);
  (c) known values: mu(R^3) and m(half-spaces) for both norms; m({q.h>0}) is parallel to q
      (symmetry of both densities under h -> -h gives m(R^3) = 0, hence
      m({q.h>0}) = -m({q.h<0})).
Run: python3 -I check_engine.py   (from this folder)"""
import sys, os, random
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from poly3 import *
sys.path.insert(0, os.path.join(HERE, '..', 'ts66py'))
import geo3

out = []
rng = random.Random(661)
bad = 0; nn = 0; qbad = 0
for t in range(300):
    k = rng.randint(1, 5)
    A = [vec(*[F(rng.randint(-5, 5), rng.randint(1, 3)) for _ in range(3)]) for _ in range(k)]
    A = [a for a in A if any(a)]
    M1, m1 = measure(A, 'L1')
    M2, m2 = geo3.moments(A)
    if M1 != M2 or m1 != tuple(m2): bad += 1
    if M1 > 0:
        nn += 1
        Qa = Qset([A]); Qb = geo3.Q_model([A])
        ga = gens(A); gb = geo3.gens_model([A])
        ok = all(all(dot(q, g) >= 0 for g in gb) for q in Qa) and all(all(dot(q, g) >= 0 for g in ga) for q in Qb)
        ok = ok and (bool(Qa) == bool(Qb))
        if not ok: qbad += 1
out.append('(a) 300 random cones: mass/moment disagreements with geo3 = %d' % bad)
out.append('(b) %d non-null cones: Q polygon disagreements = %d' % (nn, qbad))
for norm in ('L1', 'Linf'):
    Mall, mall = measure([], norm)
    out.append('(c) %s: mu(R^3) = %s, m(R^3) = %s' % (norm, Mall, mall))
    for q in (vec(1, 0, 0), vec(F(1, 2), F(1, 2), 0), vec(F(1, 3), F(1, 3), F(1, 3)), vec(F(1, 5), F(3, 10), F(1, 2))):
        Mh, mh = measure([q], norm); Mn, mn = measure([neg(q)], norm)
        par = cross(mh, q) == ZERO if norm == 'L1' and q in (vec(1, 0, 0), vec(F(1, 3), F(1, 3), F(1, 3))) else None
        out.append('    q=%s: mu{q.h>0}=%s (=mu/2: %s), m{q.h>0}+m{q.h<0}=0: %s%s'
                   % (tuple(map(str, q)), Mh, Mh == Mall/2, add(mh, mn) == ZERO,
                      '' if par is None else ', m parallel to q: %s' % par))
ok = bad == 0 and qbad == 0
out.append('ENGINE CHECK: %s' % ('PASS' if ok else 'FAIL'))
open(os.path.join(HERE, 'check_engine.out'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out))
