"""REF66_ts check 2b: rerun of rival C1 of ref_case1 ({h1>0} minus a hole; Q_X = {e1}) with a
larger hole, because with the thin hole (mass ~ 8e-6) the float prior search failed to produce a
certifiable prior under the L1 density (a search failure, not a counterexample: the Linf run of the
same rival is certified).  Run: python3 -I ref_case1b.py"""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from refcore import *
from ref_case2 import thin, POS, fmt
out = []
for eps in (F(1, 2), F(1, 3)):
    X = diff([[POS[0]]], thin(vec(1, -2, 1), eps))
    for norm in ('L1', 'Linf'):
        r = case1(X, norm)
        out.append('%-4s C1b {h1>0} minus hole near (1,-2,1), eps=%s: %s | Q_X=%s pi=%s tau=%s margin=%.3g gain=%.3g | N0: safe %s'
                   % (norm, eps, 'CERTIFIED' if r['ok'] else 'FAIL', [fmt(q) for q in r['QX']], fmt(r.get('pi')),
                      r.get('tau'), float(r.get('margin', 0)), float(r.get('gain', 0)), r.get('N0_safe')))
        print(out[-1], flush=True)
open(os.path.join(HERE, 'ref_case1b.out'), 'w').write('\n'.join(out) + '\n')
