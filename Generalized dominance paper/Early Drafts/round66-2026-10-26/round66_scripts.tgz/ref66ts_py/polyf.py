"""REF66_ts: float version of poly3.measure (for prior searches only; every conclusion is
re-verified exactly with poly3).  Vectorised vertex enumeration."""
from itertools import combinations, product
import math
import numpy as np

BALLF = {'L1': np.array(list(product((1, -1), repeat=3)), float),
         'Linf': np.array(((1, 0, 0), (0, 1, 0), (0, 0, 1), (-1, 0, 0), (0, -1, 0), (0, 0, -1)), float)}
_TRI = {}

def _triples(k):
    if k not in _TRI:
        _TRI[k] = np.array(list(combinations(range(k), 3)), int)
    return _TRI[k]

def measure_f(A, norm='L1'):
    A = np.array([[float(x) for x in a] for a in A if any(a)], float).reshape(-1, 3)
    if len(A): A = A / np.abs(A).max(axis=1, keepdims=True)
    S = BALLF[norm]
    N = np.vstack([A, S]); c = np.concatenate([np.zeros(len(A)), np.ones(len(S))])
    T = _triples(len(N))
    M = N[T]                                   # (t,3,3)
    d = np.linalg.det(M)
    ok = np.abs(d) > 1e-12
    M = M[ok]; rhs = c[T[ok]]
    if len(M) == 0: return 0.0, np.zeros(3)
    X = np.linalg.solve(M, rhs[..., None])[..., 0]
    feas = np.ones(len(X), bool)
    if len(A): feas &= (X @ A.T >= -1e-11).all(axis=1)
    feas &= (X @ S.T <= 1 + 1e-11).all(axis=1)
    V = X[feas]
    if len(V) == 0: return 0.0, np.zeros(3)
    # dedupe
    V = np.unique(np.round(V, 10), axis=0)
    vol = 0.0; mom = np.zeros(3)
    for s in S:
        face = V[np.abs(V @ s - 1) < 1e-9]
        if len(face) < 3: continue
        cen = face.mean(axis=0)
        t = np.array([1.0, 0, 0]) if abs(s[0]) < 0.9 else np.array([0, 1.0, 0])
        u = np.cross(s, t); w = np.cross(s, u)
        ang = np.arctan2((face - cen) @ w, (face - cen) @ u)
        face = face[np.argsort(ang)]
        v0 = face[0]; v1 = face[1:-1]; v2 = face[2:]
        dd = np.abs(np.einsum('i,ki->k', v0, np.cross(v1, v2))) / 6
        vol += dd.sum(); mom += (dd[:, None] * (v0 + v1 + v2) / 4).sum(axis=0)
    return 6 * vol, 24 * mom

def m_f(X, norm='L1'):
    t = np.zeros(3)
    for p in X: t += measure_f(p, norm)[1]
    return t
