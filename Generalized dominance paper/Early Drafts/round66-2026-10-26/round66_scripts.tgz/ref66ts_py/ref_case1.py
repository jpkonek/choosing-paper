"""REF66_ts check 2: TS66 Theorem 3.3 (Q_X nonempty) on the FULL domain R^3, with Q_X on the
boundary of Delta, lower-dimensional, precise, or equal to Delta -- cases that never arise on a
one-sided domain with K' in relint Delta.  Round-65 construction with K' replaced by Q_X:
relative minimax in G = hull(X), then the shrink N_tau = N0 n D_{(1-tau)Q_X + tau Delta}.
Exact checks: X in G a.e.; X incoherent; m(N_tau) - m(X) >> 0; mu(N_tau \\ X) > 0;
Q_{X \\ N_tau} == Q_X (polygon equality); record safe with witness mass = mu(N_tau \\ X).
Control: the unshrunk N0 (tau = 0) and its safety.  Two measures (L1, Linf).
Run: python3 -I ref_case1.py"""
import sys, os, random, time
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from refcore import *
from ref_case2 import thin, union, thin_from, POS, NEGO, U3, fmt

def rivals():
    R = []
    e1, e2, e3 = POS
    h = F(1, 10)
    R.append(('C1 {h1>0} minus hole near (1,-2,1): Q_X = {e1}?', diff([[e1]], thin(vec(1, -2, 1), h))))
    R.append(('C2 D_[e1,e2] = {h1>0,h2>0} minus hole near (1,1,-1)', diff([[e1, e2]], thin(vec(1, 1, -1), h))))
    p = vec(F(1, 2), F(1, 2), 0)
    R.append(('C3 D_{(1/2,1/2,0)} minus hole near (1,1,-3)', diff([[p]], thin(vec(1, 1, -3), F(1, 5)))))
    R.append(('C4 int R3+ minus hole near (1,1,1): Q_X = Delta', diff([[e1, e2, e3]], thin(vec(1, 1, 1), F(1, 5)))))
    q = vec(F(1, 2), 0, F(1, 2))
    R.append(('C5 D_[e1,p] u D_[e1,q], p,q on edges', union([e1, p], [e1, q])))
    R.append(('C6 D_{u} minus hole near (2,-1,0)', diff([[U3]], thin(vec(2, -1, 0), F(1, 5)))))
    R.append(('C7 D_[p,q] (edge midpoints) minus two holes',
              diff(diff([[p, q]], thin(vec(2, 1, 1), F(1, 4))), thin(vec(3, -1, -1), F(1, 10)))))
    R.append(('C8 {h1>0} u {h1<0,h2>0,h3>0 thin around (-t,1,1)}: Q_X = segment?',
              union([e1, e2], thin(vec(F(-1, 20), 1, 1), F(1, 20)))))
    rng = random.Random(663)
    k = 0
    while k < 8:
        # boundary prior shared by 1-3 coherent cones, with a hole
        i = rng.randrange(3)
        pb = [F(rng.randint(0, 4)) for _ in range(3)]; pb[i] = F(0)
        if sum(pb) == 0: continue
        pb = vec(*[x / sum(pb) for x in pb])
        cones = []
        for _ in range(rng.randint(1, 3)):
            qq = [F(rng.randint(0, 5)) for _ in range(3)]
            if sum(qq) == 0: continue
            cones.append([pb, vec(*[x / sum(qq) for x in qq])])
        if not cones: continue
        X = union(*cones)
        d = vec(*[F(rng.randint(-4, 6)) for _ in range(3)])
        if any(d):
            X = diff(X, thin(d, F(rng.randint(1, 6), 20)))
        if not X or not Qset(X): continue
        G = D(Qset(X))
        if mu([G]) == mu(X): continue   # coherent
        R.append(('C-rand%d boundary prior %s' % (k, fmt(pb)), X)); k += 1
    return R

if __name__ == '__main__':
    out = []; tot = {'L1': [0, 0], 'Linf': [0, 0]}; n0unsafe = {'L1': 0, 'Linf': 0}
    for name, X in rivals():
        for norm in ('L1', 'Linf'):
            t0 = time.time()
            r = case1(X, norm)
            tot[norm][0] += 1; tot[norm][1] += bool(r['ok'])
            if r.get('N0_safe') is False: n0unsafe[norm] += 1
            out.append('%-4s %-58s %s | Q_X=%s pi=%s tau=%s margin=%.3g gain=%.3g | N0 (no shrink): margin %.3g, safe %s (witness %s) [%.0fs]'
                       % (norm, name[:58], 'CERTIFIED' if r['ok'] else 'FAIL ' + str({k: v for k, v in r.items() if v is False}),
                          [fmt(q) for q in r['QX']], fmt(r.get('pi')), r.get('tau'), float(r.get('margin', 0)),
                          float(r.get('gain', 0)), float(r.get('N0_margin', 0)), r.get('N0_safe'),
                          None if r.get('N0_witness') is None else '%.3g' % float(r['N0_witness']), time.time() - t0))
            print(out[-1], flush=True)
    out.append('')
    out.append('SUMMARY: L1 %d/%d certified ; Linf %d/%d certified ; unshrunk N0 unsafe: L1 %d, Linf %d'
               % (tot['L1'][1], tot['L1'][0], tot['Linf'][1], tot['Linf'][0], n0unsafe['L1'], n0unsafe['Linf']))
    open(os.path.join(HERE, 'ref_case1.out'), 'w').write('\n'.join(out) + '\n')
    print(out[-1])
