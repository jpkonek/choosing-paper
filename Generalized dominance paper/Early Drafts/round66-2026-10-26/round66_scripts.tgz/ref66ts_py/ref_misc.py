"""REF66_ts check 4: smaller exact checks.
 (a) Prop 3.2(c), A_K (F61, p = u, eps = 1/2): balls of sup-radius 1/2 around x = (1,-1,-20) and
     y = (1,4,-1) lie in A_K and in {h1 > 0}; the ball of radius 1 around x + y lies outside A_K.
     Since e1 is in Q_B and hull(B) contains N_x + N_y (radius 1 around x+y), hull(B) is not in A_K.
 (b) Prop 3.2(c), U u -U with K' = conv{(.4,.3,.3),(.3,.4,.3)}: same pattern, exact margins.
 (c) Protection on R^3 (Lemma 2.3): for 200 random cone models Y and coherent C = D_Q with Q in
     {{e1}, [e1,e2], {(1/2,1/2,0)}, Delta, {u}, reversed triangle}, the record r(Y,C) is unsafe
     (it attacks C) and is guidance at all three worlds only if Y = C a.e.
 (d) Lemma E, both directions, on 40 random models: Q_X empty (clipping) <=> a certified lam with
     m(X n {lam.h<0}) << 0 exists; for Q_X nonempty, no lam on a 1/20-grid gives a certificate
     (consistent with Lemma 2.1(d)).
 (e) Safety test vs brute force on R^3: 200 random records (A,B); test "Q_B empty or
     mu(A n hull B) > 0" compared with an attack search over hull(B) and 40 coherent models D_Q.
Run: python3 -I ref_misc.py"""
import sys, os, random
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from refcore import *
from ref_case2 import thin, union, thin_from, POS, NEGO, U3, fmt
out = []; ALL = True

def box_corners(c, r):
    return [tuple(c[i] + r * s[i] for i in range(3)) for s in product((1, -1), repeat=3)]
from itertools import product

# (a) A_K
v = [vec(F(2, 3), F(1, 6), F(1, 6)), vec(F(1, 6), F(2, 3), F(1, 6)), vec(F(1, 6), F(1, 6), F(2, 3))]
def in_AK_box(c, r):
    """every h in the sup-ball B(c,r) lies in A_K (sign pattern constant on the ball; A_K is then
    defined by finitely many linear inequalities, checked at the corners)."""
    cs = box_corners(c, r)
    sg = [tuple(x > 0 for x in h) for h in cs]
    if len(set(sg)) != 1 or any(min(abs(x) for x in h) == 0 for h in cs): return None
    posk = [k for k in range(3) if sg[0][k]]
    if len(posk) <= 1: return True
    return all(dot(v[k], h) >= 0 for k in posk for h in cs)
x, y = vec(1, -1, -20), vec(1, 4, -1)
r = F(1, 2)
a1 = in_AK_box(x, r) and in_AK_box(y, r) and all(h[0] > 0 for h in box_corners(x, r) + box_corners(y, r))
s = add(x, y)
a2 = in_AK_box(s, 2 * r) is False
out.append('(a) A_K: B(x,1/2), B(y,1/2) in A_K n {h1>0}: %s ; B(x+y,1) outside A_K: %s ; v1.(x+y) = %s'
           % (a1, a2, dot(v[0], s)))
ALL &= bool(a1 and a2)
# (b) U u -U
K = [vec(F(2, 5), F(3, 10), F(3, 10)), vec(F(3, 10), F(2, 5), F(3, 10))]
x, y = vec(F(13, 5), F(-3, 2), F(19, 4)), vec(F(1, 2), F(-7, 5), F(-9, 2))
r = F(1, 20)
def minmax_on_ball(k, c, r): return dot(k, c) - r * sum(abs(t) for t in k), dot(k, c) + r * sum(abs(t) for t in k)
bx = all(minmax_on_ball(k, x, r)[0] > 0 for k in K)            # B(x,r) in U
by = all(minmax_on_ball(k, y, r)[1] < 0 for k in K)            # B(y,r) in -U
h1 = x[0] - r > 0 and y[0] - r > 0
s = add(x, y)
lo0, hi0 = minmax_on_ball(K[0], s, 2 * r); lo1, hi1 = minmax_on_ball(K[1], s, 2 * r)
outside = lo0 > 0 and hi1 < 0                                  # K[0].h > 0 > K[1].h on B(x+y, 2r)
out.append('(b) U u -U: B(x,1/20) in U: %s ; B(y,1/20) in -U: %s ; h1>0 on both: %s ; on B(x+y,1/10): k0.h in [%s,%s], k1.h in [%s,%s] -> outside U u -U: %s'
           % (bx, by, h1, lo0, hi0, lo1, hi1, outside))
ALL &= bool(bx and by and h1 and outside)

# (c) protection
rng = random.Random(664)
def rand_model():
    cones = []
    for _ in range(rng.randint(1, 3)):
        g = [vec(*[F(rng.randint(-5, 5), rng.randint(1, 2)) for _ in range(3)]) for _ in range(3)]
        if det3(*g) == 0: continue
        cones.append(thin_from(g))
    return union(*cones) if cones else []
Qs = {'{e1}': [POS[0]], '[e1,e2]': [POS[0], POS[1]], '{(1/2,1/2,0)}': [vec(F(1, 2), F(1, 2), 0)],
      'Delta': list(POS), '{u}': [U3],
      'rev.tri': [vec(F(1, 5), F(2, 5), F(2, 5)), vec(F(2, 5), F(1, 5), F(2, 5)), vec(F(2, 5), F(2, 5), F(1, 5))]}
viol = 0; tests = 0; allg = 0
for t in range(200):
    name = list(Qs)[t % len(Qs)]; C = [D(Qs[name])]
    if t % 3 == 0:
        Y = union(C[0], *[c for c in rand_model()])          # C plus extra
    elif t % 3 == 1:
        Y = diff_model(C, rand_model())                       # C minus extra
    else:
        Y = rand_model()
    A = diff_model(Y, C); B = diff_model(C, Y)
    tests += 1
    # unsafe: attacks C (B in C trivially, A n C null)
    attacks = mu(cap(A, C[0])) == 0 and all(mu(cap([p], C[0])) == mu([p]) for p in B)
    guid = all(mu(cap(A, [neg(POS[w])])) == 0 and mu(cap(B, [POS[w]])) == 0 for w in range(3))
    nonnull = mu(A) + mu(B) > 0
    if guid and nonnull: viol += 1
    if guid: allg += 1
    if not attacks: viol += 1
out.append('(c) protection on R^3: %d records r(Y,C); all attack C (unsafe); guidance at all worlds only when null: violations = %d (null records: %d)'
           % (tests, viol, allg))
ALL &= viol == 0

# (d) Lemma E both directions
rng = random.Random(665)
cnt = {'empty': 0, 'nonempty': 0}; bad = 0
grid = [(F(i, 20), F(j, 20), 1 - F(i, 20) - F(j, 20)) for i in range(21) for j in range(21 - i)]
for t in range(40):
    X = rand_model()
    if rng.random() < 0.5: X = union(*([[U3]] + X)) if X else [[U3]]
    if not X: continue
    QX = Qset(X)
    if not QX:
        cnt['empty'] += 1
        lam, _ = lemmaE(X, 'L1')
        if lam is None: bad += 1
    else:
        cnt['nonempty'] += 1
        for l in grid:
            if pos(neg(m(cap(X, [neg(l)])))): bad += 1; break
out.append('(d) Lemma E: %d models with Q_X empty, %d with Q_X nonempty; disagreements = %d' % (cnt['empty'], cnt['nonempty'], bad))
ALL &= bad == 0

# (e) safety test vs brute force
rng = random.Random(666)
fam = []
for _ in range(40):
    pts = []
    for _ in range(rng.randint(1, 3)):
        w = [F(rng.randint(0, 5)) for _ in range(3)]
        if sum(w) == 0: w = [F(1)] * 3
        pts.append(vec(*[a / sum(w) for a in w]))
    fam.append(D(pts))
agree = 0; disagree = 0; ns = 0; nu = 0
for t in range(200):
    Y = rand_model(); Z = rand_model()
    A = diff_model(Y, Z); B = diff_model(Z, Y)      # record r(Y,Z)
    sf, QB, w = safe(A, B)
    attacked = False
    cands = list(fam) + ([D(QB)] if QB else [])
    for C in cands:
        if mu(cap(A, C)) == 0 and all(mu(cap([p], C)) == mu([p]) for p in B):
            attacked = True; break
    if sf: ns += 1
    else: nu += 1
    if sf and attacked: disagree += 1
    elif (not sf) and not attacked: disagree += 1
    else: agree += 1
out.append('(e) safety test vs attack search: %d records (%d safe, %d unsafe); disagreements = %d' % (agree + disagree, ns, nu, disagree))
ALL &= disagree == 0
out.append('MISC: %s' % ('ALL PASS' if ALL else 'FAIL'))
open(os.path.join(HERE, 'ref_misc.out'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out))
