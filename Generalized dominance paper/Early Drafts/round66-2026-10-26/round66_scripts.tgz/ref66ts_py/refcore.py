"""REF66_ts: independent implementations of the two-sided constructions (exact certification).

case2(X, norm): TS66 Thm 3.4 -- any lam with m(X n {lam.h<0}) << 0 (Lemma E), X1 = X n {lam.h>0},
                G1 = hull(X1), pi from the relative minimax in G1 against m(X), N = G1 n {pi.h>0}.
case1(X, norm): TS66 Thm 3.3 -- round-65 construction with K' replaced by Q_X (relative minimax in
                G = hull(X) against m(X), then the shrink N_tau = N0 n D_{(1-tau)Q_X + tau Delta}).
Every reported property is verified in exact arithmetic with poly3; floats only find priors.
"""
from poly3 import *
from polyf import measure_f, m_f
import numpy as np
from fractions import Fraction as F

def to_simplex(a, b):
    return np.array([a, b, 1 - a - b])

def search(fun, starts=None, iters=4000):
    """minimise a convex function on Delta_3 by a shrinking pattern search (float)."""
    best = None
    grid = 12
    pts = [(i / grid, j / grid) for i in range(grid + 1) for j in range(grid + 1 - i)]
    if starts: pts += starts
    for (a, b) in pts:
        v = fun(to_simplex(a, b))
        if best is None or v < best[0]: best = (v, a, b)
    v, a, b = best; step = 1 / grid
    dirs = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, -1), (-1, 1)]
    while step > 1e-12 and iters > 0:
        imp = False
        for (da, db) in dirs:
            na, nb = a + step * da, b + step * db
            if na < 0 or nb < 0 or na + nb > 1: continue
            nv = fun(to_simplex(na, nb)); iters -= 1
            if nv < v: v, a, b, imp = nv, na, nb, True
        if not imp: step /= 2
    return v, to_simplex(a, b)

def rat(p, den):
    a = F(p[0]).limit_denominator(den); b = F(p[1]).limit_denominator(den)
    a = max(a, F(0)); b = max(b, F(0))
    if a + b > 1: b = 1 - a
    return (a, b, 1 - a - b)

def certify(pf, test, dens=(10, 100, 10**3, 10**4, 10**5, 10**6, 10**8, 10**10, 10**12)):
    for d in dens:
        c = rat(pf, d)
        if test(c): return c
    return None

def capf(X, cons): return [list(p) + list(cons) for p in X]

def lemmaE(X, norm):
    """certified rational lam in Delta with m(X n {lam.h<0}) << 0, or None."""
    def Fd(l):   # int_X (l.h)^- = -l.m(X n {l.h<0})
        return -float(l @ m_f(capf(X, [tuple(-x for x in l)]), norm))
    v, lf = search(Fd)
    lam = certify(lf, lambda l: pos(neg(m(cap(X, [neg(l)]), norm))))
    return lam, v

def minimax_in(Gcons, target_m, norm):
    """certified rational pi with m(G n {pi.h>0}) - target_m >> 0, or None (G = {g.h>0, g in Gcons})."""
    tf = np.array([float(x) for x in target_m])
    def dual(p):
        mm = measure_f(list(Gcons) + [tuple(p)], norm)[1]
        return float(p @ (mm - tf))
    v, pf = search(dual)
    pi = certify(pf, lambda p: pos(sub(measure(list(Gcons) + [p], norm)[1], target_m)))
    return pi, v

def case2(X, norm='L1'):
    r = {}
    QX = Qset(X, norm); r['QX_empty'] = not QX
    mX = m(X, norm)
    lam, vF = lemmaE(X, norm); r['lam'] = lam; r['vX_float'] = vF
    if lam is None: r['ok'] = False; return r
    L = cap(X, [neg(lam)]); mL = m(L, norm)
    r['mL<<0'] = pos(neg(mL))
    X1 = cap(X, [lam]); r['X1_null'] = (mu(X1, norm) == 0)
    Q1 = Qset(X1, norm)                       # contains lam
    r['lam_in_Q1'] = in_Q(lam, X1, norm)
    G1 = D(Q1) if X1 else [vec(1, 0, 0), vec(0, 1, 0), vec(0, 0, 1)]   # hull(null)=int R^3_+
    r['X1_coherent'] = (not r['X1_null']) and mu([G1], norm) == mu(X1, norm) and \
        all(mu(cap([p], G1), norm) == mu([p], norm) for p in X1)
    pi, vd = minimax_in(G1, mX, norm); r['pi'] = pi
    if pi is None: r['ok'] = False; return r
    N = list(G1) + [pi]
    dN = sub(measure(N, norm)[1], mX); r['margin'] = min(dN)
    A = diff([N], [])  # placeholder
    A = diff_model([N], X)              # N \ X
    B = diff([list(p) for p in X], N)   # X \ N
    r['N_misses_L'] = mu(cap([N], [neg(lam)]), norm) == 0
    r['QB_empty'] = not Qset(B, norm)
    # independent certificate that Q_B is empty: L subset of B a.e. and m(L) << 0 (Lemma 2.1(d))
    r['L_in_B'] = mu(cap(L, N), norm) == 0
    sf, QB, w = safe(A, B, norm); r['safe'] = sf
    r['gain_mass'] = mu(A, norm)
    r['ok'] = (r['QX_empty'] and r['mL<<0'] and r['lam_in_Q1'] and pos(dN) and r['N_misses_L']
               and r['QB_empty'] and r['L_in_B'] and sf)
    return r

def shrinkgen(Q, tau):
    return [tuple((1 - tau) * q[t] + tau * (1 if t == i else 0) for t in range(3)) for q in Q for i in range(3)]

def poly_eq(P1, P2):
    """equality of two convex polygons/segments/points in Delta given by vertex lists."""
    def inside(q, P):
        # q in conv(P): test via clipping P by... use barycentric LP-free test in the 2-plane
        if len(P) == 1: return q == P[0]
        if len(P) == 2:
            a, b = P; d = sub(b, a); e = sub(q, a)
            if cross(d, e) != ZERO: return False
            t = dot(e, d) / dot(d, d); return 0 <= t <= 1
        n = len(P); sgn = None
        for k in range(n):
            a, b = P[k], P[(k + 1) % n]
            c = dot(cross(sub(b, a), sub(q, a)), ONE)
            if c == 0: continue
            s = c > 0
            if sgn is None: sgn = s
            elif s != sgn: return False
        return True
    return all(inside(q, P2) for q in P1) and all(inside(q, P1) for q in P2)

def case1(X, norm='L1', taus=None):
    r = {}
    QX = Qset(X, norm); r['QX'] = QX
    if not QX: r['ok'] = False; return r
    G = D(QX); mX = m(X, norm)
    r['X_in_G'] = all(mu(cap([p], G), norm) == mu([p], norm) for p in X)
    r['incoherent'] = mu([G], norm) > mu(X, norm)
    pi, v = minimax_in(G, mX, norm); r['pi'] = pi
    if pi is None: r['ok'] = False; return r
    N0 = list(G) + [pi]
    r['N0_margin'] = min(sub(measure(N0, norm)[1], mX))
    A0 = diff_model([N0], X)
    r['N0_gain'] = mu(A0, norm)
    B0 = diff([list(p) for p in X], N0)
    s0, _, w0 = safe(A0, B0, norm); r['N0_safe'] = s0; r['N0_witness'] = w0
    r['ok'] = False
    for tau in (taus or [F(1, 10**k) for k in range(1, 10)]):
        N = N0 + shrinkgen(QX, tau)
        d = sub(measure(N, norm)[1], mX)
        if not pos(d): continue
        A = diff_model([N], X); B = diff([list(p) for p in X], N)
        gain = mu(A, norm)
        if gain == 0: continue
        QB = Qset(B, norm)
        hull_inv = bool(QB) and poly_eq(QB, QX)
        sf, _, w = safe(A, B, norm)
        r.update(tau=tau, margin=min(d), gain=gain, hull_inv=hull_inv, safe=sf, witness_eq_gain=(w == gain))
        r['ok'] = r['X_in_G'] and r['incoherent'] and hull_inv and sf and (w == gain)
        break
    return r
