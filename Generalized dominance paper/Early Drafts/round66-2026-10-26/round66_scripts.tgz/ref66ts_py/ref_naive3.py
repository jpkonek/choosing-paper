"""REF66_ts check 3c: is the TRUE minimax prior of lift L2 inside the unsafe region?
ref_naive2 shows that for lift L2 the unsafe region has a boundary within 5e-4 of pi*.
Here: (1) the extreme rays g of the pieces of Y (the only places where the combinatorics of
B = Y n {pi.h<0} can change) and min_g |pi*.g|/|g|_1; (2) exact unsafety tests on grids of radius
1e-5 and 1e-6 around the den-1e8 rounding of pi*; (3) the dual gap, which bounds |pi - pi*|.
Run: python3 -I ref_naive3.py"""
import sys, os, pickle
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from refcore import *
from ref_case2 import fmt
import numpy as np

def attack(N0, Y):
    A = diff_model([N0], Y); B = diff([list(p) for p in Y], N0)
    QB = Qset(B)
    if not QB: return False
    C = D(QB)
    return all(mu(cap([p], C)) == mu([p]) for p in B) and mu(cap(A, C)) == 0

lifts = pickle.load(open(os.path.join(HERE, 'lifts.pkl'), 'rb'))
out = []
for k in ('L2', 'L1'):
    Y = lifts[k]['lift']; mY = m(Y); tf = np.array([float(x) for x in mY])
    def dual(p): return float(p @ (measure_f([tuple(p)], 'L1')[1] - tf))
    v, pf = search(dual, iters=40000)
    p0 = rat(pf, 10**9)
    out.append('=== lift %s: pi* ~ (%.12f, %.12f, %.12f)' % (k, pf[0], pf[1], pf[2]))
    # gradient-based distance estimate: dual is smooth; numerical Hessian on the simplex plane
    h = 1e-4; e1 = np.array([1, -1, 0.]) / np.sqrt(2); e2 = np.array([1, 1, -2.]) / np.sqrt(6)
    def f(x, y): return dual(pf + x * e1 + y * e2)
    H = np.array([[f(h, 0) - 2 * f(0, 0) + f(-h, 0), (f(h, h) - f(h, -h) - f(-h, h) + f(-h, -h)) / 4],
                  [0, f(0, h) - 2 * f(0, 0) + f(0, -h)]]) / h**2
    H[1, 0] = H[0, 1]
    lmin = min(np.linalg.eigvalsh(H))
    out.append('  Hessian eigenvalues of the dual on aff Delta: %s ; float dual gap at search point ~ 1e-15 => |pi - pi*| <~ %.1e'
               % (np.round(np.linalg.eigvalsh(H), 4), np.sqrt(2e-15 / lmin)))
    gs = []
    for p in Y:
        for g in gens(p):
            gs.append((abs(float(dot(p0, g))) / float(sum(abs(x) for x in g)), g))
    gs.sort(key=lambda t: t[0])
    out.append('  smallest |pi*.g|/|g|_1 over extreme rays g of the pieces of Y: %s'
               % ', '.join('%.2e' % t[0] for t in gs[:4]))
    for r in (F(1, 10**6), F(1, 10**5), F(1, 10**4)):
        tot = uns = 0
        for i in range(-2, 3):
            for j in range(-2, 3):
                p = (p0[0] + r * F(i, 2), p0[1] + r * F(j, 2)); p = (p[0], p[1], 1 - p[0] - p[1])
                if not pos(sub(measure([p])[1], mY)): continue
                tot += 1; uns += attack([p], Y)
        out.append('  grid radius %s (step %s): %d/%d priors give an UNSAFE record' % (r, r / 2, uns, tot))
        print(out[-1], flush=True)
open(os.path.join(HERE, 'ref_naive3.out'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out))
