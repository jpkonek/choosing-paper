"""REF66_ts check 3b: the naive defender at the TRUE Brier-minimax prior.

ref_naive.py certified the first rational prior (smallest denominator) with a positive margin,
which is a Brier-dominating half-space but not the minimax one.  Here:
  * pi* = argmin over Delta of the smooth convex dual pi.(m({pi.h>0}) - m(Y)), found by a pattern
    search to 1e-13 with the float engine (L1 density, as in TS66);
  * the record of N0 = {pi.h>0} is tested exactly at: TS66's reported rational (den 10^4),
    the rational of pi* with den 10^8, and every grid prior at radius r around pi* (r = 10^-3 and
    10^-2, 5x5 grids) that still has margin >> 0;
  * the dual gap at each tested prior is reported, so 'how far from minimax' is visible.
Run: python3 -I ref_naive2.py"""
import sys, os, pickle
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from refcore import *
from ref_naive import attack_certificate
from ref_case2 import fmt
import numpy as np

lifts = pickle.load(open(os.path.join(HERE, 'lifts.pkl'), 'rb'))
ts = {'L1': (F(5065, 10000), F(2792, 10000), F(2143, 10000)), 'L2': (F(3668, 10000), F(4537, 10000), F(1795, 10000))}
out = []
for k in sorted(lifts):
    Y = lifts[k]['lift']; mY = m(Y); tf = np.array([float(x) for x in mY])
    def dual(p):
        mm = measure_f([tuple(p)], 'L1')[1]
        return float(p @ (mm - tf))
    v, pf = search(dual, iters=20000)
    out.append('=== lift %s: float minimax prior pi* = (%.10f, %.10f, %.10f), dual value %.8g' % (k, pf[0], pf[1], pf[2], v))
    cands = [('TS66 reported pi0 (den 1e4)', ts[k]), ('pi* rounded (den 1e8)', rat(pf, 10**8))]
    for r in (F(1, 1000), F(1, 100)):
        for i in range(-2, 3):
            for j in range(-2, 3):
                if i == 0 and j == 0: continue
                p0 = rat(pf, 10**8)
                p = (p0[0] + r * F(i, 2), p0[1] + r * F(j, 2)); p = (p[0], p[1], 1 - p[0] - p[1])
                if min(p) < 0: continue
                cands.append(('grid r=%s (%d,%d)' % (r, i, j), p))
    stats = {}
    for name, p in cands:
        mg = sub(measure([p])[1], mY)
        if not pos(mg):
            out.append('  %-28s pi=%s margin not >> 0 (skipped)' % (name, fmt(p))); continue
        uns, QB, AC, Am = attack_certificate([p], Y)
        gap = float(np.array([float(x) for x in p]) @ (np.array([float(x) for x in measure([p])[1]]) - tf)) - v
        key = name.split(' (')[0] if name.startswith('grid') else name
        stats.setdefault(key, [0, 0]); stats[key][0] += 1; stats[key][1] += bool(uns)
        out.append('  %-28s pi=%s min margin %.4g, dual gap %.2e: %s' % (name, fmt(p), float(min(mg)), gap,
                   'UNSAFE (attacks D_{Q_B}, mu(A n D_{Q_B}) = 0)' if uns else 'safe (witness mass %.3g)' % float(AC)))
        print(out[-1], flush=True)
    for key, (t, u) in stats.items():
        out.append('  -> %s: %d/%d unsafe' % (key, u, t))
open(os.path.join(HERE, 'ref_naive2.out'), 'w').write('\n'.join(out) + '\n')
print('\n'.join(out))
