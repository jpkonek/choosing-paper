"""REF66_ts check 1: TS66 Theorem 3.4 (Q_X empty) re-verified with the independent engine,
under TWO measures (L1 density = TS66's, and the Linf density exp(-|h|_inf)), on
  (A) TS66's 30 rivals (T1-T10 + 20 random, seed 66) and its 2 lifted naive-unsafe rivals;
  (B) new adversarial rivals:
      B1  sure loss spread thin over three thin cones (every two of them + int R^3_+ coherent),
      B2  coherent on one half-space, wild on the other,
      B3  pieces near boundary directions of Delta (near coordinate planes / -e_i / e_i),
      B5  X1 = X n {lam.h>0} null (pure sure losses), and X1 coherent.
For each rival, exact checks: Q_X empty; lam with m(X n {lam.h<0}) << 0; lam in Q_{X1};
N = hull(X1) n {pi.h>0} with m(N) - m(X) >> 0; N n {lam.h<0} null; L := X n {lam.h<0} is a.e.
inside X \\ N and m(L) << 0 (independent certificate that Q_{X\\N} is empty); Q_{X\\N} empty by
polygon clipping; record r(N,X) safe.
Run: python3 -I ref_case2.py [all|ts66|new] [start] [time limit per case, s]  (from this folder; 'ts66' takes about 1-2 hours,
'new' about 30 minutes; 'ts66' writes ref_case2_ts66.out, 'new' writes ref_case2_new.out)"""
import sys, os, pickle, random, time
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from refcore import *
sys.path.insert(1, os.path.join(HERE, '..', 'ts66py'))
from case2_check import rivals, random_rivals, small_cone, simplicial, disjoint_union

def thin(d, eps):
    """open simplicial cone around direction d (independent constructor)."""
    g = [add(d, scal(eps, sub(EE[i], vec(F(1, 3), F(1, 3), F(1, 3))))) for i in range(3)]
    if det3(*g) == 0:   # sum(d) = 0: centred generators are coplanar; use half-centred ones
        g = [add(d, scal(eps, sub(EE[i], vec(F(1, 6), F(1, 6), F(1, 6))))) for i in range(3)]
    c = add(add(g[0], g[1]), g[2]); out = []
    for k in range(3):
        a = cross(g[k], g[(k + 1) % 3])
        if dot(a, c) < 0: a = neg(a)
        out.append(a)
    return out

def union(*cones):
    X = []
    for c in cones:
        pieces = [list(c)]
        for prev in X:
            new = []
            for p in pieces: new += diff([p], prev) if prev else []
            pieces = new
        X += pieces
    return X

POS = [vec(1, 0, 0), vec(0, 1, 0), vec(0, 0, 1)]
NEGO = [neg(v) for v in POS]
U3 = vec(F(1, 3), F(1, 3), F(1, 3))

def new_rivals():
    R = []
    # B1: spread-thin sure loss.  b_j = e_j - c(1 - e_j), sum = (1-2c) 1 = -delta 1.
    for delta, eps in ((F(1, 10), F(1, 20)), (F(1, 50), F(1, 100)), (F(1, 200), F(1, 200))):
        c = (1 + delta) / 2
        b = [tuple(F(1) if i == j else -c for i in range(3)) for j in range(3)]
        R.append(('B1 int R3+ + 3 thin cones, sum b = -%s 1, eps %s' % (delta, eps),
                  union(POS, *[thin(x, eps) for x in b])))
    Kr = [vec(F(1, 5), F(2, 5), F(2, 5)), vec(F(2, 5), F(1, 5), F(2, 5)), vec(F(2, 5), F(2, 5), F(1, 5))]
    delta, eps = F(1, 20), F(1, 40)
    c = (1 + delta) / 2
    b = [tuple(F(1) if i == j else -c for i in range(3)) for j in range(3)]
    R.append(('B1b D_K(rev. triangle) + 3 thin cones, sum = -1/20 1', union(Kr, *[thin(x, eps) for x in b])))
    # B2: coherent on {pi.h>0}, wild on {pi.h<0}
    rng = random.Random(662)
    pis = [vec(F(1, 2), F(1, 3), F(1, 6)), U3, vec(F(1, 10), F(1, 10), F(4, 5))]
    for k in range(6):
        pi = pis[k % 3]
        coh = Kr + [pi]          # D_K n {pi.h>0}
        wild = []
        for _ in range(rng.randint(2, 3)):
            g = [vec(*[F(rng.randint(-6, 6), rng.randint(1, 3)) for _ in range(3)]) for _ in range(3)]
            if det3(*g) == 0: continue
            wild.append(thin_from(g) + [neg(pi)])
        R.append(('B2 coherent on {pi.h>0}, wild below (k=%d)' % k, union(coh, *wild)))
    # B3: near-boundary directions
    t = F(1, 20)
    R.append(('B3a {h1>0} + thin cone near (-1,t,t)', union([POS[0]], thin(vec(-1, t, t), F(1, 40)))))
    R.append(('B3b {h1>0} u {h1<0,h2>0,h3>0}', union([POS[0]], [NEGO[0], POS[1], POS[2]])))
    R.append(('B3c D_{[e1,e2]} + thin cone near (-t,-t,1)', union(POS[:2], thin(vec(-t, -t, 1), F(1, 50)))))
    R.append(('B3d {h1>0} + thin cones near -e2 and -e3 tilted', union([POS[0]], thin(vec(t, -1, t / 2), F(1, 50)),
                                                                      thin(vec(t / 2, t, -1), F(1, 50)))))
    R.append(('B3e D_{(1/2,1/2,0)} + thin cone near (1,-1-t,-1)', union([vec(F(1, 2), F(1, 2), 0)],
                                                                    thin(vec(1, -1 - t, -1), F(1, 50)))))
    R.append(('B3f D_{e3} + D_{e1} (two vertex Bayes acts)', union([POS[2]], [POS[0]])))
    # B5: X1 null / pure sure losses; X1 coherent
    R.append(('B5a X = -int R3+ (all sure losses)', [NEGO]))
    R.append(('B5b X = thin cone around -(1,2,3)', [thin(vec(-1, -2, -3), F(1, 10))]))
    R.append(('B5c X = int R3+ u thin sure-loss cone', union(POS, thin(vec(-1, -1, -1), F(1, 10)))))
    R.append(('B5d X = {h1>0} u -int R3+', union([POS[0]], NEGO)))
    return R

def thin_from(g):
    c = add(add(g[0], g[1]), g[2]); out = []
    for k in range(3):
        a = cross(g[k], g[(k + 1) % 3])
        if dot(a, c) < 0: a = neg(a)
        out.append(a)
    return out

def fmt(q): return None if q is None else '(%s)' % ', '.join('%.4g' % float(x) for x in q)

if __name__ == '__main__':
    # usage: python3 -I ref_case2.py [part]   part in {all (default), ts66, new}
    part = sys.argv[1] if len(sys.argv) > 1 else 'all'
    start = int(sys.argv[2]) if len(sys.argv) > 2 else 0          # skip the first `start` rivals
    limit = int(sys.argv[3]) if len(sys.argv) > 3 else 0          # per-(rival, measure) time limit, s
    import signal
    class Timeout(Exception): pass
    def _alarm(sig, frm): raise Timeout()
    signal.signal(signal.SIGALRM, _alarm)
    lifts = pickle.load(open(os.path.join(HERE, 'lifts.pkl'), 'rb'))
    R = []
    if part in ('all', 'ts66'):
        R += [('TS66 ' + n, X) for n, X in rivals() + random_rivals(20, 66)]
    if part in ('all', 'new'):
        R += [('TS66 lift %s' % k, lifts[k]['lift']) for k in sorted(lifts)]
        R += new_rivals()
    out = []; tot = {'L1': [0, 0], 'Linf': [0, 0]}; skipped = []
    R = R[start:]
    for name, X in R:
        if Qset(X, 'L1'):
            skipped.append(name); out.append('--- %s : Q_X NONEMPTY -> Case 1 (see ref_case1)' % name); continue
        for norm in ('L1', 'Linf'):
            t0 = time.time()
            if limit: signal.alarm(limit)
            try:
                r = case2(X, norm)
            except Timeout:
                out.append('%-4s %-62s TIMEOUT after %ds (prior search not completed; not a failure of the theorem)' % (norm, name[:62], limit))
                print(out[-1], flush=True); tot[norm][0] += 0; continue
            finally:
                signal.alarm(0)
            tot[norm][0] += 1; tot[norm][1] += bool(r['ok'])
            out.append('%-4s %-62s %s | lam=%s pi=%s margin=%.3g X1:%s mu(N\\X)=%.3g  [%.0fs]'
                       % (norm, name[:62], 'CERTIFIED' if r['ok'] else 'FAIL ' + str({k: v for k, v in r.items() if v is False}),
                          fmt(r.get('lam')), fmt(r.get('pi')), float(r.get('margin', 0)),
                          'null' if r.get('X1_null') else ('coherent' if r.get('X1_coherent') else 'incoh'),
                          float(r.get('gain_mass', 0)), time.time() - t0))
            print(out[-1], flush=True)
    out.append('')
    out.append('SUMMARY: L1 %d/%d certified ; Linf %d/%d certified ; skipped (Q_X nonempty): %s'
               % (tot['L1'][1], tot['L1'][0], tot['Linf'][1], tot['Linf'][0], skipped))
    open(os.path.join(HERE, 'ref_case2%s%s.out' % ('' if part == 'all' else '_' + part, '_from%d' % start if start else '')), 'w').write('\n'.join(out) + '\n')
    print(out[-1])
