"""REF66_ts: an independent exact engine for cone models in R^3.

Written from scratch for the referee; it shares no code with ts66py/geo3.py.

Measure.  For a norm ||.|| whose unit ball B is a polytope, the density exp(-||h||) gives,
for every cone C (positively homogeneous set),
    mu(C)   = 3!  * vol(C n B),
    m(C)    = 4!  * int_{C n B} h dh,
because h = r u, dh = r^2 dr dsigma(u), int_0^inf r^2 e^-r dr = 2, int_0^inf r^3 e^-r dr = 6,
and vol(C n B) = (1/3) sigma(C), int_{C n B} h = (1/4) int u dsigma.
Two norms are offered: 'L1' (the density used by TS66; then mu, m agree with geo3 exactly)
and 'Linf' (an independent measure satisfying (M), used to check that the theorems do not
depend on mu).

Polytope C n B, with C = cl{a.h > 0 : a in A}, is computed by exact vertex enumeration
(all triples of bounding planes).  vol and int h are computed by coning the facets of
C n B that do not pass through 0 from the origin (C n B is convex and contains 0).

Credal sets.  The nonzero vertices of C n B generate cl C as a cone, so
    Q_piece = {q in Delta : q.v >= 0 for every vertex v of C n B}.
Q_X is the intersection over non-null pieces (Lemma 2.1(a)); it is computed by clipping
Delta.  Exact arithmetic throughout (fractions.Fraction); floats only to search priors
and to order facet vertices cyclically.
"""
from fractions import Fraction as F
from itertools import combinations, product
import math

def vec(*x): return tuple(F(t) for t in x)
def dot(a, b): return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]
def add(a, b): return (a[0]+b[0], a[1]+b[1], a[2]+b[2])
def sub(a, b): return (a[0]-b[0], a[1]-b[1], a[2]-b[2])
def scal(c, a): return (c*a[0], c*a[1], c*a[2])
def neg(a): return (-a[0], -a[1], -a[2])
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def det3(a, b, c): return dot(a, cross(b, c))
ONE = vec(1, 1, 1)
EE = [vec(1, 0, 0), vec(0, 1, 0), vec(0, 0, 1)]
ZERO = vec(0, 0, 0)

BALL = {'L1': [tuple(F(s) for s in sg) for sg in product((1, -1), repeat=3)],
        'Linf': [EE[0], EE[1], EE[2], neg(EE[0]), neg(EE[1]), neg(EE[2])]}

def solve3(r0, r1, r2, b):
    d = det3(r0, r1, r2)
    if d == 0: return None
    # Cramer
    c0 = (r0[0], r1[0], r2[0]); c1 = (r0[1], r1[1], r2[1]); c2 = (r0[2], r1[2], r2[2])
    x = det3(b, c1, c2) / d
    y = det3(c0, b, c2) / d
    z = det3(c0, c1, b) / d
    return (x, y, z)

_cache = {}
def polytope(A, norm):
    """Vertices of {a.h >= 0 (a in A), s.h <= 1 (s in ball facets)} and the facet lists."""
    key = (tuple(A), norm)
    if key in _cache: return _cache[key]
    A = [a for a in A if any(a)]
    S = BALL[norm]
    planes = [(a, F(0)) for a in A] + [(s, F(1)) for s in S]   # plane: n.h = c
    def feas(h):
        return all(dot(a, h) >= 0 for a in A) and all(dot(s, h) <= 1 for s in S)
    # float pre-filter (loose tolerance) to find candidate triples; every vertex is then
    # recomputed and its feasibility decided in exact arithmetic.  A triple is discarded only
    # if its float solution is infeasible by more than 1e-6 (relative), so no vertex is lost.
    import numpy as _np
    fpl = [(_np.array([float(t) for t in nrm]), float(c)) for (nrm, c) in planes]
    scale = [max(1.0, float(_np.abs(nrm).max())) for (nrm, c) in fpl]
    cands = []
    for (p, q, r) in combinations(range(len(planes)), 3):
        M = _np.array([fpl[p][0], fpl[q][0], fpl[r][0]])
        if abs(_np.linalg.det(M)) < 1e-12 * scale[p] * scale[q] * scale[r]:
            cands.append((p, q, r)); continue      # near-singular: decide exactly
        x = _np.linalg.solve(M, _np.array([fpl[p][1], fpl[q][1], fpl[r][1]]))
        nx = max(1.0, float(_np.abs(x).max()))
        if all(fpl[k][0] @ x >= -1e-6 * scale[k] * nx for k in range(len(A))) and \
           all(fpl[k][0] @ x <= 1 + 1e-6 * nx for k in range(len(A), len(planes))):
            cands.append((p, q, r))
    verts = []
    for (p, q, r) in cands:
        (n0, c0), (n1, c1), (n2, c2) = planes[p], planes[q], planes[r]
        x = solve3(n0, n1, n2, (c0, c1, c2))
        if x is None or not feas(x): continue
        if x not in verts: verts.append(x)
    _cache[key] = verts
    return verts

def _order(face, normal):
    c = tuple(sum(v[i] for v in face) / len(face) for i in range(3))
    # orthonormal-ish basis of the plane (float only for ordering)
    nf = [float(t) for t in normal]
    t = [1.0, 0.0, 0.0] if abs(nf[0]) < 0.9 else [0.0, 1.0, 0.0]
    u = [nf[1]*t[2]-nf[2]*t[1], nf[2]*t[0]-nf[0]*t[2], nf[0]*t[1]-nf[1]*t[0]]
    w = [nf[1]*u[2]-nf[2]*u[1], nf[2]*u[0]-nf[0]*u[2], nf[0]*u[1]-nf[1]*u[0]]
    def ang(v):
        d = [float(v[i]-c[i]) for i in range(3)]
        return math.atan2(sum(d[i]*w[i] for i in range(3)), sum(d[i]*u[i] for i in range(3)))
    return sorted(face, key=ang)

def measure(A, norm='L1'):
    """(mu, m) of the open cone {a.h>0, a in A} for density exp(-||h||_norm), exact."""
    verts = polytope(A, norm)
    vol = F(0); mom = [F(0)]*3
    for s in BALL[norm]:
        face = [v for v in verts if dot(s, v) == 1]
        if len(face) < 3: continue
        face = _order(face, s)
        v0 = face[0]
        for k in range(1, len(face)-1):
            d = abs(det3(v0, face[k], face[k+1])) / 6
            vol += d
            for i in range(3): mom[i] += d * (v0[i] + face[k][i] + face[k+1][i]) / 4
    return 6*vol, tuple(24*x for x in mom)

def gens(A, norm='L1'):
    return [v for v in polytope(A, norm) if any(v)]

# ------------------------------------------------------------------ models
def mu(X, norm='L1'): return sum((measure(p, norm)[0] for p in X), F(0))
def m(X, norm='L1'):
    t = (F(0),)*3
    for p in X: t = add(t, measure(p, norm)[1])
    return t
def nonnull(p, norm='L1'): return measure(p, norm)[0] > 0
def cap(X, cons): return [list(p) + list(cons) for p in X if nonnull(list(p) + list(cons))]
def diff(X, Ccons):
    """X minus the open cone C = {c.h>0}; pieces disjoint, null pieces dropped."""
    if not Ccons: return []
    out = []
    for p in X:
        for j, c in enumerate(Ccons):
            q = list(p) + list(Ccons[:j]) + [neg(c)]
            if nonnull(q): out.append(q)
    return out
def diff_model(X, Y):
    out = X
    for c in Y: out = diff(out, c)
    return out

# ------------------------------------------------------------------ credal polygons
def clip(poly, g):
    out = []
    n = len(poly)
    if n == 0: return []
    if n == 1: return list(poly) if dot(g, poly[0]) >= 0 else []
    if n == 2:
        a, b = poly; fa, fb = dot(g, a), dot(g, b)
        if fa >= 0 and fb >= 0: return [a, b]
        if fa < 0 and fb < 0: return []
        t = fa/(fa-fb); x = tuple(a[i]+t*(b[i]-a[i]) for i in range(3))
        res = [a, x] if fa >= 0 else [x, b]
        return [res[0]] if res[0] == res[1] else res
    for k in range(n):
        a, b = poly[k], poly[(k+1) % n]; fa, fb = dot(g, a), dot(g, b)
        if fa >= 0: out.append(a)
        if fa*fb < 0:
            t = fa/(fa-fb); out.append(tuple(a[i]+t*(b[i]-a[i]) for i in range(3)))
    res = []
    for x in out:
        if x not in res: res.append(x)
    return res

def Qset(X, norm='L1'):
    """Vertices of Q_X ([] if empty).  Polygon/segment/point in Delta."""
    poly = list(EE)
    for p in X:
        if not nonnull(p, norm): continue
        for v in gens(p, norm):
            poly = clip(poly, v)
            if not poly: return []
    return poly

def in_Q(q, X, norm='L1'):
    return all(dot(q, v) >= 0 for p in X if nonnull(p, norm) for v in gens(p, norm))

def D(Q):
    """open cone D_Q as constraint list (Q given by a finite generating set)."""
    return [tuple(q) for q in Q]

def safe(A, B, norm='L1'):
    """TS66 Lemma 2.2 test: safe iff Q_B empty or mu(A n hull B) > 0 (on R^3).
    Returns (safe, QB, witness mass)."""
    QB = Qset(B, norm)
    if not QB: return True, [], None
    w = mu(cap(A, D(QB)), norm)
    return w > 0, QB, w

def pos(v): return all(x > 0 for x in v)
