"""REF65_hA: independent exact core for checking X65 Theorem H.1 in three worlds.

Density exp(-|h|_1) on R^3 (positive density, finite first moment).
A convex open polyhedral cone is a list of vectors a, meaning {h : a.h > 0 for all a}.
A model X is a list of such cones ("pieces"), assumed pairwise disjoint.

Everything that is labelled exact uses Fractions.  The only floating-point code is the
search for a prior pi (Step 1 of X65); every pi found is re-verified exactly.

Credal side (independent of section geometry, so it also handles non-pointed hulls):
  Q_piece  = {q in Delta : q.g >= 0 for all generators g of cl(piece)}
  Q_X      = intersection over non-null pieces.
  Q is returned as the list of its vertices (all feasible pairwise intersections of the
  constraint lines in the 2-simplex).  D_Q = D_{vertices}.
"""
from fractions import Fraction as Fr
from itertools import product, combinations

def V(*x): return tuple(Fr(t) for t in x)
def dot(a, b): return sum(x*y for x, y in zip(a, b))
def add(*vs): return tuple(sum(c) for c in zip(*vs))
def sub(a, b): return tuple(x-y for x, y in zip(a, b))
def sc(c, a): return tuple(c*x for x in a)
def neg(a): return sc(-1, a)
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def det(a, b, c): return dot(a, cross(b, c))
E3 = [V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)]
ONE = V(1, 1, 1)
u = V(Fr(1, 3), Fr(1, 3), Fr(1, 3))

# ---------------------------------------------------------------- moments (exact)
def _clip(poly, a):
    out = []; n = len(poly)
    for k in range(n):
        p, q = poly[k], poly[(k+1) % n]
        fp, fq = dot(a, p), dot(a, q)
        if fp >= 0: out.append(p)
        if fp*fq < 0:
            t = fp/(fp-fq); out.append(tuple(p[i]+t*(q[i]-p[i]) for i in range(3)))
    res = []
    for p in out:
        if not res or res[-1] != p: res.append(p)
    while len(res) > 1 and res[0] == res[-1]: res.pop()
    return res

def moments(ineqs, zero=Fr(0)):
    """(mass, first moment) of {a.h>0 all a} under exp(-|h|_1)."""
    M = zero; m = [zero]*3
    for s in product((1, -1), repeat=3):
        one = 1 if zero == 0 and isinstance(zero, float) else Fr(1)
        poly = [tuple((Fr(s[i]) if not isinstance(zero, float) else float(s[i])) if i == k else zero
                      for i in range(3)) for k in range(3)]
        for a in ineqs:
            poly = _clip(poly, a)
            if len(poly) < 3: break
        if len(poly) < 3: continue
        g0 = poly[0]
        for k in range(1, len(poly)-1):
            d = abs(det(g0, poly[k], poly[k+1]))
            M += d
            for i in range(3): m[i] += d*(g0[i]+poly[k][i]+poly[k+1][i])
    return M, tuple(m)

def fmoments(ineqs):
    return moments([tuple(float(x) for x in a) for a in ineqs], zero=0.0)

# ---------------------------------------------------------------- generators of closures
def _nullspace_rank(A):
    """rank of A (list of 3-vectors) and a basis of its null space (exact)."""
    rows = [list(a) for a in A if any(a)]
    M = [r[:] for r in rows]; piv = []; r = 0
    for c in range(3):
        p = next((i for i in range(r, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[r], M[p] = M[p], M[r]
        for i in range(len(M)):
            if i != r and M[i][c] != 0:
                f = M[i][c]/M[r][c]
                M[i] = [M[i][j]-f*M[r][j] for j in range(3)]
        piv.append(c); r += 1
    free = [c for c in range(3) if c not in piv]
    basis = []
    for fcol in free:
        x = [Fr(0)]*3; x[fcol] = Fr(1)
        for i, pc in enumerate(piv):
            x[pc] = -M[i][fcol]/M[i][pc]
        basis.append(tuple(x))
    return r, basis

def generators(ineqs):
    """A finite set G with cl{a.h>0} = {a.h>=0} = cone(G) (lines given as +-l)."""
    A = list(ineqs)
    rk, null = _nullspace_rank(A)
    feas = lambda g: all(dot(a, g) >= 0 for a in A) and any(g)
    if rk == 0:
        return [*E3, *map(neg, E3)]
    if rk == 3:
        G = []
        for a, b in combinations(A, 2):
            c = cross(a, b)
            for g in (c, neg(c)):
                if any(g) and feas(g) and g not in G: G.append(g)
        return G
    if rk == 2:
        l = null[0]
        G = [l, neg(l)]
        for a in A:
            c = cross(l, a)
            for g in (c, neg(c)):
                if any(g) and feas(g) and g not in G: G.append(g)
        return G
    # rk == 1: half-space a.h >= 0
    a = next(x for x in A if any(x))
    return [null[0], neg(null[0]), null[1], neg(null[1]), a]

# ---------------------------------------------------------------- credal polygons
def Qverts(gens):
    """vertices of {q in Delta : q.g >= 0 for g in gens} (exact).  q=(x,y,1-x-y)."""
    lines = [((g[0]-g[2], g[1]-g[2]), g[2]) for g in gens]       # c.(x,y) + d >= 0
    lines += [((Fr(1), Fr(0)), Fr(0)), ((Fr(0), Fr(1)), Fr(0)), ((Fr(-1), Fr(-1)), Fr(1))]
    pts = []
    for (c1, d1), (c2, d2) in combinations(lines, 2):
        D = c1[0]*c2[1]-c1[1]*c2[0]
        if D == 0: continue
        x = (-d1*c2[1]+d2*c1[1])/D
        y = (-c1[0]*d2+c2[0]*d1)/D
        if all(c[0]*x+c[1]*y+d >= 0 for c, d in lines):
            q = (x, y, 1-x-y)
            if q not in pts: pts.append(q)
    return pts

def is_null(ineqs):
    return moments(ineqs)[0] == 0

def Q_of(pieces):
    gens = []
    for p in pieces:
        if is_null(p): continue
        for g in generators(p):
            if g not in gens: gens.append(g)
    return Qverts(gens), gens

def in_Q(q, gens):
    return all(dot(q, g) >= 0 for g in gens)

def m_of(pieces):
    tot = (Fr(0),)*3
    for p in pieces: tot = add(tot, moments(p)[1])
    return tot

def minus(pieces, Nin):
    """pieces of (union pieces) \\ N, N = {a.h>0 : a in Nin}; disjoint; null ones dropped."""
    out = []
    for p in pieces:
        for j, a in enumerate(Nin):
            c = p + list(Nin[:j]) + [neg(a)]
            if not is_null(c): out.append(c)
    return out

def mass_N_minus_X(Nin, pieces):
    M = moments(Nin)[0]
    for p in pieces: M -= moments(p + list(Nin))[0]
    return M

def shrink_verts(QX, tau):
    return [tuple((1-tau)*q[t] + tau*(1 if t == i else 0) for t in range(3)) for q in QX for i in range(3)]

def P_of(QX, h): return min(dot(q, h) for q in QX)

# ---------------------------------------------------------------- Step-1 search (float, then exact)
def find_pi(Gin, mX, grid=60, refine=True, rng=None):
    """search pi in Delta maximising min_i (m(G n {pi.h>0}) - m(X))_i.  Returns best (score, pi)."""
    fX = [float(x) for x in mX]
    def score(pi):
        if min(pi) < 0: return -1e9
        _, m = fmoments([pi] + list(Gin))
        return min(m[i]-fX[i] for i in range(3))
    best = (-1e9, None)
    for i in range(0, grid+1):
        for j in range(0, grid+1-i):
            pi = (i/grid, j/grid, (grid-i-j)/grid)
            s = score(pi)
            if s > best[0]: best = (s, pi)
    if refine:
        s0, pi = best; step = 1.0/grid
        dirs = [(1, -1, 0), (-1, 1, 0), (1, 0, -1), (-1, 0, 1), (0, 1, -1), (0, -1, 1)]
        while step > 1e-9:
            improved = False
            for d in dirs:
                c = tuple(pi[t] + step*d[t] for t in range(3))
                s = score(c)
                if s > s0: s0, pi, improved = s, c, True
            if not improved: step /= 2
        best = (s0, pi)
    return best

def rat(pi, den=10**7):
    a = Fr(round(pi[0]*den), den); b = Fr(round(pi[1]*den), den)
    return (a, b, 1-a-b)

# ---------------------------------------------------------------- Step-1 via minimax (float, exact check later)
def find_pi_minimax(Gin, mX, iters=70):
    """max_{Y subset G} min_i (m_i(Y)-m_i(X)) = min_{lam in Delta} phi(lam),
    phi(lam) = lam.m(G n {lam.h>0}) - lam.m(X)  (convex: support function of M_G minus linear).
    Any minimiser lam* gives the maximin point z* = m(G n {lam*.h>0}) (a.e.-unique maximiser),
    so pi = lam* is the strict dominator of X65 Step 1 whenever the value is > 0."""
    fX = [float(x) for x in mX]
    G = list(Gin)
    def phi(x, y):
        lam = (x, y, 1-x-y)
        _, m = fmoments([lam] + G)
        return sum(lam[i]*(m[i]-fX[i]) for i in range(3))
    def inner(x):
        lo, hi = 0.0, 1.0-x
        for _ in range(iters):
            a = lo+(hi-lo)/3; b = hi-(hi-lo)/3
            if phi(x, a) <= phi(x, b): hi = b
            else: lo = a
        y = (lo+hi)/2
        return phi(x, y), y
    lo, hi = 0.0, 1.0
    for _ in range(iters):
        a = lo+(hi-lo)/3; b = hi-(hi-lo)/3
        if inner(a)[0] <= inner(b)[0]: hi = b
        else: lo = a
    x = (lo+hi)/2; val, y = inner(x)
    return val, (x, y, 1-x-y)
