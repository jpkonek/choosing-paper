"""REF65_hA: exact replay of X65 Theorem H.1 on adversarial three-world rivals.

For each rival X (finite disjoint union of open polyhedral cones inside U = D_{K'}):
  0. Q_X (vertices), G = hull(X) = D_{Q_X}; checks K' in Q_X and mu(G \\ X) > 0 (incoherence).
  1. Step 1: search pi with N0 = G n {pi.h>0} a strict dominator (float search, exact check).
  3. Step 3: N_tau = N0 n D_{(1-tau)Q_X + tau Delta}; exact strict margin for some tau.
  4-5. Exact: Q_{X \\ N_tau} == Q_X  (so hull(X\\N_tau) = G contains N_tau \\ X), and
       mu(N_tau \\ X) > 0.  Hence mu((N\\X) n hull(X\\N)) = mu(N\\X) > 0.
  Control (tau = 0): is Q_{X\\N0} == Q_X?  exact mass of (N0\\X) n hull(X\\N0).
  Invariance test: for random tau in (0,1) and random coherent N subset D_{Q_tau} (credal set
       conv(Q_tau u random points)), exact check Q_{X\\N} == Q_X.
"""
import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from core import *
from core import _nullspace_rank

# ------------------------------------------------------------ data
v = [V(Fr(1,5),Fr(2,5),Fr(2,5)), V(Fr(2,5),Fr(1,5),Fr(2,5)), V(Fr(2,5),Fr(2,5),Fr(1,5))]
def mix(a, b, t): return tuple((1-t)*a[i]+t*b[i] for i in range(3))
KP_TRI = [mix(vk, u, Fr(1,2)) for vk in v]          # K' = (u+K)/2 (reversed triangle)
DK = list(v)

def cone_from_gens(gens):
    """open cone over a convex polygon given by generators in cyclic order."""
    c = add(*gens); out = []
    for k in range(len(gens)):
        a = cross(gens[k], gens[(k+1) % len(gens)])
        if dot(a, c) < 0: a = neg(a)
        out.append(a)
    return out

def piece_beyond(k, delta, lam, U):
    i, j = [x for x in range(3) if x != k]
    s = add(v[i], v[j]); l = sub(v[i], v[j])
    return [neg(v[k]), add(v[k], sc(delta, s)), add(l, sc(lam, s)), add(neg(l), sc(lam, s))] + U

def small_cone(d, eps):
    """narrow open triangular cone around direction d."""
    gens = [add(d, sc(eps, sub(E3[i], u))) for i in range(3)]
    return cone_from_gens(gens)

# ------------------------------------------------------------ pipeline
def run(name, X, Kp, out, ntau=9, controls=True, inv_trials=6, rng=None):
    out.append('=== %s' % name)
    QX, gX = Q_of(X)
    assert all(in_Q(k, gX) for k in Kp), "K' not in Q_X"
    assert all(all(dot(k, g) >= 0 for g in gX) for k in Kp)
    mX = m_of(X)
    massG = moments(QX)[0]
    gap = massG - sum(moments(p)[0] for p in X)
    out.append('  |vert Q_X| = %d ; Q_X = %s' % (len(QX), [tuple(round(float(t), 4) for t in q) for q in QX]))
    rk, null = _nullspace_rank(QX)
    out.append('  cl hull(X) pointed: %s ; mu(G\\X) = %.6g (>0: incoherent)' % (rk == 3, float(gap)))
    assert gap > 0
    # X subset G a.e.: every piece lies in G (mass of piece n G equals mass of piece)
    for p in X:
        assert moments(p + list(QX))[0] == moments(p)[0], 'X not inside hull(X)'
    pi = None
    s, pif = find_pi_minimax(QX, mX)
    tries = [pif]
    for cand0 in tries:
        for den in (10**6, 10**8, 10**10, 10**12):
            cand = rat(cand0, den)
            if min(cand) < 0: continue
            d = sub(moments([cand] + QX)[1], mX)
            if all(x > 0 for x in d): pi = cand; break
        if pi: break
    if pi is None:
        s2, pif2 = find_pi(QX, mX, grid=40)
        for den in (10**6, 10**8, 10**10):
            cand = rat(pif2, den)
            if min(cand) < 0: continue
            d = sub(moments([cand] + QX)[1], mX)
            if all(x > 0 for x in d): pi = cand; break
    out.append('  Step 1 minimax value (float) = %.4g' % s)
    if pi is None:
        out.append('  Step 1: SEARCH FAILURE (float score %.3g) -- not evidence against the lemma' % s)
        return False
    d0 = sub(moments([pi] + QX)[1], mX)
    out.append('  Step 1: pi = %s ; m(N0)-m(X) = %s (exact, all > 0)' % ([round(float(t), 6) for t in pi], [float(x) for x in d0]))
    N0 = [pi] + list(QX)
    # Step 2: N0 \\ X non-null
    a0 = mass_N_minus_X(N0, X)
    out.append('  Step 2: mu(N0\\X) = %.6g > 0: %s' % (float(a0), a0 > 0))
    assert a0 > 0
    if controls:
        B0 = minus(X, N0)
        QB0, gB0 = Q_of(B0)
        same0 = all(in_Q(q, gX) for q in QB0)
        # exact witness mass for N0: (N0 \\ X) n hull(B0)
        H0 = list(QB0)
        w0 = mass_N_minus_X(N0 + H0, X)
        out.append('  Control tau=0: Q_{X\\N0} == Q_X: %s ; mu((N0\\X) n hull(X\\N0)) = %.6g' % (same0, float(w0)))
    ok = False
    for k in range(1, ntau+1):
        tau = Fr(1, 10**k)
        Nt = N0 + shrink_verts(QX, tau)
        d = sub(moments(Nt)[1], mX)
        if not all(x > 0 for x in d): continue
        B = minus(X, Nt)
        QB, gB = Q_of(B)
        same = all(in_Q(q, gX) for q in QB) and all(in_Q(q, gB) for q in QX)
        A = mass_N_minus_X(Nt, X)
        # direct witness mass, computed without using the lemma
        W = mass_N_minus_X(Nt + list(QB), X)
        out.append('  Step 3-5: tau = 1/10^%d ; m(N)-m(X) = %s ; Q_{X\\N} == Q_X: %s ; mu(N\\X) = %.6g ; mu((N\\X) n hull(X\\N)) = %.6g'
                   % (k, [float(x) for x in d], same, float(A), float(W)))
        ok = same and A > 0 and W == A
        # Steps 4-5 inequality at an explicit point a of N\\X: min_{q in Q_B} q.a >= P(a)
        break
    if not ok:
        out.append('  Steps 3-5: FAILED to certify')
        return False
    # invariance lemma test
    rng = rng or random.Random(0)
    bad = 0
    for t in range(inv_trials):
        tau = Fr(rng.randint(1, 99), 100)
        extra = []
        for _ in range(rng.randint(0, 2)):
            a = Fr(rng.randint(0, 100), 100); b = Fr(rng.randint(0, 100), 100) * (1 - a)
            extra.append((a, b, 1-a-b))
        Nin = list(set(shrink_verts(QX, tau) + extra + list(Kp)))
        B = minus(X, Nin)
        QB, gB = Q_of(B)
        if not all(in_Q(q, gX) for q in QB): bad += 1
    out.append('  Invariance lemma, %d random (tau, N subset D_{Q_tau}) : Q_{X\\N} == Q_X in all: %s' % (inv_trials, bad == 0))
    return ok and bad == 0

def rivals():
    R = []
    U = list(KP_TRI)
    # E1 spike beyond face F1 of the reversed triangle, reaching dU (X65 5.1 type)
    R.append(('E1 spike D_K u P (lateral 1/40, to dU)', [DK, piece_beyond(0, Fr(4), Fr(1, 40), U)], U))
    # E1b three spikes
    R.append(('E1b three spikes', [DK] + [piece_beyond(k, Fr(4), Fr(1, 40), U) for k in range(3)], U))
    # E2 deep hole in U (hull(X) = U)
    H = small_cone(V(2, 2, -1), Fr(1, 4))
    R.append(('E2 deep hole U \\ H', minus([U], H), U))
    # E3 boundary case of Step 1: X = U n {nu.h>0}, nu not >= 0
    nu = V(1, 1, Fr(-1, 5))
    R.append(('E3 boundary case X = U n {nu.h>0}, nu=(1,1,-1/5)', [U + [nu]], U))
    # E4 hull touching boundary directions of Delta: X subset {h1+h2>0}, minus a hole
    Ks = [mix(vk, u, Fr(3, 4)) for vk in v]
    H4 = small_cone(V(3, 3, -1), Fr(1, 3))
    R.append(('E4 Q_X meets dDelta: (U n {h1+h2>0}) \\ hole', minus([Ks + [V(1, 1, 0)]], H4), Ks))
    # E5 non-pointed hull (K'={u}): positive orthant plus four thin wedges with apex +-w
    w = V(1, -1, 0); wp = V(1, 1, -2)
    def wedge(sg, s1, s2, t):
        g0 = sc(sg, w)
        return cone_from_gens([g0, add(g0, sc(s1, wp), sc(t, ONE)), add(g0, sc(s2, wp), sc(t, ONE))])
    t = Fr(1, 10)
    X5 = [list(E3)] + [wedge(sg, a, b, t) for sg in (1, -1) for (a, b) in ((Fr(1, 10), Fr(2, 10)), (Fr(-2, 10), Fr(-1, 10)))]
    R.append(('E5 non-pointed hull: R^3_+ u four wedges at +-w (K\'={u})', X5, [u]))
    # E5b non-pointed U itself (K' a segment), deep hole: hull(X) = U contains a line
    Kseg = [V(Fr(3, 10), Fr(3, 10), Fr(4, 10)), V(Fr(4, 10), Fr(3, 10), Fr(3, 10))]
    R.append(('E5b K\' a segment (U non-pointed), deep hole', minus([list(Kseg)], small_cone(V(2, 1, -1), Fr(1, 5))), Kseg))
    # E6 comb of teeth along a face of U
    k1 = KP_TRI[0]; S = ONE; l = sub(KP_TRI[1], KP_TRI[2])
    teeth = []
    for m in range(-4, 5):
        a, b = Fr(2*m, 40), Fr(2*m+1, 40)
        teeth.append([add(l, sc(-a, S)), add(neg(l), sc(b, S)), add(neg(k1), sc(Fr(1, 20), S))])
    X6 = [U]
    for T in teeth: X6 = minus(X6, T)
    R.append(('E6 comb: U minus 9 teeth along a face', X6, U))
    # E7 union of two Bayes acts (T1 of ES64)
    p1 = (Fr(1, 5), Fr(13, 40), Fr(19, 40)); p2 = (Fr(1, 5), Fr(1, 8), Fr(27, 40))
    R.append(('E7 N_p1 u N_p2', [U + [p1]] + minus([U + [p2]], [p1]), U))
    # E8 X inside the positive orthant with a hole: Q_X = Delta
    R.append(('E8 R^3_+ minus a hole (Q_X = Delta)', minus([list(E3)], small_cone(ONE, Fr(1, 3))), U))
    # E9 coherent cone D_K plus a thin bump hugging the whole face F1 (tangential)
    R.append(('E9 D_K u full-width shallow collar beyond F1', [DK, piece_beyond(0, Fr(1, 50), Fr(1, 2), U)], U))
    return R

def random_rivals(n, rng):
    U = list(KP_TRI); R = []
    for t in range(n):
        a = Fr(rng.randint(15, 45), 100); b = Fr(rng.randint(15, 45), 100)
        pi0 = (a, b, 1-a-b)
        X = [U + [pi0]]
        for _ in range(rng.randint(0, 2)):        # bumps
            d = (Fr(rng.randint(-5, 10), 4), Fr(rng.randint(-5, 10), 4), Fr(rng.randint(-5, 10), 4))
            if dot(u, d) <= 0: continue
            Bp = small_cone(d, Fr(rng.randint(1, 4), 10)) + U
            X = X + minus([Bp], X[0]) if not is_null(Bp) else X
        for _ in range(rng.randint(0, 2)):        # holes
            d = (Fr(rng.randint(-5, 10), 4), Fr(rng.randint(-5, 10), 4), Fr(rng.randint(-5, 10), 4))
            if dot(u, d) <= 0: continue
            X = minus(X, small_cone(d, Fr(rng.randint(1, 4), 10)))
        # make pieces disjoint (bumps may overlap each other): rebuild
        dis = []
        for p in X:
            q = [p]
            for r in dis: q = minus(q, r)
            dis += q
        R.append(('R%d random Bayes act +- bumps/holes' % t, dis, U))
    return R

def main():
    out = []
    rng = random.Random(651)
    allok = True; cnt = 0; fails = []
    for name, X, Kp in rivals() + random_rivals(int(sys.argv[1]) if len(sys.argv) > 1 else 12, rng):
        try:
            QX, gX = Q_of(X)
            mG = moments(QX)[0]; mXs = sum(moments(p)[0] for p in X)
            if mG == mXs:
                out.append('=== %s : coherent, skipped' % name); continue
            ok = run(name, X, Kp, out, rng=rng)
        except AssertionError as e:
            out.append('  ASSERTION: %s' % e); ok = False
        cnt += 1
        if not ok: fails.append(name)
        print('\n'.join(out[-12:]) if False else '', end='')
    out.append('\nSUMMARY: rivals run = %d ; not certified = %s' % (cnt, fails))
    print('\n'.join(out))

if __name__ == '__main__':
    main()
