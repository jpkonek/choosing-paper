"""REF65_hA: (A) X65 Example NP (non-pointed hull) and (B) the shrink-invariance lemma in n = 3..7.

(A) X65 5.2: n = 3, K' = {u}, U = {sum h > 0}.  h = a w + b w' + g 1/sqrt3 (unit w, w').
    X = int R^3_+  u  {g > 0, g|h| < b^2 < 4 g|h|}.
    Checks (50-digit mpmath; the inequalities checked have margins >> 1e-40):
      A1  w' + eps 1 is NOT in cone(+-w) + int R^3_+   (X65's 'do not generate').
      A2  for tau = 1/10 and N_tau = D_{(1-tau){u} + tau Delta} (the Step-3 shrink of Q_X = {u}),
          two explicit points x+, x- of X, each with an open ball outside cl N_tau (so density
          points of X \\ N_tau), with  (w' + eps 1) - lam (x+ + x-) >> 0.
          So w' + eps 1 lies in hull(X \\ N_tau) (W1, sufficiency direction): the shrink handles NP.
      A3  q = u + z with z != 0 small: an explicit point of X with q.h < 0  (Q_X = {u}).
(B) Referee lemma (shrink invariance): if q in Delta and q.x >= -c P_{Q_X}(x) for a.e. x in X,
    then q in Q_X.  Consequence: Q_{X \\ N} = Q_X for every N subset D_{(1-tau)Q_X + tau Delta}.
    NUMERICS (scipy LP): X = finite union of thin cones around random directions in U,
    random K' near u, random tau in (0,1), random coherent N subset D_{Q_tau}; test
    min_{q in Q_{X\\N}} q.s >= 0 for every generator s of X.
"""
import mpmath as mp
import numpy as np
from scipy.optimize import linprog
import random
mp.mp.dps = 50

def partA():
    out = []
    s2, s3, s6 = mp.sqrt(2), mp.sqrt(3), mp.sqrt(6)
    w = mp.matrix([1/s2, -1/s2, 0]); wp = mp.matrix([1/s6, 1/s6, -2/s6]); o = mp.matrix([1/s3]*3)
    def pt(a, b, g): return a*w + b*wp + g*o
    def inX(a, b, g):
        h = pt(a, b, g); nh = mp.sqrt(a*a + b*b + g*g)
        orth = min(h) > 0
        return orth or (g > 0 and g*nh < b*b < 4*g*nh), h
    eps = mp.mpf(1)/100
    t = wp + eps*mp.matrix([1, 1, 1])
    # A1: any s w + p has third coordinate p_3 > 0, but t_3 = -2/sqrt6 + eps < 0
    out.append('A1  (w\' + eps1)_3 = %s < 0 = (s w)_3 : not in cone(+-w)+int R^3_+ : %s'
               % (mp.nstr(t[2], 8), t[2] < 0))
    tau = mp.mpf(1)/10
    g = mp.mpf(1)/10**6
    b = mp.mpf(3)/2*mp.sqrt(g)                    # b^2 = 2.25 g, inside (g|h|, 4g|h|) since |h| ~ 1
    pts = []
    for a in (1, -1):
        ok, h = inX(mp.mpf(a), b, g)
        u = mp.matrix([mp.mpf(1)/3]*3)
        Ptau = (1-tau)*(u.T*h)[0] + tau*min(h)          # P_{Q_tau}(h)
        pts.append(h)
        out.append('A2  x%s in X: %s ; P_{Q_tau}(x) = %s < 0 (outside cl N_tau, open condition)'
                   % ('+' if a > 0 else '-', ok, mp.nstr(Ptau, 8)))
    lam = 1/(2*b)
    r = t - lam*(pts[0] + pts[1])
    out.append('A2  residual (w\'+eps1) - lam(x+ + x-) = %s  >> 0: %s'
               % ([mp.nstr(x, 6) for x in r], min(r) > 0))
    # A3: Q_X = {u}: for q = u + z (z orthogonal to 1, small), find h in X with q.h < 0
    rng = random.Random(3); bad = 0
    for _ in range(20):
        z = mp.matrix([rng.uniform(-1, 1) for _ in range(3)]); z = z - (sum(z)/3)*mp.matrix([1, 1, 1])
        z = z*(mp.mpf(1)/10**3)/mp.norm(z)
        q = mp.matrix([mp.mpf(1)/3]*3) + z
        zw = (z.T*w)[0]; zwp = (z.T*wp)[0]
        found = False
        for gg in [mp.mpf(10)**(-k) for k in range(4, 40)]:
            for a in (1, -1):
                for bb in (mp.mpf(3)/2*mp.sqrt(gg), -mp.mpf(3)/2*mp.sqrt(gg)):
                    ok, h = inX(mp.mpf(a), bb, gg)
                    if ok and (q.T*h)[0] < 0: found = True; break
                if found: break
            if found: break
        bad += (not found)
    out.append('A3  20 random q = u + z, |z| = 1e-3: a point of X with q.h < 0 found for all: %s' % (bad == 0))
    return out

def partB(trials=300, seed=7):
    rng = np.random.default_rng(seed); out = []; worst = np.inf; fails = 0; nontriv = 0
    for t in range(trials):
        n = int(rng.integers(3, 8))
        uu = np.ones(n)/n
        # K' = small simplex around u
        Kp = [uu + 0.05*(np.eye(n)[i]-uu) for i in range(n)]
        # X directions: random points of U (k.h > 0 for all k in K'), biased to near dU
        S = []
        while len(S) < 4*n:
            h = rng.normal(size=n)
            m = min(k @ h for k in Kp)
            if m <= 0: h = h + (-m + abs(rng.normal())*0.05)*np.ones(n)
            if min(k @ h for k in Kp) > 0: S.append(h/np.abs(h).sum())
        S = np.array(S)
        # Q_X = {q in Delta : S q >= 0}
        def lp_min(c, A_ub, b_ub):
            r = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=np.ones((1, n)), b_eq=[1.0],
                        bounds=[(0, None)]*n, method='highs')
            return r.fun if r.status == 0 else None
        PX = np.array([lp_min(s, -S, np.zeros(len(S))) for s in S])     # P_{Q_X}(s) >= 0
        tau = rng.uniform(0.01, 0.99)
        Ptau = (1-tau)*PX + tau*S.min(axis=1)
        extra = [rng.dirichlet(np.ones(n)) for _ in range(int(rng.integers(0, 3)))]
        inN = (Ptau > 1e-12) & np.array([all(r @ s > 0 for r in extra) for s in S])
        removed = S[~inN]
        if len(removed) == 0:
            A = np.zeros((0, n)); b = np.zeros(0)
        else:
            A = -removed; b = np.zeros(len(removed))
        # Q_B = {q in Delta: q.s >= 0 for removed s}; lemma: Q_B subset Q_X, i.e. min_{Q_B} q.s >= 0 for all s in S
        mins = [lp_min(s, A if len(A) else None, b if len(A) else None) for s in S[inN]]
        m = min(mins) if mins else 0.0
        worst = min(worst, m)
        if m < -1e-9: fails += 1
        if inN.any() and (~inN).any(): nontriv += 1
    out.append('B   %d random instances, n = 3..7 (%d with both kept and removed generators):' % (trials, nontriv))
    out.append('B   min over instances of min_{q in Q_{X\\N}} q.s over kept generators s = %.3e ; violations: %d' % (worst, fails))
    return out

if __name__ == '__main__':
    print('\n'.join(partA() + partB()))
