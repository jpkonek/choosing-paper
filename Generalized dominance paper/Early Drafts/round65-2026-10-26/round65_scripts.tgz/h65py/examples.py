"""H65: run the Theorem-H construction (construct.py) on the named hard rivals of rounds 64-65.
All certificates exact (CHECKED)."""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..', 'es64py'))
from construct import *
from geom import v, U, DK, piece_beyond

def subtract(pieces, C):
    """pieces minus the open convex cone C = {c.h>0} (up to null sets)."""
    out = []
    for p in pieces:
        for i in range(len(C)):
            q = p + [neg(C[i])] + [C[l] for l in range(i)]
            if moment(q)[0] > 0: out.append(q)
    return out

# 1. ES64 Prop 3.4 bump rival: every strict Bayes dominator on the grid fails
P1 = piece_beyond(0, F(1,10), F(1,10))
construct([U+DK, P1], U, "X1 = D_K u P1 (ES64 Prop 3.4)")
# 2. full collar trade
Ps = [piece_beyond(k, F(1,10), F(1,10)) for k in range(3)]
construct([U+DK] + Ps, U, "D_K u P1 u P2 u P3 (collar)")
# 3. REF64 midpiece pieces (face midpoints)
s_dir = add(v[1], v[2]); l_dir = sub(v[1], v[2])
lam, d1, d2 = F(1,50), F(1,100), F(1,20)
M1 = [neg(v[0]), add(v[0], sc(d2, s_dir)), add(neg(v[0]), sc(-d1, s_dir)),
      add(l_dir, sc(lam, s_dir)), add(neg(l_dir), sc(lam, s_dir))] + U
assert moment(M1 + DK)[0] == 0
construct([U+DK, M1], U, "D_K u midpiece (REF64 3.4)")
# 4. WT65 Example C6 (K' = {u}: U is a half-space, not pointed)
def V(*xs): return tuple(F(x) for x in xs)
def perm(h, s): h = list(h); i, j = s; h[i], h[j] = h[j], h[i]; return tuple(h)
def simplicial(g):
    out = []
    for i in range(3):
        a, b, c = g[i], g[(i+1)%3], g[(i+2)%3]
        n = cross(a, b)
        if dot(n, c) < 0: n = neg(n)
        out.append(n)
    return out
Uc = [V(F(1,3), F(1,3), F(1,3))]
Qv = [V(F(3,5),F(1,5),F(1,5)), V(F(1,5),F(3,5),F(1,5)), V(F(1,5),F(1,5),F(3,5))]
G1 = [V(-1,3,3), V(-1,6,3), V(-1,3,6)]
holes = [G1, [perm(g,(0,1)) for g in G1], [perm(g,(0,2)) for g in G1]]
pcs = [Qv + Uc]
for Hh in holes: pcs = subtract(pcs, simplicial(Hh))
construct(pcs, Uc, "WT65 C6: D_Q minus three cones (K'={u})")
