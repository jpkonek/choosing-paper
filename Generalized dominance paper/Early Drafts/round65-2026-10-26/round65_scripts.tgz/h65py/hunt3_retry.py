"""H65: retry the construction on the hunt3 rivals where the first (coarse) search failed,
with a finer LP discretisation (search aid only) and more witness samples. Certificates exact."""
import os, sys, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..', 'es64py'))
import construct as C
from construct import *
from geom import U
M = int(sys.argv[1]) if len(sys.argv) > 1 else 100
_orig = C.lp_start
C.lp_start = lambda Gin, mX, M0=40: _orig(Gin, mX, M)
_orig2 = C.lp_start2
C.lp_start2 = lambda Gin, pieces, M0=60: _orig2(Gin, pieces, M)
R = json.load(open(os.path.join(HERE, 'hunt3_rivals.json')))
todo = [("hole",8)] if "--hole8" in sys.argv else [("deephole",5),("deephole",8),("hole",8)] if "--last" in sys.argv else [("deephole",4),("deephole",5),("deephole",8),("deephole",9),("hole",1),("hole",2),
        ("hole",7),("hole",8),("hole",9),("bump",2)]
ok = 0
for kind, k, pcs in R:
    if (kind, k) not in todo: continue
    pieces = [[tuple(F(x) for x in a) for a in p] for p in pcs]
    res = construct(pieces, U, "%s #%d (LP grid %d)" % (kind, k, M), seed=1000+k)
    sys.stdout.flush()
    ok += bool(res and res['cert'])
print("retry certified %d / %d" % (ok, len(todo)))
