"""H65: consolidated run of the final construct.py on all 30 hunt3 rivals (seed 5).
Search aids: float grid + pattern search + LP duals (cells M=60; M=120 for hole #8) + Nelder-Mead.
Every certificate printed is verified in exact rationals (CHECKED)."""
import os, sys, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..', 'es64py'))
import construct as C
from construct import *
from geom import U
_o1, _o2 = C.lp_start, C.lp_start2
R = json.load(open(os.path.join(HERE, 'hunt3_rivals.json')))
ok = 0
for kind, k, pcs in R:
    M = 120 if (kind, k) == ("hole", 8) else 60
    C.lp_start = lambda Gin, mX, M0=40, M=M: _o1(Gin, mX, M)
    C.lp_start2 = lambda Gin, pieces, M0=60, M=M: _o2(Gin, pieces, M)
    pieces = [[tuple(F(x) for x in a) for a in p] for p in pcs]
    res = construct(pieces, U, "%s #%d" % (kind, k), seed=k)
    sys.stdout.flush()
    ok += bool(res and res['cert'])
print("H65 construction certified %d / %d rivals" % (ok, len(R)))
