"""H65: run the Theorem-H construction on the 30 rivals of ES64 hunt3.py (seed 5, 10 per kind).
The rivals are dumped by hunt3_h65.py (a copy of ES64's script, same seed, which asserts that the
piece decomposition reproduces ES64's m(X) exactly) into hunt3_rivals.json.
ES64's verdicts for the same rivals are in hunt3_es64_rerun.out (identical to es64py/hunt3.out).
Certificates exact (CHECKED); the pi- and a-searches are searches."""
import os, sys, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..', 'es64py'))
from construct import *
from geom import U
R = json.load(open(os.path.join(HERE, 'hunt3_rivals.json')))
ok = 0
for kind, k, pcs in R:
    pieces = [[tuple(F(x) for x in a) for a in p] for p in pcs]
    res = construct(pieces, U, "%s #%d" % (kind, k), seed=k)
    sys.stdout.flush()
    ok += bool(res and res['cert'])
print("H65 construction certified %d / %d rivals" % (ok, len(R)))
