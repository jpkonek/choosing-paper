"""X65: exact illustration of the two-world theorem (Theorem 2D in X65_notes.md).

Two worlds, density exp(-|h|_1). Cone models only (the theorem is for all
measurable X; cones are used here because their moments are exact rationals).

Coordinates:  L-side ray h = x(1,-t), 0<t<TL ;  R-side ray h = y(-s,1), 0<s<TR.
TL*TR <= 1.  A model containing the open positive quadrant is described by a
finite union of open slope-intervals on each side.
Coherent models: N(alpha,beta) = L(0,alpha) u Q+ u R(0,beta), 0<=alpha<=TL, 0<=beta<=TR.

Moments (exact):  wedge L(t1,t2): ( I0(t2)-I0(t1), -(I1(t2)-I1(t1)) )
                  wedge R(s1,s2): ( -(I1(s2)-I1(s1)), I0(s2)-I0(s1) )
with I0(t) = -1/(1+t)^2,  I1(t) = -2/(1+t) + 1/(1+t)^2.

For each random X the script follows the proof's case split, builds the
defender N, and checks exactly:  m(N)-m(X) >= 0, != 0, and the witness
  f_L < alpha < e_L   or   f_R < beta < e_R
(equivalent to mu((N\\X) n hull(X\\N)) > 0 by Lemma 2D.1).
"""
from fractions import Fraction as F
import random

def I0(t): return -1/(1+t)**2
def I1(t): return -2/(1+t) + 1/(1+t)**2

def mL(t1, t2): return (I0(t2)-I0(t1), -(I1(t2)-I1(t1)))
def mR(s1, s2): return (-(I1(s2)-I1(s1)), I0(s2)-I0(s1))
def add(a, b): return (a[0]+b[0], a[1]+b[1])
def sub(a, b): return (a[0]-b[0], a[1]-b[1])
ZERO = (F(0), F(0))

def m_side(ivs, side):
    tot = ZERO
    for (a, b) in ivs:
        tot = add(tot, mL(a, b) if side == 'L' else mR(a, b))
    return tot

def normalise(ivs):
    ivs = sorted(ivs); out = []
    for a, b in ivs:
        if out and a <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], b))
        else:
            out.append((a, b))
    return out

def e_f(ivs):
    """e = ess sup slope; f = sup{alpha: (0,alpha) subset X}."""
    if not ivs: return F(0), F(0)
    e = ivs[-1][1]
    f = ivs[0][1] if ivs[0][0] == 0 else F(0)
    return e, f

def mN(alpha, beta): return add(mL(F(0), alpha), mR(F(0), beta))

def witness(alpha, beta, XL, XR):
    eL, fL = e_f(XL); eR, fR = e_f(XR)
    return (fL < alpha < eL) or (fR < beta < eR)

def dominates(alpha, beta, mX):
    d = sub(mN(alpha, beta), mX)
    return d[0] >= 0 and d[1] >= 0 and d != ZERO, d

def bisect_beta(target2, lo, hi, base):
    """smallest-ish rational beta in [lo,hi] with mR(lo,beta)[1] >= target2."""
    for _ in range(60):
        mid = (lo+hi)/2
        if mR(base, mid)[1] >= target2: hi = mid
        else: lo = mid
    return hi

def defender(XL, XR, TL, TR, stats):
    eL, fL = e_f(XL); eR, fR = e_f(XR)
    mX = add(m_side(XL, 'L'), m_side(XR, 'R'))
    v = sub(mN(eL, eR), mX)                       # m(hull X \ X)
    eps_list = [F(1, 2**k) for k in range(4, 40)]
    if v[0] >= 0 and v[1] >= 0:
        if v[0] > 0:
            stats['a'] += 1
            for ep in eps_list:
                al = eL - ep*(eL-fL)
                ok, d = dominates(al, eR, mX)
                if ok and d[0] > 0 and d[1] > 0: return al, eR, d
        else:
            stats['b'] += 1
            for ep in eps_list:
                be = eR - ep*(eR-fR)
                ok, d = dominates(eL, be, mX)
                if ok and d[0] > 0 and d[1] > 0: return eL, be, d
        return None
    if v[1] < 0:                                   # case (c): buy coordinate 2 on the R side
        room = mR(eR, TR)[1]
        if room >= -v[1]:
            stats['c_room'] += 1
            be = bisect_beta(-v[1], eR, TR, eR)
            for ep in eps_list:
                al = eL - ep*(eL-fL)
                ok, d = dominates(al, be, mX)
                if ok and d[0] > 0 and d[1] > 0: return al, be, d
            return None
        stats['c_noroom'] += 1
    else:                                          # case (d): v[0] < 0
        room = mL(eL, TL)[0]
        if room >= -v[0]:
            stats['d_room'] += 1
            al = bisect_alpha(-v[0], eL, TL)
            for ep in eps_list:
                be = eR - ep*(eR-fR)
                ok, d = dominates(al, be, mX)
                if ok and d[0] > 0 and d[1] > 0: return al, be, d
            return None
        stats['d_noroom'] += 1
    # no-room cases: any dominator is a witness (proof); find one by Bayes grid
    # Bayes acts N_lam = (min(lam,TL), min(1/lam,TR)), lam in (0,inf), then a
    # coarse grid over all coherent N(alpha,beta).  Any dominator found is tested.
    cands = []
    for k in range(1, 800):
        lam = F(k, 100)
        cands.append((min(lam, TL), min(1/lam, TR)))
    for i in range(0, 61):
        for j in range(0, 61):
            cands.append((TL*F(i, 60), TR*F(j, 60)))
    for al, be in cands:
        ok, d = dominates(al, be, mX)
        if ok: return al, be, d
    return None

def bisect_alpha(target1, lo, hi):
    base = lo
    for _ in range(60):
        mid = (lo+hi)/2
        if mL(base, mid)[0] >= target1: hi = mid
        else: lo = mid
    return hi

def rand_side(T, rng):
    k = rng.randint(1, 3)
    pts = sorted(set(F(rng.randint(1, 99), 100)*T for _ in range(2*k)))
    if len(pts) % 2: pts = pts[:-1]
    ivs = [(pts[i], pts[i+1]) for i in range(0, len(pts), 2)]
    if rng.random() < 0.6: ivs.append((F(0), pts[0] if pts else T/2))
    return normalise(ivs)

def main():
    rng = random.Random(65)
    stats = {'a': 0, 'b': 0, 'c_room': 0, 'c_noroom': 0, 'd_room': 0, 'd_noroom': 0}
    ok = fail = coh = 0
    for trial in range(400):
        TL = F(rng.randint(1, 9), 10) * rng.choice([F(1), F(2), F(3)])
        TR = F(rng.randint(5, 10), 10) / TL
        if TL*TR > 1: TR = 1/TL
        XL = rand_side(TL, rng); XR = rand_side(TR, rng)
        eL, fL = e_f(XL); eR, fR = e_f(XR)
        if eL == fL and eR == fR:
            coh += 1; continue                      # coherent: skip
        res = defender(XL, XR, TL, TR, stats)
        if res is None:
            fail += 1; print('FAIL', TL, TR, XL, XR); continue
        al, be, d = res
        assert 0 <= al <= TL and 0 <= be <= TR
        dom, _ = dominates(al, be, add(m_side(XL, 'L'), m_side(XR, 'R')))
        if dom and witness(al, be, XL, XR): ok += 1
        else:
            fail += 1; print('NO WITNESS', TL, TR, XL, XR, al, be)
    print('incoherent instances:', ok + fail, ' certified exactly:', ok, ' failures:', fail,
          ' (coherent skipped:', coh, ')')
    print('case counts:', stats)

if __name__ == '__main__':
    main()
