"""X65: a 'surround' rival in three worlds, exact.

Rival X = D_K u P, P a long narrow spike beyond the face F_1 of the reversed
triangle, reaching the boundary of U.  Density exp(-|h|_1); moments of polyhedral
cones are exact (es64py/cones.py).

Part 1. U-Bayes acts N_pi on a grid: which strictly dominate X, and for which
        of them is mu((N\\X) n hull(X\\N)) > 0?  (exact polygon areas in the
        section sum(h)=1).  Non-witness dominators exhibit the 'surround' shape.
Part 2. The inside-hull defender N = hull(X) n {pi.h>0} plus thin cuts at the
        vertices of hull(X) lying in cl N: exact dominance and exact witness.
Part 3. The uniform shrink of X65 Theorem H.1:
        N = hull(X) n {pi.h>0} n D_{(1-tau) Q_X + tau Delta}: exact dominance and witness.
"""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'es64py'))
from fractions import Fraction as F
from cones import moment, dot
import geom
from geom import v, U, DK, piece_beyond, add, sub, sc, neg

E = [(F(1), F(0), F(0)), (F(0), F(1), F(0)), (F(0), F(0), F(1))]

# ---------- exact convex polygons in the section sum(h) = 1 ----------
def clip(poly, a):
    out = []; n = len(poly)
    for k in range(n):
        p, q = poly[k], poly[(k+1) % n]
        fp, fq = dot(a, p), dot(a, q)
        if fp >= 0: out.append(p)
        if (fp > 0 and fq < 0) or (fp < 0 and fq > 0):
            t = fp/(fp-fq); out.append(tuple(p[i]+t*(q[i]-p[i]) for i in range(3)))
    res = []
    for p in out:
        if not res or res[-1] != p: res.append(p)
    if len(res) > 1 and res[0] == res[-1]: res.pop()
    return res

BIG = [(F(-20), F(-20), F(41)), (F(41), F(-20), F(-20)), (F(-20), F(41), F(-20))]
def poly(ineqs):
    p = list(BIG)
    for a in ineqs:
        p = clip(p, a)
        if len(p) < 3: return []
    return p

def area(p):
    if len(p) < 3: return F(0)
    s = F(0)
    for k in range(len(p)):
        a, b = p[k], p[(k+1) % len(p)]
        s += a[0]*b[1] - a[1]*b[0]
    return abs(s)/2

def hull2(points):
    pts = sorted(set(points), key=lambda p: (p[0], p[1]))
    if len(pts) <= 2: return pts
    def cr(o, a, b): return (a[0]-o[0])*(b[1]-o[1]) - (a[1]-o[1])*(b[0]-o[0])
    lo, up = [], []
    for p in pts:
        while len(lo) >= 2 and cr(lo[-2], lo[-1], p) <= 0: lo.pop()
        lo.append(p)
    for p in reversed(pts):
        while len(up) >= 2 and cr(up[-2], up[-1], p) <= 0: up.pop()
        up.append(p)
    return lo[:-1] + up[:-1]

def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])

def ineqs_of_hull(h, interior):
    """facet functionals of the cone over a convex polygon h (counter-clockwise)."""
    out = []
    for k in range(len(h)):
        q = cross(h[k], h[(k+1) % len(h)])
        if dot(q, interior) < 0: q = neg(q)
        out.append(q)
    return out

def pieces_outside(ineqsY, ineqsN):
    """convex pieces of Y \\ N (N given by inequalities)."""
    res = []
    for j, a in enumerate(ineqsN):
        p = poly(ineqsY + [neg(a)] + ineqsN[:j])
        if area(p) > 0: res.append(p)
    return res

# ---------- the rival ----------
P = piece_beyond(0, F(4), F(1, 40))     # depth up to 4*s: clipped by U, so P reaches the U-boundary
X_parts = [DK, P]                        # disjoint open cones
mX = add(moment(DK)[1], moment(P)[1])
assert area(poly(DK + P)) == 0

def witness(Nineqs):
    """mu((N\\X) n hull(X\\N)) > 0 ?  Exact, in the section."""
    pts = []
    for Y in X_parts:
        for pc in pieces_outside(Y, Nineqs):
            pts += pc
    if not pts: return False, None
    G = hull2(pts + E)
    if len(G) < 3: return False, None
    NG = poly(Nineqs + ineqs_of_hull(G, (F(1,3),)*3))
    aNG = area(NG)
    covered = sum(area(clip_all(NG, Y)) for Y in X_parts)
    return aNG > covered, aNG - covered

def clip_all(p, ineqs):
    for a in ineqs:
        p = clip(p, a)
        if len(p) < 3: return []
    return p

def strict(Nineqs):
    d = sub(moment(Nineqs)[1], mX)
    return all(x > 0 for x in d), d

def main():
    print('m(X) =', [float(x) for x in mX])
    print('P section area =', float(area(poly(P))), ' D_K area =', float(area(poly(DK))))
    # Part 1: U-Bayes grid
    tot = wit = 0; examples = []
    N = 60
    for i in range(1, N):
        for j in range(1, N-i):
            pi = (F(i, N), F(j, N), F(N-i-j, N))
            Nin = [pi] + U
            ok, d = strict(Nin)
            if not ok: continue
            tot += 1
            w, slack = witness(Nin)
            wit += w
            if not w and len(examples) < 3: examples.append((pi, d))
    print('Part 1: U-Bayes strict dominators on the 1/%d grid: %d; with witness: %d; without: %d'
          % (N, tot, wit, tot-wit))
    for pi, d in examples:
        print('   no-witness example pi =', pi, ' margin =', [float(x) for x in d])
    # Part 2: inside-hull defender
    Hpts = []
    for Y in X_parts: Hpts += poly(Y)
    G = hull2(Hpts + E)
    Gin = ineqs_of_hull(G, (F(1,3),)*3)
    print('hull(X): section vertices', len(G), '; m(hull)-m(X) =',
          [float(x) for x in sub(moment(Gin)[1], mX)])
    best = None
    def with_cuts(pi, tau):
        Nin = [pi] + Gin
        cuts = []
        for k, g in enumerate(G):
            if min(g) >= 0: continue
            if dot(pi, g) < 0: continue            # vertex already outside cl N: no cut needed
            q = Gin[k]                             # facet through g and the next vertex
            sq = sum(q); q = tuple(x/sq for x in q)
            i = min(range(3), key=lambda t: g[t])
            cuts.append(tuple((1-tau)*q[t] + tau*(1 if t == i else 0) for t in range(3)))
        return Nin + cuts, len(cuts)
    # strict G-Bayes dominators are rare here: symmetric line search pi = (1-2p, p, p)
    sym = []
    for k in range(3900, 4100):
        p = F(k, 10000)
        pi = (1-2*p, p, p)
        ok, d = strict([pi] + Gin)
        if ok: sym.append((min(d), pi, d))
    sym.sort(reverse=True)
    print('Part 2: strict G-Bayes dominators on the line pi=(1-2p,p,p), p in [0.39,0.41), step 1e-4:', len(sym))
    for _, pi, _ in sym[:1]:
        for tau in [F(1, 10**k) for k in range(2, 9)]:
            Nin, nc = with_cuts(pi, tau)
            ok, d = strict(Nin)
            if not ok: continue
            w, slack = witness(Nin)
            if w:
                best = (pi, d, slack, tau, nc); break
    if best:
        pi, d, slack, tau, nc = best
        print('Part 2: inside-hull defender hull(X) n {pi.h>0} with', nc, 'thin cuts (tau = %s), pi =' % tau, pi)
        print('   m(N)-m(X) =', [float(x) for x in d], ' (all > 0, exact)')
        print('   section area of (N\\X) n hull(X\\N) =', float(slack), '> 0 (exact)')
    # Part 3: the uniform shrink of X65 Theorem H (no vertex-by-vertex cuts):
    #   N = hull(X) n {pi.h>0} n D_{(1-tau)Q_X + tau*Delta}
    if sym:
        pi = sym[0][1]
        QX = []
        for q in Gin:
            sq = sum(q); QX.append(tuple(x/sq for x in q))
        for tau in [F(1, 10**k) for k in range(2, 9)]:
            shr = [tuple((1-tau)*q[t] + tau*(1 if t == i else 0) for t in range(3)) for q in QX for i in range(3)]
            Nin = [pi] + Gin + shr
            ok, d = strict(Nin)
            if not ok: continue
            w, slack = witness(Nin)
            print('Part 3: uniform shrink, tau = %s: m(N)-m(X) =' % tau, [float(x) for x in d],
                  '; witness:', w, '; section area of (N\\X) n hull(X\\N) =', float(slack))
            if w: break
    best = None
    for i in range(1, N):
        for j in range(1, N-i):
            pi = (F(i, N), F(j, N), F(N-i-j, N))
            Nin = [pi] + Gin
            ok, d = strict(Nin)
            if not ok: continue
            w, slack = witness(Nin)
            if w:
                best = (pi, d, slack); break
        if best: break
    if best:
        pi, d, slack = best
        print('Part 2: inside-hull defender hull(X) n {pi.h>0}, pi =', pi)
        print('   m(N)-m(X) =', [float(x) for x in d], ' (all > 0, exact)')
        print('   section area of (N\\X) n hull(X\\N) =', float(slack), '> 0 (exact)')
    else:
        print('Part 2b: (no inside-hull defender without cuts on this grid; cuts are needed)')

if __name__ == '__main__':
    main()
