"""REF64_es: exhaustive finite-atom check of ES64's deletion relation Delta(N).
Atoms carry constant payoff vectors h_a in Z^3 (unit mass); a model is a set of atoms; m(X) = sum h_a.
Records r(X,Y) = (X\\Y, Y\\X).  Br_i, G_i, script-R, i(r), Del_i, Acc_i exactly as in ES64 Def 3.1.
'Coherent' = a declared family N; every member contains the all-positive atom a0 (as every D_Q
contains int R^3_+).  Checks, over ALL pairs/triples of the 2^8 models:
  reflexivity; strict (G); (TC); finite-chain (Suzumura) consistency; non-transitivity;
  Thm 3.2(i) (members of N have no weak dominator); (star) => undominated = N and every
  X notin N dominated by a member; converse: undominated = N and N-dominance of all X
  notin N  =>  (star)   [necessity of (star) within Delta(N)];
  disjoint additivity (Add) and (TP) failures are counted."""
import numpy as np, itertools, random

H = np.array([(2,2,2),(3,-1,-1),(-1,3,-1),(-1,-1,3),(2,1,-2),(1,-2,2),(-2,2,1),(1,1,-1)])
n = len(H); M = 1 << n
masks = np.arange(M)
bits = ((masks[:,None] >> np.arange(n)) & 1).astype(np.int64)
mvec = bits @ H                                   # m(X)
POS = [sum(1<<a for a in range(n) if H[a,i] > 0) for i in range(3)]
NEG = [sum(1<<a for a in range(n) if H[a,i] < 0) for i in range(3)]
def m_of(S): return mvec[S]

def build(Nfam):
    Nset = set(Nfam)
    # script-R: records (A,B) disjoint, nonnull, m(A)>=m(B) coordinatewise, attacking some member
    def attacks(A,B):
        return any((B & ~Z) == 0 and (A & Z) == 0 for Z in Nfam)
    def guided(A,B,i): return (A & ~POS[i]) == 0 and (B & ~NEG[i]) == 0
    def iworld(A,B):
        mA, mB = m_of(A), m_of(B)
        for i in range(3):
            if mA[i] > mB[i] and not guided(A,B,i): return i
        for i in range(3):
            if not guided(A,B,i): return i
        return None
    Del = [set(), set(), set()]
    for A in range(M):
        for B in range(M):
            if A & B or (A|B) == 0: continue
            if np.all(m_of(A) >= m_of(B)) and attacks(A,B):
                i = iworld(A,B)
                assert i is not None, "no deletion world"
                Del[i].add((A,B))
                if m_of(A)[i] == m_of(B)[i]: Del[i].add((B,A))
    L = np.zeros((3,M,M), dtype=bool)
    for X in range(M):
        for Y in range(M):
            A, B = X & ~Y, Y & ~X
            for i in range(3):
                L[i,X,Y] = (m_of(A)[i] >= m_of(B)[i]) and (A,B) not in Del[i]
    return L, Del

def closure(R):
    T = R.copy()
    for k in range(M):
        T |= T[:,k][:,None] & T[k,:][None,:]
    return T

def check(Nfam, verbose=True):
    L, Del = build(Nfam)
    res = {}
    res['refl'] = all(L[i].diagonal().all() for i in range(3))
    g_ok = True
    for i in range(3):
        for X in range(M):
            for Y in range(M):
                A,B = X&~Y, Y&~X
                if (A|B) and (A & ~POS[i])==0 and (B & ~NEG[i])==0:
                    if not (L[i,X,Y] and not L[i,Y,X]): g_ok=False
    res['strictG'] = g_ok
    tc = fcc = True; nontrans = 0
    for i in range(3):
        R = L[i]; S = R & ~R.T
        R2 = (R.astype(np.int32) @ R.astype(np.int32)) > 0
        if (R2 & S.T).any(): tc = False
        T = closure(R)
        if (T & S.T).any(): fcc = False
        nontrans += int((R2 & ~R).sum())
    res['TC'] = tc; res['FCC'] = fcc; res['nontransitive_pairs'] = nontrans
    WD = L[0] & L[1] & L[2]                               # WD[Y,X]: Y weakly dominates X
    D = WD & ~(L[0].T & L[1].T & L[2].T)                  # Y dominates X
    undom = [X for X in range(M) if not D[:,X].any()]
    res['members_no_weak_dominator'] = all(not WD[[Y for Y in range(M) if Y != Z], Z].any() for Z in Nfam)
    def star(X):
        for Z in Nfam:
            A, B = Z & ~X, X & ~Z
            if np.all(m_of(Z) >= m_of(X)) and np.any(m_of(Z) != m_of(X)) and \
               not any((B & ~W)==0 and (A & W)==0 for W in Nfam):
                return True
        return False
    others = [X for X in range(M) if X not in set(Nfam)]
    star_all = all(star(X) for X in others)
    cover_like = set(undom) == set(Nfam) and all(any(D[Z,X] for Z in Nfam) for X in others)
    res['star_all'] = star_all; res['undom==N_and_N_dominates_rest'] = cover_like
    res['star<=>cover_like'] = (star_all == cover_like)
    # per-model equivalence: X dominated by a member  <=>  star(X)
    res['per_model_equiv'] = all(star(X) == any(D[Z,X] for Z in Nfam) for X in others)
    # (Add): disjoint accepted records whose union is refused
    add_fail = 0
    for i in range(3):
        acc = [(A,B) for A in range(M) for B in range(M) if not (A&B) and L[i, A, B]]
        # realize record (A,B) by models (A,B)
        accset = set(acc)
        for (A1,B1) in random.sample(acc, min(len(acc), 600)):
            for (A2,B2) in random.sample(acc, min(len(acc), 600)):
                if (A1|B1) & (A2|B2): continue
                if (A1|A2, B1|B2) not in accset: add_fail += 1
    res['Add_failures(sampled)'] = add_fail
    # (TP): Y<=X and X pointwise at least as good at i as M  =>  Y<=M
    tp_fail = 0
    for i in range(3):
        for X in range(M):
            for Mm in range(M):
                A,B = X&~Mm, Mm&~X
                if (A & ~POS[i])==0 and (B & ~NEG[i])==0:
                    tp_fail += int((L[i][:,X] & ~L[i][:,Mm]).sum())
    res['TP_failures'] = tp_fail
    res['n_undominated'] = len(undom); res['|N|'] = len(Nfam)
    if verbose: print(res)
    return res

random.seed(5)
a0 = 1
fams = []
# family 1: 'all models containing a0 that are Brier-Pareto-maximal or near' -- arbitrary declared family
fams.append(sorted({a0, a0|0b1110, a0|0b1110000, a0|0b10, a0|0b100, a0|0b1000}))
fams.append(sorted({X for X in range(M) if X & a0 and bin(X).count('1') <= 2}))
for _ in range(3):
    fams.append(sorted({a0} | {X | a0 for X in random.sample(range(M), 12)}))
allok = True
for k, fam in enumerate(fams):
    print("family", k, "size", len(fam))
    r = check(fam)
    allok = allok and r['refl'] and r['strictG'] and r['TC'] and r['FCC'] and \
            r['members_no_weak_dominator'] and r['star<=>cover_like'] and r['per_model_equiv']
print("ALL STRUCTURAL CHECKS PASS:", allok)

# Positive direction: N := Brier-Pareto-optimal models (atom analogue of the Bayes acts; Lemma 3.3
# says improving records never attack them, so (star) must hold and undominated must equal N).
par = [X for X in range(M) if not any(np.all(mvec[Y] >= mvec[X]) and np.any(mvec[Y] != mvec[X]) for Y in range(M))]
par = [X for X in par if X & a0]
print("Pareto family size", len(par))
r = check(par)
print("PARETO FAMILY: star_all and undominated == N:", r['star_all'] and r['undom==N_and_N_dominates_rest'])
# add one non-Pareto member (a 'protected target') and report what happens
extra = next(X for X in range(M) if X & a0 and X not in par and bin(X).count('1') >= 4)
r2 = check(sorted(set(par) | {extra}))
print("Pareto + one protected non-Pareto model: star_all =", r2['star_all'], " undominated =", r2['n_undominated'])
