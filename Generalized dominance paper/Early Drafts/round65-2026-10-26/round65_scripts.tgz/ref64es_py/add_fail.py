"""REF64_es: the deletion relation Delta(N) violates DISJOINT ADDITIVITY at world 1
(two accepted records with disjoint supports whose union is refused), while it satisfies
finite-chain (Suzumura) consistency by construction.
N := D_{Q_t}, t = 3/23 (ES64's defender); D := N \\ D_K.  Split D = S1 u S2 (disjoint), with
S1 := (D cap {v2.h<0}) u (D cap {v1.h<0} cap {lateral side})  [a lateral sub-cone of the face-1 piece],
S2 := D \\ S1.  We need, exactly:
  (a) m_1(S1) >= 0 and m_1(S2) >= 0          (both records (S,{}) are Brier-accepted at world 1)
  (b) m(S1) and m(S2) each have a negative coordinate  (so neither record is in script-R: never deleted;
      neither is a tie-inverse since it is not a Brier tie at the relevant world / m(S)<=0 fails)
  (c) m(D) >> 0 and (D,{}) attacks D_K, so (D,{}) is in script-R; it is not guided at world 1
      (D meets {h_1<0}); and m_1(D)>0, so i((D,{})) = 1: deleted at world 1.
Models: Y0 := D_K, Y1 := D_K u S2, Y2 := N.  Y2 <=_1 Y1 (record (S1,{})), Y1 <=_1 Y0 (record (S2,{})),
but not Y2 <=_1 Y0.  The two steps have disjoint supports (no cancellation)."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from xcone import *

t = Fr(3,23)
Q = [mix(vk,u,t) for vk in v]
Nc = Q + U
# D = N minus D_K. Pieces by sign of v_k.h. First check overlaps are null.
pieces = [Nc + [neg(v[k])] for k in range(3)]
ov = [mass(Nc + [neg(v[a]), neg(v[b])]) for a,b in ((0,1),(0,2),(1,2))]
print("overlap masses N cap {v_a.h<0, v_b.h<0}:", [float(x) for x in ov])
mD = sub(mom(Nc), mom(Nc + DK))
print("m(N\\D_K) =", f(mD), " (ES64: 0.0287955708 each)")
mP = [mom(p) for p in pieces]
print("face pieces m(D cap {v_k.h<0}):", [f(x) for x in mP])
# overlaps are non-null (near the corners), so use a disjoint decomposition below.
p2 = mom(Nc + [neg(v[1])])                                  # D cap {v2.h<0}

# lateral split of the face-1 piece: lateral l = (v2-v3).h, s = (v2+v3).h; side {l > c s}
s_dir = add(v[1],v[2]); l_dir = sub(v[1],v[2])
best=None
for num in range(-100,101):
    c = Fr(num,100)
    side = Nc + [neg(v[0]), v[1], sub(l_dir, sc(c,s_dir))]   # v1.h<0, v2.h>0, l - c s > 0
    m_side = mom(side)
    S1 = add(p2, m_side)
    S2 = sub(mD, S1)
    ok = S1[0] >= 0 and S2[0] >= 0 and min(S1) < 0 and min(S2) < 0
    if ok:
        best=(c,S1,S2); break
c,S1,S2 = best
print("split parameter c =", c)
print("m(S1) =", f(S1), " m(S2) =", f(S2))
print("(a) m_1(S1)>=0:", S1[0]>=0, " m_1(S2)>=0:", S2[0]>=0)
print("(b) S1 has negative coord:", min(S1)<0, " S2 has negative coord:", min(S2)<0)
gd1 = mass(Nc + [neg(v[1]), neg(e[0])])     # D meets {h_1 < 0}? (inside face-2 piece)
print("(c) m(D)>>0:", min(mD)>0, "; mass(D cap {h_1<0}) >= ", float(gd1), ">0:", gd1>0, "; m_1(D)>0:", mD[0]>0)
print("DISJOINT ADDITIVITY FAILS AT WORLD 1:", all([S1[0]>=0,S2[0]>=0,min(S1)<0,min(S2)<0,min(mD)>0,gd1>0]))
