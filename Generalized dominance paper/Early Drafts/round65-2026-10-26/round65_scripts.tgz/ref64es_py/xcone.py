"""Independent exact moments of polyhedral cones in R^3 under density exp(-|h|_1).
Re-implementation (referee REF64_es); does not import es64py.
A cone is a list of vectors a; the cone is {h : a.h > 0 for all a}.
Method: in each orthant s, the cross-section {h: s.h = 1, s_i h_i >= 0} is a triangle;
clip it by the half-planes, triangulate; for a simplex cone(g1,g2,g3) with s.g_k = 1,
  mass = |det| * Gamma(3)/2! ... we use  int_{cone} e^{-s.h} dh = |det G| and
  int_{cone} h e^{-s.h} dh = |det G| (g1+g2+g3)   (substitute h = G t, t >= 0).
Exact rationals throughout."""
from fractions import Fraction as Fr
from itertools import product

def V(*x): return tuple(Fr(t) for t in x)
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def add(*vs): return tuple(sum(c) for c in zip(*vs))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def sc(c,a): return tuple(c*x for x in a)
def neg(a): return sc(-1,a)
def det(a,b,c):
    return (a[0]*(b[1]*c[2]-b[2]*c[1]) - a[1]*(b[0]*c[2]-b[2]*c[0]) + a[2]*(b[0]*c[1]-b[1]*c[0]))

def _clip(poly, a):
    out=[]; n=len(poly)
    for k in range(n):
        p,q = poly[k], poly[(k+1)%n]
        fp,fq = dot(a,p), dot(a,q)
        if fp >= 0: out.append(p)
        if fp*fq < 0:
            t = fp/(fp-fq); out.append(tuple(p[i]+t*(q[i]-p[i]) for i in range(3)))
    res=[]
    for p in out:
        if not res or res[-1]!=p: res.append(p)
    while len(res)>1 and res[0]==res[-1]: res.pop()
    return res

def moments(ineqs):
    M = Fr(0); m=[Fr(0)]*3
    for s in product((1,-1),repeat=3):
        poly=[tuple(Fr(s[i]) if i==k else Fr(0) for i in range(3)) for k in range(3)]
        for a in ineqs:
            poly=_clip(poly,a)
            if len(poly)<3: break
        if len(poly)<3: continue
        g0=poly[0]
        for k in range(1,len(poly)-1):
            d=abs(det(g0,poly[k],poly[k+1]))
            M+=d
            for i in range(3): m[i]+=d*(g0[i]+poly[k][i]+poly[k+1][i])
    return M, tuple(m)

def mom(ineqs): return moments(ineqs)[1]
def mass(ineqs): return moments(ineqs)[0]
def f(x): return [float(t) for t in x]

# reversed-triangle data (as in the brief)
v = [V(Fr(1,5),Fr(2,5),Fr(2,5)), V(Fr(2,5),Fr(1,5),Fr(2,5)), V(Fr(2,5),Fr(2,5),Fr(1,5))]
u = V(Fr(1,3),Fr(1,3),Fr(1,3))
def mix(a,b,t): return tuple((1-t)*a[i]+t*b[i] for i in range(3))
Kp = [mix(vk,u,Fr(1,2)) for vk in v]       # K' = (K+u)/2, as in ES64
U = list(Kp)
DK = list(v)
e = [V(1,0,0),V(0,1,0),V(0,0,1)]
