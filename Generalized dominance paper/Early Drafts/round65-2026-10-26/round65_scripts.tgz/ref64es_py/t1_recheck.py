"""REF64_es: independent strict re-check of the two printed T1 certificates (ES64 5.5(i), t1c.out).
X = N_p1 u N_p2 (union of two Bayes acts), defender N_q.  Checks with STRICT inequalities:
 m(N_q) - m(X) >> 0;  a in U, q.a>0, p1.a<0, p2.a<0  (open nbhd of a lies in N_q \\ X);
 b1 in U, p1.b1>0, q.b1<0 (density point of X \\ N_q);  b2 in U, p2.b2>0, q.b2<0;
 a - (l1 b1 + l2 b2) in int R^3_+ for some l >= 0  (Lemma 5.3), solved exactly by LP-free search:
 we test a in relint conv{b1,b2,e1,e2,e3} in the plane sum=1 via barycentric feasibility."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from xcone import *
from fractions import Fraction as Fr
import itertools

cases = [
 ((Fr(1,5),Fr(13,40),Fr(19,40)), (Fr(1,5),Fr(1,8),Fr(27,40)), ('53449/250000','77587/250000','29741/62500'),
  ('221823028984/121973095557','-18024477827/243946191114','-60558463009/81315397038'),
  ('25171034/23271375','879582943/744684000','-940372031/744684000'),
  ('63255206/27298625','-81465389/104826720','-1415197051/2620668000')),
 ((Fr(3,8),Fr(3,8),Fr(1,4)), (Fr(1,4),Fr(19,40),Fr(11,40)), ('716033/2000000','95291/250000','521639/2000000'),
  ('-400592057081/2244738395565','-4336304472769/2244738395565','16756393/5387523'),
  ('67504801/66664800','-200778847/66664800','3599/1200'),
  ('-5687330003/6465027600','-95904969709/64650276000','72476181913/21550092000')),
]
def P(t): return tuple(Fr(x) for x in t)
def inU(h): return all(dot(k,h) > 0 for k in U)
allok = True
for p1, p2, q, a, b1, b2 in cases:
    q, a, b1, b2 = P(q), P(a), P(b1), P(b2)
    mX = sub(add(mom(U+[p1]), mom(U+[p2])), mom(U+[p1,p2]))
    d = sub(mom(U+[q]), mX)
    c = {'dom': min(d) > 0, 'a': inU(a) and dot(q,a)>0 and dot(p1,a)<0 and dot(p2,a)<0,
         'b1': inU(b1) and dot(p1,b1)>0 and dot(q,b1)<0, 'b2': inU(b2) and dot(p2,b2)>0 and dot(q,b2)<0}
    # a - l1 b1 - l2 b2 >> 0 : search l on a rational grid around the barycentric solution
    found = False
    for l1n in range(0, 201):
        for l2n in range(0, 201):
            l1, l2 = Fr(l1n,200), Fr(l2n,200)
            r = sub(a, add(sc(l1,b1), sc(l2,b2)))
            if min(r) > 0: found = True; break
        if found: break
    c['hull'] = found
    print("m(N_q)-m(X) =", f(d), c, ("l=(%s,%s)" % (l1,l2)) if found else "")
    allok = allok and all(c.values())
print("T1 CERTIFICATES (strict):", allok)
