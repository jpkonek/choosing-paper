"""REF64_es: (H) for collar rivals D_K u P whose pieces sit near the face MIDPOINTS (E61's collar
trade), which ES64 Prop 5.6 does NOT cover (its corner cones need lateral >= 0.096).
P_1 := {lat in (-lam, lam), depth in (d1, d2)} beyond F_1 (inside U); P_2, P_3 by permutation.
lam = 1/50, d1 = 1/100, d2 = 1/20.   Defender: N := D_{Q_t}, with t chosen so that the boundary
q_1.h = 0 of N crosses P_1 (N contains the inner part of P_1 but not the outer part).
Certificate (Lemma 5.3 of ES64): corner cone C* = {lat in [lam-xi, lam], depth in [D1, D2]} inside P_1
and outside N; y(p) := p + kappa*s(p)*(e3 + (e1+e2)/1000) is linear in p; at the 4 extreme rays:
 y in N, v1.y<0 (not in D_K), lat(y) > lam (not in P_1), v2.y>0, v3.y>0 (not in P_2, P_3).
Brier: m(N) - m(D_K u P) >> 0 for P = P_1 and for P = P_1 u P_2 u P_3.  Exact rationals."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from xcone import *

r2 = V(2,-3,2); r3 = V(2,2,-3)
# w with v1.w=-1, v2.w=0, v3.w=0 : solve by Cramer
def solve(M, rhs):
    D = det(*M); out=[]
    for k in range(3):
        Mk=[list(r) for r in M]
        for r in range(3): Mk[r][k]=rhs[r]
        out.append(det(*[tuple(x) for x in Mk])/D)
    return tuple(out)
w = solve([v[0],v[1],v[2]], (Fr(-1),Fr(0),Fr(0)))
def H(a,b,c): return add(sc(a,r2),sc(b,r3),sc(c,w))
def ray(lat,dep): return H((1+lat)/2,(1-lat)/2,dep)      # s = 1
s_dir = add(v[1],v[2]); l_dir = sub(v[1],v[2])
assert dot(v[1],H(1,0,0))==1 and dot(v[2],H(0,1,0))==1 and dot(v[0],H(0,0,1))==-1

lam, d1, d2 = Fr(1,50), Fr(1,100), Fr(1,20)
def piece(k_perm):
    # face-1 piece, then permute coordinates for faces 2,3
    ineqs = [neg(v[0]), sub(sc(d2,s_dir), neg(v[0])), add(neg(v[0]), sc(-d1,s_dir)),
             add(l_dir, sc(lam,s_dir)), add(neg(l_dir), sc(lam,s_dir))] + U
    # depth c/s in (d1,d2):  -v1.h > d1 s  and  -v1.h < d2 s
    return [tuple(a[k_perm[i]] for i in range(3)) for a in ineqs]
perms = [(0,1,2),(1,0,2),(2,1,0)]   # map face 1 to faces 1,2,3 (v is permutation-symmetric)
P = [piece(p) for p in perms]
for k in range(3):
    # check the permuted piece is beyond face k
    assert mass(P[k] + [v[k]]) == 0
mP = [mom(p) for p in P]
mDK = mom(U+DK)
print("m(P_1) =", f(mP[0]), " mass(P_1) =", float(mass(P[0])))
# choose t: boundary of N at lat 0 at depth d* = 3/100
dstar = Fr(3,100)
h0 = ray(Fr(0), dstar)
# q1.h0 = (1-t) v1.h0 + t u.h0 = 0
t = -dot(v[0],h0)/(dot(u,h0)-dot(v[0],h0))
t = Fr(round(t*10**6),10**6)
Q = [mix(vk,u,t) for vk in v]
Nc = Q + U
print("t =", t)
mN = mom(Nc)
ok = True
for name, mp in (("P_1", mP[0]), ("P_1uP_2uP_3", add(*mP))):
    d = sub(mN, add(mDK, mp))
    print("m(N)-m(D_K u %s) =" % name, f(d), " >>0:", min(d) > 0)
    ok = ok and min(d) > 0
print("mass(P_1 \\ N) =", float(mass(P[0]+[neg(Q[0])])), "  mass(P_1 cap N) =", float(mass(P[0]+Nc)))
# certificate
xi, D1, D2, kappa = Fr(2,1000), None, Fr(45,1000), Fr(2,100)
# boundary depth of N on [lam-xi, lam]: q1.ray(lat,dep)=0 is linear in dep; take max over the two lats
def bdep(lat):
    a0 = dot(Q[0], ray(lat, Fr(0))); a1 = dot(Q[0], ray(lat, Fr(1))) - a0
    return -a0/a1
D1 = max(bdep(lam-xi), bdep(lam)) + Fr(1,1000)
D2 = D1 + Fr(4,1000)
print("corner cone: lat in [%s, %s], depth in [%s, %s]" % (float(lam-xi), float(lam), float(D1), float(D2)))
def y_of(p):
    return add(p, sc(dot(s_dir,p)*kappa, add(e[2], sc(Fr(1,1000), add(e[0],e[1])))))
def inside(ineqs,h): return all(dot(a,h)>0 for a in ineqs)
for la in (lam-xi, lam):
    for de in (D1, D2):
        p = ray(la, de)
        y = y_of(p)
        c = [dot(Q[0],p) < 0,                       # p outside N
             d1 < de < d2 and -lam < la <= lam,    # p in closed P_1 (lat=lam is the boundary edge)
             inside(U,p),                           # p in U
             inside(Nc,y),                          # y in N
             dot(v[0],y) < 0,                       # y beyond F_1, not in D_K
             dot(l_dir,y) > lam*dot(s_dir,y),       # y outside P_1 laterally
             dot(v[1],y) > 0 and dot(v[2],y) > 0]   # y not in P_2, P_3 (they lie beyond F_2, F_3)
        print("  ray lat=%.4f depth=%.4f:" % (float(la), float(de)), c)
        ok = ok and all(c)
print("MIDPOINT COLLAR CERTIFICATE:", ok)
