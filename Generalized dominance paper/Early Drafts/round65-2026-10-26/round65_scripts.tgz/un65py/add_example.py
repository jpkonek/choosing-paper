"""UN65: exact re-verification of the transitivity / (Add) failure of Delta(all coherent)
(REF64_es Sec. 5.3(3)), in the explicit form used in the note.
Density exp(-|h|_1); exact cone moments from ../ref64es_py/xcone.py (independent of es64py).
n = 3, v_k as below, K = conv{v_k}, u = (1/3,1/3,1/3), K' = (K+u)/2, U = D_{K'}.
N = D_Q, Q = conv{(20/23) v_k + (3/23) u}.  D = N \\ D_K.
w = (76,-43,157).  S1 = D cap ({v2.h<0} u {v1.h<0<v2.h, w.h>0}),  S2 = D \\ S1."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'ref64es_py'))
from xcone import V, Fr, mom, mass, sub, add, neg, sc, dot, v, u, mix, Kp, f

t = Fr(3, 23)
Q = [mix(vk, u, t) for vk in v]
# K' subset Q (so N is a model on U): each vertex of K' is a convex combination of Q's vertices
# K' vertex (v_k+u)/2 = (1-s) Qvertex_k + s u with s from (1-s)(1-t)=1/2
s = 1 - Fr(1, 2) / (1 - t)
assert 0 <= s <= 1
Nc = Q + Kp                      # N = D_Q (Kp constraints redundant since K' in Q)
w = V(76, -43, 157)
# check w is proportional to (v2-v3) + (19/100)(v2+v3)
ww = add(sub(v[1], v[2]), sc(Fr(19, 100), add(v[1], v[2])))
assert all(ww[i] * 500 == w[i] for i in range(3))
mD = sub(mom(Nc), mom(Nc + list(v)))
p2 = mom(Nc + [neg(v[1])])                       # N cap {v2.h<0}  (subset of D)
side = mom(Nc + [neg(v[0]), v[1], w])            # N cap {v1.h<0<v2.h, w.h>0} (subset of D)
mS1 = add(p2, side)
mS2 = sub(mD, mS1)
print("m(D)  =", mD, f(mD))
print("m(S1) =", mS1, f(mS1))
print("m(S2) =", mS2, f(mS2))
print("m_1(S1) > 0:", mS1[0] > 0, "  m_1(S2) > 0:", mS2[0] > 0)
print("m_3(S1) < 0:", mS1[2] < 0, "  m_2(S2) < 0:", mS2[1] < 0)
print("m(D) >> 0:", min(mD) > 0)
mneg = mass(Nc + [neg(v[1]), V(-1, 0, 0)])       # D cap {h_1<0} contains N cap {v2.h<0, h_1<0}
print("mass(N cap {v2.h<0, h1<0}) =", mneg, float(mneg), "> 0:", mneg > 0)
