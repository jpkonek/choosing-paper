"""WT65: how many removed density points does the witness need?

Claim (PROVED in WT65_notes.md, Lemma W2): if every b in F lies in C_{K'} with
K' a nonempty subset of relint(Delta), and a - sum_j lam_j b_j >> 0 for some
lam >= 0 and b_j in F, then the same holds with at most n-1 of the b_j.

This script (i) stress-tests the claim on random adversarial data, verifying
every representation it reports EXACTLY in rational arithmetic, and
(ii) checks the sharpness example (n-1 needed) exactly, and
(iii) the control example without one-sidedness (n needed).

Feasibility of a subset J is decided by the LP  max t  s.t.
  sum_{j in J} lam_j b_j + t*1 <= a,  lam >= 0,  t <= 1.
Only POSITIVE answers are used as evidence (and re-verified exactly);
LP infeasibility is never used as a proof.
"""
import itertools, random
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import linprog


def lp_slack(a, B):
    """max t with a - B@lam >= t*1, lam >= 0, t <= 1. Returns (t, lam)."""
    n, r = B.shape
    if r == 0:
        return min(1.0, float(a.min())), np.zeros(0)
    c = np.zeros(r + 1); c[-1] = -1.0
    A_ub = np.hstack([B, np.ones((n, 1))])
    bounds = [(0, None)] * r + [(None, 1.0)]
    res = linprog(c, A_ub=A_ub, b_ub=a, bounds=bounds, method="highs")
    if res.status != 0:
        return -np.inf, None
    return -res.fun, res.x[:r]


def exact_ok(a_fr, b_fr, lam):
    lam_fr = [max(Fr(0), Fr(float(x)).limit_denominator(10**9)) for x in lam]
    n = len(a_fr)
    res = [a_fr[i] - sum(l * b[i] for l, b in zip(lam_fr, b_fr)) for i in range(n)]
    return all(x > 0 for x in res)


def min_generators(a_fr, F_fr):
    """Smallest k such that some k-subset of F works (with exact verification)."""
    n = len(a_fr)
    a = np.array([float(x) for x in a_fr])
    F = [np.array([float(x) for x in b]) for b in F_fr]
    for k in range(0, len(F) + 1):
        for J in itertools.combinations(range(len(F)), k):
            B = np.array([F[j] for j in J]).T if k else np.zeros((n, 0))
            t, lam = lp_slack(a, B)
            if t > 1e-9 and (k == 0 or exact_ok(a_fr, [F_fr[j] for j in J], lam)):
                return k, J
    return None, None


def rand_rational_vec(n, lo, hi, den=97):
    return [Fr(random.randint(int(lo * den), int(hi * den)), den) for _ in range(n)]


def random_case(n):
    # K' = {k0}: a single point of relint Delta (the weakest one-sidedness; larger K' only shrinks C_{K'}).
    w = [Fr(random.randint(1, 20)) for _ in range(n)]
    k0 = [x / sum(w) for x in w]
    F = []
    while len(F) < n:
        b = rand_rational_vec(n, -3, 3)
        s = sum(k * x for k, x in zip(k0, b))
        if s > 0 and s < Fr(1, 4):  # close to the boundary of C_{K'}: adversarial
            F.append(b)
    lam = [Fr(random.randint(1, 50), 10) for _ in range(n)]
    a = [sum(l * b[i] for l, b in zip(lam, F)) + Fr(random.randint(1, 5), 1000) for i in range(n)]
    return a, F, k0


def main():
    random.seed(65)
    print("(i) random adversarial cases: a = sum of n generators in C_{K'} + small slack")
    for n in (2, 3, 4, 5):
        hist = {}
        for _ in range(400 if n < 5 else 200):
            a, F, k0 = random_case(n)
            k, J = min_generators(a, F)
            assert k is not None, "the full set must work"
            hist[k] = hist.get(k, 0) + 1
            assert k <= n - 1, ("COUNTEREXAMPLE to r <= n-1", a, F, k0)
        print(f"  n={n}: minimal number of generators found (exactly verified): {dict(sorted(hist.items()))};"
              f" never n")

    print("(ii) sharpness example: b_j = L e_n - e_j + s*sum_{k not in {j,n}} e_k, a = sum b_j + eps*1")
    for n in (2, 3, 4, 5, 6):
        L, s, eps = Fr(4 * n), Fr(1, 10 * n), Fr(1, 100)
        F = []
        for j in range(n - 1):
            b = [s if (k != j and k != n - 1) else Fr(0) for k in range(n)]
            b[j] = Fr(-1); b[n - 1] = L
            F.append(b)
        a = [sum(b[i] for b in F) + eps for i in range(n)]
        # in U = D_{K'} for K' = {centroid}:
        assert all(sum(b) > 0 for b in F) and sum(a) > 0
        # exact: full set works
        assert all(a[i] - sum(b[i] for b in F) > 0 for i in range(n))
        # exact obstruction: coordinate i<n of a is negative and only b_i has a negative i-th coordinate
        assert all(a[i] < 0 for i in range(n - 1))
        assert all(F[j][i] >= 0 for i in range(n - 1) for j in range(n - 1) if j != i)
        k, J = min_generators(a, F)
        print(f"  n={n}: a_i<0 for i<n (exact); minimal generators = {k} (= n-1 = {n-1})")
        assert k == n - 1

    print("(iii) control without one-sidedness: b_j = -e_j, a = -1 + eps*1")
    for n in (2, 3, 4):
        F = [[Fr(-1) if k == j else Fr(0) for k in range(n)] for j in range(n)]
        a = [Fr(-1, 2)] * n
        k, J = min_generators(a, F)
        print(f"  n={n}: minimal generators = {k} (= n)")
        assert k == n


if __name__ == "__main__":
    main()
