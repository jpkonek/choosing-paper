"""WT65: exact check of the three-world example (WT65_notes.md, Example C2).

Q = conv{v1,v2,v3}, v1 = (3/5,1/5,1/5) and permutations; K' = {(1/3,1/3,1/3)}.
G1 = int cone((-1,3,3),(-1,6,3),(-1,3,6)); G2, G3 its images under the
transpositions (1 2), (1 3).  X := D_Q minus cl(G1 u G2 u G3).
Q_eps := conv(Q u {v1 + eps*d}), d = (1,-1/2,-1/2).

Checks (exact, density e^{-|h|_1} via es64py/cones.py):
  * cl G minus 0 inside D_Q; m(G) = c*1 with c > 0;
  * Phi_X(Q) = 0 (structural; see notes);
  * for eps in a range: cl G minus 0 inside D_{Q_eps}, hence B_eps = D_Q cap {q_eps.h <= 0};
    exact margin m(D_{Q_eps}) - m(X) = m(G) - m(B_eps) >= delta*1;
    b_eps = (-2,3,3) + eps*1 is an interior point of B_eps (so a density point);
    every generator g of G1 has g - (3/4) b_eps >> 0, so cl G1 minus 0 lies in hull(B_eps);
    hence Phi_X(Q_eps) >= mu(G1) > 0.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "es64py"))
from fractions import Fraction as F
from cones import moment, dot, det3

def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])

def simplicial_ineqs(g):
    out = []
    for i in range(3):
        a, b, c = g[i], g[(i+1) % 3], g[(i+2) % 3]
        nrm = cross(a, b)
        if dot(nrm, c) < 0:
            nrm = tuple(-x for x in nrm)
        out.append(nrm)
    return out

def perm(h, s):  # apply transposition s=(i,j) to coordinates
    h = list(h); i, j = s; h[i], h[j] = h[j], h[i]; return tuple(h)

V = lambda *xs: tuple(F(x) for x in xs)
v1, v2, v3 = V(F(3,5), F(1,5), F(1,5)), V(F(1,5), F(3,5), F(1,5)), V(F(1,5), F(1,5), F(3,5))
Qv = [v1, v2, v3]
G1 = [V(-1, 3, 3), V(-1, 6, 3), V(-1, 3, 6)]
G2 = [perm(g, (0, 1)) for g in G1]
G3 = [perm(g, (0, 2)) for g in G1]
Gs = [G1, G2, G3]

# cl G minus 0 inside D_Q
assert all(dot(v, g) > 0 for v in Qv for G in Gs for g in G)
# G_j inside {h_j < 0, other coords > 0}: pairwise disjoint and outside the closed... open orthant
for j, G in enumerate(Gs):
    assert all(g[j] < 0 and all(g[k] > 0 for k in range(3) if k != j) for g in G)
mG = [F(0)] * 3; muG1 = None
for G in Gs:
    ms, mo = moment(simplicial_ineqs(G))
    if muG1 is None: muG1 = ms
    mG = [mG[i] + mo[i] for i in range(3)]
print("mu(G1) =", muG1, "=", float(muG1))
print("m(G) =", [str(x) for x in mG], "(equal coordinates, positive)")
assert mG[0] == mG[1] == mG[2] and mG[0] > 0

mDQ = moment(Qv)[1]
d = (F(1), F(-1, 2), F(-1, 2))
b = V(-2, 3, 3)
assert dot(v1, b) == 0 and dot(v2, b) > 0 and dot(v3, b) > 0   # b on the boundary of D_Q
delta = mG[0] / 4
print("delta := m_1(G)/4 =", float(delta))
for eps in [F(1, 100), F(1, 200), F(1, 400), F(1, 1000), F(1, 10**6)]:
    q = tuple(v1[i] + eps * d[i] for i in range(3))
    assert all(x > 0 for x in q) and sum(q) == 1
    # cl G minus 0 inside D_{Q_eps}  (so A_eps = G and B_eps = D_Q cap {q.h <= 0})
    assert all(dot(q, g) > 0 for G in Gs for g in G)
    mDQe = moment(Qv + [q])[1]
    mB = [mDQ[i] - mDQe[i] for i in range(3)]
    margin = [mG[i] - mB[i] for i in range(3)]
    assert all(x >= delta for x in margin)
    be = tuple(b[i] + eps for i in range(3))
    # b_eps strictly inside D_Q, strictly in {q.h<0}, and outside cl G:
    assert all(dot(v, be) > 0 for v in Qv) and dot(q, be) < 0
    assert 3 * (-be[0]) > min(be[1], be[2])          # outside cl G1  (cl G1 sits in {-3h1 <= min(h2,h3)})
    assert all(-3 * g[0] <= min(g[1], g[2]) for g in G1)
    assert be[1] > 0 and be[2] > 0                    # outside cl G2, cl G3
    # cl G1 minus 0 inside cone(b_eps) + int R^3_+  (lambda = 3/4 per unit of generator weight)
    assert all(all(g[i] - F(3, 4) * be[i] > 0 for i in range(3)) for g in G1)
    print(f"  eps={eps}: margin = {[round(float(x), 6) for x in margin]}  (>= delta);"
          f"  Phi_X(Q_eps) >= mu(G1) = {float(muG1):.6f}")
print("Phi_X(Q) = 0 at the limit Q (X subset D_Q, so the removed part is empty).")
