"""NUMERICS (sanity only; the verdict rests on the hand check).
Two worlds, mu with density exp(-|h|_1); conic models are angular sets.
For random incoherent conic X inside U = D_{K'} we run the three steps of the
proof of Theorem 5.3 on a fine angle grid and check:
  (i)  m(N) - m(X) >> 0,  (ii) N subset hull(X \\ N),  mu(N \\ X) > 0,
and the shrink identity Q_{X\\N} = Q_X (Corollary 5.2).
Radial integral: int_0^inf r*(c,s) e^{-r(|c|+|s|)} r dr = 2 (c,s)/(|c|+|s|)^3.
"""
import numpy as np
rng = np.random.default_rng(65)
M = 40000
th = np.linspace(-np.pi, np.pi, M, endpoint=False) + np.pi / M
H = np.stack([np.cos(th), np.sin(th)], 1)
dth = 2 * np.pi / M
w = 2.0 / (np.abs(H[:, 0]) + np.abs(H[:, 1])) ** 3 * dth     # moment weight
wm = 1.0 / (np.abs(H[:, 0]) + np.abs(H[:, 1])) ** 2 * dth   # mass weight

def lin(q):  # q in [0,1] -> (q,1-q).h for all grid directions
    return q * H[:, 0] + (1 - q) * H[:, 1]
def D(Q):     # Q = (lo, hi) interval of probabilities for world 1
    return (lin(Q[0]) > 0) & (lin(Q[1]) > 0)
def P(Q):
    return np.minimum(lin(Q[0]), lin(Q[1]))
def m(S): return (H[S] * w[S, None]).sum(0)
def mass(S): return wm[S].sum()
def Qof(S):   # {q : (q,1-q).h >= 0 on S}; interval, computed from constraints
    if not S.any(): return (0.0, 1.0)
    a, b = H[S, 0], H[S, 1]          # q a + (1-q) b = b + q (a-b) >= 0
    lo, hi = 0.0, 1.0
    d = a - b
    pos, neg = d > 0, d < 0
    if pos.any(): lo = max(lo, np.max(-b[pos] / d[pos]))
    if neg.any(): hi = min(hi, np.min(-b[neg] / d[neg]))
    z = (d == 0) & (b < 0)
    if z.any(): return None
    return (lo, hi) if lo <= hi else None

fails = 0
ninc = 0
for trial in range(80):
    Kp = tuple(sorted(rng.uniform(0.05, 0.95, 2)))
    U = D(Kp)
    idx = np.flatnonzero(U)
    # X: union of a few random arcs inside U (conic, generally incoherent)
    X = np.zeros(M, bool)
    for _ in range(rng.integers(1, 5)):
        a = rng.choice(idx); L = rng.integers(M // 200, M // 12)
        X[a:a + L] = True
    X &= U
    QX = Qof(X); G = D(QX)
    coherent = np.array_equal(X, G & U) or mass(X ^ (G & U)) < 1e-9
    if coherent: continue
    ninc += 1
    x = m(X)
    lams = np.linspace(0, 1, 801)
    vals = [ (lambda S: l * (m(S)[0] - x[0]) + (1 - l) * (m(S)[1] - x[1]))(G & (lin(l) > 0)) for l in lams]
    l_star = lams[int(np.argmin(vals))]
    N0 = G & (lin(l_star) > 0)
    marg0 = m(N0) - x
    # shrink
    ok = False
    for tau in [0.2, 0.1, 0.05, 0.02, 0.01, 0.005, 0.002, 0.001]:
        Ptau = (1 - tau) * P(QX) + tau * H.min(1)
        N = N0 & (Ptau > 0)
        if (m(N) - x).min() > 0 and mass(N & ~X) > 0:
            ok = True; break
    if not ok:
        fails += 1; print("trial", trial, "no tau found; margin0", marg0); continue
    QB = Qof(X & ~N)
    hullB = D(QB)
    inside = not (N & ~hullB).any()
    shrink_ok = abs(QB[0] - QX[0]) < 1e-9 and abs(QB[1] - QX[1]) < 1e-9
    if not (inside and shrink_ok and marg0.min() > 0):
        fails += 1
        print("trial", trial, "FAIL", Kp, QX, QB, inside, marg0)
print("incoherent rivals checked:", ninc, " failures:", fails)
