"""Independent exact re-check of Example 7.1 (REF65_un).

mu has density exp(-|h|_1) on R^3 (unnormalised, total mass 8).
All sets are finite Boolean combinations of open half-spaces {f.h>0}.
We split R^3 into the full-dimensional cells of the arrangement of all forms
(including the coordinate forms, so each cell lies in one orthant), compute each
cell's extreme rays exactly, fan-triangulate, and integrate exactly:
for a simplicial cone with rays a,b,c inside orthant sigma (|h|_1 = sigma.h),
  int e^{-sigma.h} dh   = |det[a b c]| / ((sigma.a)(sigma.b)(sigma.c))
  int h e^{-sigma.h} dh = (same) * (a/(sigma.a) + b/(sigma.b) + c/(sigma.c)).
No code is shared with earlier scripts.
"""
from fractions import Fraction as Fr
from itertools import product, combinations
import math

def dot(a, b): return sum(x*y for x, y in zip(a, b))
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def det3(a, b, c): return dot(a, cross(b, c))
def add(a, b): return tuple(x+y for x, y in zip(a, b))
def scal(t, a): return tuple(t*x for x in a)

F = Fr
v1 = (F(1,5), F(2,5), F(2,5)); v2 = (F(2,5), F(1,5), F(2,5)); v3 = (F(2,5), F(2,5), F(1,5))
u = (F(1,3),)*3
V = [v1, v2, v3]
Kp = [scal(F(1,2), add(v, u)) for v in V]
Qv = [add(scal(F(20,23), v), scal(F(3,23), u)) for v in V]
w = (F(76), F(-43), F(157))
E = [(F(1),F(0),F(0)), (F(0),F(1),F(0)), (F(0),F(0),F(1))]

# barycentric check of K' in Q in K (all are homothets of K about u)
def bary(p, verts):
    # solve p = sum l_k verts_k, sum l_k = 1 (3x3, verts affinely independent in plane x.1=1)
    # since verts have coordinate sum 1, solve linear system M l = p with M columns verts
    M = [[verts[k][i] for k in range(3)] for i in range(3)]
    d = det3(*[tuple(M[i][k] for i in range(3)) for k in range(3)])
    sol = []
    for k in range(3):
        cols = [tuple(M[i][j] for i in range(3)) for j in range(3)]
        cols[k] = p
        sol.append(det3(*cols) / d)
    return sol
ok1 = all(min(bary(p, Qv)) >= 0 for p in Kp)
ok2 = all(min(bary(p, V)) >= 0 for p in Qv)
print("K' subset Q:", ok1, "  Q subset K:", ok2)
print("Q vertices:", Qv)

forms = {'q1': Qv[0], 'q2': Qv[1], 'q3': Qv[2], 'v1': v1, 'v2': v2, 'v3': v3,
         'w': w, 'e1': E[0], 'e2': E[1], 'e3': E[2], "k1": Kp[0], "k2": Kp[1], "k3": Kp[2]}
names = list(forms)

def norm_ray(r):
    s = sum(abs(x) for x in r)
    return tuple(x / s for x in r)

def cell_rays(signs):
    cons = [scal(signs[nm], forms[nm]) for nm in names]
    rays = set()
    for a, b in combinations(cons, 2):
        c = cross(a, b)
        if c == (0, 0, 0):
            continue
        for cand in (c, scal(-1, c)):
            if all(dot(g, cand) >= 0 for g in cons):
                rays.add(norm_ray(cand))
    if len(rays) < 3:
        return None
    rays = list(rays)
    tot = (F(0),)*3
    for r in rays: tot = add(tot, r)
    if not all(dot(g, tot) > 0 for g in cons):
        return None  # not full-dimensional
    return rays, tot

def cell_integrals(rays, centre, sigma):
    # order rays cyclically around centre (floats only for the ordering)
    c = [float(x) for x in centre]
    cn = math.sqrt(sum(x*x for x in c)); c = [x/cn for x in c]
    # basis of plane orthogonal to c
    t = [1.0, 0.0, 0.0] if abs(c[0]) < 0.9 else [0.0, 1.0, 0.0]
    e1 = [t[1]*c[2]-t[2]*c[1], t[2]*c[0]-t[0]*c[2], t[0]*c[1]-t[1]*c[0]]
    n1 = math.sqrt(sum(x*x for x in e1)); e1 = [x/n1 for x in e1]
    e2 = [c[1]*e1[2]-c[2]*e1[1], c[2]*e1[0]-c[0]*e1[2], c[0]*e1[1]-c[1]*e1[0]]
    def ang(r):
        rf = [float(x) for x in r]
        return math.atan2(sum(a*b for a, b in zip(rf, e2)), sum(a*b for a, b in zip(rf, e1)))
    rays = sorted(rays, key=ang)
    mass = F(0); mom = (F(0),)*3
    a = rays[0]
    for b, cc in zip(rays[1:-1], rays[2:]):
        d = abs(det3(a, b, cc))
        sa, sb, sc = dot(sigma, a), dot(sigma, b), dot(sigma, cc)
        assert sa > 0 and sb > 0 and sc > 0
        base = d / (sa*sb*sc)
        mass += base
        mom = add(mom, scal(base, add(add(scal(1/sa, a), scal(1/sb, b)), scal(1/sc, cc))))
    return mass, mom

cells = []
for pat in product((1, -1), repeat=len(names)):
    signs = dict(zip(names, (F(s) for s in pat)))
    res = cell_rays(signs)
    if res is None:
        continue
    rays, centre = res
    sigma = (signs['e1'], signs['e2'], signs['e3'])
    mass, mom = cell_integrals(rays, centre, sigma)
    cells.append((signs, mass, mom))
print("full-dimensional cells:", len(cells))
tm = sum(c[1] for c in cells)
print("total mass (should be 8):", tm)
assert tm == 8
tmom = (F(0),)*3
for c in cells: tmom = add(tmom, c[2])
print("total first moment (should be 0):", tmom)

def P(s, nm): return s[nm] > 0
def inN(s): return P(s,'q1') and P(s,'q2') and P(s,'q3')
def inDK(s): return P(s,'v1') and P(s,'v2') and P(s,'v3')
def inU(s): return P(s,'k1') and P(s,'k2') and P(s,'k3')
def inD(s): return inN(s) and not inDK(s)
def inS1(s): return inD(s) and ((not P(s,'v2')) or ((not P(s,'v1')) and P(s,'v2') and P(s,'w')))
def inS2(s): return inD(s) and not inS1(s)

def integ(pred):
    mass = F(0); mom = (F(0),)*3
    for s, ms, mo in cells:
        if pred(s):
            mass += ms; mom = add(mom, mo)
    return mass, mom

# sanity: N subset U, D_K subset N
assert all(inU(s) for s, _, _ in cells if inN(s)), "N not inside U"
assert all(inN(s) for s, _, _ in cells if inDK(s)), "D_K not inside N"
print("N subset U and D_K subset N: True")

mD = integ(inD)[1]; m1 = integ(inS1)[1]; m2 = integ(inS2)[1]
print("m(D)  =", mD, [float(x) for x in mD])
print("m(S1) =", m1, [float(x) for x in m1])
print("m(S2) =", m2, [float(x) for x in m2])
print("m(S1)+m(S2) == m(D):", add(m1, m2) == mD)
claimed = {
 'mD': (F(68269,2370816),)*3,
 'mS1': (F(1691077,59270400), F(122655769,2963520000), F(-58937269,2963520000)),
 'mS2': (F(163,617400), F(-37319519,2963520000), F(16030391,329280000)),
}
print("matches note m(D):", mD == claimed['mD'])
print("matches note m(S1):", m1 == claimed['mS1'])
print("matches note m(S2):", m2 == claimed['mS2'])
witness = integ(lambda s: inN(s) and not P(s,'v2') and not P(s,'e1'))[0]
print("mu(N & v2.h<0 & h1<0) =", witness, " note claims 1853/70560:", witness == F(1853,70560))
# extra: is D inside {h1>0} a.e.? (it must not be, for i(r)=1)
print("mu(D & h1<0) =", integ(lambda s: inD(s) and not P(s,'e1'))[0])
# sign pattern used in the example
print("m1(S1)>0:", m1[0] > 0, " m3(S1)<0:", m1[2] < 0, " m1(S2)>0:", m2[0] > 0, " m2(S2)<0:", m2[1] < 0,
      " m(D)>>0:", all(x > 0 for x in mD))
# deletion world of (D, empty): least i with m_i(D)>0 and (D,empty) not in G_i
for i in range(3):
    notG = integ(lambda s, i=i: inD(s) and not P(s, 'e%d' % (i+1)))[0] > 0
    print(" world", i+1, ": m_i(D)>0:", mD[i] > 0, " (D,0) not in G_i:", notG)
