"""REF65_paper: exact checks for the new proofs in 'Covering coherent sets of desirable gambles'.
Run: python3 -I checks.py   (all arithmetic exact: sympy / fractions)
"""
import itertools, random
from fractions import Fraction as Fr
import sympy as sp

random.seed(65)
ok = lambda b, msg: print(("PASS " if b else "FAIL ") + msg) or b

# ---------------------------------------------------------------- 1. Theorem 8.14 step 5(a)
u1, u2, u3 = sp.symbols('u1 u2 u3', positive=True)
u = sp.Matrix([u1, u2, u3]); one = sp.Matrix([1, 1, 1])
Mrows = u * one.T - sp.eye(3)                     # rows g^i = u_i 1 - e_i
ok(sp.simplify(Mrows.det() - (u1 + u2 + u3 - 1)) == 0, "8.14(a): det(u 1^T - I) = 1.u - 1 (n=3)")
# crossing pattern: (g^i)_i = u_i - 1 < 0, (g^i)_l = u_i > 0
g = [Mrows.row(i) for i in range(3)]
ok(all(g[i][i] == u[i] - 1 and all(g[i][l] == u[i] for l in range(3) if l != i) for i in range(3)),
   "8.14(a): g^i negative exactly at i")
# F_{v^k} = cone{g^i, g^l}: g^i lies in F_{v^j} and F_{v^l}; world m crossing at the face used
for i in range(3):
    for m in range(3):
        faces = [k for k in range(3) if k != i]          # faces containing g^i
        good = [k for k in faces if m != k]               # m crossing at v^k iff m != k
        assert good, (i, m)
ok(True, "8.14(a): for every ray g^i and every world m some face through g^i has m crossing")

# ---------------------------------------------------------------- 2. Corollary 8.5(b) vertex count
def drc_vertices(p, k):
    n = len(p)
    cons = []   # m.g >= 0 with g = (k/p_j) e_j - (1/p_i) e_i
    for i in range(n):
        for j in range(n):
            if i != j:
                gg = [Fr(0)] * n; gg[j] += Fr(k) / p[j]; gg[i] -= Fr(1) / p[i]; cons.append(gg)
    for a in range(n):
        gg = [Fr(0)] * n; gg[a] = Fr(1); cons.append(gg)   # m_a >= 0
    verts = set()
    for S in itertools.combinations(range(len(cons)), n - 1):
        A = sp.Matrix([[1] * n] + [cons[s] for s in S]); b = sp.Matrix([1] + [0] * (n - 1))
        if A.det() == 0: continue
        m = A.LUsolve(b)
        if all(sum(c[t] * m[t] for t in range(n)) >= 0 for c in cons):
            verts.add(tuple(m))
    return verts, cons
for n in (3, 4):
    p = [Fr(random.randint(1, 9)) for _ in range(n)]; s = sum(p); p = [x / s for x in p]
    V, cons = drc_vertices(p, 2)
    nonvis = 0
    for v in V:
        act = [c for c in cons if sum(c[t] * v[t] for t in range(n)) == 0 and any(c)]
        negs = set(t for c in act for t in range(n) if c[t] < 0)
        # Lemma poly: visible from j iff every active normal is negative at j
        vis = any(all(c[j] < 0 for c in act) for j in range(n))
        nonvis += (not vis)
    ok(len(V) == 2 ** n - 2 and nonvis == 2 ** n - n - 2,
       f"8.5(b): density-ratio class n={n}: {len(V)} vertices, {nonvis} not visible (expect {2**n-2}, {2**n-n-2})")

# ---------------------------------------------------------------- 3. reversed-triangle facts
v = [sp.Matrix(2 * one - sp.eye(3).col(k)) / 5 for k in range(3)]
r = [2 * one - 5 * sp.eye(3).col(j) for j in range(3)]
ok(all((v[k].T * r[j])[0] == (1 if k == j else 0) for k in range(3) for j in range(3)), "R: v_k.r_j = delta_kj")
ok(r[0] + r[1] + r[2] == one, "R: r_1+r_2+r_3 = 1")

# ---------------------------------------------------------------- 4. Lemma 8.18 (collar) estimate, exact
def dot(a, b): return sum(x * y for x, y in zip(a, b))
V = [[Fr(1, 5), Fr(2, 5), Fr(2, 5)], [Fr(2, 5), Fr(1, 5), Fr(2, 5)], [Fr(2, 5), Fr(2, 5), Fr(1, 5)]]
RR = [[-3, 2, 2], [2, -3, 2], [2, 2, -3]]
def norm2(a): return dot(a, a)
fails = 0; trials = 0
for k in range(3):
    for j in range(3):
        if j == k: continue
        i = 3 - j - k
        for _ in range(40):
            s_, t_ = Fr(random.randint(1, 30), 7), Fr(random.randint(1, 30), 7)
            p = [s_ * RR[i][a] + t_ * RR[j][a] for a in range(3)]
            eps = Fr(1, 10); b = [RR[i][a] + eps * RR[j][a] for a in range(3)]
            eta = Fr(1, 20); bp = [x - eta for x in b]
            assert bp[j] > 0 and bp[k] > 0 and dot(V[k], bp) == -eta
            # choose t, c as in the proof
            t = Fr(1, 2)
            while True:
                vals = [dot(V[l], p) - t * dot(V[l], bp) for l in range(3) if l != k] + [p[k] - t * bp[k]]
                if min(vals) > 0: break
                t /= 2
            c = min(vals) / 2
            # r with r|v_l| < c, r < c, r|v_k| < t eta ; |v_l|^2 <= 9/25 so |v_l| < 3/5
            rad = min(c, t * eta) / 2
            for __ in range(25):
                d = [Fr(random.randint(-50, 50), 50) for _ in range(3)]
                if norm2(d) == 0: continue
                # scale so |d| < rad : need sc^2 |d|^2 < rad^2
                sc = rad / (1 + norm2(d))       # |d| <= 1+|d|^2  so sc|d| < rad
                x = [p[a] + sc * d[a] for a in range(3)]
                A = [(x[a] - t * bp[a]) / (1 - t) for a in range(3)]
                trials += 1
                if not (all(dot(V[l], A) > 0 for l in range(3)) and A[k] > 0):
                    fails += 1
ok(fails == 0, f"8.18: A=(x-tb')/(1-t) in D_R and h_k>0 for all {trials} sampled x in B(p,r)")

# ---------------------------------------------------------------- 5. Theorem 8.19 steps 4-5
J = sp.ones(3, 3); Mc = 5 * sp.eye(3) - 2 * J
ok(sorted(Mc.eigenvals().keys()) == [-1, 5] and Mc.det() != 0, "8.19: 5I-2J eigenvalues {-1,5}, nonsingular")
# sigma_v = -kappa h_j on faces F_k (k != j): values at rays
kap = sp.Symbol('kappa')
for j in range(3):
    vals = [(-kap * RR[i][j]) for i in range(3)]
    ok(vals[j] == 3 * kap and all(vals[i] == -2 * kap for i in range(3) if i != j),
       f"8.19: world {j+1}: sigma(r_j)=3kappa, sigma(r_i)=-2kappa")
# Step 6: min over R of m.(e1-e2)
ok(min(dot(vv, [1, -1, 0]) for vv in V) == Fr(-1, 5), "8.19 step 6: min_R m.(e1-e2) = -1/5")

# ---------------------------------------------------------------- 6. Theorem 8.20 steps 3-4 identities
ci, cj, ck, a, th = sp.symbols('c_i c_j c_k a theta')
expr3 = a * ci + th * cj + ck - (-cj) * (a * ci / (-cj) + ck / (-cj) - th)
expr4 = th * ci + a * cj + ck - ci * (th - a * (-cj) / ci - (-ck) / ci)
ok(sp.simplify(expr3) == 0 and sp.simplify(expr4) == 0, "8.20: pi.c factorisations in Steps 3 and 4")
# Step 2 example: H Lipschitz increasing; F'(y0)=1/H'(b)
tt = sp.Symbol('t', positive=True)
H = tt + tt ** 3; b0 = sp.Rational(1, 2); y0 = H.subs(tt, b0)
ok(sp.nsimplify(1 / sp.diff(H, tt).subs(tt, b0)) == sp.Rational(4, 7), "8.20 step 2: sample inverse derivative 1/H'(b)")

# ---------------------------------------------------------------- 7. Appendix A
# Lemma A.3 (kink test) on a random instance
for _ in range(20):
    nvec = sp.Matrix([random.randint(-3, 3) for _ in range(3)])
    if nvec == sp.zeros(3, 1): continue
    q = sp.Matrix([1, 1, 1]); d = sp.Matrix([random.randint(-3, 3) for _ in range(3)])
    if (q.T * d)[0] <= 0: continue
    Mp = sp.Matrix(3, 3, lambda *_: random.randint(-3, 3))
    Mm = Mp - d * nvec.T
    fp = q.T * Mp; fm = q.T * Mm
    if sp.Matrix.vstack(fp, fm).rank() < 2: continue
    # z, w' with fp(z)=1, fm(z)=-1, fp(w')=fm(w')=1 (least-norm solutions)
    A2 = sp.Matrix.vstack(fp, fm)
    z = A2.pinv() * sp.Matrix([1, -1]); w_ = A2.pinv() * sp.Matrix([1, 1])
    eta = sp.Rational(1, 10)
    # at h0 = 0 (both functionals vanish; n.h0 = 0)
    qc = lambda h: max((fp * h)[0], (fm * h)[0])
    x0 = -eta * w_
    assert qc(x0 + 2 * eta * z) == eta and qc(x0 - 2 * eta * z) == eta and qc(x0) == -eta
ok(True, "A.3: q.c'(x0 +- 2 eta z) = eta > 0 > -eta = q.c'(x0) (random instances)")

# Lemma A.7 junction witness
S, ct, lam, oLe, be, tg = sp.symbols('S c_t lambda omegaLe beta tgamma', positive=True)
# q.M_tau(w+se+r1) = lambda s t omega.L e + r(beta+t gamma') ; c_t = lambda t omega.Le/(beta+t gamma')
B = be + tg
f_tau = lambda s_, r_: s_ * ct * B + r_ * B          # using lambda t omega.Le = c_t B
P2 = (2 * S, -sp.Rational(3, 2) * ct * S); Z = (S / 2, -sp.Rational(5, 8) * ct * S)
P1r = sp.Rational(1, 4) * ct * S
ok(sp.simplify(f_tau(*P2) - ct * S * B / 2) == 0 and sp.simplify(f_tau(*Z) + ct * S * B / 8) == 0,
   "A.7: q.M_tau P2 = c_t S B/2 > 0, q.M_tau Z = -c_t S B/8 < 0")
ok(sp.simplify((sp.Matrix([-S, P1r]) + sp.Matrix(P2)) / 2 - sp.Matrix(Z)) == sp.zeros(2, 1), "A.7: Z is the midpoint of P1, P2")

# Corner system: L_k h = sum_{i != k} lam_ik h_i (e_i - e_k); parallelism at the three corner rays
L = {(i, k): sp.Symbol(f'l{i+1}{k+1}', positive=True) for i in range(3) for k in range(3) if i != k}
E = sp.eye(3)
def Lk(k, h):
    return sum((L[(i, k)] * h[i] * (E.col(i) - E.col(k)) for i in range(3) if i != k), sp.zeros(3, 1))
eqs = []
for j in range(3):
    a_, b_ = [kk for kk in range(3) if kk != j]          # r_j lies in F_a and F_b
    X = Lk(a_, RR[j]); Y = Lk(b_, RR[j])
    eqs.append(sp.factor(X[0] * Y[1] - X[1] * Y[0]))
aa = L[(1, 2)] / L[(0, 2)]; bb = L[(2, 0)] / L[(1, 0)]; cc = L[(0, 1)] / L[(2, 1)]
target = [aa + 1 / cc - sp.Rational(3, 2), bb + 1 / aa - sp.Rational(3, 2), cc + 1 / bb - sp.Rational(3, 2)]
match = True
for e_, tg_ in zip(eqs, target):
    ratio = sp.simplify(e_ / sp.together(tg_))
    num = sp.together(tg_).as_numer_denom()[0]
    match &= sp.simplify(sp.factor(e_) / sp.factor(num)).is_constant() if num != 0 else False
ok(match, "corner system: parallelism at r_1, r_2, r_3 <=> a+1/c=b+1/a=c+1/b=3/2 (direct, not by symmetry)")
print("   corner determinants:", eqs)
x = sp.Symbol('x'); T = lambda y: sp.Rational(3, 2) - 1 / y
T3 = sp.simplify(T(T(T(x))))
ok(sp.simplify(T3 - (3 * x - 10) / (10 * x - 12)) == 0, "corner system: T^3(x) = (3x-10)/(10x-12)")
ok(sp.expand(x * (10 * x - 12) - (3 * x - 10) - 5 * (2 * x ** 2 - 3 * x + 2)) == 0 and
   sp.discriminant(2 * x ** 2 - 3 * x + 2) == -7, "corner system: fixed points 2x^2-3x+2=0, discriminant -7")

# ---------------------------------------------------------------- 8. Flag F3: a 'valley' configuration
# Cross-section at w in relint F_3: h = (1+alpha) w + s e + r 1, v_3.h = r.
# g = 1.c = min(r,|s|) for r>0 (sectors at angles [0,pi/4],[pi/4,pi/2],[pi/2,3pi/4],[3pi/4,pi]), g = r for r<0.
# c(h) = (g/3) 1 + (1+alpha) p with p in 1-perp, p != 0  -> continuous PL, c(w) = p != 0.
ssym, rsym = sp.symbols('s r')
gpieces = [rsym, ssym, -ssym, rsym]            # inner sectors 1..4
walls = [(1, 1), (0, 1), (-1, 1)]              # directions u_j = (s,r) of inner half-walls
# kinks of g across walls: g_j - g_{j+1} = (1.d_j) (n_j.h), n_j.e > 0
n_j = [ssym - rsym, ssym, ssym + rsym]
ud = [sp.simplify((gpieces[j] - gpieces[j + 1]) / n_j[j]) for j in range(3)]
ok(ud == [-1, 2, -1], f"F3 valley: 1.d_j = {ud}; REF62 step 1 would assert all <= 0, false at the middle wall")
# along the middle wall (s=0, r>0): g = 0, so q_t.c(w + r u) = t omega.p for all r: no zero crossing
ok(all(gp.subs({ssym: 0}) in (0, rsym) for gp in gpieces[1:3]) and
   gpieces[1].subs(ssym, 0) == 0, "F3 valley: 1.c = 0 on the middle inner half-wall (inside D_R): kink test has no O(t) crossing")
print("   (this configuration is excluded only by the strict-sign lemma, paper Lemma A.4(ii) / DC63 4.2-D(b))")
