"""The collar trade X2 = D_K u P1 u P2 u P3 (three thin pieces beyond the face midpoints).
(a) m(X2) - m(D_K) >> 0: the collar trade is a strict Brier improvement at every world;
(b) in the deletion relation the record (P, {}) is deleted at world 1 only; worlds 2,3 keep D_K u P < D_K;
(c) the coherent defender N = D_Q (Q = K shrunk by t=3/23) Brier-dominates X2 strictly at every world,
    and the open cone R of bump.py (built from P1 \\ N) certifies non-invertibility;
(d) explicit failure of (TP) at world 1:  N <=_1 D_K u P1 (kept), D_K u P1 <=_1 D_K (guidance), but
    N and D_K are incomparable at world 1 (record deleted).
Exact arithmetic."""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geom import *
from cones import moment

delta, lam = F(1,10), F(1,10)
Ps = [piece_beyond(k, delta, lam) for k in range(3)]
mPs = [mom(p) for p in Ps]
mDK = mom(U+DK)
mP = add(*mPs)
print("(a) m(P1+P2+P3) =", fmt(mP), " >>0:", min(mP) > 0)
mX2 = add(mDK, mP)
t = F(3,23)
Q = [mix(vk, u, t) for vk in v]
mN = mom(DQ(Q))
d = sub(mN, mX2)
print("(c) m(N)-m(X2) =", fmt(d), " >>0:", min(d) > 0)
print("    m(N)-m(D_K) =", fmt(sub(mN, mDK)), "  (so the record 'add N\\D_K' is deleted, at world 1)")
mX1 = add(mDK, mPs[0])
d1 = sub(mN, mX1)
print("(d) m(N)-m(D_K u P1) =", fmt(d1), " >>0:", min(d1) > 0)
# guidance: is P1 inside {h_1>0}?  check mass of P1 cap {h_1<0}
print("    mass(P1 cap {h_1<0}) =", moment(Ps[0] + [vec(-1,0,0)])[0], "(0 means D_K u P1 is pointwise 1-better than D_K)")
print("    mass(P2 cap {h_1>0}) =", float(moment(Ps[1] + [vec(1,0,0)])[0]), " (0: P2 lies in {h_1<0}, so adding P is not 1-guidance-weak)")
