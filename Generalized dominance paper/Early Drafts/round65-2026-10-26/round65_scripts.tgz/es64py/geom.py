"""Shared geometry for ES64: reversed triangle, domain, helpers. Exact rationals."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
from cones import moment, vec, dot

v = [vec(F(1,5),F(2,5),F(2,5)), vec(F(2,5),F(1,5),F(2,5)), vec(F(2,5),F(2,5),F(1,5))]
u = vec(F(1,3),F(1,3),F(1,3))
def mix(a, b, t):
    return tuple((1-t)*a[i] + t*b[i] for i in range(3))
Kp = [mix(vk, u, F(1,2)) for vk in v]          # K' = (u+K)/2
U = list(Kp)                                    # U = D_{K'}
DK = list(v)                                    # D_K

def neg(a):
    return tuple(-x for x in a)
def add(*vs):
    return tuple(sum(x[i] for x in vs) for i in range(3))
def sc(c, a):
    return tuple(c*x for x in a)
def sub(a, b):
    return tuple(a[i]-b[i] for i in range(3))

def mom(ineqs):
    return moment(ineqs)[1]

def piece_beyond(k, delta, lam, centre=F(0)):
    """Cone beyond face F_{v_k} (k=0,1,2), depth 0<-v_k.h<delta*s(h), lateral
    |l(h) - centre*s(h)| < lam*s(h), where s=(v_i+v_j).h, l=(v_i-v_j).h, inside U."""
    i, j = [x for x in range(3) if x != k]
    s = add(v[i], v[j]); l = sub(v[i], v[j])
    ineqs = [neg(v[k]), add(v[k], sc(delta, s)),
             add(sub(l, sc(centre, s)), sc(lam, s)), add(neg(sub(l, sc(centre, s))), sc(lam, s))]
    return ineqs + U

def DQ(qs):
    return list(qs) + U

def fmt(x):
    return [float(t) for t in x]
