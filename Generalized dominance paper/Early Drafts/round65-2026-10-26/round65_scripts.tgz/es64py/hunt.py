"""Random test of condition (H) on structured incoherent rivals (NUMERICS for the search,
exact for every certificate found).

(H): for incoherent X there is a coherent N with m(N) >= m(X), m(N) != m(X), and
     mu((N\\X) cap hull(X\\N)) > 0.
Certificate used (sufficient, exact): points a in int(N\\X), b in int(X\\N), lam > 0 with
     a - lam*b in int R^3_+   (then a neighbourhood of a lies in hull(X\\N)).
Rival families (all inside U = D_{K'}):
  T1  X = N_p1 u N_p2            (union of two Bayes acts)
  T2  X = N_p1 \\ C               (Bayes act with a polyhedral conic hole)
  T3  X = N_p1 u C               (Bayes act with a polyhedral conic bump outside it)
  T4  X = D_K u C                (target with a bump beyond a face)
Defenders searched: N_q = U cap {q.h>0} (q on a grid) and N_q cap N_q' (pairs from the best singles).
"""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geom import *
from cones import moment, det3

random.seed(int(sys.argv[1]) if len(sys.argv) > 1 else 1)
TRIALS = int(sys.argv[2]) if len(sys.argv) > 2 else 12

def rq(lo=F(1,10)):
    while True:
        a = F(random.randint(1, 40), 40); b = F(random.randint(1, 40), 40)
        if a + b < 1 and min(a, b, 1-a-b) >= lo:
            return (a, b, 1-a-b)

def inside(ineqs, h):
    return all(dot(g, h) > 0 for g in ineqs)

def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])

def cone_ineqs(g):
    g1, g2, g3 = g
    out = []
    for (x, y, z) in ((g1, g2, g3), (g2, g3, g1), (g3, g1, g2)):
        n = cross(x, y)
        if dot(n, z) < 0:
            n = neg(n)
        out.append(n)
    return out

def rand_pt(scale=3):
    return tuple(F(random.randint(-30*scale, 30*scale), 30) for _ in range(3))

def sample_U(n):
    pts = []
    while len(pts) < n:
        h = rand_pt()
        if inside(U, h):
            pts.append(h)
    return pts

def make_rival(kind):
    if kind == 'T1':
        p1, p2 = rq(), rq()
        A, B = U+[p1], U+[p2]
        m = sub(add(mom(A), mom(B)), mom(A+[p2]))
        return (lambda h: inside(A, h) or inside(B, h)), m, (p1, p2)
    # polyhedral cone C from a small random triangle of directions near a boundary point
    if kind in ('T2', 'T3'):
        p1 = rq()
        A = U+[p1]
        while True:
            c = sample_U(1)[0]
            g = [add(c, tuple(F(random.randint(-6, 6), 30) for _ in range(3))) for _ in range(3)]
            if det3(*g) != 0 and all(inside(U, x) for x in g):
                break
        C = cone_ineqs(g) + U
        mC = mom(C); mAC = mom(A+C)
        if kind == 'T2':
            if mAC == mom(C) and moment(C)[0] > 0 and False:
                pass
            m = sub(mom(A), mAC)
            return (lambda h: inside(A, h) and not inside(C, h)), m, (p1, g)
        m = sub(add(mom(A), mC), mAC)
        return (lambda h: inside(A, h) or inside(C, h)), m, (p1, g)
    if kind == 'T4':
        k = random.randrange(3)
        cen = F(random.randint(-8, 8), 10)
        C = piece_beyond(k, F(random.randint(1, 4), 20), F(random.randint(1, 4), 20), cen)
        m = add(mom(U+DK), mom(C))
        return (lambda h: inside(DK+U, h) or inside(C, h)), m, (k, cen)

def lam_ok(a, b):
    lo, hi = F(0), None
    for i in range(3):
        if b[i] > 0:
            if a[i] <= 0:
                return False
            r = a[i]/b[i]; hi = r if hi is None else min(hi, r)
        elif b[i] < 0:
            lo = max(lo, a[i]/b[i])
        else:
            if a[i] <= 0:
                return False
    return hi is None or lo < hi

GRID = 20
qs = [(F(a, GRID), F(b, GRID), F(GRID-a-b, GRID)) for a in range(GRID+1) for b in range(GRID+1-a)]
mN1 = {q: mom(U+[q]) for q in qs}
PTS = sample_U(1500)

def certificate(inX, Nineq):
    Aset = [h for h in PTS if inside(Nineq, h) and not inX(h)]
    Bset = [h for h in PTS if inX(h) and not inside(Nineq, h)]
    for a in Aset:
        for b in Bset:
            if lam_ok(a, b):
                return a, b
    return None

def defend(inX, mX):
    singles = [(q, sub(mN1[q], mX)) for q in qs]
    good = [(q, d) for q, d in singles if min(d) > 0]
    for q, d in good:
        c = certificate(inX, U+[q])
        if c:
            return ('single', q, d, c)
    # pairs: intersections of two half-spaces, q from all grid points with small loss
    ranked = sorted(singles, key=lambda t: -min(t[1]))[:25]
    for i in range(len(ranked)):
        for j in range(i+1, len(ranked)):
            q1, q2 = ranked[i][0], ranked[j][0]
            Nq = U+[q1, q2]
            d = sub(mom(Nq), mX)
            if min(d) > 0:
                c = certificate(inX, Nq)
                if c:
                    return ('pair', (q1, q2), d, c)
    return None

if __name__ == "__main__":
    stats = {}
    for kind in ('T1', 'T2', 'T3', 'T4'):
        ok = fail = triv = 0
        for _ in range(TRIALS):
            inX, mX, par = make_rival(kind)
            # skip rivals that are (numerically) coherent or empty modifications
            r = defend(inX, mX)
            if r is None:
                fail += 1
                print("  NO DEFENDER FOUND:", kind, par)
            else:
                ok += 1
        stats[kind] = (ok, fail)
        print(kind, "certified:", ok, " not found:", fail, flush=True)
    print("SUMMARY", stats)
    