"""Generic random test of (H) on conic rivals (section-plane geometry, exact certificates).
For a rival X (union/difference of polyhedral cones inside U):
  1. find priors q with m(N_q) - m(X) >> 0 by local search on min-gap (exact moments);
  2. for each such Bayes act, and for cuts N_q cap N_q' (q' random near q), test the
     certificate  'some sampled a in N\\X lies in int conv( sampled points of X\\N  u {e1,e2,e3} )'
     in the section sum(h)=1 (= a in int cone(X\\N u R^3_+), hence in hull(X\\N)).
Search = NUMERICS; each success is an exact certificate (CHECKED)."""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geom import *
from cones import moment, det3
from hunt import inside, cone_ineqs, rq
from t1c import in_open_hull, E

seed = int(sys.argv[1]) if len(sys.argv) > 1 else 2
TR = int(sys.argv[2]) if len(sys.argv) > 2 else 6
random.seed(seed)

def sec_pts(n):
    out = []
    while len(out) < n:
        x = (F(random.randint(-4000, 4000), 1000), F(random.randint(-4000, 4000), 1000))
        h = (x[0], x[1], 1-x[0]-x[1])
        if inside(U, h): out.append(h)
    return out
PTS = sec_pts(6000)

def best_dominator(mX, starts):
    best = None
    for q0 in starts:
        q = q0; step = F(1, 40)
        d = sub(mom(U+[q]), mX); val = min(d)
        for it in range(60):
            imp = False
            for da, db in ((1,0),(-1,0),(0,1),(0,-1),(1,-1),(-1,1)):
                qq = (q[0]+da*step, q[1]+db*step, q[2]-(da+db)*step)
                if min(qq) < 0: continue
                dd = sub(mom(U+[qq]), mX)
                if min(dd) > val:
                    q, d, val, imp = qq, dd, min(dd), True
            if not imp:
                step /= 2
                if step < F(1, 10**7): break
        if best is None or val > best[0]:
            best = (val, q, d)
    return best

LOCAL = []
def local_pts(g, n=3000):
    cen = sc(F(1,3), add(*g))
    out = []
    for _ in range(n):
        w = [F(random.randint(0, 1000)) for _ in range(3)]
        s = sum(w) or F(1)
        x = add(*[sc(wi/s, gi) for wi, gi in zip(w, g)])
        x = add(cen, sc(F(random.choice([1, 2, 3, 5])), sub(x, cen)))
        if inside(U, x): out.append(x)
    return out

def test_cert(inX, N):
    P = PTS + LOCAL
    A = [h for h in P if inside(N, h) and not inX(h)]
    B = [h for h in P if inX(h) and not inside(N, h)]
    if not A or not B: return None
    Bs = B if len(B) < 400 else random.sample(B, 400)
    for a in A[:200]:
        if in_open_hull(a, Bs + E):
            return a
    return None

def rival(kind):
    p1 = rq()
    A = U+[p1]
    while True:
        cen = PTS[random.randrange(len(PTS))]
        g = [add(cen, (F(random.randint(-400,400),1000), F(random.randint(-400,400),1000), F(0))) for _ in range(3)]
        g = [(x[0], x[1], 1-x[0]-x[1]) for x in g]
        if det3(*g) != 0 and all(inside(U, x) for x in g): break
    C = cone_ineqs(g) + U
    LOCAL[:] = local_pts(g)
    mAC = moment(A+C); mC = moment(C)
    if kind == 'hole':
        if mAC[0] == 0 or mAC[0] == mC[0]: return None      # need C to meet N_p1 and stick out (else X coherent or C inside)
        return (lambda h: inside(A, h) and not inside(C, h)), sub(mom(A), mAC[1])
    if kind == 'deephole':
        if mAC[0] != mC[0]: return None                     # C inside N_p1
        return (lambda h: inside(A, h) and not inside(C, h)), sub(mom(A), mAC[1])
    if kind == 'bump':
        if mAC[0] == mC[0]: return None                     # C must stick out
        return (lambda h: inside(A, h) or inside(C, h)), sub(add(mom(A), mC[1]), mAC[1])

for kind in (sys.argv[3].split(',') if len(sys.argv) > 3 else ('deephole', 'hole', 'bump')):
    ok = tot = 0
    while tot < TR:
        r = rival(kind)
        if r is None: continue
        inX, mX = r
        tot += 1
        starts = [rq() for _ in range(8)] + [(F(1,3),F(1,3),F(1,3))]
        val, q, d = best_dominator(mX, starts)
        if val <= 0:
            print(" ", kind, "no strict Bayes dominator found by local search (gap %.2e)" % float(val)); continue
        res = test_cert(inX, U+[q])
        tag = 'bayes'
        if not res:
            for k in range(120):
                r = 2000 * (10 ** (k % 3))
                q2 = (q[0] + F(random.randint(-200,200), r), q[1] + F(random.randint(-200,200), r))
                q2 = (q2[0], q2[1], 1-q2[0]-q2[1])
                if min(q2) < 0: continue
                N = U+[q2] if k % 2 else U+[q, q2]
                if min(sub(mom(N), mX)) <= 0: continue
                res = test_cert(inX, N)
                if res: tag = 'cut'; break
        if not res:
            # thin cuts along the faces of U: q' = vertex of K' pushed slightly outward
            for k in range(240):
                kv = Kp[k % 3]
                r = F(1, 10 ** (1 + (k // 3) % 4))
                w = (F(random.randint(-100,100),100), F(random.randint(-100,100),100))
                w = (w[0], w[1], -w[0]-w[1])
                q2 = add(kv, sc(r, w))
                if min(q2) < 0: continue
                N = U+[q, q2]
                if min(sub(mom(N), mX)) <= 0: continue
                res = test_cert(inX, N)
                if res: tag = 'U-face cut'; break
        ok += res is not None
        print(" ", kind, "gap %.2e" % float(val), "certified:", res is not None, tag if res else "", flush=True)
    print(kind, "certified", ok, "/", tot, flush=True)
