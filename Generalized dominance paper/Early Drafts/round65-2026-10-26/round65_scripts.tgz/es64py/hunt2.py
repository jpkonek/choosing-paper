"""Focused test of (H) on X = N_p1 u N_p2 (union of two Bayes acts) and on hole/bump rivals,
with a richer defender family: N_S = U cap {s.h>0 : s in S}, |S| <= 2, S from a grid
(every such N_S is coherent: N_S = D_{conv(K' u S)}).
A defender is accepted only with an exact certificate:
   m(N) - m(X) >> 0  and points a in int(N\\X), b1,b2 in int(X\\N), with
   a - (l1 b1 + l2 b2) in int R^3_+ for some l1,l2 >= 0 (LP on a grid of l's).
Search = NUMERICS; each certificate = CHECKED (exact rationals)."""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geom import *
from cones import moment
from hunt import rq, inside, sample_U, make_rival

random.seed(int(sys.argv[1]) if len(sys.argv) > 1 else 7)
TRIALS = int(sys.argv[2]) if len(sys.argv) > 2 else 6
KIND = sys.argv[3] if len(sys.argv) > 3 else 'T1'
G = 15
grid = [(F(a, G), F(b, G), F(G-a-b, G)) for a in range(G+1) for b in range(G+1-a)]
PTS = sample_U(2500)
LAMS = [F(k, 8) for k in range(0, 33)]

def pos(x):
    return all(t > 0 for t in x)

def cert(inX, N):
    A = [h for h in PTS if inside(N, h) and not inX(h)]
    B = [h for h in PTS if inX(h) and not inside(N, h)]
    if not A or not B:
        return None
    for a in A:
        for b in B:
            for l in LAMS[1:]:
                if pos(sub(a, sc(l, b))):
                    return (a, b)
    # two-point combinations
    Bs = B[:60]
    for a in A[:60]:
        for i in range(len(Bs)):
            for j in range(i+1, len(Bs)):
                for l1 in LAMS[1:17]:
                    for l2 in LAMS[1:17]:
                        if pos(sub(a, add(sc(l1, Bs[i]), sc(l2, Bs[j])))):
                            return (a, Bs[i], Bs[j])
    return None

mS1 = {s: mom(U+[s]) for s in grid}
found = 0
for trial in range(TRIALS):
    inX, mX, par = make_rival(KIND)
    best = None
    cands = []
    for s in grid:
        d = sub(mS1[s], mX)
        if min(d) > 0:
            cands.append((min(d), [s]))
    for i, s in enumerate(grid):
        for t in grid[i+1:]:
            # quick prune: intersection moment <= each single in no simple way; compute
            N = U+[s, t]
            d = sub(mom(N), mX)
            if min(d) > 0:
                cands.append((min(d), [s, t]))
    cands.sort(key=lambda c: -c[0])
    ok = None
    for score, S in cands[:400]:
        c = cert(inX, U+S)
        if c:
            ok = (S, score, c)
            break
    print(KIND, "trial", trial, "par", [tuple(map(str, p)) if isinstance(p, tuple) else p for p in par] if KIND=='T1' else par,
          "#dominating N_S:", len(cands), " certified:", ok is not None, (ok[0], float(ok[1])) if ok else "", flush=True)
    found += ok is not None
print("SUMMARY", KIND, found, "/", TRIALS)
