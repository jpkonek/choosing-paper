"""T1 refined: X = N_p1 u N_p2.  Sample priors q near the best dominator q*, keep strict Bayes
dominators, and decide the hull test for N_q exactly by plane geometry in the section sum(h)=1:
   The section of N_q \\ X is the part of the triangle U beyond both lines l1, l2 and inside l_q;
   X \\ N_q consists of the parts of the two lobes beyond l_q.  We search a in N_q\\X and
   b1 in lobe1\\N_q, b2 in lobe2\\N_q with a - l1*b1 - l2*b2 >> 0 (exact rationals).
Search = NUMERICS; every reported certificate is exact (CHECKED)."""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geom import *
from hunt import inside

def section_points(n, centre, rad):
    pts = []
    for _ in range(n):
        x = add(centre, (F(random.randint(-1000,1000),1000)*rad, F(random.randint(-1000,1000),1000)*rad, F(0)))
        x = (x[0], x[1], 1 - x[0] - x[1])
        pts.append(x)
    return pts

def study(p1, p2, qstar, rad_q=F(3,1000), nq=300, seed=5):
    random.seed(seed)
    A, B = U+[p1], U+[p2]
    mX = sub(add(mom(A), mom(B)), mom(A+[p2]))
    inX = lambda h: inside(A, h) or inside(B, h)
    c = (p1[1]*p2[2]-p1[2]*p2[1], p1[2]*p2[0]-p1[0]*p2[2], p1[0]*p2[1]-p1[1]*p2[0])
    c = sc(1/sum(c), c)
    pts = [h for h in section_points(6000, c, F(3)) if inside(U, h)]
    pts += [h for h in section_points(6000, c, F(1,2)) if inside(U, h)]
    ndom = ncert = 0
    example = None
    for _ in range(nq):
        dq = (F(random.randint(-1000,1000),1000)*rad_q, F(random.randint(-1000,1000),1000)*rad_q)
        q = (qstar[0]+dq[0], qstar[1]+dq[1], 1-qstar[0]-dq[0]-qstar[1]-dq[1])
        if min(q) < 0: continue
        d = sub(mom(U+[q]), mX)
        if min(d) <= 0: continue
        ndom += 1
        Nq = U+[q]
        As = [h for h in pts if inside(Nq, h) and not inX(h)]
        B1 = [h for h in pts if inside(A, h) and not inside(B, h) and not inside(Nq, h)]
        B2 = [h for h in pts if inside(B, h) and not inside(A, h) and not inside(Nq, h)]
        ok = None
        if As and B1 and B2:
            random.shuffle(As); random.shuffle(B1); random.shuffle(B2)
            for a in As[:30]:
                for b1 in B1[:30]:
                    for b2 in B2[:30]:
                        for l1 in (F(1,8), F(1,4), F(1,2), F(1)):
                            for l2 in (F(1,8), F(1,4), F(1,2), F(1)):
                                if min(sub(a, add(sc(l1, b1), sc(l2, b2)))) > 0:
                                    ok = (a, b1, b2, l1, l2); break
                            if ok: break
                        if ok: break
                    if ok: break
                if ok: break
        if ok:
            ncert += 1
            if example is None: example = (q, d, ok)
        else:
            if ndom <= 3:
                print("   no cert at q", fmt(q), " |N\\X|>0:", bool(As), " lobe1 cut:", bool(B1), " lobe2 cut:", bool(B2))
    print("p1", fmt(p1), "p2", fmt(p2), ": strict dominators sampled", ndom, " with certificate", ncert)
    if example:
        q, d, ok = example
        print("   example q =", [str(x) for x in q], " gap", fmt(d))
        print("   a =", [str(x) for x in ok[0]], " b1 =", [str(x) for x in ok[1]], " b2 =", [str(x) for x in ok[2]], " l =", ok[3], ok[4])

if __name__ == "__main__":
    study((F(1,5),F(13,40),F(19,40)), (F(1,5),F(1,8),F(27,40)), (F(2137,10000), F(3104,10000), F(4759,10000)))
    study((F(3,8),F(3,8),F(1,4)), (F(1,4),F(19,40),F(11,40)), (F(3581,10000), F(3811,10000), F(2608,10000)), rad_q=F(1,1000))
