"""Exact moments of polyhedral cones in R^3 under the density exp(-|h|_1).

A cone is given by a list of strict linear inequalities a.h > 0 (a: tuple of Fractions).
Within an orthant with sign vector s, |h|_1 = s.h, and for a simplicial cone
cone(g1,g2,g3) with s.g_k = 1 one has
   mass   = |det[g1 g2 g3]|,
   moment = |det[g1 g2 g3]| * (g1+g2+g3)            (exact).
We clip the orthant cross-section {s.h = 1, s_i h_i >= 0} (a triangle) by the
half-planes a.h >= 0, then fan-triangulate.  Everything is exact (Fractions).
"""
from fractions import Fraction as F
from itertools import product

def dot(a, b):
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]

def det3(a, b, c):
    return (a[0]*(b[1]*c[2]-b[2]*c[1]) - a[1]*(b[0]*c[2]-b[2]*c[0])
            + a[2]*(b[0]*c[1]-b[1]*c[0]))

def clip(poly, a):
    """Clip a convex polygon (list of 3-vectors, cyclic) by a.h >= 0."""
    out = []
    n = len(poly)
    for k in range(n):
        p, q = poly[k], poly[(k+1) % n]
        fp, fq = dot(a, p), dot(a, q)
        if fp >= 0:
            out.append(p)
        if (fp > 0 and fq < 0) or (fp < 0 and fq > 0):
            t = fp / (fp - fq)
            out.append(tuple(p[i] + t*(q[i]-p[i]) for i in range(3)))
    # remove duplicates
    res = []
    for p in out:
        if not res or res[-1] != p:
            res.append(p)
    if len(res) > 1 and res[0] == res[-1]:
        res.pop()
    return res

ORTHANTS = list(product((1, -1), repeat=3))

def orthant_triangle(s):
    return [tuple(F(s[i]) if i == k else F(0) for i in range(3)) for k in range(3)]

def moment(ineqs):
    """Return (mass, moment vector) of the open cone {a.h > 0 for a in ineqs}."""
    mass = F(0)
    mom = [F(0), F(0), F(0)]
    for s in ORTHANTS:
        poly = orthant_triangle(s)
        for a in ineqs:
            poly = clip(poly, a)
            if len(poly) < 3:
                break
        if len(poly) < 3:
            continue
        g0 = poly[0]
        for k in range(1, len(poly)-1):
            g1, g2 = poly[k], poly[k+1]
            d = abs(det3(g0, g1, g2))
            if d == 0:
                continue
            mass += d
            for i in range(3):
                mom[i] += d*(g0[i]+g1[i]+g2[i])
    return mass, tuple(mom)

def vec(*xs):
    return tuple(F(x) for x in xs)
