"""ES64 Proposition 5.6 (exact certificate for a whole class of collar rivals).
Boxes B_k := piece_beyond(k, 1/10, 1/10) (thin pieces beyond the face midpoints of D_K).
Defender N := D_{Q_t}, Q_t = (1-t)K + t u, t = 3/23.
(1) Brier part, for EVERY measurable P inside B_1 u B_2 u B_3:
      m(N) - m(D_K u P) >= m(N \\ D_K) - m_k(B_k) e_k-type bound  >> 0.
    Needs: on B_k, h_k > 0 and h_j < 0 (j != k)  [checked exactly: masses of the wrong-sign parts are 0],
    and the coordinatewise bound  m_k(N\\D_K) - m_k(B_k) > 0,  m_j(N\\D_K) > 0.
(2) Hull part: corner cones C_k^+-, inside B_k \\ N.  For a density point p of P in C_1^+,
      y(p) := p + (s(p)/9)(e_3 + (e_1+e_2)/1000),   s = (v_2+v_3).h,
    is linear in p; we check at the 4 extreme rays of C_1^+ that y lies in N, beyond face 1,
    outside B_1 laterally, inside the other two half-spaces v_2.h>0, v_3.h>0 (so outside B_2, B_3),
    and that C_1^+ misses N.  (C_1^- with e_2 and the other faces follow by the symmetry of the
    configuration under permutations of worlds; we also check C_1^- directly.)
Exact rationals."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geom import *
from cones import moment

delta, lam = F(1,10), F(1,10)
Bk = [piece_beyond(k, delta, lam) for k in range(3)]
t = F(3,23)
Q = [mix(vk, u, t) for vk in v]
Nd = DQ(Q)
e = [vec(1,0,0), vec(0,1,0), vec(0,0,1)]
ok = True
for k in range(3):
    for j in range(3):
        sgn = vec(*[(1 if i == j else 0) for i in range(3)])
        wrong = moment(Bk[k] + ([neg(sgn)] if j == k else [sgn]))[0]
        if wrong != 0: ok = False
print("(1a) sign pattern on boxes (h_k>0, h_j<0 on B_k):", ok)
mNK = sub(mom(Nd), mom(U+DK))
bound = [mNK[k] - mom(Bk[k])[k] for k in range(3)]
print("(1b) m(N\\D_K) =", fmt(mNK), "; m_k(N\\D_K) - m_k(B_k) =", [float(x) for x in bound],
      " all > 0:", all(x > 0 for x in bound) and all(x > 0 for x in mNK))

# corner cones of B_1 in coordinates a = v2.h, b = v3.h, c = -v1.h  (s=a+b, lat=(a-b)/s, depth=c/s)
from bump import solve3, wv
r2 = (F(2),F(-3),F(2)); r3 = (F(2),F(2),F(-3))
def H(a, b, c): return add(sc(a, r2), sc(b, r3), sc(c, wv))
def ray(lat, depth): return H((1+lat)/2, (1-lat)/2, depth)
s_dir = add(v[1], v[2]); l_dir = sub(v[1], v[2])
def y_of(p, side):
    eside = e[2] if side > 0 else e[1]
    eo = add(e[0], e[1]) if side > 0 else add(e[0], e[2])
    return add(p, sc(dot(s_dir, p)/9, add(eside, sc(F(1,1000), eo))))
def inside_all(ineqs, h): return all(dot(g, h) > 0 for g in ineqs)
allok = ok and all(x > 0 for x in bound)
for side in (+1, -1):
    lats = (F(96,1000), F(1,10)) if side > 0 else (F(-1,10), F(-96,1000))
    rays = [ray(la, de) for la in lats for de in (F(7,100), F(9,100))]
    for p in rays:
        y = y_of(p, side)
        c1 = dot(Q[0], p) < 0                         # p outside N (beyond N's face 1)
        c2 = inside_all(Nd, y)                         # y in N
        c3 = dot(v[0], y) < 0                          # y beyond face 1 (not in D_K)
        c4 = side*dot(l_dir, y) > lam*dot(s_dir, y)    # y outside B_1 laterally
        c5 = dot(v[1], y) > 0 and dot(v[2], y) > 0     # y not in B_2, B_3
        c6 = all(dot(g, p) >= 0 for g in Bk[0])        # ray in closed B_1
        allok = allok and c1 and c2 and c3 and c4 and c5 and c6
        print("  side", side, "ray lat/depth", [float(dot(l_dir,p)/dot(s_dir,p)), float(-dot(v[0],p)/dot(s_dir,p))],
              "checks:", c1, c2, c3, c4, c5, c6)
print("PROPOSITION 5.6 CERTIFICATE:", allok)
