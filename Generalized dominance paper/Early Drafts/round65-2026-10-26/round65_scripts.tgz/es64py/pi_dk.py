"""Which Bayes acts N_pi = U cap {pi.h>0} Brier-dominate D_K (componentwise moments)?
Reversed triangle K = {m_i <= 2/5}; U = D_{K'}, K' = (u+K)/2.  Density exp(-|h|_1). Exact."""
from fractions import Fraction as F
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cones import moment, vec
import sys

v = [vec(F(1,5),F(2,5),F(2,5)), vec(F(2,5),F(1,5),F(2,5)), vec(F(2,5),F(2,5),F(1,5))]
u = vec(F(1,3),F(1,3),F(1,3))
w = [tuple((u[i]+vk[i])/2 for i in range(3)) for vk in v]
U = list(w)
DK = list(v)
mDK = moment(U+DK)[1]
mU = moment(U)[1]
print("m(D_K) =", [float(x) for x in mDK], " m(U) =", [float(x) for x in mU])

N = int(sys.argv[1]) if len(sys.argv) > 1 else 40
dom = []
for a in range(N+1):
    for b in range(N+1-a):
        c = N-a-b
        pi = vec(F(a,N),F(b,N),F(c,N))
        m = moment(U+[pi])[1]
        d = tuple(m[i]-mDK[i] for i in range(3))
        if min(d) > 0:
            dom.append((pi, d))
print("grid", N, ": #pi with m(N_pi) >> m(D_K):", len(dom))
for k in range(3):
    best = min(dom, key=lambda t: t[0][k])
    print(" min pi_%d over Pi(D_K):" % (k+1), float(best[0][k]), [float(x) for x in best[0]])
print(" 1/5 =", 0.2)
