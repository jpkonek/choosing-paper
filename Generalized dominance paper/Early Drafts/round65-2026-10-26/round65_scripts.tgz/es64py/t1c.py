"""T1 exact construction.  X = N_p1 u N_p2, lines l1 = p1^perp, l2 = p2^perp meeting at c in U.
For a strict Bayes dominator N_q whose line l_q separates c from... we compute in the section
sum(h)=1:  c1 = l_q cap l1,  c2 = l_q cap l2.  If both lie in U and q.c > 0 (c inside N_q),
then N_q \\ X contains the open triangle (c, c1, c2) (beyond both l1, l2, inside l_q) and
X \\ N_q contains points of both lobes just beyond c1 and c2.  Certificate (exact):
   a = centroid(c,c1,c2),  b1 = c1 + s(c1-c) + small move into lobe1, b2 likewise,
   a in int conv{b1, b2, e1, e2, e3}   (section of int cone(b1,b2,R^3_+)).
Lemma 5.3 of ES64_notes: this is a non-invertibility certificate."""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geom import *
from hunt import inside

def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def sect(x):
    s = sum(x); return sc(1/s, x)
def meet(p, q):
    """section point of the two lines p.h=0, q.h=0"""
    return sect(cross(p, q))

def in_open_hull(a, pts):
    """a strictly inside conv(pts) in the plane sum=1 (use coords 0,1). exact."""
    P = [(x[0], x[1]) for x in pts]
    # convex hull (monotone chain)
    P = sorted(set(P))
    def cr(o, a, b): return (a[0]-o[0])*(b[1]-o[1]) - (a[1]-o[1])*(b[0]-o[0])
    lo, hi = [], []
    for p in P:
        while len(lo) >= 2 and cr(lo[-2], lo[-1], p) <= 0: lo.pop()
        lo.append(p)
    for p in reversed(P):
        while len(hi) >= 2 and cr(hi[-2], hi[-1], p) <= 0: hi.pop()
        hi.append(p)
    H = lo[:-1] + hi[:-1]
    A = (a[0], a[1])
    return all(cr(H[i], H[(i+1) % len(H)], A) > 0 for i in range(len(H)))

E = [vec(1,0,0), vec(0,1,0), vec(0,0,1)]

def certify(p1, p2, q):
    A, B, Nq = U+[p1], U+[p2], U+[q]
    c = meet(p1, p2); c1 = meet(q, p1); c2 = meet(q, p2)
    if not (dot(q, c) > 0 and inside(U, c1) and inside(U, c2)):
        return None
    a = sc(F(1,3), add(c, c1, c2))
    inX = lambda h: inside(A, h) or inside(B, h)
    if not (inside(Nq, a) and not inX(a)):
        return None
    for s in (F(1,10), F(1,4), F(1,2), F(1)):
        for eps in (F(1,10**k) for k in range(2, 9)):
            # move beyond c_i along l_i, then into lobe i by eps*(direction of increasing p_i... )
            b1 = add(c1, sc(s, sub(c1, c)))
            b2 = add(c2, sc(s, sub(c2, c)))
            # nudge into the lobes: lobe1 = {p1>0>=p2}: move along gradient of p1 restricted to section
            g1 = sub(p1, sc(sum(p1)/3, vec(1,1,1))); g2 = sub(p2, sc(sum(p2)/3, vec(1,1,1)))
            b1 = add(b1, sc(eps, g1)); b2 = add(b2, sc(eps, g2))
            ok1 = inside(A, b1) and not inside(B, b1) and not inside(Nq, b1) and inside(U, b1)
            ok2 = inside(B, b2) and not inside(A, b2) and not inside(Nq, b2) and inside(U, b2)
            if ok1 and ok2 and in_open_hull(a, [b1, b2] + E):
                return (a, b1, b2)
    return None

def scan(p1, p2, qstar, rad, n=400, seed=11):
    random.seed(seed)
    A, B = U+[p1], U+[p2]
    mX = sub(add(mom(A), mom(B)), mom(A+[p2]))
    nd = nc = 0; ex = None
    for _ in range(n):
        q = (qstar[0] + F(random.randint(-1000,1000),1000)*rad, qstar[1] + F(random.randint(-1000,1000),1000)*rad)
        q = (q[0], q[1], 1-q[0]-q[1])
        if min(q) < 0: continue
        d = sub(mom(U+[q]), mX)
        if min(d) <= 0: continue
        nd += 1
        r = certify(p1, p2, q)
        if r:
            nc += 1
            if ex is None: ex = (q, d, r)
    print("p1", fmt(p1), "p2", fmt(p2), ": strict dominators", nd, " certified", nc)
    if ex:
        q, d, r = ex
        print("   q =", [str(x) for x in q], " m(N_q)-m(X) =", fmt(d))
        print("   a =", [str(x) for x in r[0]])
        print("   b1 =", [str(x) for x in r[1]])
        print("   b2 =", [str(x) for x in r[2]])

if __name__ == "__main__":
    scan((F(1,5),F(13,40),F(19,40)), (F(1,5),F(1,8),F(27,40)), (F(2137,10000), F(3104,10000)), F(2,1000))
    scan((F(3,8),F(3,8),F(1,4)), (F(1,4),F(19,40),F(11,40)), (F(3581,10000), F(3811,10000)), F(5,10000))
