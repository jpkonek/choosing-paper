"""Family T1: X = N_p1 u N_p2 (union of two Bayes acts whose boundary lines cross at the ray c in U).
Scan priors q on a fine grid; for every strict Bayes dominator N_q of X decide (exactly) whether
the record (N_q\\X, X\\N_q) passes the hull test, using the criterion of ES64 Lemma 5.3:
   N_q\\X is non-null and lies in W = {p1.h<=0, p2.h<=0};  a point a of it lies in
   int cone(b1, b2, R^3_+) with b1 in N_p1\\N_p2\\N_q, b2 in N_p2\\N_p1\\N_q.
We test this with exact LPs on sampled points (search = NUMERICS, positives = CHECKED)."""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geom import *
from cones import moment
from hunt import inside, sample_U

def run(p1, p2, G=120, npts=4000, seed=3):
    random.seed(seed)
    A, B = U+[p1], U+[p2]
    mX = sub(add(mom(A), mom(B)), mom(A+[p2]))
    c = (p1[1]*p2[2]-p1[2]*p2[1], p1[2]*p2[0]-p1[0]*p2[2], p1[0]*p2[1]-p1[1]*p2[0])
    if sum(c) < 0: c = neg(c)
    print("p1", fmt(p1), "p2", fmt(p2), " c =", fmt(sc(1/sum(c), c)), " c in U:", inside(U, c))
    doms = []
    for a in range(G+1):
        for b in range(G+1-a):
            q = (F(a,G), F(b,G), F(G-a-b,G))
            d = sub(mom(U+[q]), mX)
            if min(d) > 0:
                doms.append((q, d))
    print("  strict Bayes dominators on grid 1/%d: %d" % (G, len(doms)))
    if not doms: return
    # classify: does the q-line cut the wedge W near c on both sides?
    pts = sample_U(npts)
    # add points near c
    cn = sc(1/sum(c), c)
    for _ in range(npts):
        pts.append(add(cn, tuple(F(random.randint(-300,300), 1000) for _ in range(3))))
    pts = [h for h in pts if inside(U, h)]
    inX = lambda h: inside(A, h) or inside(B, h)
    passed = 0
    for q, d in doms:
        Nq = U+[q]
        As = [h for h in pts if inside(Nq, h) and not inX(h)]
        B1 = [h for h in pts if inside(A, h) and not inside(B, h) and not inside(Nq, h)]
        B2 = [h for h in pts if inside(B, h) and not inside(A, h) and not inside(Nq, h)]
        ok = False
        if As and B1 and B2:
            for a in As[:40]:
                for b1 in B1[:40]:
                    for b2 in B2[:40]:
                        # a = l1 b1 + l2 b2 + p, p >> 0 : try a few (l1,l2)
                        for l1 in (F(1,4), F(1,2), F(1), F(2)):
                            for l2 in (F(1,4), F(1,2), F(1), F(2)):
                                pp = sub(a, add(sc(l1, b1), sc(l2, b2)))
                                if min(pp) > 0:
                                    ok = True; break
                            if ok: break
                        if ok: break
                    if ok: break
                if ok: break
        passed += ok
    print("  dominators with a certificate:", passed, "of", len(doms))

if __name__ == "__main__":
    run((F(1,5),F(13,40),F(19,40)), (F(1,5),F(1,8),F(27,40)))
    run((F(3,8),F(3,8),F(1,4)), (F(1,4),F(19,40),F(11,40)))
    run((F(17,40),F(9,40),F(7,20)), (F(7,40),F(3,5),F(9,40)))
