"""Rival X1 = D_K u P, P a thin piece beyond the midpoint of face F_{v_1}.
(a) every Bayes act that strictly Brier-dominates X1 contains P (so in the deletion design with
    only Bayes acts + D_K protected, X1 would have no admissible defender);
(b) an explicit coherent defender N = D_Q (Q = K shrunk by t) with m(N) - m(X1) >> 0, and an
    explicit open cone R inside (N \\ X1) cap hull(X1 \\ N)  (non-invertibility certificate).
Exact arithmetic (density exp(-|h|_1))."""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geom import *
from cones import moment

delta, lam = F(1,10), F(1,10)
P = piece_beyond(0, delta, lam)
mP_mass, mP = moment(P)
mX = add(mom(U+DK), mP)
print("mass(P) =", float(mP_mass), " m(P) =", fmt(mP))
print("m(X1) =", fmt(mX))

# (a) Bayes dominators
N = 60
cnt = 0; cnt_drop = 0
for a in range(N+1):
    for b in range(N+1-a):
        pi = vec(F(a,N), F(b,N), F(N-a-b,N))
        d = sub(mom(U+[pi]), mX)
        if min(d) > 0:
            cnt += 1
            drop = moment(P+[neg(pi)])[0]      # mass of P cap {pi.h<0}
            if drop > 0:
                cnt_drop += 1
print("(a) grid %d: Bayes acts strictly dominating X1: %d; of these dropping part of P: %d" % (N, cnt, cnt_drop))

# (b) defender
t = F(3,23)                     # t/(1-t) = 3/20, face-1 depth eta = delta/2 at the midpoint
Q = [mix(vk, u, t) for vk in v]
Nd = DQ(Q)
dN = sub(mom(Nd), mX)
print("(b) t =", t, " m(N)-m(X1) =", fmt(dN), " >>0:", min(dN) > 0)
# exact: P \ N non-null, and the certificate cone R
PminusN = moment(P + [neg(Q[0])])[0]
print("    mass(P \\ N) =", float(PminusN), ">0:", PminusN > 0)
# three points of int(P\N): depth 3/4*delta (between eta=delta/2 and delta), lateral near +lam edge
r2 = (F(2),F(-3),F(2)); r3 = (F(2),F(2),F(-3))
m1 = add(r2, r3)                 # (4,-1,-1): s=2, l=0, v1.m1=0
s_dir = add(v[1], v[2]); l_dir = sub(v[1], v[2])
def point(depth, lat):
    # h = m1 + x*(r2 - r3) + y*n with s(h)=2 kept approx; solve exactly below
    # use parametrisation h = a*r2 + b*r3 - c*e where e=(1,0,0)... simpler: search on a small grid
    return None
# explicit construction: h(a,b,c) = a*r2 + b*r3 - c*(1,1,1)/... ; v1.r2=v1.r3=0, v2.r2=1,v2.r3=0, v3.r3=1
# so for h = a r2 + b r3 + c w with w chosen so v1.w=-1, v2.w=v3.w=0: w solves V w = (-1,0,0)
import itertools
def solve3(M, rhs):
    # Cramer
    from cones import det3
    cols = list(zip(*M))
    D = det3(*M)
    out = []
    for k in range(3):
        Mk = [list(row) for row in M]
        for r in range(3):
            Mk[r][k] = rhs[r]
        out.append(det3(*[tuple(x) for x in Mk]) / D)
    return tuple(out)
wv = solve3([v[0], v[1], v[2]], (F(-1), F(0), F(0)))
def H(a, b, c):
    return add(sc(a, r2), sc(b, r3), sc(c, wv))   # v1.H=-c, v2.H=a, v3.H=b ; s=a+b, l=a-b
def inP(h):  return all(dot(g, h) > 0 for g in P)
def inN(h):  return all(dot(g, h) > 0 for g in Nd)
def inDK(h): return all(dot(g, h) > 0 for g in DK)
# depth c/(a+b); lateral (a-b)/(a+b)
p_pts = [H(F(1099,2000), F(901,2000), F(150,2000)),    # lat=0.099, depth 0.075
         H(F(1098,2000), F(902,2000), F(160,2000)),      # lat=0.098, depth 0.080
         H(F(1099,2000), F(901,2000), F(170,2000))]      # lat=0.099, depth 0.085
print("    p-points in P\\N:", [inP(p) and not inN(p) for p in p_pts])
e3 = vec(0,0,1)
tau = F(1,10)
y_pts = [mix(p, e3, tau) for p in p_pts]
def lat_depth(h):
    s = dot(s_dir, h); return float(dot(l_dir, h)/s), float(-dot(v[0], h)/s)
for yv in y_pts:
    print("    generator y: lat,depth =", lat_depth(yv), " inN:", inN(yv), " inDK:", inDK(yv),
          " outside P-band:", dot(l_dir, yv) > lam*dot(s_dir, yv), " beyond face1:", dot(v[0], yv) < 0)
from cones import det3
print("    generators independent:", det3(*y_pts) != 0)
ok = all(inN(yv) and dot(v[0], yv) < 0 and dot(l_dir, yv) > lam*dot(s_dir, yv) for yv in y_pts)
print("CERTIFICATE (b):", ok and min(dN) > 0 and PminusN > 0)
