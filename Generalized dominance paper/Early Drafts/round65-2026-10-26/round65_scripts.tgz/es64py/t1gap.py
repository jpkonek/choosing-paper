"""max over q of min_i (m(N_q)-m(X))_i for X = N_p1 u N_p2 (float scan, then local refinement)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geom import *
def gap(p1, p2, G=60):
    A, B = U+[p1], U+[p2]
    mX = sub(add(mom(A), mom(B)), mom(A+[p2]))
    best = None
    for a in range(G+1):
        for b in range(G+1-a):
            q = (F(a,G), F(b,G), F(G-a-b,G))
            d = sub(mom(U+[q]), mX)
            if best is None or min(d) > best[0]:
                best = (min(d), q, d)
    # refine
    step = F(1, G)
    q = best[1]
    for it in range(40):
        improved = False
        for da, db in ((1,0),(-1,0),(0,1),(0,-1),(1,-1),(-1,1)):
            qq = (q[0]+da*step, q[1]+db*step, q[2]-(da+db)*step)
            if min(qq) < 0: continue
            d = sub(mom(U+[qq]), mX)
            if min(d) > best[0]:
                best = (min(d), qq, d); q = qq; improved = True
        if not improved:
            step /= 2
    print("p1", fmt(p1), "p2", fmt(p2), "best min-gap", float(best[0]), "at q", fmt(best[1]), "gap", fmt(best[2]))
    print("   m(X) =", fmt(mX), " m(N_p1) =", fmt(mom(A)), " m(N_p2) =", fmt(mom(B)))
gap((F(1,5),F(13,40),F(19,40)), (F(1,5),F(1,8),F(27,40)))
gap((F(3,8),F(3,8),F(1,4)), (F(1,4),F(19,40),F(11,40)))
