"""REF65_ad: does  completeness + (IB) + (TP) + reflexivity + strict (G)  imply (Add)?

AD65 §0.2 / §3 summary claim that, apart from (Tr) and completeness + (TC), nothing in the list implies
(Add).  The maximal combination not covered by AD65's examples is  complete + (IB) + (TP)  (without
(TC); with (TC) it is transitive).  The 3-atom census (lattice.py) finds no witness.

For record relations, every constraint here is a 2-clause:
   guided r:                 x_r
   anti-guided non-null r:   not x_r
   completeness:             x_r or x_{r^-1}
   (TP):                     not x_r or x_{r o g}      (g guided, composable with r)
   (Add)-failure at (r1,r2): x_{r1}, x_{r2}, not x_{r1 u r2}
so existence is decided exactly by 2-SAT.  We run it for every sign pattern on n = 3, 4, 5 atoms and
every disjoint pair (r1, r2).  A satisfying assignment is re-checked at model level with rel.props.
Run: python3 -I sat_complete_tp.py > sat_complete_tp.out
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rel import *
sys.setrecursionlimit(100000)


def two_sat(nvars, clauses):
    """clauses: list of (lit, lit), lit = 2*v (true) or 2*v+1 (false).  Returns assignment or None."""
    N = 2 * nvars
    adj = [[] for _ in range(N)]
    for a, b in clauses:
        adj[a ^ 1].append(b)
        adj[b ^ 1].append(a)
    # iterative Tarjan
    index = [0] * N; low = [0] * N; onst = [False] * N; idx = [-1] * N
    comp = [-1] * N; st = []; counter = [0]; ncomp = [0]
    for s in range(N):
        if idx[s] != -1: continue
        work = [(s, 0)]
        while work:
            v, i = work.pop()
            if i == 0:
                idx[v] = low[v] = counter[0]; counter[0] += 1
                st.append(v); onst[v] = True
            recurse = False
            for j in range(i, len(adj[v])):
                w = adj[v][j]
                if idx[w] == -1:
                    work.append((v, j + 1)); work.append((w, 0)); recurse = True; break
                elif onst[w]:
                    low[v] = min(low[v], idx[w])
            if recurse: continue
            if low[v] == idx[v]:
                while True:
                    w = st.pop(); onst[w] = False; comp[w] = ncomp[0]
                    if w == v: break
                ncomp[0] += 1
            if work:
                u = work[-1][0]
                low[u] = min(low[u], low[v])
    assign = []
    for v in range(nvars):
        if comp[2 * v] == comp[2 * v + 1]: return None
        assign.append(comp[2 * v] < comp[2 * v + 1])   # Tarjan numbers SCCs in reverse topological order
    return assign


def run(n, npos):
    pos = (1 << npos) - 1; neg = ((1 << n) - 1) & ~pos
    R = records(n); id_ = {r: i for i, r in enumerate(R)}
    Gs = guided_set(n, pos, neg)
    T = lambda v: 2 * v; F = lambda v: 2 * v + 1
    base = []
    for r in R:
        v = id_[r]
        if r in Gs: base.append((T(v), T(v)))
        elif (r[1], r[0]) in Gs: base.append((F(v), F(v)))
        base.append((T(v), T(id_[(r[1], r[0])])))
        for g in Gs:
            if composable(r, g):
                base.append((F(v), T(id_[compose(r, g)])))
    found = None; tried = 0
    for r1 in R:
        for r2 in R:
            if (r1[0] | r1[1]) & (r2[0] | r2[1]) or r1 >= r2: continue
            u = (r1[0] | r2[0], r1[1] | r2[1])
            tried += 1
            cl = base + [(T(id_[r1]), T(id_[r1])), (T(id_[r2]), T(id_[r2])), (F(id_[u]), F(id_[u]))]
            a = two_sat(len(R), cl)
            if a is not None:
                found = (r1, r2, a); break
        if found: break
    return pos, neg, R, found, tried


if __name__ == '__main__':
  for n in (3, 4, 5):
      for npos in range(0, n + 1):
          pos, neg, R, found, tried = run(n, npos)
          if found is None:
              print(f"n={n} npos={npos}: UNSAT for all {tried} disjoint pairs (complete+TP+strictG => Add here)")
          else:
              r1, r2, a = found
              Acc = {r for r, x in zip(R, a) if x}
              le = matrix_from_records(n, Acc)
              d = props(n, le, pos, neg, ib=(n <= 4))
              print(f"n={n} npos={npos}: SAT  r1={r1} r2={r2}  model-level re-check: {fmt(d, ('refl','strictG','TC','FCC','Add','TP','Tr','complete'))}")
