"""REF65_ad: independent atom check of AD65 Theorem 5.2 (R_lex(N)) and Prop 5.1 (pure guidance).

Random atom systems: 7 atoms with integer payoff vectors in Z^3, one-sided (no atom wrong at every world),
at least one atom right at every world (stands for int R^3_+, contained in every member).
Families N: random sets of models each containing every all-right atom.
Checked exhaustively per system:
  per world: refl, strict (G), (IB) literal, (TC), (FCC), (Add)       [rel.props]
  (b) no member of N has a weak dominator other than itself
  (c) for X not in N: (X dominated by a member) <=> (star)(X); and then strict at every world
  defenders' records rec(N,X) under (star) are accepted at every world (never deleted)
Run: python3 -I rlex_check.py > rlex_check.out
"""
import sys, os, random
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rel import props, fmt

random.seed(65)
def system(n=7):
    while True:
        H = [tuple(random.choice([-3, -2, -1, 1, 2, 3]) for _ in range(3)) for _ in range(n)]
        if any(all(x < 0 for x in h) for h in H): continue
        if not any(all(x > 0 for x in h) for h in H): continue
        return H

def run(H, fam):
    n = len(H); M = 1 << n
    m = [tuple(sum(H[a][i] for a in range(n) if X >> a & 1) for i in range(3)) for X in range(M)]
    pos = [sum(1 << a for a in range(n) if H[a][i] > 0) for i in range(3)]
    neg = [sum(1 << a for a in range(n) if H[a][i] < 0) for i in range(3)]
    def attacks(A, B, Z): return (B & ~Z) == 0 and (A & Z) == 0
    def NA(A, B): return not any(attacks(A, B, Z) for Z in fam)
    def guided(i, A, B): return (A & ~pos[i]) == 0 and (B & ~neg[i]) == 0
    def L(i, X, Y):
        d = [m[X][j] - m[Y][j] for j in range(3)]
        return (d[i], sum(d))
    def acc(i, X, Y):
        A, B = X & ~Y, Y & ~X
        if guided(i, A, B): return True
        l = L(i, X, Y)
        if l > (0, 0): return NA(A, B)
        if l == (0, 0): return NA(A, B) and NA(B, A)
        return False
    le = [np.array([[acc(i, X, Y) for Y in range(M)] for X in range(M)]) for i in range(3)]
    ok = True
    for i in range(3):
        d = props(n, le[i], pos[i], neg[i], ib=False)
        ok &= d['refl'] and d['strictG'] and d['TC'] and d['FCC'] and d['Add']
    WD = le[0] & le[1] & le[2]
    ST = (le[0] & ~le[0].T) | (le[1] & ~le[1].T) | (le[2] & ~le[2].T)
    DOM = WD & ST
    SDOM = (le[0] & ~le[0].T) & (le[1] & ~le[1].T) & (le[2] & ~le[2].T)
    prot = all(not WD[Y, Z] for Z in fam for Y in range(M) if Y != Z)
    fs = set(fam); star_ok = True; strict_ok = True; def_ok = True
    for X in range(M):
        if X in fs: continue
        defs = [Z for Z in fam if all(m[Z][j] >= m[X][j] for j in range(3)) and m[Z] != m[X] and NA(Z & ~X, X & ~Z)]
        dommem = [Z for Z in fam if DOM[Z, X]]
        if bool(defs) != bool(dommem): star_ok = False
        for Z in defs:
            if not WD[Z, X]: def_ok = False
            if not SDOM[Z, X]: strict_ok = False
        for Z in dommem:
            if Z not in defs: star_ok = False
    return ok, prot, star_ok, strict_ok, def_ok

allok = True
for t in range(12):
    H = system()
    n = len(H); M = 1 << n
    core = sum(1 << a for a in range(n) if all(x > 0 for x in H[a]))
    fam = sorted({core} | {X | core for X in random.sample(range(M), random.randint(1, 20))})
    res = run(H, fam)
    print(f"system {t}: |N|={len(fam)}  axioms(refl,strictG,TC,FCC,Add)={res[0]}  protection={res[1]}  "
          f"(star)<=>dominated-by-member={res[2]}  strict-at-every-world={res[3]}  defenders-accepted={res[4]}")
    allok &= all(res)
# pure guidance: protection of every model containing the all-right atoms
H = system(); n = len(H); M = 1 << n
pos = [sum(1 << a for a in range(n) if H[a][i] > 0) for i in range(3)]
neg = [sum(1 << a for a in range(n) if H[a][i] < 0) for i in range(3)]
core = sum(1 << a for a in range(n) if all(x > 0 for x in H[a]))
PG = [np.array([[((X & ~Y) & ~pos[i]) == 0 and ((Y & ~X) & ~neg[i]) == 0 for Y in range(M)] for X in range(M)]) for i in range(3)]
tr = all(props(n, PG[i], pos[i], neg[i], ib=False)['Tr'] for i in range(3))
WD = PG[0] & PG[1] & PG[2]
prot = all(not WD[Y, Z] for Z in range(M) if (Z & core) == core for Y in range(M) if Y != Z)
print(f"pure guidance: transitive={tr}; every model containing the all-right atoms has no weak dominator={prot}")
allok &= tr and prot
print("ALL PASS" if allok else "SOME FAIL")
