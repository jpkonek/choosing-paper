"""REF65_ad: exact CONTINUUM witnesses, found by SAT, for the two non-implications whose AD65 witness is
atom-only (Example G) or missing:
  (G*)  complete + (IB) + (Add) + (TP) + refl + strict (G),  NOT (TC)      [AD65 Ex G, atom-only]
  (K*)  complete + (IB) + (Add) + refl + strict (G),         NOT (TP)      [no witness in AD65]

Space: atomless, partitioned into cells a (right), b (wrong), c (wrong).  A relation is a set S of
label-tuples (L_a, L_b, L_c), L_k a non-empty subset of {P,N,U}: record (A,B) is accepted iff the tuple
of label sets it induces on the cells lies in S.  Such relations satisfy (IB) by construction.
Every continuum model triple induces per cell a non-empty set of point types (x,y,z) in {0,1}^3, and
all such per-cell sets occur; the clauses below range over ALL of them, so constraints are exact.
Verification is done directly (independently of the SAT encoding) by enumerating all per-cell
label quadruples (65 per cell, 65^3 combinations).
Run: python3 -I sat_lattice.py > sat_lattice.out
"""
import itertools
from pysat.solvers import Glucose4

TYPES = list(itertools.product((0, 1), repeat=3))
def lab(u, v): return 'P' if (u, v) == (1, 0) else ('N' if (u, v) == (0, 1) else 'U')
def typesets(exclude=()):
    ts = [t for t in TYPES if t not in exclude]
    return [T for r in range(1, len(ts) + 1) for T in itertools.combinations(ts, r)]
def quad(T):
    return (frozenset(lab(t[0], t[1]) for t in T), frozenset(lab(t[1], t[2]) for t in T),
            frozenset(lab(t[0], t[2]) for t in T), frozenset(lab(t[2], t[0]) for t in T))
LS = [frozenset(s) for r in (1, 2, 3) for s in itertools.combinations('PNU', r)]
cells = [('a', 1), ('b', -1), ('c', -1)]
tuples = list(itertools.product(LS, repeat=3))
vid = {t: i + 1 for i, t in enumerate(tuples)}
def inv(t): return tuple(frozenset({'P': 'N', 'N': 'P', 'U': 'U'}[x] for x in L) for L in t)
def gcell(k, L): return ('N' not in L) if cells[k][1] > 0 else ('P' not in L)
def guided(t): return all(gcell(k, t[k]) for k in range(3))
NULL = tuple(frozenset('U') for _ in range(3))
Q_ALL = sorted(set(quad(T) for T in typesets()), key=str)
Q_ADD = sorted(set(quad(T) for T in typesets(exclude=((0, 1, 0), (1, 0, 1)))), key=str)
P, N, U = frozenset('P'), frozenset('N'), frozenset('U')

def solve(with_TP, units):
    cl = []
    for t in tuples:
        if guided(t):
            cl.append([vid[t]])
            if t != NULL: cl.append([-vid[inv(t)]])
        cl.append([vid[t], vid[inv(t)]])                       # completeness
    for combo in itertools.product(Q_ADD, repeat=3):            # (Add)
        xy, yz, xz = (tuple(c[i] for c in combo) for i in range(3))
        cl.append([-vid[xy], -vid[yz], vid[xz]])
    if with_TP:
        for combo in itertools.product(Q_ALL, repeat=3):        # (TP)
            xy, yz, xz = (tuple(c[i] for c in combo) for i in range(3))
            if guided(yz): cl.append([-vid[xy], vid[xz]])
    cl += [[u] for u in units]
    s = Glucose4(bootstrap_with=cl)
    if not s.solve(): return None
    model = set(x for x in s.get_model() if x > 0)
    return {t for t in tuples if vid[t] in model}

def verify(S):
    acc = lambda t: t in S
    res = {'refl': acc(NULL), 'complete': all(acc(t) or acc(inv(t)) for t in tuples),
           'strictG': all(acc(t) and (t == NULL or not acc(inv(t))) for t in tuples if guided(t))}
    tc = tr = tp = True
    for combo in itertools.product(Q_ALL, repeat=3):
        xy, yz, xz, zx = (tuple(c[i] for c in combo) for i in range(4))
        if acc(xy) and acc(yz):
            if not acc(xz):
                tr = False
                if acc(zx): tc = False
        if acc(xy) and guided(yz) and not acc(xz): tp = False
    add = True
    for combo in itertools.product(Q_ADD, repeat=3):
        xy, yz, xz = (tuple(c[i] for c in combo) for i in range(3))
        if acc(xy) and acc(yz) and not acc(xz): add = False
    res.update(TC=tc, Tr=tr, TP=tp, Add=add)
    return res

# (G*): AD65 Ex G's TC-failure pattern on whole cells: {} <= {a,b} <= {a,c},  {a,c} < {}
S = solve(True, [vid[(N, N, U)], vid[(U, P, N)], vid[(P, U, P)], -vid[(N, U, N)]])
print("(G*) complete+Add+TP, not TC:", "SAT" if S else "UNSAT")
if S:
    r = verify(S); print("   verified:", r)
    ok1 = r['complete'] and r['Add'] and r['TP'] and r['strictG'] and r['refl'] and not r['TC']
else:
    ok1 = False
# (K*): (TP)-failure pattern of Ex B: {a,b,c} <= {}, {} pointwise better than {b}, {a,b,c} not <= {b}
S = solve(False, [vid[(P, P, P)], -vid[(P, U, P)]])
print("(K*) complete+Add, not TP:", "SAT" if S else "UNSAT")
if S:
    r = verify(S); print("   verified:", r)
    ok2 = r['complete'] and r['Add'] and r['strictG'] and r['refl'] and not r['TP']
else:
    ok2 = False
print("BOTH WITNESSES EXIST (continuum, exact)" if ok1 and ok2 else "NOT BOTH")
