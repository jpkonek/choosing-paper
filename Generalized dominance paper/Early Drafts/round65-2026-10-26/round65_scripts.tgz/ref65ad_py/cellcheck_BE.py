"""REF65_ad: exact continuum checks (cell method of cellcheck.py) for Examples B and E.
B: cells a(+), b(-), c(-) partition U;  Acc = G u {(abc,-)}.
E: cells a(+), b(-), c(-) partition U;  Acc = (Add)+(TP) closure of G u {(b,c),(ac,-)}
   = G u F1 u F2,  F1 = {c fully removed, a never removed},  F2 = {a fully added, b never added}
   (description checked against the atom closure at refinement k = 1, 2).
(FCC) for B and E follows from the deletion lemma (all non-null accepted records Brier-strict), by hand.
Run: python3 -I cellcheck_BE.py > cellcheck_BE.out"""
import sys, os, io, contextlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
with contextlib.redirect_stdout(io.StringIO()):
    from cellcheck import Rel, report, only, notin, rec_cells, agree
cells = [('a', 1), ('b', -1), ('c', -1)]
G = {0: notin('N'), 1: notin('P'), 2: notin('P')}
relB = Rel(cells, [G, {0: only('P'), 1: only('P'), 2: only('P')}])
def witB(rel):   # {a,b,c} <= {} , {} pointwise better than {b}, but {a,b,c} not <= {b}
    return (rel.acc(rec_cells(rel, {'a','b','c'}, set())) and not rel.acc(rec_cells(rel, {'a','c'}, set())), "TP failure")
ok = report("Ex B", relB, dict(refl=True, strictG=True, Add=True, TC=True, TP=False), witB)
relE = Rel(cells, [G, {0: notin('N'), 2: only('N')}, {0: only('P'), 1: notin('P')}])
def witE(rel):
    return (rel.acc(rec_cells(rel, {'b'}, {'c'})) and rel.acc(rec_cells(rel, {'a','c'}, set()))
            and not rel.acc(rec_cells(rel, {'a','b'}, set())) and not rel.acc(rec_cells(rel, set(), {'a','b'})),
            "{a,b} <= {a,c} <= {} with {a,b}, {} incomparable")
ok &= report("Ex E (Add+TP closure)", relE, dict(refl=True, strictG=True, Add=True, TC=True, TP=True, Tr=False), witE)
for k in (1, 2):
    a = agree(relE, k, [({'b'}, {'c'}), ({'a', 'c'}, set())], 'addtp'); print(f"E description = atom (Add)+(TP) closure at k={k}: {a}"); ok &= a
print("ALL AS CLAIMED" if ok else "SOME DIFFER")
