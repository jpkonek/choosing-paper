"""REF65_ad: independent exact property checker for single-world relations on finite atom algebras.

Written from the definitions in AD65 §1 / W62 §2, without importing ad65py.
Models are bitmasks over n atoms; every subset of atoms is a model (decomposable domain).
le[X,Y] = True  means  X <=_w Y  (X at least as good as Y).
pos / neg are bitmasks of atoms right / wrong to accept at this world (a partition of the atoms).

(IB) is checked in the literal W62 form, quantifying over every S (union of atoms):
  X\\S = Y\\S, X'\\S = Y'\\S, X cap S = X' cap S, Y cap S = Y' cap S  ==>  (X<=Y iff X'<=Y').
"""
import numpy as np


def guided_matrix(n, pos, neg):
    M = 1 << n
    G = np.zeros((M, M), dtype=bool)
    for X in range(M):
        for Y in range(M):
            P, N = X & ~Y, Y & ~X
            G[X, Y] = (P & ~pos) == 0 and (N & ~neg) == 0
    return G


def bmul(A, B):
    return (A.astype(np.int64) @ B.astype(np.int64)) > 0


def tclose(R):
    T = R.copy()
    for k in range(T.shape[0]):
        T |= T[:, k][:, None] & T[k, :][None, :]
    return T


def ib_literal(n, le):
    full = (1 << n) - 1
    for S in range(full + 1):
        comp = full & ~S
        # subsets of S and of comp
        subsS = []
        s = S
        while True:
            subsS.append(s)
            if s == 0:
                break
            s = (s - 1) & S
        subsC = []
        s = comp
        while True:
            subsC.append(s)
            if s == 0:
                break
            s = (s - 1) & comp
        for a in subsS:
            for b in subsS:
                vals = {bool(le[a | T, b | T]) for T in subsC}
                if len(vals) > 1:
                    return False
    return True


def props(n, le, pos, neg, ib=True):
    M = 1 << n
    le = np.asarray(le, dtype=bool)
    G = guided_matrix(n, pos, neg)
    lt = le & ~le.T
    out = {}
    out['refl'] = bool(le.diagonal().all())
    out['weakG'] = bool((~G | le).all())
    offdiag = ~np.eye(M, dtype=bool)
    out['strictG'] = bool((~(G & offdiag) | lt).all())
    out['IB'] = ib_literal(n, le) if ib else None
    L2 = bmul(le, le)                      # exists B: A<=B<=C
    out['TC'] = not bool((L2 & lt.T).any())
    out['Tr'] = not bool((L2 & ~le).any())
    out['TP'] = not bool((bmul(le, G) & ~le).any())
    out['FCC'] = not bool((tclose(le) & lt.T).any())
    out['complete'] = bool((le | le.T).all())
    # (Add): X<=Y<=Z with (X^Y)&(Y^Z)=0 ==> X<=Z
    add = True
    for X in range(M):
        for Y in range(M):
            if not le[X, Y]:
                continue
            free = (M - 1) & ~(X ^ Y)
            D = free
            while True:
                Z = Y ^ D
                if le[Y, Z] and not le[X, Z]:
                    add = False
                    break
                if D == 0:
                    break
                D = (D - 1) & free
            if not add:
                break
        if not add:
            break
    out['Add'] = add
    return out


KEYS = ('refl', 'strictG', 'IB', 'TC', 'FCC', 'Add', 'TP', 'Tr', 'complete')


def fmt(d, keys=KEYS):
    return '  '.join(f"{k}={'Y' if d[k] else 'n'}" for k in keys)


# ---------------- record calculus (independent implementation) ----------------
def records(n):
    """all pairs (P,N) of disjoint atom sets"""
    full = (1 << n) - 1
    out = []
    P = full
    while True:
        rest = full & ~P
        N = rest
        while True:
            out.append((P, N))
            if N == 0:
                break
            N = (N - 1) & rest
        if P == 0:
            break
        P = (P - 1) & full
    return out


def guided_set(n, pos, neg):
    return {(P, N) for (P, N) in records(n) if (P & ~pos) == 0 and (N & ~neg) == 0}


def compose(r, s):
    (P1, N1), (P2, N2) = r, s
    assert (P1 & P2) == 0 and (N1 & N2) == 0
    return ((P1 & ~N2) | (P2 & ~N1), (N1 & ~P2) | (N2 & ~P1))


def composable(r, s):
    return (r[0] & s[0]) == 0 and (r[1] & s[1]) == 0


def close_add(S, n):
    """least superset of S closed under disjoint union"""
    S = set(S)
    frontier = list(S)
    while frontier:
        new = []
        for r in frontier:
            sr = r[0] | r[1]
            for s in list(S):
                if sr & (s[0] | s[1]):
                    continue
                u = (r[0] | s[0], r[1] | s[1])
                if u not in S:
                    S.add(u)
                    new.append(u)
        frontier = new
    return S


def close_tp(S, Gset):
    S = set(S)
    frontier = list(S)
    while frontier:
        new = []
        for r in frontier:
            for g in Gset:
                if composable(r, g):
                    c = compose(r, g)
                    if c not in S:
                        S.add(c)
                        new.append(c)
        frontier = new
    return S


def close_add_tp(S, Gset, n):
    S = set(S) | set(Gset)
    while True:
        S2 = close_tp(close_add(S, n), Gset)
        if S2 == S:
            return S
        S = S2


def matrix_from_records(n, Acc):
    M = 1 << n
    le = np.zeros((M, M), dtype=bool)
    for X in range(M):
        for Y in range(M):
            le[X, Y] = (X & ~Y, Y & ~X) in Acc
    return le
