"""REF65_ad: EXACT continuum verification of the purely combinatorial Examples C, D, D' (no Brier values).

Setting.  U is partitioned into finitely many non-null cells, each inside pos_w or neg_w.  Models are
arbitrary measurable subsets (atomless measure), so a record may cut cells.

Key observation.  For each of these relations, whether a record (A,B) is accepted depends only on, for
each cell k, the set L_k of labels occurring a.e. in k, where a point gets label P (in A), N (in B) or
U (untouched).  For a model triple (X,Y,Z), each point has a type t = (x,y,z) in {0,1}^3; in each cell
the set of types occurring with positive measure is an arbitrary NON-EMPTY subset T_k of the 8 types
(atomlessness: any finite pattern can be realised, and every realised triple gives such a pattern).
The label sets of rec(X,Y), rec(Y,Z), rec(X,Z), rec(Z,X) in cell k are functions of T_k.
So a property quantified over all model triples holds iff it holds over all tuples (T_k)_k.
This is an exhaustive check of the continuum statement, not a sampled or atom-only check.

Relations are given as a union of 'cell-product' disjuncts: each disjunct assigns to every cell a set of
allowed label-sets.  The checks avoid enumerating 255^cells tuples by the following exact reduction:
for each choice of disjuncts witnessing the premises, enumerate per cell the achievable label data, record
which disjuncts the conclusion's label set violates, and ask whether some per-cell choice violates all.

Run: python3 -I cellcheck.py > cellcheck.out
"""
import itertools

TYPES = list(itertools.product((0, 1), repeat=3))
def lab(u, v):
    return 'P' if (u, v) == (1, 0) else ('N' if (u, v) == (0, 1) else 'U')
ALL_LABELSETS = [frozenset(s) for r in (1, 2, 3) for s in itertools.combinations('PNU', r)]

def typesets(exclude=()):
    ts = [t for t in TYPES if t not in exclude]
    out = []
    for r in range(1, len(ts) + 1):
        for T in itertools.combinations(ts, r):
            out.append(T)
    return out

def labels(T):
    """label sets of rec(X,Y), rec(Y,Z), rec(X,Z), rec(Z,X) from a cell type-set"""
    xy = frozenset(lab(t[0], t[1]) for t in T)
    yz = frozenset(lab(t[1], t[2]) for t in T)
    xz = frozenset(lab(t[0], t[2]) for t in T)
    zx = frozenset(lab(t[2], t[0]) for t in T)
    yx = frozenset(lab(t[1], t[0]) for t in T)
    return xy, yz, xz, zx, yx

class Rel:
    def __init__(self, cells, disjuncts):
        """cells: list of (name, sign); disjuncts: list of dicts cell_index -> predicate on label set
        (missing cell = any label set allowed)."""
        self.cells = cells; self.D = disjuncts
    def cell_ok(self, d, k, L):
        f = self.D[d].get(k)
        return True if f is None else f(L)
    def acc(self, Ls):
        return any(all(self.cell_ok(d, k, Ls[k]) for k in range(len(self.cells))) for d in range(len(self.D)))
    def guided_cell(self, k, L):
        s = self.cells[k][1]
        return ('N' not in L) if s > 0 else ('P' not in L)
    def guided(self, Ls):
        return all(self.guided_cell(k, Ls[k]) for k in range(len(self.cells)))

def exists_violation(rel, prem, concl_idx, exclude=(), extra_prem=None):
    """Is there a cell-type tuple such that premises hold and the conclusion fails?
    prem: list of label indices (0=xy,1=yz,2=xz,3=zx,4=yx) that must be ACCEPTED (via some disjunct each);
    extra_prem: list of label indices that must be GUIDED;  concl_idx: label index that must be REFUSED."""
    nc = len(rel.cells); nd = len(rel.D)
    per_cell_data = [labels(T) for T in typesets(exclude)]
    for choice in itertools.product(range(nd), repeat=len(prem)):
        # per cell: set of achievable violation vectors of the conclusion
        cellvecs = []
        feasible = True
        for k in range(nc):
            vecs = set()
            for Ls in per_cell_data:
                if not all(rel.cell_ok(choice[p], k, Ls[idx]) for p, idx in enumerate(prem)): continue
                if extra_prem and not all(rel.guided_cell(k, Ls[idx]) for idx in extra_prem): continue
                L = Ls[concl_idx]
                vecs.add(tuple(not rel.cell_ok(d, k, L) for d in range(nd)))
            if not vecs: feasible = False; break
            cellvecs.append(vecs)
        if not feasible: continue
        for combo in itertools.product(*cellvecs):
            if all(any(v[d] for v in combo) for d in range(nd)):
                return True, choice
    return False, None

def strict_G(rel):
    """every non-null guided record accepted and its inverse refused (pairs: label sets per cell)."""
    nc = len(rel.cells)
    for Ls in itertools.product(ALL_LABELSETS, repeat=nc):
        if all(L == frozenset('U') for L in Ls): continue
        if rel.guided(Ls):
            inv = tuple(frozenset({'P': 'N', 'N': 'P', 'U': 'U'}[x] for x in L) for L in Ls)
            if not rel.acc(Ls) or rel.acc(inv): return False
    return True

def report(name, rel, claims, witness=None):
    res = {}
    res['refl'] = rel.acc(tuple(frozenset('U') for _ in rel.cells))
    res['strictG'] = strict_G(rel)
    v, _ = exists_violation(rel, [0, 1, 3], 2); res['TC'] = not v              # X<=Y<=Z, Z<=X  => X<=Z
    v, _ = exists_violation(rel, [0, 1], 2); res['Tr'] = not v
    v, _ = exists_violation(rel, [0, 1], 2, exclude=((0, 1, 0), (1, 0, 1))); res['Add'] = not v
    v, _ = exists_violation(rel, [0], 2, extra_prem=[1]); res['TP'] = not v     # Y=x<=X=y, rec(y,z) guided => x<=z
    print(f"{name}: " + '  '.join(f"{k}={'Y' if res[k] else 'n'}" for k in res))
    ok = all(res[k] == v for k, v in claims.items())
    if witness:
        w = witness(rel); print("   FCC/TC-failure witness on whole cells:", w); ok = ok and w[0]
    print("   ->", "AS CLAIMED (continuum, exact)" if ok else "DIFFERS")
    return ok

ALL = True
P_, N_, U_ = frozenset('P'), frozenset('N'), frozenset('U')
def only(x): return lambda L: L == frozenset(x)
def notin(x): return lambda L: x not in L
def rec_cells(rel, A, B):
    nm = [c[0] for c in rel.cells]
    return tuple(P_ if x in A else (N_ if x in B else U_) for x in nm)

# ---------------- Example C: (Add)+(TP) closure of G u {(b,c),(c,ab)}; cells a(+), b(-), c(-) ----------
cellsC = [('a', 1), ('b', -1), ('c', -1)]
G_C = {0: notin('N'), 1: notin('P'), 2: notin('P')}
F1_C = {0: notin('N'), 2: only('N')}          # closure of (b,c): c fully removed, a never removed
F2_C = {1: only('N')}                         # closure of (c,ab): b fully removed
relC = Rel(cellsC, [G_C, F1_C, F2_C])
def witC(rel):
    # {b} <= {c} <= {a,b} and {a,b} < {b}
    r1 = rec_cells(rel, {'b'}, {'c'}); r2 = rec_cells(rel, {'c'}, {'a', 'b'})
    s = rec_cells(rel, {'a'}, set()); s_inv = rec_cells(rel, set(), {'a'})
    return (rel.acc(r1) and rel.acc(r2) and rel.acc(s) and not rel.acc(s_inv), "{b}<={c}<={a,b}, {a,b}<{b}")
ALL &= report("Ex C", relC, dict(refl=True, strictG=True, Add=True, TP=True, TC=False, Tr=False), witC)

# ---------------- Example D: G u {(abc,-), (b,ac)}; cells a(+), b(-), c(-) partition U --------------------
G_D = G_C
S1_D = {0: only('P'), 1: only('P'), 2: only('P')}
S2_D = {0: only('N'), 1: only('P'), 2: only('N')}
relD = Rel(cellsC, [G_D, S1_D, S2_D])
def witD(rel):
    ch = [rec_cells(rel, set(), {'b'}), rec_cells(rel, {'b'}, {'a', 'c'}), rec_cells(rel, set(), {'b'}),
          rec_cells(rel, {'a', 'b', 'c'}, set())]
    back = rec_cells(rel, set(), {'a', 'b', 'c'})
    return (all(rel.acc(r) for r in ch) and not rel.acc(back),
            "{} <= {b} <= {a,c} <= {a,b,c} and {a,b,c} < {}")
ALL &= report("Ex D", relD, dict(refl=True, strictG=True, Add=True, TC=True, TP=False), witD)

# ---------------- Example D': (Add)+(TP) closure of G u {(ac,bd),(ad,bc),(b,a)}; a,b(+) c,d(-) -----------
cellsDp = [('a', 1), ('b', 1), ('c', -1), ('d', -1)]
G_Dp = {0: notin('N'), 1: notin('N'), 2: notin('P'), 3: notin('P')}
F1 = {0: only('P'), 3: only('N')}
F2 = {0: only('P'), 2: only('N')}
F3 = {1: only('P'), 2: notin('P'), 3: notin('P')}
relDp = Rel(cellsDp, [G_Dp, F1, F2, F3])
def witDp(rel):
    ch = [rec_cells(rel, {'a', 'c'}, {'b', 'd'}), rec_cells(rel, {'b'}, {'a'}), rec_cells(rel, {'a', 'd'}, {'b', 'c'}),
          rec_cells(rel, {'b'}, {'a'})]
    back = rec_cells(rel, {'a'}, {'b'})
    return (all(rel.acc(r) for r in ch) and not rel.acc(back),
            "{a,c} <= {b,d} <= {a,d} <= {b,c} and {b,c} < {a,c}")
ALL &= report("Ex D'", relDp, dict(refl=True, strictG=True, Add=True, TP=True, TC=True, Tr=False), witDp)

# ---------------- consistency of the cell descriptions with the atom closures (k = 1, 2) -----------------
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rel import records, guided_set, close_add, close_add_tp
def cell_labels_of(rec, cellmasks):
    P, N = rec
    out = []
    for m in cellmasks:
        L = set()
        for a in range(32):
            if m >> a & 1:
                L.add('P' if P >> a & 1 else ('N' if N >> a & 1 else 'U'))
        out.append(frozenset(L))
    return tuple(out)
def agree(rel, k, gens_by_name, mode):
    cells = rel.cells; nc = len(cells); n = nc * k
    masks = [((1 << k) - 1) << (k * i) for i in range(nc)]
    pos = sum(masks[i] for i in range(nc) if cells[i][1] > 0); neg = ((1 << n) - 1) & ~pos
    nm = {cells[i][0]: masks[i] for i in range(nc)}
    gens = [(sum(nm[x] for x in A), sum(nm[x] for x in B)) for A, B in gens_by_name]
    Gs = guided_set(n, pos, neg)
    Acc = close_add_tp(gens, Gs, n) if mode == 'addtp' else close_add(Gs | set(gens), n)
    return all((r in Acc) == rel.acc(cell_labels_of(r, masks)) for r in records(n))
for name, rel, gens, mode in [("C", relC, [({'b'}, {'c'}), ({'c'}, {'a', 'b'})], 'addtp'),
                              ("D", relD, [({'a', 'b', 'c'}, set()), ({'b'}, {'a', 'c'})], 'add'),
                              ("D'", relDp, [({'a', 'c'}, {'b', 'd'}), ({'a', 'd'}, {'b', 'c'}), ({'b'}, {'a'})], 'addtp')]:
    for k in (1, 2):
        a = agree(rel, k, gens, mode)
        print(f"cell description of Ex {name} = atom closure at refinement k={k}: {a}")
        ALL &= a
print("ALL AS CLAIMED" if ALL else "SOME DIFFER")

# ---------------- negative controls (the checker must detect failures) ----------------
print("\nnegative controls:")
ctl = Rel([('a', 1), ('b', -1)], [{0: notin('N'), 1: notin('P')}, {0: only('U'), 1: only('P')}])
r = report("control: G u {(b,-) alone}", ctl, dict(Add=False))
ALL &= r

# ---------------- OR64 diagnostics, per world, on OR64's cell systems (exact continuum, cells fixed) -------
# M1+ at worlds i, j:  Acc = G u { r0 u g : g guided, disjoint from r0 },  r0 = (E u A, B)
M1cells = [('E', (+1, -1, +1)), ('A', (-1, +1, +1)), ('B', (+1, +1, -1)), ('R2', (-1, -1, +1)),
           ('P', (+1, +1, +1)), ('D', (+1, -1, -1)), ('E2', (+1, -1, +1)), ('F', (-1, +1, -1))]
for w in (0, 1, 2):
    cells = [(nm, s[w]) for nm, s in M1cells]
    Gd = {k: (notin('N') if cells[k][1] > 0 else notin('P')) for k in range(len(cells))}
    if w == 2:
        rel = Rel(cells, [Gd])
    else:
        R0 = dict(Gd); R0[0] = only('P'); R0[1] = only('P'); R0[2] = only('N')
        rel = Rel(cells, [Gd, R0])
    ALL &= report(f"M1+ world {w+1}", rel, dict(refl=True, strictG=True, TC=True, Add=True))

# T+ at each world: (i) A n OUT in pos_w, B n IN in neg_w; (ii) toward part null or has a right move
Tcells = [('I0', (+1, +1, +1), 'IN'), ('I1', (-1, +1, +1), 'IN'), ('I2', (+1, -1, +1), 'IN'), ('I3', (+1, +1, -1), 'IN'),
          ('O1', (+1, -1, -1), 'OUT'), ('O2', (-1, +1, -1), 'OUT'), ('O3', (-1, -1, +1), 'OUT'),
          ('O4', (+1, +1, -1), 'OUT'), ('O5', (-1, +1, +1), 'OUT')]
for w in (0, 1, 2):
    cells = [(nm, s[w]) for nm, s, _ in Tcells]
    side = [t for _, _, t in Tcells]
    def cond_i(k):
        # away moves must be right at w: OUT cells: P only if pos; IN cells: N only if neg
        if side[k] == 'OUT':
            return (lambda L: True) if cells[k][1] > 0 else notin('P')
        return (lambda L: True) if cells[k][1] < 0 else notin('N')
    def toward_null(k):
        return notin('P') if side[k] == 'IN' else notin('N')
    def both(f, g): return lambda L: f(L) and g(L)
    D0 = {k: both(cond_i(k), toward_null(k)) for k in range(len(cells))}
    disj = [D0]
    for k in range(len(cells)):
        right = ('P' if cells[k][1] > 0 else None) if side[k] == 'IN' else ('N' if cells[k][1] < 0 else None)
        if right is None: continue
        Dk = {j: cond_i(j) for j in range(len(cells))}
        Dk[k] = both(cond_i(k), (lambda r: (lambda L: r in L))(right))
        disj.append(Dk)
    rel = Rel(cells, disj)
    ALL &= report(f"T+ world {w+1}", rel, dict(refl=True, strictG=True, TC=True, Tr=True, Add=True, TP=True))
print("ALL AS CLAIMED (incl. controls and OR64 diagnostics)" if ALL else "SOME DIFFER")
