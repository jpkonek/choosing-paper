"""REF65_ad: independent re-verification of AD65 Examples A-H, plus a REFINEMENT test.

Refinement test.  The intended framework has an atomless measure: a record may cut any cell.  An atom
example is a relation on a finite algebra only.  To probe whether each example's property vector
survives when cells can be cut, every atom is split into k sub-atoms of the same sign (values split),
and the SAME definition (Brier-minus-R, closure of the same generators, ...) is applied on the finer
algebra.  If a property flips under refinement, the atom example does not lift by its stated
definition.  (A refinement that preserves everything is evidence, not proof, of a continuum lift.)

Run: python3 -I examples_ref.py > examples_ref.out
"""
import sys, os, itertools
from fractions import Fraction as Fr
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rel import *

ALLOK = True
def expect(label, d, exp):
    global ALLOK
    bad = {k: d[k] for k, v in exp.items() if d[k] != v}
    status = 'AS CLAIMED' if not bad else f'DIFFERS {bad}'
    print(f"  {label}: {fmt(d)}   -> {status}")
    return not bad

def refine(atoms, k, splitvals=None):
    """atoms: list of (name, sign, value).  Returns refined atom list and map name->mask."""
    out = []; mp = {}
    for (nm, s, v) in atoms:
        mask = 0
        parts = splitvals[nm] if splitvals and nm in splitvals else ([Fr(v, k)] * k if v is not None else [None] * k)
        for t in range(k):
            mask |= 1 << len(out)
            out.append((f"{nm}{t}", s, parts[t]))
        mp[nm] = mask
    return out, mp

def setup(atoms):
    n = len(atoms)
    pos = sum(1 << a for a, (_, s, _) in enumerate(atoms) if s > 0)
    neg = sum(1 << a for a, (_, s, _) in enumerate(atoms) if s < 0)
    val = [v for (_, _, v) in atoms]
    def m(S): return sum(val[a] for a in range(n) if S >> a & 1)
    return n, pos, neg, m

def rec_of(mp, P, N):
    return (sum(mp[x] for x in P), sum(mp[x] for x in N))

results = {}

# ---------------- Example A: Brier minus one strict record R ----------------
print("Example A  (atoms x1(+3) y1(-2) x2(+4) y2(-3); Acc = Br minus R=(x1y1x2y2, -))")
A_atoms = [('x1', 1, 3), ('y1', -1, -2), ('x2', 1, 4), ('y2', -1, -3)]
for k in (1, 2):
    atoms, mp = refine(A_atoms, k, splitvals=None if k == 1 else
                       {'x1': [1, 2], 'y1': [-1, -1], 'x2': [2, 2], 'y2': [-1, -2]})
    n, pos, neg, m = setup(atoms)
    R = rec_of(mp, ['x1', 'y1', 'x2', 'y2'], [])
    Br = {r for r in records(n) if m(r[0]) - m(r[1]) >= 0}
    Acc = Br - {R}
    d = props(n, matrix_from_records(n, Acc), pos, neg)
    exp = dict(refl=True, strictG=True, IB=True, TC=True, FCC=True, TP=True, Add=False, Tr=False, complete=False)
    ok = expect(f"naive  k={k}", d, exp)
    results[f'A naive k={k}'] = ok
    # repaired: delete the (TP)-preimage closure D of R, plus tie-inverses of D
    Gs = guided_set(n, pos, neg)
    D = {R}
    changed = True
    while changed:
        changed = False
        for r in records(n):
            if r in D: continue
            for g in Gs:
                if composable(r, g) and compose(r, g) in D:
                    D.add(r); changed = True; break
    D2 = {(r[1], r[0]) for r in D if m(r[0]) - m(r[1]) == 0}
    Acc2 = Br - D - D2
    # invariant used in the hand proof: every member of D adds all of y1 u y2
    yy = mp['y1'] | mp['y2']
    inv = all((r[0] & yy) == yy for r in D)
    d2 = props(n, matrix_from_records(n, Acc2), pos, neg)
    ok2 = expect(f"repair k={k}", d2, exp)
    print(f"     repair: |D|={len(D)}, every r in D adds all of y1,y2: {inv}; |tie-inverses|={len(D2)}")
    results[f'A repaired k={k}'] = ok2 and inv

# ---------------- Example B ----------------
print("\nExample B  (a(+3) b(-1) c(-1); Acc = G u {(abc,-)})")
B_atoms = [('a', 1, 3), ('b', -1, -1), ('c', -1, -1)]
for k in (1, 2):
    atoms, mp = refine(B_atoms, k)
    n, pos, neg, m = setup(atoms)
    Gs = guided_set(n, pos, neg)
    Acc = close_add(Gs | {rec_of(mp, ['a', 'b', 'c'], [])}, n)
    d = props(n, matrix_from_records(n, Acc), pos, neg)
    results[f'B k={k}'] = expect(f"k={k}", d, dict(refl=True, strictG=True, IB=True, TC=True, FCC=True, Add=True, TP=False, Tr=False, complete=False))

# ---------------- Example C ----------------
print("\nExample C  (a(+) b(-) c(-); (Add)+(TP) closure of G u {(b,c),(c,ab)})")
C_atoms = [('a', 1, None), ('b', -1, None), ('c', -1, None)]
for k in (1, 2):
    atoms, mp = refine(C_atoms, k)
    n, pos, neg, _ = setup([(x, s, 0) for (x, s, _) in atoms])
    Gs = guided_set(n, pos, neg)
    Acc = close_add_tp([rec_of(mp, ['b'], ['c']), rec_of(mp, ['c'], ['a', 'b'])], Gs, n)
    d = props(n, matrix_from_records(n, Acc), pos, neg)
    results[f'C k={k}'] = expect(f"k={k}", d, dict(refl=True, strictG=True, IB=True, Add=True, TP=True, TC=False, FCC=False, Tr=False))

# ---------------- Example D ----------------
print("\nExample D  (a(+) b(-) c(-); (Add) closure of G u {(abc,-),(b,ac)})")
for k in (1, 2):
    atoms, mp = refine(C_atoms, k)
    n, pos, neg, _ = setup([(x, s, 0) for (x, s, _) in atoms])
    Gs = guided_set(n, pos, neg)
    Acc = close_add(Gs | {rec_of(mp, ['a', 'b', 'c'], []), rec_of(mp, ['b'], ['a', 'c'])}, n)
    d = props(n, matrix_from_records(n, Acc), pos, neg)
    results[f'D k={k}'] = expect(f"k={k}", d, dict(refl=True, strictG=True, IB=True, Add=True, TC=True, FCC=False, TP=False))

# ---------------- Example D' ----------------
print("\nExample D'  (a(+) b(+) c(-) d(-); (Add)+(TP) closure of G u {(ac,bd),(ad,bc),(b,a)})")
Dp_atoms = [('a', 1, None), ('b', 1, None), ('c', -1, None), ('d', -1, None)]
for k in (1, 2):
    atoms, mp = refine(Dp_atoms, k)
    n, pos, neg, _ = setup([(x, s, 0) for (x, s, _) in atoms])
    Gs = guided_set(n, pos, neg)
    gens = [rec_of(mp, ['a', 'c'], ['b', 'd']), rec_of(mp, ['a', 'd'], ['b', 'c']), rec_of(mp, ['b'], ['a'])]
    Acc = close_add_tp(gens, Gs, n)
    d = props(n, matrix_from_records(n, Acc), pos, neg, ib=(k == 1))
    if k > 1: d['IB'] = True   # record-defined: (IB) holds by construction (literal check skipped for size)
    results[f"D' k={k}"] = expect(f"k={k}", d, dict(refl=True, strictG=True, IB=True, Add=True, TP=True, TC=True, FCC=False, Tr=False))

# ---------------- Example E ----------------
print("\nExample E  (a(+3) b(-1) c(-2); closure of G u {(b,c),(ac,-)})")
E_atoms = [('a', 1, 3), ('b', -1, -1), ('c', -1, -2)]
for k in (1, 2):
    atoms, mp = refine(E_atoms, k)
    n, pos, neg, m = setup(atoms)
    Gs = guided_set(n, pos, neg)
    gens = [rec_of(mp, ['b'], ['c']), rec_of(mp, ['a', 'c'], [])]
    exp = dict(refl=True, strictG=True, IB=True, Add=True, TP=True, TC=True, FCC=True, Tr=False, complete=False)
    Acc = close_add(Gs | set(gens), n)
    d = props(n, matrix_from_records(n, Acc), pos, neg)
    results[f'E add-closure k={k}'] = expect(f"(Add) closure      k={k}", d, exp)
    Acc = close_add_tp(gens, Gs, n)
    d = props(n, matrix_from_records(n, Acc), pos, neg)
    sub = all(m(r[0]) - m(r[1]) > 0 or r == (0, 0) for r in Acc)
    results[f'E add+tp-closure k={k}'] = expect(f"(Add)+(TP) closure k={k}", d, exp) and sub
    print(f"     (Add)+(TP) closure is Brier-strict on every non-null record: {sub}")

# ---------------- Example F ----------------
print("\nExample F  (a(+1) b(+1) c(-1); Phi = m + eps*interaction(a,c); model level)")
for k in (1, 2):
    atoms, mp = refine([('a', 1, 1), ('b', 1, 1), ('c', -1, -1)], k)
    n, pos, neg, m = setup(atoms)
    def phi(X):
        na = bin(X & mp['a']).count('1'); nc = bin(X & mp['c']).count('1')
        return m(X) + Fr(1, 2) * Fr(na * nc, k * k)
    M = 1 << n
    le = np.array([[phi(X) >= phi(Y) for Y in range(M)] for X in range(M)])
    d = props(n, le, pos, neg)
    results[f'F k={k}'] = expect(f"k={k}", d, dict(refl=True, strictG=True, Tr=True, complete=True, Add=True, TC=True, FCC=True, TP=True, IB=False))

# ---------------- Example G (atoms only: a complete orientation has no canonical refinement) --------------
print("\nExample G  (a(+) b(-) c(-); the complete record relation printed in ad65py/examples.out)")
n = 3; pos = 0b001; neg = 0b110
a_, b_, c_ = 1, 2, 4
Gs = guided_set(n, pos, neg)
extra = {(a_ | b_, c_), (a_ | c_, b_), (a_ | c_, 0), (b_, c_), (0, a_ | b_ | c_), (0, a_ | b_)}
Acc = Gs | extra
d = props(n, matrix_from_records(n, Acc), pos, neg)
results['G atoms'] = expect("k=1", d, dict(refl=True, strictG=True, IB=True, complete=True, Add=True, TP=True, TC=False, FCC=False, Tr=False))

# ---------------- Example H (atoms; continuum version proved by hand in REF65_ad §3) ----------------
print("\nExample H  (atoms as A; Acc = G u {Brier-acceptable records touching <= 2 atoms})")
atoms, mp = refine(A_atoms, 1)
n, pos, neg, m = setup(atoms)
Gs = guided_set(n, pos, neg)
Acc = Gs | {r for r in records(n) if m(r[0]) - m(r[1]) >= 0 and bin(r[0] | r[1]).count('1') <= 2}
d = props(n, matrix_from_records(n, Acc), pos, neg)
results['H atoms'] = expect("k=1", d, dict(refl=True, strictG=True, IB=True, TC=True, FCC=True, Add=False, TP=False, Tr=False, complete=False))

print("\nSUMMARY")
for k, v in results.items():
    print(f"  {k:28s} {'as claimed' if v else 'DIFFERS FROM CLAIM'}")
