"""REF65_ad: exhaustive census of ALL single-world record relations on 3 atoms that satisfy
reflexivity and strict (G) (hence (IB) by construction), for every sign pattern.

For 3 atoms there are 27 records: 8 guided (always accepted), 7 non-null anti-guided (never accepted
under strict (G)), and 12 free records, so 2^12 = 4096 relations per sign pattern.

Output: the set of realised property vectors over (TC, FCC, Add, TP, Tr, complete), and, for every
conjunction S of properties and every property p, whether S => p holds throughout the census.
We then compare with AD65 §3 ("the only implications are (Tr) => all, (FCC) => (TC),
complete + (TC) => (Tr)").  A census on 3 atoms can only REFUTE an implication; implications that
survive it are checked against the 4-atom examples of AD65 (A, D') and against hand proofs.

Also searches for:  complete + (IB) + (TP) + strict (G)  without (Add)   (needed for AD65 §0.2's claim
'apart from (Tr) and completeness + (TC), nothing in the list implies (Add)').
Run: python3 -I lattice.py > lattice.out
"""
import sys, os, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rel import *

KEYS6 = ('TC', 'FCC', 'Add', 'TP', 'Tr', 'complete')
n = 3
vectors = {}
witness = {}
for npos in range(0, 4):
    pos = (1 << npos) - 1; neg = 7 & ~pos
    Gs = guided_set(n, pos, neg)
    anti = {(r[1], r[0]) for r in Gs if r != (0, 0)}
    free = [r for r in records(n) if r not in Gs and r not in anti]
    assert len(free) == 12
    for bits in range(1 << 12):
        Acc = set(Gs) | {free[t] for t in range(12) if bits >> t & 1}
        le = matrix_from_records(n, Acc)
        d = props(n, le, pos, neg, ib=False)
        assert d['refl'] and d['strictG']
        v = tuple(d[k] for k in KEYS6)
        vectors[v] = vectors.get(v, 0) + 1
        witness.setdefault(v, (npos, sorted(r for r in Acc if r not in Gs)))

print("realised property vectors (TC, FCC, Add, TP, Tr, complete) : count")
for v, c in sorted(vectors.items(), reverse=True):
    print("  ", ''.join('Y' if x else 'n' for x in v), c)

# implications S => p holding on the whole census, with S minimal
print("\nimplications S => p valid on the 3-atom census (S minimal, p not in S):")
idx = {k: i for i, k in enumerate(KEYS6)}
valid = []
for r in range(0, len(KEYS6)):
    for S in itertools.combinations(KEYS6, r):
        for p in KEYS6:
            if p in S: continue
            if all(v[idx[p]] for v in vectors if all(v[idx[s]] for s in S)):
                if not any(set(T) <= set(S) and q == p for (T, q) in valid):
                    valid.append((S, p))
for S, p in valid:
    print("   ", ' + '.join(S) if S else '(nothing)', '=>', p)

# the specific search
target = [v for v in vectors if v[idx['complete']] and v[idx['TP']] and not v[idx['Add']]]
print("\ncomplete + (TP) + strict (G) + (IB) without (Add) on 3 atoms:", "FOUND" if target else "NONE")
for v in target:
    print("   vector", v, "witness (npos, accepted non-guided records):", witness[v])
