"""REF65_ad: print a minimal-ish witness for complete + (TP) + strict (G) + (IB) without (Add) on 4 atoms
(a,b right; c,d wrong), minimising the number of accepted non-guided records via repeated 2-SAT with
extra unit clauses (greedy).  Run: python3 -I sat_witness.py > sat_witness.out"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rel import *
from sat_complete_tp import two_sat
n = 4; pos = 0b0011; neg = 0b1100
nm = 'abcd'
def S(mask): return '{' + ''.join(nm[a] for a in range(n) if mask >> a & 1) + '}'
R = records(n); id_ = {r: i for i, r in enumerate(R)}
Gs = guided_set(n, pos, neg)
T = lambda v: 2 * v; F = lambda v: 2 * v + 1
base = []
for r in R:
    v = id_[r]
    if r in Gs: base.append((T(v), T(v)))
    elif (r[1], r[0]) in Gs: base.append((F(v), F(v)))
    base.append((T(v), T(id_[(r[1], r[0])])))
    for g in Gs:
        if composable(r, g): base.append((F(v), T(id_[compose(r, g)])))
r1 = (0b0101, 0); r2 = (0b1010, 0)          # (a c, -) and (b d, -)
u = (r1[0] | r2[0], r1[1] | r2[1])
cl = base + [(T(id_[r1]),) * 2, (T(id_[r2]),) * 2, (F(id_[u]),) * 2]
a = two_sat(len(R), cl)
print("pair r1=(ac,-), r2=(bd,-):", "SAT" if a else "UNSAT")
if a:
    Acc = {r for r, x in zip(R, a) if x}
    d = props(n, matrix_from_records(n, Acc), pos, neg)
    print(fmt(d))
    # witness of Add failure in model form
    print("models: {a,b,c,d} <=", S(0b1010), "<= {} ?  ", "(ac u bd refused; parts accepted)")
    nong = sorted((S(r[0]) + ' for ' + S(r[1])) for r in Acc if r not in Gs)
    print("accepted non-guided records (%d):" % len(nong)); print('  ', nong)
