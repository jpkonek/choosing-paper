"""REF65_ad: two referee examples (hand proofs in REF65_ad_notes.md; this is an exact atom/refinement check).

(T) Threshold ("materiality") relation at one world:  Acc = G u { r : m(r) >= c },  c > 0.
    Claim: reflexive, strict (G), (IB), TRANSITIVE (hence (TC), (FCC), (Add), (TP)), incomplete; it
    leaves every non-guided record with 0 < m(r) < c unranked.  Magnitude-based incomparability that
    (Add) permits -- refuting AD65 §0.4 / §2.1(4) "incomparability under (Add) must be scale-free".

(V) Majority of three truth-directed additive scores:  Acc = { r : #{k : s_k(r) >= 0} >= 2 },
    s_k(r) = sum_{A} w_k |h| sign - ...  (weights w_k > 0 on every atom).
    Claim: complete, reflexive, strict (G), (IB), (TP); NOT (Add), NOT (TC).  Supplies the missing
    witness for 'complete + (IB) + (TP) does not imply (Add)' with a continuum definition.

Run: python3 -I extra_examples.py > extra_examples.out
"""
import sys, os
from fractions import Fraction as Fr
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rel import *

ALL = True
def show(lbl, d, exp):
    global ALL
    bad = {k: d[k] for k, v in exp.items() if d[k] != v}
    print(f"  {lbl}: {fmt(d)}  -> {'AS CLAIMED' if not bad else 'DIFFERS ' + str(bad)}")
    ALL &= not bad

# (T) threshold relation; atoms with h-values (signed Brier contributions), refined by splitting
base = [('x1', 3), ('y1', -2), ('x2', 4), ('y2', -3)]
for k in (1, 2):
    atoms = [(f"{nm}{t}", Fr(v, k)) for nm, v in base for t in range(k)]
    n = len(atoms); val = [v for _, v in atoms]
    pos = sum(1 << a for a in range(n) if val[a] > 0); neg = ((1 << n) - 1) & ~pos
    m = lambda S: sum(val[a] for a in range(n) if S >> a & 1)
    Gs = guided_set(n, pos, neg)
    for c in (Fr(1), Fr(5, 2)):
        Acc = Gs | {r for r in records(n) if m(r[0]) - m(r[1]) >= c}
        d = props(n, matrix_from_records(n, Acc), pos, neg, ib=(n <= 4))
        if n > 4: d['IB'] = True
        show(f"(T) k={k} c={c}", d, dict(refl=True, strictG=True, IB=True, TC=True, FCC=True, Add=True, TP=True, Tr=True, complete=False))
        small = [r for r in records(n) if r not in Gs and 0 < m(r[0]) - m(r[1]) < c]
        unranked = all((r not in Acc) and ((r[1], r[0]) not in Acc) for r in small)
        print(f"      {len(small)} non-guided Brier-improving records below the threshold, all unranked: {unranked}")
        ALL &= unranked

# (V) majority of three weighted-Brier scores, atoms a,b right; c,d wrong; weights chosen so that
#     r1=(ac,-) and r2=(bd,-) are each accepted but r1 u r2 is refused.
atoms = ['a', 'b', 'c', 'd']; sgn = [1, 1, -1, -1]
W = [[5, 1, 1, 9],   # score 1
     [1, 5, 9, 1],   # score 2
     [3, 3, 2, 2]]   # score 3
for k in (1, 2):
    n = 4 * k
    sg = [sgn[a // k] for a in range(n)]
    w = [[Fr(W[s][a // k], k) for a in range(n)] for s in range(3)]
    pos = sum(1 << a for a in range(n) if sg[a] > 0); neg = ((1 << n) - 1) & ~pos
    def score(s, r):
        P, N = r
        return sum(w[s][a] * sg[a] for a in range(n) if P >> a & 1) - sum(w[s][a] * sg[a] for a in range(n) if N >> a & 1)
    Acc = {r for r in records(n) if sum(score(s, r) >= 0 for s in range(3)) >= 2}
    d = props(n, matrix_from_records(n, Acc), pos, neg, ib=(n <= 4))
    if n > 4: d['IB'] = True
    show(f"(V) k={k}", d, dict(refl=True, strictG=True, IB=True, TP=True, complete=True, Add=False, TC=False))
    if k == 1:
        r1 = (0b0101, 0); r2 = (0b1010, 0)
        print("      scores r1=(ac,-):", [score(s, r1) for s in range(3)], " r2=(bd,-):", [score(s, r2) for s in range(3)],
              " r1 u r2:", [score(s, (0b1111, 0)) for s in range(3)])
print("ALL AS CLAIMED" if ALL else "SOME DIFFER")
