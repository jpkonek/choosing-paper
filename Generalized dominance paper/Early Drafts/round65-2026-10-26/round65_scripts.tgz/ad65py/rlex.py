"""AD65: finite-atom check of the (Add)-closed deletion relation R_lex(N) of AD65_notes.md §4.

Atoms carry integer payoff vectors h_a in Z^3 (unit mass); a model is a set of atoms; m(X) = sum h_a.
Record r = (A,B) attacks Z if B subset Z and A cap Z empty.  NA(N) = records attacking no member of N.
  Acc_i := G_i  u  { r in NA : L_i(r) >lex 0 }  u  { r in NA, r^-1 in NA : L_i(r) = 0 },
  L_i(r) := ( m_i(A)-m_i(B),  sum_j (m_j(A)-m_j(B)) ).
Checks (exhaustive over all 2^8 models, all records, all disjoint record pairs):
  reflexivity; strict (G); (TC); finite-chain consistency; (Add);
  protection: no member of N has a weak dominator other than itself;
  per model X notin N:  X dominated by a member of N  <=>  (star)(X);
  and, when (star) holds for all X notin N: undominated models = N exactly.
(TP) and transitivity failures are counted (they are not claimed).
Families: the declared families of REF64_es atoms.py, the Brier-Pareto family, and 'coherent-like'
families {atoms a : q.h_a > 0 for all q in Q} for random rational polytopes Q containing a fixed K'.
Run: python3 -I rlex.py > rlex.out"""
import numpy as np, itertools, random
from fractions import Fraction as Fr

H = np.array([(2,2,2),(3,-1,-1),(-1,3,-1),(-1,-1,3),(2,1,-2),(1,-2,2),(-2,2,1),(1,1,-1)])
n = len(H); M = 1 << n
bits = ((np.arange(M)[:,None] >> np.arange(n)) & 1).astype(np.int64)
mvec = bits @ H
POS = [sum(1<<a for a in range(n) if H[a,i] > 0) for i in range(3)]
NEG = [sum(1<<a for a in range(n) if H[a,i] < 0) for i in range(3)]
assert all((POS[i] | NEG[i]) == M-1 for i in range(3))
allpos = sum(1<<a for a in range(n) if all(H[a] > 0)); allneg = sum(1<<a for a in range(n) if all(H[a] < 0))
assert allneg == 0   # one-sided: no atom wrong at every world

def build(Nfam):
    Nf = list(Nfam)
    def attacks(A, B): return any((B & ~Z) == 0 and (A & Z) == 0 for Z in Nf)
    def guided(A, B, i): return (A & ~POS[i]) == 0 and (B & ~NEG[i]) == 0
    NA = {}
    def na(A, B):
        k = (A, B)
        if k not in NA: NA[k] = not attacks(A, B)
        return NA[k]
    def acc(i, A, B):
        if guided(A, B, i): return True
        d = mvec[A] - mvec[B]; s = int(d.sum()); di = int(d[i])
        if (di, s) > (0, 0): return na(A, B)
        if (di, s) == (0, 0): return na(A, B) and na(B, A)
        return False
    L = np.zeros((3, M, M), dtype=bool)
    for X in range(M):
        for Y in range(M):
            A, B = X & ~Y, Y & ~X
            for i in range(3): L[i, X, Y] = acc(i, A, B)
    return L, acc, na

def closure(R):
    T = R.copy()
    for k in range(M): T |= T[:, k][:, None] & T[k, :][None, :]
    return T

def check(Nfam, label):
    L, acc, na = build(Nfam)
    res = {}
    res['refl'] = all(L[i].diagonal().all() for i in range(3))
    sg = True
    for i in range(3):
        for X in range(M):
            for Y in range(M):
                A, B = X & ~Y, Y & ~X
                if (A | B) and (A & ~POS[i]) == 0 and (B & ~NEG[i]) == 0 and not (L[i, X, Y] and not L[i, Y, X]): sg = False
    res['strictG'] = sg
    tc = fcc = True; nontrans = 0; tpfail = 0
    for i in range(3):
        R = L[i]; S = R & ~R.T
        R2 = (R.astype(np.int32) @ R.astype(np.int32)) > 0
        if (R2 & S.T).any(): tc = False
        if (closure(R) & S.T).any(): fcc = False
        nontrans += int((R2 & ~R).sum())
        for X in range(M):
            for Mm in range(M):
                A, B = X & ~Mm, Mm & ~X
                if (A & ~POS[i]) == 0 and (B & ~NEG[i]) == 0:
                    tpfail += int((R[:, X] & ~R[:, Mm]).sum())
    res['TC'] = tc; res['FCC'] = fcc
    # (Add): exhaustive over all ordered pairs of records with disjoint supports (5^n assignments)
    addok = True
    for code in itertools.product(range(5), repeat=n):
        A1 = sum(1<<a for a,c in enumerate(code) if c == 1); B1 = sum(1<<a for a,c in enumerate(code) if c == 2)
        A2 = sum(1<<a for a,c in enumerate(code) if c == 3); B2 = sum(1<<a for a,c in enumerate(code) if c == 4)
        for i in range(3):
            if acc(i, A1, B1) and acc(i, A2, B2) and not acc(i, A1 | A2, B1 | B2):
                addok = False
    res['Add'] = addok
    WD = L[0] & L[1] & L[2]
    D = WD & ~(L[0].T & L[1].T & L[2].T)
    undom = {X for X in range(M) if not D[:, X].any()}
    res['protection'] = all(not WD[Y, Z] for Z in Nfam for Y in range(M) if Y != Z)
    def star(X):
        return any(np.all(mvec[Z] >= mvec[X]) and np.any(mvec[Z] != mvec[X]) and na(Z & ~X, X & ~Z) for Z in Nfam)
    others = [X for X in range(M) if X not in set(Nfam)]
    res['per_model_star<=>dominated_by_member'] = all(star(X) == any(D[Z, X] for Z in Nfam) for X in others)
    sa = all(star(X) for X in others)
    res['star_all'] = sa
    res['undom==N'] = (undom == set(Nfam))
    res['star_all=>undom==N'] = (not sa) or res['undom==N']
    res['TP_failures'] = tpfail; res['nontransitive_chains'] = nontrans; res['|N|'] = len(Nfam); res['|undom|'] = len(undom)
    print(label, res)
    return res

ok = True
def need(r):
    return r['refl'] and r['strictG'] and r['TC'] and r['FCC'] and r['Add'] and r['protection'] and \
           r['per_model_star<=>dominated_by_member'] and r['star_all=>undom==N']

random.seed(5)
a0 = allpos
fams = []
fams.append(('declared-0', sorted({a0, a0|0b1110, a0|0b1110000, a0|0b10, a0|0b100, a0|0b1000})))
fams.append(('declared-1', sorted({X for X in range(M) if X & a0 and bin(X).count('1') <= 2})))
for k in range(3):
    fams.append((f'random-{k}', sorted({a0} | {X | a0 for X in random.sample(range(M), 12)})))
par = [X for X in range(M) if not any(np.all(mvec[Y] >= mvec[X]) and np.any(mvec[Y] != mvec[X]) for Y in range(M))]
fams.append(('Pareto', [X for X in par if X & a0]))
# coherent-like families: X_Q = {a : q.h_a > 0 for all q in Q},  Q = conv(K' u random points), K' = {u}
u = np.array([Fr(1,3)]*3)
def DQ(Qpts):
    return sum(1<<a for a in range(n) if all(sum(Fr(int(H[a,j]))*q[j] for j in range(3)) > 0 for q in Qpts))
grid = [np.array([Fr(i,6), Fr(j,6), Fr(6-i-j,6)]) for i in range(7) for j in range(7-i)]
coh = {DQ([u])}
for _ in range(4000):
    coh.add(DQ([u] + random.sample(grid, random.randint(1, 4))))
fams.append(('coherent-like (all D_Q on atoms, Q from grid)', sorted(coh)))
if __name__ == "__main__":
    for lab, fam in fams:
        r = check(fam, lab)
        ok = ok and need(r)
    print("ALL STRUCTURAL CHECKS PASS:", ok)
    # pure guidance: Acc_i = G_i.  Transitive; every member of every family above has no weak dominator.
    def g(i, A, B): return (A & ~POS[i]) == 0 and (B & ~NEG[i]) == 0
    PG = np.array([[[g(i, X & ~Y, Y & ~X) for Y in range(M)] for X in range(M)] for i in range(3)])
    trans = all(not ((((PG[i].astype(np.int32) @ PG[i].astype(np.int32)) > 0) & ~PG[i]).any()) for i in range(3))
    WDg = PG[0] & PG[1] & PG[2]
    prot = all(not WDg[Y, Z] for lab, fam in fams for Z in fam for Y in range(M) if Y != Z)
    print("pure guidance: transitive at every world:", trans, "; every member of every family has no weak dominator:", prot)
