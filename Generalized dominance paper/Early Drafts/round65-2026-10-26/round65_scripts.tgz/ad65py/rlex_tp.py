"""AD65 (exploratory, atoms only): what happens to R_lex(N) if it is closed under (TP) and (Add)?
At each world, Acc_i is closed under r -> r o g (g guided at i) and disjoint union, until stable.
Reported: whether (TC) and protection of N survive, per family.  This is a diagnostic only: a failure on
atoms shows that THIS route (close R_lex) breaks; it does not show that (TP) excludes protection + cover.
Run: python3 -I rlex_tp.py > rlex_tp.out"""
import numpy as np, itertools, random, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rlex as RL
from props import comp

M, n = RL.M, RL.n
def recs():
    for code in itertools.product((0, 1, 2), repeat=n):
        yield (sum(1<<a for a,c in enumerate(code) if c == 1), sum(1<<a for a,c in enumerate(code) if c == 2))
ALL = list(recs())

def run(fam, label):
    L, acc, na = RL.build(fam)
    out = {}
    tc_all = prot = True
    Accs = []
    for i in range(3):
        A = {r for r in ALL if acc(i, *r)}
        G = [r for r in ALL if (r[0] & ~RL.POS[i]) == 0 and (r[1] & ~RL.NEG[i]) == 0]
        while True:
            new = set()
            for r in A:
                for g in G:
                    if (r[0] & g[0]) or (r[1] & g[1]): continue
                    c = comp(r, g)
                    if c not in A: new.add(c)
            if not new: break
            A |= new
            # disjoint-union closure
            while True:
                L2 = list(A); add = set()
                for r1 in L2:
                    s1 = r1[0] | r1[1]
                    for r2 in L2:
                        if s1 & (r2[0] | r2[1]): continue
                        u = (r1[0] | r2[0], r1[1] | r2[1])
                        if u not in A: add.add(u)
                if not add: break
                A |= add
        Accs.append(A)
    le = np.zeros((3, M, M), dtype=bool)
    for X in range(M):
        for Y in range(M):
            r = (X & ~Y, Y & ~X)
            for i in range(3): le[i, X, Y] = r in Accs[i]
    for i in range(3):
        R = le[i]; S = R & ~R.T
        R2 = (R.astype(np.int32) @ R.astype(np.int32)) > 0
        if (R2 & S.T).any(): tc_all = False
    WD = le[0] & le[1] & le[2]
    prot = all(not WD[Y, Z] for Z in fam for Y in range(M) if Y != Z)
    print(label, {'TC after closure': tc_all, 'protection after closure': prot,
                  'records accepted (3 worlds)': sum(len(Accs[i]) for i in range(3))})

random.seed(5)
for lab, fam in RL.fams:
    run(fam, lab)
