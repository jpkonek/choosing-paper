"""AD65: the explicit relational examples of AD65_notes.md §2, each checked exhaustively at model level.
Single world unless stated.  Atoms are named; 'pos' atoms are right to accept at this world, 'neg' wrong.
Run: python3 -I examples.py > examples.out"""
import itertools, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from props import *

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name); ok = ok and bool(cond)

def names(mask, nm):
    return '{' + ','.join(nm[a] for a in range(len(nm)) if mask >> a & 1) + '}'
def rname(r, nm):
    return f"({names(r[0], nm)} for {names(r[1], nm)})"

def report(label, n, nm, pos, neg, A, expect):
    le = model_matrix(n, lambda P, N: (P, N) in A)
    d = props(n, le, pos, neg)
    G = guided_records(n, pos, neg)
    print(f"\n== {label}")
    print("   atoms:", ', '.join(f"{nm[a]}({'+' if pos >> a & 1 else '-'})" for a in range(n)))
    print("   accepted non-guided records:", sorted(rname(r, nm) for r in A if r not in G))
    print("   ", fmt(d))
    for k, v in expect.items():
        check(f"{label}: {k} = {v}", d[k] == v)
    return le, d

def find_add_failure(n, le, nm):
    M = 1 << n
    for X in range(M):
        for Y in range(M):
            if not le[X][Y]: continue
            for Z in range(M):
                if le[Y][Z] and not le[X][Z] and ((X ^ Y) & (Y ^ Z)) == 0:
                    return f"X={names(X,nm)} <= Y={names(Y,nm)} <= Z={names(Z,nm)}, disjoint changes, X not<= Z"
def find_tp_failure(n, le, nm, pos, neg):
    M = 1 << n
    for Y in range(M):
        for X in range(M):
            if not le[Y][X]: continue
            for Mm in range(M):
                P, N = rec(X, Mm)
                if (P & ~pos) == 0 and (N & ~neg) == 0 and not le[Y][Mm]:
                    return f"Y={names(Y,nm)} <= X={names(X,nm)}, X pointwise at least as good as M={names(Mm,nm)}, Y not<= M"
def find_tc_failure(n, le, nm):
    M = 1 << n
    for A_ in range(M):
        for B in range(M):
            if not le[A_][B]: continue
            for C in range(M):
                if le[B][C] and strict(le, C, A_):
                    return f"A={names(A_,nm)} <= B={names(B,nm)} <= C={names(C,nm)} and C < A"
def find_strict_cycle(n, le, nm, maxlen=6):
    """shortest chain A0 <= A1 <= ... <= Ak with Ak < A0 (BFS)"""
    M = 1 << n
    best = None
    for s in range(M):
        prev = {s: None}; frontier = [s]
        for depth in range(maxlen):
            nxt = []
            for x in frontier:
                for y in range(M):
                    if le[x][y] and y not in prev:
                        prev[y] = x; nxt.append(y)
            frontier = nxt
        for t in prev:
            if strict(le, t, s):
                path = [t]
                while prev[path[-1]] is not None: path.append(prev[path[-1]])
                path = path[::-1]
                if best is None or len(path) < len(best): best = path
    return ' <= '.join(names(x, nm) for x in best) + f'  and  {names(best[-1],nm)} < {names(best[0],nm)}' if best else None

# ---------------------------------------------------------------- Example A
# (TC), FCC, (TP), (IB), strict (G) hold; (Add) fails.  Brier with ONE deleted strict record.
nm = ['x1', 'y1', 'x2', 'y2']; val = [3, -2, 4, -3]; n = 4
pos = 0b0101; neg = 0b1010
def m(S): return sum(val[a] for a in range(n) if S >> a & 1)
R = (0b1111, 0)
A = {r for r in all_records(n) if m(r[0]) - m(r[1]) >= 0 and r != R}
print("Example A: values", dict(zip(nm, val)), "; Acc = Brier-acceptable records minus R =", rname(R, nm))
le, d = report("Ex A", n, nm, pos, neg, A, dict(refl=True, strictG=True, IB=True, TC=True, FCC=True, TP=True, Add=False, trans=False))
print("   Add failure:", find_add_failure(n, le, nm))

# ---------------------------------------------------------------- Example B
# (Add), (TC), FCC, (IB), strict (G) hold; (TP) fails.  Brier sub-relation keeping G and one bundle.
nm = ['a', 'b', 'c']; val = [3, -1, -1]; n = 3
pos = 0b001; neg = 0b110
def m(S): return sum(val[a] for a in range(n) if S >> a & 1)
G = guided_records(n, pos, neg)
A = add_closure(G | {(0b111, 0)})
check("Ex B: every accepted record is Brier-strict or null (so a Brier sub-relation, symmetric on ties)",
      all((m(r[0]) - m(r[1]) > 0) or r == (0, 0) for r in A))
le, d = report("Ex B", n, nm, pos, neg, A, dict(refl=True, strictG=True, IB=True, TC=True, FCC=True, Add=True, TP=False, trans=False))
print("   TP failure:", find_tp_failure(n, le, nm, pos, neg))

# ---------------------------------------------------------------- Example C
# (Add), (TP), (IB), strict (G) hold; (TC) fails.
nm = ['a', 'b', 'c']; n = 3; pos = 0b001; neg = 0b110
G = guided_records(n, pos, neg)
A = add_tp_closure([(0b010, 0b100), (0b100, 0b011)], G)
le, d = report("Ex C", n, nm, pos, neg, A, dict(refl=True, strictG=True, IB=True, Add=True, TP=True, TC=False, FCC=False))
print("   TC failure:", find_tc_failure(n, le, nm))

# ---------------------------------------------------------------- Example D
# (Add), (TC), (IB), strict (G) hold; finite-chain consistency fails.
nm = ['a', 'b', 'c']; n = 3; pos = 0b001; neg = 0b110
G = guided_records(n, pos, neg)
A = add_closure(G | {(0b111, 0), (0b010, 0b101)})
le, d = report("Ex D", n, nm, pos, neg, A, dict(refl=True, strictG=True, IB=True, Add=True, TC=True, FCC=False))
print("   shortest strict cycle:", find_strict_cycle(n, le, nm))

# ---------------------------------------------------------------- Example D'
# (Add), (TP), (TC), (IB), strict (G) hold; finite-chain consistency fails.  Minimise the generators.
nm = ['a', 'b', 'c', 'd']; n = 4; pos = 0b0011; neg = 0b1100
G = guided_records(n, pos, neg)
S = [(5, 10), (9, 6), (2, 1), (1, 10)]
def pattern(S):
    A = add_tp_closure(S, G)
    le = model_matrix(n, lambda P, N: (P, N) in A)
    d = props(n, le, pos, neg)
    return d['strictG'] and d['Add'] and d['TP'] and d['TC'] and not d['FCC']
assert pattern(S)
changed = True
while changed:
    changed = False
    for r in list(S):
        T = [s for s in S if s != r]
        if T and pattern(T):
            S = T; changed = True; break
print("\nEx D' minimal generator set:", [rname(r, nm) for r in S])
A = add_tp_closure(S, G)
le, d = report("Ex D'", n, nm, pos, neg, A, dict(refl=True, strictG=True, IB=True, Add=True, TP=True, TC=True, FCC=False))
print("   shortest strict cycle:", find_strict_cycle(n, le, nm))

# ---------------------------------------------------------------- Example E
# (Add), (TP), (TC), FCC, (IB), strict (G) hold; transitivity fails.  Brier sub-relation.
nm = ['a', 'b', 'c']; val = [3, -1, -2]; n = 3; pos = 0b001; neg = 0b110
def m(S): return sum(val[a] for a in range(n) if S >> a & 1)
G = guided_records(n, pos, neg)
A = add_closure(G | {(0b010, 0b100), (0b101, 0)})
check("Ex E: every accepted record is Brier-strict or null", all((m(r[0]) - m(r[1]) > 0) or r == (0, 0) for r in A))
le, d = report("Ex E", n, nm, pos, neg, A, dict(refl=True, strictG=True, IB=True, Add=True, TP=True, TC=True, FCC=True, trans=False))
M = 1 << n
w = next((X, Y, Z) for X in range(M) for Y in range(M) for Z in range(M) if le[X][Y] and le[Y][Z] and not le[X][Z])
print("   non-transitive chain:", ' <= '.join(names(x, nm) for x in w), " (first and last incomparable:",
      not le[w[0]][w[2]] and not le[w[2]][w[0]], ")")

# ---------------------------------------------------------------- Example F
# Complete and transitive (hence (Add), (TC), FCC, (TP)); strict (G); (IB) fails.  Model-level relation.
nm = ['a', 'b', 'c']; val = [1, 1, -1]; n = 3; pos = 0b011; neg = 0b100; eps = 0.5
def phi(X):
    return sum(val[a] for a in range(n) if X >> a & 1) + eps * ((X & 0b101) == 0b101)   # interaction of a and c
le = [[phi(X) >= phi(Y) for Y in range(8)] for X in range(8)]
d = props(n, le, pos, neg)
print("\n== Ex F (score Phi(X) = m(X) + 1/2 [a and c both in X])\n   ", fmt(d))
for k, v in dict(refl=True, strictG=True, trans=True, complete=True, Add=True, TC=True, FCC=True, TP=True, IB=False).items():
    check(f"Ex F: {k} = {v}", d[k] == v)
print("   IB failure: {a} vs {b} tied; {a,c} vs {b,c} strict:", le[1][2] and le[2][1], strict(le, 5, 6))

# ---------------------------------------------------------------- Example G
# Complete, (IB), strict (G), (Add); (TC) fails.  Exhaustive over orientations on 3 atoms.
nm = ['a', 'b', 'c']; n = 3; pos = 0b001; neg = 0b110
G = guided_records(n, pos, neg); AG = {(r[1], r[0]) for r in G}
free = sorted({frozenset((r, (r[1], r[0]))) for r in all_records(n) if r not in G and r not in AG}, key=sorted)
exG = None; count = 0
for choice in itertools.product((0, 1, 2), repeat=len(free)):
    A = set(G)
    for pair, c in zip(free, choice):
        r1, r2 = sorted(pair)
        if c in (0, 2): A.add(r1)
        if c in (1, 2): A.add(r2)
    le = model_matrix(n, lambda P, N: (P, N) in A)
    d = props(n, le, pos, neg)
    if d['complete'] and d['strictG'] and d['Add'] and not d['TC']:
        count += 1
        if exG is None or len(A) < len(exG): exG = A
print(f"\n   complete + (Add) + strict (G) + (IB) without (TC): {count} of {3**len(free)} orientations")
le, d = report("Ex G", n, nm, pos, neg, exG, dict(complete=True, strictG=True, IB=True, Add=True, TC=False))
print("   TC failure:", find_tc_failure(n, le, nm))

# ---------------------------------------------------------------- Example H
# 'Trust region' deliberate incomparability: Brier verdicts only for changes touching at most 2 atoms.
# World-local, accuracy-only; reflexive, strict (G), (IB), (TC), FCC hold; (Add) fails.
nm = ['x1', 'y1', 'x2', 'y2']; val = [3, -2, 4, -3]; n = 4; pos = 0b0101; neg = 0b1010
def m(S): return sum(val[a] for a in range(n) if S >> a & 1)
G = guided_records(n, pos, neg)
A = set(G) | {r for r in all_records(n) if m(r[0]) - m(r[1]) >= 0 and bin(r[0] | r[1]).count('1') <= 2}
le, d = report("Ex H", n, nm, pos, neg, A, dict(refl=True, strictG=True, IB=True, TC=True, FCC=True, Add=False))
print("   Add failure:", find_add_failure(n, le, nm))

print("\nALL PASS" if ok else "\nSOME FAIL")
