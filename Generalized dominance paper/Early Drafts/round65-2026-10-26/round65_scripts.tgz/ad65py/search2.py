"""AD65: random search for  (Add)+(TP)+(TC) without finite-chain consistency, and for (TP)+(TC) without FCC.
Run: python3 -I search2.py > search2.out"""
import random, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from props import *

rng = random.Random(7)
targets = {'TP,TC, not FCC': lambda d: d['strictG'] and d['TP'] and d['TC'] and not d['FCC'],
           'Add,TP,TC, not FCC': lambda d: d['strictG'] and d['Add'] and d['TP'] and d['TC'] and not d['FCC']}
found = {}
tried = {'tp': 0, 'addtp': 0}; tc_ok = {'tp': 0, 'addtp': 0}
for it in range(6000):
    n = rng.choice((4, 4, 5))
    npos = rng.randint(1, n - 1)
    pos = (1 << npos) - 1; neg = ((1 << n) - 1) & ~pos
    G = guided_records(n, pos, neg)
    nong = [r for r in all_records(n) if r not in G and (r[1], r[0]) not in G]
    S = rng.sample(nong, rng.randint(2, 4))
    for mode in ('tp', 'addtp'):
        A = tp_closure(set(G) | set(S), G) if mode == 'tp' else add_tp_closure(S, G)
        if len(A) > 3 ** n * 0.6: continue
        tried[mode] += 1
        le = model_matrix(n, lambda P, N: (P, N) in A)
        d = props(n, le, pos, neg)
        if d['TC'] and d['strictG']: tc_ok[mode] += 1
        for name, f in targets.items():
            if name not in found and f(d):
                found[name] = (n, pos, S, mode)
                print(f"{name}: n={n} pos={pos:0{n}b} S={S} mode={mode} |Acc|={len(A)} {fmt(d)}"); sys.stdout.flush()
    if len(found) == len(targets): break
print("tried:", tried, " of which strict (G) and (TC) hold:", tc_ok)
print("not found:", [t for t in targets if t not in found])
