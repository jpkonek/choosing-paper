"""AD65: exact checkers for single-world and multi-world relational properties on finite atom systems.

An atom stands for a non-null measurable cell with a fixed sign pattern (and, where needed, a fixed
integer payoff vector).  Models are bitmasks of atoms.  A relation at one world is given either
  - at record level: a predicate acc(P, N) on disjoint pairs (records), so (IB) holds by construction; or
  - at model level: a boolean matrix le[X][Y]  ("X is no worse than Y").
All checks below are exhaustive over the finite model space; nothing is sampled unless stated.

Conventions (as in ES64/OR64):  X <= Y means X is at least as good as Y;  rec(X,Y) = (X\\Y, Y\\X);
a record (P,N) is guided at w if P subset pos_w and N subset neg_w.
"""
import itertools

def rec(X, Y):
    return (X & ~Y, Y & ~X)

def comp(r1, r2):
    (P1, N1), (P2, N2) = r1, r2
    return ((P1 & ~N2) | (P2 & ~N1), (N1 & ~P2) | (N2 & ~P1))

def model_matrix(n, acc):
    M = 1 << n
    return [[acc(X & ~Y, Y & ~X) for Y in range(M)] for X in range(M)]

def strict(le, X, Y):
    return le[X][Y] and not le[Y][X]

def closure(le):
    M = len(le)
    T = [row[:] for row in le]
    for k in range(M):
        Tk = T[k]
        for i in range(M):
            if T[i][k]:
                Ti = T[i]
                for j in range(M):
                    if Tk[j]:
                        Ti[j] = True
    return T

def props(n, le, pos, neg, complete_check=False):
    """Return a dict of exact property values for one world.
    pos, neg: bitmasks of atoms with h_w > 0, h_w < 0 (every atom is in exactly one)."""
    M = 1 << n
    out = {}
    out['refl'] = all(le[X][X] for X in range(M))
    def guided(X, Y):
        P, N = rec(X, Y)
        return (P & ~pos) == 0 and (N & ~neg) == 0
    # strict (G): guided non-null => X <_w Y ;  weak (G): guided => X <=_w Y
    sg = wg = True
    for X in range(M):
        for Y in range(M):
            if guided(X, Y):
                if not le[X][Y]: wg = False
                if X != Y and not strict(le, X, Y): sg = False
    out['strictG'] = sg; out['weakG'] = wg
    # (IB) in W62 form, exhaustive: X<=Y iff X'<=Y' whenever (X,Y),(X',Y') have the same record
    recmap = {}
    ib = True
    for X in range(M):
        for Y in range(M):
            r = rec(X, Y)
            if r in recmap and recmap[r] != le[X][Y]: ib = False
            recmap.setdefault(r, le[X][Y])
    out['IB'] = ib
    tc = trans = add = tp = True
    for A in range(M):
        for B in range(M):
            if not le[A][B]: continue
            for C in range(M):
                if not le[B][C]: continue
                if strict(le, C, A): tc = False
                if not le[A][C]:
                    trans = False
                    if ((A ^ B) & (B ^ C)) == 0: add = False
    # (TP): Y <= X and X pointwise at least as good as Mm (guided, possibly null) => Y <= Mm
    for Y in range(M):
        for X in range(M):
            if not le[Y][X]: continue
            for Mm in range(M):
                if guided(X, Mm) and not le[Y][Mm]: tp = False
    out['TC'] = tc; out['trans'] = trans; out['Add'] = add; out['TP'] = tp
    T = closure(le)
    out['FCC'] = not any(T[A][C] and strict(le, C, A) for A in range(M) for C in range(M))
    out['complete'] = all(le[X][Y] or le[Y][X] for X in range(M) for Y in range(M))
    return out

def fmt(d, keys=('refl','strictG','IB','TC','FCC','Add','TP','trans','complete')):
    return '  '.join(f"{k}={'Y' if d[k] else 'n'}" for k in keys)

# ---------- record-level closures (single world) ----------
def all_records(n):
    for code in itertools.product((0, 1, 2), repeat=n):
        P = sum(1 << a for a, c in enumerate(code) if c == 1)
        N = sum(1 << a for a, c in enumerate(code) if c == 2)
        yield (P, N)

def guided_records(n, pos, neg):
    return {r for r in all_records(n) if (r[0] & ~pos) == 0 and (r[1] & ~neg) == 0}

def add_closure(S):
    S = set(S)
    changed = True
    while changed:
        changed = False
        L = list(S)
        for r1 in L:
            s1 = r1[0] | r1[1]
            for r2 in L:
                if s1 & (r2[0] | r2[1]): continue
                u = (r1[0] | r2[0], r1[1] | r2[1])
                if u not in S:
                    S.add(u); changed = True
    return S

def tp_closure(S, G):
    """close under r -> r o g for guided g composable with r (this is (TP) at record level)."""
    S = set(S)
    changed = True
    while changed:
        changed = False
        for r in list(S):
            for g in G:
                if (r[0] & g[0]) or (r[1] & g[1]): continue
                c = comp(r, g)
                if c not in S:
                    S.add(c); changed = True
    return S

def add_tp_closure(S, G):
    S = set(S) | set(G)
    while True:
        S2 = tp_closure(add_closure(S), G)
        if S2 == S: return S
        S = S2
