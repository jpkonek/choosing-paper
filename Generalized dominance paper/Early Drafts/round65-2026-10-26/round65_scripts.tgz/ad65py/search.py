"""AD65: exhaustive search for small single-world record relations realising each property pattern.
Relations are closures of  G  u  S  (S = a few non-guided records) under disjoint union ('add')
or under disjoint union and composition with guided records ('addtp').  Every reported example is
then re-checked exhaustively at model level in examples.py.  Run: python3 -I search.py > search.out"""
import itertools, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from props import *

patterns = {
 'P2: Add,TC,FCC, not TP':        lambda d: d['strictG'] and d['Add'] and d['TC'] and d['FCC'] and not d['TP'],
 'P3: Add,TP, not TC':            lambda d: d['strictG'] and d['Add'] and d['TP'] and not d['TC'],
 'P4: Add,TC, not FCC':           lambda d: d['strictG'] and d['Add'] and d['TC'] and not d['FCC'],
 'P4p: Add,TP,TC, not FCC':       lambda d: d['strictG'] and d['Add'] and d['TP'] and d['TC'] and not d['FCC'],
 'P5: Add,TP,TC,FCC, not trans':  lambda d: d['strictG'] and d['Add'] and d['TP'] and d['TC'] and d['FCC'] and not d['trans'],
}
found = {}
for n in (3, 4):
    for npos in range(1, n):
        pos = (1 << npos) - 1; neg = ((1 << n) - 1) & ~pos
        G = guided_records(n, pos, neg)
        nong = [r for r in all_records(n) if r not in G and (r[1], r[0]) not in G]   # neither guided nor anti-guided
        for k in (1, 2, 3):
            if n == 4 and k == 3: break
            for S in itertools.combinations(nong, k):
                for mode in ('add', 'addtp'):
                    A = add_closure(set(G) | set(S)) if mode == 'add' else add_tp_closure(S, G)
                    le = model_matrix(n, lambda P, N: (P, N) in A)
                    d = props(n, le, pos, neg)
                    for name, f in patterns.items():
                        if name not in found and f(d):
                            found[name] = (n, pos, neg, S, mode, d)
                            print(f"{name}: n={n} pos={pos:0{n}b} S={S} mode={mode} |Acc|={len(A)}  {fmt(d)}")
                            sys.stdout.flush()
        if len(found) == len(patterns): break
    if len(found) == len(patterns): break
print("not found:", [p for p in patterns if p not in found])
