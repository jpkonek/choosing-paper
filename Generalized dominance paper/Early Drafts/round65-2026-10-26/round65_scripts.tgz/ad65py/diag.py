"""AD65: (Add)-closures of OR64's diagnostics M1 and T.  Does (Add) exclude the *conclusions* of M1 and T,
or only the particular relations?  Same atom systems as OR64 or64py/records.py.
  M1+ : Acc_w = G_w u { r0 u g : g in G_w, supports disjoint }  for w in {i, j};  Acc_k = G_k.
  T+  : Acc_w = { t u g : t in T_w or null, g in G_w, supports disjoint }.
Everything exhaustive over all models / triples / disjoint record pairs.  Run: python3 -I diag.py > diag.out"""
import itertools, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from props import props, fmt, model_matrix, closure

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name); ok = ok and bool(cond)

class Sys3:
    def __init__(self, atoms):
        self.atoms = atoms; self.n = len(atoms); self.full = (1 << self.n) - 1
        self.pos = [sum(1 << a for a, (_, s, _) in enumerate(atoms) if s[w] > 0) for w in range(3)]
        self.neg = [sum(1 << a for a, (_, s, _) in enumerate(atoms) if s[w] < 0) for w in range(3)]
    def mask(self, *nm): return sum(1 << a for a, (x, _, _) in enumerate(self.atoms) if x in nm)
    def tagged(self, t): return sum(1 << a for a, (_, _, tg) in enumerate(self.atoms) if t in tg)
    def guided(self, w, p, q): return (p & ~self.pos[w]) == 0 and (q & ~self.neg[w]) == 0
    def anti(self, w, p, q): return (p | q) != 0 and self.guided(w, q, p)
    def names(self, X): return '{' + ','.join(x for a, (x, _, _) in enumerate(self.atoms) if X >> a & 1) + '}'
    def finish(self, label):
        self.le = [model_matrix(self.n, lambda P, N, w=w: self.acc(w, P, N)) for w in range(3)]
        allok = True
        for w in range(3):
            d = props(self.n, self.le[w], self.pos[w], self.neg[w])
            print(f"   {label} world {w+1}: {fmt(d)}")
            allok = allok and d['refl'] and d['strictG'] and d['IB'] and d['TC'] and d['Add']
            self.last = d
        check(f"{label}: reflexive, strict (G), (IB), (TC), (Add) at every world (exhaustive)", allok)
    def LE(self, w, X, Y): return self.le[w][X][Y]
    def LT(self, w, X, Y): return self.le[w][X][Y] and not self.le[w][Y][X]
    def dom(self, Y, X): return all(self.LE(w, Y, X) for w in range(3)) and any(self.LT(w, Y, X) for w in range(3))

def disjoint_decomp(p, q, S1, S2):
    """is (p,q) = s1 u s2 with s1 in S1(pred), s2 in S2(pred), disjoint supports?  brute force over splits."""
    sup = p | q
    sub = sup
    while True:
        p1, q1 = p & sub, q & sub
        if S1(p1, q1) and S2(p & ~sub, q & ~sub): return True
        if sub == 0: return False
        sub = (sub - 1) & sup

# ---------------------------------------------------------------- M1+
print("§1 M1+ = (Add)-closure of OR64's M1")
M1 = Sys3([('E',(+1,-1,+1),{'R'}),('A',(-1,+1,+1),set()),('B',(+1,+1,-1),set()),('R2',(-1,-1,+1),{'R'}),
           ('P',(+1,+1,+1),set()),('D',(+1,-1,-1),set()),('E2',(+1,-1,+1),set()),('F',(-1,+1,-1),set())])
r0 = (M1.mask('E','A'), M1.mask('B'))
def accM1p(w, p, q):
    if M1.guided(w, p, q): return True
    if w == 2: return False
    # (p,q) = r0 u g, g guided at w, disjoint
    if (p & r0[0]) != r0[0] or (q & r0[1]) != r0[1]: return False
    return M1.guided(w, p & ~r0[0], q & ~r0[1])
M1.acc = accM1p
M1.finish("M1+")
i, j, k = 0, 1, 2
R = M1.tagged('R'); MR = (M1.full & ~R) & M1.neg[j]; Xi = (M1.full & ~R) & M1.pos[i]
Y0 = (Xi & ~M1.mask('B')) | M1.mask('E','A')
check("M1+: R is an E61 priority region at j (no Y meeting R has Y <=_j M_R)",
      all(not M1.LE(j, Y, MR) for Y in range(M1.full+1) if Y & R))
check("M1+: Y0 meets R and dominates the box model X_i (E61 box lemma still fails)", (Y0 & R) and M1.dom(Y0, Xi))
check("M1+: (TP) fails at j: Y0 <=_j X_i, X_i pointwise at least as good as M_R at j, Y0 not <=_j M_R",
      M1.LE(j, Y0, Xi) and M1.guided(j, Xi & ~MR, MR & ~Xi) and not M1.LE(j, Y0, MR))

# ---------------------------------------------------------------- T+
print("§2 T+ = (Add)-closure of OR64's diagnostic T")
T = Sys3([('I0',(+1,+1,+1),{'IN'}),('I1',(-1,+1,+1),{'IN'}),('I2',(+1,-1,+1),{'IN'}),('I3',(+1,+1,-1),{'IN'}),
          ('O1',(+1,-1,-1),{'OUT'}),('O2',(-1,+1,-1),{'OUT'}),('O3',(-1,-1,+1),{'OUT'}),('O4',(+1,+1,-1),{'OUT'}),
          ('O5',(-1,+1,+1),{'OUT'})])
IN, OUT = T.tagged('IN'), T.tagged('OUT')
def inT(w, p, q):
    return (p | q) != 0 and (p & ~IN) == 0 and (q & ~OUT) == 0 and not T.anti(w, p, q)
def accTp(w, p, q):
    if T.guided(w, p, q) or inT(w, p, q): return True
    return disjoint_decomp(p, q, lambda a, b: inT(w, a, b), lambda a, b: T.guided(w, a, b))
T.acc = accTp
T.finish("T+")
DK = IN; NM = T.full + 1
undom = [X for X in range(NM) if not any(T.dom(Y, X) for Y in range(NM))]
I_set = [X for X in range(NM) if any(T.guided(w, X & ~DK, DK & ~X) for w in range(3))]
check("T+: D_K undominated, and no other model is tied with D_K at every world",
      DK in undom and all(not (all(T.LE(w, X, DK) and T.LE(w, DK, X) for w in range(3))) for X in range(NM) if X != DK))
check("T+: undominated models = D_K together with the one-world improvements of D_K (same as T)",
      sorted(undom) == sorted(I_set))
print(f"   |models| = {NM}, |undominated| = {len(undom)}")
collar = [P for P in range(1, NM) if (P & ~OUT) == 0 and all(P & T.neg[w] for w in range(3))]
check(f"T+: all {len(collar)} collar additions refused at every world, and D_K strictly dominates each D_K u P",
      all(not T.LE(w, DK | P, DK) for w in range(3) for P in collar) and all(T.dom(DK, DK | P) for P in collar))
print("ALL PASS" if ok else "SOME FAIL")
