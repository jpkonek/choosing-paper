"""REF65_hB: random adversarial rivals (spikes to dU, notches at dD touching it, holes in non-pointed U,
holes touching dU), X65 uniform shrink end to end, exact certificates (see e2e.py)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e2e
from e2e import *
R = random.Random(7)
def rv(lo, hi): return F(R.randint(lo, hi), R.randint(1, 9))
out = []
for t in range(36):
    kind = t % 4
    if kind == 0:     # spike beyond a random face of D, random width, through to dU
        f = R.randrange(3); v = KD[f]; i, j = [k for k in range(3) if k != f]
        s = add(E[i], E[j]); l = sub(E[i], E[j]); w = F(1, R.choice([10, 40, 200, 1000]))
        off = F(R.randint(-8, 8), 10)
        S = UP + [neg(v), add(sub(l, sc(off, s)), sc(w, s)), add(neg(sub(l, sc(off, s))), sc(w, s))]
        X = [D, S]; hint = None; name = "spike f%d w=%s off=%s" % (f, w, off)
    elif kind == 1:   # several notches touching dD (incl. deep ones)
        X = [D]; hint = []
        for _ in range(R.randint(1, 4)):
            f = R.randrange(3); lo = F(R.randint(-9, 8), 10); hi = lo + F(R.randint(1, 5), 50)
            dp = F(1, R.choice([5, 20, 100, 1000]))
            X = minus_cone(X, notch(dp, lo, hi, f)); hint.append(D + notch(dp, lo, hi, f))
        name = "notches x%d" % len(hint)
    elif kind == 2:   # hole inside the half-space U = {sum h > 0}, avoiding R^3_+
        while True:
            g = [tuple(rv(-6, 6) for _ in range(3)) for _ in range(3)]
            if all(sum(x) > 0 for x in g) and all(min(x) < 0 for x in g) and det3(*g) != 0:
                Hc = simplicial(g)
                if moment(Hc + [V(1, 0, 0)] + [V(0, 1, 0)] + [V(0, 0, 1)])[0] == 0: break
        X = minus_cone([[U3]], Hc); hint = [Hc]; name = "half-space hole"
    else:             # hole touching dU (one generator on dU)
        while True:
            z = (rv(-6, 6), rv(-6, 6)); g0 = V(z[0], z[1], -z[0]-z[1])
            g = [g0] + [tuple(rv(-6, 6) for _ in range(3)) for _ in range(2)]
            if g0 != V(0, 0, 0) and all(sum(x) > 0 for x in g[1:]) and det3(*g) != 0:
                Hc = simplicial(g)
                if moment(Hc + [V(1, 0, 0)] + [V(0, 1, 0)] + [V(0, 0, 1)])[0] == 0: break
        X = minus_cone([[U3]], Hc); hint = [Hc]; name = "half-space hole at dU"
    QX = QX_of(X) if kind < 2 else [U3]
    e2e.HINT[0] = hint
    r = x65("#%02d %s" % (t, name), X, QX, None)
    out.append(bool(r and r['cert']))
print("certified %d / %d (failures are search failures unless a printed exact check fails)" % (sum(out), len(out)))
