"""REF65_hB: X65 Example NP (non-pointed hull) against H65's Generation Lemma and Step 2,
and against X65's uniform shrink.  Exact rational arithmetic throughout.

NP: n = 3, K' = {u}, U = {sum h > 0}.  Unnormalised frame w = (1,-1,0), w' = (1,1,-2), 1 = (1,1,1).
For h = A w + B w' + G 1 the orthonormal coordinates are alpha = A sqrt2, beta = B sqrt6,
gamma = G sqrt3, and |h|^2 = 2A^2 + 6B^2 + 3G^2.
X := int R^3_+  u  {gamma > 0, gamma|h| < beta^2 < 4 gamma|h|}
   <=> G > 0 and 3 G^2 |h|^2 < 36 B^4 < 48 G^2 |h|^2   (squared; exact test).
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geo3 import *

w, wp = V(1,-1,0), V(1,1,-2)
def pt(A, B, G): return add(sc(A, w), sc(B, wp), sc(G, ONE))
def in_band(A, B, G):
    h2 = 2*A*A + 6*B*B + 3*G*G
    return G > 0 and 3*G*G*h2 < 36*B**4 < 48*G*G*h2
def in_X(A, B, G):
    h = pt(A, B, G)
    return min(h) > 0 or in_band(A, B, G)

print("== Example NP: exact checks ==")
a = V(2, 2, -1)                      # = w' + 1
print("a = w' + 1 =", a, " in U:", sum(a) > 0, " in X:", in_X(F(0), F(1), F(1)))

# (1) Without the lineality cut (N1 = U): Sigma(X) \ N1 = Sigma(X) n dU = rays +-w (X65, analytic).
#     a is in N1 = U but not in cone(+-w) + int R^3_+ : every a - lam w + lam' w has 3rd coord a_3 = -1.
print("(1) N1 = U: w_3 =", w[2], "; so (a - c)_3 = a_3 =", a[2], "< 0 for every c in cone(+-w):",
      "Generation Lemma conclusion FAILS without its lineality hypothesis (cl N1 = cl U contains 1^perp).")

# (2) H65 Step 2: q''_k = (1-s1) u + s1 delta_k, N1 = U n {q''_k.h > 0, k=1..3}.
s1 = F(1, 10)
qpp = [add(sc(1-s1, U3), sc(s1, E[k])) for k in range(3)]
N1 = [U3] + qpp
print("(2) lineality cut s1 = 1/10; a in N1:", inside(N1, a))
#     cl N1 meets L = 1^perp only in 0: on L, q''_k.l = s1 l_k and some l_k < 0 (Lemma 2.5).
for l in (w, neg(w), wp, neg(wp), add(w, wp), sub(w, wp)):
    assert any(dot(q, l) < 0 for q in qpp)
print("    sample lineality directions all cut off by some q''_k: True")
#     tangential X points outside N1 that generate a:
A, B, G = F(1), F(1, 10), F(1, 100)
xp, xm = pt(A, B, G), pt(-A, B, G)
print("    x+ = w + B w' + G 1 =", xp, " in X:", in_X(A, B, G), "  outside cl N1:", outside_cl(N1, xp))
print("    x- =-w + B w' + G 1 =", xm, " in X:", in_X(-A, B, G), "  outside cl N1:", outside_cl(N1, xm))
lam = F(5)
resid = sub(a, sc(lam, add(xp, xm)))
print("    a - 5(x+ + x-) =", resid, " >> 0:", min(resid) > 0)
#     x+- are interior points of X (open band) and of the open set {q''_k.h < 0}; so they are
#     density points of X \ N for any N inside N1 -> Lemma 2.1 certifies the hull part.

# (3) X65 uniform shrink on the same a: Q_X = {u}, P(h) = u.h; tau = 1/10, delta = 1/40 < tau P(a)/2.
tau, delta = F(1, 10), F(1, 40)
Pa = dot(U3, a)
b = sub(a, sc(Pa - delta, ONE))
print("(3) shrink: P(a) =", Pa, " a in N_tau:", (1-tau)*Pa + tau*min(a) > 0, " b =", b, " P(b) =", dot(U3, b))
A, B, G = F(100), F(1, 2), F(1, 300)
yp, ym = pt(A, B, G), pt(-A, B, G)
pprime = sub(b, add(yp, ym))
def in_Ntau(h): return dot(U3, h) > 0 and (1-tau)*dot(U3, h) + tau*min(h) > 0
print("    y+, y- in X:", in_X(A, B, G), in_X(-A, B, G), "; p' = b - y+ - y- =", pprime, ">> 0:", min(pprime) > 0)
print("    y+ removed (outside cl N_tau):", not in_Ntau(yp), "; y- removed:", not in_Ntau(ym))
Qp = polygon_Q([yp, ym])
mn = min(dot(q, a) for q in Qp)
print("    min over {q in Delta: q.y+ >= 0, q.y- >= 0} of q.a =", mn, " >= P(a) - delta/tau =", Pa - delta/tau, ":", mn >= Pa - delta/tau, "> 0:", mn > 0)
