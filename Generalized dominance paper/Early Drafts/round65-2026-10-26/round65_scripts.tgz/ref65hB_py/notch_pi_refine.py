"""REF65_hB: refine the hull-relative Bayes act search on notch rivals #13, #17, #29 (search aid).
Lemma 2.2(d) (H65) / Step 1 (X65) assert existence; this checks numerically that the window is
merely tiny, then re-checks any hit exactly and runs the exact X65 certificate from it."""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
HERE = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(HERE, 'e2e_random.py')).read()
src = src.replace("    r = x65(", "    RIV.append((t,name,X,QX,hint)); r=None and x65(").replace('print("certified', '0 and print("certified')
RIV = []
exec(compile(src, 'e2e_random', 'exec'), {'__file__': os.path.join(HERE, 'e2e_random.py'), 'RIV': RIV})
import e2e
from e2e import *
from scipy.optimize import minimize
import numpy as np
for (t, name, X, QX, hint) in RIV:
    if t not in (1, 13, 17, 29): continue
    mX = mX_of(X); mXf = [float(x) for x in mX]; Gf = fl(QX)
    def marg(p):
        d = moment(Gf + [tuple(p)], 1.0, 0.0)[1]; return [d[i]-mXf[i] for i in range(3)]
    best = None
    # smooth surrogate: maximise soft-min, many restarts around each vertex of Q_X
    rs = np.random.RandomState(t)
    for qv in QX:
        qf = np.array([float(c) for c in qv])
        for trial in range(60):
            z0 = qf[:2] + rs.normal(0, 10**rs.uniform(-6, -2), 2)
            def obj(z):
                p = (z[0], z[1], 1-z[0]-z[1])
                if min(p) < 0: return 1.0
                return -min(marg(p))*1e6
            r = minimize(obj, z0, method='Nelder-Mead',
                         options=dict(xatol=1e-14, fatol=1e-12, maxiter=4000,
                                      initial_simplex=[z0, z0+[1e-5, 0], z0+[0, 1e-5]]))
            v = -r.fun/1e6
            if best is None or v > best[0]: best = (v, (r.x[0], r.x[1], 1-r.x[0]-r.x[1]))
    print("#%02d best float min-margin %.3e at pi=%s" % (t, best[0], tuple(round(c, 12) for c in best[1])))
    if best[0] > 0:
        for dd in (10**12, 10**14, 10**16):
            a_, b_ = fr(best[1][0], dd), fr(best[1][1], dd); pi = (a_, b_, 1-a_-b_)
            d = sub(moment(list(QX) + [pi])[1], mX)
            if min(d) > 0: break
        print("    exact margin:", [float(x) for x in d], "strict:", min(d) > 0)
        if min(d) > 0:
            e2e.find_pi = lambda Gin, mX_, grid=0: (pi, d)
            e2e.HINT[0] = hint
            e2e.x65("#%02d %s (refined pi)" % (t, name), X, QX, None)
