"""REF65_hB: independent end-to-end runs of X65's uniform-shrink construction (Theorem H.1), and of
H65's lineality-cut path (Step 2) on NON-POINTED hulls, on adversarial polyhedral rivals.
Exact rational verification of every certificate; floats only steer the searches.

Certificate checked exactly (sufficient for (H) at X with defender N):
  (1) N = D_Q with Q a finite set containing (the vertices of) Q_X, so N is coherent (K' <= Q_X);
  (2) m(N) - m(X) >> 0 (exact moments);
  (3) a lies in the open set N and outside the closure of every piece of X  => a is a density
      point of N \\ X;
  (4) the removed points x_j lie strictly inside a piece of X and outside cl N  => density points
      of X \\ N; and min{q.a : q in Delta, q.x_j >= 0 for all j} > 0 (exact polygon in Delta).
  By Claim 0 (WT65) Q_{X\\N} lies in that polygon, so a ball around a lies in hull(X\\N).
"""
import os, sys, random, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geo3 import *
import numpy as np
from scipy.optimize import linprog, minimize

rnd = random.Random(2026)

def rays(ineqs):
    out = []
    for i in range(len(ineqs)):
        for j in range(i+1, len(ineqs)):
            r = cross(ineqs[i], ineqs[j])
            if r == (0, 0, 0): continue
            for rr in (r, neg(r)):
                if all(dot(a, rr) >= 0 for a in ineqs):
                    s = sum(abs(x) for x in rr); rr = tuple(x/s for x in rr)
                    if rr not in out: out.append(rr)
    return out

def pointed(ineqs):
    R = rays(ineqs)
    return len(R) >= 3 and any(det3(R[i], R[j], R[k]) != 0 for i in range(len(R))
                               for j in range(i+1, len(R)) for k in range(j+1, len(R)))

def mX_of(pieces): return add(*[moment(p)[1] for p in pieces])

def fr(x, d=10**6): return F(x).limit_denominator(d)

def sample_in(piece, k, conc=False):
    """k exact points strictly inside the open cone 'piece'."""
    out = []
    R = rays(piece) if pointed(piece) else None
    tries = 0
    while len(out) < k and tries < 200*k:
        tries += 1
        if R:
            if conc:
                i = rnd.randrange(len(R))
                wts = [F(1) if j == i else F(1, 10**rnd.randint(2, 6)) for j in range(len(R))]
            else:
                wts = [F(rnd.randint(1, 100)) for _ in R]
            h = add(*[sc(wt, r) for wt, r in zip(wts, R)])
        else:
            h = tuple(fr(rnd.gauss(0, 1), 1000) for _ in range(3))
            if conc:   # push towards the boundary of the piece
                t = F(rnd.randint(1, 1000), 1000)
                h = add(h, sc(-t, ONE)) if rnd.random() < .5 else h
        if inside(piece, h): out.append(h)
    return out

def find_pi(Gin, mX, grid=36):
    mXf = [float(x) for x in mX]; Gf = fl(Gin)
    def fval(p):
        d = moment(Gf + [tuple(p)], 1.0, 0.0)[1]
        return min(d[i]-mXf[i] for i in range(3))
    best = None
    for i in range(grid+1):
        for j in range(grid+1-i):
            p = (i/grid, j/grid, (grid-i-j)/grid)
            v = fval(p)
            if best is None or v > best[0]: best = (v, p)
    cands = [best]
    def obj(z):
        q = (z[0], z[1], 1-z[0]-z[1])
        return 1.0 if min(q) < 0 else -fval(q)
    for st in [best[1]] + [(rnd.random(), rnd.random()) for _ in range(8)]:
        r = minimize(obj, np.array(st[:2]), method='Nelder-Mead', options=dict(xatol=1e-12, fatol=1e-15, maxiter=3000))
        cands.append((-r.fun, (r.x[0], r.x[1], 1-r.x[0]-r.x[1])))
    cands.sort(key=lambda c: -c[0])
    QXv = [q for q in Gin if sum(q) == 1 and min(q) >= 0]
    for qv in QXv:
        for e in range(1, 13):
            for dirn in [E[0], E[1], E[2], U3] + QXv:
                p = tuple(float((1-F(1, 2**e))*qv[i] + F(1, 2**e)*dirn[i]) for i in range(3))
                cands.append((fval(p), p))
    cands.sort(key=lambda c: -c[0])
    for v, p in cands[:6]:
        a_, b_ = fr(p[0], 10**9), fr(p[1], 10**9)
        pi = (a_, b_, 1-a_-b_)
        if min(pi) < 0: continue
        d = sub(moment(Gin + [pi])[1], mX)
        if min(d) > 0: return pi, d
    return None, None

def lp_rep(target, cands):
    """max t s.t. target - sum lam_s s >= t 1, lam >= 0; exact re-verification."""
    if not cands: return None
    k = len(cands)
    c = np.zeros(k+1); c[-1] = -1
    A = [[float(s[i]) for s in cands] + [1.0] for i in range(3)]
    sc_ = max(abs(float(x)) for x in target) + 1
    res = linprog(c, A_ub=np.array(A), b_ub=np.array([float(x) for x in target]),
                  bounds=[(0, None)]*k + [(None, sc_)], method='highs')
    if res.status != 0 or res.x[-1] <= 0: return None
    for d in (10**6, 10**9, 10**12):
        lam = [fr(x, d) if x > 1e-13 else F(0) for x in res.x[:k]]
        resid = sub(target, add(V(0, 0, 0), *[sc(l, s) for l, s in zip(lam, cands)]))
        if min(resid) > 0: return lam, resid
    return None

def near_boundary(QX, pieces, k):
    """exact points of X close to dG = d hull(X): x = y - (P(y) - eps|y|_1) 1, kept if inside a piece."""
    out = []; tries = 0
    while len(out) < k and tries < 100*k:
        tries += 1
        y = tuple(fr(rnd.gauss(0, 1), 1000) for _ in range(3))
        eps = F(1, 10**rnd.randint(1, 12))
        x = sub(y, sc(P_of(QX, y) - eps*sum(abs(c) for c in y), ONE))
        if any(inside(p, x) for p in pieces): out.append(x)
    return out

def near_rays(pieces):
    """exact interior points of pointed pieces arbitrarily close to their extreme rays."""
    out = []
    for p in pieces:
        if not pointed(p): continue
        R = rays(p); c = add(*R)
        for r in R:
            for e in range(2, 14, 2):
                x = add(r, sc(F(1, 10**e), c))
                if inside(p, x): out.append(x)
            for r2 in R:      # near the 2-faces as well
                if r2 == r: continue
                for e in (3, 6, 9, 12):
                    x = add(add(r, r2), sc(F(1, 10**e), c))
                    if inside(p, x): out.append(x)
    return out

HINT = [None]
def gap_points(Nin, pieces, Gin, k=400):
    out = []
    pool = sample_in(Nin, 4*k) + sample_in(Nin, 2*k, conc=True)
    if HINT[0]:
        for hc in HINT[0]: pool = sample_in(hc, 2*k) + sample_in(hc, k, conc=True) + pool
    for h in pool:
        if inside(Nin, h) and all(outside_cl(p, h) for p in pieces): out.append(h)
        if len(out) >= k: break
    return out

def x65(name, pieces, QX, Uin):
    t0 = time.time()
    mX = mX_of(pieces)
    Gin = list(QX)
    P = lambda h: P_of(QX, h)
    pi, d0 = find_pi(Gin, mX)
    if pi is None:
        print("%-34s X65: no strict hull-relative Bayes dominator found by the search (search failure)" % name); return None
    N0 = Gin + [pi]
    xs_all = []
    for p in pieces: xs_all += sample_in(p, 60) + sample_in(p, 60, conc=True)
    xs_all += near_boundary(QX, pieces, 300) + near_rays(pieces)
    stats = dict(tau=0, gaps=0, lpfail=0)
    for tau in [F(1, 10**e) for e in range(1, 13)]:
        Nt = N0 + [add(sc(1-tau, v), sc(tau, E[i])) for v in QX for i in range(3)]
        d = sub(moment(Nt)[1], mX)
        if min(d) <= 0: continue
        stats['tau'] += 1
        for a in gap_points(Nt, pieces, Gin, 60):
            stats['gaps'] += 1
            Pa = P(a); delta = tau*Pa/4
            b = sub(a, sc(Pa-delta, ONE))
            extra = [sub(b, sc(delta*F(1, 2**e), ONE)) for e in range(1, 6)]
            nb = sum(abs(c) for c in b)
            for i in range(3):
                for j in range(3):
                    if i == j: continue
                    for e in range(1, 8):
                        y = add(b, sc(nb*F(1, 2**e), sub(E[i], E[j])))
                        for k in (3, 6, 9, 12):
                            extra.append(sub(y, sc(P(y) - nb*F(1, 10**k), ONE)))
            extra = [x for x in extra if any(inside(p, x) for p in pieces)]
            rep = lp_rep(b, extra + xs_all)
            if rep is None: stats['lpfail'] += 1; continue
            xs_used_pool = extra + xs_all
            lam, pp = rep
            used = [(l, x) for l, x in zip(lam, xs_used_pool) if l > 0]
            if any(not outside_cl(Nt, x) and not inside(Nt, x) for _, x in used): continue
            rem = [x for _, x in used if outside_cl(Nt, x)]
            kept = [x for _, x in used if inside(Nt, x)]
            Qp = polygon_Q(rem)
            mn = min(dot(q, a) for q in Qp)
            pred = Pa - delta/tau
            cert = (min(d) > 0 and inside(Nt, a) and all(outside_cl(p, a) for p in pieces)
                    and all(any(inside(p, x) for p in pieces) for x in rem) and mn > 0)
            print("%-34s X65: margin(N0)=%.2e tau=%s margin(N_tau)=%.2e kept=%d removed=%d "
                  "min_Q' q.a/P(a)=%.4f (proof bound %.2f) CERTIFIED=%s [%.0fs]" %
                  (name, float(min(d0)), tau, float(min(d)), len(kept), len(rem), float(mn/Pa),
                   float(pred/Pa), cert, time.time()-t0))
            return dict(pi=pi, N0=N0, cert=cert)
    print("%-34s X65: no certificate assembled (search failure) %s" % (name, stats)); return None

def h65_step2(name, pieces, QX, pi, qX):
    """H65 Step 2 (lineality cut) on a non-pointed hull, then generation by X points outside N1."""
    mX = mX_of(pieces)
    N0 = list(QX) + [pi]
    xs_all = []
    for p in pieces: xs_all += sample_in(p, 80) + sample_in(p, 80, conc=True)
    xs_all += near_boundary(QX, pieces, 400) + near_rays(pieces)
    for s1 in (F(1, 10), F(1, 100), F(1, 1000), F(1, 10**4), F(1, 10**5)):
        N1 = N0 + [add(sc(1-s1, qX), sc(s1, E[k])) for k in range(3)]
        d1 = sub(moment(N1)[1], mX)
        if min(d1) <= 0: continue
        outs = [x for x in xs_all if outside_cl(N1, x)]
        outs0 = [x for x in xs_all if outside_cl(N0, x)]
        for a in gap_points(N1, pieces, N0, 60):
            rep = lp_rep(a, outs)
            if rep is None: continue
            lam, resid = rep
            used = [x for l, x in zip(lam, outs) if l > 0]
            cert = min(d1) > 0 and inside(N1, a) and all(outside_cl(p, a) for p in pieces) and min(resid) > 0
            rep0 = lp_rep(a, outs0)
            print("%-34s H65 Step 2: s1=%s margin(N1)=%.2e  a generated by %d X-points outside cl N1, "
                  "CERTIFIED=%s  (same a from points outside cl N0 only: %s)" %
                  (name, s1, float(min(d1)), len(used), cert, "yes" if rep0 else "no"))
            return cert
    print("%-34s H65 Step 2: no certificate assembled (search failure)" % name)

# ---------------------------------------------------------------- rivals
def tri(rho): return [add(sc(1-rho, U3), sc(rho, E[i])) for i in range(3)]

# pointed setting: K' = conv{(1-rho)u + rho e_i}, rho = 1/5
KP = tri(F(1, 5)); UP = list(KP)
KD = tri(F(1, 2)); D = KD + UP          # D_{Kd}, Kd > K'
v1 = KD[0]; s_ = add(E[1], E[2]); l_ = sub(E[1], E[2])

def spike(w):
    return UP + [neg(v1), add(l_, sc(w, s_)), add(neg(l_), sc(w, s_))]
def notch(depth, lat_lo, lat_hi, face=0):
    v = KD[face]; i, j = [k for k in range(3) if k != face]
    s = add(E[i], E[j]); l = sub(E[i], E[j])
    # inside D, within 'depth' of face F_v, lateral offset in (lat_lo, lat_hi)
    return [sub(sc(depth, s), v), sub(l, sc(lat_lo, s)), add(neg(l), sc(lat_hi, s))]

def QX_of(pieces):
    R = []
    for p in pieces: R += rays(p)
    return polygon_Q(R + list(E))

rivals = []
X = [D, spike(F(1, 40))]
rivals.append(("R1 spike to dU (w=1/40)", X, QX_of(X), UP))
X = [D, spike(F(1, 400))]
rivals.append(("R1' needle spike to dU (w=1/400)", X, QX_of(X), UP))
X = minus_cone([D], notch(F(1, 20), F(-1, 10), F(1, 10)))
rivals.append(("R2 notch at dD (mid-face)", X, QX_of(X), UP, [D + notch(F(1, 20), F(-1, 10), F(1, 10))]))
X = [D]
for f in range(3):
    for (lo, hi) in ((F(-7, 10), F(-6, 10)), (F(-1, 20), F(1, 20)), (F(6, 10), F(7, 10))):
        X = minus_cone(X, notch(F(1, 200), lo, hi, f))
rivals.append(("R5 comb: 9 shallow notches at dD", X, QX_of(X), UP))

# non-pointed settings
UH = [U3]                                   # K' = {u}: U a half-space
H = simplicial([V(2, 2, -1), V(3, 1, -1), V(2, 2, F(-3, 2))])
X = minus_cone([UH], H)
rivals.append(("R3 half-space minus interior hole", X, [U3], UH, [H]))
H1 = simplicial([V(1, -1, 0), V(2, 1, -1), V(3, -1, -1)])
H2 = simplicial([V(0, 1, -1), V(-1, 2, 1), V(-1, 3, -1)])
X = minus_cone(minus_cone([UH], H1), H2)
rivals.append(("R4 half-space minus 2 holes at dU", X, [U3], UH))
KS = [V(F(1, 2), F(1, 4), F(1, 4)), V(F(1, 4), F(1, 2), F(1, 4))]   # segment: lineality (-1,-1,3)
H = simplicial([V(2, 2, -1), V(3, 1, -1), V(2, 3, -2)])
X = minus_cone([list(KS)], H)
rivals.append(("R6 wedge (K' segment) minus hole", X, list(KS), list(KS), [H]))

if __name__ == "__main__":
    for rv in rivals:
        name, pieces, QX, Uin = rv[:4]
        HINT[0] = rv[4] if len(rv) > 4 else None
        assert all(moment(p)[0] > 0 for p in pieces)
        res = x65(name, pieces, QX, Uin)
        if res and len(QX) <= 2:            # non-pointed hull: also run H65 Step 2
            qX = add(*QX)
            qX = sc(1/sum(qX), qX)
            h65_step2(name, pieces, QX, res['pi'], qX)
