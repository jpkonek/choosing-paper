"""REF65_hB: adversarial exact test of X65 Theorem H.1, Steps 4-5 (the inequality chain).

For random credal Q_X (polygon in Delta, possibly touching the boundary of Delta), random pi,
tau (down to 1e-6), a in N_tau, delta in (0, tau P(a)/2), b := a - (P(a)-delta) 1, and
ADVERSARIAL representations b = sum lam_j x_j + p' with x_j in cl G (P(x_j) >= 0), chosen to
(i) put x_j near dG with very negative coordinates and (ii) push sum lam_j P(x_j) up to delta:
  kept    := x_j in N_tau (open),  removed := the rest,
  Q'      := {q in Delta : q.x_j >= 0 for removed j}   (a superset of Q_B by Claim 0),
and we verify EXACTLY:  min_{q in Q'} q.a  >=  P(a) - delta/tau  >  P(a)/2.
Also: control with tau := 0 (no shrink, N_0 only), showing the bound genuinely needs the shrink.
"""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geo3 import *

rnd = random.Random(65)
def rq():
    x = [F(rnd.randint(1, 60)) for _ in range(3)]; s = sum(x); return tuple(c/s for c in x)
def rbd():  # random point of the boundary of Delta (adversarial: Q_X touching dDelta)
    i = rnd.randrange(3); t = F(rnd.randint(0, 50), 50)
    v = [F(0)]*3; v[(i+1) % 3] = t; v[(i+2) % 3] = 1-t; return tuple(v)

def hull_pts(pts):
    """vertices of conv(pts) in the plane sum=1 (exact; gift wrapping via clipping is overkill)"""
    # use Delta clipped by all supporting lines through pairs: simple O(k^3) exact hull
    ver = []
    for p in pts:
        others = [q for q in pts if q != p]
        # p is a vertex iff it is not in conv(others): test by LP-free check on triangles
        inside_some = False
        for i in range(len(others)):
            for j in range(i+1, len(others)):
                for k in range(j+1, len(others)):
                    A_, B_, C_ = others[i], others[j], others[k]
                    d = det3(A_, B_, C_)
                    if d == 0: continue
                    # barycentric coords of p (all in plane sum=1 -> det formula)
                    la = det3(p, B_, C_)/d; lb = det3(A_, p, C_)/d; lc = det3(A_, B_, p)/d
                    if la >= 0 and lb >= 0 and lc >= 0: inside_some = True; break
                if inside_some: break
            if inside_some: break
        if not inside_some and p not in ver: ver.append(p)
    return ver

def run(trials=4000, tau0=False):
    """Representation first: kept x_j are pushed to the edge of N_tau (Q_tau(x) tiny, so the most
    negative coordinate allowed), removed x_j sit near dG with huge negative coordinates; then
    b0 := sum lam_j x_j + p', delta := P(b0), a := b0 + (P(a)-delta) 1 with P(a) chosen so that
    delta < tau P(a)/2 as tightly as allowed."""
    worst = None; fails = 0; nkept = 0; nrem = 0; done = 0
    for t in range(trials):
        pts = [rq() for _ in range(rnd.randint(1, 4))] + ([rbd()] if rnd.random() < 0.4 else [])
        QX = hull_pts(pts) or pts
        P = lambda h: P_of(QX, h)
        pi = rq() if rnd.random() < 0.7 else rbd()
        tau = F(0) if tau0 else rnd.choice([F(1, 2), F(1, 10), F(1, 100), F(1, 10**4), F(1, 10**6)])
        Qtau = lambda h: (1-tau)*P(h) + tau*min(h)
        inN = lambda h: P(h) > 0 and dot(pi, h) > 0 and Qtau(h) > 0
        xs = []
        for _ in range(rnd.randint(1, 6)):
            y = tuple(F(rnd.randint(-10**3, 10**3), rnd.randint(1, 7)) for _ in range(3))
            eps = F(rnd.randint(1, 5), 10**rnd.randint(0, 8))
            x = sub(y, sc(P(y)-eps, ONE))            # P(x) = eps > 0, x near dG
            if rnd.random() < 0.6 and not tau0:
                # push x to the edge of D_{Q_tau}: choose eps so that Q_tau(x) = tiny > 0
                m = min(x) - P(x)                   # min(x) = P(x) + m, m <= 0
                if m < 0:
                    tiny = F(1, 10**rnd.randint(3, 12))
                    # (1-tau) e + tau (e + m) = tiny  ->  e = (tiny - tau m)
                    e = tiny - tau*m
                    x = sub(y, sc(P(y)-e, ONE))
            xs.append(x)
        lam = [F(rnd.randint(1, 9), rnd.randint(1, 9)) for _ in xs]
        pprime = tuple(F(1, 10**rnd.randint(0, 9)) * F(rnd.randint(1, 9)) for _ in range(3))
        b0 = add(add(*[sc(l, x) for l, x in zip(lam, xs)]), pprime)
        delta = P(b0)
        assert delta > 0
        if tau0:
            Pa = 2*delta*F(rnd.randint(101, 400), 100)
        else:
            Pa = 2*delta/tau*F(rnd.randint(1001, 1100), 1000)   # delta < tau P(a)/2, nearly tight
        a = add(b0, sc(Pa-delta, ONE))
        assert P(a) == Pa
        if not inN(a): continue
        rem = [x for x in xs if not inN(x)]
        kept = [x for x in xs if inN(x)]
        nkept += len(kept); nrem += len(rem)
        Qp = polygon_Q(rem)
        assert Qp, "Q' empty (impossible: contains Q_X)"
        mn = min(dot(q, a) for q in Qp)
        done += 1
        if tau0:
            ok = mn > 0
        else:
            ok = (mn >= Pa - delta/tau) and (Pa - delta/tau > Pa/2) and mn > 0
            assert sum(l*P(x) for l, x in zip(lam, xs)) < delta
        if not ok: fails += 1
        r = mn/Pa
        if worst is None or r < worst[0]: worst = (r, len(kept), len(rem), tau)
    return done, fails, nkept, nrem, worst

d, f, k, r, wst = run()
print("X65 Steps 4-5, tau > 0: %d adversarial instances, %d failures of  min_{Q'} q.a >= P(a)-delta/tau > P(a)/2 ;"
      " kept points %d, removed %d; worst min_{Q'} q.a / P(a) = %s (kept=%d, removed=%d, tau=%s)" %
      (d, f, k, r, float(wst[0]), wst[1], wst[2], wst[3]))
d, f, k, r, wst = run(tau0=True)
print("CONTROL tau = 0 (no shrink, N = N_0): %d instances, %d with min_{Q'} q.a <= 0 (no certificate from this"
      " representation); worst ratio %.4g  -> the shrink is what makes Step 5 work." % (d, f, float(wst[0])))
