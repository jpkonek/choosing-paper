"""REF65_hB: polar scan for strict hull-relative Bayes dominators on the single-notch rivals where
e2e_random's generic search failed (#01, #13, #17, #29).  Search aid; every hit re-checked exactly,
then the X65 certificate is assembled exactly by e2e.x65 starting from that pi."""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'e2e_random.py')).read()
src = src.replace("    r = x65(", "    RIV.append((t,name,X,QX,hint)); r=None and x65(")
src = src.replace('print("certified', '0 and print("certified')
RIV = []
g = {'__file__': os.path.join(os.path.dirname(os.path.abspath(__file__)), 'e2e_random.py'), 'RIV': RIV}
exec(compile(src, 'e2e_random', 'exec'), g)
import e2e
from e2e import *
w1 = (1/math.sqrt(2), -1/math.sqrt(2), 0.0); w2 = (1/math.sqrt(6), 1/math.sqrt(6), -2/math.sqrt(6))
for (t, name, X, QX, hint) in RIV:
    if t not in (1, 13, 17, 29): continue
    mX = mX_of(X); mXf = [float(x) for x in mX]; Gf = fl(QX)
    def fval(p):
        d = moment(Gf + [tuple(p)], 1.0, 0.0)[1]; return min(d[i]-mXf[i] for i in range(3))
    print("#%02d %s: m(hull)-m(X) =" % (t, name), [float(x) for x in sub(moment(list(QX))[1], mX)])
    best = None
    for qv in QX:
        qf = [float(c) for c in qv]
        for e in range(4, 60):
            r = 10**(-e/8)
            for k in range(720):
                th = 2*math.pi*k/720
                p = tuple(qf[i] + r*(math.cos(th)*w1[i] + math.sin(th)*w2[i]) for i in range(3))
                if min(p) < 0: continue
                v = fval(p)
                if best is None or v > best[0]: best = (v, p)
    print("    best float margin found: %.3e at pi=%s" % (best[0], tuple(round(c, 9) for c in best[1])))
    if best[0] > 0:
        a_, b_ = fr(best[1][0], 10**12), fr(best[1][1], 10**12); pi = (a_, b_, 1-a_-b_)
        d = sub(moment(list(QX) + [pi])[1], mX)
        print("    exact margin of hull(X) n {pi.h>0}:", [float(x) for x in d], min(d) > 0)
