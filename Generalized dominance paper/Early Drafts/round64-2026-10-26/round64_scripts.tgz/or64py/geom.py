"""OR64 exact geometry checks for the reversed triangle K = {m in Delta_3 : m_i <= 2/5}.
All arithmetic is exact (fractions.Fraction). Run: python3 -I geom.py > geom.out
"""
from fractions import Fraction as Fr

def dot(a, b): return sum(x*y for x, y in zip(a, b))
def add(a, b): return tuple(x+y for x, y in zip(a, b))
def sc(t, a): return tuple(t*x for x in a)
def sub(a, b): return tuple(x-y for x, y in zip(a, b))
def sgn(x): return '+' if x > 0 else ('-' if x < 0 else '0')

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok = ok and cond

one = (Fr(1),)*3
e = [tuple(Fr(int(i == j)) for j in range(3)) for i in range(3)]
v = [tuple(Fr(1, 5) if j == i else Fr(2, 5) for j in range(3)) for i in range(3)]   # vertices of K
r = [sub(sc(2, one), sc(5, e[j])) for j in range(3)]                                  # rays of D_K
print("§1 vertices v_k:", v)
print("   rays r_j:", r)
check("v_k . r_j = delta_kj", all(dot(v[k], r[j]) == (1 if k == j else 0) for k in range(3) for j in range(3)))
check("v_1+v_2+v_3 = 1", add(add(v[0], v[1]), v[2]) == one)
check("each v_k in K (coords <= 2/5, sum 1)", all(sum(x) == 1 and max(x) <= Fr(2, 5) for x in v))

# faces F_k = cone(r_i, r_j), {i,j,k} = {1,2,3}; h_k > 0 on F_k; h_i, h_j change sign
print("§2 faces")
for k in range(3):
    i, j = [x for x in range(3) if x != k]
    ok_k = all(add(sc(s, r[i]), sc(1 - s, r[j]))[k] > 0 for s in [Fr(n, 20) for n in range(21)])
    check(f"h_{k+1} > 0 on F_{k+1} (sampled exactly at 21 points incl. ends)", ok_k)
    # crossing points
    for w in (i, j):
        # solve (s r_i + (1-s) r_j)_w = 0
        a, b = r[i][w], r[j][w]
        s = b / (b - a)
        p = add(sc(s, r[i]), sc(1 - s, r[j]))
        check(f"F_{k+1} crosses h_{w+1}=0 in its relative interior at s={s}", 0 < s < 1 and p[w] == 0)

print("§3 face midpoints and collar centres")
m = [add(r[i], r[j]) for k in range(3) for (i, j) in [tuple(x for x in range(3) if x != k)]]
print("   m_k:", m, " signs:", [''.join(sgn(x) for x in mk) for mk in m])
check("sum m_k = (2,2,2)", add(add(m[0], m[1]), m[2]) == sc(2, one))
for delta in [Fr(1, 10), Fr(1, 100)]:
    c = [sub(m[k], sc(delta, v[k])) for k in range(3)]
    check(f"delta={delta}: v_k.c_k < 0 and v_l.c_k > 0 (l != k): c_k beyond F_k only",
          all(dot(v[k], c[k]) < 0 and all(dot(v[l], c[k]) > 0 for l in range(3) if l != k) for k in range(3)))
    check(f"delta={delta}: sum c_k = (2 - delta)(1,1,1)", add(add(c[0], c[1]), c[2]) == sc(2 - delta, one))
    print("   signs of c_k:", [''.join(sgn(x) for x in ck) for ck in c])

print("§4 exact witness for the collar-hull step (E61 Lemma 3.4 geometry; used in OR64 Lemma OC)")
# i = 1 (index 0), j = 2 (index 1).  F_{v_1} = cone(r_2, r_3).
i, j = 0, 1
p = add(r[1], sc(Fr(1, 4), r[2]))        # point of relint F_{v_1} with p_2 < 0
b = add(r[2], sc(Fr(1, 4), r[1]))        # point of relint F_{v_1} with b_2 > 0
eta = Fr(1, 10); delta = Fr(1, 1000)
B = sub(b, sc(eta, v[i]))
x = sub(p, sc(delta, v[i]))
t = 2*delta/eta
A = sc(1/(1 - t), sub(x, sc(t, B)))
print("   p =", p, " b =", b)
print("   B =", B, " x =", x, " t =", t)
print("   A =", A)
check("p, b in relint F_{v_1}: v_1.p = v_1.b = 0, v_2,v_3 > 0", dot(v[0], p) == 0 == dot(v[0], b)
      and all(dot(v[l], p) > 0 and dot(v[l], b) > 0 for l in (1, 2)))
check("p_2 < 0 < b_2", p[1] < 0 < b[1])
check("x is beyond F_{v_1}: v_1.x < 0, v_2.x > 0, v_3.x > 0", dot(v[0], x) < 0 and dot(v[1], x) > 0 and dot(v[2], x) > 0)
check("x is j-wrong and i-correct: x_2 < 0 < x_1", x[1] < 0 < x[0])
check("B in {h_1>0, h_2>0} and beyond F_{v_1}", B[0] > 0 and B[1] > 0 and dot(v[0], B) < 0)
check("A in D_K and A_1 > 0", all(dot(v[l], A) > 0 for l in range(3)) and A[0] > 0)
check("x = (1-t)A + tB exactly", add(sc(1 - t, A), sc(t, B)) == x)
# membership of x, B in the explicit one-sided domain U = D_{K'}, K' = (u + K)/2
u = (Fr(1, 3),)*3
Kp = [sc(Fr(1, 2), add(u, vk)) for vk in v]
check("x, B, A in U = D_{K'} with K' = (u+K)/2 (vertices of K')", all(dot(q, y) > 0 for q in Kp for y in (x, B, A)))
print("ALL PASS" if ok else "SOME FAIL")
