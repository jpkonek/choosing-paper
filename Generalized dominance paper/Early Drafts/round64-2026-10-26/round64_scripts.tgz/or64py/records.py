"""OR64: finite-atom checks of the record calculus, of counter-model M1 (E61 box lemma fails
under (TC) for E61's priority regions) and of the diagnostic relation T (toward-the-target).

Atom models are the exact finite analogue of the measure-theoretic constructions in OR64_notes.md:
each atom stands for a non-null measurable cell with a fixed sign pattern; models are unions of atoms;
a relation is defined on records (X \\ Y, Y \\ X), so (IB) holds by construction (also re-tested).
The measure-theoretic proofs in the notes do not depend on these checks; they guard against slips.
Run: python3 -I records.py > records.out
"""
import itertools, random

ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    ok = ok and bool(cond)

class System:
    def __init__(self, atoms):
        # atoms: list of (name, signs (3-tuple of +1/-1), tags set)
        self.atoms = atoms
        self.n = len(atoms)
        self.full = (1 << self.n) - 1
        self.pos = [sum(1 << a for a, (_, s, _) in enumerate(atoms) if s[w] > 0) for w in range(3)]
        self.neg = [sum(1 << a for a, (_, s, _) in enumerate(atoms) if s[w] < 0) for w in range(3)]
        self.acc = None  # function (w, p, n) -> bool
    def mask(self, *names):
        return sum(1 << a for a, (nm, _, _) in enumerate(self.atoms) if nm in names)
    def tagged(self, tag):
        return sum(1 << a for a, (_, _, t) in enumerate(self.atoms) if tag in t)
    def guided(self, w, p, n):
        return (p & ~self.pos[w]) == 0 and (n & ~self.neg[w]) == 0
    def anti(self, w, p, n):
        return (p | n) != 0 and self.guided(w, n, p)
    def le(self, w, X, Y):           # X <=_w Y  (X no worse than Y at w)
        return self.acc(w, X & ~Y, Y & ~X)
    def lt(self, w, X, Y):
        return self.le(w, X, Y) and not self.le(w, Y, X)
    def names(self, X):
        return '{' + ','.join(nm for a, (nm, _, _) in enumerate(self.atoms) if X >> a & 1) + '}'

    def check_axioms(self, label):
        N = self.full + 1
        refl = all(self.le(w, X, X) for w in range(3) for X in range(N))
        check(f"{label}: reflexive", refl)
        sg = True
        for w in range(3):
            for X in range(N):
                for Y in range(N):
                    if X != Y and self.guided(w, X & ~Y, Y & ~X):
                        if not (self.le(w, X, Y) and not self.le(w, Y, X)):
                            sg = False
        check(f"{label}: strict (G) at every world", sg)
        # (TC): A<=B, B<=C  =>  not (C < A)
        tc = True; nontrans = 0; witness = None
        for w in range(3):
            up = [[Y for Y in range(N) if self.le(w, X, Y)] for X in range(N)]
            for A in range(N):
                for B in up[A]:
                    for C in up[B]:
                        if self.lt(w, C, A):
                            tc = False
                        if not self.le(w, A, C):
                            nontrans += 1
                            if witness is None: witness = (w, A, B, C)
        check(f"{label}: (TC) at every world (exhaustive over all triples)", tc)
        print(f"   {label}: number of chains A<=B<=C with A not<= C (non-transitive instances): {nontrans}")
        if witness:
            w, A, B, C = witness
            print(f"   e.g. world {w+1}: A={self.names(A)} <= B={self.names(B)} <= C={self.names(C)}, A,C incomparable:",
                  not self.le(w, A, C) and not self.le(w, C, A))
        # (IB), W62 form, random test
        rng = random.Random(1)
        ib = True
        for _ in range(20000):
            S = rng.randrange(N)
            base1, base2 = rng.randrange(N) & ~S, rng.randrange(N) & ~S
            XS, YS = rng.randrange(N) & S, rng.randrange(N) & S
            X, Y, X2, Y2 = base1 | XS, base1 | YS, base2 | XS, base2 | YS
            for w in range(3):
                if self.le(w, X, Y) != self.le(w, X2, Y2): ib = False
        check(f"{label}: (IB) in the W62 form (20000 random instances)", ib)

    def dominates(self, Y, X):
        return all(self.le(w, Y, X) for w in range(3)) and any(self.lt(w, Y, X) for w in range(3))

# ---------------------------------------------------------------- record composition
print("§0 record composition formula and commutativity")
def comp(r1, r2):
    (P1, N1), (P2, N2) = r1, r2
    return ((P1 & ~N2) | (P2 & ~N1), (N1 & ~P2) | (N2 & ~P1))
rng = random.Random(0)
good = True; commut = True
for _ in range(100000):
    A, B, C = rng.randrange(256), rng.randrange(256), rng.randrange(256)
    r1 = (A & ~B, B & ~A); r2 = (B & ~C, C & ~B)
    if comp(r1, r2) != (A & ~C, C & ~A): good = False
    if comp(r1, r2) != comp(r2, r1): commut = False
    if (r1[0] & r2[0]) or (r1[1] & r2[1]): good = False   # composability is automatic
check("rec(A,C) = rec(A,B) o rec(B,C), with P1&P2 = N1&N2 = 0 (100000 random triples, 8 atoms)", good)
check("composition is commutative", commut)

# ---------------------------------------------------------------- M1
print("§1 counter-model M1: E61 priority region at j, box model X_i dominated, (TC) holds")
# worlds: index 0 = i, 1 = j, 2 = k
M1 = System([
    ('E',  (+1, -1, +1), {'R'}),
    ('A',  (-1, +1, +1), set()),
    ('B',  (+1, +1, -1), set()),
    ('R2', (-1, -1, +1), {'R'}),
    ('P',  (+1, +1, +1), set()),
    ('D',  (+1, -1, -1), set()),
    ('E2', (+1, -1, +1), set()),
    ('F',  (-1, +1, -1), set()),
])
r0 = (M1.mask('E', 'A'), M1.mask('B'))
def accM1(w, p, n):
    if M1.guided(w, p, n): return True
    return w in (0, 1) and (p, n) == r0
M1.acc = accM1
M1.check_axioms("M1")
R = M1.tagged('R')
MR = (M1.full & ~R) & M1.neg[1]
Xi = (M1.full & ~R) & M1.pos[0]
Y0 = (Xi & ~M1.mask('B')) | M1.mask('E', 'A')
print("   R =", M1.names(R), " M_R =", M1.names(MR), " X_i =", M1.names(Xi), " Y0 =", M1.names(Y0))
check("R is a priority region at j in E61's sense: no Y meeting R has Y <=_j M_R",
      all(not M1.le(1, Y, MR) for Y in range(M1.full + 1) if Y & R))
check("Y0 meets R", Y0 & R != 0)
check("Y0 <=_i X_i, Y0 <=_j X_i, Y0 <_k X_i: Y0 dominates X_i (box lemma conclusion fails)",
      M1.le(0, Y0, Xi) and M1.le(1, Y0, Xi) and M1.lt(2, Y0, Xi) and M1.dominates(Y0, Xi))
check("X_i <=_j M_R (weak guidance) and Y0, M_R incomparable at j",
      M1.le(1, Xi, MR) and not M1.le(1, Y0, MR) and not M1.le(1, MR, Y0))
check("R is not a strong priority region at j (Y0 meets R, X_i avoids R, Y0 <=_j X_i)", M1.le(1, Y0, Xi))
check("R is not a strict priority region at j (not M_R <_j Y0)", not M1.lt(1, MR, Y0))
check("M1 is not transitive at j: Y0 <=_j X_i <=_j M_R but not Y0 <=_j M_R",
      M1.le(1, Y0, Xi) and M1.le(1, Xi, MR) and not M1.le(1, Y0, MR))

print("§1b (TC) is needed for the strict-priority repair: M1 plus the records M_R <=_j Y (Y meeting R)")
SM1 = {(MR & ~Y, Y & ~MR) for Y in range(M1.full + 1) if Y & R}
def accM1b(w, p, n):
    return accM1(w, p, n) or (w == 1 and (p, n) in SM1)
M1.acc = accM1b
check("M1b: R is a strict priority region at j (M_R <_j Y for every Y meeting R)",
      all(M1.lt(1, MR, Y) for Y in range(M1.full + 1) if Y & R))
check("M1b: X_i is still dominated by Y0", M1.dominates(Y0, Xi))
check("M1b: (TC) fails at j on the chain Y0 <=_j X_i <=_j M_R with M_R <_j Y0",
      M1.le(1, Y0, Xi) and M1.le(1, Xi, MR) and M1.lt(1, MR, Y0))
M1.acc = accM1

# ---------------------------------------------------------------- strict-priority repair, exhaustive on M1-like systems
print("§2 strict priority + (TC) => box lemma: random non-transitive systems containing the strict-priority records")
# Acc_j = G_j  u  S  u  X_j,  Acc_i = G_i u X_i,  Acc_k = G_k, where S = {rec(M_R, Y) : Y meets R} makes M_R <=_j Y
# for every Y meeting R, and X_j, X_i are 1-3 random extra records.  Systems failing strict (G) or (TC) are discarded.
small = System([
    ('E', (+1, -1, +1), {'R'}),
    ('A', (-1, +1, +1), set()),
    ('B', (+1, +1, -1), set()),
    ('P', (+1, +1, +1), set()),
    ('D', (+1, -1, -1), set()),
])
N = 32
Rs = small.tagged('R'); MRs = (small.full & ~Rs) & small.neg[1]; Xis = (small.full & ~Rs) & small.pos[0]
Srec = {(MRs & ~Y, Y & ~MRs) for Y in range(N) if Y & Rs}
recs = [(p, n) for p in range(N) for n in range(N) if p & n == 0]
extra = {0: set(), 1: set()}
def acc_small(w, p, n):
    if small.guided(w, p, n): return True
    if w == 1 and (p, n) in Srec: return True
    return (p, n) in extra.get(w, ())
small.acc = acc_small
def sys_ok():
    for w in range(3):
        for X in range(N):
            for Y in range(N):
                if X != Y and small.guided(w, X & ~Y, Y & ~X) and not (small.le(w, X, Y) and not small.le(w, Y, X)):
                    return False
        up = [[Y for Y in range(N) if small.le(w, X, Y)] for X in range(N)]
        for A in range(N):
            for B in up[A]:
                for C in up[B]:
                    if small.lt(w, C, A): return False
    return True
rng2 = random.Random(5)
tested = good_sys = nprio = viol = nontrans_sys = 0
for _ in range(1500):
    extra = {0: set(rng2.sample(recs, rng2.randint(1, 3))), 1: set(rng2.sample(recs, rng2.randint(1, 3)))}
    tested += 1
    if not sys_ok(): continue
    good_sys += 1
    if all(small.lt(1, MRs, Y) for Y in range(N) if Y & Rs):
        nprio += 1
        if any(not small.le(1, A, C) for A in range(N) for B in range(N) if small.le(1, A, B)
               for C in range(N) if small.le(1, B, C)):
            nontrans_sys += 1
        if any(small.dominates(Y, Xis) for Y in range(N)): viol += 1
print(f"   sampled: {tested}; reflexive + strict (G) + (TC): {good_sys}; with R strict priority at j: {nprio}; "
      f"of these non-transitive at j: {nontrans_sys}")
check("in every such system with R a strict priority region at j, the box model X_i is undominated", viol == 0 and nprio > 0)

# ---------------------------------------------------------------- diagnostic relation T
print("§3 diagnostic relation T (guidance plus 'toward the target' records not anti-guided at w)")
T = System([
    ('I0', (+1, +1, +1), {'IN'}),
    ('I1', (-1, +1, +1), {'IN'}),
    ('I2', (+1, -1, +1), {'IN'}),
    ('I3', (+1, +1, -1), {'IN'}),
    ('O1', (+1, -1, -1), {'OUT'}),
    ('O2', (-1, +1, -1), {'OUT'}),
    ('O3', (-1, -1, +1), {'OUT'}),
    ('O4', (+1, +1, -1), {'OUT'}),
    ('O5', (-1, +1, +1), {'OUT'}),
])
IN, OUT = T.tagged('IN'), T.tagged('OUT')
def accT(w, p, n):
    if T.guided(w, p, n): return True
    return (p & ~IN) == 0 and (n & ~OUT) == 0 and not T.anti(w, p, n) and (p | n) != 0
T.acc = accT
T.check_axioms("T")
DK = IN
NM = T.full + 1
undom = [X for X in range(NM) if not any(T.dominates(Y, X) for Y in range(NM))]
I_set = [X for X in range(NM) if any(T.guided(w, X & ~DK, DK & ~X) for w in range(3))]
check("D_K undominated", DK in undom)
check("undominated models = D_K together with the one-world improvements of D_K", sorted(undom) == sorted(I_set))
print(f"   |models| = {NM}, |undominated| = {len(undom)}")
check("every model that is not pointwise at least as good as D_K at some world is strictly dominated by D_K",
      all(all(T.lt(w, DK, X) for w in range(3)) for X in range(NM) if X not in I_set))
collar = [P for P in range(1, NM) if (P & ~OUT) == 0 and all(P & T.neg[w] for w in range(3))]
check(f"all {len(collar)} collar additions P (P outside D_K, wrong somewhere at every world): "
      "no world accepts D_K u P <= D_K, and D_K strictly dominates D_K u P",
      all(not T.le(w, DK | P, DK) for w in range(3) for P in collar) and all(T.dominates(DK, DK | P) for P in collar))
# Lemma T (target transfer): no dominance pair has a record moving away from D_K
away_dom = 0
for X in range(NM):
    for Y in range(NM):
        if T.dominates(Y, X):
            A, Nn = Y & ~X, X & ~Y
            if (A & IN) == 0 and (Nn & OUT) == 0: away_dom += 1
check("Lemma T instance: no dominance record moves away from D_K", away_dom == 0)
print("ALL PASS" if ok else "SOME FAIL")
