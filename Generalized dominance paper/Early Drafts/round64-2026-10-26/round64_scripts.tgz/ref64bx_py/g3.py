# Exact 3-world geometry helpers (Fractions only). Written for REF64_bx.
from fractions import Fraction as Fr
import itertools, random

E = [(Fr(1),Fr(0),Fr(0)),(Fr(0),Fr(1),Fr(0)),(Fr(0),Fr(0),Fr(1))]
ONE = (Fr(1),Fr(1),Fr(1))

def v(*a): return tuple(Fr(x) for x in a)
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def add(a,b): return tuple(x+y for x,y in zip(a,b))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def sc(t,a): return tuple(t*x for x in a)
def had(a,b): return tuple(x*y for x,y in zip(a,b))
def nu(w):
    s = sum(w); assert s > 0
    return tuple(x/s for x in w)
def cross(a,b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def prim(g):
    # scale to primitive integer vector (for display)
    from math import gcd
    den = 1
    for x in g: den = den*x.denominator//gcd(den,x.denominator)
    ints = [int(x*den) for x in g]
    gg = 0
    for x in ints: gg = gcd(gg, abs(x))
    return tuple(i//gg for i in ints) if gg else tuple(ints)

def hull2(points):
    """Exact convex hull of points in aff Delta_3 (use coords (m1,m2)); returns vertices CCW, no collinear."""
    pts = sorted(set(points), key=lambda m:(m[0],m[1]))
    if len(pts) <= 1: return pts
    def cr(o,a,b): return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    lower=[]
    for p in pts:
        while len(lower)>=2 and cr(lower[-2],lower[-1],p) <= 0: lower.pop()
        lower.append(p)
    upper=[]
    for p in reversed(pts):
        while len(upper)>=2 and cr(upper[-2],upper[-1],p) <= 0: upper.pop()
        upper.append(p)
    return lower[:-1]+upper[:-1]

def edges_normals(V):
    """V: hull vertices (cyclic). Returns list of (a,b,g) with inward homogeneous normal g (g.a=g.b=0, g.m>=0 on K)."""
    out=[]
    k=len(V)
    if k < 3: return out
    cen = tuple(sum(x[i] for x in V)/k for i in range(3))
    for i in range(k):
        a,b = V[i],V[(i+1)%k]
        g = cross(a,b)
        if dot(g,cen) < 0: g = sc(-1,g)
        out.append((a,b,g))
    return out

def vertex_types(V):
    """World types at each vertex of polygon V via Lemma 4.13 (poly): S visible, T tangential, A anti-visible, C crossing."""
    en = edges_normals(V)
    res={}
    for x in V:
        act=[g for (a,b,g) in en if dot(g,x)==0]
        t=''
        for j in range(3):
            cs=[g[j] for g in act]
            if all(c<0 for c in cs): t+='S'
            elif all(c<=0 for c in cs): t+='T'
            elif all(c>=0 for c in cs): t+='A'
            else: t+='C'
        res[x]=t
    return res

def bary(T,x):
    # barycentric coords of x in triangle T (3 vertices), solve 3x3
    import sympy
    M = sympy.Matrix([[T[0][i],T[1][i],T[2][i]] for i in range(3)])
    sol = M.LUsolve(sympy.Matrix([x[0],x[1],x[2]]))
    return tuple(Fr(str(s)) for s in sol)

def visible_def(V, x, j):
    """Definition 4.11(a): open ray x+s(x-e_j) meets relint K, for triangle V (polygon: test with small s via all facet normals)."""
    en = edges_normals(V)
    d = sub(x, E[j])
    # x + s d in relint K for small s>0 iff for every active g: g.d > 0 (inactive ones stay positive)
    act=[g for (a,b,g) in en if dot(g,x)==0]
    return all(dot(g,d) > 0 for g in act)

def is_cevian(g): return any(c==0 for c in g)

def rand_simplex_pt(rng, den=60, interior=True):
    while True:
        a = rng.randint(1,den-2); b = rng.randint(1,den-1-a); c = den-a-b
        if c>=1 or not interior:
            return (Fr(a,den),Fr(b,den),Fr(c,den))
