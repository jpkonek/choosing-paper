# REF64_bx: Lemma 6.5, Corollary 6.6 (<=), open problem (4) test triangles, Example 7.17, Theorem 7.16(d).
import sys, random, itertools
sys.path.insert(0,'.')
from g3 import *
out=[]
def P(*a): out.append(' '.join(str(x) for x in a))
rng=random.Random(6406)

# ---- Lemma 6.5(a),(c): random boxes in n=3
cnt={}; tri=0; noncev=0; amem=0
for it in range(3000):
    ndeg=it%4
    lo=[];hi=[]
    degs=set(rng.sample(range(3),ndeg))
    for j in range(3):
        a=Fr(rng.randint(1,30),rng.randint(1,9))
        b=a if j in degs else a+Fr(rng.randint(1,30),rng.randint(1,9))
        lo.append(a);hi.append(b)
    corners=[nu(tuple(c)) for c in itertools.product(*[(lo[j],hi[j]) for j in range(3)])]
    Hh=hull2(corners)
    cnt[(ndeg,len(Hh))]=cnt.get((ndeg,len(Hh)),0)+1
    if len(Hh)==3: tri+=1
    if len(Hh)>=3:
        for a,b,g in edges_normals(Hh):
            if not is_cevian(g): noncev+=1
    elif len(Hh)==2:
        g=cross(Hh[0],Hh[1])
        if not is_cevian(g): noncev+=1
    # (a): random m in Delta: m in nu(R) iff inequalities
    for _ in range(5):
        m=rand_simplex_pt(rng,97)
        ineq=all(lo[i]*m[j]<=hi[j]*m[i] for i in range(3) for j in range(3) if i!=j)
        # membership by LP-free test: t exists with lo<=t m<=hi
        tlo=max(lo[j]/m[j] for j in range(3)); thi=min(hi[j]/m[j] for j in range(3))
        if ineq != (tlo<=thi): amem+=1
P('Lemma 6.5 boxes: (degenerate coords, hull vertex count) ->',sorted(cnt.items()))
P('  triangles:',tri,' non-cevian edges:',noncev,' (a) membership mismatches:',amem)

# ---- Lemma 6.5(b): random cevian segments
badb=0
for _ in range(2000):
    a=rand_simplex_pt(rng,80); l=rng.randrange(3)
    tau=Fr(rng.randint(1,40),rng.randint(41,90))
    b=add(sc(1-tau,a),sc(tau,E[l]))
    if min(b)<=0: continue
    if rng.random()<0.5: a,b=b,a   # feed in random order
    # proof's normalisation
    s=None
    # b = a + s(e_l - a)
    for j in range(3):
        if j!=l: s=1-b[j]/a[j]; break
    A,Bp=(a,b) if s>0 else (b,a)
    t=None
    for j in range(3):
        if j!=l: t=1-Bp[j]/A[j]; break
    lo=list(A); hi=list(A); hi[l]=A[l]+t/(1-t)
    corners=[nu(tuple(c)) for c in itertools.product(*[(lo[j],hi[j]) for j in range(3)])]
    if set(hull2(corners))!=set([a,b]): badb+=1
P('Lemma 6.5(b): segment-as-box failures:',badb)

# ---- classification helper
def classify(T):
    H=hull2(T); assert len(H)==3
    ty=vertex_types(H)
    bad=[x for x in H if not any(visible_def(H,x,j) for j in range(3))]
    # consistency: type 'S' somewhere iff visible
    for x in H: assert (('S' in ty[x])==(x not in bad))
    en=edges_normals(H)
    cev=[is_cevian(g) for a,b,g in en]
    def edge_cev(x,y):
        for a,b,g in en:
            if {a,b}=={x,y}: return is_cevian(g)
    if len(bad)<=1: cls='V'
    elif len(bad)==2: cls='X' if edge_cev(*bad) else 'N'
    else: cls='3allcev' if all(cev) else '3'
    return H,ty,bad,sum(cev),cls,en

# ---- Corollary 6.6 (<=): construction on random class-X triangles, exact
nX=0; failX=0
tries=0
while nX<400 and tries<400000:
    tries+=1
    T=[rand_simplex_pt(rng,40) for _ in range(3)]
    if len(hull2(T))!=3: continue
    # force a cevian edge sometimes
    if rng.random()<0.7:
        a=T[0]; l=rng.randrange(3); tau=Fr(rng.randint(1,30),rng.randint(31,60))
        b=add(sc(1-tau,a),sc(tau,E[l]))
        if min(b)<=0: continue
        T=[a,b,T[2]]
        if len(hull2(T))!=3: continue
    H,ty,bad,ncev,cls,en=classify(T)
    if cls!='X': continue
    nX+=1
    cvert=[x for x in H if x not in bad][0]
    j=[jj for jj in range(3) if visible_def(H,cvert,jj)][0]
    # epsilon with k=c+eps(c-e_j) in relint T
    eps=Fr(1,2)
    while True:
        kk=add(cvert,sc(eps,sub(cvert,E[j])))
        if min(kk)>0 and all(dot(g,kk)>0 for a,b,g in en): break
        eps/=2
    A_j_ok = add(sc(1/(1+eps),kk),sc(eps/(1+eps),E[j]))==cvert
    a,b=bad
    l=[ll for ll in range(3) if cross(a,b)[ll]==0]
    # build box as in Lemma 6.5(b)
    ll=None
    for cand in range(3):
        if dot(cross(a,b),E[cand])==0: ll=cand
    s=None
    for jj in range(3):
        if jj!=ll: s=1-b[jj]/a[jj]; break
    A_,B_=(a,b) if s>0 else (b,a)
    for jj in range(3):
        if jj!=ll: t=1-B_[jj]/A_[jj]; break
    lo=list(A_); hi=list(A_); hi[ll]=A_[ll]+t/(1-t)
    corners=[nu(tuple(c)) for c in itertools.product(*[(lo[x],hi[x]) for x in range(3)])]
    K=hull2([kk,cvert]+corners)
    if not(A_j_ok and set(K)==set(H)): failX+=1
P('Corollary 6.6 (<=): class-X triangles built',nX,' failures',failX)

# ---- open problem (4) test triangles
tests={'OP4-a (stated: one cevian edge)':[sc(Fr(1,8),v(1,6,1)),sc(Fr(1,10),v(6,1,3)),sc(Fr(1,8),v(6,1,1))],
       'OP4-b (stated: two cevian edges)':[sc(Fr(1,11),v(6,4,1)),sc(Fr(1,10),v(6,1,3)),sc(Fr(1,8),v(6,1,1))],
       'Example 6.7 T':[sc(Fr(1,5),v(1,2,2)),sc(Fr(1,5),v(2,1,2)),sc(Fr(1,5),v(3,1,1))],
       'reversed triangle':[sc(Fr(1,5),v(1,2,2)),sc(Fr(1,5),v(2,1,2)),sc(Fr(1,5),v(2,2,1))]}
for name,T in tests.items():
    H,ty,bad,ncev,cls,en=classify(T)
    P(name,': interior',all(min(x)>0 for x in T),'| types',[(tuple(str(c) for c in x),ty[x]) for x in H])
    P('   normals',[prim(g) for a,b,g in en],'| #cevian edges',ncev,'| bad',[tuple(str(c) for c in x) for x in bad],'| class',cls)

# ---- Example 7.17 pentagon
cyc=[sc(Fr(1,7),v(1,4,2)),sc(Fr(1,7),v(2,1,4)),sc(Fr(1,7),v(4,2,1))]
L=[sc(Fr(1,5),v(1,2,2)),v(Fr(1,2),Fr(1,2),0),sc(Fr(1,5),v(1,3,1))]
gens=[nu(had(qq,m)) for qq in L for m in cyc]
K=hull2(gens)
P('Example 7.17: vertices',[tuple(str(c) for c in x) for x in K])
P('   normals',[prim(g) for a,b,g in edges_normals(K)],' #non-cevian',sum(1 for a,b,g in edges_normals(K) if not is_cevian(g)))
HL=hull2(L); tyL=vertex_types(HL)
P('   L facet normals',[prim(g) for a,b,g in edges_normals(HL)],'types',[(tuple(str(c) for c in x),tyL[x]) for x in HL])

# ---- Theorem 7.16(d): random L with pi* in relint Delta_{12}, random orthant-planar K0 (cyclic-type / boxes)
def rand_op():
    # random normalised box (2-dim) or random all-cevian triangle via log coordinates
    if rng.random()<0.5:
        lo=[Fr(rng.randint(1,9)) for _ in range(3)]; hi=[x+Fr(rng.randint(1,9)) for x in lo]
        return hull2([nu(tuple(c)) for c in itertools.product(*[(lo[j],hi[j]) for j in range(3)])])
    # cyclic-type triangle {m3<=r1 m1, m1<=r2 m2, m2<=r3 m3} with r1 r2 r3>1
    while True:
        r=[Fr(rng.randint(2,9),rng.randint(1,4)) for _ in range(3)]
        if r[0]*r[1]*r[2]>1: break
    # vertices: intersections of pairs of lines m3=r1 m1, m1=r2 m2, m2=r3 m3
    V=[nu((r[1],Fr(1),r[0]*r[1])),  # m1=r2 m2, m3=r1 m1
       nu((r[1]*r[2],r[2],Fr(1))), # m1=r2 m2, m2=r3 m3
       nu((Fr(1),r[2]*r[0],r[0]))] # m2=r3 m3, m3=r1 m1
    H=hull2(V)
    return H
fails=0; ntest=0; polys=0
for _ in range(300):
    pis=Fr(rng.randint(1,19),20); pi=(pis,1-pis,Fr(0))
    Lv=[pi]+[rand_simplex_pt(rng,30) for _ in range(rng.choice([2,3]))]
    HL=hull2(Lv)
    if len(HL)<3 or pi not in HL: continue
    K0=rand_op()
    if len(K0)<3: continue
    en0=edges_normals(K0)
    if not all(is_cevian(g) for a,b,g in en0): continue
    gens=[nu(had(qq,m)) for qq in HL for m in K0]
    K=hull2(gens)
    ntest+=1
    if not any(not is_cevian(g) for a,b,g in edges_normals(K)): fails+=1
P('Theorem 7.16(d): random (L,K0) pairs',ntest,' with all edge lines cevian (counterexamples):',fails)

open('geom_checks.out','w').write('\n'.join(out)+'\n')
print('\n'.join(out))
