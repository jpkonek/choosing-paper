# REF64_bx: consistency of Section 8.3 item (1) (>=2 all-crossing vertices excluded for convex error levels)
# with the veto-box class X and with all-cevian triangles: count CCC vertices.
import sys, random
sys.path.insert(0,'.')
from g3 import *
rng=random.Random(99)
stats={}
n=0
while n<6000:
    T=[rand_simplex_pt(rng,40) for _ in range(3)]
    if rng.random()<0.6:
        a=T[0]; l=rng.randrange(3); tau=Fr(rng.randint(1,30),rng.randint(31,60))
        b=add(sc(1-tau,a),sc(tau,E[l]))
        if min(b)<=0: continue
        T=[a,b,T[2]]
    H=hull2(T)
    if len(H)!=3: continue
    n+=1
    ty=vertex_types(H)
    bad=[x for x in H if 'S' not in ty[x]]
    en=edges_normals(H)
    allcev=all(is_cevian(g) for a,b,g in en)
    def ec(x,y):
        for a,b,g in en:
            if {a,b}=={x,y}: return is_cevian(g)
    if len(bad)<=1: cls='V'
    elif len(bad)==2: cls='X' if ec(*bad) else 'N'
    else: cls='3c' if allcev else '3'
    if allcev: cls+='+allcev'
    nccc=sum(1 for x in H if ty[x]=='CCC')
    stats.setdefault(cls,{}); stats[cls][nccc]=stats[cls].get(nccc,0)+1
lines=['class -> {#CCC vertices: count}']+[f'{k}: {v}' for k,v in sorted(stats.items())]
open('ccc_check.out','w').write('\n'.join(lines)+'\n'); print('\n'.join(lines))
