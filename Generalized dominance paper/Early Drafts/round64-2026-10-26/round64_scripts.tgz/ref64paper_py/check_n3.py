"""REF64_paper: randomized exact test of Theorem 6.8 (N(L*K0) = N(L) <= 1 for n = 3, pi* interior)
and of Lemma 6.6 (non-visible interior extreme point <=> in some M_i).
Run: python3 -I check_n3.py"""
import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from polyhull import *

random.seed(64)
cyc = [nu((1,4,2)), nu((2,1,4)), nu((4,2,1))]
hexv=[nu((1,2,2)),nu((1,1,2)),nu((2,1,2)),nu((2,1,1)),nu((2,F(11,5),1)),nu((F(11,10),F(11,5),1))]
box=[nu(x) for x in product((1,3),(1,2),(2,5)) if True]
seg=[nu((1,1,1)), nu((1,1,3))]          # lower-dimensional orthant-planar K0 (segment on a cevian line through e3)
K0s={'cyclic':cyc,'hexagon':hexv,'box':box,'segment':seg}

def interior(p): return all(t>0 for t in p)

def Ncount(V,Fc):
    return sum(1 for v in V if interior(v) and 'S' not in vis_types(v,Fc))

def in_Mi(x, V):
    out=[]
    for i in range(3):
        ok=all(m[i]*x[j]-m[j]*x[i]>=0 for j in range(3) if j!=i for m in V)
        if ok: out.append(i)
    return out

def randpt():
    a=[random.randint(1,12) for _ in range(3)]
    return nu(a)

trials=0; fails=0; lemma_fail=0
while trials<300:
    pts=[randpt() for _ in range(random.choice([3,4,5]))]
    VL,FL=hull(pts)
    if len(VL)<3: continue
    nL=Ncount(VL,FL)
    if nL>1: continue      # (L) forces at most one non-visible vertex (the exempt point)
    for name,K0 in K0s.items():
        gens=[nu(had(q,m)) for q in VL for m in K0]
        V,Fc=hull(gens)
        nK=Ncount(V,Fc)
        if nK!=nL:
            fails+=1; print('FAIL',name,[str(t) for t in VL],nL,nK)
        for x in V:
            nv=('S' not in vis_types(x,Fc))
            if nv != bool(in_Mi(x,V)): lemma_fail+=1; print('Lemma 6.6 fail',x)
    trials+=1
print('trials',trials,'Theorem 6.8 failures',fails,'Lemma 6.6 failures',lemma_fail)
