"""REF64_paper: independent exact re-verification of the computed examples in
'Covering coherent sets of desirable gambles (draft)'.
Run:  python3 -I check_examples.py  (from this folder; imports polyhull by path)."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from polyhull import *

def show(v):
    return '(' + ','.join(str(t) for t in v) + ')'

print('=== Remark 4.20(1) triangle ===')
v = (F(2,5),F(3,10),F(3,10)); w=(F(1,5),F(2,5),F(2,5)); x=(F(9,20),F(9,20),F(1,10))
V,Fc = hull([v,w,x]); print('facets', Fc)
for p in V: print(show(p), vis_types(p,Fc))
print('w == v + (v-e1)/3 :', w == tuple(v[i]+(v[i]-(1 if i==0 else 0))/3 for i in range(3)))

print('\n=== Example 5.11 cyclic triangle ===')
cyc = [nu((1,4,2)), nu((2,1,4)), nu((4,2,1))]
V,Fc = hull(cyc); print('facets', Fc)
for p in V: print(show(p), vis_types(p,Fc))
def maxratio(Vs,b,a): return max(p[b]/p[a] for p in Vs)
P1 = maxratio(V,1,0)*maxratio(V,2,1)*maxratio(V,0,2)
P2 = maxratio(V,2,0)*maxratio(V,1,2)*maxratio(V,0,1)
print('cyclic products', P1, P2)
# deciding vertex per mixed orthant: point maximising all m_b/m_a, a in P, b in N
import itertools
for Pset in [(0,),(1,),(2,),(0,1),(0,2),(1,2)]:
    N=[i for i in range(3) if i not in Pset]
    dec=[p for p in V if all(p[b]/p[a]==maxratio(V,b,a) for a in Pset for b in N)]
    print(' P=',[i+1 for i in Pset],'deciding', [show(p) for p in dec])

print('\n=== Example 5.12 hexagon ===')
hexv=[nu((1,2,2)),nu((1,1,2)),nu((2,1,2)),nu((2,1,1)),nu((2,F(11,5),1)),nu((F(11,10),F(11,5),1))]
V,Fc = hull(hexv); print('#vertices',len(V),'facets', Fc)
for p in V: print(show(p), vis_types(p,Fc))
print('cyclic products', maxratio(V,1,0)*maxratio(V,2,1)*maxratio(V,0,2), maxratio(V,2,0)*maxratio(V,1,2)*maxratio(V,0,1))
print('non-visible vertices', sum(1 for p in V if 'S' not in vis_types(p,Fc)))
print('every facet normal has a zero coord:', all(any(t==0 for t in g) for g in Fc))

print('\n=== Example 6.16 pentagon ===')
L=[nu((1,2,2)),(F(1,2),F(1,2),F(0)),nu((1,3,1))]
VL,FL=hull(L); print('L facets',FL)
for p in VL: print(' L vertex',show(p),vis_types(p,FL))
gens=[nu(had(q,m)) for q in L for m in cyc]
V,Fc=hull(gens); print('K #vertices',len(V))
for p in V: print(' ',show(p), vis_types(p,Fc))
print('K facets',Fc)
claimed=[nu((1,12,2)),nu((1,8,4)),nu((1,1,4)),nu((2,1,0)),nu((1,4,0))]
print('vertices as claimed:', sorted(V)==sorted(claimed))
print('claimed facets match:', sorted(Fc)==sorted([(-4,8,-1),(0,0,1),(4,-1,4),(4,0,-1),(16,-1,-2)]))
print('boundary edge = nu(pi*.K0):', sorted(nu(had(L[1],m)) for m in cyc))
print('facets w/o zero coord', [g for g in Fc if all(t!=0 for t in g)])
# Theorem BE (c) check via face count: K cap Delta_{12} has 2 extreme points with support {1,2}

print('\n=== Example 6.13 / Theorem F ([1,2]^4 box) ===')
n=4
p0=nu((4,3,2,1)); eps=F(1,20)
ub=tuple(F(1,4) for _ in range(4))
e=lambda j: tuple(F(int(i==j)) for i in range(n))
vL=[tuple((1-eps)*p0[i]+eps*e(j)[i] for i in range(n)) for j in range(n)]
print('v_j:', [show(v) for v in vL])
claimed_v=[(F(43,100),F(57,200),F(19,100),F(19,200)),(F(19,50),F(67,200),F(19,100),F(19,200)),
           (F(19,50),F(57,200),F(6,25),F(19,200)),(F(19,50),F(57,200),F(19,100),F(29,200))]
print('v_j as printed:', vL==claimed_v)
print('eps bound', min((p0[0]-p0[b])/(1+p0[0]-p0[b]) for b in range(1,4)))
Lv=[ub]+vL
VL,FL=hull(Lv); print('L facets', FL)
print('L facets with no zero coordinate', [g for g in FL if all(t!=0 for t in g)])
# (F): q_a > q_b on L\{ub}: check on vertices v_j (then convexity)
print('(F) on v_j:', all(v[0]>v[b] for v in vL for b in range(1,4)))
K0=[nu(x) for x in product((1,2),repeat=4) if len(set(x))>1]
gens=[nu(had(q,m)) for q in Lv for m in K0]
print('#generators',len(gens), '#distinct', len(set(gens)))
V,Fc=hull(gens)
E=edges(V,Fc)
print('K: #V',len(V),'#E',len(E),'#F',len(Fc), 'Euler', len(V)-len(E)+len(Fc))
bad=[v for v in V if 'S' not in vis_types(v,Fc)]
print('non-visible vertices:',len(bad))
for v in bad:
    y=[t/min(v) for t in v]
    print('  ', show(v), 'as box corner', show(y), vis_types(v,Fc))
nz=[g for g in Fc if all(t!=0 for t in g)]
print('facets with no zero coordinate:',len(nz), nz)
print('contains (-19,-19,-19,362):', (-19,-19,-19,362) in Fc, ' (134,-57,-57,94):', (134,-57,-57,94) in Fc)
print('facets by #nonzero', {k:sum(1 for g in Fc if sum(1 for t in g if t!=0)==k) for k in (2,3,4)})
pred=[nu(x) for x in product((1,2),repeat=4) if x[0]==1 and sum(1 for t in x[1:] if t==2)>=2]
print('Theorem F(b) predicted corners all non-visible vertices:', all(p in bad for p in pred), len(pred))
# Theorem F(c) construction: from each L facet with no zero coord build eta' and check it is a K facet
for eta in FL:
    if all(t!=0 for t in eta):
        xs=[1 if t>=0 else 2 for t in eta]
        etap=to_int([F(eta[j],xs[j]) for j in range(4)]) if all(t>0 for t in eta) else None
        g=[F(eta[j],xs[j]) for j in range(4)]
        from math import gcd
        from functools import reduce
        L_=reduce(lambda a,b:a*b//gcd(a,b),[q.denominator for q in g],1)
        gi=[int(q*L_) for q in g]; d=reduce(gcd,[abs(t) for t in gi]); gi=tuple(t//d for t in gi)
        print('  L facet',eta,'-> eta\'',gi,'is K facet:',gi in Fc)

print('\n=== Open problem (4) test triangle ===')
T=[nu((1,6,1)), nu((6,1,3)), nu((6,1,1))]
V,Fc=hull(T); print('facets',Fc)
for p in V: print(' ',show(p),vis_types(p,Fc))
print('cevian edges (normal with a zero coordinate):', sum(1 for g in Fc if any(t==0 for t in g)))

print('\n=== Corollary 6.12 with a facet of L: n=4 explicit family facet claim ===')
k=[kk for kk in range(4) if ub[kk] > (1-eps)*p0[kk]]
print('k with ub_k > (1-eps)p0_k:', [kk+1 for kk in k])
for kk in k:
    g=tuple(F(int(i==kk))-(1-eps)*p0[kk] for i in range(4))
    gi=to_int([abs(t) for t in g]); gi=tuple(t if g[i]>0 else -t for i,t in enumerate(gi))
    print('  normal', gi, 'is L facet:', gi in FL)
