"""Independent exact hull routines for REF64_paper (integer / Fraction arithmetic only).

A polytope K in aff(Delta) subset R^n is handled through its cone: points are positive
vectors (not necessarily normalised).  A 'facet normal' is a primitive integer g in R^n with
g.p >= 0 for every generator and g.p = 0 on a set of generators spanning an (n-1)-dim linear
space.  This is the paper's convention (Lemma 4.16): K = {m in aff Delta : g_f . m >= 0}.
"""
from fractions import Fraction as F
from itertools import combinations, product
from math import gcd
from functools import reduce
import sympy


def to_int(v):
    """Scale a positive rational vector to a primitive integer vector (same ray)."""
    v = [F(x) for x in v]
    L = reduce(lambda a, b: a * b // gcd(a, b), [x.denominator for x in v], 1)
    w = [int(x * L) for x in v]
    g = reduce(gcd, [abs(t) for t in w if t != 0], 0)
    return tuple(t // g for t in w)


def nu(v):
    s = sum(F(x) for x in v)
    return tuple(F(x) / s for x in v)


def had(a, b):
    return tuple(F(x) * F(y) for x, y in zip(a, b))


def det(M):
    if len(M) == 1:
        return M[0][0]
    if len(M) == 2:
        return M[0][0] * M[1][1] - M[0][1] * M[1][0]
    return sum((-1) ** j * M[0][j] * det([r[:j] + r[j + 1:] for r in M[1:]]) for j in range(len(M)))


def nullvec(rows, n):
    """Null vector of an (n-1) x n integer matrix via signed maximal minors (None if rank < n-1)."""
    rows = [list(r) for r in rows]
    w = [(-1) ** j * det([r[:j] + r[j + 1:] for r in rows]) for j in range(n)]
    if all(t == 0 for t in w):
        return None
    g = reduce(gcd, [abs(t) for t in w if t != 0], 0)
    return tuple(t // g for t in w)


def rank(rows):
    if not rows:
        return 0
    return sympy.Matrix(rows).rank()


def hull(points):
    """points: list of positive rational vectors in R^n (cone generators).
    Returns (vertices as normalised tuples, facets as primitive integer normals)."""
    P = list({to_int(p) for p in points})
    n = len(P[0])
    facets = set()
    for S in combinations(range(len(P)), n - 1):
        rows = [P[i] for i in S]
        g = nullvec(rows, n)
        if g is None:
            continue
        vals = [sum(a * b for a, b in zip(g, p)) for p in P]
        if all(v >= 0 for v in vals):
            facets.add(g)
        elif all(v <= 0 for v in vals):
            facets.add(tuple(-t for t in g))
    facets = sorted(facets)
    verts = []
    for p in P:
        act = [g for g in facets if sum(a * b for a, b in zip(g, p)) == 0]
        if rank(act) == n - 1:
            verts.append(p)
    return [nu(v) for v in verts], facets


def active(x, facets):
    return [g for g in facets if sum(a * F(b) for a, b in zip(g, x)) == 0]


def vis_types(x, facets):
    """Per world j: 'S' visible (all active g_j<0), 'T' tangential (all <=0, not all <0),
    'A' anti (all >=0 and some >0... i.e. every generator >=0), 'C' crossing (both signs)."""
    act = active(x, facets)
    out = ''
    for j in range(len(x)):
        c = [g[j] for g in act]
        if all(t < 0 for t in c):
            out += 'S'
        elif all(t <= 0 for t in c):
            out += 'T'
        elif all(t >= 0 for t in c):
            out += 'A'
        else:
            out += 'C'
    return out


def edges(verts, facets):
    n = len(verts[0])
    E = []
    for a, b in combinations(verts, 2):
        common = [g for g in facets if sum(x * F(y) for x, y in zip(g, a)) == 0
                  and sum(x * F(y) for x, y in zip(g, b)) == 0]
        if rank(common) == n - 2:
            # the face exposed by these is the segment [a,b] iff no third vertex lies on all
            third = [v for v in verts if v not in (a, b)
                     and all(sum(x * F(y) for x, y in zip(g, v)) == 0 for g in common)]
            if not third:
                E.append((a, b))
    return E
