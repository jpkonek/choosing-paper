"""Exact convex-hull utilities for subsets of the simplex (Fraction arithmetic).
Points are tuples of Fractions summing to 1. Facets are homogeneous normals g
with g.m >= 0 on the hull (facet = zero set)."""
from fractions import Fraction as F
from itertools import combinations, product

def nu(x):
    s = sum(x); return tuple(F(t)/s for t in x)

def had(a,b): return tuple(x*y for x,y in zip(a,b))
def dot(a,b): return sum(x*y for x,y in zip(a,b))

def det(M):
    M=[list(r) for r in M]; n=len(M); d=F(1)
    for c in range(n):
        p=None
        for r in range(c,n):
            if M[r][c]!=0: p=r;break
        if p is None: return F(0)
        if p!=c: M[c],M[p]=M[p],M[c]; d=-d
        d*=M[c][c]
        for r in range(c+1,n):
            f=M[r][c]/M[c][c]
            for k in range(c,n): M[r][k]-=f*M[c][k]
    return d

def rank(vs):
    M=[list(v) for v in vs]
    if not M: return 0
    n=len(M[0]); r=0
    for c in range(n):
        p=None
        for i in range(r,len(M)):
            if M[i][c]!=0: p=i;break
        if p is None: continue
        M[r],M[p]=M[p],M[r]
        for i in range(len(M)):
            if i!=r and M[i][c]!=0:
                f=M[i][c]/M[r][c]
                M[i]=[a-f*b for a,b in zip(M[i],M[r])]
        r+=1
    return r

def normal(pts):
    """homogeneous normal orthogonal to n-1 vectors in R^n (cofactors)."""
    n=len(pts[0]); g=[]
    for i in range(n):
        M=[[p[j] for j in range(n) if j!=i] for p in pts]
        g.append((-1)**i*det(M))
    return tuple(g)

def primitive(g):
    # scale to make it canonical: divide by gcd-ish (first nonzero abs value) keep sign
    import math
    den=1
    for t in g: den=den*t.denominator//math.gcd(den,t.denominator)
    gi=[int(t*den) for t in g]
    gg=0
    for t in gi: gg=math.gcd(gg,abs(t))
    return tuple(t//gg for t in gi)

def hull(points):
    pts=list(dict.fromkeys(points)); n=len(pts[0])
    facets=set()
    for comb in combinations(range(len(pts)),n-1):
        vs=[pts[i] for i in comb]
        if rank(vs)<n-1: continue
        g=normal(vs)
        vals=[dot(g,p) for p in pts]
        if all(v>=0 for v in vals): facets.add(primitive(g))
        elif all(v<=0 for v in vals): facets.add(primitive(tuple(-t for t in g)))
    facets=sorted(facets)
    verts=[]
    for p in pts:
        inc=[g for g in facets if dot(g,p)==0]
        if rank(inc)>=n-1: verts.append(p)
    return verts,facets

def incident(p,facets): return [g for g in facets if dot(g,p)==0]

def types(p,facets):
    """world types at vertex p: S strictly visible, T tangential, A anti, C crossing.
    F_p = cone of incident facet normals (polytope)."""
    inc=incident(p,facets); out=''
    n=len(p)
    for j in range(n):
        vals=[g[j] for g in inc]
        if all(v<0 for v in vals): out+='S'
        elif all(v<=0 for v in vals): out+='T'
        elif all(v>=0 for v in vals): out+='A'
        else: out+='C'
    return out

def edges(verts,facets,n):
    E=[]
    for a,b in combinations(verts,2):
        common=[g for g in facets if dot(g,a)==0 and dot(g,b)==0]
        if rank(common)>=n-2: E.append((a,b))
    return E
