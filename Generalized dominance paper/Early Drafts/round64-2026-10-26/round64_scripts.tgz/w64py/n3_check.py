import sys; sys.path.insert(0,'.')
from hull import *
n=3
def show(v): return '('+','.join(str(t) for t in v)+')'
# cyclic triangle
cyc=[nu((1,4,2)),nu((2,1,4)),nu((4,2,1))]
V,Fc=hull(cyc); print('cyclic facets',Fc,[types(v,Fc) for v in V])
# ratio criterion: for each mixed orthant (P,N) find vertex maximizing m_j/m_i, i in P, j in N
from itertools import combinations
def ratio_check(verts):
    res={}
    for r in (1,2):
        for P in combinations(range(3),r):
            N=[j for j in range(3) if j not in P]
            good=[d for d in verts if all(d[j]*m[i] >= m[j]*d[i] for m in verts for i in P for j in N)]
            res[(P,tuple(N))]=[show(d) for d in good]
    return res
print('cyclic ratio', ratio_check(V))
# hexagon
hexv=[nu(x) for x in [(1,2,2),(1,1,2),(2,1,2),(2,1,1),(F(2),F(11,5),F(1)),(F(11,10),F(11,5),F(1))]]
V,Fc=hull(hexv); print('hexagon #verts',len(V),'facets',Fc)
print('hex ratio',ratio_check(V))
def maxratio(verts,i,j): return max(m[j]/m[i] for m in verts)
for name,vs in (('cyc',cyc),('hex',V)):
    h1=maxratio(vs,0,1)*maxratio(vs,1,2)*maxratio(vs,2,0)
    h2=maxratio(vs,0,2)*maxratio(vs,2,1)*maxratio(vs,1,0)
    print(name,'holonomy products',h1,h2,h1/h2)
print('hex types',[types(v,Fc) for v in V])
# reversed triangle
R=[nu((1,2,2)),nu((2,1,2)),nu((2,2,1))]
V,Fc=hull(R); print('reversed facets',Fc,[types(v,Fc) for v in V])
# pentagon
Lv=[nu((1,2,2)),(F(1,2),F(1,2),F(0)),nu((1,3,1))]
VL,FL=hull(Lv); print('L facets',FL,[ (show(v),types(v,FL)) for v in VL])
gens=[nu(had(q,m)) for q in Lv for m in cyc]
V,Fc=hull(gens)
print('pentagon',[show(v) for v in V]); print('facets',Fc)
for g in Fc: print(g,'cevian' if 0 in g else 'non-cevian')
print('pent types',[(show(v),types(v,Fc)) for v in V])
