import sys; sys.path.insert(0,'.')
from hull import *
n=4
p0=nu((4,3,2,1)); eps=F(1,20)
ub=tuple(F(1,4) for _ in range(4))
e=lambda j: tuple(F(int(i==j)) for i in range(n))
vL=[tuple((1-eps)*p0[i]+eps*e(j)[i] for i in range(n)) for j in range(n)]
Lv=[ub]+vL
K0v=[nu(x) for x in product((1,2),repeat=4) if len(set(x))>1]
gens=[nu(had(q,m)) for q in Lv for m in K0v]
V,Fc=hull(gens)
print('L vertices'); VL,FL=hull(Lv)
for v in VL: print(v,types(v,FL))
print('L facets',FL)
print('K: #vertices',len(V),'#facets',len(Fc),'#edges',len(edges(V,Fc,n)))
bad=[v for v in V if 'S' not in types(v,Fc)]
print('bad',len(bad))
for v in bad: print([str(t) for t in v],types(v,Fc))
nz=[g for g in Fc if all(t!=0 for t in g)]
print('facets with no zero coordinate',len(nz),nz)
print('facets by #nonzero',{k:sum(1 for g in Fc if sum(1 for t in g if t!=0)==k) for k in (2,3,4)})
# epsilon condition
a=0
print('eps bound',min((p0[a]-p0[b])/(1+p0[a]-p0[b]) for b in range(1,4)))
# Theorem F predicted corners: x_a=1 (alpha), |H|>=2
pred=[nu(x) for x in product((1,2),repeat=4) if x[0]==1 and sum(1 for t in x[1:] if t==2)>=2]
print('predicted',len(pred), all(p in bad for p in pred))
print('verts list')
for v in V: print('(' + ','.join(str(t) for t in v)+')', types(v,Fc))
