import sys; sys.path.insert(0,'.')
from hull import *
p=nu((1,2,2)); q=nu((2,1,2)); s=nu((3,1,1))
V,Fc=hull([p,q,s]); print('facets',Fc)
for v in V: print(v,types(v,Fc),[g for g in Fc if dot(g,v)==0])
k=nu((22,11,17)); print('k',k, 'bary', [F(1,10),F(3,5),F(3,10)], tuple(F(1,10)*a+F(3,5)*b+F(3,10)*c for a,b,c in zip(p,q,s))==k)
e3=(F(0),F(0),F(1)); print('q identity', tuple(F(10,11)*a+F(1,11)*b for a,b in zip(k,e3))==q)
print('nu(6,2,2)=s',nu((6,2,2))==s)
# k strictly positive on extreme rays of cl D_T: rays = cross products of adjacent vertices
def cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
for a,b in ((p,q),(p,s),(q,s)):
    r=cross(a,b); 
    # orient so that third vertex positive
    c=[x for x in (p,q,s) if x not in (a,b)][0]
    if dot(r,c)<0: r=tuple(-t for t in r)
    print('ray',[str(t*25) for t in r],'k.r',dot(k,r))
