"""REF64_pc (a),(b): the lexicographic Bayes sets X*(W0,beta,alpha) of the T-ranking, at every kind
of admissible triple (boundary priors, beta_3 = 0, formal W0 not containing worlds 1,2), checked exactly:
  (i)  g(h) = alpha3*phi3(h) - sum_j beta_j c_j(h) equals max_{w in vert W}(-w.h);
  (ii) N(W0) cap {g<0} = D_{K(W0,beta,alpha)} with K = conv({k} u [q if 3 in W0] u nu(vert W));
  (iii) closure of X* under addition (convex cone) on random accepted pairs;
  (iv) strict decrease g(h+t1) <= g(h) - t beta.l  (null tie set, uniqueness).
Control: replacing the concave c1 = min(h1,6h1) by the convex max(h1,6h1) (still sign-correct)
breaks (iii) at some triple -- concavity is what the coherence proof uses.
Run: python3 -I t_family.py"""
import sys, random
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from rg import *

OUT = []
def pr(*a):
    s = ' '.join(str(x) for x in a); OUT.append(s); print(s)

p = (Fr(1,5), Fr(2,5), Fr(2,5)); q = (Fr(2,5), Fr(1,5), Fr(2,5)); s = (Fr(3,5), Fr(1,5), Fr(1,5))
k = (Fr(22,50), Fr(11,50), Fr(17,50))
L = (Fr(1), Fr(2), Fr(2)); Uu = (Fr(6), Fr(2), Fr(2))
rng = random.Random(6402)
def rq(M=50, D=11):
    return Fr(rng.randint(-M, M), rng.randint(1, D))

def chart(h, concave=True):
    c1 = min(h[0], 6*h[0]) if concave else max(h[0], 6*h[0])
    return (c1, 2*h[1], 2*h[2])

def phi3(h):
    return max(Fr(0), -dot(q, h))

def g(h, W0, beta, a3, concave=True):
    c = chart(h, concave)
    val = -sum(beta[j]*c[j] for j in range(3))
    if 2 not in W0:
        val += a3 * phi3(h)
    return val

def inN(h, W0):
    if dot(k, h) <= 0: return False
    if 2 in W0 and dot(q, h) < 0: return False
    return True

def Wverts(beta, W0, a3):
    corners = [(L[0], L[1], L[2]), (Uu[0], L[1], L[2])]   # R = [1,6] x {2} x {2}
    base = [tuple(beta[j]*r[j] for j in range(3)) for r in corners]
    if 2 in W0 or a3 == 0:
        return base
    return base + [tuple(b[j] + a3*q[j] for j in range(3)) for b in base]

def Kpts(beta, W0, a3):
    pts = [k] + ([q] if 2 in W0 else []) + [nu(w) for w in Wverts(beta, W0, a3)]
    return [lift(x) for x in hull2(pts)]

def Xstar(h, W0, beta, a3, concave=True):
    return inN(h, W0) and g(h, W0, beta, a3, concave) < 0

def rand_triple():
    W0 = rng.choice([(0,1,2), (0,1), (2,), (0,2), (1,2), (0,), (1,)])
    # admissible: supp beta subset W0, beta != 0, alpha on complement (only world 3 has a veto)
    while True:
        beta = [Fr(rng.choice([0, 0, 1, 2, 3, 5, 7]), rng.randint(1, 4)) if j in W0 else Fr(0) for j in range(3)]
        if any(beta): break
    a3 = Fr(rng.choice([0, 0, 1, 2, 5]), rng.randint(1, 3)) if 2 not in W0 else Fr(0)
    return W0, beta, a3

fails = {'i': 0, 'ii': 0, 'iii': 0, 'iv': 0}
ntrip = 0; npairs = 0; kinds = {}
special = [((0,1,2), [Fr(1),Fr(1),Fr(1)], Fr(0)),     # target
           ((0,1,2), [Fr(1),Fr(0),Fr(0)], Fr(0)),     # boundary prior e1
           ((0,1,2), [Fr(0),Fr(0),Fr(1)], Fr(0)),     # e3, veto respected
           ((0,1), [Fr(1),Fr(1),Fr(0)], Fr(0)),       # pi3 = 0, no veto weight
           ((0,1), [Fr(0),Fr(1),Fr(0)], Fr(3)),       # pi = e2 with veto weight
           ((0,1), [Fr(1),Fr(0),Fr(0)], Fr(1))]
trips = special + [rand_triple() for _ in range(400)]
for (W0, beta, a3) in trips:
    ntrip += 1
    kinds[(tuple(W0), a3 > 0)] = kinds.get((tuple(W0), a3 > 0), 0) + 1
    Wv = Wverts(beta, W0, a3)
    K = Kpts(beta, W0, a3)
    acc = []
    for _ in range(400):
        h = (rq(), rq(), rq())
        # (i)
        if g(h, W0, beta, a3) != max(-dot(w, h) for w in Wv): fails['i'] += 1
        # (iv)
        t = abs(rq()) + Fr(1, 7)
        ht = tuple(z + t for z in h)
        if not g(ht, W0, beta, a3) <= g(h, W0, beta, a3) - t*sum(beta[j]*L[j] for j in range(3)): fails['iv'] += 1
        # (ii): skip the null boundary sets
        if dot(k, h) == 0 or dot(q, h) == 0 or any(dot(m, h) == 0 for m in K) or g(h, W0, beta, a3) == 0: continue
        x = Xstar(h, W0, beta, a3)
        dk = dot(k, h) > 0 and all(dot(m, h) > 0 for m in K)
        if x != dk: fails['ii'] += 1
        if x: acc.append(h)
    # (iii)
    for _ in range(60):
        if len(acc) < 2: break
        a, b = rng.sample(acc, 2); npairs += 1
        hs = tuple(x + y for x, y in zip(a, b))
        if not Xstar(hs, W0, beta, a3): fails['iii'] += 1
pr('triples tested: %d (kinds by (W0, alpha3>0): %s)' % (ntrip, dict(sorted(kinds.items()))))
pr('accepted pairs tested for closure under addition: %d' % npairs)
pr('failures:', fails)

# exact undominated-family statement for the target and two boundary triples
for (W0, beta, a3) in special:
    pr('  triple W0=%s beta=%s alpha3=%s : K vertices %s' % ([w+1 for w in W0], [str(b) for b in beta], a3, [tuple(str(z) for z in m) for m in Kpts(beta, W0, a3)]))

# Control: convex (non-concave) world-1 chart
bad_found = None
for (W0, beta, a3) in trips:
    acc = []
    for _ in range(300):
        h = (rq(), rq(), rq())
        if Xstar(h, W0, beta, a3, concave=False): acc.append(h)
    for _ in range(200):
        if len(acc) < 2: break
        a, b = rng.sample(acc, 2)
        hs = tuple(x + y for x, y in zip(a, b))
        if not Xstar(hs, W0, beta, a3, concave=False):
            bad_found = (W0, beta, a3, a, b); break
    if bad_found: break
pr('control (c1 = max(h1,6h1), convex): non-convex Bayes set witness:',
   None if not bad_found else 'W0=%s beta=%s a3=%s h=%s h\'=%s' % ([w+1 for w in bad_found[0]], [str(x) for x in bad_found[1]], bad_found[2], [str(z) for z in bad_found[3]], [str(z) for z in bad_found[4]]))
open(__file__.replace('.py', '.out'), 'w').write('\n'.join(OUT) + '\n')
