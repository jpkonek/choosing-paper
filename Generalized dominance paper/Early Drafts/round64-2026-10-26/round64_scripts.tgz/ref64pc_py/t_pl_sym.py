"""REF64_pc: the corner value system for T with a symbolic target prior pi* = (a,b,c) > 0.
Reduce each c(r) in pi^perp and compute the 6x6 determinant as a polynomial in a,b,c."""
import sys
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from rg import *
import sympy as sp
p = (Fr(1,5), Fr(2,5), Fr(2,5)); q = (Fr(2,5), Fr(1,5), Fr(2,5)); s = (Fr(3,5), Fr(1,5), Fr(1,5))
V = [p, q, s]
R = {'rpq': edge_ray(V,0,1), 'rps': edge_ray(V,0,2), 'rqs': edge_ray(V,1,2)}
a, b, c = sp.symbols('a b c', positive=True)
pi = (a, b, c)
C = {nm: sp.symbols(nm + '_1:4') for nm in R}
eqs = []
for nm in C:
    eqs.append(sum(pi[j]*C[nm][j] for j in range(3)))
    for m in range(3):
        if R[nm][m] == 0: eqs.append(C[nm][m])
fac = {'F_p': ('rpq', 'rps'), 'F_q': ('rpq', 'rqs'), 'F_s': ('rps', 'rqs')}
for f, (e1, e2) in fac.items():
    r1, r2 = R[e1], R[e2]
    for m in range(3):
        if r1[m]*r2[m] < 0:
            eqs.append(sp.Rational(r2[m])*C[e1][m] - sp.Rational(r1[m])*C[e2][m])
syms = [x for nm in C for x in C[nm]]
A = sp.Matrix([[sp.diff(e, x) for x in syms] for e in eqs])
print('equations:', A.shape[0], 'unknowns:', A.shape[1])
d = sp.factor(A.det())
print('det =', d)
out = 'equations %d unknowns %d\ndet = %s\n' % (A.shape[0], A.shape[1], d)
open(__file__.replace('.py', '.out'), 'w').write(out)
