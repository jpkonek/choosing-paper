"""REF64_pc: null vectors of the corner value system for T at boundary target priors pi* (one zero)."""
import sys
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from rg import *
import sympy as sp
p = (Fr(1,5), Fr(2,5), Fr(2,5)); q = (Fr(2,5), Fr(1,5), Fr(2,5)); s = (Fr(3,5), Fr(1,5), Fr(1,5))
V = [p, q, s]
R = {'rpq': edge_ray(V,0,1), 'rps': edge_ray(V,0,2), 'rqs': edge_ray(V,1,2)}
OUT = []
def pr(*a):
    x = ' '.join(str(z) for z in a); OUT.append(x); print(x)
for pi in [(0,1,1), (1,0,1), (1,1,0)]:
    C = {nm: sp.symbols(nm + '_1:4') for nm in R}
    eqs = []
    for nm in C:
        eqs.append(sum(pi[j]*C[nm][j] for j in range(3)))
        for m in range(3):
            if R[nm][m] == 0: eqs.append(C[nm][m])
    fac = {'F_p': ('rpq', 'rps'), 'F_q': ('rpq', 'rqs'), 'F_s': ('rps', 'rqs')}
    for f, (e1, e2) in fac.items():
        r1, r2 = R[e1], R[e2]
        for m in range(3):
            if r1[m]*r2[m] < 0:
                eqs.append(sp.Rational(r2[m])*C[e1][m] - sp.Rational(r1[m])*C[e2][m])
    syms = [x for nm in C for x in C[nm]]
    A = sp.Matrix([[sp.diff(e, x) for x in syms] for e in eqs])
    ns = A.nullspace()
    pr('pi* =', pi, ' null space dim', len(ns))
    for v in ns:
        vals = {nm: [v[syms.index(x)] for x in C[nm]] for nm in C}
        pr('   c(rpq) =', vals['rpq'], ' c(rps) =', vals['rps'], ' c(rqs) =', vals['rqs'])
        for nm in C:
            pr('     sign check at %s: r = %s, c = %s, sign-compatible (c_j r_j >= 0, c_j = 0 iff r_j = 0 allowed weakly): %s'
               % (nm, [str(z) for z in R[nm]], vals[nm], all(vals[nm][j]*R[nm][j] >= 0 for j in range(3))))
open(__file__.replace('.py', '.out'), 'w').write('\n'.join(OUT) + '\n')
