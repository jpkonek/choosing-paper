"""REF64_pc (c): Corollary BX3, both directions, checked independently.
 (A) <= : for random class-X triangles (own generator), build K'={k}, A_j={c}, degenerate box R with
     nu(R)=[a,b], and verify EXACTLY every hypothesis of Theorem BX: k in relint T, c in conv(k,e_j),
     0 < l <= u, nu(corners of R) = {a,b}, and conv({k,c} u nu(R)) = T (exact hull).
 (B) => step 4: normalised boxes in relint Delta_3 are never triangles; their edges are cevian
     (random exact boxes incl. degenerate ones).
 (C) structure of class X: the bad endpoint nearer e_l is tangential from l, so class X never has
     two O61-strong non-visible vertices.
 (D) recount of the small-integer census (coordinate sums <= 10), own classifier.
Run: python3 -I t_bx3.py"""
import sys, random, itertools
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from rg import *

OUT = []
def pr(*a):
    s = ' '.join(str(x) for x in a); OUT.append(s); print(s)
rng = random.Random(64643)

def classify(V):
    bd = bad(V)
    ncev = sum(1 for (i, j) in ((0,1),(0,2),(1,2)) if cevian_lines(V, i, j))
    if len(bd) <= 1: cat = 'V'
    elif len(bd) == 3: cat = '3' if ncev < 3 else 'OP'
    else:
        cat = 'X' if cevian_lines(V, *bd) else 'N'
    return cat, ncev

def rand_interior():
    return nu([rng.randint(1, 40) for _ in range(3)])

def on_line(a, l):
    while True:
        t = Fr(rng.randint(-95, 95), 100)
        x = lin((1 - t, a), (t, E[l]))
        if t != 0 and all(z > 0 for z in x): return x

def gen():
    if rng.random() < 0.5:
        a = rand_interior(); b = on_line(a, rng.randrange(3)); c = rand_interior()
    else:
        c = rand_interior(); l1, l2 = rng.sample(range(3), 2); a = on_line(c, l1); b = on_line(c, l2)
    return [a, b, c]

def build(V):
    bd = bad(V); ci = [x for x in range(3) if x not in bd][0]; c = V[ci]
    j = [w for w in range(3) if strictly_visible_direct(V, ci, w)][0]
    a, b = V[bd[0]], V[bd[1]]
    l = cevian_lines(V, bd[0], bd[1])[0]
    # write the endpoint nearer e_l as (1-tau) far + tau e_l
    def tau_of(far, near):
        m = [i for i in range(3) if i != l][0]
        return 1 - near[m] / far[m]
    tau = tau_of(a, b)
    if not (0 < tau < 1):
        a, b = b, a; tau = tau_of(a, b)
    assert 0 < tau < 1 and lin((1 - tau, a), (tau, E[l])) == b
    lo = list(a); hi = list(a); hi[l] = a[l] + tau / (1 - tau)
    eps = Fr(1, 2)
    while True:
        k = lin((1 + eps, c), (-eps, E[j]))
        if all(x > 0 for x in bary(V, k)): break
        eps /= 2
    return dict(k=k, c=c, j=j, lo=tuple(lo), hi=tuple(hi), far=a, near=b, l=l, eps=eps)

# (A)
nX = 0; fails = 0; tang_ok = 0; strong2 = 0
cats = {}
while nX < 2000:
    V = gen()
    if det(*V) == 0: continue
    cat, nc = classify(V)
    cats[(nc, cat)] = cats.get((nc, cat), 0) + 1
    if cat != 'X': continue
    nX += 1
    B = build(V)
    ok = all(x > 0 for x in bary(V, B['k']))
    ok &= lin((1/(1 + B['eps']), B['k']), (B['eps']/(1 + B['eps']), E[B['j']])) == B['c']
    ok &= all(0 < B['lo'][i] <= B['hi'][i] for i in range(3))
    corners = [tuple(B['hi'][i] if (m >> i) & 1 else B['lo'][i] for i in range(3)) for m in range(8)]
    ok &= set(nu(x) for x in corners) == {B['far'], B['near']}
    H = [lift(x) for x in hull2([B['k'], B['c']] + [nu(x) for x in corners])]
    ok &= set(H) == set(V)
    if not ok: fails += 1
    # (C)
    ni = V.index(B['near']); fi = V.index(B['far'])
    if wtype(V, ni, B['l']) == 'T': tang_ok += 1
    if sum(strong_nonvisible(V, x) for x in range(3)) >= 2: strong2 += 1
pr('(A) class-X triangles: %d ; Theorem BX hypotheses + exact hull = T failures: %d' % (nX, fails))
pr('    category counts in the generated sample (ncev, cat):', dict(sorted(cats.items())))
pr('(C) near endpoint tangential from l: %d / %d ; triangles with >= 2 O61-strong non-visible vertices: %d' % (tang_ok, nX, strong2))

# (B)
tri = 0; ncevfail = 0; counts = {}
for _ in range(3000):
    lo = [Fr(rng.randint(1, 30), rng.randint(1, 5)) for _ in range(3)]
    hi = [x + (Fr(rng.randint(0, 30), rng.randint(1, 5)) if rng.random() < 0.7 else 0) for x in lo]
    corners = [tuple(hi[i] if (m >> i) & 1 else lo[i] for i in range(3)) for m in range(8)]
    H = [lift(x) for x in hull2([nu(x) for x in corners])]
    nv = len(H); ndeg = sum(1 for i in range(3) if lo[i] == hi[i])
    counts[(ndeg, nv)] = counts.get((ndeg, nv), 0) + 1
    if nv == 3: tri += 1
    if nv >= 3:
        for i in range(nv):
            A_, B_ = H[i], H[(i + 1) % nv]
            if not any(det(A_, B_, E[l]) == 0 for l in range(3)): ncevfail += 1
pr('(B) random normalised boxes: (degenerate coords, hull vertex count) ->', dict(sorted(counts.items())))
pr('    triangles found: %d ; non-cevian hull edges: %d' % (tri, ncevfail))

# (D)
pts = sorted(set(nu((a, b, S - a - b)) for S in range(3, 11) for a in range(1, S) for b in range(1, S - a) if S - a - b >= 1))
cnt = {}
for P in itertools.combinations(pts, 3):
    V = list(P)
    if det(*V) == 0: continue
    cat, nc = classify(V)
    if nc not in (1, 2): continue
    cnt[(nc, cat)] = cnt.get((nc, cat), 0) + 1
pr('(D) small-integer triangles with 1 or 2 cevian edges, by (ncev, class):', dict(sorted(cnt.items())))
pr('    total %d ; class X total %d' % (sum(cnt.values()), sum(v for (n, c), v in cnt.items() if c == 'X')))
open(__file__.replace('.py', '.out'), 'w').write('\n'.join(OUT) + '\n')
