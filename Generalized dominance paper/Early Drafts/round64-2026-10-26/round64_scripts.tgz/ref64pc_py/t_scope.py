"""REF64_pc (d),(f): scoped exclusions for T, re-derived independently.
 (1) concave single chart: the ray system;
 (2) continuous PL single chart: corner value system rank, for pi* = 1 AND for pi* with zeros;
 (3) V_B (one common Brier weight): a direct proof of the one-world-tangency step at s for T
     (O61 Cor A(d) specialised to T), with exact witness numbers;
 (4) the box chart cover is consistent with O61 Thm B: the forced-face system on F_p, F_s is solvable;
 (5) the paper's open-problem test triangle conv{(1,6,1)/8,(6,1,3)/10,(6,1,1)/8}: its class.
Run: python3 -I t_scope.py"""
import sys
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from rg import *
import sympy as sp

OUT = []
def pr(*a):
    s = ' '.join(str(x) for x in a); OUT.append(s); print(s)

p = (Fr(1,5), Fr(2,5), Fr(2,5)); q = (Fr(2,5), Fr(1,5), Fr(2,5)); s = (Fr(3,5), Fr(1,5), Fr(1,5))
V = [p, q, s]
rpq, rps, rqs = edge_ray(V,0,1), edge_ray(V,0,2), edge_ray(V,1,2)
facets = {'F_p': (rpq, rps), 'F_q': (rpq, rqs), 'F_s': (rps, rqs)}

pr('=== (1) concave single chart ===')
for nmF, (a, b) in facets.items():
    pr('  %s: relint crossing worlds %s ; end-zero worlds %s' % (nmF, [m+1 for m in range(3) if a[m]*b[m] < 0], [m+1 for m in range(3) if a[m] == 0 or b[m] == 0]))
# at each ray, each world j with r_j != 0 must cross on an adjacent facet
adj = {'rpq': (rpq, ['F_p','F_q']), 'rps': (rps, ['F_p','F_s']), 'rqs': (rqs, ['F_q','F_s'])}
ok = True
for nmr, (r, fs) in adj.items():
    for j in range(3):
        if r[j] == 0: continue
        if not any(facets[f][0][j]*facets[f][1][j] < 0 for f in fs): ok = False
pr('  every world with r_j != 0 crosses on a facet adjacent to r:', ok)
M = sp.Matrix([[sp.Rational(z) for z in r] for r in (rpq, rqs, rps)])
pr('  ray matrix det =', M.det(), '; integer rays (2,2,-3),(-1,4,-1),(0,-1,1) det =', sp.Matrix([[2,2,-3],[-1,4,-1],[0,-1,1]]).det())

pr('\n=== (2) continuous PL single chart: corner value system ===')
def value_rank(pi):
    # unknowns: c at the three rays, each in pi^perp (2 dof); use 3 coords + constraint pi.c = 0
    C = {nm: sp.symbols(nm + '_1:4') for nm in ('rpq', 'rps', 'rqs')}
    R = {'rpq': rpq, 'rps': rps, 'rqs': rqs}
    eqs = []
    for nm in C:
        eqs.append(sum(sp.Rational(pi[j]) * C[nm][j] for j in range(3)))          # pi.c = 0 on boundary
        for m in range(3):
            if R[nm][m] == 0: eqs.append(C[nm][m])                                   # sign-correctness at a zero coordinate
    fac = {'F_p': ('rpq', 'rps'), 'F_q': ('rpq', 'rqs'), 'F_s': ('rps', 'rqs')}
    for f, (e1, e2) in fac.items():
        r1, r2 = R[e1], R[e2]
        for m in range(3):
            if r1[m]*r2[m] < 0:   # crossing row: c_m = lambda h_m on the facet
                eqs.append(sp.Rational(r2[m]) * C[e1][m] - sp.Rational(r1[m]) * C[e2][m])
    syms = [x for nm in C for x in C[nm]]
    A = sp.Matrix([[sp.diff(e, x) for x in syms] for e in eqs])
    return A.rank(), len(syms)
for pi in [(1,1,1), (1,2,2), (0,1,1), (1,0,1), (1,1,0), (2,3,7)]:
    rk, nv = value_rank(pi)
    pr('  pi* = %s: rank %d of %d unknowns (full rank => c = 0 at all three rays)' % (pi, rk, nv))
pi1, pi2, pi3 = sp.symbols('pi1 pi2 pi3', positive=True)

pr('\n=== (3) V_B exclusion for T without citing O61 Cor A(d) ===')
pr('  Thm A steps 1-3 at the strongly non-visible vertex p give pi = p (pi perp F_p, pi in T).')
pr('  Collar beyond F_s: need a non-null open set O in N with s.h < 0 < p.h.')
r = (Fr(0), Fr(-1), Fr(1))           # the ray r_ps (scaled), h1 = 0
gam, dl = Fr(1,10), Fr(8,100)        # need s1*gam < dl < gam, s1 = 3/5
assert s[0]*gam < dl < gam
pp = lin((1, r), (gam, E[0]), (-dl, (1,1,1)))
rp = lin((1, r), (Fr(1,2), (-1, 4, -1)))     # a relint point of F_s
assert dot(s, rp) == 0 and dot(p, rp) > 0 and dot(q, rp) > 0 and rp[2] > 0
zeta, lam = Fr(1, 1000), Fr(1, 10)
qq = lin((1, rp), (zeta, (1,1,1)))
hs = lin((lam, pp), (1 - lam, qq))
pr('  p\' = r + g e1 - d 1 =', [str(z) for z in pp], ': h1 = %s > 0, h3 = %s > 0, s.p\' = %s, p.p\' = %s' % (pp[0], pp[2], dot(s,pp), dot(p,pp)))
pr('  q\' = r\' + z 1 (r\' in relint F_s) =', [str(z) for z in qq], ': in D_T:', all(dot(v,qq) > 0 for v in V), ', h3 > 0:', qq[2] > 0)
pr('  h* = (1/10) p\' + (9/10) q\' =', [str(z) for z in hs], ': s.h* = %s < 0, p.h* = %s > 0, q.h* = %s' % (dot(s,hs), dot(p,hs), dot(q,hs)))
assert dot(s, hs) < 0 < dot(p, hs) and pp[0] > 0 and pp[2] > 0 and qq[2] > 0
pr('  => X_{13} (= Z_1 cap A cap {h3>0}, coherent, contains A cap {h1>0,h3>0} and D_T cap {h3>0}) contains a ball')
pr('     around h*; Lemma 4 (k = 2,3) puts balls around relint F_s into Z_2, Z_3; so a ball around h* lies in N')
pr('     a.e., inside {p.h > 0} and outside cl D_T, contradicting D_T = N cap {p.h > 0} a.e.  (Scaling: take')
pr('     g, d, z small and lambda small so all points lie in the (LF) neighbourhood; the inequalities are homogeneous.)')

pr('\n=== (4) the box-chart cover vs O61 Thm B (forced faces F_p, F_s only) ===')
x2, x3 = sp.symbols('x2 x3')
# Gamma = pi1*l1 - x2 h2 - x3 h3 with l1 sign-correct, l1 = 0 on {h1 = 0}; at r_ps (h1 = 0): Gamma(r_ps) = 0
eq = -x2*rps[1] - x3*rps[2]
pr('  Gamma(r_ps) = 0 gives', sp.Eq(sp.nsimplify(eq), 0), '=> x2 = x3; F_q is outside int N (q.h = 0 there), so no equation at F_q.')
c_box = lambda h: -min(5*dot(p,h), 10*dot(s,h))
pr('  box cover: Gamma = -min(5p.h,10s.h); on rays: rpq %s, rps %s, rqs %s (0 on F_p, F_s; F_q not forced)'
   % (c_box(rpq), c_box(rps), c_box(rqs)))

pr('\n=== (5) the paper\'s test triangle ===')
Tt = [(Fr(1,8), Fr(6,8), Fr(1,8)), (Fr(6,10), Fr(1,10), Fr(3,10)), (Fr(6,8), Fr(1,8), Fr(1,8))]
for i in range(3):
    pr('  vertex %s: types %s, strictly visible from %s, strong non-visible %s'
       % ([str(z) for z in Tt[i]], types(Tt, i), [j+1 for j in range(3) if strictly_visible_direct(Tt, i, j)], strong_nonvisible(Tt, i)))
for (i, j) in ((0,1),(0,2),(1,2)):
    pr('  edge (%d,%d) line through simplex vertices %s' % (i, j, [l+1 for l in cevian_lines(Tt, i, j)]))
bd = bad(Tt)
cev_bad = len(bd) == 2 and bool(cevian_lines(Tt, *bd))
pr('  bad vertices:', bd, '; edge joining them cevian:', cev_bad, '=> class', 'X (covered by Thm BX)' if cev_bad else 'N/other')
open(__file__.replace('.py', '.out'), 'w').write('\n'.join(OUT) + '\n')
