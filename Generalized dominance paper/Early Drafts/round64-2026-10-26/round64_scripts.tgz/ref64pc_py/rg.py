"""REF64_pc: referee's own exact geometry helpers (Fractions only; written independently of pc64py)."""
from fractions import Fraction as Fr
from itertools import combinations

E = [(Fr(1), Fr(0), Fr(0)), (Fr(0), Fr(1), Fr(0)), (Fr(0), Fr(0), Fr(1))]


def dot(a, b):
    return sum(Fr(x) * Fr(y) for x, y in zip(a, b))


def crs(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def det(a, b, c):
    return dot(a, crs(b, c))


def lin(*terms):
    """lin((s1,v1),(s2,v2),...) = sum s_i v_i"""
    out = [Fr(0)] * 3
    for s, v in terms:
        for i in range(3):
            out[i] += Fr(s) * Fr(v[i])
    return tuple(out)


def nu(v):
    t = sum(Fr(x) for x in v)
    return tuple(Fr(x) / t for x in v)


def bary(V, x):
    """barycentric coordinates of x w.r.t. the triangle V (rows)."""
    D = det(*V)
    out = []
    for i in range(3):
        W = list(V)
        W[i] = x
        out.append(det(*W) / D)
    return out


def edge_ray(V, i, j):
    """generator of cl D_T orthogonal to V[i], V[j], positive on the third vertex."""
    k = 3 - i - j
    r = crs(V[i], V[j])
    if dot(V[k], r) < 0:
        r = tuple(-x for x in r)
    assert dot(V[i], r) == 0 and dot(V[j], r) == 0 and dot(V[k], r) > 0
    return r


def gens(V, k):
    """the two generators of F_{V[k]} = cl D_T cap V[k]^perp."""
    i, j = [x for x in range(3) if x != k]
    return edge_ray(V, k, i), edge_ray(V, k, j)


def wtype(V, k, w):
    a, b = [g[w] for g in gens(V, k)]
    if a < 0 and b < 0:
        return 'S'
    if a <= 0 and b <= 0:
        return 'T'
    if a >= 0 and b >= 0:
        return 'A'
    return 'C'


def types(V, k):
    return ''.join(wtype(V, k, w) for w in range(3))


def strictly_visible_direct(V, k, j):
    """Definition test: V[k] + t (V[k] - e_j) in relint T for small t > 0.
    Barycentric coords are affine: bary(V[k]) = e_k, so we need the barycentric
    *direction* d = bary-direction of (V[k]-e_j) to be > 0 off k (then for small t all
    coordinates are > 0, the k-th being close to 1)."""
    y = lin((1, V[k]), (-1, E[j]))
    # direction vector (sums to 0): solve sum_i d_i V[i] = y with sum d_i = 0
    # since sum(y)=0 and V rows sum to 1, Cramer with 'bary' gives d.
    d = bary(V, y)
    return all(d[i] > 0 for i in range(3) if i != k)


def bad(V):
    return [k for k in range(3) if not any(strictly_visible_direct(V, k, j) for j in range(3))]


def cevian_lines(V, i, j):
    """simplex vertices e_l on the line through V[i], V[j]."""
    return [l for l in range(3) if det(V[i], V[j], E[l]) == 0]


def strong_nonvisible(V, k):
    """O61 sense: F_v meets {h_j > 0} for every world j."""
    g = gens(V, k)
    return all(max(g[0][w], g[1][w]) > 0 for w in range(3))


def hull2(points):
    """vertices of the convex hull of points in aff Delta (exact), via projection to (x0,x1)."""
    P = sorted(set((p[0], p[1]) for p in points))
    if len(P) <= 2:
        return P

    def cr(o, a, b):
        return (a[0]-o[0])*(b[1]-o[1]) - (a[1]-o[1])*(b[0]-o[0])
    lower, upper = [], []
    for p in P:
        while len(lower) >= 2 and cr(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(P):
        while len(upper) >= 2 and cr(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def lift(xy):
    return (xy[0], xy[1], 1 - xy[0] - xy[1])
