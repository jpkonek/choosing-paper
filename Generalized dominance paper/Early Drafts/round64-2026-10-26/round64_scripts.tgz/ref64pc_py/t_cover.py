"""REF64_pc (a): exact referee checks of the cover of T = conv{p,q,s}.
Run: python3 -I t_cover.py  (writes t_cover.out)."""
import sys, random
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from rg import *
import sympy as sp

OUT = []
def pr(*a):
    s = ' '.join(str(x) for x in a); OUT.append(s); print(s)

p = (Fr(1,5), Fr(2,5), Fr(2,5)); q = (Fr(2,5), Fr(1,5), Fr(2,5)); s = (Fr(3,5), Fr(1,5), Fr(1,5))
V = [p, q, s]; nm = 'pqs'
k = (Fr(22,50), Fr(11,50), Fr(17,50))

pr('=== 1. Geometry ===')
assert det(*V) != 0 and all(x > 0 for v in V for x in v)
for (i, j) in ((0,1),(0,2),(1,2)):
    pr('edge [%s,%s] ray %s ; simplex vertices on its line: %s' % (nm[i], nm[j], edge_ray(V,i,j), [l+1 for l in cevian_lines(V,i,j)]))
for kk in range(3):
    sv = [j+1 for j in range(3) if strictly_visible_direct(V, kk, j)]
    pr('vertex %s: gens %s ; types %s ; strictly visible (definition test) from %s ; O61-strong non-visible: %s'
       % (nm[kk], gens(V,kk), types(V,kk), sv, strong_nonvisible(V,kk)))
    assert [j for j in range(3) if types(V,kk)[j]=='S'] == [j-1 for j in sv]
pr('bad (not strictly visible) vertices:', [nm[x] for x in bad(V)])
assert bad(V) == [0, 2]

pr('\n=== 2. Data of the construction ===')
b = bary(V, k); pr('bary(k) w.r.t. (p,q,s) =', b); assert b == [Fr(1,10), Fr(3,5), Fr(3,10)]
assert lin((Fr(10,11), k), (Fr(1,11), E[2])) == q
pr('q = (10/11)k + (1/11)e3 exactly: True')
assert nu((1,2,2)) == p and nu((6,2,2)) == s
pr('nu(1,2,2) = p, nu(6,2,2) = s: True')
# K = conv({k} u {q} u [p,s]) = T (k in T, so hull vertices are p,q,s)
H = [lift(x) for x in hull2([k, q, p, s])]
pr('hull vertices of {k,q,p,s}:', H); assert set(H) == set(V)

pr('\n=== 3. Symbolic identity and sign-correctness of the chart ===')
h1, h2, h3 = sp.symbols('h1 h2 h3', real=True)
c1 = sp.Min(h1, 6*h1)
lhs = c1 + 2*h2 + 2*h3
r5p = h1 + 2*h2 + 2*h3; r10s = 6*h1 + 2*h2 + 2*h3
# case h1 >= 0: min(h1,6h1) = h1 ; case h1 < 0: = 6h1
pos = sp.Symbol('x', nonnegative=True); neg = sp.Symbol('y', negative=True)
okpos = sp.simplify(lhs.subs(h1, pos) - sp.Min(r5p, r10s).subs(h1, pos)) == 0
okneg = sp.simplify(lhs.subs(h1, neg) - sp.Min(r5p, r10s).subs(h1, neg)) == 0
pr('min(h1,6h1)+2h2+2h3 == min(5p.h,10s.h) on h1>=0:', okpos, '; on h1<0:', okneg)
pr('(6,2,2).h - (1,2,2).h =', sp.expand(r10s - r5p))
# c(h + t1) >= c(h) + t l : for a scalar chart min(l x, u x), 0<l<=u, t>=0
x, t = sp.symbols('x t', real=True)
for (L, U_) in ((1, 6), (2, 2)):
    f = lambda z: sp.Min(L*z, U_*z)
    # piecewise: check on the three regions x>=0; x<0<=x+t; x+t<0
    xs = sp.Symbol('xs', nonnegative=True); ts = sp.Symbol('ts', nonnegative=True)
    r1 = sp.simplify(f(xs+ts) - f(xs) - L*ts)
    xn = sp.Symbol('xn', negative=True)
    r3 = sp.simplify(sp.Min(L*(xn - ts), U_*(xn - ts)) - sp.Min(L*xn, U_*xn) + L*ts)  # f(x-t)... not used
    pr('  l=%d,u=%d: on x>=0: c(x+t)-c(x)-l t =' % (L, U_), r1)
# general region check by exact random rationals (superadditivity), all three regions
rng = random.Random(64064)
def rq(M=60, D=13):
    return Fr(rng.randint(-M, M), rng.randint(1, D))
def chart(h):
    return (min(h[0], 6*h[0]), 2*h[1], 2*h[2])
fails = 0
for _ in range(30000):
    h = (rq(), rq(), rq()); tt = abs(rq())
    c = chart(h); ct = chart(tuple(z + tt for z in h))
    if not (ct[0] >= c[0] + tt and ct[1] == c[1] + 2*tt and ct[2] == c[2] + 2*tt): fails += 1
    if any((c[j] > 0) != (h[j] > 0) or (c[j] < 0) != (h[j] < 0) for j in range(3)): fails += 1
    if sum(c) != min(5*dot(p,h), 10*dot(s,h)): fails += 1
pr('exact random: c(h+t1) >= c(h)+t l, sign(c)=sign(h), identity : failures =', fails)

pr('\n=== 4. (G) at world 3: veto vanishes on U cap {h3 >= 0} ===')
pr('q.h = (10/11) k.h + (1/11) h3 identically (from the identity in §2), so k.h > 0, h3 >= 0 => q.h > 0 => phi3 = 0.')
pr('Worlds 1,2 have no veto; their charts are sign-correct (§3). Hence strict (G) at every world (W62 lem:axioms argument).')

pr('\n=== 5. Domain, one-sidedness, (LF), margin ===')
rays = [edge_ray(V,i,j) for (i,j) in ((0,1),(0,2),(1,2))]
vals = [dot(k, r) for r in rays]
pr('k.r at the extreme rays:', vals); assert all(v > 0 for v in vals)
import math
marg = min(float(dot(k, r)) / math.sqrt(sum(float(z)**2 for z in r)) for r in rays)
pr('angular margin min k.r/|r| = %.5f > 0 (so cl D_T \\ 0 lies in the open half-space U; LF with N = U)' % marg)
pr('U = {k.h > 0} is an open half-space: U cap -U = empty (one-sided), convex, decomposable model class M_U.')

pr('\n=== 6. Target triple (Omega, beta=1, no alpha): X* = U cap {phi3=0} cap {sum c > 0} ===')
pr('sum c = min(5p.h, 10s.h) > 0  <=>  p.h > 0 and s.h > 0  (exact, §3).')
pr('{phi3 = 0} = {q.h >= 0} = D_q u {q.h = 0}; the hyperplane is null.')
pr('D_{p,q,s} subset D_k since k = (1/10)p + (3/5)q + (3/10)s (exact barycentrics) => k.h = positive combination.')
pr('Hence X* = D_k cap D_q cap D_p cap D_s = D_T a.e.  Exact sample check below (all-strict gambles only):')
mis = 0; n = 0
for _ in range(40000):
    h = (rq(), rq(), rq())
    if dot(k,h) <= 0 or any(dot(v,h) == 0 for v in V): continue
    n += 1
    xs = dot(q,h) >= 0 and sum(chart(h)) > 0
    dt = all(dot(v,h) > 0 for v in V)
    if xs != dt: mis += 1
pr('  gambles in U tested: %d, mismatches: %d' % (n, mis))
open(__file__.replace('.py', '.out'), 'w').write('\n'.join(OUT) + '\n')
