"""REF64_or: independent exhaustive checks of OR64's record systems M1, M1b and T,
on richer atom sets than OR64 used, with a different implementation:
the relation at each world is a boolean matrix L[X,Y] = (X <=_w Y) over ALL models (bitmasks),
and (TC) is checked for ALL triples at once via the boolean product L@L.

Atom = a non-null measurable cell with a fixed sign pattern (h_1,h_2,h_3); models = unions of atoms.
A relation defined on records (X\\Y, Y\\X) satisfies (IB) by construction (Prop 1.1 of OR64, checked by hand).
Run: python3 -I tcmat.py > tcmat.out
"""
import itertools
import numpy as np

ok = True
def check(name, cond):
    global ok
    cond = bool(cond)
    print(('PASS ' if cond else 'FAIL ') + name, flush=True)
    ok = ok and cond

class Sys:
    def __init__(self, signs, tags):
        self.signs = signs; self.tags = tags; self.n = len(signs); self.NM = 1 << self.n
        self.pos = [sum(1 << a for a, s in enumerate(signs) if s[w] > 0) for w in range(3)]
        self.neg = [sum(1 << a for a, s in enumerate(signs) if s[w] < 0) for w in range(3)]
        X = np.arange(self.NM, dtype=np.int32)
        self.P = (X[:, None] & ~X[None, :])     # X \ Y
        self.N = (X[None, :] & ~X[:, None])     # Y \ X
    def tagged(self, t):
        return sum(1 << a for a in range(self.n) if t in self.tags[a])
    def guided(self, w, P, N):                 # vectorised
        return ((P & ~self.pos[w]) == 0) & ((N & ~self.neg[w]) == 0)
    def build(self, accfun):
        self.L = [accfun(w, self.P, self.N) for w in range(3)]
    def le(self, w, X, Y): return bool(self.L[w][X, Y])
    def lt(self, w, X, Y): return self.le(w, X, Y) and not self.le(w, Y, X)
    def dom(self, Y, X):
        return all(self.le(w, Y, X) for w in range(3)) and any(self.lt(w, Y, X) for w in range(3))
    def axioms(self, label, expect_tc=True):
        res = {}
        for w in range(3):
            L = self.L[w]
            res.setdefault('refl', True); res['refl'] &= bool(np.all(np.diag(L)))
            G = self.guided(w, self.P, self.N) & (self.P | self.N != 0)
            res.setdefault('sg', True); res['sg'] &= bool(np.all(L[G]) and not np.any(L.T[G]))
            Lf = L.astype(np.float32)
            M = (Lf @ Lf) > 0.5                  # exists B: A<=B<=C
            strictCA = L.T & ~L                  # [A,C] -> C < A
            viol = int(np.count_nonzero(M & strictCA))
            res.setdefault('tcviol', 0); res['tcviol'] += viol
            res.setdefault('nontrans', 0); res['nontrans'] += int(np.count_nonzero(M & ~L))
            ties = L & L.T
            np.fill_diagonal(ties, False)
            res.setdefault('ties', 0); res['ties'] += int(np.count_nonzero(ties))
        check(f"{label}: reflexive at every world", res['refl'])
        check(f"{label}: strict (G) at every world (all {self.NM}^2 pairs)", res['sg'])
        if expect_tc:
            check(f"{label}: (TC) at every world, ALL triples (via boolean product)", res['tcviol'] == 0)
        else:
            check(f"{label}: (TC) FAILS somewhere (expected), #violating (A,C) pairs = {res['tcviol']}", res['tcviol'] > 0)
        print(f"   {label}: pairs (A,C) with A<=B<=C for some B but A not<= C: {res['nontrans']}; "
              f"non-trivial one-world ties: {res['ties']}")
        return res

# ------------------------------------------------------------------ M1 on 12 atoms (all sign patterns, R = two atoms)
print("== M1 (12 atoms: every sign pattern at least once; R has 3 atoms) ==")
i, j, k = 0, 1, 2
pats = list(itertools.product((1, -1), repeat=3))
signs = [(1, -1, 1), (-1, 1, 1), (1, 1, -1)]       # E, A, B
tags = [{'E', 'R'}, {'A'}, {'B'}]
for p in pats:                                       # one more atom of every pattern
    signs.append(p); tags.append(set())
signs.append((-1, -1, 1)); tags.append({'R'})        # extra R atom (j-wrong)
# mark the R-atoms among the generic ones: the (+,-,-) generic atom also in R
idx = signs.index((1, -1, -1), 3); tags[idx] = {'R'}
assert len(signs) == 12
S = Sys(signs, tags)
E, A, B = 1, 2, 4
R = S.tagged('R')
assert all(signs[a][j] < 0 for a in range(S.n) if R >> a & 1)
r0 = (E | A, B)
def accM1(w, P, N):
    g = S.guided(w, P, N)
    if w in (i, j):
        g = g | ((P == r0[0]) & (N == r0[1]))
    return g
S.build(accM1)
S.axioms("M1")
full = S.NM - 1
MR = (full & ~R) & S.neg[j]
Xi = (full & ~R) & S.pos[i]
Y0 = (Xi & ~B) | E | A
check("M1: R is an E61 priority region at j (no Y meeting R has Y <=_j M_R)",
      not np.any(S.L[j][[Y for Y in range(S.NM) if Y & R], MR]))
check("M1: Y0 dominates X_i (box lemma conclusion fails)", S.dom(Y0, Xi))
undomXi = not any(S.dom(Y, Xi) for Y in range(S.NM))
check("M1: X_i is dominated (by some model)", not undomXi)
check("M1: R not strong (Y0 <=_j X_i, Y0 meets R, X_i avoids R)", S.le(j, Y0, Xi) and (Y0 & R) and not (Xi & R))

print("== M1b: add rec(M_R, Y) at j for every Y meeting R (strict priority) ==")
Srec = set((MR & ~Y, Y & ~MR) for Y in range(S.NM) if Y & R)
SP = np.zeros_like(S.L[0])
for (p, q) in Srec:
    SP |= (S.P == p) & (S.N == q)
Lj_b = S.L[j] | SP
Lsave = S.L[j]; S.L[j] = Lj_b
S.axioms("M1b", expect_tc=False)
check("M1b: R is a strict priority region at j", all(S.lt(j, MR, Y) for Y in range(S.NM) if Y & R))
check("M1b: X_i still dominated by Y0", S.dom(Y0, Xi))
S.L[j] = Lsave

# ------------------------------------------------------------------ T on 13 atoms
print("== T (IN = all 7 sign patterns other than ---, OUT = all 6 patterns other than +++ and ---) ==")
INp = [p for p in pats if p != (-1, -1, -1)]
OUTp = [p for p in pats if p not in ((1, 1, 1), (-1, -1, -1))]
signs = INp + OUTp
tags = [{'IN'}] * len(INp) + [{'OUT'}] * len(OUTp)
T = Sys(signs, tags)
IN, OUT = T.tagged('IN'), T.tagged('OUT')
def accT(w, P, N):
    g = T.guided(w, P, N)
    nonnull = (P | N) != 0
    toward = ((P & ~IN) == 0) & ((N & ~OUT) == 0)
    anti = nonnull & T.guided(w, N, P)
    return g | (toward & nonnull & ~anti)
T.build(accT)
resT = T.axioms("T")
check("T: no non-trivial tie at any world (so direct (C) holds trivially)", resT['ties'] == 0)
DK = IN
NM = T.NM
# undominated set
LL = [T.L[w] for w in range(3)]
weak = LL[0] & LL[1] & LL[2]                     # weak[Y,X]: Y weakly dominates X
strict_some = (LL[0] & ~LL[0].T) | (LL[1] & ~LL[1].T) | (LL[2] & ~LL[2].T)
domm = weak & strict_some                        # domm[Y,X]: Y dominates X
undom = ~np.any(domm, axis=0)
I_set = np.zeros(NM, dtype=bool)
for X in range(NM):
    I_set[X] = any(((X & ~DK) & ~T.pos[w]) == 0 and ((DK & ~X) & ~T.neg[w]) == 0 for w in range(3))
check("T: D_K undominated", undom[DK])
check("T: undominated set = one-world improvements of D_K (incl. D_K)", np.array_equal(undom, I_set))
print(f"   |models| = {NM}, |undominated| = {int(undom.sum())}")
check("T: D_K strictly dominates every model outside I",
      all(all(T.lt(w, DK, X) for w in range(3)) for X in range(NM) if not I_set[X]))
collar = [P for P in range(1, NM) if (P & ~OUT) == 0 and all(P & T.neg[w] for w in range(3))]
check(f"T: every one of the {len(collar)} additions P (P in OUT, wrong somewhere at every world) is refused at every world",
      all(not T.le(w, DK | P, DK) for w in range(3) for P in collar))
# (VA) holds in T with R_j := OUT & neg_j: (VA2) trivial (C \ R_j is j-correct, guided), (VA1): X_i undominated
va1 = True
for jj in range(3):
    Rj = OUT & T.neg[jj]
    for ii in range(3):
        if ii == jj: continue
        Xi_ = (full_T := NM - 1) & ~Rj & T.pos[ii]
        va1 &= bool(undom[Xi_])
check("T: with R_j := OUT & neg_j every dented box (U\\R_j) & pos_i is undominated, so (VA1) holds; "
      "(VA2) holds trivially since C\\R_j is j-correct", va1)
va2 = all(T.le(jj, DK | P, DK) for jj in range(3) for P in range(1, NM)
          if (P & ~(OUT & ~T.neg[jj])) == 0)
check("T: (VA2)-analogue: D_K u P <=_j D_K for every P in OUT \\ R_j", va2)
print("ALL PASS" if ok else "SOME FAIL")
