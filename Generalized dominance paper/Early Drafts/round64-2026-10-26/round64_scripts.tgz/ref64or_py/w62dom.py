"""REF64_or: W62 Lemma `lem:dominance`, (C)-step, needs transitivity, not only completeness of the
last step.  Record system on atoms:
   a  = (+,+,+)   (correct at every world)
   b1 = (+,-,-), b2 = (-,+,-), b3 = (-,-,+)  (each correct at exactly one world)
   plus extra atoms c = (+,+,-), d = (-,+,+)   (to make the check less special)
Acc_w := guided records at w  together with  t := ({b1,b2,b3},{a})  and its inverse t^{-1}, at EVERY world.
Claims checked exhaustively over all model triples:
   reflexive, strict (G), (IB) (by construction), (TC) at every world;
   Y := {a} u {c,d} is undominated; X := {b1,b2,b3} u {c,d} is tied with Y at every world;
   X is dominated (by X u {a}).
So "X tied at every world with an undominated Y" does not make X undominated under (TC) alone:
W62's derivation of (C) ("Z dominates X => Z dominates Y") uses transitivity.
Run: python3 -I w62dom.py > w62dom.out
"""
import numpy as np
ok = True
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name); ok = ok and bool(cond)

signs = [(1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1), (1, 1, -1), (-1, 1, 1)]
n = len(signs); NM = 1 << n
a, b1, b2, b3, c, d = (1 << q for q in range(n))
pos = [sum(1 << q for q in range(n) if signs[q][w] > 0) for w in range(3)]
neg = [sum(1 << q for q in range(n) if signs[q][w] < 0) for w in range(3)]
Xs = np.arange(NM)
P = Xs[:, None] & ~Xs[None, :]; N = Xs[None, :] & ~Xs[:, None]
t = (b1 | b2 | b3, a)
def acc(w):
    g = ((P & ~pos[w]) == 0) & ((N & ~neg[w]) == 0)
    return g | ((P == t[0]) & (N == t[1])) | ((P == t[1]) & (N == t[0]))
L = [acc(w) for w in range(3)]
refl = all(np.all(np.diag(L[w])) for w in range(3))
sg = True; tc = True
for w in range(3):
    G = (((P & ~pos[w]) == 0) & ((N & ~neg[w]) == 0)) & ((P | N) != 0)
    sg &= bool(np.all(L[w][G]) and not np.any(L[w].T[G]))
    Lf = L[w].astype(np.int64)
    M = (Lf @ Lf) > 0
    tc &= not np.any(M & L[w].T & ~L[w])
check("reflexive", refl); check("strict (G)", sg); check("(TC) at every world, all triples", tc)
nontrans = sum(int(np.count_nonzero(((L[w].astype(np.int64) @ L[w].astype(np.int64)) > 0) & ~L[w])) for w in range(3))
print("   non-transitive (A,C) pairs:", nontrans)
weak = L[0] & L[1] & L[2]
strict = (L[0] & ~L[0].T) | (L[1] & ~L[1].T) | (L[2] & ~L[2].T)
dom = weak & strict
Y = a | c | d; X = b1 | b2 | b3 | c | d
check("X and Y tied at every world", all(L[w][X, Y] and L[w][Y, X] for w in range(3)))
check("Y undominated", not np.any(dom[:, Y]))
check("X dominated by X u {a}", bool(dom[X | a, X]))
Z = X | a
print("   at the dominating chain Z <= X <= Y:", [(bool(L[w][Z, X]), bool(L[w][X, Y]), bool(L[w][Z, Y]), bool(L[w][Y, Z])) for w in range(3)],
      "(Z,Y incomparable at every world)")
print("ALL PASS" if ok else "SOME FAIL")
