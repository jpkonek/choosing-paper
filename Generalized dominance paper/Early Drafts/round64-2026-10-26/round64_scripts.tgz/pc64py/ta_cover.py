"""PC64: exact certificate for the veto-box cover of the partially cevian triangle
   T = conv{p, q, s},  p = (1,2,2)/5,  q = (2,1,2)/5,  s = (3,1,1)/5.

Ranking on M_U, U = D_{K'}, K' = {k}, k = (22,11,17)/50:
  world 1:  -int_X c1,               c1(h) = min(h1, 6 h1)
  world 2:  -int_X c2,               c2(h) = 2 h2
  world 3:  (int_X max(0,-q.h), -int_X c3) lexicographically,  c3(h) = 2 h3
i.e. a veto (A_3 = {q}) followed by the box chart c_j = min(l_j h_j, u_j h_j), l=(1,2,2), u=(6,2,2).
All checks exact (Fraction / sympy)."""
import sys, random, itertools
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from geom import *
import sympy as sp

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); out.append(s); print(s)

p = (F(1,5), F(2,5), F(2,5)); q = (F(2,5), F(1,5), F(2,5)); s = (F(3,5), F(1,5), F(1,5))
V = [p, q, s]
names = ['p', 'q', 's']
l = (F(1), F(2), F(2)); u = (F(6), F(2), F(2))

pr('== 1. Geometry of T ==')
assert is_triangle_interior(V)
for (i, j) in ((0, 1), (0, 2), (1, 2)):
    r = ray(V, i, j)
    on = [lab for lab in range(3) if det3(V[i], V[j], E[lab]) == 0]
    pr('edge [%s,%s]: ray %s ; edge line through simplex vertices e_l, l in %s' % (names[i], names[j], fmt(r), [x+1 for x in on]))
pr('cevian edges (i,j,l):', cevian_edges(V))
for k in range(3):
    r1, r2 = facet_rays(V, k)
    sv = [j+1 for j in range(3) if strict_vis_ray_test(V, k, j)]
    pr('vertex %s = %s: facet generators %s, %s; world types %s; strictly visible from worlds %s (ray test %s)'
       % (names[k], fmt(V[k]), fmt(r1), fmt(r2), types(V, k), [j+1 for j in range(3) if types(V,k)[j]=='S'], sv))
    assert ([j for j in range(3) if types(V,k)[j]=='S'] == [j for j in range(3) if strict_vis_ray_test(V,k,j)])
pr('vertices not strictly visible:', [names[k] for k in bad_vertices(V)])
assert bad_vertices(V) == [0, 2]
assert len(cevian_edges(V)) == 1

pr('\n== 2. Domain and veto guidance ==')
k = (F(22,50), F(11,50), F(17,50))
# barycentric coordinates of k
D = det3(*V)
bary = []
for i in range(3):
    cols = list(V); cols[i] = k; bary.append(det3(*cols) / D)
pr('k =', fmt(k), 'barycentric w.r.t. (p,q,s):', fmt(bary), '-> k in relint T:', all(b > 0 for b in bary))
assert all(b > 0 for b in bary) and sum(bary) == 1
lam = F(10, 11)
assert add(scal(lam, k), scal(1 - lam, E[2])) == q
pr('q = (10/11) k + (1/11) e_3  : exact identity holds -> q in conv(K\' u {e_3})')


pr('(LF): k.r > 0 at the three extreme rays of cl D_T (so cl D_T minus 0 lies in the open half-space U):',
   [str(dot(k, ray(V, i, j))) for (i, j) in ((0, 1), (0, 2), (1, 2))])
assert all(dot(k, ray(V, i, j)) > 0 for (i, j) in ((0, 1), (0, 2), (1, 2)))

pr('\n== 3. Box chart: sign-correctness and the target chart identity (sympy) ==')
h1, h2, h3 = sp.symbols('h1 h2 h3', real=True)
c_pos = (h1, 2*h2, 2*h3)        # h1 >= 0 branch of c
c_neg = (6*h1, 2*h2, 2*h3)      # h1 <  0 branch
pv = (1, 2, 2); sv5 = (6, 2, 2)  # 5p and 10 s
sum_pos = sp.expand(sum(c_pos)); sum_neg = sp.expand(sum(c_neg))
pr('1.c on {h1>=0}:', sum_pos, ' = (1,2,2).h :', sp.simplify(sum_pos - (h1 + 2*h2 + 2*h3)) == 0)
pr('1.c on {h1<0}:', sum_neg, ' = (6,2,2).h :', sp.simplify(sum_neg - (6*h1 + 2*h2 + 2*h3)) == 0)
pr('on {h1>=0}: (6,2,2).h - (1,2,2).h = 5 h1 >= 0, so 1.c = min((1,2,2).h,(6,2,2).h) = min(5 p.h, 10 s.h) everywhere')
# exact random check of 1.c(h) = min(5p.h, 10 s.h) and sign correctness
rng = random.Random(6401)
def rq():
    return F(rng.randint(-60, 60), rng.randint(1, 12))
def chart(h):
    return (min(h[0], 6*h[0]), 2*h[1], 2*h[2])
bad = 0
for _ in range(20000):
    h = (rq(), rq(), rq())
    c = chart(h)
    if sum(c) != min(5*dot(p, h), 10*dot(s, h)): bad += 1
    if any(sgn(c[j]) != sgn(h[j]) for j in range(3)): bad += 1
pr('exact random check (20000 rational gambles): identity + sign-correctness failures =', bad)
assert bad == 0

pr('\n== 4. Target: N(Omega) cap {1.c > 0} = D_T ==')
def inU(h): return dot(k, h) > 0
def inDT(h): return all(dot(v, h) > 0 for v in V)
def phi3(h): return max(F(0), -dot(q, h))
bad = 0; nU = 0
for _ in range(40000):
    h = (rq(), rq(), rq())
    if not inU(h): continue
    nU += 1
    lhs = (phi3(h) == 0) and (sum(chart(h)) > 0)
    # off the null set {q.h = 0}, phi3 = 0 iff q.h > 0
    if dot(q, h) == 0: continue
    if lhs != inDT(h): bad += 1
pr('gambles in U tested: %d ; mismatches between {phi_3=0, 1.c>0} and D_T: %d' % (nU, bad))
assert bad == 0
# guidance of the veto: phi3 = 0 on U cap {h3 >= 0}
bad = 0
for _ in range(20000):
    h = (rq(), rq(), abs(rq()))
    if inU(h) and phi3(h) != 0: bad += 1
pr('veto vanishes on U cap {h3>=0}: failures =', bad)
assert bad == 0

pr('\n== 5. Uniqueness monotonicity: c(h + t1) >= c(h) + t l (componentwise), t >= 0 ==')
bad = 0
for _ in range(20000):
    h = (rq(), rq(), rq()); t = abs(rq())
    c1 = chart(add(h, (t, t, t))); c0 = chart(h)
    if any(c1[j] < c0[j] + t*l[j] for j in range(3)): bad += 1
pr('failures:', bad); assert bad == 0

pr('\n== 6. Coherence of every undominated model (random admissible triples) ==')
# undominated models X*(W0,beta,alpha) = N(W0) cap {g<0},
#   g = alpha3 phi3 [3 notin W0] - beta.c ;  claimed = D_{K(W0,beta,alpha)},
#   K = conv(K' u [q if 3 in W0] u nu(W)),  W generated by beta*rho (rho corner of R) + alpha3*lam*q, lam in {0,1}
corners = [tuple(x) for x in itertools.product(*[(l[j], u[j]) for j in range(3)])]
def run_triple(W0, beta, alpha3, ntest=1500):
    gens = []
    for rho in corners:
        base = had(beta, rho)
        gens.append(base)
        if 2 not in W0:
            gens.append(add(base, scal(alpha3, q)))
    Kset = [k] + ([q] if 2 in W0 else []) + [nu(w) for w in gens if sum(w) > 0]
    bad = 0
    for _ in range(ntest):
        h = (rq(), rq(), rq())
        if not inU(h): continue
        if dot(q, h) == 0: continue
        g = (alpha3 * phi3(h) if 2 not in W0 else 0) - dot(beta, chart(h))
        gmax = max(-dot(w, h) for w in gens)
        if g != gmax: bad += 1
        inN = (phi3(h) == 0) if 2 in W0 else True
        if g == 0: continue
        lhs = inN and g < 0
        rhs = all(dot(m, h) > 0 for m in Kset)
        if lhs != rhs: bad += 1
    return bad
tot = 0; ntr = 0
for _ in range(300):
    W0 = [0, 1] + ([2] if rng.random() < 0.5 else [])
    beta = [F(rng.randint(0, 9)) for _ in range(3)]
    for j in range(3):
        if j not in W0: beta[j] = F(0)
    if all(b == 0 for b in beta): beta[0] = F(1)
    alpha3 = F(rng.randint(0, 9), rng.randint(1, 4))
    tot += run_triple(W0, tuple(beta), alpha3, 300); ntr += 1
pr('random admissible triples: %d ; failures of g = max(-w.h) or X* = D_K(W0,beta,alpha): %d' % (ntr, tot))
assert tot == 0
# convexity (closure under addition) of a few undominated models, exact
def member(W0, beta, alpha3, h):
    if not inU(h): return False
    if 2 in W0 and phi3(h) != 0: return False
    g = (alpha3 * phi3(h) if 2 not in W0 else 0) - dot(beta, chart(h))
    return g < 0
bad = 0; pairs = 0
for _ in range(200):
    W0 = [0, 1] + ([2] if rng.random() < 0.5 else [])
    beta = tuple(F(rng.randint(0 if j in W0 else 0, 9)) if j in W0 else F(0) for j in range(3))
    if all(b == 0 for b in beta): beta = (F(1), F(0), F(0))
    alpha3 = F(rng.randint(0, 9), rng.randint(1, 4))
    for _ in range(200):
        h = (rq(), rq(), rq()); g2 = (rq(), rq(), rq())
        if member(W0, beta, alpha3, h) and member(W0, beta, alpha3, g2):
            pairs += 1
            if not member(W0, beta, alpha3, add(h, g2)): bad += 1
pr('closure under addition of undominated models: %d accepted pairs, %d failures' % (pairs, bad))
assert bad == 0

pr('\n== 7. Target as the triple (Omega, beta=(1,1,1), -) ==')
gens = [had((F(1),F(1),F(1)), rho) for rho in corners]
pts = sorted(set(nu(w) for w in gens))
pr('nu(beta*R) =', [fmt(x) for x in pts], ' (the cevian segment [p,s] = nu([1,6]x{2}x{2}))')
assert set(pts) == {p, s}
pr('K(Omega,1,-) = conv(K\' u {q} u [p,s]) = conv{p,q,s} = T since k in T.')

pr('\n== 8. Sanity check on an atomic sample (NUMERICS-type; the proof is analytic) ==')
# empirical measure: rational gambles in U; score vectors; random perturbations of D_T never weakly dominate it
sample = []
while len(sample) < 3000:
    h = (rq(), rq(), rq())
    if inU(h) and all(dot(v, h) != 0 for v in V + [k]):
        sample.append(h)
def scores(X):
    a3 = sum(phi3(h) for h in X)
    b = [-sum(chart(h)[j] for h in X) for j in range(3)]
    return a3, b
def weakly_dominates(Y, X):
    a3Y, bY = scores(Y); a3X, bX = scores(X)
    ok3 = (a3Y < a3X) or (a3Y == a3X and bY[2] <= bX[2])
    return ok3 and bY[0] <= bX[0] and bY[1] <= bX[1]
DT = [h for h in sample if inDT(h)]
others = [h for h in sample if not inDT(h)]
near = sorted(sample, key=lambda h: min(abs(dot(v, h)) for v in V))[:600]
wd = 0
for it in range(400):
    Y = set(DT)
    for h in rng.sample(near, rng.randint(1, 25)):
        if h in Y: Y.discard(h)
        else: Y.add(h)
    if Y == set(DT): continue
    if weakly_dominates(list(Y), DT): wd += 1
pr('random perturbations near the boundary weakly dominating D_T: %d / 400' % wd)
assert wd == 0
open(__file__.replace('.py', '.out'), 'w').write('\n'.join(out) + '\n')
