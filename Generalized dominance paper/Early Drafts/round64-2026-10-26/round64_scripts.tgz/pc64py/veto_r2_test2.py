"""Broader version of veto_r2_test.py: veto at world j (a = (u+e_j)/2), beta supported off j,
orthant scalings lambda_sigma random; gambles concentrated near coordinate planes and near the veto plane."""
import random, sys, itertools
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from geom import *
import veto_r2_test as base
rng = random.Random(7)
def rq(): return F(rng.randint(-60, 60), rng.randint(1, 9))
def near(): 
    h = [rq(), rq(), rq()]
    i = rng.randrange(3); h[i] = F(rng.randint(-3, 3), rng.randint(5, 40))
    return tuple(h)
u = (F(1,3),)*3
found = []
tested = 0
for j in range(3):
    a = add(scal(F(1,2), u), scal(F(1,2), E[j]))
    for trial in range(150):
        lam = {s: F(rng.randint(1, 6), rng.randint(1, 6)) for s in base.dec}
        beta = [F(rng.randint(0, 9)) for _ in range(3)]; beta[j] = F(0)
        if all(b == 0 for b in beta): beta[(j+1) % 3] = F(1)
        alpha = F(rng.randint(1, 20), rng.randint(1, 4))
        def chart(h):
            sig = tuple(sgn(x) for x in h)
            return scal(lam[sig], had(base.dec[sig], h)) if sig in base.dec else h
        def mem(h):
            if dot(u, h) <= 0 or any(x == 0 for x in h): return False
            return alpha * max(F(0), -dot(a, h)) < dot(beta, chart(h))
        for _ in range(250):
            h = near() if rng.random() < .5 else (rq(), rq(), rq())
            k = near() if rng.random() < .5 else (rq(), rq(), rq())
            if mem(h) and mem(k):
                z = add(h, k)
                if any(x == 0 for x in z): continue
                tested += 1
                if not mem(z):
                    found.append((j, tuple(beta), alpha, lam, h, k, z)); break
print('pairs tested:', tested, '; non-convexity witnesses:', len(found))
for w in found[:3]:
    j, beta, alpha, lam, h, k, z = w
    print(' veto world', j+1, 'beta', fmt(beta), 'alpha', alpha, 'h', fmt(h), 'k', fmt(k), 'h+k', fmt(z))
# with lam = 1 only
