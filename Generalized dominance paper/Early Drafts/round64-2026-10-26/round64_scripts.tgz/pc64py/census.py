"""PC64 census of interior triangles with exactly one or two cevian edges (exact rational data).
Categories (bad = not strictly visible):
  V  : <= 1 bad vertex (VB class, W62 Thm exempt)
  X  : exactly 2 bad, joined by a cevian edge  -> covered by a veto-box ranking (PC64 Thm BX)
  N  : exactly 2 bad, joined by a non-cevian edge
  N33: subclass of N where both bad facets carry 3 forced coordinates (no direction match at the
       non-cevian corner between them: v_a (.) r is never parallel to v_b (.) r)
  3  : 3 bad vertices
"""
import random, sys, itertools
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from geom import *
from systems import *

def category(V):
    bad = bad_vertices(V)
    if len(bad) <= 1:
        return 'V'
    if len(bad) == 3:
        return '3'
    ce = cevian_edges(V)
    if any(set((i, j)) == set(bad) for (i, j, l) in ce):
        return 'X'
    if all(len(forced(V, k)) == 3 for k in bad):
        return 'N33'
    return 'N'

def parallel_check(V):
    """for N33: verify v_a(.)r not parallel to v_b(.)r at the non-cevian corner r between the bad facets"""
    a, b = bad_vertices(V)
    r = ray(V, a, b)
    x = had(V[a], r); y = had(V[b], r)
    return any(c != 0 for c in cross(x, y))

out = []
def pr(*a):
    s = ' '.join(str(z) for z in a); out.append(s); print(s)

rng = random.Random(6464)
def rand_pt():
    return nu([rng.randint(1, 50) for _ in range(3)])
def pt_on_cevian(w, l):
    while True:
        t = F(rng.randint(-90, 90), 100)
        pnt = tuple((1 - t) * w[i] + t * E[l][i] for i in range(3))
        if t != 0 and all(x > 0 for x in pnt):
            return pnt
def gen(ncev):
    while True:
        if ncev == 1:
            a = rand_pt(); l = rng.randrange(3); b = pt_on_cevian(a, l); c = rand_pt()
        else:
            c = rand_pt(); l1, l2 = rng.sample(range(3), 2); a = pt_on_cevian(c, l1); b = pt_on_cevian(c, l2)
        V = [a, b, c]
        if is_triangle_interior(V) and len(cevian_edges(V)) == ncev:
            return V

def main():
    for ncev in (1, 2):
        cnt = {}; par_fail = 0; dir_sol = {}
        N = 2000
        for _ in range(N):
            V = gen(ncev)
            cat = category(V)
            cnt[cat] = cnt.get(cat, 0) + 1
            if cat == 'N33' and not parallel_check(V):
                par_fail += 1
            if cat in ('N', '3'):
                eqs, unk, sols, good = solve_direction(V)
                key = (cat, bool(good))
                dir_sol[key] = dir_sol.get(key, 0) + 1
        pr('random triangles with exactly %d cevian edge(s): %d' % (ncev, N))
        pr('   categories:', dict(sorted(cnt.items())))
        pr('   N33 with v_a(.)r parallel to v_b(.)r (should be 0):', par_fail)
        pr('   full (single-chart) direction system solvable, by category N / 3:', dict(sorted(dir_sol.items())))

    # small-integer enumeration (denominators <= 10)
    pts = set()
    for S in range(3, 11):
        for a in range(1, S):
            for b in range(1, S - a):
                c = S - a - b
                if c >= 1:
                    pts.add(nu((a, b, c)))
    pts = sorted(pts)
    cnt = {}
    for P in itertools.combinations(pts, 3):
        V = list(P)
        if det3(*V) == 0: continue
        nc = len(cevian_edges(V))
        if nc not in (1, 2): continue
        cat = category(V)
        cnt[(nc, cat)] = cnt.get((nc, cat), 0) + 1
    pr('small-integer triangles (vertices with coordinate sum <= 10), exactly 1 or 2 cevian edges:')
    pr('  ', dict(sorted(cnt.items())))
    open(__file__.replace('.py', '.out'), 'w').write('\n'.join(out) + '\n')


if __name__ == "__main__":
    main()
