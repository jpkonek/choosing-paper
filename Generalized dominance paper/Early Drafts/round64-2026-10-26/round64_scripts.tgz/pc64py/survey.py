"""Survey: random interior triangles with exactly one or two cevian edges.
For each: bad vertices (not strictly visible), forced sets, value-system rank, direction-system solutions."""
import random, sys
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from geom import *
from systems import *

rng = random.Random(64)


def rand_pt():
    return nu([rng.randint(1, 40) for _ in range(3)])


def pt_on_cevian(w, l):
    while True:
        t = F(rng.randint(-80, 80), 100)
        p = tuple((1 - t) * w[i] + t * E[l][i] for i in range(3))
        if t != 0 and all(x > 0 for x in p):
            return p


def gen(ncev):
    while True:
        if ncev == 1:
            a = rand_pt(); l = rng.randrange(3)
            b = pt_on_cevian(a, l); c = rand_pt()
            V = [a, b, c]
        else:
            c = rand_pt(); l1, l2 = rng.sample(range(3), 2)
            a = pt_on_cevian(c, l1); b = pt_on_cevian(c, l2)
            V = [a, b, c]
        if not is_triangle_interior(V):
            continue
        if len(cevian_edges(V)) == ncev:
            return V


stats = {}
examples = {}
for ncev in (1, 2):
    for it in range(300):
        V = gen(ncev)
        bad = bad_vertices(V)
        if len(bad) < 2:
            continue
        fs = tuple(sorted(len(forced(V, k)) for k in range(3)))
        M, rk, neq = value_system(V)
        eqs, unk, sols, good = solve_direction(V)
        key = (ncev, len(bad), fs, rk, len(good) > 0)
        stats[key] = stats.get(key, 0) + 1
        if key not in examples:
            examples[key] = (V, [types(V, k) for k in range(3)], good)
for k in sorted(stats):
    print('ncev=%d bad=%d forced-sizes=%s value-rank=%d/6 direction-solution=%s : %d' % (k[0], k[1], k[2], k[3], k[4], stats[k]))
print()
for k, (V, ty, good) in sorted(examples.items()):
    print(k, [fmt(v) for v in V], ty, good[:2])
