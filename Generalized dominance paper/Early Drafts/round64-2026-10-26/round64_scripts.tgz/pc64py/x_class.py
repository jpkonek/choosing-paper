"""PC64: the veto-box construction for every random triangle of category X
(exactly two non-strictly-visible vertices a,b, joined by a cevian edge through e_l; third vertex c
strictly visible from world j).  Construction: K'={k}, k = c + eps (c - e_j); A_j = {c};
box R with nu(R) = [a,b]; chart c_i = min(R_lo_i h_i, R_hi_i h_i).  Exact checks on random gambles:
 k in relint T; c in conv{k, e_j}; veto vanishes on U cap {h_j >= 0}; sign-correctness;
 N(Omega) cap {1.c > 0} = D_T (off null sets)."""
import random, sys
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from geom import *
from census import category, gen, rng

out = []
def pr(*a):
    s = ' '.join(str(z) for z in a); out.append(s); print(s)

def build(V):
    bad = bad_vertices(V)
    ci = [x for x in range(3) if x not in bad][0]
    c = V[ci]
    j = [w for w in range(3) if types(V, ci)[w] == 'S'][0]
    a, b = V[bad[0]], V[bad[1]]
    l = [ll for (i1, i2, ll) in cevian_edges(V) if set((i1, i2)) == set(bad)][0]
    # b = (1-tau) a + tau e_l
    tau = None
    for m in range(3):
        if m != l and a[m] != 0:
            tau = 1 - b[m] / a[m]; break
    if tau < 0:
        a, b = b, a
        tau = None
        for m in range(3):
            if m != l and a[m] != 0:
                tau = 1 - b[m] / a[m]; break
    lo = list(a); hi = list(a); hi[l] = a[l] + tau / (1 - tau)
    assert nu(hi) == b and nu(lo) == a
    # k = c + eps (c - e_j) inside relint T
    eps = F(1, 2)
    while True:
        k = add(c, scal(eps, sub(c, E[j])))
        D = det3(*V)
        bary = []
        for i in range(3):
            cols = list(V); cols[i] = k; bary.append(det3(*cols) / D)
        if all(x > 0 for x in bary):
            break
        eps /= 2
    return k, j, c, tuple(lo), tuple(hi)

def rq():
    return F(rng.randint(-80, 80), rng.randint(1, 15))

nt = 0; fails = 0
for ncev in (1, 2):
    done = 0
    while done < 100:
        V = gen(ncev)
        if category(V) != 'X':
            continue
        done += 1; nt += 1
        k, j, c, lo, hi = build(V)
        lam = 1 / (1 + (k[0] - c[0]) / (c[0] - E[j][0])) if c[0] != E[j][0] else None
        # c on segment [k, e_j]: c = (k + eps e_j)/(1+eps) by construction
        chart = lambda h: tuple(min(lo[i]*h[i], hi[i]*h[i]) for i in range(3))
        for _ in range(1500):
            h = (rq(), rq(), rq())
            if dot(k, h) <= 0: continue
            if any(sgn(chart(h)[i]) != sgn(h[i]) for i in range(3)): fails += 1
            if h[j] >= 0 and dot(c, h) < 0: fails += 1
            if dot(c, h) == 0 or any(dot(v, h) == 0 for v in V): continue
            lhs = dot(c, h) > 0 and sum(chart(h)) > 0
            rhs = all(dot(v, h) > 0 for v in V)
            if lhs != rhs: fails += 1
pr('category-X triangles tested: %d ; failures (sign, veto guidance, target identity): %d' % (nt, fails))
open(__file__.replace('.py', '.out'), 'w').write('\n'.join(out) + '\n')
