"""Search small-integer interior triangles with 1 or 2 cevian edges and >= 2 bad vertices;
report forced sizes, direction-system solvability, vertex types."""
import sys, itertools
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from geom import *
from systems import *

pts = set()
for s in range(3, 11):
    for a in range(1, s):
        for b in range(1, s - a):
            c = s - a - b
            if c >= 1:
                pts.add(nu((a, b, c)))
pts = sorted(pts)
print(len(pts), 'points')
res = []
seen = set()
count = 0
for P in itertools.combinations(pts, 3):
    V = list(P)
    if det3(*V) == 0:
        continue
    ce = cevian_edges(V)
    if len(ce) not in (1, 2):
        continue
    bad = bad_vertices(V)
    if len(bad) < 2:
        continue
    count += 1
    den = max(max(x.denominator for x in v) for v in V)
    res.append((den, V, ce, bad))
res.sort(key=lambda t: t[0])
print(count, 'candidates')
shown = 0
for den, V, ce, bad in res:
    eqs, unk, sols, good = solve_direction(V)
    if not good:
        continue
    ty = [types(V, k) for k in range(3)]
    fs = [len(forced(V, k)) for k in range(3)]
    print(den, [fmt(v) for v in V], 'cev', ce, 'bad', bad, ty, fs, good[:1])
    shown += 1
    if shown > 25:
        break
