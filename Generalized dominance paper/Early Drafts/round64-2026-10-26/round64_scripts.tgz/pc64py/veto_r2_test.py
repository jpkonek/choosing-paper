"""PC64 side test (NUMERICS/CHECKED witness): veto followed by a NON-concave orthant-diagonal (R2) chart.
Is every lexicographic Bayes set U cap {alpha*max(0,-a.h) < beta.c(h)} (beta supported off the veto world)
convex?  Chart: c(h) = d_sigma (.) h, d_sigma = deciding vertex of the cyclic triangle K0 on orthant sigma.
An exact witness of non-convexity (h, k in the set, h+k not) shows that the box (concave) exemption
cannot simply be replaced by an orthant-planar exemption in this architecture."""
import random, sys, itertools
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from geom import *

K0 = [nu((1,4,2)), nu((2,1,4)), nu((4,2,1))]
def deciding(h):
    # on a mixed orthant D_K0 cap sigma is a half-space {d.h>0}; find the vertex deciding at points of sigma
    sig = tuple(sgn(x) for x in h)
    cands = []
    for v in K0:
        ok = True
        for tst in probe[sig]:
            if (dot(v, tst) > 0) != all(dot(w, tst) > 0 for w in K0):
                ok = False; break
        if ok: cands.append(v)
    return cands[0]
rng = random.Random(64064)
def rq(): return F(rng.randint(-60, 60), rng.randint(1, 9))
probe = {}
for sig in itertools.product((-1, 1), repeat=3):
    if len(set(sig)) == 1: continue
    pts = []
    while len(pts) < 400:
        h = tuple(sig[i] * abs(rq()) for i in range(3))
        if all(x != 0 for x in h): pts.append(h)
    probe[sig] = pts
dec = {sig: None for sig in probe}
for sig in probe:
    for v in K0:
        if all((dot(v, t) > 0) == all(dot(w, t) > 0 for w in K0) for t in probe[sig]):
            dec[sig] = v; break
print('deciding vertices per mixed orthant:', {s: fmt(v) for s, v in dec.items()})
assert all(v is not None for v in dec.values())
def chart(h):
    sig = tuple(sgn(x) for x in h)
    if sig in dec:
        return had(dec[sig], h)
    return h
u = (F(1,3),)*3
a = add(scal(F(1,2), u), scal(F(1,2), E[0]))  # strictly visible point for world 1
def inU(h): return dot(u, h) > 0
witness = None; tested = 0
for trial in range(400):
    beta = (F(0), F(rng.randint(1, 9)), F(rng.randint(0, 9)))
    alpha = F(rng.randint(1, 20), rng.randint(1, 4))
    def mem(h):
        if not inU(h) or any(x == 0 for x in h): return False
        return alpha * max(F(0), -dot(a, h)) < dot(beta, chart(h))
    for _ in range(300):
        h = (rq(), rq(), rq()); k = (rq(), rq(), rq())
        if mem(h) and mem(k):
            tested += 1
            z = add(h, k)
            if any(x == 0 for x in z): continue
            if not mem(z):
                witness = (beta, alpha, h, k, z); break
    if witness: break
print('pairs tested:', tested)
if witness:
    beta, alpha, h, k, z = witness
    print('NON-CONVEX lexicographic Bayes set: beta=%s alpha=%s' % (fmt(beta), alpha))
    for name, x in (('h', h), ('k', k), ('h+k', z)):
        print('  %s = %s : alpha*phi = %s, beta.c = %s' % (name, fmt(x), alpha*max(F(0), -dot(a, x)), dot(beta, chart(x))))
else:
    print('no witness found')
