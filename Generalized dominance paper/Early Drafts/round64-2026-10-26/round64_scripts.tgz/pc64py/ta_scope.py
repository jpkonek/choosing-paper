"""PC64: scope checks for T = conv{(1,2,2),(2,1,2),(3,1,1)}/5 (exact).
 (a) single-level concave charts: ray-matrix determinant (O61 Thm B steps 3-6, no vetoes);
 (b) continuous PL single charts: corner VALUE system rank (C62 Thm 4.1 transfer);
 (c) direction-only corner system (first-order obstruction absent);
 (d) composition: CC63 one-cevian angle criterion;
 (e) the veto-box triangle criterion (exactly two non-strictly-visible vertices joined by a cevian edge)."""
import sys
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from geom import *
from systems import *
import sympy as sp

out = []
def pr(*a):
    s = ' '.join(str(x) for x in a); out.append(s); print(s)

V = [(F(1,5), F(2,5), F(2,5)), (F(2,5), F(1,5), F(2,5)), (F(3,5), F(1,5), F(1,5))]
R = corner_rays(V)
pr('rays:', {k: fmt(v) for k, v in R.items()})
for k in range(3):
    pr('facet F_%d: forced coords %s, relint crossings %s' % (k, [m+1 for m in forced(V, k)], [m+1 for m in relint_crossings(V, k)]))
# (a) which world crosses on which facet (relint); slope equations at each ray
cross_on = {j: [k for k in range(3) if j in relint_crossings(V, k)] for j in range(3)}
pr('(a) worlds with a relint crossing: ', {j+1: v for j, v in cross_on.items()})
ok = True
for e, r in R.items():
    fac = [k for k in range(3) if e in facet_edges(k)]
    for j in range(3):
        if r[j] == 0: continue
        if not any(j in relint_crossings(V, k) for k in fac): ok = False
pr('    every world with r_j != 0 crosses on a facet adjacent to the ray r (needed for c_j(r)=s_j r_j):', ok)
M = sp.Matrix([[sp.Rational(x) for x in R[e]] for e in EDGES])
pr('    ray matrix det =', M.det(), '(nonzero => s = 0, contradiction: no single concave chart)')
# (b)
Mv, rk, neq = value_system(V)
pr('(b) corner value system: %d equations, rank %d of 6 (rank 6 => c = 0 on boundary => contradiction with C62 L4.2)' % (neq, rk))
# (c)
eqs, unk, sols, good = solve_direction(V)
pr('(c) direction system equations:', eqs)
pr('    admissible real solutions:', good)
# (d) angle criterion: composed iff the two simplex vertices off the cevian line lie in the opposite angles of two different vertices
ce = cevian_edges(V)
lcev = ce[0][2]
others = [j for j in range(3) if j != lcev]
vis_from = {j: [k for k in range(3) if types(V, k)[j] == 'S'] for j in others}
pr('(d) cevian line through e_%d; strictly visible vertices (1-based world: 0-based vertex list): %s' % (lcev+1, {j+1: v for j, v in vis_from.items()}))
crit = all(vis_from[j] for j in others) and set(vis_from[others[0]]) != set(vis_from[others[1]]) or False
pr('    CC63 angle criterion satisfied:', bool(all(vis_from[j] for j in others)), '-> not a composed target')
# (e)
bad = bad_vertices(V)
edge_cev = any(set((i, j)) == set(bad) for (i, j, l) in ce)
pr('(e) bad vertices %s joined by a cevian edge: %s' % (bad, edge_cev))
open(__file__.replace('.py', '.out'), 'w').write('\n'.join(out) + '\n')
