"""Corner systems for facet-linear charts at the target prior (normalised pi* = 1).

Facet map on F_k: linear map v_k^perp -> 1^perp, determined by its values at the two end rays.
Forced coordinates (C62 Lemma 4.4 generalised): c_m vanishes where h_m vanishes on F_k.
VALUE system (continuous fields): c single-valued at corner rays -> homogeneous linear system.
DIRECTION system (only directions matched at corner rays): c(r1)=C_{r1}, c(r2)=t_k C_{r2}.
"""
import sympy as sp
from geom import *

EDGES = ((0, 1), (0, 2), (1, 2))


def corner_rays(V):
    return {e: ray(V, *e) for e in EDGES}


def facet_edges(k):
    i, j = [x for x in range(3) if x != k]
    return (tuple(sorted((k, i))), tuple(sorted((k, j))))


def value_system(V):
    """unknowns: C_e in 1^perp for e in EDGES, C_e = (x_e, y_e, -x_e-y_e). returns (matrix, rank)."""
    R = corner_rays(V)
    syms = {}
    for e in EDGES:
        syms[e] = sp.symbols('x%d%d y%d%d' % (e + e))
    Cv = {e: (syms[e][0], syms[e][1], -syms[e][0]-syms[e][1]) for e in EDGES}
    eqs = []
    for e in EDGES:
        r = R[e]
        for m in range(3):
            if r[m] == 0:
                eqs.append(Cv[e][m])
    for k in range(3):
        e1, e2 = facet_edges(k)
        r1, r2 = R[e1], R[e2]
        for m in range(3):
            if r1[m] * r2[m] < 0:
                a, b = abs(r2[m]), abs(r1[m])
                eqs.append(sp.Rational(a) * Cv[e1][m] + sp.Rational(b) * Cv[e2][m])
    allsyms = [s for e in EDGES for s in syms[e]]
    M = sp.Matrix([[sp.diff(q, s) for s in allsyms] for q in eqs])
    return M, M.rank(), len(eqs)


def corner_param(r, p):
    """direction vector in 1^perp with the weak sign pattern of r (normalised)."""
    zeros = [m for m in range(3) if r[m] == 0]
    if zeros:
        m = zeros[0]
        pos = [i for i in range(3) if r[i] > 0][0]
        neg = [i for i in range(3) if r[i] < 0][0]
        C = [0, 0, 0]
        C[pos], C[neg] = 1, -1
        return tuple(sp.Integer(x) for x in C), False
    pos = [i for i in range(3) if r[i] > 0]
    neg = [i for i in range(3) if r[i] < 0]
    C = [0, 0, 0]
    if len(pos) == 2:
        C[pos[0]], C[pos[1]], C[neg[0]] = p, 1 - p, -1
    else:
        C[neg[0]], C[neg[1]], C[pos[0]] = -p, -(1 - p), 1
    return tuple(C), True


def direction_system(V):
    R = corner_rays(V)
    ps, Cv, free = {}, {}, []
    for e in EDGES:
        p = sp.Symbol('p%d%d' % e)
        C, isfree = corner_param(R[e], p)
        Cv[e] = C
        if isfree:
            free.append(p)
    ts = [sp.Symbol('t%d' % k) for k in range(3)]
    eqs = []
    for k in range(3):
        e1, e2 = facet_edges(k)
        r1, r2 = R[e1], R[e2]
        for m in range(3):
            if r1[m] * r2[m] < 0:
                a, b = abs(r2[m]), abs(r1[m])
                eqs.append(sp.Rational(a) * Cv[e1][m] + ts[k] * sp.Rational(b) * Cv[e2][m])
    unknowns = free + [t for t in ts if any(t in q.free_symbols for q in eqs)]
    return eqs, unknowns, Cv, ts, free


def solve_direction(V):
    eqs, unk, Cv, ts, free = direction_system(V)
    if not eqs:
        return eqs, unk, [{}], []
    sols = sp.solve(eqs, unk, dict=True)
    good = []
    for s in sols:
        ok = True
        for p in free:
            if p in s:
                val = s[p]
                if not val.is_real:
                    ok = False; break
                if val.free_symbols:
                    continue
                if not (0 <= val <= 1):
                    ok = False; break
        for t in ts:
            if t in s:
                val = s[t]
                if val.free_symbols:
                    continue
                if not val.is_real or not val > 0:
                    ok = False; break
        if ok:
            good.append(s)
    return eqs, unk, sols, good
