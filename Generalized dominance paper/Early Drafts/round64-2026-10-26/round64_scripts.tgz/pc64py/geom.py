"""PC64 exact geometry for interior triangles in the 3-world simplex (Fractions only).

Conventions.
  T = conv{V[0],V[1],V[2]} with V[k] in relint Delta.
  D_T = {h : V[k].h > 0, k = 0,1,2}.
  ray(i,j): extreme ray of cl D_T for the edge [V[i],V[j]] = +-(V[i] x V[j]), oriented so V[k].ray > 0 (k the third index).
  facet F_k = cl D_T cap V[k]^perp = cone(ray(k,i), ray(k,j)).
  world types at V[k] (P61 V1 / O61 / FD62): from the two generators of F_k:
     S strictly visible (both < 0), T tangential (<= 0, one = 0), A anti-visible (>= 0),
     C crossing (opposite strict signs).
  edge [V[i],V[j]] is cevian iff its line passes through a vertex e_l of Delta iff ray(i,j)_l = 0.
"""
from fractions import Fraction as F
from itertools import combinations

E = [(F(1), F(0), F(0)), (F(0), F(1), F(0)), (F(0), F(0), F(1))]
ONE = (F(1), F(1), F(1))


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def sub(a, b):
    return tuple(x - y for x, y in zip(a, b))


def scal(s, a):
    return tuple(s * x for x in a)


def had(a, b):
    return tuple(x * y for x, y in zip(a, b))


def nu(v):
    s = sum(v)
    return tuple(F(x) / s for x in v)


def sgn(x):
    return (x > 0) - (x < 0)


def det3(a, b, c):
    return dot(a, cross(b, c))


def third(i, j):
    return 3 - i - j


def ray(V, i, j):
    r = cross(V[i], V[j])
    k = third(i, j)
    if dot(V[k], r) < 0:
        r = scal(-1, r)
    assert dot(V[k], r) > 0 and dot(V[i], r) == 0 and dot(V[j], r) == 0
    return r


def facet_rays(V, k):
    i, j = [x for x in range(3) if x != k]
    return ray(V, k, i), ray(V, k, j)


def types(V, k):
    r1, r2 = facet_rays(V, k)
    out = ''
    for w in range(3):
        a, b = r1[w], r2[w]
        if a < 0 and b < 0:
            out += 'S'
        elif a <= 0 and b <= 0:
            out += 'T'
        elif a >= 0 and b >= 0:
            out += 'A'
        else:
            out += 'C'
    return out


def strictly_visible(V, k):
    return 'S' in types(V, k)


def bad_vertices(V):
    return [k for k in range(3) if not strictly_visible(V, k)]


def cevian_edges(V):
    """list of (i,j,l): edge [V[i],V[j]] lies on a line through e_l"""
    out = []
    for i, j in ((0, 1), (0, 2), (1, 2)):
        r = ray(V, i, j)
        for l in range(3):
            if r[l] == 0:
                out.append((i, j, l))
    return out


def forced(V, k):
    """coordinates m that vanish somewhere on F_k minus 0 (end zero or relint crossing)"""
    r1, r2 = facet_rays(V, k)
    return [m for m in range(3) if r1[m] * r2[m] <= 0]


def relint_crossings(V, k):
    r1, r2 = facet_rays(V, k)
    return [m for m in range(3) if r1[m] * r2[m] < 0]


def is_triangle_interior(V):
    return all(x > 0 for v in V for x in v) and det3(*V) != 0


def strict_vis_ray_test(V, k, j):
    """independent test (P61 definition): V[k] + s (V[k]-e_j) in relint T for small s>0.
    Barycentric coordinates of the point w.r.t. V must all be > 0 for small s>0:
    first-order: bary(V[k]) = e_k, derivative d = bary(V[k]-e_j); need d_i > 0 for i != k."""
    # solve V^T x = y  (x barycentric, rows of V are vertices)
    y = sub(V[k], E[j])
    D = det3(V[0], V[1], V[2])
    # Cramer on columns: y = sum_i x_i V[i]
    cols = [V[0], V[1], V[2]]
    xs = []
    for i in range(3):
        cc = list(cols)
        cc[i] = y
        xs.append(det3(*cc) / D)
    return all(xs[i] > 0 for i in range(3) if i != k)


def fmt(v):
    return '(' + ', '.join(str(x) for x in v) + ')'
