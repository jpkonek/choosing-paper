"""RA68b sanity checks (Monte Carlo / exact arithmetic) for Ex 6.4, Rem 4.4, Ex B.1.
Standard Gaussian mu on R^2. Checks are sanity checks only; the proofs were checked by hand."""
import numpy as np
from math import sqrt
rng = np.random.default_rng(68)
M = 4_000_000
H = rng.standard_normal((M, 2))

# ---- Example 6.4: exact bound arithmetic
lo1 = -1.1 + 0.6 * 1.9
lo2 = 2.9 - 0.6 * 3.1
print("Ex6.4 a'-0.6b' lower bounds:", round(lo1, 4), round(lo2, 4))
print("Ex6.4 increment bound coefficient:", -1.1 / 2 - (-1.9 + 1.1 / 4))
# balls inside C={h1+h2>0}? min of h1+h2 on ball radius .1 about centre c is c1+c2-0.1*sqrt2
for c in [(-1, 3), (-2, 3), (1, 1)]:
    print("  centre", c, "min h1+h2 on V:", c[0] + c[1] - 0.1 * sqrt(2))
# Monte Carlo of the actual measures with concentric radii solving the mass equations
def in_ball(c, r):
    return ((H[:, 0] - c[0]) ** 2 + (H[:, 1] - c[1]) ** 2) < r * r
w = 1.0 / M
mVa, mVb, mVc = (in_ball(c, .1).sum() * w for c in [(-1, 3), (-2, 3), (1, 1)])
print("  mu(Va),mu(Vb),mu(Vc) ~", mVa, mVb, mVc)

# ---- Remark 4.4 first part: m(N) coordinates for N = W u W'
W = in_ball((3, -1), .5)
Wp = in_ball((-1, 3), .5)
mN = (H[W | Wp]).sum(axis=0) * w
print("Rem4.4(i) m(N) ~", mN, "(both should be equal and >0)")

# ---- Remark 4.4 second part: Q_B = {(1/2,1/2)}; (1/2,1/2).m(B)>0
B = (H.sum(axis=1) > 0) & (H.min(axis=1) <= 0)
for t in [0.4, 0.49, 0.51, 0.6]:
    q = np.array([t, 1 - t])
    print(f"  t={t}: mu(B & q.h<0) ~ {(B & (H @ q < 0)).sum() * w:.5f}")
print("  (1/2,1/2).m(B) ~", (H[B].sum(axis=1) / 2).sum() * w)
# incoherent variant suggested in REF67_out U2: B' = B & ||h||>1
Bp = B & (np.abs(H).max(axis=1) > 1)
for t in [0.45, 0.55]:
    q = np.array([t, 1 - t])
    print(f"  B' t={t}: mu(B' & q.h<0) ~ {(Bp & (H @ q < 0)).sum() * w:.5f}")
print("  (1/2,1/2).m(B') ~", (H[Bp].sum(axis=1) / 2).sum() * w)

# ---- Example B.1: support function of R in direction lam is int_V |lam.h| > 0
V = in_ball((0.5, 0.5), .5)
cs = []
for th in np.linspace(0, np.pi, 181):
    lam = np.array([np.cos(th), np.sin(th)])
    cs.append(np.abs(H[V] @ lam).sum() * w)
print("ExB.1 min support function over directions ~", min(cs))
