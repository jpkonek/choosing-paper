import random, sys
sys.path.insert(0, '.')
from checks import prop71_instance, wdom
rng = random.Random(7); t=f=0; unav=0
for _ in range(20000):
    n,w,C,ch,G,phi,avail,le = prop71_instance(rng)
    H1 = all(phi[o][b] > phi[o][a] for o in range(w) for a in range(n) for b in range(n) if a!=b and ch[(a,b)] in G[o])
    H2 = all(not all(ch[(c,m)] in G[o] for o in range(w)) for c in C for m in range(n) if m!=c)
    if not (H1 and H2): continue
    CL=[c for c in C if not any(wdom(n,w,le,y,c) and not wdom(n,w,le,c,y) for y in range(n))]
    if all(any(wdom(n,w,le,c,m) for c in CL) for m in range(n)):
        t+=1
        if any(m not in C and any(ch[(m,c)] not in avail for c in C) for m in range(n)): unav+=1
    else: f+=1
print('conclusion true',t,'false',f,'true with an unavailable repair',unav)
