"""RL68 independent numerical / exhaustive checks for the definitive LDG manuscript.
Run: python3 -I checks.py
"""
import itertools, math, random
from fractions import Fraction as Fr

FAIL = []
def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond:
        FAIL.append(name)

# ---------------------------------------------------------------- Prop 7.1
# Random finite instances: models 0..n-1, worlds 0..w-1, a coarse change map
# change(m', m) in a small label set (null label 0 iff m == m'), guided sets,
# scores. Verify (a), (b), (c) and the final clause whenever the hypotheses hold.
def prop71_instance(rng):
    n = rng.randint(2, 6); w = rng.randint(1, 3)
    C = set(i for i in range(n) if rng.random() < 0.5)
    nlab = rng.randint(1, n * n)
    ch = {}
    for a in range(n):
        for b in range(n):
            ch[(a, b)] = 0 if a == b else rng.randint(1, nlab)   # change from a to b
    G = [set([0]) | set(l for l in range(1, nlab + 1) if rng.random() < 0.3) for _ in range(w)]
    phi = [[rng.randint(0, 4) for _ in range(n)] for _ in range(w)]
    avail_coh = set(ch[(z, b)] for z in C for b in range(n))
    def le(om, m, mp):  # m <=_om m'  iff change from m' to m guided, or unavailable & improves
        c = ch[(mp, m)]
        return c in G[om] or (c not in avail_coh and phi[om][m] > phi[om][mp])
    return n, w, C, ch, G, phi, avail_coh, le

def wdom(n, w, le, c, m):
    return all(le(o, c, m) for o in range(w))

def run_prop71(trials=40000, seed=1):
    rng = random.Random(seed)
    stats = dict(H1=0, H2=0, both=0)
    ok = True
    for _ in range(trials):
        n, w, C, ch, G, phi, avail, le = prop71_instance(rng)
        # reflexive
        if not all(le(o, m, m) for o in range(w) for m in range(n)):
            ok = False; print('reflexive fail')
        H1 = all(phi[o][b] > phi[o][a] for o in range(w) for a in range(n) for b in range(n)
                 if a != b and ch[(a, b)] in G[o])
        H2 = all(not all(ch[(c, m)] in G[o] for o in range(w)) for c in C for m in range(n) if m != c)
        if H1:
            stats['H1'] += 1
            for o in range(w):
                for m in range(n):
                    for mp in range(n):
                        if m != mp and le(o, m, mp) and not phi[o][m] > phi[o][mp]:
                            ok = False; print('(a) fail')
                        if m != mp and le(o, m, mp) and le(o, mp, m):
                            ok = False; print('(a) tie fail')
        if H2:
            stats['H2'] += 1
            for c in C:
                for m in range(n):
                    if m != c and wdom(n, w, le, m, c):
                        ok = False; print('(b) fail')
        if H1 and H2:
            stats['both'] += 1
            def dominated(x):
                return any(wdom(n, w, le, y, x) and not wdom(n, w, le, x, y) for y in range(n))
            CL = [c for c in C if not dominated(c)]
            concl = all(any(wdom(n, w, le, c, m) for c in CL) for m in range(n))
            rep = all(any(all(ch[(m, c)] in G[o] for o in range(w)) or
                          (ch[(m, c)] not in avail and all(phi[o][c] > phi[o][m] for o in range(w)))
                          for c in C) for m in range(n) if m not in C)
            if concl != rep:
                ok = False; print('(c) equivalence fail', concl, rep)
            if concl:
                # closure under ties and strict dominance of incoherent models
                for m in range(n):
                    for c in CL:
                        if wdom(n, w, le, m, c) and wdom(n, w, le, c, m) and m not in CL:
                            ok = False; print('closure fail')
                    if m not in C:
                        if not any(all(le(o, c, m) and not le(o, m, c) for o in range(w)) for c in CL):
                            ok = False; print('strict fail')
    print('  Prop 7.1 instances:', stats)
    return ok

check('Prop 7.1 (a),(b),(c) on random finite instances', run_prop71())

# Necessity of the hypotheses as stated: (b) without protection fails; acyclicity without (a)'s hypothesis fails
def find_counter(seed=2, trials=20000):
    rng = random.Random(seed)
    cyc = prot = False
    for _ in range(trials):
        n, w, C, ch, G, phi, avail, le = prop71_instance(rng)
        H1 = all(phi[o][b] > phi[o][a] for o in range(w) for a in range(n) for b in range(n)
                 if a != b and ch[(a, b)] in G[o])
        if not H1:
            for o in range(w):
                for a in range(n):
                    for b in range(n):
                        if a != b and le(o, a, b) and le(o, b, a):
                            cyc = True
        H2 = all(not all(ch[(c, m)] in G[o] for o in range(w)) for c in C for m in range(n) if m != c)
        if not H2 and C:
            prot = True
        if cyc and prot:
            break
    return cyc
check('without "guided changes improve the score" the ranking can have 2-cycles (so "acyclic" needs it)', find_counter())

# ---------------------------------------------------------------- Example 4.4
def ex44(W=12, bounded=False):
    big = (lambda n: Fr(3) - Fr(1, n)) if bounded else (lambda n: 2 + n)
    worlds = range(1, W + 1)
    def L(mod, om):
        if mod == 'x': return 1
        n = mod
        return 0 if om <= n else big(n)
    # truncated check on worlds 1..W with e_1..e_{W-1}
    E = list(range(1, W))
    ok = True
    for n in E:
        for k in E:
            if n != k and all(L(k, o) <= L(n, o) for o in worlds):
                ok = False
        if all(L('x', o) <= L(n, o) for o in worlds):
            ok = False
        if all(L(n, o) <= 1 for o in worlds):
            ok = False
    for F in itertools.chain.from_iterable(itertools.combinations(worlds, r) for r in (1, 2, 3)):
        M = max(F)
        if M in E and not all(L(M, o) == 0 for o in F):
            ok = False
    return ok
check('Example 4.4 (2+n), truncated', ex44())
check('Example 4.4 (3-1/n), truncated', ex44(bounded=True))

# ---------------------------------------------------------------- Example 5.4
def ex54(G=24):
    ts = [Fr(i, G) for i in range(G + 1)]
    models = [('c', t) for t in ts] + [('x', t) for t in ts]
    def score(m, om):
        if m[0] == 'x': return 2
        return m[1] if om == 1 else 1 - m[1]
    def le(om, a, b):
        if score(a, om) > score(b, om): return False
        if om == 1 and a[0] == 'c' and b[0] == 'x' and a[1] == b[1] and a[1] > 0: return False
        if om == 2 and a == ('c', 0) and b == ('x', 0): return False
        return True
    ok = True
    wd = lambda a, b: le(1, a, b) and le(2, a, b)
    dom = lambda a, b: wd(a, b) and not wd(b, a)
    CL = [m for m in models if m[0] == 'c' and not any(dom(y, m) for y in models)]
    ok &= len(CL) == len(ts)
    for m in models:
        ok &= any(wd(c, m) for c in CL)
    # guarantee sets
    def A(om, p2, m):
        if m[0] == 'c':
            s = m[1]
            return p2 <= s if om == 1 else p2 >= s
        q = m[1]
        if q > 0:
            return p2 == 0 if om == 1 else True
        return True if om == 1 else p2 == 1
    for p2 in ts:
        c = ('c', p2)
        supp = [o for o, pr in ((1, 1 - p2), (2, p2)) if pr > 0]
        for m in models:
            for om in (1, 2):
                if A(om, p2, m) and not le(om, c, m): ok = False
            if not any(A(om, p2, m) for om in supp): ok = False
    # intransitivity witness
    q, s = Fr(1, 4), Fr(1, 2)
    ok &= le(1, ('c', q), ('c', s)) and le(1, ('c', s), ('x', q)) and not le(1, ('c', q), ('x', q))
    # vertices force c0 / c1
    ok &= [c for c in CL if all(le(1, c, m) for m in models)] == [('c', 0)]
    ok &= [c for c in CL if all(le(2, c, m) for m in models)] == [('c', 1)]
    return ok
check('Example 5.4 on a grid', ex54())

# ---------------------------------------------------------------- Example 5.5 randomisation
def ex55():
    a = 2 ** 0.25
    ok = True
    for i in range(1, 1000):
        s = i / 1000
        x, y = a * math.sqrt(1 - s), a * math.sqrt(s)
        ok &= abs(x * x + y * y - a * a) < 1e-12 and x + y > a
        ok &= not (x <= a / 2 and y <= a / 2)
    # quadratic losses at most 2 on [0,1]^2
    mx = max((1 - c1) ** 2 + c2 ** 2 for c1 in [0, .5, 1] for c2 in [0, .5, 1])
    ok &= mx == 2 and abs(a ** 4 - 2) < 1e-12
    # expected loss along the arc strictly concave: check endpoints are the minimisers
    for p1 in [0.1, 0.3, 0.5, 0.9]:
        vals = [a * (p1 * math.sqrt(1 - j / 200) + (1 - p1) * math.sqrt(j / 200)) for j in range(201)]
        k = vals.index(min(vals))
        ok &= k in (0, 200)
    return ok
check('Example 5.5 (arc, line x+y=a, (a/2,a/2), endpoints)', ex55())

# ---------------------------------------------------------------- Example 6.4
def ex64():
    ok = True
    g0 = lambda y: 0 if y == 0 else 1 + y
    g1 = lambda y: math.inf if y == 0 else y - math.log(y)
    L = lambda f: ((1 - f[0]) ** 2 + g0(f[1]), f[0] ** 2 + g1(f[1]))
    grid = [i / 200 for i in range(201)]
    for p2 in [0.0, 0.01, 0.2, 0.5, 0.9, 1.0]:
        p1 = 1 - p2
        best = min((p1 * L((f1, f2))[0] + (p2 * L((f1, f2))[1] if p2 > 0 else 0), f1, f2)
                   for f1 in grid for f2 in grid)
        V = p1 * p2 + 1 - p2 * math.log(p2) if p2 > 0 else 0.0
        ok &= abs(best[0] - V) < 1e-9 and abs(best[1] - p1) < 1e-9 and abs(best[2] - p2) < 1e-9
    ok &= L((0.5, 0)) == (0.25, math.inf)
    ok &= not any(L((f1, f2))[0] < 0.25 and L((f1, f2))[1] < math.inf for f1 in grid for f2 in grid)
    e = 1e-6
    ok &= abs((1 - e) * e + 1 - e * math.log(e) - 1) < 1e-4
    return ok
check('Example 6.4 (Bayes models, V, m=(1/2,0))', ex64())

# ---------------------------------------------------------------- Lemma 8.3 random
def lem83(trials=3000, seed=3):
    rng = random.Random(seed)
    ok = True
    for _ in range(trials):
        k = rng.randint(1, 4)
        cells = {j: [(j, i) for i in range(rng.randint(1, 3))] for j in range(1, k + 1)}
        F = [w for j in cells for w in cells[j] if rng.random() < 0.6]
        if not F:
            F = [cells[1][0]]
        x = [rng.random() ** 3 for _ in F]
        if rng.random() < 0.3:
            x = [0 if rng.random() < 0.5 else v for v in x]
        if sum(x) == 0:
            x[0] = 1
        p = {w: v / sum(x) for w, v in zip(F, x)}
        eta = 1 / (2 * k)
        pE = {j: sum(p[w] for w in F if w[0] == j) for j in cells}
        J = [j for j in cells if any(w[0] == j for w in F)]
        beta = {j: max(pE[j] - eta, 0) for j in cells}
        ok &= sum(beta.values()) >= eta - 1e-12
        lam = {j: beta[j] / sum(beta.values()) for j in cells}
        q0 = {}
        for j in J:
            Fj = [w for w in F if w[0] == j]
            den = max(pE[j], eta)
            r = {w: (p[w] + max(eta - pE[j], 0) / len(Fj)) / den for w in Fj}
            ok &= abs(sum(r.values()) - 1) < 1e-12
            for w in Fj:
                q0[w] = q0.get(w, 0) + lam[j] * r[w]
        ok &= all(p[w] > 0 for w, v in q0.items() if v > 1e-15)
        ok &= abs(sum(q0.values()) - 1) < 1e-12
    return ok
check('Lemma 8.3 (probabilities, support, sum beta >= eta)', lem83())

# ---------------------------------------------------------------- Example 8.5
def ex85():
    ok = True
    def L(m):
        x, y, z, a, b, c = m
        return ((1 - x) ** 2 + y ** 2 + z ** 2 + (1 - a) ** 2 + b ** 2,
                x ** 2 + (1 - y) ** 2 + z ** 2 + a ** 2 + (1 - b) ** 2,
                x ** 2 + y ** 2 + (1 - z) ** 2 + (1 - c) ** 2)
    for t in [0.2, 0.5, 0.8]:
        e = 1e-7
        p = (e * t, e * (1 - t), 1 - e); s = p[0] + p[1]
        l = L((p[0], p[1], p[2], p[0] / s, p[1] / s, 1))
        ok &= abs(l[0] - (2 + 2 * (1 - t) ** 2)) < 1e-5 and abs(l[1] - (2 + 2 * t * t)) < 1e-5
    ok &= L((0, 0, 1, 0, 0, 1)) == (3, 3, 0)
    ok &= L((0, 0, 1, .5, .5, 1)) == (2.5, 2.5, 0)
    ok &= min(L((0, 0, 1, a / 50, b / 50, 1))[0] + L((0, 0, 1, a / 50, b / 50, 1))[1]
              for a in range(51) for b in range(51)) >= 5 - 1e-12
    return ok
check('Example 8.5', ex85())

# ---------------------------------------------------------------- Prop 8.6 identity
def p86(seed=4):
    rng = random.Random(seed); ok = True
    for _ in range(200):
        N = 8
        m = [rng.random() for _ in range(N)]
        x = [rng.random() for _ in range(N)]; p = [v / sum(x) for v in x]
        nm = sum(v * v for v in m); npp = sum(v * v for v in p)
        lhs = sum(p[w] * ((nm + 1 - 2 * m[w]) - (npp + 1 - 2 * p[w])) for w in range(N))
        ok &= abs(lhs - sum((m[i] - p[i]) ** 2 for i in range(N))) < 1e-12
    return ok
check('Prop 8.6 Bayes identity', p86())

# ---------------------------------------------------------------- Prop 8.7 (Joyce foil)
def p87(seed=5):
    ok = True
    eps = 1 / 250
    def s(x):
        z = [math.exp(v) for v in x]; t = sum(z); return [v / t for v in z]
    def L(x):
        sx = s(x); pen = eps * (sum(x) - 1) ** 2
        return [(1 - sx[i]) ** 2 + pen for i in range(3)]
    e = math.e
    ok &= 1 / 7 < 1 / (1 + 2 * e) and e / (e + 2) < 3 / 5
    ok &= 4 * eps < 8 / 175 and 2 * eps < 4 / 245
    Lx = L((1, 1, 0))
    ok &= abs(Lx[0] - (((e + 1) / (2 * e + 1)) ** 2 + eps)) < 1e-12 and Lx[0] < 49 / 144 + eps < 9 / 25
    G = 300
    for i in range(G + 1):
        for j in range(G + 1 - i):
            b = (i / G, j / G, 1 - i / G - j / G)
            Lb = L(b)
            if not max(Lb[0], Lb[1]) > 9 / 25: ok = False
    Lb3 = L((.5, .5, 0)); ok &= Lb3[0] > Lx[0] and Lb3[1] > Lx[1]
    # truth-directedness: random moves closer to the truth at a random world strictly reduce the loss
    rng = random.Random(seed)
    for _ in range(20000):
        x = [rng.random() for _ in range(3)]; i = rng.randrange(3)
        y = list(x)
        for n in range(3):
            tgt = 1.0 if n == i else 0.0
            y[n] = x[n] + rng.random() * (tgt - x[n]) * (rng.random() < 0.7)
        if y != x and not L(y)[i] < L(x)[i]:
            ok = False
    return ok
check('Prop 8.7 numerics', p87())

# ---------------------------------------------------------------- Lemma 2.2 direction
# lsc of L' = f o L need not give lsc of L when f is continuous but its inverse is not:
# D = [0,1) u [2,3], f(t)=t on [0,1), t-1 on [2,3]; h(theta)=theta (theta<1), 2 (theta=1).
def lem22():
    f = lambda t: t if t < 1 else t - 1
    h = lambda th: th if th < 1 else 2.0
    # f o h (theta) = theta : continuous, hence lsc; h jumps up at 1 so is not lsc
    return all(abs(f(h(th)) - th) < 1e-15 for th in [0, .3, .999, 1.0]) and h(1.0) > 1.0
check('Lemma 2.2: transfer is one-directional (counterexample to the converse)', lem22())

print('\nALL PASS' if not FAIL else '\nFAILURES: ' + ', '.join(FAIL))
