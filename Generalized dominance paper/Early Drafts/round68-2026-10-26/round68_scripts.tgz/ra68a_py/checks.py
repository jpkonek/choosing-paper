"""RA68a sanity checks for 'Coherence and accuracy for sets of desirable gambles'.

Run: python3 -I checks.py  (writes checks.out next to this script)
These computations illustrate; the verdicts in RA68a_notes.md rest on the proofs.
"""
import itertools, math, os, sys
import numpy as np
from scipy import integrate, stats

out = []
def say(*a):
    s = " ".join(str(x) for x in a); print(s); out.append(s)

rng = np.random.default_rng(68)
phi = stats.norm.pdf

def ball_int(c, r, f, n=400):
    """integral over disc(c,r) of f(h1,h2)*gauss(h1)gauss(h2), polar quadrature"""
    def g(rho, th):
        h1 = c[0] + rho*math.cos(th); h2 = c[1] + rho*math.sin(th)
        return f(h1, h2)*phi(h1)*phi(h2)*rho
    v, e = integrate.dblquad(lambda rho, th: g(rho, th), 0, 2*math.pi, 0, r, epsabs=1e-14, epsrel=1e-10)
    return v

# ---------- Example 6.4 ----------
say("== Example 6.4 (R^2, two worlds) ==")
a, b, c = np.array([-1., 3.]), np.array([-2., 3.]), np.array([1., 1.])
cent = {"a": a, "b": b, "c": c}
for k1, k2 in itertools.combinations(cent, 2):
    d = np.linalg.norm(cent[k1]-cent[k2]); say(f"dist {k1}{k2} = {d:.3f} (>0.2 needed)")
for k, v in cent.items():
    say(f"ball {k}: min h1+h2 over ball = {v.sum()-0.1*math.sqrt(2):.3f} (>0 => inside C)")
# exact interval bounds for a'-(3/5)b'
lo1 = -1.1 + 0.6*1.9; lo2 = 2.9 - 0.6*3.1
say(f"a'-(3/5)b' lower bounds: ({lo1:.3f}, {lo2:.3f}) both >0")
# random check
A = a + 0.1*np.sqrt(rng.random(10**5))[:, None]*np.stack([np.cos(t:=2*np.pi*rng.random(10**5)), np.sin(t)], 1)
B = b + 0.1*np.sqrt(rng.random(10**5))[:, None]*np.stack([np.cos(t:=2*np.pi*rng.random(10**5)), np.sin(t)], 1)
D = A - 0.6*B
say("random a'-(3/5)b' min coords:", D.min(0))
say(f"score bound: -1.1*d/2 + 1.9d - 1.1*d/4 = {(-0.55+1.9-0.275):.3f} d")
# Gaussian instance: radii with masses delta/2, delta, delta/4
mass = lambda cc, r: ball_int(cc, r, lambda x, y: 1.0)
mV = {k: mass(v, 0.1) for k, v in cent.items()}; delta = min(mV.values())
def radius_for(cc, target):
    lo, hi = 0.0, 0.1
    for _ in range(60):
        mid = (lo+hi)/2
        if mass(cc, mid) < target: lo = mid
        else: hi = mid
    return (lo+hi)/2
rA, rBm, rBp = radius_for(a, delta/2), radius_for(b, delta), radius_for(c, delta/4)
m1 = lambda cc, r: ball_int(cc, r, lambda x, y: x)
diff = m1(a, rA) - (m1(b, rBm) + m1(c, rBp))
say(f"Gaussian instance: delta={delta:.4e}; m1(A)-m1(B) = {diff:.4e}; ratio to delta = {diff/delta:.4f} (>1.075)")
say(f"m1(B) = {m1(b, rBm)+m1(c, rBp):.4e} (<0 needed for 'not C <=_1 X')")

# ---------- Remark 4.4 ----------
say("== Remark 4.4 ==")
W = ball_int((3., -1.), 0.5, lambda x, y: x+y)
say(f"int_W (h1+h2) dmu = {W:.4e} (>0)")
# second part: Q_B = {(1/2,1/2)} ; B = {h1+h2>0, min<=0}
def massB_neg(t, N=400000):
    h = rng.standard_normal((N, 2))
    inB = (h.sum(1) > 0) & (h.min(1) <= 0)
    return np.mean(inB & (t*h[:, 0]+(1-t)*h[:, 1] < 0))
for t in [0.3, 0.45, 0.49, 0.5, 0.51, 0.55, 0.7]:
    say(f"t={t}: mu(B & q.h<0) ~ {massB_neg(t):.5f}")
h = rng.standard_normal((2_000_000, 2)); inB = (h.sum(1) > 0) & (h.min(1) <= 0)
say(f"(1/2,1/2).m(B) ~ {np.mean(np.where(inB, h.sum(1)/2, 0)):.4f} (>0)")
say("note: X = N u B = {h1+h2>0} exactly, so X is coherent in the manuscript's instance")
# incoherent variant B' = B & |h|>1
inBp = inB & (np.linalg.norm(h, axis=1) > 1)
mBp = np.array([np.mean(np.where(inBp, h[:, 0], 0)), np.mean(np.where(inBp, h[:, 1], 0))])
say(f"incoherent variant B'=B&|h|>1: m(B') ~ {mBp} (both >0, so gain -m(B') <0 at both worlds); mu(B&|h|<=1) ~ {np.mean(inB & ~(np.linalg.norm(h,axis=1)>1)):.4f}")

# ---------- One world: the ranking is transitive ----------
say("== One world (E=R): transitivity check by enumeration ==")
atoms = np.array([-2.0, -1.0, -0.5, 0.7, 1.0, 1.5])   # atoms off 0, so (M2) holds
w = np.array([1.0, 1.0, 1.0, 1.0, 1.0, 1.0])
pos = atoms > 0
models = list(itertools.product([0, 1], repeat=len(atoms)))
score = {X: float(np.dot(np.array(X)*w, atoms)) for X in models}
def leq(X, Y):  # X <=_1 Y : change from Y to X
    Xa, Ya = np.array(X, bool), np.array(Y, bool)
    add, rem = Xa & ~Ya, Ya & ~Xa
    guided = np.all(atoms[add] > 0) and np.all(atoms[rem] < 0)
    if guided: return True
    # only coherent model is C=(0,inf): could make iff rem subset pos and add disjoint from pos
    avail = np.all(pos[rem]) and not np.any(pos[add])
    return (not avail) and score[X] > score[Y] + 1e-12
viol = 0; incomp = 0
L = {(X, Y): leq(X, Y) for X in models for Y in models}
for X, Y, Z in itertools.product(models, repeat=3):
    if L[(X, Y)] and L[(Y, Z)] and not L[(X, Z)]: viol += 1
for X, Y in itertools.combinations(models, 2):
    if not L[(X, Y)] and not L[(Y, X)]: incomp += 1
say(f"one world, {len(models)} models: transitivity violations = {viol}; incomparable pairs = {incomp}")

# ---------- Veto-Brier Step 7 identity ----------
say("== Appendix D, Step 7: {g<0} = D_What ==")
n = 3; eps = 0.5; p = np.array([0.5, 0.3, 0.2])
v = np.array([(1-eps)*p + eps*np.eye(n)[i] for i in range(n)])
bad = 0
for trial in range(200):
    W0 = [i for i in range(n) if rng.random() < 0.5] or [0]
    beta = np.zeros(n); beta[W0] = rng.random(len(W0)) + 0.01
    alpha = {i: rng.random() for i in range(n) if i not in W0}
    hs = rng.standard_normal((2000, n))*3
    g = sum(alpha[i]*np.maximum(-(hs @ v[i]), 0) for i in alpha) - hs @ beta
    # D_What via vertices t in {0,1}^{complement}
    verts = []
    for t in itertools.product([0, 1], repeat=len(alpha)):
        wv = beta + sum(alpha[i]*ti*v[i] for i, ti in zip(alpha, t)) if alpha else beta.copy()
        verts.append(wv/wv.sum())
    Dw = np.all(np.stack([hs @ u > 0 for u in verts], 1), 1)
    bad += np.sum((g < 0) != Dw)
say(f"mismatches over 400000 samples: {bad}")

# ---------- Example B.1: c>0 ----------
say("== Example B.1: support function lower bound c ==")
cV, rV = np.array([0.0, 2.0]), 0.5
hh = rng.standard_normal((2_000_000, 2)); inV = np.linalg.norm(hh-cV, axis=1) < rV
angs = np.linspace(0, 2*np.pi, 361)
sup = [np.mean(np.where(inV, np.abs(hh @ np.array([math.cos(t), math.sin(t)])), 0)) for t in angs]
say(f"V=ball((0,2),0.5): min support ~ {min(sup):.4f} > 0")

with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "checks.out"), "w") as f:
    f.write("\n".join(out) + "\n")
