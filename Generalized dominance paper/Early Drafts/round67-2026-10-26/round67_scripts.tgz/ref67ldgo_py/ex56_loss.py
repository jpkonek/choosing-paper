# Example 5.6, optional loss-ranking variant (new, unrefereed in LDGO67).
# Omega = {1..W} truncation; coherent e_n (n=1..K, K<W), incoherent x with loss 1.
# L(e_n,w)=0 for w<=n, 2+n for w>n.  Exact integers.
import itertools, sys
W=int(sys.argv[1]) if len(sys.argv)>1 else 9
K=W-1
fails=0
def L(m,w):
    if m=='x': return 1
    n=m; return 0 if w<=n else 2+n
models=list(range(1,K+1))+['x']
worlds=range(1,W+1)
def wd(a,b): return all(L(a,w)<=L(b,w) for w in worlds)
def dom(a,b): return wd(a,b) and not wd(b,a)
# pairwise incomparability of e_n
for a,b in itertools.permutations(range(1,K+1),2):
    if wd(a,b): fails+=1; print('e comparable',a,b)
# every e_n undominated
for n in range(1,K+1):
    if any(dom(m,n) for m in models): fails+=1; print('e dominated',n)
# x undominated, no e_n weakly dominates x
if any(wd(n,'x') for n in range(1,K+1)): fails+=1; print('some e weakly dominates x')
if any(dom(m,'x') for m in models): fails+=1; print('x dominated')
# closure under ties: x tied with no e_n
if any(wd('x',n) and wd(n,'x') for n in range(1,K+1)): fails+=1
# guarantees on finite F with max F <= K: e_{max F} ideal on F (constant assignment, A=Delta_F)
cnt=0
for r in range(1,4):
    for F in itertools.combinations(range(1,K+1),r):
        N=max(F)
        for m in models:
            for w in F:
                cnt+=1
                if not L(N,w)<=L(m,w): fails+=1; print('guarantee fails',F,m,w)
# transitivity (complete preorder) is automatic for losses
print('checked guarantees',cnt)
print('ALL PASS' if fails==0 else f'FAILURES {fails}')
