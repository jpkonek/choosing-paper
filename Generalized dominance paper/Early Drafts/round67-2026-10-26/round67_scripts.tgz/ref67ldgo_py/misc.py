import math, random, itertools
fails=0
# Example 4.6: rescaled quadratic. Bayes models for interior p are endpoints only.
a=2**0.25
def Lq(c): return ((1-c[0])**2+c[1]**2, c[0]**2+(1-c[1])**2)
def Lr(c): return tuple(v**0.25 for v in Lq(c))
N=200
grid=[(i/N,j/N) for i in range(N+1) for j in range(N+1)]
for p1 in [0.1,0.3,0.5,0.7,0.9]:
    vals=[(p1*Lr(c)[0]+(1-p1)*Lr(c)[1],c) for c in grid]
    best=min(vals)[0]
    arg=[c for v,c in vals if v<best+1e-12]
    if not all(c in [(1.0,0.0),(0.0,1.0)] for c in arg): fails+=1; print('46',p1,arg)
# identity assignment for quadratic: p Bayes for p (closed form) - check numerically
for p1 in [0.2,0.6]:
    vals=min((p1*Lq(c)[0]+(1-p1)*Lq(c)[1],c) for c in grid)
    if abs(vals[1][0]-p1)>1/N or abs(vals[1][1]-(1-p1))>1/N: fails+=1; print('46q',vals)
# Example 6.4 (SSK Ex 2)
def g0(y): return 0 if y==0 else 1+y
def g1(y): return math.inf if y==0 else y-math.log(y)
def L64(f): return ((1-f[0])**2+g0(f[1]), f[0]**2+g1(f[1]))
m=(0.5,0.0)
if L64(m)!=(0.25,math.inf): fails+=1
if L64((1,0))!=(0,math.inf): fails+=1
# no model strictly dominates m: need L1<1/4 => f2=0 => L2=inf
for f in [(i/50,j/50) for i in range(51) for j in range(51)]:
    l=L64(f)
    if l[0]<0.25 and l[1]<math.inf: fails+=1; print('64 strict',f)
# V(p)->1 as p->delta1 with p2>0
for p2 in [1e-3,1e-5]:
    V=(1-p2)*p2+1-p2*math.log(p2)
    if abs(V-1)>0.02: fails+=1
# Example 8.5 profiles
def L85(mv):
    x,y,z,a,b,c=mv
    return ((1-x)**2+y**2+z**2+(1-a)**2+b**2, x**2+(1-y)**2+z**2+a**2+(1-b)**2, x**2+y**2+(1-z)**2+(1-c)**2)
if L85((0,0,1,0,0,1))!=(3,3,0) or L85((0,0,1,.5,.5,1))!=(2.5,2.5,0): fails+=1
# limit along (eps t, eps(1-t),1-eps): Bayes model (p1,p2,p3,p1/s,p2/s,1)
for t in [0.2,0.7]:
    eps=1e-7; p=(eps*t,eps*(1-t),1-eps); s=p[0]+p[1]
    l=L85((p[0],p[1],p[2],p[0]/s,p[1]/s,1))
    if abs(l[0]-(2+2*(1-t)**2))>1e-5 or abs(l[1]-(2+2*t**2))>1e-5: fails+=1; print('85',l)
# Prop 8.6: sum_w p_w (L(m,w)-L(p,w)) = ||m-p||^2, random finite checks
for _ in range(200):
    n=6; m=[random.random()*0.5 for _ in range(n)]
    p=[random.random() for _ in range(n)]; sp=sum(p); p=[v/sp for v in p]
    Lb=lambda v,w: sum(u*u for u in v)+1-2*v[w]
    lhs=sum(p[w]*(Lb(m,w)-Lb(p,w)) for w in range(n))
    if abs(lhs-sum((m[i]-p[i])**2 for i in range(n)))>1e-12: fails+=1
# Joyce foil (Prop 9.2): x*=(1,1,0); L1(x*)<9/25; every coherent b has max(L1,L2)>9/25; truth-directed sampled
eps=1/250
def s(x): e=[math.exp(v) for v in x]; S=sum(e); return [v/S for v in e]
def LJ(x): sx=s(x); pen=eps*(sum(x)-1)**2; return [(1-sx[i])**2+pen for i in range(3)]
xs=(1,1,0)
if not LJ(xs)[0]<9/25: fails+=1
M=300
for i in range(M+1):
    for j in range(M+1-i):
        b=(i/M,j/M,1-(i+j)/M); l=LJ(b)
        if not max(l[0],l[1])>9/25: fails+=1; print('joyce',b)
for _ in range(20000):
    x=[random.random() for _ in range(3)]; w=random.randrange(3); y=list(x)
    k=random.randrange(3); tgt=1.0 if k==w else 0.0
    y[k]=x[k]+(tgt-x[k])*random.uniform(0.01,1)
    if not LJ(y)[w]<LJ(x)[w]: fails+=1; print('td',x,y,w); break
print('ALL PASS' if fails==0 else f'FAILURES {fails}')
