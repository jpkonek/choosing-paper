# Example 5.6 (relational, reduced CC67 example) on a truncation: worlds 1..W, e_1..e_K (K<W), h, x.
from fractions import Fraction as Fr
import itertools, sys
W=int(sys.argv[1]) if len(sys.argv)>1 else 7
K=W-1
coh=[('e',n) for n in range(1,K+1)]+[('h',0)]
models=coh+[('x',0)]
def rel(a,b,w):
    if a==b: return True
    if a[0]!='x' and b[0]!='x': return True
    if b[0]=='x' and a[0]=='e': return w<=a[1]
    if b[0]=='x' and a[0]=='h': return w>=2
    return False
worlds=range(1,W+1)
wd=lambda a,b,S=worlds: all(rel(a,b,w) for w in S)
dom=lambda a,b: wd(a,b) and not wd(b,a)
fails=0
CL=[c for c in coh if not any(dom(m,c) for m in models)]
if CL!=coh: fails+=1
x=('x',0)
if any(wd(c,x) for c in coh): fails+=1; print('W holds?')
if any(dom(m,x) for m in models): fails+=1
if any(wd(x,c) and wd(c,x) for c in coh): fails+=1
# intransitive witness
if not (rel(('h',0),('e',1),1) and rel(('e',1),x,1) and not rel(('h',0),x,1)): fails+=1
# (TC)/acyclicity: no a<=b<=c with c<a (strict)
strict=lambda a,b,w: rel(a,b,w) and not rel(b,a,w)
for w in worlds:
    for a,b,c in itertools.product(models,repeat=3):
        if rel(a,b,w) and rel(b,c,w) and strict(c,a,w): fails+=1; print('TC',a,b,c,w)
# guarantees on finite F (max F <= K), grid p1 in multiples of 1/12 incl. 1/2
grid=[Fr(i,12) for i in range(13)]
for r in (1,2,3):
  for F in itertools.combinations(range(1,K+1),r):
    N=max(F)
    others=[w for w in F if w!=1]
    # parametrize p by p1 (if 1 in F) and mass on others: test p supported patterns
    for p1 in (grid if 1 in F else [Fr(0)]):
      for S in itertools.chain.from_iterable(itertools.combinations(others,k) for k in range(len(others)+1)):
        supp=([1] if p1>0 else [])+list(S)
        if not supp: continue
        if 1 in F and p1==1 and S: continue
        if (1 not in F or p1<1) and not S: continue
        assigned=('e',N) if (1 in F and p1>=Fr(1,2)) else ('h',0)
        def A(m,w):
            if m[0]!='x': return True
            if w>=2: return True
            return p1>=Fr(1,2)
        for m in models:
            for w in F:
                if A(m,w) and not rel(assigned,m,w): fails+=1; print('guar',F,p1,S,m,w)
            if not any(A(m,w) for w in supp): fails+=1; print('cov',F,p1,S,m)
print('ALL PASS' if fails==0 else f'FAILURES {fails}')
