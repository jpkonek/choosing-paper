# Example 4.7 (two-world AUDIT example), exact rationals on a t-grid.
# c_t: scores (t,1-t); x_t: (2,2). Keep all score comparisons (<=) except
# c_q <=_1 x_q for q>0, and c_0 <=_2 x_0.
from fractions import Fraction as Fr
import itertools, sys
G=int(sys.argv[1]) if len(sys.argv)>1 else 12
T=[Fr(i,G) for i in range(G+1)]
models=[('c',t) for t in T]+[('x',t) for t in T]
def sc(m,w):
    k,t=m
    return (t if w==1 else 1-t) if k=='c' else Fr(2)
def rel(a,b,w):
    if not sc(a,w)<=sc(b,w): return False
    if a[0]=='c' and b[0]=='x' and a[1]==b[1]:
        if w==1 and a[1]>0: return False
        if w==2 and a[1]==0: return False
    return True
fails=0
W=(1,2)
wd=lambda a,b: all(rel(a,b,w) for w in W)
dom=lambda a,b: wd(a,b) and not wd(b,a)
# reflexive; intransitive witness
assert all(rel(m,m,w) for m in models for w in W)
q,s=T[1],T[2]
if not (rel(('c',q),('c',s),1) and rel(('c',s),('x',q),1) and not rel(('c',q),('x',q),1)): fails+=1
# C_L = all c_t ; each x_q dominated by every c_s, s!=q ; closure under ties
CL=[m for m in models if m[0]=='c' and not any(dom(n,m) for n in models)]
if len(CL)!=len(T): fails+=1; print('CL wrong')
for qq in T:
    for ss in T:
        if ss!=qq and not dom(('c',ss),('x',qq)): fails+=1; print('not dominated',ss,qq)
    if wd(('c',qq),('x',qq)): fails+=1; print('c_q weakly dominates x_q', qq)
for m in models:
    if m[0]=='x' and any(wd(m,c) and wd(c,m) for c in CL): fails+=1
# Theorem 4.3 data: p=(1-u,u), u=p2 in grid (contains switch points). assigned c_u.
def A(m,w,u):
    k,t=m
    if k=='c': return u<=t if w==1 else u>=t
    if t>0: return u==0 if w==1 else True
    return True if w==1 else u==1
for u in T:
    supp=[w for w,pw in ((1,1-u),(2,u)) if pw>0]
    for m in models:
        for w in W:
            if A(m,w,u) and not rel(('c',u),m,w): fails+=1; print('guarantee',u,m,w)
        if not any(A(m,w,u) for w in supp): fails+=1; print('coverage',u,m)
# Direct argument: full comparison set {p: c_p <=_1 x_q} = complement of {c_p=c_q} (q>0)
for qq in T:
    for t in T:
        lhs=rel(('c',t),('x',qq),1) if qq>0 else rel(('c',t),('x',qq),2)
        if lhs != (t!=qq): fails+=1; print('full section',qq,t)
# competitiveness at vertices forces c_0 at delta_1 and c_1 at delta_2
comp1=[t for t in T if all(rel(('c',t),m,1) for m in models)]
comp2=[t for t in T if all(rel(('c',t),m,2) for m in models)]
if comp1!=[Fr(0)] or comp2!=[Fr(1)]: fails+=1; print('vertex',comp1,comp2)
print('ALL PASS' if fails==0 else f'FAILURES {fails}')
