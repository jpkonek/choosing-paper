"""REF67_out: independent numerical checks of OUT67 Example 5.9 and Remark 3.4.

Standard Gaussian mu on R^2 (satisfies (M1)-(M3); Lebesgue null sets).
Run: python3 -I check_examples.py  (writes check_examples.out next to this file)
"""
import os
import numpy as np
from scipy import integrate, optimize

OUT = []
def say(*a):
    s = " ".join(str(x) for x in a)
    print(s); OUT.append(s)

phi = lambda x, y: np.exp(-(x*x + y*y) / 2) / (2*np.pi)

def disc_moment(c, r, f):
    """integral over the disc of radius r about c of f(h) dmu(h) (polar coords)."""
    g = lambda rho, th: f(c[0] + rho*np.cos(th), c[1] + rho*np.sin(th)) * phi(c[0] + rho*np.cos(th), c[1] + rho*np.sin(th)) * rho
    v, _ = integrate.dblquad(g, 0, 2*np.pi, 0, r, epsabs=1e-13, epsrel=1e-11)
    return v

# ---------------- Example 5.9 ----------------
say("== Example 5.9 (full domain R^2, Gaussian mu) ==")
A  = ((1.0, -1.0), 0.1)
A1 = ((1.5, -0.5), 0.3)
A2 = ((-1.0, -0.5), 0.1)
h1 = lambda x, y: x
mA, mA1, mA2 = (disc_moment(c, r, h1) for c, r in (A, A1, A2))
say("m_1(A) =", mA, " m_1(A1) =", mA1, " m_1(A2) =", mA2)
say("increment m_1(A') - m_1(A) =", mA1 + mA2 - mA, "(must be > 0)")
# disjointness
d = lambda p, q: np.hypot(p[0]-q[0], p[1]-q[1])
say("A,A1 disjoint:", d(A[0], A1[0]) > A[1] + A1[1], "; A,A2 disjoint:", d(A[0], A2[0]) > A[1] + A2[1],
    "; A1,A2 disjoint:", d(A1[0], A2[0]) > A1[1] + A2[1])
# Q_A = {(t,1-t): min over disc of t h1 + (1-t) h2 >= 0}
def disc_min(c, r, t):
    q = np.array([t, 1-t]); return q @ np.array(c) - r*np.linalg.norm(q)
tmin = optimize.brentq(lambda t: disc_min(*A, t), 0.5, 1.0)
say("Q_A = {(t,1-t): t >=", round(tmin, 6), "}")
worst = min(disc_min(*A1, t) for t in np.linspace(tmin, 1, 20001))
say("A1 inside hull(A) = D_{Q_A}: min over Q_A x A1 of q.h =", worst, "(>0 => change (A',A) closed)")
say("A' misses D_{e2} = {h2>0}:", A1[0][1] + A1[1] < 0 and A2[0][1] + A2[1] < 0,
    "; A2 has h1<0:", A2[0][0] + A2[1] < 0, "; A inside {h1>0}:", A[0][0] - A[1] > 0)

# ---------------- Remark 3.4: hull inclusion alone ----------------
say("")
say("== Remark 3.4 second bullet: X = {h1+h2>0}, N = int R^2_+, B = X minus N ==")
# For q=(t,1-t), mass of B intersect {q.h<0}: B = {h1+h2>0, min(h1,h2)<=0}
def mass_B_neg(t, R=12.0):
    # integrate over B with q.h<0 using a grid (Gaussian tails negligible beyond R)
    n = 1201
    xs = np.linspace(-R, R, n); X_, Y_ = np.meshgrid(xs, xs); w = (xs[1]-xs[0])**2
    inB = (X_ + Y_ > 0) & (np.minimum(X_, Y_) <= 0)
    neg = t*X_ + (1-t)*Y_ < 0
    return float((phi(X_, Y_) * (inB & neg)).sum() * w)
for t in (0.3, 0.45, 0.49, 0.5, 0.51, 0.55, 0.7):
    say(f"  q=({t},{1-t}): mu(B & q.h<0) = {mass_B_neg(t):.3e}")
say("  => Q_B = {(1/2,1/2)} (positive mass whenever t != 1/2), hull(B) = {h1+h2>0} = X, which contains N.")
n_ = 1201; R = 12.0; xs = np.linspace(-R, R, n_); X_, Y_ = np.meshgrid(xs, xs); w = (xs[1]-xs[0])**2
inB = (X_ + Y_ > 0) & (np.minimum(X_, Y_) <= 0)
mB = np.array([(phi(X_, Y_) * inB * X_).sum()*w, (phi(X_, Y_) * inB * Y_).sum()*w])
say("  m(B) =", mB, "; (1/2,1/2).m(B) =", 0.5*mB.sum(), "(>0, so the gain m(N)-m(X) = -m(B) is not positive at both worlds)")

# Incoherent variant: X' = int R^2_+ union B', B' = B intersect {|h|>1}
say("")
say("== Incoherent variant: X' = int R^2_+ u B', B' = B & {|h|_2 > 1}, N = int R^2_+ ==")
inBp = inB & (np.hypot(X_, Y_) > 1)
for t in (0.45, 0.5, 0.55):
    neg = t*X_ + (1-t)*Y_ < 0
    say(f"  q=({t},{1-t}): mu(B' & q.h<0) = {float((phi(X_,Y_)*(inBp & neg)).sum()*w):.3e}")
missing = inB & ~inBp
say("  mu(hull(X') minus X') >= mu(B & |h|<=1) =", float((phi(X_, Y_)*missing).sum()*w), "> 0, so X' is incoherent")
mBp = np.array([(phi(X_, Y_)*inBp*X_).sum()*w, (phi(X_, Y_)*inBp*Y_).sum()*w])
say("  change X'->N removes B' only; open to the coherent {h1+h2>0}; m(B') =", mBp, "(gain -m(B') fails at a world)")
say("  RF67b family X = D_Q u B, N = D_Q with Q = Delta, Q_B = {(1/2,1/2)} strictly inside Q: N in hull(B) holds.")

here = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(here, "check_examples.out"), "w") as fh:
    fh.write("\n".join(OUT) + "\n")
