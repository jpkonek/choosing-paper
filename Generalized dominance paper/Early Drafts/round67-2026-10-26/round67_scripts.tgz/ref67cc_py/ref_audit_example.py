"""REF67_cc: independent exact check of the AUDIT_r67_compactness s5 example.
Written from the audit text, not from cc67py.  Two configurations:
 (A) two worlds {1,2} (CC67's simplification): check (LA),(C),(W),(TC), reflexivity,
     intransitivity, and condition (B) on Delta with certificates pulled back along theta(p)=p_2,
     realiser c_{theta(p)}; grid of t includes every p_2 value tested, so exact thresholds theta=s occur.
 (B) copies: worlds (type, j) for j<=J; F ranges over all subsets with <=3 worlds; same checks of
     the local hypotheses (closed sections are preimages of closed intervals under a continuous map,
     so only coverage (b) and realisation (a) need checking).
Exact rationals throughout."""
from fractions import Fraction as Fr
from itertools import product, combinations
import sys
G = int(sys.argv[1]) if len(sys.argv) > 1 else 12
T = [Fr(k, G) for k in range(G + 1)]
COH = [('c', t) for t in T]; INC = [('x', t) for t in T]; M = COH + INC
def score(m, ty):
    if m[0] == 'x': return Fr(2)
    return m[1] if ty == 1 else 1 - m[1]
def le(a, b, ty):           # a <=_ty b
    if score(a, ty) > score(b, ty): return False
    if a[0] == 'c' and b[0] == 'x' and a[1] == b[1]:
        if ty == 1 and a[1] > 0: return False
        if ty == 2 and a[1] == 0: return False
    return True
fails = []
def need(c, m):
    if not c: fails.append(m)
TY = [1, 2]
for ty in TY:
    for a in M: need(le(a, a, ty), 'refl')
    for a, b, c in product(M, repeat=3):
        if le(a, b, ty) and le(b, c, ty):
            need(not (le(c, a, ty) and not le(a, c, ty)), f'TC {a}{b}{c}')
# removed comparisons are strict score comparisons; every score tie survives in both directions
for ty in TY:
    for a, b in product(M, repeat=2):
        if score(a, ty) == score(b, ty): need(le(a, b, ty) and le(b, a, ty), 'tie kept')
wdom = lambda a, b: all(le(a, b, ty) for ty in TY)
dom = lambda a, b: wdom(a, b) and not wdom(b, a)
CL = [c for c in COH if not any(dom(m, c) for m in M)]
need(CL == COH, 'C_L = C')
need([m for m in M if not any(dom(a, m) for a in M)] == COH, 'U_L = C')
for c in COH: need([a for a in M if wdom(a, c)] == [c], 'only self')
for y in INC: need(any(wdom(c, y) for c in COH), 'W'); need(not any(wdom(c, y) and wdom(y, c) for c in COH), 'C')
for y in INC: need(not wdom(('c', y[1]), y), 'c_q never weakly dominates x_q')
need(le(('c', T[1]), ('c', T[2]), 1) and le(('c', T[2]), ('x', T[1]), 1) and not le(('c', T[1]), ('x', T[1]), 1), 'intransitive')
# global guaranteed sets K_ty(rival) in Theta=[0,1]
def K(r, ty, th):
    k, v = r
    if k == 'c': return th <= v if ty == 1 else th >= v
    if v > 0: return th == 0 if ty == 1 else True
    return True if ty == 1 else th == 1
for r in M:
    for ty in TY:
        for th in T:
            if K(r, ty, th): need(le(('c', th), r, ty), f'(a) {r} {ty} {th}')
# (A) two worlds: condition (B) with B_ty(p) = {r : K(r,ty,p_2)}, realiser c_{p_2}
for k in range(G + 1):
    p = (Fr(G - k, G), Fr(k, G)); th = p[1]
    for r in M:
        need(any(p[i] > 0 and K(r, TY[i], th) for i in range(2)), f'(B2) {r} p={p}')
# (B) copies: worlds (ty, j); F with up to 3 worlds; p on grid of denominator G
worlds = [(ty, j) for ty in TY for j in range(1, 3)]
for n in range(1, 4):
    for F in combinations(worlds, n):
        for v in product(range(G + 1), repeat=n):
            if sum(v) != G: continue
            th = Fr(sum(vi for vi, w in zip(v, F) if w[0] == 2), G)
            for r in M:
                need(any(vi > 0 and K(r, w[0], th) for vi, w in zip(v, F)), f'(b) {F} {v} {r}')
print('checks failed:', len(fails), fails[:5])
print('ALL PASS' if not fails else 'SOME FAIL')
