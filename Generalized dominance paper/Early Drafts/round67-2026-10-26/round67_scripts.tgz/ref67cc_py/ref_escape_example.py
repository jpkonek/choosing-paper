"""REF67_cc: independent exact check of the CC67 s3.5 example (written from the CC67 table, not cc67py).
Worlds 1..W.  Coherent: d, h, e_n (n=1..N, N >= W+2 so that every e_{max F} exists).
Incoherent: x, z, w_k (k=1..N).  Coherent models tied with each other; incoherent related only to
themselves on the left; coherent c <=_w y (y incoherent) per the table.
Checks: reflexivity, (TC), (LA), (C), (W) on the truncation; condition (B) on every F with |F|<=4
using CC67's realisers and listed comparisons, on an exact grid (denominator 12, so p_1 = 1/2, 1/3
occur), with the listed sets verified to be closed p_1-intervals; the finite core of the failure
argument over ALL coherent c and ALL supports S; the reduced example (e_n, h, x) where (B) holds on
every F but (W) fails; and the infinite step symbolically."""
from fractions import Fraction as Fr
from itertools import product, combinations
import sys
W = int(sys.argv[1]) if len(sys.argv) > 1 else 7
N = W + 2; GD = 12
COH = ['d', 'h'] + [('e', n) for n in range(1, N + 1)]
INC = ['x', 'z'] + [('w', k) for k in range(1, N + 1)]
M = COH + INC
def meets(c, y, w):
    if c == 'd': return {'x': True, 'z': w >= 2}.get(y, None) if y in ('x', 'z') else w > y[1]
    if c == 'h': return w >= 2 if y == 'x' else True
    n = c[1]
    if y == 'x': return w <= n
    if y == 'z': return w == 1
    return True
def le(a, b, w):
    if a == b: return True
    if a in COH: return True if b in COH else meets(a, b, w)
    return False
fails = []
def need(c, m):
    if not c: fails.append(m)
Wd = list(range(1, W + 1))
for w in Wd:
    for a, b, c in product(M, repeat=3):
        if le(a, b, w) and le(b, c, w): need(not (le(c, a, w) and not le(a, c, w)), 'TC')
wdom = lambda a, b, S=Wd: all(le(a, b, w) for w in S)
dom = lambda a, b: wdom(a, b) and not wdom(b, a)
need([c for c in COH if not any(dom(m, c) for m in M)] == COH, 'LA')
for y in INC:
    need(not any(wdom(c, y) and wdom(y, c) for c in COH), 'C')
    need(any(wdom(c, y) for c in COH), 'W')
# listed comparisons (as closed p_1-intervals) and realiser
def listed(F, y, w):           # returns closed interval [lo,hi] of p_1, or None
    if 1 not in F or y in COH or y[0] == 'w': return (Fr(0), Fr(1))
    if y == 'x': return (Fr(0), Fr(1)) if w >= 2 else (Fr(1, 2), Fr(1))
    if y == 'z': return (Fr(1, 3), Fr(1)) if w == 1 else (Fr(0), Fr(1, 3))
def realiser(F, p1):
    return ('e', max(F)) if (1 in F and p1 >= Fr(1, 2)) else 'h'
def inside(iv, p1): return iv[0] <= p1 <= iv[1]
def check_B(F, models, rivals):
    for v in product(range(GD + 1), repeat=len(F)):
        if sum(v) != GD: continue
        p = {f: Fr(vi, GD) for f, vi in zip(F, v)}; p1 = p.get(1, Fr(0))
        c = realiser(F, p1); need(c in models, 'realiser exists')
        for y in rivals:
            need(any(p[w] > 0 and inside(listed(F, y, w), p1) for w in F), f'B2 {F} {v} {y}')
            for w in F:
                if inside(listed(F, y, w), p1): need(le(c, y, w), f'B3 {F} {v} {y} {w}')
for r in range(1, 5):
    for F in combinations(Wd, r): check_B(F, COH, M)
# finite core of the failure, over all coherent c and all supports S
for r in range(1, 5):
    for F in combinations(Wd, r):
        if 1 not in F: continue
        for c in COH:
            if not all(meets(c, 'x', w) for w in F): continue
            for s in range(1, len(F) + 1):
                for S in combinations(F, s):
                    if all(any(le(c, y, w) for w in S) for y in M):  # competitive on S
                        need(c != 'd' and c != 'h' and c[1] >= max(F), 'must be e_n, n>=max F')
                        need([w for w in S if meets(c, 'z', w)] == [1], 'z only at world 1')
# infinite step, symbolically: worlds meeting x are all (d), >=2 (h), <=n (e_n); z at 1: d no, h yes, e_n yes
need(meets('d', 'z', 1) is False and not meets('h', 'x', 1), 'no global limit (d fails z at 1; h fails x at 1)')
for n in range(1, N + 1): need(not meets(('e', n), 'x', n + 1), 'e_n fails x at n+1')
# reduced example: models e_n, h, x only; (B) on every F, but no coherent model meets x everywhere
COH2 = ['h'] + [('e', n) for n in range(1, N + 1)]
for r in range(1, 5):
    for F in combinations(Wd, r): check_B(F, COH2, COH2 + ['x'])
need(not any(all(meets(c, 'x', w) for w in range(1, N + 2)) for c in COH2), 'reduced: (W) fails on worlds 1..N+1')
print('W =', W, 'checks failed:', len(fails), fails[:5])
print('ALL PASS' if not fails else 'SOME FAIL')
