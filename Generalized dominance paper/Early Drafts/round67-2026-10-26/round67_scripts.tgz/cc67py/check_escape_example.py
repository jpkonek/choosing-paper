"""CC67: exact finite checks of the example separating the local theorem's hypotheses
from (W) + finite (B) on every finite set of worlds.
Worlds 1..WM (truncation of N), coherent d, h, e_n (n=1..NM), incoherent x, z, w_k (k=1..KM).
Coherent models are tied with each other at every world; incoherent models are related only
to themselves; coherent c <=_w y (y incoherent) iff y in Meet(c, w)."""
from fractions import Fraction as Fr
from itertools import product, combinations
import sys
WM, NM, KM = (int(a) for a in sys.argv[1:4]) if len(sys.argv) > 3 else (6, 8, 8)
Wd = range(1, WM + 1)
COH = ['d', 'h'] + [('e', n) for n in range(1, NM + 1)]
INC = ['x', 'z'] + [('w', k) for k in range(1, KM + 1)]
M = COH + INC
def meet(c, y, w):
    if c == 'd':
        if y == 'x': return True
        if y == 'z': return w >= 2
        return y[1] < w
    if c == 'h':
        if y == 'x': return w >= 2
        return True
    n = c[1]
    if y == 'x': return w <= n
    if y == 'z': return w == 1
    return True
def rel(a, b, w):
    if a == b: return True
    if a in COH and b in COH: return True
    if a in COH and b in INC: return meet(a, b, w)
    return False
ok = True
def chk(c, msg):
    global ok
    if not c: ok = False; print('FAIL', msg)
wd = lambda a, b: all(rel(a, b, w) for w in Wd)
dom = lambda a, b: wd(a, b) and not wd(b, a)
CL = [c for c in COH if not any(dom(m, c) for m in M)]
chk(CL == COH, '(LA): C_L = C')
chk(not any(wd(y, c) and wd(c, y) for y in INC for c in COH), '(C)')
for y in INC: chk(any(wd(c, y) for c in COH), f'(W) for {y}')
if WM > NM: chk([c for c in COH if wd(c, 'x')] == ['d'], 'only d weakly dominates x')
# finite (B) on every F subset of 1..WM, with the stated realisers and certificates
def realiser(F, p):  # p: dict world->Fraction
    N = max(F)
    if 1 in F and p.get(1, 0) >= Fr(1, 2): return ('e', N)
    return 'h'
def cert(F, p, y, w):  # is y listed for world w at p?
    p1 = p.get(1, 0)
    if y in COH or (y not in ('x', 'z')): return True
    if 1 not in F: return True
    if y == 'x': return w >= 2 or p1 >= Fr(1, 2)
    if y == 'z': return p1 >= Fr(1, 3) if w == 1 else p1 <= Fr(1, 3)
G = 6
grid_extra = [Fr(1, 2), Fr(1, 3)]
for r in range(1, 4):
    for F in combinations(Wd, r):
        if max(F) > NM: continue  # realiser e_{max F} must exist in truncation
        pts = []
        for v in product(range(G + 1), repeat=len(F)):
            if sum(v) == G: pts.append({f: Fr(vi, G) for f, vi in zip(F, v)})
        if 1 in F and len(F) >= 2:  # exact threshold points p_1 = 1/2, 1/3
            for a in grid_extra:
                rest = [f for f in F if f != 1]
                pts.append({1: a, rest[0]: 1 - a})
        for p in pts:
            c = realiser(F, p)
            for y in M:
                chk(any(p.get(w, 0) > 0 and cert(F, p, y, w) for w in F), f'coverage F={F} p={p} y={y}')
                for w in F:
                    if cert(F, p, y, w): chk(rel(c, y, w), f'realisation F={F} p={p} y={y} w={w}')
# core of the failure of the local theorem: for F containing 1 with max F <= NM - 1,
# a coherent model that meets x at every world of F and meets every rival at some world of a
# nonempty S subset of F must be some e_n and then meets z only at world 1.
for r in range(1, 4):
    for F in combinations(Wd, r):
        if 1 not in F or max(F) >= NM: continue
        for c in COH:
            if not all(meet(c, 'x', w) for w in F): continue
            for s in range(1, len(F) + 1):
                for S in combinations(F, s):
                    if all(any(rel(c, y, w) for w in S) for y in M):
                        chk(c[0] == 'e', f'realiser at a point dominating x on F={F} is some e_n')
                        chk([w for w in S if meet(c, 'z', w)] == [1], 'z only at world 1')
# no coherent model meets x at every world and z at world 1 (WM > NM so e_n fail x somewhere)
if WM > NM: chk(not any(all(meet(c, 'x', w) for w in Wd) and meet(c, 'z', 1) for c in COH), 'no global limit')
print('ALL PASS' if ok else 'SOME FAIL')
