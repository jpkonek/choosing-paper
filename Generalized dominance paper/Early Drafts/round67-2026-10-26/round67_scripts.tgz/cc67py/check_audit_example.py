"""CC67: exact checks of the strict-separation example (AUDIT_r67_compactness s5),
on a finite grid of t-values and with TWO worlds (types 1 and 2) only.
Checks: reflexivity, (TC), no accepted cycle with a strict step, intransitivity witness,
undominated set, (W), (C), the global closed-section structure (sections are intervals /
points of [0,1]), joint realisation, and the local pulled-back coverage on Delta_F for
F with several worlds of each type (p on an exact rational grid)."""
from fractions import Fraction as Fr
from itertools import product, combinations
N = 6
T = [Fr(k, N) for k in range(N + 1)]
C = [('c', t) for t in T]; X = [('x', t) for t in T]; M = C + X
def loss(m, w):
    k, t = m
    if k == 'x': return Fr(2)
    return t if w == 1 else 1 - t
def rel(a, b, w):  # a <=_w b
    if loss(a, w) > loss(b, w): return False
    if a[0] == 'c' and b[0] == 'x' and a[1] == b[1]:
        q = a[1]
        if w == 1 and q > 0: return False
        if w == 2 and q == 0: return False
    return True
W = [1, 2]; ok = True
def chk(c, msg):
    global ok
    if not c: ok = False; print('FAIL', msg)
chk(all(rel(m, m, w) for m in M for w in W), 'reflexive')
for w in W:
    for a, b, c in product(M, repeat=3):
        if rel(a, b, w) and rel(b, c, w):
            chk(not (rel(c, a, w) and not rel(a, c, w)), 'TC')
            if rel(c, a, w):  # accepted 3-cycle: all steps must be non-strict
                chk(rel(b, a, w) and rel(c, b, w) and rel(a, c, w), 'strict step in cycle')
# intransitivity witness: c_q <=_1 c_s <=_1 x_q, not c_q <=_1 x_q (0<q<s)
q, s = T[1], T[2]
chk(rel(('c', q), ('c', s), 1) and rel(('c', s), ('x', q), 1) and not rel(('c', q), ('x', q), 1), 'intransitive witness')
wd = lambda a, b: all(rel(a, b, w) for w in W)
dom = lambda a, b: wd(a, b) and not wd(b, a)
U = [m for m in M if not any(dom(a, m) for a in M)]
chk(set(U) == set(C), 'U_L = C')
for c in C: chk([a for a in M if wd(a, c)] == [c], 'only self weakly dominates c_t')
for x in X: chk(all(dom(c, x) for c in C if c[1] != x[1]), 'x_q dominated by c_s, s!=q')
chk(not any(wd(m, c) and wd(c, m) for m in X for c in C), '(C)')
# global sections K_w(rival) subset of Theta=[0,1]
def K(r, w, th):
    k, v = r
    if k == 'c': return th <= v if w == 1 else th >= v
    if v > 0: return th == 0 if w == 1 else True
    return True if w == 1 else th == 1
for r in M:
    for w in W:
        for th in T:
            if K(r, w, th): chk(rel(('c', th), r, w), f'realiser c_theta meets {r} at {w}, theta={th}')
    chk(any(K(r, 1, th) and K(r, 2, th) for th in T), f'joint point for {r}')
# local: F has a type-1 worlds and b type-2 worlds; theta(p)=type-2 mass
G = 4
for a, b in [(1, 1), (2, 1), (1, 2), (2, 2)]:
    types = [1] * a + [2] * b
    for p in product(range(G + 1), repeat=a + b):
        if sum(p) != G: continue
        th = Fr(sum(pi for pi, ty in zip(p, types) if ty == 2), G)
        for r in M:
            chk(any(pi > 0 and K(r, ty, th) for pi, ty in zip(p, types)), f'local coverage {r} p={p}')
print('ALL PASS' if ok else 'SOME FAIL')
