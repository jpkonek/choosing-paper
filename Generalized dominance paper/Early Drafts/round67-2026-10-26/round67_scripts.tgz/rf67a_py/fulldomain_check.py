"""RF67a numerical illustration (NUMERICS) of the full-domain theorem of AUDIT_r67_brief Sec. 2.

Setting.  E = {g + t*1 : g in E0, t real}, dim E = 3, with world set Omega finite:
  (A) Omega = {0,1,2}, E = R^3 (states = simplex);
  (B) Omega = 201-point grid of [0,1], E = span{1, w, w^2} (states = polygon
      conv{(s, s^2)}: curved state space, many extreme points).
A gamble g in E0 = {g : g(w0) = 0} is coded by beta in R^2 with g(w) = <v_w, beta>,
and a state by theta in P = conv{v_w}, with q_theta(g + t1) = <theta, beta> + t.

Measure (Lemma 7.3 of the draft, atomic nu):  mu = sum_k w_k law(g_k + t 1), t ~ N(0,1).
It satisfies (M1) and (M2) (null boundaries) but NOT (M3) (finitely many lines):
this also illustrates that the defender does not use full support.
On line k every D_Q is the half-line t > -P_Q(g_k); all integrals are closed form.

For each rival X with Q_X empty we check:
  P1  eta = min_theta F(theta) > 0, F(theta) = int_X q_theta(h)^- dmu;
  P2  L = X cap {q* < 0} has max over worlds of m(L)(w) = -eta (saddle identity);
  T1  X+ = X cap {q* > 0}; q* in Q_{X+}; coherent or not;
  T2  defender N (X+ itself, or Theorem 7.7 inside hull(X+) with shrink);
      N subset {q* > 0}; hull invariance Q_{X+ \\ N} = Q_{X+} in the incoherent branch;
  T3  Q_{X \\ N} empty (polygon clipping), so the record r(N,X) is safe;
  T4  total margin min_w (m(N) - m(X))(w) >= eta.
Controls with Q_X nonempty run Theorem 7.7 inside hull(X).
Run: python3 -I fulldomain_check.py   (writes fulldomain_check.out)
"""
import numpy as np
from math import inf
from scipy.stats import norm
from scipy.optimize import minimize
from scipy.spatial import ConvexHull

rng = np.random.default_rng(67)
TOL = 1e-10

def Phi(x): return norm.cdf(x)
def phi(x):
    return 0.0 if np.isinf(x) else norm.pdf(x)

# ---------------- intervals on a line ----------------
def norm_iv(ivs):
    ivs = sorted([(a, b) for a, b in ivs if b > a + 1e-15])
    out = []
    for a, b in ivs:
        if out and a <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], b))
        else:
            out.append((a, b))
    return out

def cap(ivs, lo=-inf, hi=inf):
    return norm_iv([(max(a, lo), min(b, hi)) for a, b in ivs])

def minus(ivs, jvs):
    out = ivs
    for c, d in jvs:
        out = norm_iv([p for a, b in out for p in ((a, min(b, c)), (max(a, d), b))])
    return out

def union(ivs, jvs): return norm_iv(list(ivs) + list(jvs))

def pr(ivs): return sum(Phi(b) - Phi(a) for a, b in ivs)
def m1(ivs): return sum(phi(a) - phi(b) for a, b in ivs)   # int t phi(t) dt

# ---------------- space ----------------
class Space:
    def __init__(self, V, name):
        self.V = np.array(V, float); self.name = name
        h = ConvexHull(self.V)
        self.Pverts = self.V[h.vertices]          # ccw
        self.eq = h.equations                      # a.x + b <= 0 inside
    def Pmin(self, verts, beta):                   # P_Q(g) for polygon Q with vertices
        return float(np.min(verts @ beta))

def clip(poly, beta, tau):
    """polygon (ccw vertex array) intersect {theta : <theta,beta> >= -tau}."""
    if len(poly) == 0: return poly
    out = []
    n = len(poly)
    val = poly @ beta + tau + 1e-10
    if n == 1:
        return poly if val[0] >= 0 else np.zeros((0, 2))
    for i in range(n):
        P, Qp = poly[i], poly[(i + 1) % n]
        vp, vq = val[i], val[(i + 1) % n]
        if vp >= 0: out.append(P)
        if (vp >= 0) != (vq >= 0):
            s = vp / (vp - vq); out.append(P + s * (Qp - P))
    return np.array(out) if out else np.zeros((0, 2))

class Lines:
    def __init__(self, betas, w):
        self.B = np.array(betas, float); self.w = np.array(w, float)
    @property
    def K(self): return len(self.w)

def mom(LN, X):
    """m(X) coded as (Bvec in R^2, const c): m(X) = g + c 1 with g <-> Bvec."""
    Bv = sum(LN.w[k] * pr(X[k]) * LN.B[k] for k in range(LN.K))
    c = sum(LN.w[k] * m1(X[k]) for k in range(LN.K))
    return np.array(Bv, float), float(c)

def mass(LN, X): return sum(LN.w[k] * pr(X[k]) for k in range(LN.K))

def at_worlds(SP, m): return SP.V @ m[0] + m[1]
def sub(m, n): return (m[0] - n[0], m[1] - n[1])

def Qset(SP, LN, X):
    poly = SP.Pverts.copy()
    for k in range(LN.K):
        if LN.w[k] * pr(X[k]) <= 1e-300: continue
        tau = X[k][0][0]
        if tau == -inf: return np.zeros((0, 2))
        poly = clip(poly, LN.B[k], tau)
        if len(poly) == 0: return poly
    return poly

from scipy.optimize import linprog
def slack(SP, LN, X):
    """max over states theta of min_k (<theta,beta_k> + inf X_k)/(1+|beta_k|): < 0 iff Q_X empty."""
    A, b = [], []
    for k in range(LN.K):
        if LN.w[k] * pr(X[k]) <= 1e-300: continue
        tau = X[k][0][0]
        if tau == -inf: return -inf
        nb = 1 + np.linalg.norm(LN.B[k])
        A.append([-LN.B[k][0] / nb, -LN.B[k][1] / nb, 1.0]); b.append(tau / nb)
    for a in SP.eq:
        A.append([a[0], a[1], 0.0]); b.append(-a[2])
    r = linprog([0, 0, -1], A_ub=np.array(A), b_ub=np.array(b), bounds=[(None, None), (None, None), (None, 10)])
    return -r.fun

def area(poly):
    if len(poly) < 3: return 0.0
    x, y = poly[:, 0], poly[:, 1]
    return 0.5 * abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))

def support_gap(P1, P2, ndir=720):
    if len(P1) == 0 or len(P2) == 0: return inf if len(P1) != len(P2) else 0.0
    ang = np.linspace(0, 2 * np.pi, ndir, endpoint=False)
    D = np.stack([np.cos(ang), np.sin(ang)], 1)
    return float(np.max(np.abs((P1 @ D.T).min(0) - (P2 @ D.T).min(0))))

def minimize_over_P(SP, f, g, x0=None):
    cons = [{'type': 'ineq', 'fun': (lambda th, a=a: -(a[:2] @ th + a[2])),
             'jac': (lambda th, a=a: -a[:2])} for a in SP.eq]
    x0 = SP.Pverts.mean(0) if x0 is None else x0
    best = None
    for start in [x0] + [SP.Pverts[i] * 0.9 + 0.1 * SP.Pverts.mean(0) for i in range(0, len(SP.Pverts), max(1, len(SP.Pverts) // 6))]:
        r = minimize(f, start, jac=g, constraints=cons, method='SLSQP',
                     options={'ftol': 1e-15, 'maxiter': 2000})
        th = r.x
        if np.max(SP.eq[:, :2] @ th + SP.eq[:, 2]) > 1e-9: continue
        if best is None or f(th) < f(best): best = th
    return best

# ---------------- Proposition: uniformly losing part ----------------
def F_neg(SP, LN, X, th):
    c = LN.B @ th; val = 0.0; gr = np.zeros(2)
    for k in range(LN.K):
        for a, b in X[k]:
            u = min(b, -c[k])
            if u > a:
                val += LN.w[k] * (-c[k] * (Phi(u) - Phi(a)) - (phi(a) - phi(u)))
                gr -= LN.w[k] * (Phi(u) - Phi(a)) * LN.B[k]
    return val, gr

def proposition(SP, LN, X):
    f = lambda th: F_neg(SP, LN, X, th)[0]
    g = lambda th: F_neg(SP, LN, X, th)[1]
    th = minimize_over_P(SP, f, g)
    eta = f(th)
    c = LN.B @ th
    L = [cap(X[k], hi=-c[k]) for k in range(LN.K)]
    Xp = [cap(X[k], lo=-c[k]) for k in range(LN.K)]
    mL = mom(LN, L)
    return th, eta, L, Xp, mL

# ---------------- Theorem 7.7 inside hull(Y) ----------------
def thm77(SP, LN, Y):
    QY = Qset(SP, LN, Y)
    assert len(QY) > 0
    gam = np.array([-SP.Pmin(QY, LN.B[k]) for k in range(LN.K)])  # hull(Y) threshold
    mY = mom(LN, Y)
    def Psi(th):
        c = LN.B @ th; val = -(th @ mY[0] + mY[1]); gr = -mY[0].copy()
        for k in range(LN.K):
            u = max(gam[k], -c[k])
            val += LN.w[k] * (c[k] * (1 - Phi(u)) + phi(u))
            gr += LN.w[k] * (1 - Phi(u)) * LN.B[k]
        return val, gr
    th2 = minimize_over_P(SP, lambda t: Psi(t)[0], lambda t: Psi(t)[1])
    v = Psi(th2)[0]
    c2 = LN.B @ th2
    if v < 1e-9:
        return None
    thr0 = np.maximum(gam, -c2)
    N0 = [[(thr0[k], inf)] for k in range(LN.K)]
    marg0 = at_worlds(SP, sub(mom(LN, N0), mY)).min()
    PS = np.array([np.min(SP.V @ LN.B[k]) for k in range(LN.K)])
    PG = -gam
    tau = 0.5
    while True:
        Ptau = (1 - tau) * PG + tau * PS
        thr = np.maximum(thr0, -Ptau)
        N = [[(thr[k], inf)] for k in range(LN.K)]
        marg = at_worlds(SP, sub(mom(LN, N), mY)).min()
        gain = mass(LN, [minus(N[k], Y[k]) for k in range(LN.K)])
        if marg >= v / 2 and gain > 1e-13: break
        tau /= 2
        if tau < 1e-14: raise RuntimeError('shrink failed')
    QYmN = Qset(SP, LN, [minus(Y[k], N[k]) for k in range(LN.K)])
    hullgap = support_gap(QYmN, QY)
    return dict(N=N, thr=thr, v=v, marg0=marg0, marg=marg, tau=tau, gain=gain,
                hullgap=hullgap, QY=QY, th2=th2)

def is_coherent(SP, LN, Y):
    QY = Qset(SP, LN, Y)
    if len(QY) == 0: return False, QY
    H = [[(-SP.Pmin(QY, LN.B[k]), inf)] for k in range(LN.K)]
    d = mass(LN, [union(minus(Y[k], H[k]), minus(H[k], Y[k])) for k in range(LN.K)])
    return d < 1e-8, QY

# ---------------- full-domain repair ----------------
def repair(SP, LN, X, label, out):
    QX = Qset(SP, LN, X)
    rec = {'label': label}
    if slack(SP, LN, X) >= -1e-9:
        coh, _ = is_coherent(SP, LN, X)
        if coh:
            out.append(f"{label}: coherent, skipped"); return None
        R = thm77(SP, LN, X)
        if R is None:
            out.append(f"{label}: numerically coherent, skipped"); return None
        N = R['N']
        tot = at_worlds(SP, sub(mom(LN, N), mom(LN, X))).min()
        add = mass(LN, [minus(N[k], X[k]) for k in range(LN.K)])
        out.append(f"{label}: CASE Q_X nonempty (area {area(QX):.3g}); v={R['v']:.4g} "
                   f"marg(N0)-v={R['marg0']-R['v']:.1e} tau={R['tau']:.3g} "
                   f"margin={tot:.4g} (>=v/2: {tot >= R['v']/2 - 1e-12}) mu(N\\X)={add:.3g} "
                   f"hull gap |Q_(X\\N)-Q_X|={R['hullgap']:.1e}")
        ok = tot > 0 and add > 0 and R['hullgap'] < 1e-8
        return ok
    th, eta, L, Xp, mL = proposition(SP, LN, X)
    sat = at_worlds(SP, mL).max()          # should equal -eta
    c = LN.B @ th
    QXp = Qset(SP, LN, Xp)
    qstar_in = len(QXp) > 0 and all(LN.B[k] @ th >= -Xp[k][0][0] - 1e-12
                                    for k in range(LN.K) if pr(Xp[k]) > 0)
    coh, _ = is_coherent(SP, LN, Xp) if len(QXp) > 0 else (False, None)
    gain_Xp = at_worlds(SP, sub(mom(LN, Xp), mom(LN, X))).min()
    if coh:
        N = [[(-SP.Pmin(QXp, LN.B[k]), inf)] for k in range(LN.K)]
        branch = 'X+ coherent: N = X+'; hullgap = 0.0; tau = None
    else:
        R = thm77(SP, LN, Xp)
    if (not coh) and R is None:
        coh = True
    if coh:
        N = [[(-SP.Pmin(QXp, LN.B[k]), inf)] for k in range(LN.K)]
        branch = 'X+ coherent (numerically): N = hull(X+)'; hullgap = 0.0; tau = None
    else:
        N = R['N']; hullgap = R['hullgap']; tau = R['tau']
        branch = f"X+ incoherent (mu(X+)={mass(LN, Xp):.3g}): Thm 7.7 in hull(X+), v'={R['v']:.3g}, tau={tau:.3g}"
    Nsub = all(N[k][0][0] >= -c[k] - 1e-8 for k in range(LN.K))      # N inside {q*>0}
    XmN = [minus(X[k], N[k]) for k in range(LN.K)]
    Lleft = mass(LN, [minus(L[k], XmN[k]) for k in range(LN.K)])        # mu(L \ (X\N))
    QXmN = Qset(SP, LN, XmN); slk = slack(SP, LN, XmN)
    tot = at_worlds(SP, sub(mom(LN, N), mom(LN, X))).min()
    add = mass(LN, [minus(N[k], X[k]) for k in range(LN.K)])
    # Alternative (one more relaxed minimax, no shrink): maximise min-world gain over Y inside D_{q*}
    gam = -c                                   # D_{q*} threshold on each line
    mX = mom(LN, X)
    def Psi(t2):
        c2 = LN.B @ t2; val = -(t2 @ mX[0] + mX[1]); gr = -mX[0].copy()
        for k in range(LN.K):
            u = max(gam[k], -c2[k])
            val += LN.w[k] * (c2[k] * (1 - Phi(u)) + phi(u)); gr += LN.w[k] * (1 - Phi(u)) * LN.B[k]
        return val, gr
    t2 = minimize_over_P(SP, lambda t: Psi(t)[0], lambda t: Psi(t)[1])
    v2 = Psi(t2)[0]
    Nalt = [[(max(gam[k], -(LN.B[k] @ t2)), inf)] for k in range(LN.K)]
    tot_alt = at_worlds(SP, sub(mom(LN, Nalt), mX)).min()
    slk_alt = slack(SP, LN, [minus(X[k], Nalt[k]) for k in range(LN.K)])
    alt_ok = tot_alt >= eta - 1e-9 and abs(tot_alt - v2) < 1e-7 and slk_alt < 0
    out.append(f"    alt two-prior defender D_[q*,pi*]: value v''={v2:.4g}, min-world margin={tot_alt:.4g} "
               f"(>= eta: {tot_alt >= eta-1e-9}; = v'': {abs(tot_alt-v2)<1e-7}); Q_(X\\N) empty (slack {slk_alt:.2e}) => {'OK' if alt_ok else 'FAIL'}")
    ok = (alt_ok and eta > 0 and abs(sat + eta) < 1e-7 and qstar_in and Nsub and Lleft < 1e-10
          and len(QXmN) == 0 and slk < 0 and tot >= eta - 1e-9 and hullgap < 1e-8)
    out.append(f"{label}: CASE Q_X empty; eta={eta:.4g}; max_w m(L)(w)+eta={sat+eta:.1e}; "
               f"min_w gain(X+ vs X)-eta={gain_Xp-eta:.1e}; q* in Q_(X+): {qstar_in}; {branch}; "
               f"hull gap={hullgap:.1e}; N in {{q*>0}}: {Nsub}; mu(L minus (X\\N))={Lleft:.1e}; "
               f"Q_(X\\N) empty: {len(QXmN)==0} (LP slack {slk:.2e}); total margin={tot:.4g} (>= eta: {tot >= eta-1e-9}); "
               f"mu(N\\X)={add:.3g}  => {'OK' if ok else 'FAIL'}")
    return ok

# ---------------- rivals ----------------
def DQ(SP, LN, poly):
    return [[(-SP.Pmin(poly, LN.B[k]), inf)] for k in range(LN.K)]

def negDQ(SP, LN, poly):  # -D_Q on line k: t < -max_Q <theta,beta_k>
    return [[(-inf, -float(np.max(poly @ LN.B[k])))] for k in range(LN.K)]

def triangle_cuts(T):
    cuts = []
    for i in range(3):
        A, B, C = T[i], T[(i + 1) % 3], T[(i + 2) % 3]
        d = B - A; n = np.array([d[1], -d[0]])
        if n @ (C - A) > 0: n = -n            # exterior normal
        cuts.append((n, -float(n @ A)))       # {<theta,n> >= -tau} with tau = -<A,n>
    return cuts

def build(SP, K=40, scale=2.0, extra=()):
    betas = [scale * rng.standard_normal(2) for _ in range(K)] + [b for b, _ in extra]
    w = [1.0 / (1 + np.linalg.norm(b)) for b in betas[:K]] + [wt for _, wt in extra]
    w = np.array(w); w = w / w.sum()
    return Lines(betas, w)

def run_space(SP, tri, out):
    res = []
    cuts = triangle_cuts(np.array(tri))
    for eps, wt in [(0.5, 0.02), (0.05, 0.005), (0.005, 0.001)]:
        LN = build(SP, extra=[(n, wt) for n, _ in cuts])
        K0 = LN.K - 3
        full = [[(-inf, inf)] for _ in range(LN.K)]
        S = SP.Pverts
        DS = DQ(SP, LN, S)
        if eps == 0.5:
            res.append(repair(SP, LN, full, 'R1 X = E', out))
            res.append(repair(SP, LN, [union(a, b) for a, b in zip(DS, negDQ(SP, LN, S))], 'R2 X = D_S u -D_S', out))
            Kp = 0.7 * S.mean(0) + 0.3 * S
            res.append(repair(SP, LN, [union(a, b) for a, b in zip(DQ(SP, LN, Kp), negDQ(SP, LN, Kp))], 'R3 X = D_K u -D_K', out))
            res.append(repair(SP, LN, [[(-inf, -float(np.max(SP.V @ LN.B[k])))] for k in range(LN.K)], 'R4 X = sure losses {sup h<0}', out))
            res.append(repair(SP, LN, [minus(f, d) for f, d in zip(full, DS)], 'R5 X = E \\ D_S', out))
        thin = [list(DS[k]) for k in range(LN.K)]
        for j, (n, tau) in enumerate(cuts):
            thin[K0 + j] = union(thin[K0 + j], [(tau, tau + eps)])
        res.append(repair(SP, LN, thin, f'R6 thin pairwise-consistent bets, eps={eps}, w={wt}', out))
    # random rivals
    LN = build(SP)
    nQe = 0; trials = 0
    while nQe < 12 and trials < 400:
        trials += 1
        X = []
        for k in range(LN.K):
            ivs = []
            for _ in range(rng.integers(0, 3)):
                a = rng.normal(0, 1.5); ivs.append((a, a + rng.exponential(1.5)))
            if rng.random() < 0.5: ivs.append((rng.normal(0, 1), inf))
            X.append(norm_iv(ivs))
        if slack(SP, LN, X) < -1e-6:
            nQe += 1; res.append(repair(SP, LN, X, f'R7 random #{trials}', out))
    # controls with Q_X nonempty: union of two coherent models with holes
    S = SP.Pverts
    for i in range(4):
        th1 = S.T @ rng.dirichlet(np.ones(len(S))); th2 = S.T @ rng.dirichlet(np.ones(len(S)))
        A = DQ(SP, LN, th1[None, :]); B = DQ(SP, LN, th2[None, :])
        X = [union(a, b) for a, b in zip(A, B)]
        for k in rng.choice(LN.K, 5, replace=False):
            t0 = X[k][0][0] + rng.exponential(1.0); X[k] = minus(X[k], [(t0, t0 + 0.5)])
        res.append(repair(SP, LN, X, f'C{i} union of two precise models with holes', out))
    for i in range(4):
        th0 = S.T @ rng.dirichlet(np.ones(len(S)))
        K1 = np.array([th0, S.T @ rng.dirichlet(np.ones(len(S))), S.T @ rng.dirichlet(np.ones(len(S)))])
        K2 = np.array([th0, S.T @ rng.dirichlet(np.ones(len(S))), S.T @ rng.dirichlet(np.ones(len(S)))])
        X = [union(a, b) for a, b in zip(DQ(SP, LN, K1), DQ(SP, LN, K2))]
        for k in rng.choice(LN.K, 5, replace=False):
            t0 = X[k][0][0] + rng.exponential(1.0); X[k] = minus(X[k], [(t0, t0 + 0.5)])
        res.append(repair(SP, LN, X, f'D{i} Q_X nonempty control (D_K1 u D_K2, K1,K2 share a state, with holes)', out))
    return res

def main():
    out = []
    SA = Space([(0, 0), (1, 0), (0, 1)], 'R^3, three worlds')
    grid = np.linspace(0, 1, 201)
    SB = Space(np.stack([grid, grid ** 2], 1), 'span{1,w,w^2} on 201-point grid of [0,1]')
    allres = []
    for SP, tri in [(SA, [(0.2, 0.2), (0.5, 0.2), (0.25, 0.5)]),
                    (SB, [(0.3, 0.15), (0.6, 0.45), (0.55, 0.32)])]:
        out.append(f"=== Space: {SP.name}; |Omega|={len(SP.V)}; extreme states={len(SP.Pverts)} ===")
        r = run_space(SP, tri, out)
        r = [x for x in r if x is not None]
        out.append(f"--- {sum(r)}/{len(r)} OK in this space")
        allres += r
    out.append(f"=== TOTAL {sum(allres)}/{len(allres)} OK ===")
    txt = "\n".join(out)
    print(txt)
    open('fulldomain_check.out', 'w').write(txt + "\n")

if __name__ == '__main__':
    main()
