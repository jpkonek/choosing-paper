"""RF67b: the rival X = E (contains h and -h for every h), Gaussian mu, two spaces.
(1) Omega=(0,1], E={a+b w}: states q_s(a+bw)=a+bs, s in [0,1]; q_0 is not an evaluation.
    F(q_s)=E[(a+bs)^-]=sqrt(1+s^2)/sqrt(2 pi): q*=q_0, eta=1/sqrt(2 pi), L={a<0}, m(L)=-eta*1.
(2) Omega=[0,1], E=span{1,w,w^2}: F(q)=|q|/sqrt(2 pi), minimised over the moment space at
    q*=(1,0,0)=delta_0; same eta, L={a<0}.
Both: X_+={q*>0}=D_{q*} is coherent, N=X_+, record (empty, L) safe since m(L)=-eta*1.
Exact values above; this script confirms them by Monte Carlo.  python3 -I whole_space.py
"""
import numpy as np
rng = np.random.default_rng(67)
out = []
def P(*a):
    s = " ".join(str(x) for x in a); print(s); out.append(s)
eta = 1/np.sqrt(2*np.pi)
Z = rng.standard_normal((4_000_000, 3))
# (1)
H = Z[:, :2]
ss = np.linspace(0, 1, 101)
F = [np.mean(np.maximum(-(H[:, 0] + s*H[:, 1]), 0)) for s in ss]
P("(1) argmin_s F(q_s) =", ss[int(np.argmin(F))], " min F =", min(F), " exact eta =", eta)
mL = (H * (H[:, 0] < 0)[:, None]).mean(0)
P("(1) m(L) coefficients (a,b) =", mL, " exact (-eta, 0) =", (-eta, 0.0))
# (2)
F2 = lambda q: np.mean(np.maximum(-(Z @ q), 0))
best = min(((F2(np.array([1, m1, m1*m1 + t*(m1 - m1*m1)])), m1, t)
            for m1 in np.linspace(0, 1, 21) for t in np.linspace(0, 1, 11)))
P("(2) grid argmin over moment space (m1,t) =", best[1:], " F =", best[0], " exact eta =", eta)
mL2 = (Z * (Z[:, 0] < 0)[:, None]).mean(0)
P("(2) m(L) coefficients =", mL2, " exact (-eta,0,0)")
open(__file__.replace('.py', '.out'), 'w').write("\n".join(out) + "\n")
