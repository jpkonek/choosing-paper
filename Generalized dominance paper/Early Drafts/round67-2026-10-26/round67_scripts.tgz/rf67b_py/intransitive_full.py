"""RF67b: the simple ranking on the full domain E = R^2 (Omega={1,2}, mu standard Gaussian) is not transitive.
A = ball(0.1) about (1,-1); A1 = ball(0.3) about (1.5,-0.5); A2 = ball(0.1) about (-1,-0.5); A' = A1 u A2.
Claims at world 1:  A' <=_1 A  (record (A',A): safe since A1 inside hull(A), and m_1(A') > m_1(A));
                    A <=_1 {}  (record (A,{}) is guidance at world 1);
                    not A' <=_1 {} (record (A',{}) is not guidance (A2 has h_1<0) and applies to D_{e2}={h_2>0}).
python3 -I intransitive_full.py
"""
import numpy as np
out=[]
def P(*a):
    s=" ".join(str(x) for x in a); print(s); out.append(s)
def ball_moment(c, r, n=801):
    xs=np.linspace(-r,r,n); X,Y=np.meshgrid(xs,xs); inside=X**2+Y**2<r*r
    H1=c[0]+X[inside]; H2=c[1]+Y[inside]; dens=np.exp(-(H1**2+H2**2)/2)/(2*np.pi); dA=(xs[1]-xs[0])**2
    return np.array([np.sum(H1*dens)*dA, np.sum(H2*dens)*dA]), np.sum(dens)*dA, H1, H2
mA,_,a1,a2=ball_moment((1,-1),.1); m1,_,b1,b2=ball_moment((1.5,-.5),.3); m2,_,c1,c2=ball_moment((-1,-.5),.1)
P("m(A) =",mA," m(A1) =",m1," m(A2) =",m2)
P("m_1(A') - m_1(A) =",m1[0]+m2[0]-mA[0]," (>0 needed)")
P("A inside {h1>0}:",a1.min()>0, "; A2 has h1<0:",c1.max()<0, "; A' inside {h2<0} (so A' misses D_{e2}):",max(b2.max(),c2.max())<0)
# Q_A = {q=(t,1-t): t*h1+(1-t)*h2 >= 0 on A}; hull(A) = {h: min_{q in Q_A} q.h > 0}
ts=np.linspace(0,1,100001); ok=np.array([np.min(t*a1+(1-t)*a2)>=0 for t in ts[::100]])
tmin=ts[::100][ok].min(); P("Q_A = {(t,1-t): t >=",tmin,"}")
P("A1 inside hull(A): min over t in [tmin,1] and h in A1 of q.h =",min(np.min(t*b1+(1-t)*b2) for t in (tmin,1.0)))
open(__file__.replace('.py','.out'),'w').write("\n".join(out)+"\n")
