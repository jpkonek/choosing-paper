"""RF67b NUMERICS: full-domain Case 2 (Q_X empty) with a thinly spread sure loss.

Omega = [0,1] (uncountable), E = span{1, w, w^2} (gambles h = a + b w + c w^2),
mu = standard Gaussian law of (a,b,c).  States = (1, m1, m2) with (m1,m2) in the
moment space M = {0<=m1<=1, m1^2<=m2<=m1}; its extreme points are the evaluations.

Rival X = union of thin cones (angular radius rho) around g_c = delta - (w-c)^2,
c in [0,1].  Each g_c is positive near c, so no single direction is a sure loss,
but every state is negative on some g_c (take |c - mean| > sqrt(delta)), so Q_X = {}.

Checks (Proposition and Theorem of AUDIT_r67_brief Sec. 2):
 1. eta = min_q int_X q(h)^- dmu > 0, attained at q*.
 2. L = X cap {q* < 0}: max_w m(L)(w) <= -eta (saddle: = -eta).
 3. Case-2 defender, route A (half-space G1={q*>0}) and route B (G1 = hull(X_+)):
    N = G1 cap {pi* > 0};  min_w (m(N)-m(X))(w) >= eta;  N inside {q*>0};  L inside X\\N.
Quadrature: Fibonacci sphere, Gaussian = R*U with E[R] = 2 sqrt(2/pi).
Run: python3 -I thin_sure_loss.py  (writes thin_sure_loss.out)
"""
import numpy as np
from scipy.optimize import minimize
from scipy.spatial import ConvexHull

out = []
def P(*a):
    s = " ".join(str(x) for x in a); print(s); out.append(s)

NPTS = 3_000_000
ER = 2*np.sqrt(2/np.pi)
i = np.arange(NPTS) + 0.5
phi = np.arccos(1 - 2*i/NPTS); th = np.pi*(1+5**0.5)*i
U = np.stack([np.cos(th)*np.sin(phi), np.sin(th)*np.sin(phi), np.cos(phi)], 1)
W = ER/NPTS                         # weight of each sample for first-moment integrals
wg = np.linspace(0, 1, 2001)        # world grid for reporting (exact max computed too)

def maxquad(m):   # exact max over w in [0,1] of m0 + m1 w + m2 w^2
    cands = [0.0, 1.0]
    if abs(m[2]) > 1e-15:
        v = -m[1]/(2*m[2])
        if 0 < v < 1: cands.append(v)
    return max(m[0]+m[1]*w+m[2]*w*w for w in cands)
def minquad(m): return -maxquad(-np.asarray(m))

def state(x): return np.array([1.0, x[0], x[1]])
cons = [{'type':'ineq','fun':lambda x: x[0]},{'type':'ineq','fun':lambda x: 1-x[0]},
        {'type':'ineq','fun':lambda x: x[1]-x[0]**2},{'type':'ineq','fun':lambda x: x[0]-x[1]}]

def argmin_over_M(fun, grad, ngrid=41):
    best = None
    for a in np.linspace(0,1,ngrid):
        for t in np.linspace(0,1,ngrid//2+1):
            x = np.array([a, a*a + t*(a-a*a)])
            v = fun(x)
            if best is None or v < best[0]: best = (v, x)
    r = minimize(fun, best[1], jac=grad, constraints=cons, method='SLSQP',
                 options={'ftol':1e-14,'maxiter':500})
    x = r.x if r.fun <= best[0] else best[1]
    return x, fun(x)

for delta, rho, withp in [(0.02, 0.06, False), (0.05, 0.04, False), (0.01, 0.08, False), (0.02, 0.06, True), (0.05, 0.04, True)]:
    P(f"=== delta={delta}, rho={rho}, X also contains the half-space {{p.h>0}}, p = Lebesgue mean: {withp} ===")
    cs = np.linspace(0, 1, 401)
    G = np.stack([delta - cs**2, 2*cs, -np.ones_like(cs)], 1)
    G /= np.linalg.norm(G, axis=1, keepdims=True)
    inX = np.zeros(NPTS, bool); cr = np.cos(rho)
    for s in range(0, NPTS, 200_000):
        inX[s:s+200_000] = (U[s:s+200_000] @ G.T).max(1) > cr
    if withp:
        inX |= (U @ np.array([1.0, 0.5, 1/3])) > 0
    UX = U[inX]
    P("mu(X) =", inX.mean())
    # sanity: no g_c is a sure loss; every state negative on some g_c
    P("min over c of max_w g_c(w) =", min(maxquad([delta-c*c, 2*c, -1]) for c in cs), "(>0: no single sure loss)")

    def F(x):
        q = state(x); s = UX @ q; return W*np.sum(np.maximum(-s, 0))
    def dF(x):
        q = state(x); s = UX @ q; neg = s < 0; return -W*UX[neg][:, 1:].sum(0)
    xs, eta = argmin_over_M(F, dF)
    qs = state(xs)
    P("q* = (1, m1, m2) =", qs, " eta = min_q int_X q^- =", eta)
    P("q* on evaluation curve? m2 - m1^2 =", xs[1]-xs[0]**2, "; m1 - m2 =", xs[0]-xs[1])
    s = UX @ qs
    mL = W*UX[s < 0].sum(0); mX = W*UX.sum(0); mXp = W*UX[s > 0].sum(0)
    P("m(L) coefficients =", mL, " max_w m(L)(w) =", maxquad(mL), " vs -eta =", -eta)
    P("saddle identity: min over states of q(-m(L)) = min_w -m(L)(w) =", -maxquad(mL),
      " rel.err vs eta =", abs(-maxquad(mL)-eta)/eta)
    P("Q_L empty certificate: m(L) <= -eta(1-1e-3) at every world:", maxquad(mL) <= -eta*(1-1e-3))
    P("min_w (m(X_+)-m(X))(w) =", minquad(mXp-mX))

    def defender(G1mask, label):
        UG = U[G1mask]
        def H(x):
            p = state(x); s = UG @ p; return W*np.sum(np.maximum(s,0)) - p @ mX
        def dH(x):
            p = state(x); s = UG @ p; pos = s > 0; return W*UG[pos][:,1:].sum(0) - mX[1:]
        xp, v = argmin_over_M(H, dH)
        p = state(xp); Nmask = G1mask & (U @ p > 0)
        mN = W*U[Nmask].sum(0)
        marg = minquad(mN - mX)
        bad = np.sum(Nmask & (U @ qs <= 0))
        Lmask = np.zeros(NPTS, bool); Lmask[np.flatnonzero(inX)[s < 0]] = True
        P(f"[{label}] pi* =", p, " v' =", v, " min_w (m(N)-m(X))(w) =", marg,
          " >= eta?", marg >= eta*(1-1e-3), " ; samples of N with q*<=0:", bad,
          " ; samples of L inside N:", int(np.sum(Lmask & Nmask)),
          " ; mu(N\\X) =", np.mean(Nmask & ~inX))
    defender(U @ qs > 0, "route A: G1 = {q*>0}")
    # route B: G1 = hull(X_+), with Q_{X_+} computed from the convex hull of X_+ in the plane q*.u = 1
    Up = UX[s > 0]; proj = Up/(Up @ qs)[:, None]
    # coordinates in the plane: basis orthogonal to qs
    e1 = np.cross(qs, [0, 0, 1.0]); e1 /= np.linalg.norm(e1); e2 = np.cross(qs/np.linalg.norm(qs), e1)
    pts = np.stack([proj @ e1, proj @ e2], 1)
    hv = proj[ConvexHull(pts).vertices]
    grid = [(xs[0], xs[1])]
    for aa in np.concatenate([np.linspace(0, 1, 801), np.clip(xs[0] + np.linspace(-0.05, 0.05, 1001), 0, 1)]):
        for t in np.concatenate([np.linspace(0, 1, 201), np.linspace(0, 0.02, 201)]):
            grid.append((aa, aa*aa + t*(aa-aa*aa)))
    grid = np.array(grid); Qg = np.column_stack([np.ones(len(grid)), grid])
    ok = (Qg @ hv.T).min(1) >= -1e-12
    QX = Qg[ok]
    P("route B: #hull vertices of X_+ =", len(hv), " #grid states in Q_{X_+} =", ok.sum(),
      " q* in Q_{X_+}:", (hv @ qs).min() > 0)
    P("route B: extent of Q_{X_+} grid: m1 in", QX[:,1].min(), QX[:,1].max(), "; max (m2-m1^2) =", (QX[:,2]-QX[:,1]**2).max())
    if ok.sum() >= 3:
        try:
            QV = QX[ConvexHull(QX[:, 1:]).vertices]
        except Exception:
            QV = QX
    else:
        QV = QX
    G1 = np.zeros(NPTS, bool)
    for st in range(0, NPTS, 200_000):
        G1[st:st+200_000] = (U[st:st+200_000] @ QV.T).min(1) > 0
    P("route B: mu(hull(X_+)) =", G1.mean(), " ; X_+ samples outside hull (grid error):",
      int(np.sum(inX & (U @ qs > 0) & ~G1)))
    defender(G1, "route B: G1 = hull(X_+)")

open(__file__.replace('.py', '.out'), 'w').write("\n".join(out) + "\n")
